
using UnityEngine;
namespace Bokura
{
	public class AnimKeyEvent : MonoBehaviour
	{
		public Bokura.OnAvatarAnimDelegate onAnimEvent;
		public void OnAnimationKey(string eventName)
		{
			if(onAnimEvent!=null)
			{
				//onAnimEvent(eventName);
			}
		}
	}

}