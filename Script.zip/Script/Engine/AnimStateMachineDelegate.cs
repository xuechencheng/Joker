using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{

	public class AnimStateMachineDelegate : StateMachineBehaviour 
	{

		public int EntityStateID;
        public int Layer;
		// OnStateEnter is called before OnStateEnter is called on any state inside this state machine
		//override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
		//      param = Random. (
		//}

		// OnStateUpdate is called before OnStateUpdate is called on any state inside this state machine
		//override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
		//
		//}

		// OnStateExit is called before OnStateExit is called on any state inside this state machine

		//Bokura.AnimStateMachineStateChangeDelegate m_onLeaveState;
		public Bokura.OnAnimStateMachineChangeDelegate m_onLeaveStateMachine;
		public Bokura.OnAnimStateMachineChangeDelegate m_onEnterStateMachine;
		public Bokura.OnAnimStateMachineChangeDelegate m_onEnterState;


		public Bokura.OnAnimStateMachineChangeDelegate onLeaveStateMachine
		{
			get
			{
				return m_onLeaveStateMachine;
			}
			set
			{
				m_onLeaveStateMachine = value;
			}
		}
		// OnStateMove is called before OnStateMove is called on any state inside this state machine
		//override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
		//
		//}

		// OnStateIK is called before OnStateIK is called on any state inside this state machine
		//override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
		//
		//}

		// OnStateMachineEnter is called when entering a statemachine via its Entry Node
		public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
		{
			if(m_onEnterState!=null)
			{
				m_onEnterState(EntityStateID,Layer);
			}	
		}

		override public void OnStateMachineEnter(Animator animator, int stateMachinePathHash)
		{
			if (m_onEnterStateMachine != null)
			{
				m_onEnterStateMachine(EntityStateID, Layer);
			}
		}

		// OnStateMachineExit is called when exiting a statemachine via its Exit Node
		override public void OnStateMachineExit(Animator animator, int stateMachinePathHash)
		{
			if(m_onLeaveStateMachine!=null)
			{
				m_onLeaveStateMachine(EntityStateID, Layer);
			}
		}


		//Animator.isinState ("state") 
	}

}

