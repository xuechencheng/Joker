
using UnityEngine;

namespace Bokura
{
    public class AnimatorIKComponent : MonoBehaviour
    {
        protected Animator animator = null;
        //public Transform target = null;
        protected bool IsOpenIK = false;
        //public Vector3 LookAtPosition { get { return m_LookAtPosition; }set { m_LookAtPosition = LookAtPosition - transform.position).normalized; } }
        protected float m_sign = 0.03f;
        protected float m_RotateAngleSpeed = 1;
        protected Vector3 m_LookAtPosition;
        protected Vector3 deltaLookAtPosition;
        protected float LookDuration = 2;
        protected float Weight = 0;
        protected float Elapse = 0;

        protected bool Restrain = false;
        protected Transform HeadBone = null;
        protected Vector3 HeadPosition { get { return HeadBone ? HeadBone.position : transform.position +  new Vector3(0,1.7f,0); } }
        protected float MaxWeight = 0.6f;
        protected static float MaxAngle = 40;
        //protected Vector3 DefaultPosition { get { return transform.position + new Vector3(0, 2, 0); } }
        // Use this for initialization
        void Start()
        {
            animator = GetComponent<Animator>();
            HeadBone = Bokura.Utilities.SearchChildTransform(transform, Bokura.AvatarAttachment.Head);
            deltaLookAtPosition = transform.forward;
        }
        private void OnUpdateRotateEnter()
        {
            animator.SetLookAtPosition(deltaLookAtPosition);
            Weight = Mathf.Clamp(Weight + m_sign, 0, MaxWeight);
            animator.SetLookAtWeight(Weight, Weight * 0.2f);
        }
        private void OnUpdateRotateStay()
        {
            animator.SetLookAtPosition(deltaLookAtPosition);
            animator.SetLookAtWeight(Weight, Weight * 0.2f);
        }
        private void OnUpdateRotateLeave()
        {
            animator.SetLookAtPosition(deltaLookAtPosition);
            Weight = Mathf.Clamp(Weight - m_sign, 0, MaxWeight);
            animator.SetLookAtWeight(Weight, Weight * 0.2f);
        }
        private void OnAnimatorIK(int layerIndex)
        {
            if (animator == null) return;

            deltaLookAtPosition = m_LookAtPosition;
            //var dir = m_LookAtPosition - deltaLookAtPosition;
            //if (dir.sqrMagnitude < 0.01f)
            //    deltaLookAtPosition = m_LookAtPosition;
            //else
            //    deltaLookAtPosition += dir.normalized * 0.1f;

            if (IsOpenIK )
            {
                if(Weight < MaxWeight)
                {
                    OnUpdateRotateEnter();
                }
                else
                {
                    Elapse += Time.deltaTime;
                    IsOpenIK = Elapse <= LookDuration;
                    OnUpdateRotateStay();
                }
            }
            else if( Weight > 0)
            {
                OnUpdateRotateLeave();
            }

        }
        public void LookAmount(Vector3 Pos,float duration = 2,bool restrain = false)
        {
            Elapse = 0;
            IsOpenIK = true;

            //Restrain = true;
            //if (Restrain)
            //{
            //    var forward = transform.forward;
            //    var dir = (Pos - HeadPosition).normalized;
            //    var crossdir = Vector3.Cross(forward, dir);
            //    var angle = Vector3.SignedAngle(forward, dir, crossdir);
            //    if(Mathf.Abs(angle) > MaxAngle)
            //    {
            //        Quaternion rot = Quaternion.AngleAxis( Mathf.Sign(angle)* MaxAngle, crossdir);
            //        var restrain_dir = rot * forward;
            //        Pos = transform.position +  restrain_dir * 5;
            //    }
            //}

            m_LookAtPosition = Pos;
            LookDuration = duration;
        }

        public void SetMaxWeight(float maxWeight)
        {
            MaxWeight = maxWeight;
        }

        public void SwitchIK(bool open = false)
        {
            if (IsOpenIK != open)
                IsOpenIK = open;
        }

#if UNITY_EDITOR
        public void OnDrawGizmos()
        {

            Gizmos.DrawSphere(m_LookAtPosition, 0.1f);
            Gizmos.DrawSphere(deltaLookAtPosition, 0.1f);
        }
#endif
    }

}