using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public class AnimatorWraper
    {
        public enum AnimatorLayer { BaseLayer = 0,UpLayer = 1};

        protected bool Inited = false;
        protected bool InitedAfterPlay = false;

        protected int CurrentStateHashName = 0;
        protected float CurrentFadeTime = 0;
        protected float CurrentNormalizeTime = 0;

        protected GameObject unityGameObject = null;
        protected Animator m_mainAnimator = null;
        private List<Animator> allAnimator = new List<Animator>(ConstValue.kCap4);
        protected AnimatorIKComponent IKComponent = null;

        //protected Transform LookAtTarget = null;

        public Animator MainAnimator { get { return m_mainAnimator; } }
        public AnimatorWraper()
        {

        }
        public void Init(GameObject gameobject)
        {
            Debug.Assert(gameobject != null);

            unityGameObject = gameobject;
            allAnimator.Clear();
            gameobject.GetComponentsInChildren<Animator>(false, allAnimator);
            RefreshMainAnimator();
            InitIKComponent();
            InitProperty();

            Inited = true;
            if (InitedAfterPlay)
            {
                /*var ret = */CrossFadeAll(CurrentStateHashName, CurrentFadeTime, CurrentNormalizeTime);
                //LogHelper.LogWarning($"animator load finished. after playing animation .{gameobject.name} {ret} {CurrentStateHashName} {CurrentFadeTime} {CurrentNormalizeTime}");
            }
        }
        public void InitIKComponent()
        {
            if(MainAnimator != null)
            {
                IKComponent = MainAnimator.GetOrAddComponent<AnimatorIKComponent>();
            }
        }
        public void Update()
        {
            //if (!Inited) return;
            CurrentNormalizeTime += Time.deltaTime;
        }

        public void LookAtTarget(Vector3 targetpos, float duration = 2,bool restrain = false)
        {
            IKComponent?.LookAmount(targetpos, duration, restrain);
        }

        public void SetMaxWeight(float maxWeight)
        {
            IKComponent?.SetMaxWeight(maxWeight);
        }


        protected void RefreshMainAnimator()
        {
            if (allAnimator.Count > 0)
            {
                foreach (var animator in allAnimator)
                {
                    if (animator.transform.parent == unityGameObject.transform)
                        m_mainAnimator = animator;
                }
                if (m_mainAnimator == null)
                    m_mainAnimator = allAnimator[0];
            }
#if UNITY_EDITOR
            else
                LogHelper.LogFormat("gameObject not find animator .{0}", unityGameObject.name);

            foreach (var animator in allAnimator)
                if (animator.runtimeAnimatorController == null) LogHelper.LogWarning("animator runtmeAnimatorController is null.{0}", animator.name);
#endif
        }


        public void Release()
        {
            Inited = false;
            InitedAfterPlay = false;

            CurrentStateHashName = 0;
            CurrentFadeTime = 0;
            CurrentNormalizeTime = 0;
            unityGameObject = null;
            m_mainAnimator = null;
            allAnimator.Clear();
        }


        #region animator interface

        public bool CrossFadeAll(int animid, float fadetime = 0.1f, float normalize = 0.0f, bool forcePlay = true)
        {
            CurrentStateHashName = animid;
            CurrentFadeTime = fadetime;
            CurrentNormalizeTime = normalize;

            if (!Inited) {
                InitedAfterPlay = true;
                //LogHelper.LogWarning($"animator do't load. {Utilities.AnimatorHashToString(CurrentStateHashName)} {CurrentStateHashName} {CurrentFadeTime} {CurrentNormalizeTime}");
                return false;
            }

            bool ret = false;
            if (allAnimator != null)
            {
                for (var i = 0; i < allAnimator.Count; i++)
                {
                    ret |= AnimatorCrossFadeAllLayer(allAnimator[i], animid, fadetime, normalize, forcePlay);
                }
                if (!ret) LogHelper.LogWarningFormat("do't found animation id {0} {1}", Utilities.AnimatorHashToString(animid), animid);
            }
            return ret;
        }
        protected bool AnimatorCrossFadeAllLayer(Animator animator, int animid, float fadetime = 0.1f, float normalize = 0.0f, bool forcePlay = true)
        {
            bool ret = false;
            if (animator != null && animator.isActiveAndEnabled && animator.runtimeAnimatorController != null)
            {
                for (int layer = 0; layer < animator.layerCount; layer++)
                {
                    ret |= AnimatorCrossFade(animator, animid, layer, fadetime, normalize, forcePlay);
                }
            }
            return ret;
        }
        protected bool AnimatorCrossFade(Animator animator, int animid, int layer = 0, float fadetime = 0.1f, float normalize = 0.0f, bool forcePlay = true)
        {
            if (animator != null)
            {
                if (HasAnim(animator, animid, layer))
                {
                    if (forcePlay)
                        animator.CrossFade(animid, fadetime, layer, normalize);
                    else if (!IsPlayingAnimtion(animator, animid, layer))
                        animator.CrossFade(animid, fadetime, layer, normalize);
                    //else
                    //    return false;
                    return true;
                }
            }
            return false;
        }
        public bool HasAnim(int animid)
        {
            return HasAnim(MainAnimator, animid);
        }
        public static bool HasAnim(Animator animator, int animid, int layer = 0)
        {
            if (animator != null && animator.runtimeAnimatorController != null)
            {
                return animator.HasState(layer, animid);
            }
            return false;
        }

        public bool IsPlayingAnimtion(int animid, int layer = 0)
        {
            return IsPlayingAnimtion(MainAnimator, animid, layer);
        }
        public static bool IsPlayingAnimtion(Animator animator, int animid, int layer = 0)
        {
            if (animator != null && animator.runtimeAnimatorController != null && animator.layerCount > layer)
            {
                var curinfo = animator.GetCurrentAnimatorStateInfo(layer);
                var nextinfo = animator.GetNextAnimatorStateInfo(layer);
                bool isCurrent = animid == curinfo.shortNameHash/* && (animid == nextinfo.shortNameHash || nextinfo.shortNameHash == 0)*/;
                bool isNext =/* animid != curinfo.shortNameHash &&*/ animid == nextinfo.shortNameHash;
                return isCurrent || isNext;
            }
            return false;
        }

        public void SetFloat(int hashParamName, float f)
        {
            if (MainAnimator != null)
                MainAnimator.SetFloat(hashParamName, f);
            //for (var i = 0; i < allAnimator.Count; i++)
            //{
            //    var animator = allAnimator[i];
            //    if (animator != null && animator.runtimeAnimatorController != null)
            //        animator.SetFloat(hashParamName, f);
            //}
        }
        public void SetFloat(int hashParamName, float f, float damptime, float deltatime)
        {
            if (MainAnimator != null)
                MainAnimator.SetFloat(hashParamName, f, damptime, deltatime);
            //for (var i = 0; i < allAnimator.Count; i++)
            //{
            //    var animator = allAnimator[i];
            //    if (animator != null && animator.runtimeAnimatorController != null)
            //        animator.SetFloat(hashParamName, f, damptime, deltatime);
            //}
        }
        public void SetBool(int hashParamName, bool b)
        {
            if (MainAnimator != null)
                MainAnimator.SetBool(hashParamName, b);

            //for (var i = 0; i < allAnimator.Count; i++)
            //{
            //    var animator = allAnimator[i];
            //    if (animator != null && animator.runtimeAnimatorController != null)
            //        animator.SetBool(hashParamName, b);
            //}
        }
        public float GetFloat(int hashParamName)
        {
            if (MainAnimator != null)
                return MainAnimator.GetFloat(hashParamName);
            return 0;
        }
        public void SetLayerWeight(int layerIndex, float weight)
        {
            if (MainAnimator != null && layerIndex < MainAnimator.layerCount )
                MainAnimator.SetLayerWeight(layerIndex, weight);
        }
        public float GetLayerWeight(int layerIndex)
        {
            if (MainAnimator != null && layerIndex < MainAnimator.layerCount)
                return MainAnimator.GetLayerWeight(layerIndex);
            return 0;
        }
        public AnimatorStateInfo GetCurrentAnimatorStateInfo(int layer = 0)
        {
            if (MainAnimator == null) return default(AnimatorStateInfo);
            return MainAnimator.GetCurrentAnimatorStateInfo(layer);
        }
        public AnimatorStateInfo GetNextAnimatorStateInfo(int layer = 0)
        {
            //if (!Inited && InitedAfterPlay) return CurrentStateHashName;
            if (MainAnimator == null) return default(AnimatorStateInfo);
            return MainAnimator.GetNextAnimatorStateInfo(layer);
        }
        public void RefreshAllAnimator(RefreshAnimatorWay way, Animator animator = null)
        {
            switch (way)
            {
                case RefreshAnimatorWay.Add:
                    if (animator != null) allAnimator.Add(animator);
                    break;
                case RefreshAnimatorWay.Remove:
                    allAnimator.Remove(animator);
                    break;
                case RefreshAnimatorWay.Refresh:
                    allAnimator.Clear();
                    unityGameObject.GetComponentsInChildren<Animator>(allAnimator);
                    RefreshMainAnimator();
                    break;
            }
        }
        #endregion

        #region animator property

        private AnimatorCullingMode m_cullingMode = AnimatorCullingMode.CullUpdateTransforms;
        public AnimatorCullingMode cullingMode { get { return m_cullingMode; } set { if (m_cullingMode != value) { m_cullingMode = value; OnCullingModeChanged(); } } }

        protected void InitProperty()
        {
            if (MainAnimator != null)
            {
                m_cullingMode = MainAnimator.cullingMode;
                m_speed = MainAnimator.speed;
            }

            //MainAnimator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
        }

        protected void OnCullingModeChanged()
        {
            for (var i = 0; i < allAnimator.Count; i++)
            {
                var animator = allAnimator[i];
                if (animator != null && animator.runtimeAnimatorController != null)
                    animator.cullingMode = cullingMode;
            }
        }

        protected float m_speed = 1;
        public float speed { get { return m_speed; } set { if (m_speed != value) { m_speed = value; OnSpeedChanged(); } } }

        protected void OnSpeedChanged()
        {
            for (var i = 0; i < allAnimator.Count; i++)
            {
                var animator = allAnimator[i];
                if (animator != null && animator.runtimeAnimatorController != null)
                    animator.speed = speed;
            }

        }
#endregion
    }

}