#define MOVE_WORLD
#define USE_TIMLINE
using System;
using UnityEngine;
using Bokura;
using UnityEngine.Events;
using System.Collections.Generic;
using UnityEngine.Playables;
using UnityEngine.Timeline;
using Magic;
namespace Bokura
{

    class OnAvatarEnableDelegate : MonoBehaviour
    {

        public System.Action onEnable;

        private void OnEnable()
        {
            onEnable?.Invoke();
        }
    }

    public class AvatarEventFinder : MonoBehaviour
    {
        public AvatarEvent m_AvatarEvent;
    }

    public class Avatar : AvatarEvent, IAvatar
    {
        class Part
        {          
            public Part(Avatar avatar, AvatarPart p)
            {
                m_part = p;
                m_avatar = avatar;
            }
            Avatar m_avatar;
            public GameObject m_go;
            public AvatarPart m_part;
            AvatarLODData m_lodData;
            bool m_visible=true;
            Renderer[][] m_renders = new Renderer[AvatarLODData.MAX_LEVEL][];
            Renderer[] m_rootRenders;
            public Renderer[] Renders { get { return m_rootRenders; } }
            public SubPart subPart;
            public void refreshAttach()
            {
                if(m_go)
                {
                    var parent = m_avatar.GetAttachmentTransform(Avatar.PartAttachment[(int)m_part]);
                    if (parent != m_go.transform.parent)
                    {
                        m_go.transform.SetParent(parent, false);
                    }
                }

            }

            public void Clear()
            {
                if(m_go)
                {
                    GameObject.DestroyImmediate(m_go);
                    m_go = null;
                }
                if (subPart != null)
                {
                    subPart.Clear();
                }
            }

            void ResetTransform(Transform t)
            {
                if (m_part == AvatarPart.Head)
                {
                    var headt = Utilities.SearchChildTransform(t, AvatarAttachment.Head, true);
                    if (headt)
                    {
                        headt.localPosition = Vector3.zero;
                        headt.localRotation = Quaternion.identity;
                    }
                }
                else if (m_part == AvatarPart.Hair)
                {
                    var headt = Utilities.SearchChildTransform(t, AvatarAttachment.Hair,true);
                    if (headt)
                    {
                        headt.localPosition = Vector3.zero;
                        headt.localRotation = Quaternion.identity;
                    }
                }
            }

            public void Instantiate(GameObject go)
            {
                var parent = m_avatar.GetAttachmentTransform(Avatar.PartAttachment[(int)m_part]);
                m_go = GameObject.Instantiate<GameObject>(go, parent,false);               
                m_go.transform.localPosition = Vector3.zero;
                m_go.transform.localRotation = Quaternion.identity;
                if (parent)
                    m_go.SetLayerRecursively(parent.gameObject.layer);
                ResetTransform(m_go.transform);
                m_lodData = m_go.GetComponentInChildren<AvatarLODData>();
                m_rootRenders = m_go.GetComponentsInChildren<Renderer>();
                if (m_lodData!=null)
                {
                    //m_lodData.onModelChange += OnLODModelChange;
                    m_lodData.onLevelLoaded += OnLODModelLoaded;
                    m_lodData.SetLevel(m_avatar.GetCurLODLevel());
                }
                else
                {
                    if (m_part == AvatarPart.Head)
                        m_avatar.onLevel0HeadLoaded?.Invoke(m_go);
                }

            }

            void OnLODModelLoaded(int level)
            {
                //ResetTransform(m_lodData.GetLevelObject(level).transform);
            }

           

            void RefreshVisible()
            {
                if(m_rootRenders != null)
                {
                    for(int i = 0; i < m_rootRenders.Length; i++)
                    {
                        if (m_rootRenders[i] != null)
                        {
                            m_rootRenders[i].enabled = m_visible;
                        }
                    }
                }
                if (subPart != null)
                {
                    subPart.visible = m_visible;//鍞囬グ鐨勭墿浣?
                }
                if (m_lodData == null)
                    return;
                if (m_lodData.GetCurLevel() >= AvatarLODData.MAX_LEVEL)
                    return;
                var renders = m_renders[m_lodData.GetCurLevel()];
                if(renders!=null)
                {
                    for (int i = 0; i < renders.Length; i++)
                    {
                        if (renders[i] != null)
                        {
                            renders[i].enabled = m_visible;
                        }

                    }
                }
               
            }
            public void SetLODLevel(int lvl)
            {
                if (m_lodData)
                {
                    m_lodData.SetLevel(lvl);
                }
            }

            public void UpdateLODLevel()
            {
                if (m_lodData)
                {
                    m_lodData.UpdateLevel();
                }
            }
            public void SetVisible(bool b)
            {
                m_visible = b;
                RefreshVisible();
            }
            
        }

        class SubPart
        {
            Transform root;
            GameObject m_go;
            string subNode;
            public SubPart(Transform root,string nodeName)
            {
                if (root)
                {
                    this.root = root;
                }
                subNode = nodeName;
            }

            public void ResetRoot(Transform root)
            {
                if (root)
                {
                    this.root = root;
                }
            }

            public void AttachChildToBone(Transform child)
            {
                Transform subBoneNode = Utilities.SearchChildTransform(root, subNode);
                if (subBoneNode)
                {
                    child.SetParent(subBoneNode);
                    child.localPosition = Vector3.zero;
                    child.localRotation = Quaternion.identity;
                }
                m_go = child.gameObject;
            }
            public bool visible
            {
                set {
                    if (m_go)
                    {
                        m_go.SetActive(value);
                    }
                }
            }
            public void Clear()
            {
                if (m_go)
                {
                    GameObject.DestroyImmediate(m_go);
                    m_go = null;
                }
                if (root)
                {
                    Transform subBoneNode = Utilities.SearchChildTransform(root, subNode);
                    if (subBoneNode)
                    {
                        Renderer render = subBoneNode.gameObject.GetComponentInChildren<Renderer>();
                        if (render)
                        {
                            GameObject.DestroyImmediate(render);//清空一下在这个骨骼下边的显示物体
                        }
                    }
                }
            }
        }

        public void LoadSubPart(AvatarPart apType,string path,string modelName,string subNodeName,LoadCallback cb = null)
        {
            for (int i = 0; i < m_subParts.Length; i++)
            {
                if (m_subParts[i]!=null&&m_subParts[i].m_part == apType)
                {
                    Part part = m_subParts[i];
                    
                    if (part.subPart == null)
                    {
                        part.subPart = new SubPart(m_subParts[i].m_go.transform, subNodeName);
                    }
                    else
                    {
                        part.subPart.ResetRoot(m_subParts[i].m_go.transform);

                        part.subPart.Clear();
                    }
                    SubPart sb = part.subPart;
                    if (string.IsNullOrEmpty(modelName))
                    {
                        sb.Clear();
                    }
                    else
                    {
                        UnityEngine.Object o = ResourceHelper.LoadPrefabSync(path, modelName);
                        if (o)
                        {
                            GameObject g = o as GameObject;
                            GameObject g_instance = GameObject.Instantiate<GameObject>(g);
                            sb.AttachChildToBone(g_instance.transform);
                            cb?.Invoke(g_instance);
                        }
                    }
                    break;
                }
            }
        }

        struct  AttachedInfo
        {
            public IAvatar avatar;
            public AvatarAttachment target;
            public AvatarAttachment src;
        }

        List<AttachedInfo> m_attachedInfo = new List<AttachedInfo>(ConstValue.kCap16);
        Avatar m_parent;

        string m_curLoadModelName;
        GameObject m_unityObject = null;
        AnimatorWraper m_animator = new AnimatorWraper();
#if !USE_TIMLINE
        UnityEngine.Playables.PlayableDirector m_director;////没有用的变量 m_director 用弘包起来 下面有用  报警告 注销掉 使用下面的函数  shiliang
#endif
        AvatarEvent m_avatarEvent;
        RuntimeAnimatorController m_attackAnimatorController;
        //RuntimeAnimatorController m_defendAnimatorController;

        private Dictionary<int, Dictionary<int, List<MagicDataBase>>> m_loadedMagicEventData = new Dictionary<int, Dictionary<int, List<MagicDataBase>>>(Bokura.ConstValue.kCap2);
        private Dictionary<int, Dictionary<int, AnimatorStateInfo>> m_lastStates = new Dictionary<int, Dictionary<int, AnimatorStateInfo>>(Bokura.ConstValue.kCapacity);
        private Dictionary<int, Dictionary<int, AnimatorStateInfo>> m_nextStates = new Dictionary<int, Dictionary<int, AnimatorStateInfo>>(Bokura.ConstValue.kCapacity);

        Renderer[] m_renders = null;
        MaterialPropertyGroup m_materialProterties = new MaterialPropertyGroup();
        UniqueShadow m_uniqueShadow;
        Shadowing.DecalShadow m_decalShadow;


        Collider m_boxCollider;
        float m_fDistance = 0.0f;
        bool m_showColliderBox;
        bool m_released = false;
		Vector3 m_pos;

        OnAnimStateMachineChangeDelegate m_onAminStateMachineEnterCallback;
        OnAnimStateMachineChangeDelegate m_onAminStateMachineLeaveCallback;
        public MagicTrackBuild magicTrackBuild
        {
            get
            {
                return m_magicTrackBuild;
            }
        }
        MagicTrackBuild m_magicTrackBuild;

        AvatarLODData m_avatarLODData;
        Part[] m_subParts = new Part[(int)AvatarPart.Count];
        static AvatarAttachment[] PartAttachment = new AvatarAttachment[(int)AvatarPart.Count]
        {
            AvatarAttachment.Root,
            AvatarAttachment.Head,
            AvatarAttachment.Head,
        };

        float m_animParamSpeedH;
        // float m_animParamSpeedV;没有用的变量 m_animParamSpeedV 和 不必要的获取  报警告 注销掉 shiliang
        bool m_animParamGround;

        public Avatar()
        {
            m_onAminStateMachineEnterCallback = this.OnAminStateMachineEnter;
            m_onAminStateMachineLeaveCallback = this.OnAminStateMachineLeave;
        }

        ~Avatar()
        {

        }

#region property
        public AvatarEvent avatarEvent
        {
            get { return m_avatarEvent; }
            set { m_avatarEvent = value; }
        }

        public float distance
        {
            get
            {
                return m_fDistance;
            }
        }
#endregion


        GameEvent m_onCreate = new GameEvent();
        public GameEvent onCreate
        {
            get
            {
                return m_onCreate;
            }
            set
            {
                m_onCreate = value;
            }
        }


        bool m_enableLOD = true;
        public bool EnableLOD
        {
            get
            {
                return m_enableLOD;
            }
            set
            {
                m_enableLOD = value;
            }
        }

        bool m_bVisible = true;
        public bool Visible
        {
            set
            {
                if (m_bVisible != value)
                {
                    m_bVisible = value;
                    OnVisibleChanged();
                }
            }
            get
            {
                return m_bVisible;
            }
        }

        bool m_needAnimBlend = false;
        public bool NeedAnimBlend
        {
            get { return m_needAnimBlend; }
        }
        public Vector3 AnimatorDeltaPosition
        {
            get
            {
                if (animator != null && animator.MainAnimator != null)
                    return animator.MainAnimator.deltaPosition;
                return Vector3.zero;
            }
        }

        public IMaterialPropertyGroup MaterialProterties { get { return m_materialProterties; } }

        public Collider getBoundBox()
        {
            return m_boxCollider;
        }

        #region animator
        public void SetAnimParamFloat(int hashName, float f,float damptime,float deltatime)
        {
            if (hashName == Bokura.AnimatorParam.SpeedH)
            {
                m_animParamSpeedH = f;
            }
            else if (hashName == Bokura.AnimatorParam.SpeedV)
            {
                //m_animParamSpeedV = f;没有用的变量 m_animParamSpeedV 和 不必要的获取  报警告 注销掉  shiliang
            }

           m_animator.SetFloat(hashName, f, damptime, deltatime);
        }
        public void SetAnimParamFloat(int hashName, float f)
        {
            if(hashName == Bokura.AnimatorParam.SpeedH)
            {
                m_animParamSpeedH = f;
            }
            else if (hashName == Bokura.AnimatorParam.SpeedV)
            {
                //m_animParamSpeedV = f;没有用的变量 m_animParamSpeedV 和 不必要的获取  报警告 注销掉  shiliang
            }
            m_animator.SetFloat(hashName, f);
            
        }

        public void SetAnimParamBool(int hashName, bool b)
        {
            if(hashName == Bokura.AnimatorParam.Ground)
            {
                m_animParamGround = b;
            }
            m_animator.SetBool(hashName, b);
           
        }

        public UnityEngine.GameObject unityObject
        {
            get { return m_unityObject; }
            set
            {
                if (m_unityObject == value) return;
                m_unityObject = value;
            }
        }

        public void RefreshAllAnimator(RefreshAnimatorWay way, Animator _animator = null)
        {
            animator.RefreshAllAnimator(way, _animator);

        }
        public AnimatorStateInfo GetCurrentAnimatorStateInfo(int layer = 0)
        {
            return animator.GetCurrentAnimatorStateInfo(layer);
        }


        public AnimatorStateInfo GetNextAnimatorStateInfo(int layer = 0)
        {
            return animator.GetNextAnimatorStateInfo(layer);
        }

        //public AnimatorWraper animatorwarper = new AnimatorWraper(); 
        public AnimatorWraper animator
        {
            get
            {
                return m_animator;
            }
        }

        #endregion

        LoadCallback m_onLevel0FaceLoaded;
        public LoadCallback onLevel0HeadLoaded
        {
            get
            {
                return m_onLevel0FaceLoaded;
            }
            set
            {
                m_onLevel0FaceLoaded = value;
            }
        }

        //AnimKeyEvent m_animKeyEvent;
        OnAvatarAnimDelegate m_onAnimEvent;
        public OnAvatarAnimDelegate onAnimEvent
        {
            get
            {
                return m_onAnimEvent;
            }

            set
            {
                m_onAnimEvent = value;
            }
        }

        OnAnimStateMachineChangeDelegate m_onLeaveStateMachine;
        public OnAnimStateMachineChangeDelegate onLeaveStateMachine
        {
            set
            {
                m_onLeaveStateMachine = value;
            }
            get
            {
                return m_onLeaveStateMachine;
            }
        }

        OnAnimStateMachineChangeDelegate m_onEnterStateMachine;

        public OnAnimStateMachineChangeDelegate onEnterStateMachine
        {
            get
            {
                return m_onEnterStateMachine;
            }
            set
            {
                m_onEnterStateMachine = value;
            }
        }

        OnTimelineEventDelegate m_onTimelineEvent;
        public OnTimelineEventDelegate onTimelineEvent
        {
            get
            {
                return m_onTimelineEvent;
            }
            set
            {
                m_onTimelineEvent = value;
            }
        }



        AvatarAttachment m_targetAttachment;

        public AvatarAttachment targetAttachment
        {
            get
            {
                return m_targetAttachment;
            }
        }

        bool m_grassColliderEnable = false;
        GrassCollider m_grassCollider;
        CritiasFoliage.FoliageRunWindForce m_runWindForce = null;

        public bool EnableGrassCollider
        {
            get
            {
                return m_grassColliderEnable;
            }
            set
            {
                if (m_grassColliderEnable != value)
                {
                    m_grassColliderEnable = value;
                    RefreshGrassCollider();
                }


            }
        }

        AvatarShadowType m_shadowType = AvatarShadowType.None;
        public AvatarShadowType shadowType
        {
            get
            {
                return m_shadowType;
            }
            set
            {
                m_shadowType = value;
            }
        }
       

        bool m_dontDestoryOnLoad = false;
        public void DontDestoryOnLoad()
        {
            m_dontDestoryOnLoad = true;
        }
        void RefreshGrassCollider()
        {

            if (m_grassColliderEnable)
            {

                if (this.avatarEvent.IsMainCharacter() == false)
                    return;

                if (!m_grassCollider && m_unityObject)
                    m_grassCollider = m_unityObject.AddComponent<GrassCollider>();
                if (m_grassCollider)
                    m_grassCollider.enabled = true;

                if (m_runWindForce == null && m_unityObject != null)
                    m_runWindForce = m_unityObject.AddComponent<CritiasFoliage.FoliageRunWindForce>();

                if (m_runWindForce != null)
                    m_runWindForce.enabled = true;
            }
            else
            {
                if (m_grassCollider)
                    m_grassCollider.enabled = false;

                if (m_runWindForce != null)
                    m_runWindForce.enabled = false;

            }
        }

        private GameObject FindChildRecursive(GameObject parent, string childName)
        {
            if (parent.name == childName)
                return parent;
            if (parent.transform.childCount < 1)
                return null;
            GameObject obj = null;
            for (int i = 0; i < parent.transform.childCount; i++)
            {
                var go = parent.transform.GetChild(i).gameObject;
                obj = FindChildRecursive(go, childName);
                if (obj != null)
                    break;
            }
            return obj;
        }


        void registerAnimatorDelegate()
        {
            if (m_animator.MainAnimator != null)
            {
                var behaviours = m_animator.MainAnimator.GetBehaviours<AnimStateMachineDelegate>();
                for (int i = 0; i < behaviours.Length; i++)
                {
                    behaviours[i].m_onEnterState += m_onAminStateMachineEnterCallback;
                    behaviours[i].m_onLeaveStateMachine += m_onAminStateMachineLeaveCallback;
                }

                m_attackAnimatorController = m_animator.MainAnimator.runtimeAnimatorController;
            }
        }

        void InitAllComponent(GameObject newObject)
        {
           if (m_animator != null)
           {
                m_animator.Init(newObject);
                if (m_animator.MainAnimator != null)
                {
                    MessageComponent component = m_animator.MainAnimator.GetComponent<MessageComponent>();
                    if (null == component)
                    {
                        component = m_animator.MainAnimator.gameObject.AddComponent<MessageComponent>();
                        component.Owner = this;
                    }
                }
            }


            if (m_avatarEvent.IsNpc()|| m_avatarEvent.IsCharacter() || m_avatarEvent.IsClientNpc() || m_avatarEvent.IsHomeBuilding())
            {
                var aef = newObject.AddComponent<AvatarEventFinder>();
                aef.m_AvatarEvent = m_avatarEvent;
            }

            m_renders = newObject.GetComponentsInChildren<Renderer>();

            if (m_renders != null)
            {
                for (int i = 0; i < m_renders.Length; i++)
                {
                    m_renders[i].enabled = m_bVisible;
                   if(m_avatarEvent!=null&&!m_avatarEvent.IsMainCharacter())
                    {
                        m_renders[i].shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                        if(m_renders[i].material.HasProperty(CritiasFoliage.FoliageTileManager.m_ShaderIDWorldOffset))
                        {
                            m_renders[i].material.SetVector(CritiasFoliage.FoliageTileManager.m_ShaderIDWorldOffset, Vector4.zero);
                        }
                    }
                }
            }
            

            m_materialProterties.ClearRenderer();
            m_materialProterties.AddRenderer(m_renders);

            registerAnimatorDelegate();

            if (m_attackAnimatorController != null)
            {                
               // m_loadedEventData = MecanimEventManager.LoadEventData(m_attackAnimatorController.name);
                m_loadedMagicEventData = MecanimEventManager.LoadMagicEventData(m_attackAnimatorController);
            }

            m_avatarLODData = m_unityObject.GetComponentInChildren<AvatarLODData>();
            if (m_avatarLODData)
            {
                m_avatarLODData.onPostLevelChange = OnPostLODLevelChange;

                if (EnableLOD)
                    m_avatarLODData.UpdateLevel();
                else
                    m_avatarLODData.SetLevel(0, false);
            }

            if (avatarEvent!=null&& avatarEvent.IsMainCharacter())
            {
                if (newObject.GetComponent<RPInforAssigner>() == null)
                    newObject.AddComponent<RPInforAssigner>();
                //if (newObject.GetComponent<LightPorbeInfoAssigner>() == null)
                //    newObject.AddComponent<LightPorbeInfoAssigner>();
            }
                
            if (m_shadowType == AvatarShadowType.Unique)
            {

                if (!LevelSystemManager.s_isCloseSelfShadow)
                {
                    m_uniqueShadow = newObject.GetComponent<UniqueShadow>();

                    if (!m_uniqueShadow)
                        m_uniqueShadow = newObject.AddComponent<UniqueShadow>();


                    m_uniqueShadow.avatar = this;
                    m_uniqueShadow.isMale = m_avatarEvent.IsMale();
                    //m_uniqueShadow.SettingReset();

                    m_uniqueShadow.inclusionMask = (int)(UserLayerMask.MainCharacter);// | UserLayerMask.Character);

                    m_uniqueShadow.SetVisible(m_bVisible);
                }

            }
            else if (m_shadowType == AvatarShadowType.Decal)
            {
                if (LevelSystemManager.s_isShowDecalShadow)
                {
                    var root = Utilities.SearchChildTransform(newObject.transform, "Root");
                    if (root == null) root = newObject.transform;
                    var decalshadow = root.gameObject.AddComponent<Bokura.Shadowing.DecalShadow>();
                    decalshadow.material = ResourceHelper.LoadResourceSync("art_resource/entities/characters/chr_body/Materials/", "chr_decal_shadow", ".mat") as Material;
                    m_decalShadow = decalshadow;

                    m_decalShadow.SetVisible(m_bVisible);
                }
            }

            if (avatarEvent != null && (avatarEvent.haveSkill()))
            {
                m_magicTrackBuild = new MagicTrackBuild(this);
                m_magicTrackBuild.onTimelinePlayEndDelegate = OnTimelineCallBack;
                m_magicTrackBuild.onActionMixEndDelegate = OnActionMixCallBack;
            }
        }



        void OnPostLODLevelChange(int lvl)
        {
            if (m_animator != null && m_animator.MainAnimator != null)
            {
                var behaviours = m_animator.MainAnimator.GetBehaviours<AnimStateMachineDelegate>();
                for (int i = 0; i < behaviours.Length; i++)
                {
                    behaviours[i].m_onEnterState -= m_onAminStateMachineEnterCallback;
                    behaviours[i].m_onLeaveStateMachine -= m_onAminStateMachineLeaveCallback;

                    behaviours[i].m_onEnterState += m_onAminStateMachineEnterCallback;
                    behaviours[i].m_onLeaveStateMachine += m_onAminStateMachineLeaveCallback;
                }
                m_animator.SetFloat(Bokura.AnimatorParam.SpeedH, m_animParamSpeedH);
                m_animator.SetFloat(Bokura.AnimatorParam.SpeedH, m_animParamSpeedH);
                m_animator.SetBool(Bokura.AnimatorParam.Ground, m_animParamGround);
            }

            if(m_uniqueShadow)
            {
                m_uniqueShadow.ResetMaterial();
            }
        }
        
        //逐帧加载model
        static Queue<Avatar> waitingForLoadAvatars = new Queue<Avatar>();
        public static void  EnqueueAvatar(Avatar a)
        {
            waitingForLoadAvatars.Enqueue(a);
        }
        static bool m_updateInited;
        private static void UpdateLoadingModel()
        {
            if (waitingForLoadAvatars.Count > 0)
            {
                Avatar cur = waitingForLoadAvatars.Dequeue();
                cur.DelayInitModel();
            }
            else
            {
                if (m_updateInited)
                {
                    IMonoUpdateManager.Instance.RemoveFromUpdate(UpdateLoadingModel);
                    m_updateInited = false;
                }
            }
        }


        UnityEngine.Object model; string strModelName; bool raiseEvent = true;
        public void InitModel(UnityEngine.Object model, string strModelName, bool raiseEvent = true, bool iAsync = true)
        {
            this.model = model;
            this.strModelName = strModelName;
            this.raiseEvent = raiseEvent;
            if (!iAsync)
            {
                DelayInitModel();
                return;
            }
            EnqueueAvatar(this);

            if (!m_updateInited)
            {
                IMonoUpdateManager.Instance.AddToUpdate(UpdateLoadingModel);
                m_updateInited = true;
            }
        }

        public void DelayInitModel()
        {
            if (model == null)
            {
                LogHelper.LogError(LogCategory.Framework, Utilities.BuildString("load model failed : ", strModelName));
                return;
            }

            if (m_unityObject)
            {
                m_grassCollider = null;
                GameObject.Destroy(m_unityObject);
            }

            if (m_released)
                return;

            m_unityObject = GameObject.Instantiate(model) as GameObject;
            if (m_unityObject == null)
            {
                return;
            }
            if (m_dontDestoryOnLoad)
            {
                if (!unityObject.GetComponent<DontUnload>())
                {
                    unityObject.AddComponent<DontUnload>();
                }
            }

            var onEnable = m_unityObject.AddComponent<OnAvatarEnableDelegate>();
            onEnable.onEnable = registerAnimatorDelegate;
                
			SetPosition(m_pos);
            m_boxCollider = m_unityObject.GetComponent<BoxCollider>();
#if !USE_TIMLINE
            m_director = m_unityObject.GetComponent<PlayableDirector>();
#endif

            RefreshGrassCollider();

            if (raiseEvent)
            {
                InitAllComponent(m_unityObject);
                onCreate?.Invoke();
            }

            OnAvatarChanged(m_unityObject);
        }

        public void OnAvatarChanged(GameObject go)
        {
            if (m_uniqueShadow)
                m_uniqueShadow.ResetMaterial();
        }

#region interface impletation

        public void LoadModel(string strAssetBundlesPath, string strModelName, bool bAsync)
        {
            if (string.IsNullOrEmpty(strModelName))
            {
                LogHelper.LogError(LogCategory.Framework, "Model name is empty : ");
                return;
            }
            m_curLoadModelName = strModelName;

            if (bAsync)
            {
                ResourceHelper.LoadPrefabAsync(strAssetBundlesPath, strModelName, (UnityEngine.Object o) =>
                {
                    if (o == null || !o.name.Equals(m_curLoadModelName))
                    {
                        if (null == o)
                        {
                            LogHelper.LogErrorFormat("Avatar.cs bAsync=true o is null:strAssetBundlesPath={0},strModelName={1}", strAssetBundlesPath, strModelName);
                        }
                        //else
                        //{
                        //    LogHelper.LogErrorFormat("Avatar.cs bAsync=true o.name not contain strModelName :strAssetBundlesPath={0},strModelName={1},o.name{2}", strAssetBundlesPath, strModelName, o.name);
                        //}
                        return;
                    }
                        
                    InitModel(o, strModelName);
                });

                
                //if (null != m_avatarEvent)
                //{
                //    string name = "char_mm_dun_z_ac";
                //    ResourceHelper.LoadResourceAsync("art_resource/animations/characters/chr_mm_z/", name, ".overrideController", (UnityEngine.Object o) =>
                //    {
                //        m_defendAnimatorController = o as RuntimeAnimatorController;
                //        if (m_defendAnimatorController != null)
                //        {
                //            m_loadedEventData[(int)AnimatorControllerType.ACT_Defender] = MecanimEventManager.LoadEventData(name);
                //        }

                //    });
                //}
            }
            else
            {
                UnityEngine.Object o = ResourceHelper.LoadPrefabSync(strAssetBundlesPath, strModelName);
                if (o != null && o.name.Equals(strModelName))
                {
                    InitModel(o, strModelName , true,false);
                }
                else
                {
                    if(null == o)
                    {
                        LogHelper.LogErrorFormat("Avatar.cs bAsync=false o is null:strAssetBundlesPath={0},strModelName={1}", strAssetBundlesPath, strModelName);
                    }
                    else
                    {
                        LogHelper.LogErrorFormat("Avatar.cs bAsync=false o.name not contain strModelName :strAssetBundlesPath={0},strModelName={1},o.name{2}", strAssetBundlesPath, strModelName, o.name);
                    }
                    
                }  
                //if (null != m_avatarEvent)
                //{
                //    string name = "char_mm_dun_z_ac";
                //    m_defendAnimatorController = ResourceHelper.LoadResourceSync("art_resource/animations/characters/chr_mm_z/", name, ".overrideController") as RuntimeAnimatorController;
                //    if (m_defendAnimatorController != null)
                //    {
                //        m_loadedEventData[(int)AnimatorControllerType.ACT_Defender] = MecanimEventManager.LoadEventData(name);
                //    }
                //}
            }
        }



        public void LoadPart(AvatarPart part, string strAssetBundlesPath, string strModelName, bool aSync, LoadCallback callback = null)
        {
            if(aSync)
            {
                ResourceHelper.LoadResourceAsync(strAssetBundlesPath, strModelName, IResourceLoader.strPrefabSuffix, (UnityEngine.Object o) =>
                {
                    OnLoadPartDone(part, o, callback);
                });
            }
            else
            {
                UnityEngine.Object o = ResourceHelper.LoadResourceSync(strAssetBundlesPath, strModelName, IResourceLoader.strPrefabSuffix);
                OnLoadPartDone(part, o, callback);
            }
        }



        private void OnLoadPartDone(AvatarPart part, UnityEngine.Object o, LoadCallback callback)
        {
            if(part == AvatarPart.Body)
            {
                OnLoadBodyPart(o, callback);
                return;
            }
            var sp = m_subParts[(int)part];
            if (sp != null)
                sp.Clear();
            else
            {
                sp = new Part(this, part);
                m_subParts[(int)part] = sp;
            }

            if (!o)
            {
                callback?.Invoke(null);
                return;
            }

            sp.Instantiate(o as GameObject);
            m_materialProterties.AddRenderer(sp.Renders);
            sp.SetVisible(m_bVisible);
            callback?.Invoke(sp.m_go);
            OnAvatarChanged(sp.m_go);
        }



        private void OnLoadBodyPart(UnityEngine.Object o, LoadCallback callback)
        {
            //目前lod 和非lod的资源不能混合加载
            var newbodyPart = o as GameObject;
            newbodyPart = GameObject.Instantiate(newbodyPart);

           

            var newAnimator = newbodyPart.GetComponentInChildren<Animator>();
            if (!newAnimator)
                return;
            newAnimator.transform.SetParent(m_unityObject.transform,false);

            //保存原始动画
            AnimatorStateInfo stateinfo_0 = GetCurrentAnimatorStateInfo(0);
            //AnimatorStateInfo stateinfo_1 = GetCurrentAnimatorStateInfo(1);
            //AnimatorStateInfo stateinfo_2 = GetCurrentAnimatorStateInfo(2);

            GameObject oldAvatar = null;
            if (m_animator.MainAnimator != null)
            {
                m_animator.MainAnimator.transform.SetParent(null);
                oldAvatar = m_animator.MainAnimator.gameObject;
                //GameObject.DestroyImmediate(m_animator.gameObject);
            }

            for (int i = 0; i < m_subParts.Length; i++)
            {
                if (m_subParts[i] != null)
                {
                    m_subParts[i].SetLODLevel(0);
                    m_subParts[i].refreshAttach();
                }
            }

            if (m_attachedInfo != null)
            {
                for (int i = 0; i < m_attachedInfo.Count; i++)
                {
                    var info = m_attachedInfo[i];
                    info.avatar.AttachTo(this, info.target, info.src);
                }
            }
            if(oldAvatar)
            {
                GameObject.Destroy(oldAvatar);
            }
            if (m_avatarLODData)
            {
                m_avatarLODData.ClearAlllevelModel();
                GameObject.Destroy(m_avatarLODData);
                m_avatarLODData = null;
            }
                
          
           if(m_unityObject)
            {
                Utilities.CopyTransform(newbodyPart.transform, m_unityObject.transform, "ui");
                Utilities.CopyTransform(newbodyPart.transform, m_unityObject.transform, "buff_head_node");
                Utilities.CopyTransform(newbodyPart.transform, m_unityObject.transform, "target_sel_node");
            }
           

            InitAllComponent(m_unityObject);

            //恢复动画
            if (stateinfo_0.shortNameHash != 0) newAnimator.CrossFade(stateinfo_0.shortNameHash, 0.0f, 0, stateinfo_0.normalizedTime);
            //if (stateinfo_1.shortNameHash != 0) newAnimator.CrossFade(stateinfo_1.shortNameHash, 0.0f, 1, stateinfo_1.normalizedTime);
            //if (stateinfo_2.shortNameHash != 0) newAnimator.CrossFade(stateinfo_2.shortNameHash, 0.0f, 2, stateinfo_2.normalizedTime);

            var newcc = newbodyPart.GetComponent<CharacterController>();
            if (newcc)
            {
                var oldcc = m_unityObject.GetComponent<CharacterController>();
                if(oldcc)
                {
                    oldcc.radius = newcc.radius;
                    oldcc.height = newcc.height;
                    oldcc.center = newcc.center;               
                }
            }

            GameObject.Destroy(newbodyPart);
            OnAvatarChanged(m_unityObject);
        }

        void OnVisibleChanged()
        {
            if (m_unityObject != null && m_renders != null)
            {
                for (int i = 0; i < m_renders.Length; i++)
                {
                    if (m_renders[i])
                        m_renders[i].enabled = m_bVisible;
                }
            }

            for (int i = 0; i < m_subParts.Length; i++)
            {
                m_subParts[i]?.SetVisible(m_bVisible);
            }

            // 阴影
            if (m_shadowType == AvatarShadowType.Unique)
                m_uniqueShadow?.SetVisible(m_bVisible);
            else if (m_shadowType == AvatarShadowType.Decal)
                m_decalShadow?.SetVisible(m_bVisible);
        }
        void OnAminStateMachineEnter(int stateID, int layer)
        {
            m_onEnterStateMachine?.Invoke(stateID,layer);
        }

        void OnAminStateMachineLeave(int stateID, int layer)
        {
            //LogHelper.Log(LogCategory.Framework,"leave state:" , stateID.ToString() , " " ,  this.GetHashCode().ToString());
            m_onLeaveStateMachine?.Invoke(stateID,layer);
        }

        void OnTimelineCallBack(AnimEvent eventType)
        {
            m_onTimelineEvent?.Invoke(eventType);
        }

        void OnActionMixCallBack(bool isMix)
        {
            m_needAnimBlend = isMix;
        }

        public void Release()
        {
            m_released = true;
            if(null != m_magicTrackBuild)
                m_magicTrackBuild.Release();
            //AvatarPicker.Instance.Remove(this);
            if (m_unityObject)
            {
                GameObject.Destroy(m_unityObject);
                m_unityObject = null;

            }
            if(null != m_subParts)
            {
                for (int tIdx = 0, tCount = m_subParts.Length; tIdx < tCount; tIdx++)
                {
                    if (m_subParts[tIdx] != null)
                        m_subParts[tIdx].Clear();
                }
            }

            if (animator != null)
                animator.Release();
        }

        public void ResetAvatar()
        {
            if (m_attachedInfo != null)
                m_attachedInfo.Clear();
            m_parent = null;
            m_unityObject = null;
            m_animator = null;
#if !USE_TIMLINE
            m_director = null;
#endif
            m_avatarEvent = null;
            m_attackAnimatorController = null;
            //m_defendAnimatorController = null;
            //for (int i = 0; i < m_loadedEventData.Length; i++)
            m_lastStates.Clear();
            m_nextStates.Clear();
            m_renders = null;
            m_materialProterties = new MaterialPropertyGroup();
            m_uniqueShadow = null;
            m_decalShadow = null;
            m_boxCollider = null;
            m_fDistance = 0.0f;
            m_showColliderBox = false;
            m_released = false;
            m_pos = Vector3.zero;
            m_magicTrackBuild = null;
            m_avatarLODData = null;
            m_subParts = new Part[(int)AvatarPart.Count];
            m_animParamSpeedH = 0.0f;
            m_animParamGround = false;
            m_onCreate.RemoveAllListeners();
            m_enableLOD = true;
            m_bVisible = true;
            m_onLevel0FaceLoaded = null;
            m_onAnimEvent = null;
            m_onLeaveStateMachine = null;
            m_onEnterStateMachine = null;
            m_onTimelineEvent = null;
            m_targetAttachment = AvatarAttachment.None;
            m_grassColliderEnable = false;
            m_grassCollider = null;
            m_runWindForce = null;
            m_shadowType = AvatarShadowType.None;
            m_dontDestoryOnLoad = false;
        }

        public override void Update()
        {
            Utilities.ProfilerBegin("AvatarLOD.Update");

            if (m_avatarLODData != null)
            {
                if (m_enableLOD)
                    m_avatarLODData.UpdateLevel();
                else
                    m_avatarLODData.SetLevel(0);
            }
            else
            {
                for (int i = 0; i < m_subParts.Length; i++)
                {
                    if (m_subParts[i] != null)
                    {
                        m_subParts[i].UpdateLODLevel();
                    }
                }
            }
            Utilities.ProfilerEnd();

            animator.Update();

            if (m_showColliderBox && m_boxCollider != null)
            {
                IRenderUtilities.Instance.DrawBounds(m_boxCollider.bounds, Color.green);
            }

            if (m_animator.MainAnimator)
            {
                if(m_loadedMagicEventData !=null)
                {
                    Utilities.ProfilerBegin("MecanimEventManager.FireEvents");
                    MecanimEventManager.FireEvents(this, m_loadedMagicEventData, m_lastStates, m_nextStates, m_animator.MainAnimator);
                    Utilities.ProfilerEnd();
                }
            }
            Utilities.ProfilerBegin("m_magicTrackBuild.Update");

            if (m_magicTrackBuild != null)
            {
                m_magicTrackBuild.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("m_materialProterties.LateUpdate");
            m_materialProterties.LateUpdate();
            Utilities.ProfilerEnd();

        }



        public void SetPosition(float x, float y, float z)
        {
			SetPosition(new Vector3(x, y, z));

        }



        public void SetPosition(Vector3 p)
        {

            m_pos = p;
            if (m_unityObject&& m_targetAttachment!= AvatarAttachment.EomteStand)
            {
#if MOVE_WORLD
                if (!m_unityObject.transform.parent)
                    p -= LayeredSceneLoader.WorldOffset;
#endif
                m_unityObject.transform.localPosition = p;
            }
        }
        public Vector3 GetDirection()
        {
            if (m_unityObject)
                return m_unityObject.transform.forward;
            return Vector3.zero;
        }


        public void SetDirection(float x, float y, float z)
        {
            float angle = Utilities.Vector2Angle(z, x);
            float pitch = Mathf.Asin(y) * Mathf.Rad2Deg; ;
            if (m_unityObject)
                m_unityObject.transform.rotation = Quaternion.Euler(pitch, angle, 0);
        }



        public void SetDirectionAngle(float yAngle)
        {
            if (m_unityObject)
                m_unityObject.transform.rotation = Quaternion.Euler(0, yAngle, 0);
        }


        public void SetScale(float x, float y, float z)
        {
            if (m_unityObject)
                m_unityObject.transform.localScale = new Vector3(x, y, z);

        }

        public bool IsInView(Camera camera)
        {
            var planes = GeometryUtility.CalculateFrustumPlanes(camera);
            return GeometryUtility.TestPlanesAABB(planes, m_boxCollider.bounds);

        }



#endregion




        public void SetLayer(Int32 layer)
        {
            m_unityObject?.SetLayerRecursively(layer);
        }





        void RemoveAttachInfo(IAvatar avatar)
        {
            if (m_attachedInfo == null)
                return;
            for (int i = 0; i < m_attachedInfo.Count; i++)
            {
                if (m_attachedInfo[i].avatar == avatar)
                {
                    m_attachedInfo.RemoveAt(i);
                    break;
                }
            }
        }

        void StoreAttchInfo(IAvatar avatar,AvatarAttachment src,AvatarAttachment target)
        {
            for (int i = 0; i < m_attachedInfo.Count; i++)
            {
                var info = m_attachedInfo[i];
                if (info.avatar == avatar)
                {
                    m_attachedInfo[i] = new AttachedInfo() { avatar = avatar, src = src, target = target };
                    return;
                }
            }
            m_attachedInfo.Add(new AttachedInfo() { avatar = avatar, src = src, target = target });
        }

      
        public void AttachTo(IAvatar targetAvatar, AvatarAttachment target, AvatarAttachment src)
        {
            AttachToMount(targetAvatar, target, src, "");
        }
        public void AttachToMount(IAvatar targetAvatar, AvatarAttachment target, AvatarAttachment src,string MountName)
        {
            if (unityObject == null)
                return;

            if (targetAvatar == null)
            {
                Vector3 parentpos = m_pos;
                if (m_parent != null)
                {
                    parentpos = m_parent.m_pos;
                    m_parent.RemoveAttachInfo(this);
                    m_parent = null;
                    
                }
                m_targetAttachment = target;
                if (src== AvatarAttachment.EomteStand)
                {
                    //Vector3 oldpos = unityObject.transform.position;
                    Vector3 oldscale = unityObject.transform.localScale;
                    unityObject.transform.SetParent(null, false);
                    unityObject.transform.localScale = oldscale;
                    //unityObject.transform.position = oldpos;
                    SetPosition(parentpos);
                }
                else
                {
                    unityObject.transform.SetParent(null, false);
                }

                //下马调整影子设置
                SetHorseShadow();
                return;
            }

            if (targetAvatar.unityObject == null)
                return;
            var targetAvatarObj = targetAvatar as Avatar;

            var go = targetAvatarObj.unityObject;
            if (!go)
                return;

            var srcnode =( src == AvatarAttachment.Root || src == AvatarAttachment.None ) ? unityObject.transform :
                Utilities.SearchChildTransform(unityObject.transform, src,true);
            if (srcnode)
            {
                var transform = srcnode.localToWorldMatrix.inverse * unityObject.transform.localToWorldMatrix;

                unityObject.transform.localPosition = transform.ExtractPosition();
                unityObject.transform.localRotation = transform.ExtractRotation();
            }
            else
            {
                LogHelper.LogWarning("Model: " + m_curLoadModelName + " has no weapon bind point: " + Bokura.AvatarAttachmentToBoneNode.WeaponAttachmentBone[(int)src]);
                srcnode = unityObject.transform;
                var transform = srcnode.localToWorldMatrix.inverse * unityObject.transform.localToWorldMatrix;

                unityObject.transform.localPosition = transform.ExtractPosition();
                unityObject.transform.localRotation = transform.ExtractRotation();

                unityObject.transform.localPosition = Vector3.zero;
                unityObject.transform.localRotation = Quaternion.identity;
            }


            m_parent?.RemoveAttachInfo(this);
            m_parent = targetAvatarObj;
            m_parent.StoreAttchInfo(this, src, target);


            if (target == AvatarAttachment.EomteStand)
            {
                Transform destnode = go.transform;
                if (string.IsNullOrEmpty(MountName) ==false)
                {
                    destnode = Utilities.SearchChildTransform(go.transform, MountName);
                    if (destnode == null)
                    {
                        destnode = go.transform;
                    }
                }
                unityObject.transform.SetParent(destnode);
                m_targetAttachment = target;
                unityObject.SetActive(true);
                //unityObject.transform.localPosition = Vector3.zero;
                unityObject.transform.localRotation = Quaternion.identity;

                //if (destnode==null)
                //{
                //    GameObject newEomteStand = new GameObject();
                //    newEomteStand.name = "EomteStand";
                //    newEomteStand.transform.SetParent(go.transform);
                //    newEomteStand.transform.localScale = Vector3.one;
                //    newEomteStand.transform.localPosition = Vector3.zero;
                //    newEomteStand.transform.localRotation = Quaternion.identity;
                //    destnode = newEomteStand.transform;
                //}


            }
            else
            { 
                var destnode = Utilities.SearchChildTransform(go.transform, target);
                if (destnode && target != AvatarAttachment.None)
                {
                    unityObject.transform.SetParent(destnode, false);
                    m_targetAttachment = target;
                    unityObject.SetActive(true);
                }
                else
                {
                    //TODO:杩欓噷澶勭悊闇€瑕佹敼锟?
                    unityObject.transform.SetParent(null, false);
                    unityObject.SetActive(false);
                    m_targetAttachment = target;
                }
            }

            SetHorseShadow();
        }

        public void SetHorseShadow()
        {
            //上马调整影子设置
            m_uniqueShadow?.SetHorseShadow();
        }
        public void ResumeHorseShadow()
        {
           m_uniqueShadow?.ResumeHorseShadow();
        }
        public int GetCurLODLevel()
        {
            if (m_avatarLODData != null)
            {
                return m_avatarLODData.GetCurLevel();
            }
            else
                return 0;
        }

        public UnityEngine.Transform GetAttachmentTransform(AvatarAttachment attachment)
        {
            if (unityObject)
                return Utilities.SearchChildTransform(unityObject.transform, attachment);
            return null;
        }


        public void SendMessage<T>(T param)
        {
            if (m_avatarEvent != null)
            {
                m_avatarEvent.MessageInvoke<T>(param);
            }
        }

        public void EnableBulletTime(bool isOn)
        {
            if (null != m_magicTrackBuild)
            {
                m_magicTrackBuild.EnableBulletTime(isOn, isOn ? 0.2f : 1);
            }
        }

        public void CastMagic(CastMagicData data)
        {
#if USE_TIMLINE
            if (null != m_magicTrackBuild)
            {
                Bokura.Timeline.TimeLineMagicManager.ReadPlayableJsonClient(data.skillId);
                m_magicTrackBuild.BindTimelineClient(data);
            }
#else
            var fullpath = Utilities.BuildString(IResourceLoader.MagicPath, skillId.ToString());
            if (null == m_director)
            {
                m_director = m_unityObject.AddComponent<PlayableDirector>();
            }
            if (m_director)
            {
                m_director.playableAsset = IResourceLoader.Instance.Load(fullpath, typeof(TimelineAsset)) as TimelineAsset;
                if (m_director.playableAsset != null)
                {
                    m_director.Play();
                }
                else
                {
                    LogHelper.LogWarning(LogCategory.Framework, "load playable file failure");
                }
            }
#endif

        }

        public void CastDefenderMagic(CastDefenderData data)
        {
            if (null != m_magicTrackBuild)
            {
                m_magicTrackBuild.CreateDefendPlableTrack(data);
            }
        }

        public void StopMagicAction(uint skillId)
        {
            if (null != m_magicTrackBuild)
            {
                m_magicTrackBuild.StopMagicAction(skillId);
            }
        }


        public void ReleaseMagicTrackBuilder()
        {
            if (null != m_magicTrackBuild)
            {
                m_magicTrackBuild.Release();
            }
        }

    }

}
