using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    class AvatarPickerExport : IAvatarPicker
    {
        public override AvatarEvent GetNearestAvatar(Vector3 pos)
        {
            return AvatarPicker.Instance.GetNearestAvatar(pos);
        }
        public override void Clear()
        {
            AvatarPicker.Instance.Clear();
        }
    }

    class AvatarPicker :  ISingleton<AvatarPicker>
    {
        [XLua.BlackList]
        public static void Register()
        {
            if (m_instance == null)
                m_instance = EngineSingletonManager.Instance.CreateSingleton<AvatarPicker>();
        }

        public void Clear()
        {
        }


        public AvatarEvent GetNearestAvatar(Vector3 pos)
        {
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
			//m_tempList.Clear();
			if (mainCamera == null)
                return null;

			
			//Bokura.Avatar avatar = null;
			Ray ray = mainCamera.ScreenPointToRay(pos);
            //IRenderUtilities.Instance.DrawSingleLine(ray.origin, ray.origin + ray.direction*100.0f, Color.red);
            var mask = UserLayerMask.Character | UserLayerMask.NPC | UserLayerMask.MainCharacter;
            RaycastHit hitinfo;
            //if(Physics.Raycast(ray, out hitinfo, 100.0f, (int)mask))
            if (Utilities.RayCast(ray, out hitinfo, 100.0f, (int)mask))
            {
                var aef = hitinfo.collider.GetComponent<AvatarEventFinder>();
                if (aef)
                    return aef.m_AvatarEvent;
                //hitinfo.collider
            }
            return null;
            /*
			for (int i = 0; i < m_pickList.Count; ++i)
            {
                avatar = m_pickList[i];
                if (avatar.Pick(ray))
                    m_tempList.Add(avatar);

            }

            if(m_tempList.Count > 1)
                m_tempList.Sort(m_sortCompare);

            if(m_tempList.Count > 0)
                return m_tempList[0].avatarEvent;
              
            return null;
              */
        }

    }

    class AvatarPickerSortCompare : IComparer<Avatar>
    {
        public int Compare(Avatar x, Avatar y)
        {
            int xPriority = x.avatarEvent.GetSelectPriority();
            int yPriority = y.avatarEvent.GetSelectPriority();
            if (xPriority == yPriority)
                return (x.distance < y.distance ? -1 : (x.distance == y.distance ? 0 : 1));
            return xPriority < yPriority ? -1 : (xPriority == yPriority?0:1);
        }
    }
}

