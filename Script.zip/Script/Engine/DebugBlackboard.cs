﻿using UnityEngine;
using System;
using System.Collections.Generic;
using Bokura;
using UnityEngine.Events;
using System.Text;

namespace Bokura
{
    public class DebugBlackboard : IDebugBlackboard
    {
        Dictionary<string, string> lines = new Dictionary<string, string>(8);

        StringBuilder stringbuilder = new StringBuilder();

        private void Awake()
        {
            IDebugBlackboard.instance = this;
        }

        protected override void DoOutput(string key, string format, params object[] args)
        {
            stringbuilder.Length = 0;
            stringbuilder.Append(key);
            stringbuilder.Append(": ");
            stringbuilder.AppendFormat(format, args);
            lines[key] = stringbuilder.ToString();
        }
        protected override void DoErase(string key)
        {
            lines.Remove(key);
        }
#if UNITY_EDITOR
        void OnGUI()
        {
            if (lines.Count == 0)
                return;

            int x = 20;
            int y = 300;
            int lineHeight = 25;
            int lineSpace = 5;

            var iter = lines.GetEnumerator();
            while (iter.MoveNext())
            {
                GUI.Label(new Rect(x, y, 800, lineHeight), iter.Current.Value);
                y = y + lineHeight + lineSpace;
            }       
        }
#endif
    }
}
