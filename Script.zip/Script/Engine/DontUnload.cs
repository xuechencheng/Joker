﻿using UnityEngine;

public class DontUnload : MonoBehaviour
{
	private void Awake ()
    {
		DontDestroyOnLoad(gameObject);
	}
	


    public void SetDontDestroyOnLoad()
    {
        DontDestroyOnLoad(gameObject);
    }
}
