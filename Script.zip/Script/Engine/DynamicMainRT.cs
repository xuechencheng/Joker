using UnityEngine;

namespace Bokura
{
    [ExecuteInEditMode]
    [RequireComponent(typeof(Camera))]
    [AddComponentMenu("x2Engine/DynamicMainRT")]
#if UNITY_5_4_OR_NEWER
    [ImageEffectAllowedInSceneView]
#endif
    public class DynamicMainRT : MonoBehaviour
    {
        #region ��������

        [Range(0.05f, 1)]
        [Tooltip("Camera render texture resolution")]
        public float RenderTextureResolutoinFactor = 1.0f;

        const string shaderName = "Hidden/KriptoFX/PostEffects/RFX4_Bloom";
        const string shaderAdditiveName = "Hidden/DynamicRTPaintBack";
        #endregion

        #region ���Ʋ���
        public Material mat
        {
            get
            {
                if (m_Material == null)
                    m_Material = CheckShaderAndCreateMaterial(Shader.Find(shaderName));

                return m_Material;
            }
        }

        private Material m_MaterialAdditive;

        public Material matAdditive
        {
            get
            {
                if (m_MaterialAdditive == null)
                {
                    m_MaterialAdditive = CheckShaderAndCreateMaterial(Shader.Find(shaderAdditiveName));
                    m_MaterialAdditive.renderQueue = 3000;
                }

                return m_MaterialAdditive;
            }
        }

        public static Material CheckShaderAndCreateMaterial(Shader s)
        {
            if (s == null || !s.isSupported)
                return null;

            var material = new Material(s);
            material.hideFlags = HideFlags.DontSave;
            return material;
        }

        #endregion

        #region Private Members

        private RenderTexture source;
        private int previuosFrameWidth, previuosFrameHeight;
        private float previousScale;
        private Camera RTCamera;
        private GameObject goRTCamera;
        private Camera mainCamera;
        int cullingMask;
        CameraClearFlags clearFlags;

        private Material m_Material;

        private void OnDisable()
        {
            if (m_Material != null)
                DestroyImmediate(m_Material);
            m_Material = null;

            if (m_MaterialAdditive != null)
                DestroyImmediate(m_MaterialAdditive);
            m_MaterialAdditive = null;

            if(mainCamera != null)
            {
                mainCamera.cullingMask = cullingMask;
                mainCamera.clearFlags = clearFlags;
            }
        }

        private void OnDestroy()
        {
            DestroyImmediate(goRTCamera);
            goRTCamera = null;
            RTCamera = null;
        }

        //private void OnPostRender()
        //{
        //    if (RenderTextureResolutoinFactor < 1.0f)
        //        if (Camera.current == mainCamera)
        //        {
        //            Graphics.Blit(source, mainCamera.activeTexture, matAdditive, 0);
        //        }
        //}

        void OnRenderImage(RenderTexture _source, RenderTexture _destination)
        {
            if (Camera.current == mainCamera || mainCamera == null)
            {
                if(RenderTextureResolutoinFactor < 1.0f)
                    Graphics.Blit(source, _destination, matAdditive, 0);
                else
                    Graphics.Blit(_source, _destination);
            }
        }

        void Start()
        {
            mainCamera = GetComponent<Camera>();
            InitializeRenderTarget();
        }

        private void LateUpdate()
        {
            if (previuosFrameWidth != Screen.width || previuosFrameHeight != Screen.height || Mathf.Abs(previousScale - RenderTextureResolutoinFactor) > 0.01f)
            {
                InitializeRenderTarget();
                previuosFrameWidth = Screen.width;
                previuosFrameHeight = Screen.height;
                previousScale = RenderTextureResolutoinFactor;
            }
            if (RenderTextureResolutoinFactor < 1.0f)
            {
                UpdateCameraCopy();
            }
            else if (RTCamera)
            {
                RTCamera.cullingMask = 0;
                RTCamera.clearFlags = CameraClearFlags.SolidColor;

                mainCamera.cullingMask = cullingMask;
                mainCamera.clearFlags = clearFlags;
            }
        }

        private void InitializeRenderTarget()
        {
            var width = (int)(Screen.width * RenderTextureResolutoinFactor);
            var height = (int)(Screen.height * RenderTextureResolutoinFactor);
            source = new RenderTexture(width, height, 16, RenderTextureFormat.DefaultHDR);
            source.name = "Dynamic RT";
            source.filterMode = FilterMode.Trilinear;

            if (RTCamera == null)
            {
                var go = gameObject;
                if (go != null && mainCamera != null)
                {
                    //����Ƿ��Ѿ�����Ⱦ������
                    var goTrans = go.transform;
                    int childCount = goTrans.childCount;
                    for (int i = 0; i < childCount; i++)
                    {
                        var childTrans = goTrans.GetChild(i);
                        var childgo = childTrans.gameObject;
                        if (string.Equals(childgo.name, "Dynamic RT Camera"))
                        {
                            goRTCamera = childgo;
                            break;
                        }
                    }
                    if (goRTCamera == null)
                    {
                        goRTCamera = new GameObject("Dynamic RT Camera");
                        goRTCamera.transform.parent = goTrans;
                    }

                    RTCamera = goRTCamera.AddComponent<Camera>();
                    RTCamera.CopyFrom(mainCamera);
                    RTCamera.depth--;

                    clearFlags = mainCamera.clearFlags;
                    cullingMask = mainCamera.cullingMask;
                }
            }
        }

        void UpdateCameraCopy()
        {
            var cam = RTCamera;
            if(cam != null)
            {
                if (source != null)
                    source.DiscardContents();
                cam.targetTexture = source;
                cam.clearFlags = clearFlags;
                cam.cullingMask = cullingMask;
                mainCamera.cullingMask = 0;
                mainCamera.clearFlags = CameraClearFlags.SolidColor;
            }
        }
        #endregion
    }
}
