﻿using UnityEngine;
using UnityEngine.AI;

namespace Bokura
{
    public class DynamicObstruct
         : Bokura.IDynamicObstruct
    {
        #region Interface Implement
        public override void AddGameObjectObstruct(GameObject go, ObstructType obType)
        {
            if (go == null)
                return;

            var collider = go.GetComponent<Collider>();
            var navObstruct = go.GetComponent<NavMeshObstacle>();
            Bounds bounds = new Bounds();
            if (navObstruct == null)
            {
                Renderer[] renders = go.GetComponentsInChildren<Renderer>();
                int count = renders.Length;
                Vector3 center = Vector3.zero;
                for (int i = 0; i < count; i++)
                {
                    var render = renders[i];
                    center += render.bounds.center;
                }
                center /= count;


                bounds.center = center;
                for (int i = 0; i < count; i++)
                {
                    var render = renders[i];
                    bounds.Encapsulate(render.bounds);
                }
            }

            if (collider != null)
            {
                collider.enabled = true;
            }
            else
            {
                //添加一个collider
                if (navObstruct != null)
                {
                    bounds.size = navObstruct.size;
                    bounds.center = navObstruct.center;
                }
                switch (obType)
                {
                    case ObstructType.box:
                        BoxCollider boxCollider = go.AddComponent<BoxCollider>();
                        boxCollider.center = bounds.center/* - go.transform.position*/;
                        boxCollider.size = bounds.size;
                        break;
                    case ObstructType.sphere:
                        SphereCollider sphereCollider = go.AddComponent<SphereCollider>();
                        sphereCollider.center = bounds.center/* - go.transform.position*/;
                        sphereCollider.radius = bounds.size.magnitude * 0.5f;
                        break;
                    case ObstructType.capsule:
                        CapsuleCollider capsuleCollider = go.AddComponent<CapsuleCollider>();
                        capsuleCollider.center = bounds.center/* - go.transform.position*/;
                        capsuleCollider.radius = bounds.size.magnitude * 0.5f;
                        break;
                    case ObstructType.mesh:
                        var goMesh = go.GetComponent<MeshFilter>();
                        if(goMesh)
                        {
                            MeshCollider meshCollider = go.AddComponent<MeshCollider>();
                            meshCollider.sharedMesh = goMesh.sharedMesh;
                        }
                        break;
                }
               
            }

            //添加寻路阻挡体
            if(navObstruct != null)
            {
                navObstruct.enabled = true;
            }
            else
            {
                //添加一个NavMeshObstacle
                var newNavObstruct = go.AddComponent<NavMeshObstacle>();

                newNavObstruct.shape = NavMeshObstacleShape.Box;
                newNavObstruct.size = bounds.size;
                newNavObstruct.center = bounds.center;
            }
        }

        public override void RemoveGameObjectObstruct(GameObject go)
        {
            if (go == null)
                return;

            var collider = go.GetComponent<Collider>();
            var navObstruct = go.GetComponent<NavMeshObstacle>();

            if(collider != null)
            {
                collider.enabled = false;
            }

            if(navObstruct != null)
            {
                navObstruct.enabled = false;
            }
        }
        #endregion

    }
}
