﻿using System.Collections.Generic;
using Bokura;
using System;

namespace Bokura
{
    /// <summary>
    /// 全局事件派发统一管理器：
    /// 1、支持最多4个参数的泛型事件监听、移除和触发。
    /// 2、同一个事件ID可以有多种类型的监听者
    /// 3、所有操作都没有GC
    /// 4、示例见：SceneEditor\Assets\UIAsset\Scripts\Script\Example\GlobalEventExample\map_test_globalevent.unity
    /// 5、实参eventId建议使用GlobalEventID类中的预定义值，也可以使用不与预定义值冲突的其他值
    /// </summary>
    public sealed class EventDispatchManager : IEventDispatchManager
    {
        private Dictionary<uint, HashSet<Delegate>> m_EventMap = new Dictionary<uint, HashSet<Delegate>>(20);
        private Stack<HashSet<Delegate>> m_Caches = new Stack<HashSet<Delegate>>(10);
        private HashSet<Delegate> m_RemoveCaches = new HashSet<Delegate>();
        private HashSet<Delegate> m_AddCaches = new HashSet<Delegate>();
        private uint m_InvokingId = 0;



        private HashSet<Delegate> GetListenerSet(uint eventId)
        {
            HashSet<Delegate> tListenerSet = null;
            m_EventMap.TryGetValue(eventId, out tListenerSet);
            return tListenerSet;
        }



        /// <summary>
        /// listener的实际类型必须是System.Action、System.Action<T0>、System.Action<T0, T1>、System.Action<T0, T1, T2>、System.Action<T0, T1, T2, T3>中的任意一种，不能直接将函数地址作为实参
        /// </summary>
        public override void AddListener(uint eventId, Delegate listener)
        {
            if(null != listener)
            {
                if (m_InvokingId == eventId)
                    m_AddCaches.Add(listener);
                else
                {
                    HashSet<Delegate> tListenerSet = GetListenerSet(eventId);
                    if (null == tListenerSet)
                    {
                        if (m_Caches.Count > 0)
                            tListenerSet = m_Caches.Pop();
                        else
                            tListenerSet = new HashSet<Delegate>();
                        m_EventMap.Add(eventId, tListenerSet);
                    }
                    tListenerSet.Add(listener);
                }
            }
        }



        /// <summary>
        /// listener的实际类型必须是System.Action、System.Action<T0>、System.Action<T0, T1>、System.Action<T0, T1, T2>、System.Action<T0, T1, T2, T3>中的任意一种，不能直接将函数地址作为实参
        /// </summary>
        public override void RemoveListener(uint eventId, Delegate listener)
        {
            if(null != listener)
            {
                if (m_InvokingId == eventId)
                    m_RemoveCaches.Add(listener);
                else
                {
                    HashSet<Delegate> tListenerSet = GetListenerSet(eventId);
                    if (null != tListenerSet)
                    {
                        tListenerSet.Remove(listener);
                        if (tListenerSet.Count == 0)
                        {
                            m_EventMap.Remove(eventId);
                            m_Caches.Push(tListenerSet);
                        }
                    }
                }
            }
        }



        public override void RemoveAllListeners(uint eventId)
        {
            if (m_InvokingId == eventId)
            {
                var tSet = GetListenerSet(eventId);
                if(null != tSet)
                {
                    foreach (var tListener in tSet)
                        m_RemoveCaches.Add(tListener);
                }
            }
            else
                GetListenerSet(eventId)?.Clear();
        }



        public override void Invoke(uint eventId)
        {
            m_InvokingId = eventId;
            HashSet<Delegate> tListenerSet = GetListenerSet(eventId);
            if (null != tListenerSet)
            {
                foreach (var callback in tListenerSet)
                    (callback as Action)?.Invoke();
            }
            m_InvokingId = 0;
            DoUpdateAfterInvoke(tListenerSet);
        }



        public override void Invoke<T>(uint _EventId, T _Arg0)
        {
            m_InvokingId = _EventId;
            HashSet<Delegate> tListenerSet = GetListenerSet(_EventId);
            if (null != tListenerSet)
            {
                foreach (var callback in tListenerSet)
                    (callback as Action<T>)?.Invoke(_Arg0);
            }
            m_InvokingId = 0;
            DoUpdateAfterInvoke(tListenerSet);
        }



        public override void Invoke<T0, T1>(uint eventId, T0 arg0, T1 arg1)
        {
            m_InvokingId = eventId;
            HashSet<Delegate> tListenerSet = GetListenerSet(eventId);
            if (null != tListenerSet)
            {
                foreach (var callback in tListenerSet)
                    (callback as Action<T0, T1>)?.Invoke(arg0, arg1);
            }
            m_InvokingId = 0;
            DoUpdateAfterInvoke(tListenerSet);
        }



        public override void Invoke<T0, T1, T2>(uint eventId, T0 arg0, T1 arg1, T2 arg2)
        {
            m_InvokingId = eventId;
            HashSet<Delegate> tListenerSet = GetListenerSet(eventId);
            if (null != tListenerSet)
            {
                foreach (var callback in tListenerSet)
                    (callback as Action<T0, T1, T2>)?.Invoke(arg0, arg1, arg2);
            }
            m_InvokingId = 0;
            DoUpdateAfterInvoke(tListenerSet);
        }



        public override void Invoke<T0, T1, T2, T3>(uint eventId, T0 arg0, T1 arg1, T2 arg2, T3 arg3)
        {
            m_InvokingId = eventId;
            HashSet<Delegate> tListenerSet = GetListenerSet(eventId);
            if (null != tListenerSet)
            {
                foreach (var callback in tListenerSet)
                    (callback as Action<T0, T1, T2, T3>)?.Invoke(arg0, arg1, arg2, arg3);
            }
            m_InvokingId = 0;
            DoUpdateAfterInvoke(tListenerSet);
        }



        private void DoUpdateAfterInvoke(HashSet<Delegate> set)
        {
            if(null != set)
            {
                foreach (var tListener in m_RemoveCaches)
                    set.Remove(tListener);
                foreach (var tListener in m_AddCaches)
                    set.Add(tListener);
            }
            m_RemoveCaches.Clear();
            m_AddCaches.Clear();
        }
    }
}
