using Bokura;
using Magic;
using System;

namespace Bokura
{
    
    class Factory : IFactory
    {
        public Factory()
        {
            
        }

        //private ObjectPool<Avatar> m_AvatarPool = new ObjectPool<Avatar>();
        public override IAvatar CreateAvatar(AvatarEvent avatarEvent)
        {
            Avatar avatar = new Avatar();
            //Avatar avatar = m_AvatarPool.Get();
            avatar.avatarEvent = avatarEvent;
            return avatar;
        }

        public override void ReleaseAvatar(IAvatar avatar)
        {
            //avatar.ResetAvatar();
            //m_AvatarPool.Release((Avatar)avatar);
        }

        #region PlayableBehaviourEx create interface
        private ObjectPool<ActionBehaviour> m_ActionBehaviourPool = new ObjectPool<ActionBehaviour>();
        public override ActionBehaviour CreateActionBehaviour()
        {
            ActionBehaviour behaviour = m_ActionBehaviourPool.Get();
            behaviour.Init();
            return behaviour;
        }

        public override void ReleaseActionBehaviour(ActionBehaviour behaviour)
        {
            behaviour.Release();
            m_ActionBehaviourPool.Release(behaviour);
        }

        private ObjectPool<EffectBehaviour> m_EffectBehaviourPool = new ObjectPool<EffectBehaviour>();
        public override EffectBehaviour CreateEffectBehaviour()
        {
            EffectBehaviour behaviour = m_EffectBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseEffectBehaviour(EffectBehaviour behaviour)
        {
            behaviour.Release();
            m_EffectBehaviourPool.Release(behaviour);
        }

        private ObjectPool<DefendEffectBehaviour> m_DefendEffectBehaviourPool = new ObjectPool<DefendEffectBehaviour>();
        public override DefendEffectBehaviour CreateDefendEffectBehaviour()
        {
            DefendEffectBehaviour behaviour = m_DefendEffectBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseDefendEffectBehaviour(DefendEffectBehaviour behaviour)
        {
            behaviour.Release();
            m_DefendEffectBehaviourPool.Release(behaviour);
        }

        private ObjectPool<MaterialBehaviour> m_MaterialBehaviourPool = new ObjectPool<MaterialBehaviour>();
        public override MaterialBehaviour CreateMaterialBehaviour()
        {
            MaterialBehaviour behaviour = m_MaterialBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseMaterialBehaviour(MaterialBehaviour behaviour)
        {
            behaviour.Release();
            m_MaterialBehaviourPool.Release(behaviour);
        }

        private ObjectPool<CameraBehaviour> m_CameraBehaviourPool = new ObjectPool<CameraBehaviour>();
        public override CameraBehaviour CreateCameraBehaviour()
        {
            CameraBehaviour behaviour = m_CameraBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseCameraBehaviour(CameraBehaviour behaviour)
        {
            behaviour.Release();
            m_CameraBehaviourPool.Release(behaviour);
        }

        private ObjectPool<CameraAnimationBehaviour> m_CameraAnimationBehaviourPool = new ObjectPool<CameraAnimationBehaviour>();
        public override CameraAnimationBehaviour CreateCameraAnimationBehaviour()
        {
            CameraAnimationBehaviour behaviour = m_CameraAnimationBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseCameraAnimationBehaviour(CameraAnimationBehaviour behaviour)
        {
            behaviour.Release();
            m_CameraAnimationBehaviourPool.Release(behaviour);
        }

        private ObjectPool<DefendCameraBehaviour> m_DefendCameraBehaviourPool = new ObjectPool<DefendCameraBehaviour>();
        public override DefendCameraBehaviour CreateDefendCameraBehaviour()
        {
            DefendCameraBehaviour behaviour = m_DefendCameraBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseDefendCameraBehaviour(DefendCameraBehaviour behaviour)
        {
            behaviour.Release();
            m_DefendCameraBehaviourPool.Release(behaviour);
        }

        private ObjectPool<RadialBlurBehaviour> m_RadialBlurBehaviourPool = new ObjectPool<RadialBlurBehaviour>();
        public override RadialBlurBehaviour CreateRadialBlurBehaviour()
        {
            RadialBlurBehaviour behaviour = m_RadialBlurBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseRadialBlurBehaviour(RadialBlurBehaviour behaviour)
        {
            behaviour.Release();
            m_RadialBlurBehaviourPool.Release(behaviour);
        }


        private ObjectPool<BulletBehaviour> m_BulletBehaviourPool = new ObjectPool<BulletBehaviour>();
        public override BulletBehaviour CreateBulletBehaviour()
        {
            BulletBehaviour behaviour = m_BulletBehaviourPool.Get();
            return behaviour;
        }

        public override void ReleaseBulletBehaviour(BulletBehaviour behaviour)
        {
            behaviour.Release();
            m_BulletBehaviourPool.Release(behaviour);
        }

        #endregion
    }
}