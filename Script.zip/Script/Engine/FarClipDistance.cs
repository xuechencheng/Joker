using System;
using UnityEngine;
using System.Collections;
using Bokura;

namespace Bokura
{
    public class FarClipDistance : MonoBehaviour
    {
        public float FarClipDis = 100;
        private Boolean m_bActived;
        private MeshRenderer  m_render;

        void OnEnable()
        {
            IMonoUpdateManager.Instance.AddToUpdate(DoUpdate);
        }

        void OnDisable()
        {
            IMonoUpdateManager.Instance.RemoveFromUpdate(DoUpdate);
        }

        private void Start()
        {
            m_bActived = transform.gameObject.activeSelf;
            m_render = GetComponent<MeshRenderer>();
        }

        void DoUpdate()
        {
            Camera camera = ICameraHelper.Instance.MainCamera;
            if (camera)
            {
                if (m_render)
                {
                    float fDis = Vector3.Distance(camera.transform.position, transform.position);
                    if (fDis > FarClipDis && m_bActived)
                    {
                        m_render.enabled = false;
                        m_bActived = false;
                    }

                    else if (fDis <= FarClipDis && !m_bActived)
                    {
                        m_render.enabled = true;
                        m_bActived = true;
                    }
                }
                

            }
        }
    }
}