using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 对于Renderer的MaterialPropertyBlock操作的封装
    /// </summary>
	public class MaterialPropertyGroup : Bokura.IMaterialPropertyGroup
    {
		List<Renderer> _renderers = new List<Renderer>(Bokura.ConstValue.kCap16);

        MaterialPropertyBlock _properties = new MaterialPropertyBlock();
		

		bool _dirty = false;

        //void Awake ()
        //{
        //          _properties = new MaterialPropertyBlock();
        //          var rds = gameObject.GetComponentsInChildren<Renderer>();
        //	AddRenderer(rds);
        //}
        public void ClearRenderer()
        {
            _renderers.Clear();
        }
		public void AddRenderer(Renderer renderer)
		{
			_renderers.Add(renderer);
		}

		public void AddRenderer(Renderer[] renderers)
		{
			_renderers.AddRange(renderers);
		}

		public void SetVector(int nameID, Vector4 value)
		{
			_properties.SetVector(nameID, value);
			_dirty = true;
		}
		public void SetVector(string name, Vector4 value)
		{
			_properties.SetVector(name, value);
			_dirty = true;
		}
        public void SetTexture2D(string name, Texture2D value)
        {
            _properties.SetTexture(name, value);
            _dirty = true;
        }
        public void SetColor(int nameID, Color value)
		{
			_properties.SetColor(nameID, value);
			_dirty = true;
		}
		public void SetColor(string name, Color value)
		{
			_properties.SetColor(name, value);
			_dirty = true;
		}

		public void SetFloat(int nameID, float value)
		{
			_properties.SetFloat(nameID, value);
			_dirty = true;
		}
		public void SetFloat(string name, float value)
		{
			_properties.SetFloat(name, value);
			_dirty = true;
		}
        public void EnableKeyword(string nameID)
        {
            for (int i = 0; i < _renderers.Count; ++i)
            {
                var r = _renderers[i];
                for (int j = 0; j < r.materials.Length; ++j)
                {
                    r.materials[j].EnableKeyword(nameID);
                }
            }
        }
        public void DisableKeyword(string nameID)
        {
            for (int i = 0; i < _renderers.Count; ++i)
            {
                var r = _renderers[i];
                for (int j = 0; j < r.materials.Length; ++j)
                {
                    r.materials[j].DisableKeyword(nameID);
                }
            }
        }
        public void ApplyChange()
		{
			for (int i=0; i < _renderers.Count; ++i)
			{
                if (_renderers[i])
                    _renderers[i].SetPropertyBlock(_properties);
                else
                {
                    _renderers.Clear();
                    break;
                }
			}
			_dirty = false;
		}

        public void LateUpdate()
		{
			if (_dirty)
				ApplyChange();
		}
	}

}

