using UnityEngine;
using UnityEngine.Playables;
using Bokura;

namespace Bokura
{
    public class MessageComponent : MonoBehaviour, INotificationReceiver
    {
        Avatar m_avatar;

        public Avatar Owner
        {
            set { m_avatar = value; }
        }

        public void MessageInvoke<T>(T param)
        {
            if (m_avatar != null)
            {
                m_avatar.SendMessage<T>(param);
            }
        }

        /// <summary>
        /// 魔法的循环是否被打断
        ///     如果魔法的某个动作是循环的蓄力动作，需要由外部控制是否打断这个loop，否则该动作一直循环播放
        /// </summary>
        /// <returns></returns>
        public bool IsMagicLoopBroken()
        {
            //TODO 
            return true;
        }


        public void OnAnimatorMove()
        {
            //空函数，这个函数不能删，用来标记animator计算deltaPosition的。
        }

        public void OnNotify(Playable origin, INotification notification, object context)
        {
            if (m_avatar == null) { return; }

            if (notification.GetType() == typeof(MagicEventMark))
            {
                m_avatar.magicTrackBuild?.onTimelinePlayEndDelegate((AnimEvent)((notification as MagicEventMark).data.eventType));
            }
            else if (notification.GetType() == typeof(MagicGrassMark))
            {
                m_avatar.SendMessage((notification as MagicGrassMark).data);
            }
            else if (notification.GetType() == typeof(MagicDefendGrassMark))
            {
                m_avatar.SendMessage((notification as MagicDefendGrassMark).data);
            }
            else if (notification.GetType() == typeof(MagicAudioMark))
            {
                m_avatar.SendMessage((notification as MagicAudioMark).data);
            }
            else if (notification.GetType() == typeof(MagicDefendAudioMark))
            {
                m_avatar.SendMessage((notification as MagicDefendAudioMark).data);
            }

        }
    }
}

