using System;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class NoRotation: MonoBehaviour
    {

        private void OnEnable()
        {
            IMonoUpdateManager.Instance.AddToLateUpdate(DoUpdate);
        }

        private void OnDisable()
        {
            IMonoUpdateManager.Instance.RemoveFromLateUpdate(DoUpdate);
        }

        void DoUpdate()
        {
            transform.rotation = Quaternion.identity;
        }
    }
}