
using UnityEngine;

using System.Collections;
using Bokura;

class PlayerMoveControllerClient : MonoBehaviour
{

	CharacterController m_cc;

	Vector3 m_motion;
	Vector3 m_wantMotion;
	Camera m_camera;

	Animator m_animator;

	public float m_Speed = 3.0f;
	public float m_JumpForce = 2.0f;
	//float m_fallCheckDistance = 0.3f;
	//float m_fallTime;
	//float gravity = -19.8f;
	bool m_wantJump = false;

	enum StateID : int
	{
		IDLE,
		MOVE,
		JUMP,
		FALL,
		NUM,
	}



	delegate void StateDelegate();


	class State
	{
		public StateDelegate OnEnter;
		public StateDelegate OnLeave;
		public StateDelegate OnUpdate;
	}

	State[] m_states = new State[(int)StateID.NUM];
	State m_curState;
	//int m_curLeavingAnimId;
	int m_curAnimStateId;
	float m_curDirAngle;
	int m_updateCount = 0;
	float m_fallSpeed;

    void OnEnable()
    {
        IGameMonoUpdateManager.Instance.AddToUpdate(DoUpdate);
    }

    void OnDisable()
    {
        IGameMonoUpdateManager.Instance.RemoveFromUpdate(DoUpdate);
    }

    private void Start()
	{
		m_cc = GetComponentInChildren<CharacterController>();
		m_camera = GameObject.Find("Main_Camera").GetComponent<Camera>();
		m_animator = GetComponentInChildren<Animator>();
		var behaviours = m_animator.GetBehaviours<Bokura.AnimStateMachineDelegate>();
		for (int i = 0; i < behaviours.Length; i++)
		{
			behaviours[i].m_onEnterStateMachine += OnAminStateMachineEnter;
			behaviours[i].m_onLeaveStateMachine += OnAminStateMachineLeave;
			behaviours[i].m_onEnterState += OnStateEnter;
		}


		for (int i = 0; i < (int)StateID.NUM; i++)
		{
			m_states[i] = new State();
		}

		m_states[(int)StateID.IDLE].OnEnter = () =>
		{
			m_motion.x = 0;
			m_motion.z = 0;
			m_animator.CrossFade("idle01", 0.1f, 0);
		};
		m_states[(int)StateID.IDLE].OnUpdate = () =>
		{
			if (!IsOnGround())
			{
				ChangeState(StateID.FALL);
				return;
			}
			if (WantMove())
			{
				ChangeState(StateID.MOVE);
				return;
			}
			if (m_wantJump)
			{
				ChangeState(StateID.JUMP);
				return;
			}
		};

		m_states[(int)StateID.MOVE].OnEnter = () =>
		{
			m_animator.CrossFade("Move", 0.1f, 0);
		};
		m_states[(int)StateID.MOVE].OnUpdate = () =>
		{
			if (!IsOnGround())
			{
				ChangeState(StateID.FALL);
				return;
			}
			if (m_wantJump)
			{
				ChangeState(StateID.JUMP);
				return;
			}
			if(!WantMove())
			{
				ChangeState(StateID.IDLE);
				return;
			}

			float destangle = Vector2Angle(m_wantMotion.z, m_wantMotion.x);
            LogHelper.LogWarning(LogCategory.Framework, "xx" + destangle + " " + m_wantMotion);
            //float da = destangle - m_curDirAngle;
            //float db = m_curDirAngle - destangle;
            float d = AngleDiff(m_curDirAngle, destangle);

			m_curDirAngle -= d * Time.deltaTime*5.0f;
			while (m_curDirAngle > 360.0f)
				m_curDirAngle -= 360.0f;
			while (m_curDirAngle < 0.0f)
				m_curDirAngle += 360.0f;
            //LogHelper.Log(LogCategory.Framework, "d:" + m_curDirAngle);
            d *= Mathf.Deg2Rad;
			if(m_wantMotion.x !=0.0f || m_wantMotion.z != 0.0f)
			{
				m_motion.x = Mathf.Sin(m_curDirAngle* Mathf.Deg2Rad) * m_Speed * Time.deltaTime;
				m_motion.z = Mathf.Cos(m_curDirAngle* Mathf.Deg2Rad) * m_Speed * Time.deltaTime;// * Time.deltaTime;
			}
			else
			{
				m_motion.z = 0;
				m_motion.x = 0;
			}
			var motion = m_motion;
			motion.y = 0.0f;
			motion.Normalize();

			//m_animator.SetFloat("SpeedV", motion.z, 0.1f, Time.deltaTime);
			//m_animator.SetFloat("SpeedH", motion.x, 0.1f, Time.deltaTime);

		};
		m_states[(int)StateID.FALL].OnEnter = () =>
		{

			m_animator.CrossFade("jump_loop", 0.1f, 0);
			m_animator.SetBool("Ground", false);
			//m_fallTime = 0.0f;
			m_fallSpeed = -8.0f;

		};

		m_states[(int)StateID.FALL].OnUpdate = () =>
		{
			if (IsOnGround())
			{
				
				m_animator.SetBool("Ground", true);
				if(m_curAnimStateId != 5)
				{
					if (WantMove())
						ChangeState(StateID.MOVE);
					else
						ChangeState(StateID.IDLE);
					return;
				}

		
			}

			float d = m_fallSpeed * Time.deltaTime;
			m_fallSpeed -= Time.deltaTime * 9.8f;
			//float v0 = -9.8f;

			//float d1 = v0*m_fallTime +  0.5f * gravity * Mathf.Pow(m_fallTime, 2.0f);// m_fallSpeed * Time.deltaTime;
			//m_fallTime += Time.deltaTime;                                                                           //m_fallTime += Time.deltaTime* timemul;
			////float d2 = v0 * m_fallTime + 0.5f * gravity * Mathf.Pow(m_fallTime, 2.0f);
			//float d = d2 - d1;
			//d /= distancscale;
			if (d > 30.0f)
				d = 30.0f;
			m_motion.y = d;

		};

		m_states[(int)StateID.JUMP].OnEnter = () =>
		{
			m_animator.CrossFade("jump_start", 0.1f, 0);
			m_updateCount = 0;

		};

		m_states[(int)StateID.JUMP].OnLeave = () =>
		{

		};

		
		m_states[(int)StateID.JUMP].OnUpdate = () =>
		{
			m_motion.y = m_animator.deltaPosition.y * m_JumpForce;
			//m_host.setMotionY(m_host.Avatar.animator.deltaPosition.y * m_host.JumpPower);
			//var curanim = m_animator.GetCurrentAnimatorStateInfo(0);
			//var nextanim = m_animator.GetNextAnimatorStateInfo(0);
			//if (curanim.IsName("jump_start") && nextanim.shortNameHash != 0)
			//{
			//	if (!nextanim.IsName("jump_start"))
			//	{
			//		ChangeState(StateID.FALL);
			//	}
			//}
			if(m_curAnimStateId!= 4 && m_updateCount>1)
			{
				ChangeState(StateID.FALL);
			}
			m_updateCount++;

		};

		ChangeState(StateID.IDLE);

	}

	static public float AngleDiff(float a, float b)
	{
		if (a - b > 180)
			a -= 360.0f;
		if (b - a > 180)
			a += 360.0f;
		return a - b;
	}
	void OnAminStateMachineEnter(int stateID, int layer)
	{

	}
	void OnAminStateMachineLeave(int stateID, int layer)
	{
		m_curAnimStateId = stateID;
	}

	void OnStateEnter(int stateID, int layer)
	{
		m_curAnimStateId = stateID;
	}
	void ChangeState(StateID state)
	{
		if (m_curState != null)
		{
			if (m_curState.OnLeave != null)
				m_curState.OnLeave();
		}
		m_curState = m_states[(int)state];
		if (m_curState.OnEnter != null)
			m_curState.OnEnter();
	}

	bool WantMove()
	{
		return m_wantMotion.x * m_wantMotion.x + m_wantMotion.z * m_wantMotion.z > 0.0f;
	}

	bool IsOnGround()
	{
		if (m_cc != null && !m_cc.isGrounded)
		{
			//if (!Physics.CapsuleCast(transform.position + Vector3.up * m_cc.height, transform.position , m_cc.radius, Vector3.down, m_fallCheckDistance, (int)Bokura.UserLayerMask.AllBlock))
			//{
			//	return false;
			//}
			//else
			//{
				return false;
			//}
		}
		return true;
	}

	private void DoUpdate()
	{
		//var d = m_camera.cameraToWorldMatrix.MultiplyVector(Vector3.back);
		//transform.rotation = Quaternion.Euler(0, Vector2Angle(d.z, d.x), 0);
		m_motion.y = -10.0f * Time.deltaTime;
		//m_motion.x = 0.0f;
		//m_motion.z = 0.0f;
		m_wantMotion.z = 0.0f;
		m_wantMotion.x = 0.0f;
		m_wantMotion.y = 0.0f;
		m_wantJump = false;
		if (Input.GetKey(KeyCode.W))
		{
			m_wantMotion.z += 1; //m_Speed * Time.deltaTime;
		}
		if (Input.GetKey(KeyCode.S))
		{
			m_wantMotion.z -= 1;// m_Speed * Time.deltaTime;
		}
		if (Input.GetKey(KeyCode.A))
		{
			m_wantMotion.x -= 1;// m_Speed * Time.deltaTime;
		}
		if (Input.GetKey(KeyCode.D))
		{
			m_wantMotion.x += 1;// m_Speed * Time.deltaTime;
		}
		if (Input.GetKey(KeyCode.Space))
		{
			m_wantJump = true;
		}
		m_wantMotion.Normalize();
		m_wantMotion = m_camera.transform.localToWorldMatrix.MultiplyVector(m_wantMotion);
		//m_wantMotion = transform.rotation* m_wantMotion;

		if (m_curState != null && m_curState.OnUpdate != null)
			m_curState.OnUpdate();


		m_cc.Move(/*transform.rotation **/ m_motion);
		Vector3 motion = m_motion;
		motion.y = 0;
		if(motion.sqrMagnitude>0.0f)
		{
			motion.Normalize();
		}
		m_animator.SetFloat("SpeedV", motion.z, 0.1f, Time.deltaTime);
		m_animator.SetFloat("SpeedH", motion.x, 0.1f, Time.deltaTime);
		transform.rotation = Quaternion.Euler(0, m_curDirAngle, 0);
		//m_curLeavingAnimId = 0;


	}

	static public float Vector2Angle(float x, float y)
	{
		if (float.IsNaN(x) || float.IsNaN(y))
			return 0.0f;
		float angle = 0;
		if (x == 0)
		{
			angle = y > 0 ? 90 : 270;
		}
		else if (x > 0)
		{
			angle = (float)(y > 0 ? Mathf.Atan(y / x) : (Mathf.PI * 2 + Mathf.Atan(y / x))) * Mathf.Rad2Deg;
		}
		else
			angle = (float)(180 + Mathf.Atan(y / x) * Mathf.Rad2Deg);
		return angle;
	}
}