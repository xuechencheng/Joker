using UnityEngine;
using System;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    struct stLineInfo
    {
        public Vector3 start;
        public Vector3 end;
        public Color clr;
    }

    public class RenderUtilities : IRenderUtilities
    {
        static Material lineMaterial;

        static int prop_SrcBlend = Shader.PropertyToID("_SrcBlend");
        static int prop_DstBlend = Shader.PropertyToID("_DstBlend");
        static int prop_Cull = Shader.PropertyToID("_Cull");
        static int prop_ZWrite = Shader.PropertyToID("_ZWrite");

        protected static void CreateLineMaterial()
        {
            if (!lineMaterial)
            {
                // Unity has a built-in shader that is useful for drawing
                // simple colored things.
                Shader shader = Shader.Find("Hidden/Internal-Colored");
                lineMaterial = new Material(shader);
                lineMaterial.hideFlags = HideFlags.HideAndDontSave;
                // Turn on alpha blending
                lineMaterial.SetOverrideTag("RenderType", "");
                lineMaterial.SetInt(prop_SrcBlend, (int)UnityEngine.Rendering.BlendMode.One);
                lineMaterial.SetInt(prop_DstBlend, (int)UnityEngine.Rendering.BlendMode.Zero);
                lineMaterial.DisableKeyword("_ALPHATEST_ON");
                lineMaterial.DisableKeyword("_ALPHABLEND_ON");
                lineMaterial.DisableKeyword("_ALPHAPREMUTIPLY_ON");
                // Turn backface culling off
                lineMaterial.SetInt(prop_Cull, (int)UnityEngine.Rendering.CullMode.Off);
                // Turn off depth writes
                lineMaterial.SetInt(prop_ZWrite, 0);            
            }
        }

        List<stLineInfo> m_vertexList = new List<stLineInfo>(Bokura.ConstValue.kCap32);

        public override void DrawSingleLine(Vector3 start, Vector3 end, Color clr)
        {
            stLineInfo line;
            line.start = start;
            line.end = end;
            line.clr = clr;
            m_vertexList.Add(line);
        }

        public override void DrawSingleLine(float startX, float startY, float startZ, float endX, float endY, float endZ, Color clr)
        {
            stLineInfo line;
            line.start = new Vector3(startX, startY, startZ);
            line.end = new Vector3(endX, endY, endZ);
            line.clr = clr;
            m_vertexList.Add(line);
        }

        public override void Clear()
        {
            CreateLineMaterial();
            m_vertexList.Clear();
        }

        public override void DrawBounds(Bounds bound, Color clr)
        {
            float minX = bound.min.x;
            float minY = bound.min.y;
            float minZ = bound.min.z;
            float maxX = bound.max.x;
            float maxY = bound.max.y;
            float maxZ = bound.max.z;

            DrawSingleLine(minX, minY, minZ, maxX, minY, minZ, clr);
            DrawSingleLine(maxX, minY, minZ, maxX, maxY, minZ, clr);
            DrawSingleLine(maxX, maxY, minZ, minX, maxY, minZ, clr);
            DrawSingleLine(minX, maxY, minZ, minX, minY, minZ, clr);

            DrawSingleLine(minX, minY, maxZ, maxX, minY, maxZ, clr);
            DrawSingleLine(maxX, minY, maxZ, maxX, maxY, maxZ, clr);
            DrawSingleLine(maxX, maxY, maxZ, minX, maxY, maxZ, clr);
            DrawSingleLine(minX, maxY, maxZ, minX, minY, maxZ, clr);

            DrawSingleLine(minX, minY, minZ, minX, minY, maxZ, clr);
            DrawSingleLine(maxX, minY, minZ, maxX, minY, maxZ, clr);
            DrawSingleLine(minX, maxY, minZ, minX, maxY, maxZ, clr);
            DrawSingleLine(maxX, maxY, minZ, maxX, maxY, maxZ, clr);
        }

        public override void RenderLine()
        {
            if(lineMaterial != null)
            {
                lineMaterial.SetPass(0);
                GL.PushMatrix();
                GL.MultMatrix(Matrix4x4.identity);
                GL.Begin(GL.LINES);
                for(int i = 0; i < m_vertexList.Count; ++i)
                {
                    GL.Color(m_vertexList[i].clr);
                    GL.Vertex3(m_vertexList[i].start.x, m_vertexList[i].start.y, m_vertexList[i].start.z);
                    GL.Vertex3(m_vertexList[i].end.x, m_vertexList[i].end.y, m_vertexList[i].end.z);
                }

                GL.End();
                GL.PopMatrix();
            }            
        }
    }
}