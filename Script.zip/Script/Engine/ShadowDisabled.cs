﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShadowDisabled : MonoBehaviour
{
    private void OnPreCull()
    {
        Bokura.Utilities.DisableShadow();
    }

    private void OnPostRender()
    {
        Bokura.Utilities.RestoreShadow();
    }
}
