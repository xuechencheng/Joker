using UnityEngine;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// Task type
    /// </summary>
    public enum AITaskType
    {
        None,
        Wander,     // Wander around
        Build,      // Build architecture
        Greet,      // Say hi
        Rest,       // Sit or sleep
        Circusee,
        Produce,
    }

    /// <summary>
    /// Base class of all tasks
    /// </summary>
    public class AITask
    {
        #region Params
        /// <summary>
        /// The entity this task belongs to
        /// </summary>
        protected MovableEntity m_host;

        /// <summary>
        /// This task type
        /// </summary>
        protected AITaskType m_atTaskType;
        public AITaskType TaskType { get { return m_atTaskType; } }

        /// <summary>
        /// Steps this task need to do
        /// </summary>
        protected List<AIStep> m_lsSteps = new List<AIStep>(ConstValue.kCap8);

        /// <summary>
        /// Current step
        /// </summary>
        protected AIStep m_asCurStep;

        /// <summary>
        /// Current index of step
        /// </summary>
        protected int m_iCurStep;

        /// <summary>
        /// Is task complete
        /// </summary>
        public bool TaskComplete { get { return m_iCurStep >= m_lsSteps.Count; } }
        #endregion

        #region Interface
        /// <summary>
        /// Change current step to next step
        /// </summary>
        /// <returns> Success or not </returns>
        public virtual bool Change2NextStep()
        {
            if (m_asCurStep != null && m_lsSteps.Count > 0 && ++m_iCurStep < m_lsSteps.Count)
            {
                AIStep nextStep = m_lsSteps[m_iCurStep];
                ChangeStep(nextStep);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Change current task
        /// </summary>
        /// <param name="tNextStep"> Task to change to </param>
        public virtual void ChangeStep(AIStep tNextStep)
        {
            if (m_asCurStep != null)
                m_asCurStep.OnLeave();
            if (tNextStep != null)
                tNextStep.OnEnter();
            m_asCurStep = tNextStep;
        }
        #endregion

        #region Life Cycle
        /// <summary>
        /// Init task
        /// </summary>
        /// <param name="tHost"> Host </param>
        public virtual void Init(MovableEntity tHost)
        {
            m_host = tHost;
            m_atTaskType = AITaskType.None;
            m_iCurStep = -1;
        }

        /// <summary>
        /// Called once when task start
        /// </summary>
        public virtual void OnTaskStart()
        {
            if (++m_iCurStep >= m_lsSteps.Count) return;
            ChangeStep(m_lsSteps[m_iCurStep]);
        }

        /// <summary>
        /// Called every frame while task runs
        /// </summary>
        public virtual void UpdateTask()
        {
            if (m_asCurStep == null) return;

            if (m_asCurStep.IsFinished)
                Change2NextStep();
            else
                m_asCurStep.Update();
        }

        /// <summary>
        /// Called once when task finished
        /// </summary>
        public virtual void OnTaskFinish()
        {
            
        }

        /// <summary>
        /// Clear space
        /// </summary>
        public virtual void Clear()
        {
            for (int i = 0; i < m_lsSteps.Count; i++)
                AITaskFactory.ReleaseAIStep(m_lsSteps[i], m_lsSteps[i].StepType);
            m_lsSteps.Clear();
            m_asCurStep = null;
        }
        #endregion
    }

    /// <summary>
    /// Wander around task
    /// Step1 : find path
    /// Step2 : wait a little while
    /// </summary>
    public class WanderTask : AITask
    {
        #region Life Cycle
        /// <summary>
        /// Init wander task
        /// </summary>
        /// <param name="tHost"> Host </param>
        public void Init(MovableEntity tHost, Vector3 tDstPos)
        {
            base.Init(tHost);
            m_atTaskType = AITaskType.Wander;

            MoveStep findPath = AITaskFactory.GetAIStep(AIStepType.Move) as MoveStep;
            findPath.Init(m_host, tDstPos, true);
            m_lsSteps.Add(findPath);
            IdleStep wait = AITaskFactory.GetAIStep(AIStepType.Idle) as IdleStep;
            wait.Init(m_host, UnityEngine.Random.Range(3, 10));
            m_lsSteps.Add(wait);
        }
        #endregion
    }

    /// <summary>
    /// Build task
    /// Step1 : find path to build position
    /// Step2 : build
    /// Step3 : wait for user check
    /// </summary>
    public class BuildTask : AITask
    {
        #region Property
        /// <summary>
        /// Architecture id
        /// </summary>
        private uint m_uiBuildTargetID;

        /// <summary>
        /// Is player checked
        /// </summary>
        private bool m_bIsChecked = false;
        public bool IsChecked { get { return m_bIsChecked; } set { m_bIsChecked = value; } }

        /// <summary>
        /// Has called other worker to circusee
        /// </summary>
        private bool m_bHasCalledOtherWorker = false;

        private ulong m_ulEndTime = 0;
        #endregion

        #region Test
        /// <summary>
        /// Generate build position
        /// </summary>
        /// <returns> Point generated </returns>
        private Vector3 GenerateBuildPos()
        {
            var building = HomeBuildingViewer.Instance.GetBuildingById((int)m_uiBuildTargetID);
            if (building != null)
            {
                Vector3 v3BuildingPos = building.Position;
                var buildingSize = HomeBuildingMgr.Instance.GetBuildingByID((int)m_uiBuildTargetID).Rect.size;
                float fDis = Mathf.Sqrt(buildingSize.x * buildingSize.x + buildingSize.y * buildingSize.y);
                Vector3 v3Dst = v3BuildingPos + (m_host.Position - v3BuildingPos).normalized * fDis;
                return v3Dst;
            }
            LogHelper.LogWarning("AITask : Can't get building info");
            return Vector3.zero;
        }
        #endregion

        #region Life Cycle
        /// <summary>
        /// Init build task
        /// </summary>
        /// <param name="tHost"> Host </param>
        /// <param name="tTargetID"> Building id </param>
        /// <param name="tTimeInternal"> Build total time </param>
        public void Init(MovableEntity tHost, uint tTargetID, ulong tTimeInternal)
        {
            base.Init(tHost);
            m_atTaskType = AITaskType.Build;
            m_bIsChecked = false;
            m_bHasCalledOtherWorker = false;
            m_uiBuildTargetID = tTargetID;
            m_ulEndTime = tTimeInternal;

            MoveStep findPath = AITaskFactory.GetAIStep(AIStepType.Move) as MoveStep;
            findPath.Init(m_host, GenerateBuildPos(), true);
            m_lsSteps.Add(findPath);
            ActionStep act = AITaskFactory.GetAIStep(AIStepType.Action) as ActionStep;
            //var curTime = GameScene.Instance.GetServerTime();
            //float time = 0;
            //if (tTimeInternal > curTime)
            //    time = (tTimeInternal - curTime) / 1000;
            act.Init(m_host, "dead"/*test*/, /*time*/-2, null);
            m_lsSteps.Add(act);
            IdleStep wait = AITaskFactory.GetAIStep(AIStepType.Idle) as IdleStep;
            wait.Init(m_host);
            m_lsSteps.Add(wait);
            ActionStep cheer = AITaskFactory.GetAIStep(AIStepType.Action) as ActionStep;
            cheer.Init(m_host, "clap", UnityEngine.Random.Range(3, 5), null);
            m_lsSteps.Add(cheer);
        }

        public override void UpdateTask()
        {
            base.UpdateTask();

            if (m_iCurStep == 1)
                if (GameScene.Instance.GetServerTime() > m_ulEndTime)
                    Change2NextStep();

            if (m_iCurStep == 2)
            {
                if (!m_bHasCalledOtherWorker)
                {
                    m_bHasCalledOtherWorker = true;
                    AITaskMgr.Instance.FreeWorkerGatherAround(m_uiBuildTargetID);
                }
                if (m_bIsChecked)
                    Change2NextStep();
            }
        }
        #endregion
    }

    /// <summary>
    /// Greet to player task
    /// Step1 : greet action
    /// </summary>
    public class GreetTask : AITask
    {
        #region Life Cycle
        public override void Init(MovableEntity tHost)
        {
            base.Init(tHost);
            m_atTaskType = AITaskType.Greet;

            ActionStep act = AITaskFactory.GetAIStep(AIStepType.Action) as ActionStep;
            act.Init(m_host, "att01"/*test*/, -1, () =>
            {
                if (m_host.IsInMove) m_host.Stop();
                Vector3 v3Dir = GameScene.Instance.MainChar.Position - m_host.Position;
                m_host.Avatar.SetDirection(v3Dir.x, 0, v3Dir.z);
            });
            m_lsSteps.Add(act);
        }
        #endregion
    }

    /// <summary>
    /// Rest task
    /// Step1 : find path to interaction point
    /// Step2 : sleep or sit
    /// </summary>
    public class RestTask : AITask
    {
        #region Life Cycle
        /// <summary>
        /// Init rest task
        /// </summary>
        /// <param name="tHost"> Host of this task </param>
        /// <param name="tTimeInternal"> How long to rest </param>
        public void Init(MovableEntity tHost, float tTimeInternal)
        {
            base.Init(tHost);
            m_atTaskType = AITaskType.Rest;

            ClientInteractionPointInfo interactionInfo = ClientInteractionPointMgr.Instance.GetClosestInteractionPointInfo(m_host.Position, (ClientInteractionType)(UnityEngine.Random.Range(0, 10) % 2 + 1));
            if (interactionInfo != null)
            {
                MoveStep findPath = AITaskFactory.GetAIStep(AIStepType.Move) as MoveStep;
                findPath.Init(m_host, interactionInfo.Position, true);
                m_lsSteps.Add(findPath);
                ActionStep act = AITaskFactory.GetAIStep(AIStepType.Action) as ActionStep;
                if (interactionInfo.Type == ClientInteractionType.Bench)
                    act.Init(m_host, "SitDownEnter", tTimeInternal, null);
                else if (interactionInfo.Type == ClientInteractionType.Bed)
                    act.Init(m_host, "LieBedEnter", tTimeInternal, null);
                m_lsSteps.Add(act);
            }
            else
                m_iCurStep = m_lsSteps.Count;
        }
        #endregion
    }

    /// <summary>
    /// Worker circusee when one building's done
    /// Step1 : find way to the building
    /// Step2 : wait for player check
    /// Step3 : Cheer!
    /// </summary>
    public class CircuseeTask : AITask
    {
        #region Property
        /// <summary>
        /// Is player checked
        /// </summary>
        private bool m_bIsChecked = false;
        public bool IsChecked { get { return m_bIsChecked; } set { m_bIsChecked = value; } }
        #endregion

        #region Method
        /// <summary>
        /// Generate circusee position
        /// </summary>
        /// <param name="tBuildingID"> Building id </param>
        /// <returns> Position generated </returns>
        private Vector3 GenCircuseePos(uint tBuildingID)
        {
            var building = HomeBuildingViewer.Instance.GetBuildingById((int)tBuildingID);
            if (building != null)
            {
                Vector3 v3BuildingPos = building.Position;
                var buildingSize = HomeBuildingMgr.Instance.GetBuildingByID((int)tBuildingID).Rect.size;
                float fDis = Mathf.Sqrt(buildingSize.x * buildingSize.x + buildingSize.y * buildingSize.y);
                Vector3 v3Dst = v3BuildingPos + (m_host.Position - v3BuildingPos).normalized * fDis;
                return v3Dst;
            }
            LogHelper.LogWarning("AITask : Can't get building info");
            return Vector3.zero;
        }
        #endregion

        #region Life Cycle
        public void Init(MovableEntity tHost, uint tBuildingID)
        {
            base.Init(tHost);
            m_atTaskType = AITaskType.Circusee;
            m_bIsChecked = false;
            
            MoveStep findPath = AITaskFactory.GetAIStep(AIStepType.Move) as MoveStep;
            findPath.Init(m_host, GenCircuseePos(tBuildingID), true);
            m_lsSteps.Add(findPath);
            IdleStep wait = AITaskFactory.GetAIStep(AIStepType.Idle) as IdleStep;
            wait.Init(m_host);
            m_lsSteps.Add(wait);
            ActionStep act = AITaskFactory.GetAIStep(AIStepType.Action) as ActionStep;
            act.Init(m_host, "clap", UnityEngine.Random.Range(3, 5), null);
            m_lsSteps.Add(act);
        }

        public override void UpdateTask()
        {
            base.UpdateTask();

            if (m_iCurStep == 1 && m_bIsChecked == true)
                Change2NextStep();
            if (m_iCurStep < 1 && m_bIsChecked == true)
                m_iCurStep = m_lsSteps.Count;
        }
        #endregion
    }

    /// <summary>
    /// Worker produce
    /// Step1 : find way to market
    /// Step2 : produce
    /// </summary>
    public class ProduceTask : AITask
    {
        #region Property
        /// <summary>
        /// Produce end time
        /// </summary>
        private ulong m_ulEndTime = 0;
        #endregion

        #region Method
        /// <summary>
        /// Generate produce position
        /// </summary>
        /// <returns></returns>
        private Vector3 GenProducePoint()
        {
            return HomeBuildingViewer.Instance.Offset;
        }
        #endregion

        #region Life Cycle
        public void Init(MovableEntity tHost, ulong tEndTime)
        {
            base.Init(tHost);
            m_atTaskType = AITaskType.Produce;
            m_ulEndTime = tEndTime;

            MoveStep findPath = AITaskFactory.GetAIStep(AIStepType.Move) as MoveStep;
            findPath.Init(m_host, GenProducePoint(), true);
            m_lsSteps.Add(findPath);
            //var curTime = GameScene.Instance.GetServerTime();
            //float time = 0;
            //if (tEndTime > curTime)
            //    time = (tEndTime - curTime) / 1000;
            ActionStep act = AITaskFactory.GetAIStep(AIStepType.Action) as ActionStep;
            act.Init(m_host, "clap"/*Test*/, -2, null);
            m_lsSteps.Add(act);
        }

        public override void UpdateTask()
        {
            base.UpdateTask();

            if (m_iCurStep == 1 && GameScene.Instance.GetServerTime() >= m_ulEndTime)
                m_iCurStep++;
        }
        #endregion
    }
}