using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class AITaskFactory
    {
        #region Object Pool
        private static ObjectPool<AITaskMachine> TaskMachineObjects = new ObjectPool<AITaskMachine>();

        private static ObjectPool<WanderTask> WanderTaskObjects = new ObjectPool<WanderTask>();
        private static ObjectPool<BuildTask> BuildTaskObjects = new ObjectPool<BuildTask>();
        private static ObjectPool<GreetTask> GreetTaskObjects = new ObjectPool<GreetTask>();
        private static ObjectPool<RestTask> RestTaskObjects = new ObjectPool<RestTask>();
        private static ObjectPool<CircuseeTask> CircuseeTaskObjects = new ObjectPool<CircuseeTask>();

        private static ObjectPool<IdleStep> IdleStepObjects = new ObjectPool<IdleStep>();
        private static ObjectPool<MoveStep> MoveStepObjects = new ObjectPool<MoveStep>();
        private static ObjectPool<ActionStep> ActionStepObjects = new ObjectPool<ActionStep>();
        #endregion

        #region Get Interface
        public static AITaskMachine GetTaskMachine()
        {
            return TaskMachineObjects.Get();
        }

        public static AITask GetAITask(AITaskType tTaskType)
        {
            switch(tTaskType)
            {
                case AITaskType.Wander:
                    return WanderTaskObjects.Get();
                case AITaskType.Build:
                    return BuildTaskObjects.Get();
                case AITaskType.Greet:
                    return GreetTaskObjects.Get();
                case AITaskType.Rest:
                    return RestTaskObjects.Get();
                case AITaskType.Circusee:
                    return CircuseeTaskObjects.Get();
            }
            return null;
        }

        public static AIStep GetAIStep(AIStepType tStepType)
        {
            switch(tStepType)
            {
                case AIStepType.Idle:
                    return IdleStepObjects.Get();
                case AIStepType.Move:
                    return MoveStepObjects.Get();
                case AIStepType.Action:
                    return ActionStepObjects.Get();
            }
            return null;
        }
        #endregion

        #region Release Interface
        public static void ReleaseTaskMachine(AITaskMachine tMachine)
        {
            tMachine.Clear();
            TaskMachineObjects.Release(tMachine);
        }

        public static void ReleaseAITask(AITask tTask, AITaskType tType)
        {
            tTask.Clear();
            switch (tType)
            {
                case AITaskType.Wander:
                    WanderTaskObjects.Release((WanderTask)tTask);
                    break;
                case AITaskType.Build:
                    BuildTaskObjects.Release((BuildTask)tTask);
                    break;
                case AITaskType.Greet:
                    GreetTaskObjects.Release((GreetTask)tTask);
                    break;
                case AITaskType.Rest:
                    RestTaskObjects.Release((RestTask)tTask);
                    break;
                case AITaskType.Circusee:
                    CircuseeTaskObjects.Release((CircuseeTask)tTask);
                    break;
            }
        }

        public static void ReleaseAIStep(AIStep tStep, AIStepType tType)
        {
            tStep.Clear();
            switch (tType)
            {
                case AIStepType.Idle:
                    IdleStepObjects.Release((IdleStep)tStep);
                    break;
                case AIStepType.Move:
                    MoveStepObjects.Release((MoveStep)tStep);
                    break;
                case AIStepType.Action:
                    ActionStepObjects.Release((ActionStep)tStep);
                    break;
            }
        }
        #endregion
    }
}