using UnityEngine;
using Bokura;
using System.Collections.Generic;
using UnityEngine.AI;

namespace Bokura
{
    #region AI Task Manager
    public class AITaskMgr : ClientSingleton<AITaskMgr>
    {
        #region Property
        /// <summary>
        /// Stores all entity ID and the task machine bounds to it
        /// </summary>
        private Dictionary<ulong, AITaskMachine> m_dicNPCTaskMachine;
        #endregion

        #region Interface
        /// <summary>
        /// Creating entity and task machine, then add to dictionary
        /// </summary>
        /// <param name="uid"> Entity ID </param>
        /// <param name="_baseID"> Entity's base id </param>
        /// <returns> Is successfully created </returns>
        public bool CreateEntity(ulong uid, uint _baseID, AITaskInfo tTaskInfo, Vector3 tEtyPos, string tName = null)
        {
            if (!m_dicNPCTaskMachine.ContainsKey(uid))
            {
                //============= Create entity =============
                MovableEntity ety = GameScene.Instance.CreateClientNpcSync(uid, _baseID, GameScene.Instance.MainChar.LocalPosition, Quaternion.identity, tName);
                ety.Position = tEtyPos;

                //============= Create task machine =============
                AITaskMachine taskMachine = AITaskFactory.GetTaskMachine();
                taskMachine.Init(ety, tTaskInfo);

                //============= Add task machine to dic =============
                AddTaskMachine(uid, taskMachine);
                return true;
            }
            else
                LogHelper.LogWarning("AITaskMgr : Entity id has already been created");
            return false;
        }

        /// <summary>
        /// Add entity to dictionary
        /// </summary>
        /// <param name="tID"> Entity ID </param>
        /// <param name="tTaskMachine"> The task machine to add </param>
        public void AddTaskMachine(ulong tID, AITaskMachine tTaskMachine)
        {
            if (!m_dicNPCTaskMachine.ContainsKey(tID))
                m_dicNPCTaskMachine.Add(tID, tTaskMachine);
            else
                LogHelper.LogWarning("AITaskMgr : The same id has already been added to dictionary");
        }

        /// <summary>
        /// Delete task machine according to ID
        /// </summary>
        /// <param name="tID"> Entity ID </param>
        public void DelTaskMachineByID(ulong tID)
        {
            AITaskMachine taskMachineToDel;
            if (m_dicNPCTaskMachine.TryGetValue(tID, out taskMachineToDel))
            {
                AITaskFactory.ReleaseTaskMachine(taskMachineToDel);
                m_dicNPCTaskMachine.Remove(tID);
            }
            else
                LogHelper.LogWarning("AITaskMgr : There's no such id in dictionary");
        }
        #endregion

        #region Home Worker
        #region Property
        /// <summary>
        /// Store obstacles in scene, used for generate random point
        /// </summary>
        private List<Vector2> m_lsObstacles = new List<Vector2>(ConstValue.kCap8);
        #endregion

        #region Triggered By Events
        /// <summary>
        /// Enter home map, init all worker
        /// </summary>
        private void OnEnterHomeMap()
        {
            foreach (var labor in HomeWorkerModel.Instance.HomeLaborList.Values)
            {
                if (labor.Worker.Worker_State == swm.WorkerState.Idle)
                    AddHomeWorker(labor, GenerateRandomPoint());
                else if (labor.Worker.Worker_State == swm.WorkerState.Working)
                {
                    var building = HomeBuildingViewer.Instance.GetBuildingById((int)labor.Worker.WorkerInfo.Target_id);
                    Vector3 v3Dst = new Vector3(225, 5.5f, 200);
                    if (building != null)
                    {
                        Vector3 v3BuildingPos = building.Position;
                        var buildingSize = HomeBuildingMgr.Instance.GetBuildingByID((int)labor.Worker.WorkerInfo.Target_id).Rect.size;
                        float fDis = Mathf.Sqrt(buildingSize.x * buildingSize.x + buildingSize.y * buildingSize.y);
                        v3Dst = v3BuildingPos + (HomeBuildingViewer.Instance.Offset - v3BuildingPos).normalized * fDis;
                    }
                    LogHelper.LogWarning("AITask : Can't get building info");
                    AddHomeWorker(labor, v3Dst);
                }
            }
            GameScene.Instance.onEndLoading.AddListener(OnLeaveHome);
        }

        /// <summary>
        /// Leave home map
        /// </summary>
        private void OnLeaveHome()
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return;
            if (mapinfo.maptype == (int)swm.MapType.Manor)
                return;

            foreach (var labor in HomeWorkerModel.Instance.HomeLaborList.Values)
                DelHomeWorker(labor);
            GameScene.Instance.onEndLoading.RemoveListener(OnLeaveHome);
        }
        
        /// <summary>
        /// Home worker recruit
        /// </summary>
        /// <param name="tLabor"> Worker info </param>
        private void OnAddHomeWorker(HomeLabor tLabor)
        {
            AddHomeWorker(tLabor, new Vector3(225, 5.5f, 200));
        }

        /// <summary>
        /// Home worker dismiss
        /// </summary>
        /// <param name="tLabor"> Worker info </param>
        private void OnDeleteHomeWorker(HomeLabor tLabor)
        {
            DelHomeWorker(tLabor);
        }

        /// <summary>
        /// Change worker's task
        /// </summary>
        /// <param name="tLabor"> Worker info </param>
        private void OnTaskChange(HomeLabor tLabor)
        {
            AITaskMachine workerTaskMachine;
            if (m_dicNPCTaskMachine.TryGetValue(tLabor.Worker.Id, out workerTaskMachine))
            {
                if (tLabor.Worker.Worker_State == swm.WorkerState.Idle)
                {
                    if (workerTaskMachine.CurTask.TaskType == AITaskType.Build)
                    {
                        var task = workerTaskMachine.CurTask as BuildTask;
                        task.IsChecked = true;
                        FreeWorkerCheer();
                    }
                    else if (UnityEngine.Random.Range(0, 10) % 2 == 0)
                        workerTaskMachine.Wander();
                    else
                        workerTaskMachine.Rest(UnityEngine.Random.Range(10, 30));
                }
                if (tLabor.Worker.Worker_State == swm.WorkerState.Working && HomeBuildingMgr.Instance.GetBuildingByID((int)tLabor.Worker.WorkerInfo.Target_id) != null)
                    workerTaskMachine.Build(tLabor.Worker.WorkerInfo.Target_id, tLabor.Worker.WorkerInfo.End_time);
            }
            else
                LogHelper.LogWarning("AITaskMgr : There's no such worker!");
        }

        /// <summary>
        /// Add / Delete building to / from home
        /// </summary>
        /// <param name="tBuildingID"> Building id </param>
        private void OnAddOrDelBuildingToHome(int tBuildingID)
        {
            foreach (var labor in HomeWorkerModel.Instance.HomeLaborList.Values)
            {
                AITaskMachine workerTaskMachine;
                if (tBuildingID == labor.Worker.WorkerInfo.Target_id && m_dicNPCTaskMachine.TryGetValue(labor.Worker.Id, out workerTaskMachine))
                    workerTaskMachine.Build(labor.Worker.WorkerInfo.Target_id, labor.Worker.WorkerInfo.End_time);
            }
        }

        /// <summary>
        /// When reset building, reset rest/wander worker
        /// </summary>
        /// <param name="tTargetID"> Target building(none relevent) </param>
        public void RefreshNoWorkLabor(int tTargetID)
        {
            foreach (var machine in m_dicNPCTaskMachine.Values)
            {
                switch(machine.CurTask.TaskType)
                {
                    case AITaskType.Wander:
                        machine.Wander();
                        break;
                    case AITaskType.Build:
                        //machine.Build();
                        break;
                    case AITaskType.Rest:
                        machine.Rest(UnityEngine.Random.Range(10, 30));
                        break;
                    case AITaskType.Circusee:
                        //machine.Circusee();
                        break;
                }
            }
        }
        #endregion

        #region Interface
        /// <summary>
        /// Generate random destination for host
        /// </summary>
        /// <returns> Random point </returns>
        public Vector3 GenerateRandomPoint()
        {
            m_lsObstacles.Clear();

            var pointRange = HomeBuildingMgr.Instance.BuildRange;
            var offset = HomeBuildingViewer.Instance.Offset;
            var gridSize = HomeBuildingViewer.GridSize;
            
            // Step 1 : generate a random x coordinate inside home wall
            float x = offset.x + UnityEngine.Random.Range(pointRange.xMin, pointRange.xMax) * gridSize;

            // Step 2 : detect all buildings that x coordinate equals the random x coord, push in list
            foreach (var buildingID in HomeBuildingViewer.Instance.BuildingList.Keys)
            {
                Vector3 buildingPos = HomeBuildingViewer.Instance.BuildingList[buildingID].Position;
                var buildingInfo = HomeBuildingMgr.Instance.GetBuildingByID((int)buildingID);
                if (buildingInfo != null)
                {
                    var buildingSize = buildingInfo.Rect.size;
                    if (buildingPos.x - buildingSize.x < x && buildingPos.x + buildingSize.x > x)
                    {
                        var obstacle = new Vector2(buildingPos.z - buildingSize.y, buildingPos.z + buildingSize.y);
                        m_lsObstacles.Add(obstacle);
                    }
                }
            }

            // Step 3 : sort the building list
            RankObstacles();

            // Step 4 : get the empty space in this line
            //===============|==========================
            //|              |  }space 2               |
            //|          ----|-                        |
            //|         |    | |                       |
            //|          ----|-                        |
            //|              |  }space 1               |
            //|            --|------------             |
            //|           |  |            |            |
            //|           |  |            |            |
            //|            --|------------             |
            //|              |  }space 0               | (home map)
            //===============|==========================
            int space = UnityEngine.Random.Range(0, 100) % (m_lsObstacles.Count + 1);
            float y = UnityEngine.Random.Range(0, 1);
            if (m_lsObstacles.Count > 0)
            {
                float up = 0;
                float down = 0;

                if (space == 0)
                {
                    up = m_lsObstacles[0].x;
                    //down = 130;
                    down = offset.z + pointRange.yMin * gridSize;
                }
                else if (space == m_lsObstacles.Count)
                {
                    //up = 209;
                    up = offset.z + pointRange.yMax * gridSize;
                    down = m_lsObstacles[m_lsObstacles.Count - 1].y;
                }
                else
                {
                    up = m_lsObstacles[space].x;
                    down = m_lsObstacles[space - 1].y;
                }

                //if (up == down)
                //    return GenerateRandomPoint();
                y = down + (up - down) * y;
            }
            else
            {
                //y = UnityEngine.Random.Range(0, 75) + 130;
                y = offset.z + UnityEngine.Random.Range(pointRange.yMin, pointRange.yMax) * gridSize;
            }

            RaycastHit hitinfo;
            var src = new Vector3(x, 10, y);
            if (!Physics.Raycast(src, Vector3.down, out hitinfo, 10.0f, (int)Bokura.UserLayerMask.Terrain, QueryTriggerInteraction.Ignore))
            {
                return HomeBuildingViewer.Instance.Offset;
            }
            return new Vector3(x, hitinfo.point.y, y);
        }

        /// <summary>
        /// When a worker's work is finished, other worker circusee
        /// </summary>
        /// <param name="tBuildingID"> Building to go to </param>
        public void FreeWorkerGatherAround(uint tBuildingID)
        {
            foreach (var worker in m_dicNPCTaskMachine.Values)
            {
                if (worker.CurTask.TaskType != AITaskType.Build)
                {
                    worker.Circusee(tBuildingID);
                }
            }
        }

        /// <summary>
        /// Workers cheer when building's complete
        /// </summary>
        public void FreeWorkerCheer()
        {
            foreach (var worker in m_dicNPCTaskMachine.Values)
            {
                if (worker.CurTask.TaskType == AITaskType.Circusee)
                {
                    var circusee = worker.CurTask as CircuseeTask;
                    circusee.IsChecked = true;
                }
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// Add a home worker task machine
        /// </summary>
        /// <param name="tLabor"> Worker info </param>
        /// <param name="tIsRandomPos"> Is random position when init </param>
        private void AddHomeWorker(HomeLabor tLabor, Vector3 tLaborPos)
        {
            AITaskType ttWorkerTask = AITaskType.None;
            if (tLabor.Worker.Worker_State == swm.WorkerState.Idle)
            {
                if (UnityEngine.Random.Range(0, 10) % 2 == 0)
                    ttWorkerTask = AITaskType.Wander;
                else
                    ttWorkerTask = AITaskType.Rest;
            }
            else if (tLabor.Worker.Worker_State == swm.WorkerState.Working)
                ttWorkerTask = AITaskType.Build;
            AITaskInfo tiWorkerInfo = new AITaskInfo(ttWorkerTask, tLabor.Worker.WorkerInfo.Target_id, tLabor.Worker.WorkerInfo.End_time);

            CreateEntity(tLabor.Worker.Id, (uint)tLabor.NpcTableBaseConfig.Value.id, tiWorkerInfo, tLaborPos, tLabor.LaborBaseTableBaseConfig.Value.name);
        }

        /// <summary>
        /// Delete home worker task machine according to data
        /// </summary>
        /// <param name="tLabor"> The worker to delete </param>
        private void DelHomeWorker(HomeLabor tLabor)
        {
            DelTaskMachineByID(tLabor.Worker.Id);
            var ety = GameScene.Instance.GetEntityByID(tLabor.Worker.Id);
            if (ety != null)
                GameScene.Instance.RemoveEntity(ety);
        }

        /// <summary>
        /// Rank obstacles, 0 - N : small to big
        /// </summary>
        private void RankObstacles()
        {
            if (m_lsObstacles.Count == 0) return;

            for (int i = 0; i < m_lsObstacles.Count - 1; i++)
                for (int j = i + 1; j < m_lsObstacles.Count; j++)
                    if (m_lsObstacles[j].x < m_lsObstacles[i].x)
                    {
                        var temp = m_lsObstacles[j];
                        m_lsObstacles[j] = m_lsObstacles[i];
                        m_lsObstacles[i] = temp;
                    }
        }
        #endregion
        #endregion

        #region Life Cycle
        /// <summary>
        /// Singleton initialize
        /// </summary>
        public void Init()
        {
            m_dicNPCTaskMachine = new Dictionary<ulong, AITaskMachine>(ConstValue.kCap8);

            #region Home Worker
            HomeWorkerModel.Instance.onInitHomeLaborListEvent.AddListener(OnEnterHomeMap);
            HomeWorkerModel.Instance.onAddHomeLaborEvent.AddListener(OnAddHomeWorker);
            HomeWorkerModel.Instance.onDeleteHomeLaborEvent.AddListener(OnDeleteHomeWorker);
            HomeWorkerModel.Instance.onRefreshHomeLaborWorkInfoEvent.AddListener(OnTaskChange);
            HomeBuildingViewer.Instance.OnAddBuildingFinish.AddListener(OnAddOrDelBuildingToHome);
            HomeBuildingMgr.Instance.OnBuildingInfoUpdate.AddListener(RefreshNoWorkLabor);
            #endregion
        }

        /// <summary>
        /// Update all task machine
        /// </summary>
        public void Update()
        {
            foreach (var npcTaskMachine in m_dicNPCTaskMachine.Values)
                npcTaskMachine.DoUpdate();
        }

        /// <summary>
        /// Clear space
        /// </summary>
        public void Clear()
        {
            #region Home Worker
            HomeBuildingMgr.Instance.OnBuildingInfoUpdate.RemoveListener(RefreshNoWorkLabor);
            HomeBuildingViewer.Instance.OnAddBuildingFinish.RemoveListener(OnAddOrDelBuildingToHome);
            HomeWorkerModel.Instance.onRefreshHomeLaborWorkInfoEvent.RemoveListener(OnTaskChange);
            HomeWorkerModel.Instance.onDeleteHomeLaborEvent.RemoveListener(OnDeleteHomeWorker);
            HomeWorkerModel.Instance.onAddHomeLaborEvent.RemoveListener(OnAddHomeWorker);
            HomeWorkerModel.Instance.onInitHomeLaborListEvent.RemoveListener(OnEnterHomeMap);
            #endregion

            foreach (var npcTaskMachine in m_dicNPCTaskMachine.Values)
                AITaskFactory.ReleaseTaskMachine(npcTaskMachine);
            m_dicNPCTaskMachine.Clear();
        }
        #endregion
    }
    #endregion

    #region AI Task Info
    public class AITaskInfo
    {
        public AITaskType TaskType = AITaskType.None;
        public uint TaskTargetID = 0;
        public ulong EndTime = 0;

        public AITaskInfo(AITaskType tType = AITaskType.None, uint TargetID = 0, ulong tEndTime = 0)
        {
            TaskType = tType;
            TaskTargetID = TargetID;
            EndTime = tEndTime;
        }
    }
    #endregion

    #region AI Task Machine
    /// <summary>
    /// Manage host's tasks, similar to state machine
    /// </summary>
    public class AITaskMachine
    {
        #region Property
        /// <summary>
        /// Host to this task machine
        /// </summary>
        private MovableEntity m_host;
        public MovableEntity Host { get { return m_host; } }

        /// <summary>
        /// Current task
        /// </summary>
        private AITask m_tskCurTask;
        public AITask CurTask { get { return m_tskCurTask; } }

        /// <summary>
        /// If player go out of greet range(5m), labor can greet again
        /// </summary>
        private bool m_bCanGreet = false;
        #endregion

        #region Interface
        /// <summary>
        /// Change task
        /// </summary>
        /// <param name="tNextTask"> Task to change </param>
        public void ChangeTask(AITask tNextTask)
        {
            if (m_tskCurTask != null)
            {
                m_tskCurTask.OnTaskFinish();
                AITaskFactory.ReleaseAITask(m_tskCurTask, m_tskCurTask.TaskType);
            }
            if (tNextTask != null)
                tNextTask.OnTaskStart();
            m_tskCurTask = tNextTask;
        }
        #endregion

        #region Tasks
        /// <summary>
        /// NPC wander around
        /// </summary>
        public void Wander()
        {
            var nextTask = AITaskFactory.GetAITask(AITaskType.Wander) as WanderTask;
            nextTask.Init(m_host, AITaskMgr.Instance.GenerateRandomPoint());
            ChangeTask(nextTask);
        }

        /// <summary>
        /// User command, change host to build task
        /// triggered by event
        /// </summary>
        /// <param name="tTargetID"> Building id </param>
        /// <param name="tTimeInternal"> Build total time </param>
        public void Build(uint tTargetID, ulong tTimeInternal)
        {
            var buildTask = AITaskFactory.GetAITask(AITaskType.Build) as BuildTask;
            buildTask.Init(m_host, tTargetID, tTimeInternal);
            ChangeTask(buildTask);
        }

        /// <summary>
        /// Greet to player
        /// </summary>
        public void TryToGreet()
        {
            if (m_tskCurTask is BuildTask) return;
            if (m_tskCurTask is CircuseeTask) return;

            Vector3 v3Dir = GameScene.Instance.MainChar.Position - m_host.Position;
            if (Vector3.Angle(v3Dir, m_host.Direction) > 90) return;

            if (v3Dir.magnitude < 5)
            {
                if (m_bCanGreet)
                {
                    m_bCanGreet = false;

                    var greetTask = AITaskFactory.GetAITask(AITaskType.Greet) as GreetTask;
                    greetTask.Init(m_host);
                    ChangeTask(greetTask);
                }
            }
            else
                m_bCanGreet = true;
        }

        /// <summary>
        /// Worker rest
        /// </summary>
        /// <param name="tTimeInternal"> Rest total time </param>
        public void Rest(float tTimeInternal)
        {
            var restTask = AITaskFactory.GetAITask(AITaskType.Rest) as RestTask;
            restTask.Init(m_host, tTimeInternal);
            ChangeTask(restTask);
        }

        /// <summary>
        /// Worker circusee when one worker's building finished
        /// </summary>
        /// <param name="tBuildingID"> Building ID </param>
        public void Circusee(uint tBuildingID)
        {
            var circuseeTask = AITaskFactory.GetAITask(AITaskType.Circusee) as CircuseeTask;
            circuseeTask.Init(m_host, tBuildingID);
            ChangeTask(circuseeTask);
        }

        /// <summary>
        /// Worker produce
        /// </summary>
        /// <param name="tEndTime"> Produce end time </param>
        public void Produce(ulong tEndTime)
        {
            var produceTask = AITaskFactory.GetAITask(AITaskType.Produce) as ProduceTask;
            produceTask.Init(m_host, tEndTime);
            ChangeTask(produceTask);
        }
        #endregion

        #region Life Cycle
        /// <summary>
        /// Init task machine
        /// </summary>
        /// <param name="tHost"> Host entity </param>
        /// <param name="tTaskInfo"> Host's current task info </param>
        public void Init(MovableEntity tHost, AITaskInfo tTaskInfo)
        {
            m_host = tHost;
            m_bCanGreet = false;
            
            switch (tTaskInfo.TaskType)
            {
                case AITaskType.Wander:
                        Wander();
                    break;
                case AITaskType.Build:
                    {
                        if (HomeBuildingMgr.Instance.GetBuildingByID((int)tTaskInfo.TaskTargetID) != null)
                            Build(tTaskInfo.TaskTargetID, tTaskInfo.EndTime);
                        else
                            Wander();
                    }
                    break;
                case AITaskType.Rest:
                    Rest(UnityEngine.Random.Range(10, 30));
                    break;
            }
            
            GameScene.Instance.MainChar.onMoveEvent.AddListener(TryToGreet);
        }

        /// <summary>
        /// Update
        /// </summary>
        public void DoUpdate()
        {
            if(m_host != null && m_host.IsInMove)
                TryToGreet();

            if (m_tskCurTask != null)
            {
                if (m_tskCurTask.TaskComplete)
                {
                    if (UnityEngine.Random.Range(0, 10) % 2 == 0)
                        Wander();
                    else
                        Rest(UnityEngine.Random.Range(10, 30));
                }
                else
                {
                    m_tskCurTask.UpdateTask();
                }
            }
        }

        /// <summary>
        /// Clear space
        /// </summary>
        public void Clear()
        {
            AITaskFactory.ReleaseAITask(m_tskCurTask, m_tskCurTask.TaskType);
            m_tskCurTask = null;
            
            if (GameScene.Instance.MainChar != null)
                GameScene.Instance.MainChar.onMoveEvent.RemoveListener(TryToGreet);
        }
        #endregion
    }
    #endregion
}