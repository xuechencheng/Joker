﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bokura
{
    public class AchievementDataElementInfo
    {
        public ushort group = 0;
        public ushort type = 0;
        public uint cur_value = 0;
        public uint goal = 0;
    }

    public class AchievementDataInfo
    {
        public uint id = 0;
        public swm.AchievementState state = swm.AchievementState.Undo;
        public ulong done_time = 0;
        public List<AchievementDataElementInfo> element = new List<AchievementDataElementInfo>(Bokura.ConstValue.kCap32);

        public AchievementTableBase AchievementConfig;

        /// <summary>
        /// 重置网络数据
        /// </summary>
        public void ResetNetData()
        {
            state = swm.AchievementState.Undo;
            done_time = 0;
            element.Clear();
        }

        /// <summary>
        /// 通过 _group 和 _type 获得AchievementDataElementInfo
        /// </summary>
        /// <param name="_group"></param>
        /// <param name="_type"></param>
        /// <returns></returns>
        public AchievementDataElementInfo GetAchievementDataElementInfo(ushort _group, ushort _type)
        {
            AchievementDataElementInfo _info = null;
            for(int i=0;i<element.Count;i++)
            {
                var _data = element[i];
                if(_data.group == _group && _data.type == _type)
                {
                    _info = _data;
                    break;
                }
            }
            return _info;
        }

        /// <summary>
        /// 刷新AchievementDataElementInfo数据
        /// </summary>
        /// <param name="_info"></param>
        public void RefreshElementInfo( swm.AchievementElemInfo _info )
        {
            AchievementDataElementInfo _infoData = GetAchievementDataElementInfo(_info.group,_info.type);
            if(null == _infoData)
            {
                _infoData = new AchievementDataElementInfo();
                _infoData.group = _info.group;
                _infoData.type = _info.type;
                element.Add(_infoData);
            }
            _infoData.cur_value = _info.cur_value;
            _infoData.goal = _info.goal;
        }

        /// <summary>
        /// 获得当前最大的进度
        /// </summary>
        /// <returns></returns>
        public float GetMaxRateValue()
        {
            float f = 0;
            for (int i = 0; i < element.Count; i++)
            {
                var _data = element[i];
                if (_data.goal > 0)
                {
                    float v = (float)_data.cur_value / (float)_data.goal;
                    if(v>f)
                    {
                        f = v;
                    }
                }
            }
            return f;
        }
    }

    public class AchievementData
    {
        private ulong m_UserId = 0;
        private List<AchievementDataInfo> m_AchievementInfoList = new List<AchievementDataInfo>(Bokura.ConstValue.kCap32);
        private bool m_bIsInit = false;
        public ulong UserId
        {
            get
            {
                return m_UserId;
            }
            set
            {
                m_UserId = value;
            }
        }

        public List<AchievementDataInfo> AchievementInfoList
        {
            get
            {
                return m_AchievementInfoList;
            }
        }
        /// <summary>
        /// 初始化
        /// </summary>
        public void Init()
        {
            if(!m_bIsInit)
            {
                m_bIsInit = true;
                m_AchievementInfoList.Clear();
                AchievementTableBaseList _lst = AchievementTableManager.Instance.m_DataList;
                for (int i = 0; i < _lst.AchievementTableLength; ++i)
                {
                    var data = _lst.AchievementTable(i);
                    AchievementDataInfo _info = new AchievementDataInfo();
                    _info.AchievementConfig = data.Value;
                    _info.id = (uint)data.Value.id;
                    m_AchievementInfoList.Add(_info);
                }
            }
        }

        /// <summary>
        /// 排序
        /// </summary>
        public void SortList()
        {
            if (m_AchievementInfoList.Count > 0)
            {
                m_AchievementInfoList.Sort(ProcessSrotList);
            }
        }

        private int GetValueByState(swm.AchievementState state)
        {
            int value = 0;
            switch(state)
            {
                case swm.AchievementState.Undo:
                    value = 10;
                    break;
                case swm.AchievementState.Doing:
                    value = 20;
                    break;
                case swm.AchievementState.Done:
                    value = 30;
                    break;
                case swm.AchievementState.Claimed:
                    value = 1;
                    break;
            }
            return value;
        }

        public int ProcessSrotList(AchievementDataInfo _a, AchievementDataInfo _b)
        {
            int aState = GetValueByState(_a.state);
            int bState = GetValueByState(_b.state);
            if (aState < bState)
            {
                return 1;
            }
            else if (aState > bState)
            {
                return -1;
            }

            float af = _a.GetMaxRateValue();
            float bf = _b.GetMaxRateValue();

            if(af < bf)
            {
                return 1;
            }
            else if(af > bf)
            {
                return -1;
            }


            if (_a.id < _b.id)
            {
                return -1;
            }
            else if (_a.id == _b.id)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 重置列表所有网络数据
        /// </summary>
        public void ResetNetData()
        {
            AchievementDataInfo _info;
            for (int i =0;i<m_AchievementInfoList.Count;i++)
            {
                _info = m_AchievementInfoList[i];
                _info.ResetNetData();
            }
        }

        /// <summary>
        /// 通过id获得AchievementDataInfo
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public AchievementDataInfo GetAchievementDataInfoById(uint _id)
        {
            AchievementDataInfo _info = null;
            for (int i = 0; i < m_AchievementInfoList.Count; i++)
            {
                var _data = m_AchievementInfoList[i];
                if(_data.id == _id)
                {
                    _info = _data;
                    break;
                }
            }
            if(null == _info)
            {
                AchievementTableBase? v = AchievementTableManager.GetData((int)_id);
                if(v != null)
                {
                    _info = new AchievementDataInfo();
                    _info.AchievementConfig = v.Value;
                    _info.id = _id;
                    m_AchievementInfoList.Add(_info);
                }
            }

            return _info;
        }

        /// <summary>
        /// 刷新数据 通过swm.AchievementInfo
        /// </summary>
        /// <param name="_info"></param>
        /// <returns></returns>
        public AchievementDataInfo RefreshData(swm.AchievementInfo _info)
        {
            AchievementDataInfo _infoData = GetAchievementDataInfoById(_info.id);
            if(null != _infoData)
            {
                _infoData.state = _info.state;
                _infoData.done_time = _info.done_time;
                for (int i =0;i<_info.elementLength;i++)
                {
                    _infoData.RefreshElementInfo(_info.element(i).Value);
                }
            }
            return _infoData;
        }
        /// <summary>
        /// 刷新数据 通过swm.AchievementSimpleInfo
        /// </summary>
        /// <param name="_info"></param>
        /// <returns></returns>
        public AchievementDataInfo RefreshData(swm.AchievementSimpleInfo _info)
        {
            AchievementDataInfo _infoData = GetAchievementDataInfoById(_info.id);
            if (null != _infoData)
            {
                _infoData.state = _info.state;
            }
            return _infoData;
        }

        public void SortOtherList()
        {
            if (m_AchievementInfoList.Count > 0)
            {
                m_AchievementInfoList.Sort(ProcessSrotOtherList);
            }
        }

        public int ProcessSrotOtherList(AchievementDataInfo _a, AchievementDataInfo _b)
        {
            int aState = GetValueByState(_a.state);
            int bState = GetValueByState(_b.state);
            if (aState < bState)
            {
                return -1;
            }
            else if (aState > bState)
            {
                return 1;
            }

            if (_a.id < _b.id)
            {
                return -1;
            }
            else if (_a.id == _b.id)
            {
                return 0;
            }
            return 1;
        }
    }
}
