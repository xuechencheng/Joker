using Bokura;

namespace Bokura
{
    class AchievementModel : ClientSingleton<AchievementModel>
    {
        private bool m_bIsGetOwnAchievement = false;

        private AchievementData m_OwnAchievement = new AchievementData();//自己的成就

        private AchievementData m_OtherAchievement = new AchievementData();//当前请求的 其他人的成就

        private uint m_AchievementNum = 0;
        public AchievementData OwnAchievement
        {
            get
            {
                return m_OwnAchievement;
            }
        }

        public AchievementData OtherAchievement
        {
            get
            {
                return m_OtherAchievement;
            }
        }

        public bool IsGetOwnAchievement
        {
            get
            {
                return m_bIsGetOwnAchievement;
            }
        }

        public uint AchievementNum
        {
            get
            {
                return m_AchievementNum;
            }
        }

        public class RefreshAchievementDataInfo : GameEvent<AchievementDataInfo>
        {

        }
        public GameEvent<uint> onRedPointEvent = new GameEvent<uint>();

        public GameEvent onInitGetOwnAchievementListEvent = new GameEvent();
        public RefreshAchievementDataInfo onRefreshAchievementDataInfoEvent = new RefreshAchievementDataInfo();
        public GameEvent onInitGetOtherAchievementListEvent = new GameEvent();

        [XLua.BlackList]
        public void Init()
        {
            //注册系统逻辑事件
            RedDotModel.Instance.onRedDotEvent.AddListener(PorcRedPoint);

            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAchivementList>(ProcRspAchivementList);//接受自己的成就列表
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshAchievement>(ProcRefreshAchievement);//刷新某个成就
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspOtherAchievementList>(ProcRspOtherAchievementList);//接受别人的成就列表
        }

        /// <summary>
        /// 清除所有数据
        /// </summary>
        public void Clear()
        {
            m_OwnAchievement.ResetNetData();
            m_bIsGetOwnAchievement = false;
        }

        /// <summary>
        /// 关于 邮件的红点数据和处理
        /// </summary>
        /// <param name="_msg"></param>
        private void PorcRedPoint(RedDotData _msg)
        {
            if (_msg.RedDotType == swm.RedDotType.ACHIEVEMENT)
            {
                m_AchievementNum = _msg.Num;
                onRedPointEvent.Invoke(m_AchievementNum);
            }

        }

        //接收网络消息
        /// <summary>
        /// 接收自己的成就列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspAchivementList(swm.RspAchivementList _msg)
        {
            m_OwnAchievement.Init();
            for (int i =0;i<_msg.achievementsLength;i++)
            {
                m_OwnAchievement.RefreshData(_msg.achievements(i).Value);
            }
            if(_msg.final_pack)
            {
                m_bIsGetOwnAchievement = true;
                m_OwnAchievement.SortList();
                onInitGetOwnAchievementListEvent.Invoke();
            }
        }

        /// <summary>
        /// 刷新某个成就
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshAchievement(swm.RefreshAchievement _msg)
        {
            AchievementDataInfo _infoData = m_OwnAchievement.RefreshData(_msg.achievement.Value);
            if(null != _infoData)
            {
                m_OwnAchievement.SortList();
                onRefreshAchievementDataInfoEvent.Invoke(_infoData);
            }
        }

        /// <summary>
        /// 接收别人成就列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspOtherAchievementList(swm.RspOtherAchievementList _msg)
        {
            m_OtherAchievement.Init();
            m_OtherAchievement.UserId = _msg.id;
            m_OtherAchievement.ResetNetData();
            for(int i=0;i<_msg.achievementLength;i++)
            {
                m_OtherAchievement.RefreshData(_msg.achievement(i).Value);
            }
            m_OtherAchievement.SortOtherList();
            onInitGetOtherAchievementListEvent.Invoke();
        }

        //发送网络消息
        /// <summary>
        /// 发送 请求自己的成就列表
        /// </summary>
        public void SendReqAchivementList()
        {
            if(m_bIsGetOwnAchievement)
            {
                onInitGetOwnAchievementListEvent.Invoke();
            }
            else
            {
                //没有请求过 就请求一次
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqAchivementList.StartReqAchivementList(fbb);
                var msg = swm.ReqAchivementList.EndReqAchivementList(fbb);
                fbb.Finish(msg.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqAchivementList.HashID, fbb);
            }
        }

        /// <summary>
        /// 请求领取成就奖励
        /// </summary>
        /// <param name="_id"></param>
        public void SendReqAchievementAward(uint _id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqAchievementAward.StartReqAchievementAward(fbb);
            swm.ReqAchievementAward.AddId(fbb, _id);
            var msg = swm.ReqAchievementAward.EndReqAchievementAward(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAchievementAward.HashID, fbb);
        }

        /// <summary>
        /// 请求查看别人的成就列表
        /// </summary>
        /// <param name="_id"></param>
        public void SendReqOtherAchievementList(ulong _id)
        {
            m_OtherAchievement.ResetNetData();
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqOtherAchievementList.StartReqOtherAchievementList(fbb);
            swm.ReqOtherAchievementList.AddId(fbb, _id);
            var msg = swm.ReqOtherAchievementList.EndReqOtherAchievementList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqOtherAchievementList.HashID, fbb);
        }
    }
}
