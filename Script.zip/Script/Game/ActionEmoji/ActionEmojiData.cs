#define SHOWCHECKLOG0
using System.Collections;
using System.Collections.Generic;
using Bokura;
namespace Bokura
{
    public class PlayActionEmojiRoleData
    {
        public ulong entityid;
        public uint id;
        public ulong targetid;
    }


    //当前玩家表情动作数据类
    public class ActionEmojiData
    {
        private List<uint> m_UnLockAEIds = new List<uint>(10);  //当前已解锁的动作表情id
        public List<uint> PlayerUnLockAEIds
        {
            get
            {
                return m_UnLockAEIds;
            }
        }
        private bool m_HasIniUnLockAEIds = false;
        private Dictionary<ulong,PlayActionEmojiRoleData> m_PlayEmoteActionRoles = new Dictionary<ulong,PlayActionEmojiRoleData>(10);
        private ObjectPool<PlayActionEmojiRoleData> m_PlayEmoteActionRolePools = new ObjectPool<PlayActionEmojiRoleData>();
        private PlayActionEmojiRoleData m_TempChooseReslut;

        /// <summary>
        /// 清除数据
        /// </summary>
        public void Clear()
        {
            
            //m_PlayEmoteActionRolePools.Release();
            m_UnLockAEIds.Clear();
            m_HasIniUnLockAEIds = false;
            m_TempChooseReslut = null;
            foreach (var s in m_PlayEmoteActionRoles)
            {
                m_PlayEmoteActionRolePools.Release(s.Value);
               // m_PlayEmoteActionRoles.Remove(s.Key);
            }
            m_PlayEmoteActionRoles.Clear();
            
        }
        //检查是否需要更新服务器数据 防止每次点开界面 都请求服务器数据
        public bool IsNeedUpdata
        {
            get
            {
                return m_HasIniUnLockAEIds == false || m_UnLockAEIds.Count <= 0;
            }
        }
        /// <summary>
        /// 重新初始化数据
        /// </summary>
        /// <param name="_data"></param>
    
        public bool Init(swm.SyncEmoteAction _data)
        {
            Clear();
            uint _id = 0;
            for (int i = 0; i < _data.listLength; i++)
            {
                _id = _data.list(i);
                AddOneAE(_id);
            }
            m_HasIniUnLockAEIds = true;
            return true;
        }

        //添加一个动作表情
        public void AddOneAE(uint id)
        {
            if(m_UnLockAEIds.Contains(id)==false)
            {
#if SHOWCHECKLOG
                string str = string.Format("ActionEmojiData AddOneAE 添加表情动作解锁 id ={0}", id.ToString());
                LogHelper.Log(str);// " ActionEmojiData AddOneAE 添加表情动作解锁 id = " + id.ToString());    
#endif
                m_UnLockAEIds.Add(id);
            }
        }

        public void AddOnePlayAE(swm.NotifyUseEmoteAction _data)
        {
            //PlayActionEmojiRoleData newone = new PlayActionEmojiRoleData();
            PlayActionEmojiRoleData newone;
            if (m_PlayEmoteActionRoles.TryGetValue(_data.entityid, out newone))
            {
                newone.entityid = _data.entityid;
                newone.id = _data.id;
                newone.targetid = _data.targetid;
            }
            else
            {
                newone = m_PlayEmoteActionRolePools.Get();
                newone.entityid = _data.entityid;
                newone.id = _data.id;
                newone.targetid = _data.targetid;
                m_PlayEmoteActionRoles.Add(newone.entityid, newone);
            }
           
        }
       
        public ulong ReleasePlayAE(ulong entityid)
        {
            if (m_PlayEmoteActionRoles.TryGetValue(entityid,out m_TempChooseReslut) == true)
            {
                ulong reslut = m_TempChooseReslut.targetid;
                m_PlayEmoteActionRoles.Remove(entityid);
                m_PlayEmoteActionRolePools.Release(m_TempChooseReslut);
                m_TempChooseReslut = null;
                return reslut;
            }
           else
            {
                //认为有问题
                
            }
            return 0;
        }
        public PlayActionEmojiRoleData GetPlayAERoleData(ulong entityid)
        {
            PlayActionEmojiRoleData _data;
            if (m_PlayEmoteActionRoles.TryGetValue(entityid, out _data) == true)
            {
                return _data;
            }
            return null;
        }
    }
}
