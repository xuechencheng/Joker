//#define SHOWCHECKLOG
//#define TESTCODE
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    //动作表情管理类
    public class ActionEmojiManager: ClientSingleton<ActionEmojiManager>
	{
        private ActionEmojiData m_ActionEmojiData = new ActionEmojiData();
        public ActionEmojiData PlayerActionEmojiData
        {
            get
            {
                return m_ActionEmojiData;
            }
        }

        #region 回调消息定义
        
        public GameEvent onSyncEmoteActionEvent = new GameEvent();

        public class AddEmoteActionEvent : GameEvent<uint> { }
        public AddEmoteActionEvent onAddEmoteActionEvent = new AddEmoteActionEvent();
        public class AskUseEmoteActionEvent : GameEvent<ulong,uint> { }
        public AskUseEmoteActionEvent onAskUseEmoteActionEvent = new AskUseEmoteActionEvent();
        public class AskUseEmoteActionResultEvent : GameEvent<bool,ulong,uint> { }
        public AskUseEmoteActionResultEvent onAskUseEmoteActionResultEvent = new AskUseEmoteActionResultEvent();

        public class NotifyUseEmoteActionEvent : GameEvent<ulong,uint,ulong> { }
        public NotifyUseEmoteActionEvent onNotifyUseEmoteActionEvent = new NotifyUseEmoteActionEvent();

        #endregion



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
#if TESTCODE
            //测试代码
            TargetSelector.Instance.onSelectTargetChange.AddListener(test_OnLockTargetChange);
#endif
            #region 服务器返回消息
            // 同步表情动作
            //table SyncEmoteAction {
            //list:[uint32];
            //}
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SyncEmoteAction>(this.sc_SyncEmoteAction);

            // 增加表情动作
            //table AddEmoteAction {
            //id: uint32;
            //}
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AddEmoteAction>(this.sc_AddEmoteAction);

            // 询问对方是否接受使用表情
            //table AskUseEmoteAction {
            //casterid: uint64;
            //id: uint32;
            //}
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AskUseEmoteAction>(this.sc_AskUseEmoteAction);

            // 询问返回
            //table AskUseEmoteActionResult {
            //isok: bool;
            //casterid: uint64;
            //id: uint32;
            //}
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AskUseEmoteActionResult>(this.sc_AskUseEmoteActionResult);

            // 九屏使用表情动作
            //table NotifyUseEmoteAction {
            //entityid: uint64;
            //id: uint32;
            //targetid: uint64;
            //}
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyUseEmoteAction>(this.sc_NotifyUseEmoteAction);

            // 打断表情动作
            //table BrokenEmoteAction {
            //entityid: uint64;
            //}
            MsgDispatcher.instance.RegisterFBMsgProc<swm.BrokenEmoteAction>(this.sc_BrokenEmoteAction);
            #endregion
            EmoteActionTableIds.Clear();

            UserDataMgr.Instance.onUserDataSync.AddListener(RequestGetEmoteActions);


        }

        void RequestGetEmoteActions()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.GetEmoteActions.StartGetEmoteActions(fbb);
            fbb.Finish(swm.GetEmoteActions.EndGetEmoteActions(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.GetEmoteActions.HashID, fbb);

        }
        /// <summary>
        /// 加载配置数据
        /// </summary>
        //public void Load()
        //{

        //}

        private List<int> EmoteActionTableIds = new List<int>(10);


        public List<int> GetAllEaIds()
        {
            if(EmoteActionTableIds.Count<=0 && EmoteActionTableManager.Instance.m_DataList.EmoteActionTableLength>0)
            {
                for (int i = 0; i < EmoteActionTableManager.Instance.m_DataList.EmoteActionTableLength; ++i)
                {
                    var data = EmoteActionTableManager.Instance.m_DataList.EmoteActionTable(i);
                    EmoteActionTableIds.Add(data.Value.id);
                }
            }
            return EmoteActionTableIds;
        }
        /// <summary>
        /// （大退/小退）清理缓存
        /// </summary>
        public void Clear()
        {
            m_ActionEmojiData.Clear();
            EmoteActionTableIds.Clear();
        }
        /// <summary>
        /// 请求玩家所有解锁的表情动作ID
        /// </summary>
        public bool cs_GetEmoteActions()
        {
            if(m_ActionEmojiData.IsNeedUpdata==true)
            {
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.GetEmoteActions.StartGetEmoteActions(fbb);
                var msg = swm.GetEmoteActions.EndGetEmoteActions(fbb);
                fbb.Finish(msg.Value);
                MsgDispatcher.instance.SendFBPackage(swm.GetEmoteActions.HashID, fbb);
                return true;
            }
#if SHOWCHECKLOG
            else
            {
                LogHelper.Log(" cs_GetEmoteActions IsNeedUpdata=false 不需要更新服务器数据");
            }
#endif
            return false;
        }
        /// <summary>
        /// 服务器下发玩家所有的表情动作ID ( 已经解锁的  未解锁的 都在表里读) ui_actionemoji.lua处理
        /// </summary>
        public void sc_SyncEmoteAction(swm.SyncEmoteAction EAList)
        {
            m_ActionEmojiData.Init(EAList);
            onSyncEmoteActionEvent.Invoke();
        }

        /// <summary>
        /// 解锁动作表情 ui_actionemoji.lua处理
        /// </summary>
        public void sc_AddEmoteAction(swm.AddEmoteAction Ea)
        {
            m_ActionEmojiData.AddOneAE(Ea.id);
            onAddEmoteActionEvent.Invoke(Ea.id);
        }
       
        /// <summary>
        /// 玩家使用动作表情
        /// </summary>
        /// <param name="id">表情编号</param> <param name="tar">目标 如果没有则为0</param>
        /// 认为使用表情动作的检查都在lua中检查过了
        public void cs_ReqUseEmoteAction(uint id, ulong tar)
        {

#if TESTCODE
            if (m_ActionEmojiData.IsNeedUpdata == true)
            {
                cs_GetEmoteActions();
                return;
            }
#endif
#if SHOWCHECKLOG
            string str = string.Format("请求播放表情动作 entityid={0} id={1} targetid={2}", GameScene.Instance.MainChar.ThisID.ToString(), id.ToString(), tar.ToString());
            LogHelper.Log(str);
#endif
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqUseEmoteAction.StartReqUseEmoteAction(fbb);
            swm.ReqUseEmoteAction.AddId(fbb, id);
            swm.ReqUseEmoteAction.AddTargetid(fbb, tar);
           
            
            var msg = swm.ReqUseEmoteAction.EndReqUseEmoteAction(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUseEmoteAction.HashID, fbb);
        }

        /// <summary>
        /// 询问和玩家互动  别人发送过来互动表情请求 ui_actionemojiregister.lua处理
        /// </summary>
        public void sc_AskUseEmoteAction(swm.AskUseEmoteAction Ea)
        {
            onAskUseEmoteActionEvent.Invoke(Ea.casterid,Ea.id);
#if TESTCODE
            //测试代码
            cs_AskUseEmoteActionResult(true, Ea.casterid, Ea.id);
#endif
        }

        /// <summary>
        /// 询问和玩家互动  询问返回  1 服务器发给询问主客户端  被询问方返回结果 ui_actionemoji.lua处理
        /// </summary>
        public void sc_AskUseEmoteActionResult(swm.AskUseEmoteActionResult Ea)
        {
#if SHOWCHECKLOG
            string str = string.Format("通知询问和玩家互动结果 isok={0} id={1} casterid={2}", Ea.isok.ToString(), Ea.id.ToString(), Ea.casterid.ToString());
            LogHelper.Log(str);// "通知询问和玩家互动结果 isok=" + Ea.isok.ToString() + " id=" + Ea.id.ToString() + " casterid=" + Ea.casterid.ToString());
#endif
            onAskUseEmoteActionResultEvent.Invoke(Ea.isok,Ea.casterid,Ea.id);
        }

        /// <summary>
        /// 询问和玩家互动  询问返回  1被询问方发给服务器询问结果  
        /// </summary>
        public void cs_AskUseEmoteActionResult(bool isok,ulong casterid,uint id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.AskUseEmoteActionResult.StartAskUseEmoteActionResult(fbb);
            swm.AskUseEmoteActionResult.AddIsok(fbb, isok);
            swm.AskUseEmoteActionResult.AddId(fbb, id);
            swm.AskUseEmoteActionResult.AddCasterid(fbb, casterid);
            var msg = swm.AskUseEmoteActionResult.EndAskUseEmoteActionResult(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.AskUseEmoteActionResult.HashID, fbb);
        }

        /// <summary>
        /// 九屏使用表情动作  所有开始播放表情动作 由服务器下发通知 包括自己的 和 看到的别人做动作表情
        /// </summary>
        public void sc_NotifyUseEmoteAction(swm.NotifyUseEmoteAction Ea)
        {
#if SHOWCHECKLOG
            string str = string.Format("sc_NotifyUseEmoteAction 通知播放表情动作 entityid={0} id={1} targetid={2}", Ea.entityid.ToString(), Ea.id.ToString(), Ea.targetid.ToString());
            LogHelper.Log(str);// "通知播放表情动作 entityid=" + Ea.entityid.ToString()+" id="+ Ea.id.ToString() + " targetid=" + Ea.targetid.ToString());
#endif
            if (Ea.entityid<=0)
            {
                //没有动作表情的发起者 有问题
#if SHOWCHECKLOG
                string str2 = string.Format("Error sc_NotifyUseEmoteAction 没有动作表情的发起者 有问题 entityid={0}", Ea.entityid.ToString());
                LogHelper.Log(str2);// "Error sc_NotifyUseEmoteAction 没有动作表情的发起者 有问题 Ea.entityid=" + Ea.entityid.ToString());
#endif
                return;
            }
            //如果动作表情 跟自己相关
            if(Ea.entityid==GameScene.Instance.MainChar.ThisID || Ea.targetid == GameScene.Instance.MainChar.ThisID)  
            {
//                 m_NowUseAEEntityId = Ea.entityid;
                m_NowUseAEId = Ea.id;
//                 m_NowUseAETargetId = Ea.targetid;
            }
            m_ActionEmojiData.AddOnePlayAE(Ea);
            PlayEmoteAction(Ea);
            onNotifyUseEmoteActionEvent.Invoke(Ea.entityid,Ea.id,Ea.targetid);
            
        }

        /// <summary>
        /// 服务器下发打断动作表情
        /// </summary>
        public void sc_BrokenEmoteAction(swm.BrokenEmoteAction Ea)
        {
            StopAcitonEmoji(Ea.entityid);
        }

        /// <summary>
        /// 发送服务器 自己停止动作表情
        /// </summary>
        /// <param name="Ea"></param>
        public void cs_BrokenEmoteAction()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.BrokenEmoteAction.StartBrokenEmoteAction(fbb);
            swm.BrokenEmoteAction.AddEntityid(fbb, GameScene.Instance.MainChar.ThisID);
            var msg = swm.BrokenEmoteAction.EndBrokenEmoteAction(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.BrokenEmoteAction.HashID, fbb);
        }
       


        /// <summary>
        /// 玩家停止使用动作表情
        /// </summary>
        /// <param name="id">表情编号</param>
        public void StopAcitonEmoji(ulong roleid)
        {
#if SHOWCHECKLOG
            string str2 = string.Format(" StopAcitonEmoji 角色结束表情动作 roleid={0}", roleid.ToString());
            LogHelper.Log(str2);
#endif
            if (null != GameScene.Instance.MainChar && roleid == GameScene.Instance.MainChar.ThisID)
            {
                if(Is_PlayEmoteAction==true)
                {
                    //发送服务器 停止使用动作表情
                    cs_BrokenEmoteAction();
                }
                m_NowUseAEId = 0;

            }
            ulong tarroleid = m_ActionEmojiData.ReleasePlayAE(roleid);
            Entity role = GameScene.Instance.GetEntityByID(roleid);
            if (role != null && role.IsCharacter() == true)
            {
                Character character = (Character)role;
                if (character.b_isBeAttachTo == true)
                {
                    character.b_isBeAttachTo = false;
                    tarroleid = character.ul_BeAttachToRoleId;
                    character.ul_BeAttachToRoleId = 0;
                    role.Avatar.AttachTo(null, AvatarAttachment.None, AvatarAttachment.EomteStand);                   
                    character.ul_AttachRoleId = 0;
                    role.SetAvatarPosition();
                }
                character.SetopEmoteStun();

            }
            if (tarroleid>0)
            {
                Entity tarrole = GameScene.Instance.GetEntityByID(tarroleid);
                if (tarrole != null && tarrole.IsCharacter() == true)
                {
                    Character tarcharacter = (Character)tarrole;
                    if (tarcharacter.b_isBeAttachTo == true)
                    {
                        tarcharacter.b_isBeAttachTo = false;
                        tarrole.Avatar.AttachTo(null, AvatarAttachment.None, AvatarAttachment.EomteStand);
                        tarcharacter.ul_AttachRoleId = 0;
                    }
                    tarcharacter.SetAvatarPosition();
                    tarcharacter.SetopEmoteStun();
                }
                
            }

           
        }

        private uint m_NowUseAEId = 0;
//         private ulong m_NowUseAEEntityId = 0;
//         private ulong m_NowUseAETargetId = 0;
        //返回是否正在播放动作表情
        public bool Is_PlayEmoteAction
        {
            get
            {
                return m_NowUseAEId > 0;
            }
        }

        public void DoubleAction(ulong entityA, ulong entityB)
        {
            
        }
        //public void Ui_PlayThisEmoteAction(uint aeid)
        //{
        //    //认为使用表情动作的检查都在lua中检查过了


        //    m_NowUseAEId = aeid;
        //}
        swm.ChatMsgT m_sendChatMsg = new swm.ChatMsgT();

        public void PlayEmoteAction(int emoteid, ulong entityid, ulong targetid)
        {
            EmoteActionTableBase? tConfig = EmoteActionTableManager.GetData(emoteid);
            if (tConfig.HasValue)
            {
                EmoteActionTableBase tValue = tConfig.Value;
                if (entityid > 0)
                {
                    Entity askrole = GameScene.Instance.GetEntityByID(entityid);
                    if (askrole != null && askrole.IsCharacter() == true)
                    {
                        Character character = (Character)askrole;
                        if (character != null)
                        {
                            //对发起者 要注册停止表情动作的结束回调事件


                            //角色播放动作
                            if (string.IsNullOrEmpty(tValue.myactionname) == false)
                            {
                                character.EmoteStun(tValue.myactionname, tValue.interrupttype);
                            }
                            if (targetid > 0)
                            {
                                Entity tarrole = GameScene.Instance.GetEntityByID(targetid);
                                //角色播放气泡
                                if (tarrole && string.IsNullOrEmpty(tValue.speakto) == false)
                                {
                                    string str = string.Format(tValue.speakto, character.Name, tarrole.Name);
                                    //ChatModel.Instance.SendChat(swm.ChatPosType.NEARBY, str,"");
                                    //x2m.ChatMsg _msg = new x2m.ChatMsg();
                                    m_sendChatMsg.target = targetid;
                                    m_sendChatMsg.sendername = character.Name;
                                    m_sendChatMsg.chat_msg = str;
                                    m_sendChatMsg.sponsor = entityid;
                                    m_sendChatMsg.chat_pos = swm.ChatPosType.NEARBY;
                                    ChatModel.Instance.AddChatDataByMsg(m_sendChatMsg, true, true, false);
                                }
                            }
                            else
                            {
                                //角色播放气泡
                                if (string.IsNullOrEmpty(tValue.speak) == false)
                                {
                                    // ChatModel.Instance.SendChat(swm.ChatPosType.NEARBY, tValue.speak,"");
                                    // x2m.ChatMsg _msg = new x2m.ChatMsg();
                                    m_sendChatMsg.target = 0;
                                    m_sendChatMsg.sendername = character.Name;
                                    m_sendChatMsg.chat_msg = tValue.speak;
                                    m_sendChatMsg.sponsor = entityid;
                                    m_sendChatMsg.chat_pos = swm.ChatPosType.NEARBY;
                                    ChatModel.Instance.AddChatDataByMsg(m_sendChatMsg, true, true, false);
                                }
                            }

                        }
                    }
                }
                if (targetid > 0)
                {
                    Entity askrole = GameScene.Instance.GetEntityByID(entityid);
                    Entity asktorole = GameScene.Instance.GetEntityByID(targetid);
                    if (askrole!=null && asktorole != null && asktorole.IsCharacter())  //这里要检查对象是否是玩家
                    {
                        Character character = (Character)asktorole;

                        if (character != null)
                        {


                            //绑定avater到发起者
                            //Character askcharacter = (Character)askrole;
                            if (tValue.type == 3)  //双人动作表情  才绑定到 对方Avatar
                            {

                                character.b_isBeAttachTo = true;
                                character.ul_BeAttachToRoleId = entityid;
                                asktorole.Avatar.AttachToMount(askrole.Avatar, AvatarAttachment.EomteStand, AvatarAttachment.Root, tValue.mountpoint);
                                if (asktorole.Avatar != null && asktorole.Avatar.unityObject)
                                    asktorole.Avatar.unityObject.transform.localPosition = UnityEngine.Vector3.zero;

                                if (askrole != null && askrole.IsCharacter() == true)
                                {
                                    Character askcharacter = (Character)askrole;
                                    askcharacter.ul_AttachRoleId = targetid;

                                }
                            }


                            //角色播放动作
                            if (string.IsNullOrEmpty(tValue.otheractionname) == false)
                            {
                                character.EmoteStun(tValue.otheractionname, tValue.interrupttype);
                            }

                            //    //角色播放气泡
                            //    if (string.IsNullOrEmpty(tValue.otherspeak) == false)
                            //    {

                            //    }
                            //}


                        }
                    }
                }
            }
            else
            {
#if SHOWCHECKLOG
                string str = string.Format("Error PlayEmoteAction 没有动作表情的配置 有问题 Ea.id={0} ",  Ea.id.ToString());
                LogHelper.Log(str);//"Error PlayEmoteAction 没有动作表情的配置 有问题 Ea.id=" + Ea.id.ToString());
#endif
            }

        }

        public void PlayEmoteAction(swm.NotifyUseEmoteAction Ea)
        {
            PlayEmoteAction((int)Ea.id, Ea.entityid, Ea.targetid);
        }


        public void RoleEmoteMove(ulong roleid,bool ismove)
        {
            Entity askrole = GameScene.Instance.GetEntityByID(roleid);
            if(askrole!=null)
            {
                askrole.SetAnimatorParamBool(Bokura.AnimatorParam.EmoteMove, ismove);
            }
          
        }


        #region 测试相关
#if TESTCODE
        [XLua.BlackList]
        public void test_cs_ReqUseEmoteAction()
        {
            ulong tar = 0;
            uint id = 1;
            if (null!=TargetSelector.Instance.Selected)
            {
                tar = TargetSelector.Instance.Selected.ThisID;
                if (tar <= 0)
                {
                    tar = 0;
                }
                else
                {
                    id = 3;
                }
            }
            cs_ReqUseEmoteAction(1, tar);
        }
        [XLua.BlackList]
        public void test_cs_ReqUseEmoteAction(uint id, ulong tar)
        {
            cs_ReqUseEmoteAction(id, tar);
        }
        [XLua.BlackList]
        public void test_OnLockTargetChange(Entity e)
        {
            test_cs_ReqUseEmoteAction();
        }

        [XLua.BlackList]
        public void test_PlayEmote()
        {
            string myactionname = "sayhello";
            int interrupttype = 0;
            GameScene.Instance.MainChar.EmoteStun(myactionname, interrupttype);
        }
        
#endif

        #endregion




    }

}
