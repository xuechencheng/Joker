using System.Collections.Generic;
using swm;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class AirWallManager : ClientSingleton<AirWallManager>
    {

        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SetWorldBlockValid>(ResponseSetWorldBlockValid);

            GameScene.Instance.onEndLoading.AddListener(ProcessOnEndLoading);
            GameScene.Instance.onIntoMap.AddListener(ProcessIntoMap);
            GameScene.Instance.onGameStateChange.AddListener(ProcessGameStateChange);

        }

        public void Clear()
        {
            m_CurrentMapBaseId = 0;
            m_isSceneLoaded = false;
            m_AirWalls?.Clear();
            m_CacheMessage?.Clear();
        }

        private List<SetWorldBlockValid> m_CacheMessage = new List<SetWorldBlockValid>(Bokura.ConstValue.kCap32);

        /// <summary>
        /// 服务器通知更新空气墙状态
        /// </summary>
        /// <param name="msg"></param>
        private void ResponseSetWorldBlockValid(SetWorldBlockValid msg)
        {
            int _mapBaseId = 0;
            if (GameScene.Instance.CurrentIntomapInfo != null)
            {
                swm.IntoMap _msg = GameScene.Instance.CurrentIntomapInfo.Value;
                _mapBaseId = (int)(_msg.map_baseid);
            }
            
            if (! m_isSceneLoaded || msg.mapid != _mapBaseId)
            {
                m_CacheMessage.Add(Utility.CopyFBMsg<SetWorldBlockValid>(msg));
            }
            else
            {
                m_AirWalls.SetAirWallState((int)msg.blockid, msg.state == 1);
            }

#if UNITY_EDITOR
            LogHelper.Log(Utilities.BuildString("id = ", msg.blockid.ToString(), ", state = ", msg.state.ToString()));
#endif
        }

        public class AirWall
        {
            private bool m_isMeshCreated;
            private bool m_Enabled;
            public bool Enabled
            {
                get
                {
                    return m_Enabled;
                }
                set
                {
                    m_Enabled = value;

                    if (m_Enabled)
                    {
                        if (!m_isMeshCreated)
                        {
                            LoadMesh();
                        }
                    }
                    if (m_goAirWall != null)
                    {
                        m_goAirWall.SetActive(m_Enabled);
                    }
                }
            }
            private AirWallAssets.Item m_Config;
            public void Init(AirWallAssets.Item config)
            {
                m_Config = config;
                Enabled = true;
            }
            private GameObject m_goAirWall;
            public void LoadMesh()
            {
               // var childs = m_Config.points;
                //int len = childs.Length;
                //if (len < 2)
                //{
                //    return;
                //}

                m_goAirWall = new GameObject(Utilities.BuildString("mesh_side_", m_Config.baseid.ToString()));

                {
                    Transform trans = m_goAirWall.transform;

                    trans.position = m_Config.position - LayeredSceneLoader.WorldOffset;
                    var meshCollider = m_goAirWall.AddComponent<MeshCollider>();
                    meshCollider.sharedMesh = m_Config.mesh;

                    if (m_Config.matName != null && m_Config.matName != "")
                    {
                        if (!ICameraHelper.Instance.CheckLayerIsOpen(UserLayer.Layer_AirWall))
                        {
                            ICameraHelper.Instance.OpenUserLayer(UserLayer.Layer_AirWall);
                        }

                        var material = ResourceHelper.LoadResourceSync(m_Config.matPath, m_Config.matName, ".mat") as Material;
                        if (material != null)
                        {
                            var meshfilter = m_goAirWall.AddComponent<MeshFilter>();
                            meshfilter.sharedMesh = m_Config.mesh;
                            var meshrender = m_goAirWall.AddComponent<MeshRenderer>();
                            meshrender.sharedMaterial = material;
                        }
                    }

                    m_goAirWall.SetLayerRecursively((int)Bokura.UserLayer.Layer_AirWall);


                    //UnityEngine.Vector3[] vertices;
                    //Vector2[] uv;
                    //Mesh airWallMesh = new Mesh();

                    //vertices = new UnityEngine.Vector3[len * 2];
                    //uv = new Vector2[len * 2];

                    //var triangles = new int[len * 2 * 3 * 2];

                    //for (int i = 0; i < len; i++)
                    //{
                    //    vertices[2 * i].Set(childs[i].x- LayeredSceneLoader.WorldOffset.x, childs[i].y - LayeredSceneLoader.WorldOffset.y, childs[i].z - LayeredSceneLoader.WorldOffset.z);
                    //    vertices[2 * i + 1] = vertices[2 * i] + UnityEngine.Vector3.up * m_Config.height;
                    //    uv[2 * i].Set(i / len, 0);
                    //    uv[2 * i + 1].Set(i / len, 1);

                    //    triangles[12 * i] = 2 * i;
                    //    triangles[12 * i + 1] = (2 * i + 3) % vertices.Length;
                    //    triangles[12 * i + 2] = (2 * i + 1);

                    //    triangles[12 * i + 3] = 2 * i;
                    //    triangles[12 * i + 4] = (2 * i + 2) % vertices.Length;
                    //    triangles[12 * i + 5] = (2 * i + 3) % vertices.Length;
                    //}

                    //airWallMesh.vertices = vertices;
                    //airWallMesh.uv = uv;
                    //airWallMesh.triangles = triangles;

                    //var meshCollider = m_goAirWall.AddComponent<MeshCollider>();
                    //meshCollider.sharedMesh = airWallMesh;

                    //meshCollider.sharedMesh.RecalculateNormals();

                    //// 再创建一个反面的mesh,反转法线及所有三角面的顺序
                    //{
                    //    var mesh2 = Object.Instantiate(meshCollider.sharedMesh);

                    //    var normals = airWallMesh.normals;
                    //    for (int i = 0; i < normals.Length; ++i)
                    //    {
                    //        normals[i] = -normals[i];
                    //    }
                    //    mesh2.normals = normals;

                    //    for (int i = 0; i < triangles.Length; i += 3)
                    //    {
                    //        int temp = triangles[i];
                    //        triangles[i] = triangles[i + 1];
                    //        triangles[i + 1] = temp;
                    //    }
                    //    mesh2.triangles = triangles;

                    //    var meshCollider2 = m_goAirWall.AddComponent<MeshCollider>();
                    //    meshCollider2.sharedMesh = mesh2;
                    //}
                }

                m_goAirWall.SetActive(m_Enabled);

                m_isMeshCreated = true;
            }
            public void Destroy()
            {
                if (m_goAirWall != null)
                {
                    UnityEngine.Object.Destroy(m_goAirWall);
                    m_goAirWall = null;
                }
            }
        }
        public class AirWalls
        {
            private Dictionary<int, AirWall> m_AirWalls = new Dictionary<int, AirWall>(Bokura.ConstValue.kCap32);
            
            public void Clear()
            {
                var iter = m_AirWalls.GetEnumerator();
                while (iter.MoveNext())
                {
                    iter.Current.Value.Destroy();
                }
                m_AirWalls.Clear();
            }
            public void SetAirWallState(int id, bool on)
            {
                AirWall airwall;
                if (m_AirWalls.TryGetValue(id, out airwall))
                {
                    airwall.Enabled = on;
                }
            }
            public void Load(AirWallTableBase airWallTable)
            {
                if(airWallTable != null && airWallTable.m_AirWallAssets != null && airWallTable.m_AirWallAssets.AirWalls != null)
                {
                    int len = airWallTable.m_AirWallAssets.AirWalls.Length;
                    for(int i =0;i < len;i++)
                    {
                        AirWallAssets.Item _config = airWallTable.m_AirWallAssets.AirWalls[i];
                        AirWall airwall = new AirWall();
                        airwall.Init(_config);
                        m_AirWalls.Add(_config.baseid, airwall);
                    }
                }
                

//                 var iter = airWallTable.m_AirWalls.GetEnumerator();
//                 while (iter.MoveNext())
//                 {
//                     var config = iter.Current.Value;
// 
//                     AirWall airwall = new AirWall();
//                     airwall.Init(config);
//                     m_AirWalls.Add(config.AirWallId, airwall);
//                 }
            }
        }

        private AirWalls m_AirWalls = new AirWalls();

        private bool m_isSceneLoaded =false;
        private int m_CurrentMapBaseId = 0;
        void ProcessOnEndLoading()
        {
            if (GameScene.Instance.currState >= GameState.InGame)
            {
                if (GameScene.Instance.CurrentIntomapInfo != null )
                {
                    
                    swm.IntoMap _msg = GameScene.Instance.CurrentIntomapInfo.Value;
                    int _baseId = (int)(_msg.map_baseid);
                    if (m_CurrentMapBaseId != _baseId)
                    {
                        m_AirWalls.Clear();
                        m_CurrentMapBaseId = (int)(_msg.map_baseid);
                        AirWallTableBase airWallTable = AirWallTableManager.Instance.GetData(m_CurrentMapBaseId);

                        m_AirWalls.Load(airWallTable);

                        if (m_CacheMessage.Count > 0)
                        {
                            for (int i = 0; i < m_CacheMessage.Count; ++i)
                            {
                                var msg = m_CacheMessage[i];
                                if (msg.mapid == m_CurrentMapBaseId)
                                {
                                    m_AirWalls.SetAirWallState((int)msg.blockid, msg.state == 1);
                                }
                            }

                            m_CacheMessage.Clear();
                        }
                    }

                }
            }
            m_isSceneLoaded = true;


            //             do
            //             {
            //                 if (GameScene.Instance.CurrentIntomapInfo == null)
            //                 {
            //                     ClearWallData();
            //                     return;
            //                 }
            //                 swm.IntoMap _msg = GameScene.Instance.CurrentIntomapInfo.Value;
            //                 int _mapBaseId = (int)(_msg.map_baseid);
            //                 MapInfoAssets.Item _config = MapInfoTableManager.GetData(_mapBaseId);
            //                 if (_config == null)
            //                 {
            //                     ClearWallData();
            //                     return;
            //                 }
            //                 string name = _config.file;
            //                 int idx = name.LastIndexOf("_baked");
            //                 if (idx > 0)
            //                 {
            //                     name = name.Remove(idx);
            //                 }
            //                 var airWallTable = AirWallTableManager.GetData(name);
            //                 if (airWallTable == null)
            //                 {
            //                     ClearWallData();
            //                     return;
            //                 }
            // 
            //                 m_AirWalls.Clear();
            // 
            //                 m_AirWalls.Load(airWallTable);
            // 
            //                 if (m_CacheMessage.Count > 0)
            //                 {
            //                     for (int i = 0; i < m_CacheMessage.Count; ++i)
            //                     {
            //                         var msg = m_CacheMessage[i];
            //                         if (msg.mapid == _mapBaseId)
            //                         {
            //                             m_AirWalls.SetAirWallState((int)msg.blockid, msg.state == 1);
            //                         }
            //                     }
            // 
            //                     m_CacheMessage.Clear();
            //                 }
            // 
            //                 m_isSceneLoaded = true;
            //                 return;
            //             }
            //             while (false);


        }

        private void ProcessIntoMap(swm.IntoMap _msg)
        {
            ClearWallData();
        }

        private void ProcessGameStateChange(GameState oldState, GameState newState)
        {
            if (GameScene.Instance.CheckIsInGame(oldState, newState))
            {
                ClearWallData();
            }
        }

        private void ClearWallData()
        {
            m_AirWalls.Clear();
            m_CacheMessage.Clear();
            m_isSceneLoaded = false;
        }

    }
}
