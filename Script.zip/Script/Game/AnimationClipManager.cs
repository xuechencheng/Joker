﻿using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class AnimationClipManager : ClientSingleton<AnimationClipManager>
    {
        protected delegate AnimationClip CreateAnimationClip(string key);
        protected Dictionary<string, AnimationClip> clips = new Dictionary<string, AnimationClip>();
        protected Dictionary<string, CreateAnimationClip> createfuns = new Dictionary<string, CreateAnimationClip>();


        public AnimationClipManager()
        {
            createfuns.Add("ui_ani_Bagbuttonanim_less", Create_ui_ani_Bagbuttonanim_less);
        }

        public AnimationClip GetAnimationClip(string key)
        {
            if(!clips.ContainsKey(key))
            {
                if(createfuns.ContainsKey(key))
                {
                    var fun = createfuns[key];
                    if (fun != null)
                    {
                        var clip = fun(key);
                        clips.Add(key, clip);
                        return clip;
                    }
                }else
                {
                    LogHelper.Log("not load animationclip: ", key);
                }
            }else
            {
                return clips[key];
            }
            return null;
        }

        protected AnimationClip Create_ui_ani_Bagbuttonanim_less(string key)
        {
            AnimationClip clip = new AnimationClip();
            clip.legacy = true;
            AnimationCurve curveY = new AnimationCurve();
            curveY.AddKey(new Keyframe(0, 100));
            curveY.AddKey(new Keyframe(0.5f, 150));
            curveY.AddKey(new Keyframe(1, 0));

            AnimationCurve curveX = new AnimationCurve();
            curveX.AddKey(new Keyframe(0, -Screen.width / 2));
            curveX.AddKey(new Keyframe(1, 0));

            AnimationCurve curveactive = AnimationCurve.EaseInOut(0, 1, 1, 0);
            AnimationCurve curvescale = new AnimationCurve();
            curvescale.AddKey(new Keyframe(0.8F, 1));
            curvescale.AddKey(new Keyframe(1f, 0.5f));
            curvescale.AddKey(new Keyframe(1.2f, 1));
            clip.SetCurve("ui_buttoniconpanel", typeof(RectTransform), "m_AnchoredPosition.y", curveY);
            clip.SetCurve("ui_buttoniconpanel", typeof(RectTransform), "m_AnchoredPosition.x", curveX);
            clip.SetCurve("ui_buttoniconpanel", typeof(GameObject), "m_IsActive", curveactive);
            clip.SetCurve("btn_bag", typeof(Transform), "localScale.x", curvescale);
            clip.SetCurve("btn_bag", typeof(Transform), "localScale.y", curvescale);
            clip.SetCurve("btn_bag", typeof(Transform), "localScale.z", curvescale);
            return clip; 
        }


    }
}
