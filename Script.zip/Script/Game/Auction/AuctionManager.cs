﻿using System.Collections.Generic;
using Bokura;
using System.IO;
using UnityEngine;
using FlatBuffers;
using swm;

namespace Bokura
{
    public class AuctionManager : ClientSingleton<AuctionManager>
    {

        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<RspTradeByIdList>(ProcRspTradeByIdList);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTradeItem>(ProcRspTradeItem);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSelfTradeList>(ProcRspSelfTradeList);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTradeByIdAndPage>(ProcRspTradeByIdAndPage);
            MsgDispatcher.instance.RegisterFBMsgProc<RspBuyTradeItem>(ProcRspBuyTradeItem);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTakeDownTradeItem>(ProcRspTakeDownTradeItem);
            MsgDispatcher.instance.RegisterFBMsgProc<RspStoreUpTradeItem>(ProcRspStoreUpTradeItem);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCancelStoreUpTradeItem>(ProcRspCancelStoreUpTradeItem);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSelfStoreUpTradeList>(ProcRspSelfStoreUpTradeList);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTradeRecordList>(ProcRspTradeRecordList);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTradeItemRecommend>(ProcRspTradeItemRecommend);
            MsgDispatcher.instance.RegisterFBMsgProc<RspAllTradeNoticeByPage>(ProcRspAllTradeNoticeByPage);
            MsgDispatcher.instance.RegisterFBMsgProc<RspAuctionOfferPrice>(ProcRspAuctionOfferPrice);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTradeVerifyList>(ProcRspTradeVerifyList);
        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
        {

        }




        /// <summary>
        /// （大退/小退）清理缓存
        /// </summary>
        public void Clear()
        {
            m_ShopNormalAuctionPageList.Clear();

            m_ShopSpecAuctionPageList.Clear();

            m_SearchList.Clear();

            m_SimpleSearchDic.Clear();

            m_ResultList.Clear();

            if (m_SelfSellList != null)
                m_SelfSellList.Clear();

            if (m_CollectList != null)
                m_CollectList.Clear();

            if (m_AuctionHistoryList != null)
                m_AuctionHistoryList.Clear();

            if (m_VerifyList != null)
                m_VerifyList.Clear();
        }

        enum AuctionID
        {
            Normal = 0,
            Spec,
        }

        private List<TradeTagTableBase> m_ShopNormalAuctionPageList = new List<TradeTagTableBase>(30);//灵宝页签
        private List<TradeTagTableBase> m_ShopSpecAuctionPageList = new List<TradeTagTableBase>(30);//仙宝页签

        private List<uint> m_SearchList = new List<uint>(30);//搜索列表
        private Dictionary<uint, uint> m_SimpleSearchDic = new Dictionary<uint, uint>(50);//搜索简单反馈表
        private List<AuctionSellItem> m_ResultList = new List<AuctionSellItem>(12);//搜索结果列表 
        private List<AuctionSellItem> m_SelfSellList = null;//上架列表
        private List<AuctionSellItem> m_CollectList = null;//收藏列表
        private List<AuctionHistoryItem> m_AuctionHistoryList = null;//交易历史
        private List<ClientVerifyData> m_VerifyList = null;


        int filtertype = 0;

        public int FilterType
        {
            get
            {
                return filtertype;
            }

            set
            {
                filtertype = value;
            }
        }

        int filterlevel = 1;

        public int FilterLevel
        {
            get
            {
                return filterlevel;
            }

            set
            {
                filterlevel = value;
            }
        }

        int filterquality = 1;

        public int FilterQuality
        {
            get
            {
                return filterquality;
            }

            set
            {
                filterquality = value;
            }
        }


        public List<ClientVerifyData> VerifyList
        {
            get
            {
                return m_VerifyList;
            }
        }

        private uint m_MaxPage = 0;

        public uint MaxPage
        {
            get
            {
                return m_MaxPage;
            }
        }

        public List<AuctionHistoryItem> AuctionHistoryList
        {
            get
            {
                return m_AuctionHistoryList;
            }
        }

        public List<AuctionSellItem> CollectList
        {
            get
            {
                return m_CollectList;
            }
        }

        public Dictionary<uint, uint> SimpleSearchDic
        {
            get
            {
                return m_SimpleSearchDic;
            }
        }

        public List<uint> SearchList
        {
            get
            {
                return m_SearchList;
            }
        }

        public List<AuctionSellItem> ResultList
        {
            get
            {
                return m_ResultList;
            }
        }

        public List<AuctionSellItem> SelfSellList
        {
            get
            {
                return m_SelfSellList;
            }
        }

        public List<TradeTagTableBase> ShopNormalAuctionPageList
        {
            get
            {
                if (m_ShopNormalAuctionPageList.Count == 0)
                {

                    int len = TradeTagTableManager.Instance.m_DataList.TradeTagTableLength;
                    for (int i = 0; i < len; ++i)
                    {
                        var data = TradeTagTableManager.Instance.m_DataList.TradeTagTable(i);
                        if ((data.Value.showtag & 1<<(int)AuctionID.Normal) > 0)
                        {
                            m_ShopNormalAuctionPageList.Add(data.Value);

                        }
                    }
                }
                return m_ShopNormalAuctionPageList;
            }
        }

        public List<TradeTagTableBase> ShopSpecAuctionPageList
        {
            get
            {
                if (m_ShopSpecAuctionPageList.Count == 0)
                {
                    int len = TradeTagTableManager.Instance.m_DataList.TradeTagTableLength;
                    for (int i = 0; i < len; ++i)
                    {
                        var data = TradeTagTableManager.Instance.m_DataList.TradeTagTable(i);
                        if ((data.Value.showtag & 1<<(int)AuctionID.Spec) > 0)
                        {
                            m_ShopSpecAuctionPageList.Add(data.Value);

                        }
                    }
                }
                return m_ShopSpecAuctionPageList;
            }
        }

        //寄售物品
        public AuctionSellItem GetSelfSaleItem(ulong _id)
        {
            if (m_SelfSellList == null)
                return null;
            int len = m_SelfSellList.Count;
            for (int i = 0; i < len; ++i)
            {
                if (m_SelfSellList[i].TradeID == _id)
                    return m_SelfSellList[i];
            }
            return null;
        }

        //是否收藏物品
        public bool IsCollectItem(ulong _id)
        {
            if (m_CollectList == null)
                return false;
            int len = m_CollectList.Count;
            for (int i = 0; i < len; ++i)
            {
                if (m_CollectList[i].TradeID == _id)
                    return true;
            }
            return false;
        }

        //灵宝
        public TradeTagTableBase? GetShopNormalAuctionPageDataById(ulong _id)
        {
            int len = m_ShopNormalAuctionPageList.Count;
            for (int i = 0; i < len; ++i)
            {
                if (m_ShopNormalAuctionPageList[i].id == (int)_id)
                    return m_ShopNormalAuctionPageList[i];
            }
            return null;
        }
        //end灵宝

        //仙宝
        public TradeTagTableBase? GetShopSpecAuctionPageDataById(ulong _id)
        {
            int len = m_ShopSpecAuctionPageList.Count;
            for (int i = 0; i < len; ++i)
            {
                if (m_ShopSpecAuctionPageList[i].id == (int)_id)
                    return m_ShopSpecAuctionPageList[i];
            }
            return null;
        }
        //end仙宝

        /// <summary>
        /// 根据页签建立检索表
        /// </summary>
        public void CreateSearchList(uint _pageId, uint _spec)
        {
            m_SearchList.Clear();
            int length = ItemTableManager.Instance.m_DataList.ItemTableLength;
            for (int i = 0; i < length; ++i)
            {
                var data = ItemTableManager.Instance.m_DataList.ItemTable(i);
                if (data.Value.tag_id != _pageId)
                    continue;
                if (_spec == 1 && data.Value.is_mostvalue != _spec)
                    continue;

                if (filterquality > data.Value.quality)
                    continue;

                if (filterlevel > data.Value.needlevel)
                    continue;

                if (filtertype != 0)
                {
                    EquipTableBase? equip = EquipTableManager.GetData(data.Value.id);
                    if (equip != null)
                    {
                        if (filtertype != equip.Value.equip_slot)
                        {
                            if (filtertype != 2)
                                continue;
                            else if (equip.Value.equip_slot > 2)
                                continue;
                        }
                    }
                }

                m_SearchList.Add((uint)data.Value.id);
            }
        }

        public void CreateSearchList(string _name, uint _spec)
        {
            m_SearchList.Clear();
            int length = ItemTableManager.Instance.m_DataList.ItemTableLength;
            for (int i = 0; i < length; ++i)
            {
                var data = ItemTableManager.Instance.m_DataList.ItemTable(i);
                if (data.Value.tag_id == 0)
                    continue;
                if (_spec == 1 && data.Value.is_mostvalue != _spec)
                    continue;

                if (filterquality > data.Value.quality)
                    continue;

                if (filterlevel > data.Value.needlevel)
                    continue;

                if (filtertype != 0)
                {
                    EquipTableBase? equip = EquipTableManager.GetData(data.Value.id);
                    if (equip != null)
                    {
                        if (filtertype != equip.Value.equip_slot)
                        {
                            if (filtertype != 2)
                                continue;
                            else if (equip.Value.equip_slot > 2)
                                continue;
                        }
                    }
                }

                if (!data.Value.name.Contains(_name))
                    continue;
                m_SearchList.Add((uint)data.Value.id);
            }
        }


        public GameEvent onTradeIdListChanged = new GameEvent();//拍卖物品数量数据变化
        public GameEvent<int> onSelfTradeListChanged = new GameEvent<int>();//寄售物品变化
        public GameEvent<int> onTradeItemPageChanged = new GameEvent<int>();//寄售物品页数变化
        public GameEvent<int> onCollectItemChanged = new GameEvent<int>();//收藏物品变化
        public GameEvent onHistoryItemChanged = new GameEvent();//交易历史变化
        public GameEvent<ulong> onTradeItemRecommend = new GameEvent<ulong>();//物品的推荐价格
        public GameEvent onTradeVerifyList = new GameEvent();//审核列表

        /// <summary>
        /// 服务器通知拍卖物品的数量数据
        /// </summary>
        private void ProcRspTradeByIdList(RspTradeByIdList msg)
        {
            m_SimpleSearchDic.Clear();
            int len = msg.trade_listLength;
            for (int i = 0; i < len; ++i)
            {
                m_SimpleSearchDic[msg.trade_list(i).Value.baseid] = msg.trade_list(i).Value.cur_num;
            }
            onTradeIdListChanged.Invoke();
        }

        /// <summary>
        /// 服务器通知寄售返回的数据
        /// </summary>
        private void ProcRspTradeItem(RspTradeItem msg)
        {
            if (m_SelfSellList == null)
                m_SelfSellList = new List<AuctionSellItem>(8);

            AuctionSellItem item = new AuctionSellItem();
            item.TradeType = msg.tradetype;
            item.Init(msg.selfinfo.Value);
            m_SelfSellList.Add(item);
            onSelfTradeListChanged.Invoke(1);
        }

        /// <summary>
        /// 服务器通知自己的寄售数据
        /// </summary>
        private void ProcRspSelfTradeList(RspSelfTradeList msg)
        {
            if (m_SelfSellList == null)
                m_SelfSellList = new List<AuctionSellItem>(8);
            else
                m_SelfSellList.Clear();
            int len = msg.trade_listLength;
            
            for (int i = 0; i < len; ++i)
            {
                AuctionSellItem item = new AuctionSellItem();
                item.TradeType = msg.tradetype;
                item.Init(msg.trade_list(i).Value);
                m_SelfSellList.Add(item);
            }
            onSelfTradeListChanged.Invoke(0);
        }

        /// <summary>
        /// 服务器通知物品的列表信息
        /// </summary>
        private void ProcRspTradeByIdAndPage(RspTradeByIdAndPage msg)
        {
            int len = msg.trade_listLength;
            m_ResultList.Clear();
            m_MaxPage = msg.maxpage;
            for (int i = 0; i < len; ++i)
            {
                AuctionSellItem item = new AuctionSellItem();
                item.TradePos = msg.pos;
                item.Init(msg.trade_list(i).Value);
                m_ResultList.Add(item);
            }

            // 购买列表
            onTradeItemPageChanged.Invoke(1);
        }

        /// <summary>
        /// 返回购买的结果
        /// </summary>
        private void ProcRspBuyTradeItem(RspBuyTradeItem msg)
        {
            if (msg.result == TradeResult.Success)
            {
                //购买返回
                if (m_CollectList != null)
                {
                    for (int i = 0; i < m_CollectList.Count; ++i)
                    {
                        if (m_CollectList[i].TradeID == msg.tradeidx)
                        {
                            m_CollectList.RemoveAt(i);
                            break;
                        }
                    }
                }


                onTradeItemPageChanged.Invoke(2);
            }
        }

        /// <summary>
        /// 返回下架的结果
        /// </summary>
        private void ProcRspTakeDownTradeItem(RspTakeDownTradeItem msg)
        {
            int len = m_SelfSellList.Count;
            for (int i = 0; i < len; ++i)
            {
                if (m_SelfSellList[i].TradeID == msg.tradeidx)
                {
                    m_SelfSellList.Remove(m_SelfSellList[i]);
                    break;
                }
            }
            onSelfTradeListChanged.Invoke(2);
        }

        /// <summary>
        /// 返回收藏的结果
        /// </summary>
        private void ProcRspStoreUpTradeItem(RspStoreUpTradeItem msg)
        {
            if (m_CollectList == null)
                m_CollectList = new List<AuctionSellItem>(12);

            AuctionSellItem item = new AuctionSellItem();
            item.Init(msg.storeitem.Value);
            m_CollectList.Add(item);
            onCollectItemChanged.Invoke(1);
        }

        /// <summary>
        /// 返回取消收藏的信息
        /// </summary>
        private void ProcRspCancelStoreUpTradeItem(RspCancelStoreUpTradeItem msg)
        {
            int len = m_CollectList.Count;
            for (int i = 0; i < len; ++i)
            {
                if (m_CollectList[i].TradeID == msg.tradeidx)
                {
                    m_CollectList.Remove(m_CollectList[i]);
                    break;
                }
            }
            onCollectItemChanged.Invoke(2);
        }

        /// <summary>
        /// 返回客户端的收藏列表
        /// </summary>
        private void ProcRspSelfStoreUpTradeList(RspSelfStoreUpTradeList msg)
        {
            if (m_CollectList == null)
                m_CollectList = new List<AuctionSellItem>(12);
            else
                m_CollectList.Clear();
            int len = msg.storelistLength;

            for (int i = 0; i < len; ++i)
            {
                AuctionSellItem item = new AuctionSellItem();
                item.TradeType = msg.tradetype;
                item.Init(msg.storelist(i).Value);
                m_CollectList.Add(item);
            }

            onCollectItemChanged.Invoke(0);
        }

        /// <summary>
        /// 返回客户端的历史记录列表
        /// </summary>
        private void ProcRspTradeRecordList(RspTradeRecordList msg)
        {
            if (m_AuctionHistoryList == null)
                m_AuctionHistoryList = new List<AuctionHistoryItem>(40);
            else
                m_AuctionHistoryList.Clear();
            int len = msg.buylistLength;

            for (int i = 0; i < len; ++i)
            {
                AuctionHistoryItem item = new AuctionHistoryItem();
                item.Name = msg.buylist(i).Value.itemname;
                item.Num = msg.buylist(i).Value.tradenum;
                item.Price = msg.buylist(i).Value.allprice;
                item.Type = 0;
                m_AuctionHistoryList.Add(item);
            }

            len = msg.selllistLength;

            for (int i = 0; i < len; ++i)
            {
                AuctionHistoryItem item = new AuctionHistoryItem();
                item.Name = msg.selllist(i).Value.itemname;
                item.Num = msg.selllist(i).Value.tradenum;
                item.Price = msg.selllist(i).Value.allprice;
                item.Type = 1;
                m_AuctionHistoryList.Add(item);
            }

            onHistoryItemChanged.Invoke();
        }
        /// <summary>
        /// 返回客户端的历史记录列表
        /// </summary>   
        private void ProcRspTradeItemRecommend(RspTradeItemRecommend msg)
        {
            onTradeItemRecommend.Invoke(msg.recommprice);
        }

        /// <summary>
        /// 返回物品的列表信息
        /// </summary>   
        private void ProcRspAllTradeNoticeByPage(RspAllTradeNoticeByPage msg)
        {
            int len = msg.trade_listLength;
            m_ResultList.Clear();
            m_MaxPage = msg.maxpage;
            for (int i = 0; i < len; ++i)
            {
                AuctionSellItem item = new AuctionSellItem();
                item.TradePos = msg.pos;
                item.Init(msg.trade_list(i).Value);
                m_ResultList.Add(item);
            }
            if (msg.pos == TradePos.Auction)
                onTradeItemPageChanged.Invoke(1);
            else
                onTradeItemPageChanged.Invoke(3);//全部页签


        }

        /// <summary>
        /// 返回客户端拍卖出价
        /// </summary>   
        private void ProcRspAuctionOfferPrice(RspAuctionOfferPrice msg)
        {
            if (msg.result == TradeResult.Success)
            {
                int len = m_ResultList.Count;
                for (int i = 0; i < len; ++i)
                {
                    if (m_ResultList[i].TradeID == msg.tradeidx)
                    {
                        m_ResultList[i].AuctionData.auctioncharid = msg.charid;
                        m_ResultList[i].AuctionData.currauctprice = msg.offerprice;
                    }
                }

                if (m_CollectList != null)
                {
                    len = m_CollectList.Count;
                    for (int i = 0; i < len; ++i)
                    {
                        if (m_CollectList[i].TradeID == msg.tradeidx)
                        {
                            m_CollectList[i].AuctionData.auctioncharid = msg.charid;
                            m_CollectList[i].AuctionData.currauctprice = msg.offerprice;
                        }
                    }
                }

                onTradeItemPageChanged.Invoke(1);
            }

        }

        /// <summary>
        /// 返回客户端审核列表
        /// </summary>   
        private void ProcRspTradeVerifyList(RspTradeVerifyList msg)
        {
            if (m_VerifyList == null)
                m_VerifyList = new List<ClientVerifyData>(20);
            else
                m_VerifyList.Clear();
            m_MaxPage = msg.maxpage;
            int len = msg.verifylistLength;
            for (int i = 0; i < len; ++i)
            {
                m_VerifyList.Add(msg.verifylist(i).Value);
            }
            onTradeVerifyList.Invoke();
        }


        //发送网络消息
        /// <summary>
        /// 发送 请求寄售物品
        /// </summary>
        SellInfoT mSellinfo = new SellInfoT();
        ReqTradeItemT mReqTradeItem = new ReqTradeItemT();
        public void SendReqTradeItem(ulong _itemid, uint _num, ulong _price, ulong _oneprice, uint _type)
        {
            mSellinfo.itemidx = _itemid;
            mSellinfo.sellnum = _num;
            mSellinfo.tradetype = (TradeType)_type;
            if (mSellinfo.tradetype == TradeType.Stall)
            {
                mSellinfo.unitprice = _price;
            }
            else
            {
                mSellinfo.unitprice = _oneprice;
                mSellinfo.auctionprice = _price;
            }

            mReqTradeItem.sellinfo = mSellinfo;

            MsgDispatcher.instance.SendFBPackage(mReqTradeItem);
        }

        /// <summary>
        /// 发送 请求我出售物品的列表
        /// </summary>
        public void SendReqSelfTradeList(int _type)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqSelfTradeList.StartReqSelfTradeList(fbb);
            ReqSelfTradeList.AddTradetype(fbb, (TradeType)_type);
            ReqSelfTradeList.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqSelfTradeList.EndReqSelfTradeList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqSelfTradeList.HashID, fbb);

        }

        /// <summary>
        /// 发送 按照物品ID请求对应的出售数量
        /// </summary>
        /// 
        ReqTradeByIdListT mReqTradeByIdList = new ReqTradeByIdListT();
        public void SendReqTradeByIdList(uint _state, int _page)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;

            mReqTradeByIdList.charid = tChar.ThisID;
            mReqTradeByIdList.pos = (TradePos)_state;

            int len = m_SearchList.Count;
            if (len==0)
            {
                m_SimpleSearchDic.Clear();
                onTradeIdListChanged.Invoke();
                return;
            }

            int curLen = _page * 12;
            if (curLen + 12 < len)
                len = curLen + 12;

            List<uint> idl = new List<uint>(len);
            for (int i = curLen; i < len; ++i)
            {
                idl.Add(m_SearchList[i]);
            }

            mReqTradeByIdList.id_list = idl;

            MsgDispatcher.instance.SendFBPackage(mReqTradeByIdList);

        }

        /// <summary>
        /// 发送 请求具体的交易信息
        /// </summary>
        public void SendReqTradeByIdAndPage(uint _state, uint _id, uint _page)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqTradeByIdAndPage.StartReqTradeByIdAndPage(fbb);
            ReqTradeByIdAndPage.AddBaseid(fbb, _id);
            ReqTradeByIdAndPage.AddPos(fbb, (TradePos)_state);
            ReqTradeByIdAndPage.AddStartpage(fbb, _page);
            ReqTradeByIdAndPage.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqTradeByIdAndPage.EndReqTradeByIdAndPage(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqTradeByIdAndPage.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求购买物品
        /// </summary>
        public void SendReqBuyTradeItem(uint _tradeid, uint _itemid, uint _num)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqBuyTradeItem.StartReqBuyTradeItem(fbb);
            ReqBuyTradeItem.AddBaseid(fbb, _itemid);
            ReqBuyTradeItem.AddBuynum(fbb, _num);
            ReqBuyTradeItem.AddTradeidx(fbb, _tradeid);
            ReqBuyTradeItem.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqBuyTradeItem.EndReqBuyTradeItem(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqBuyTradeItem.HashID, fbb);
        }

        /// <summary>
        /// 客户端请求下架物品
        /// </summary>
        public void SendReqTakeDownTradeItem(uint _tradeid)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqTakeDownTradeItem.StartReqTakeDownTradeItem(fbb);
            ReqTakeDownTradeItem.AddTradeidx(fbb, _tradeid);
            ReqTakeDownTradeItem.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqTakeDownTradeItem.EndReqTakeDownTradeItem(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqTakeDownTradeItem.HashID, fbb);
        }

        /// <summary>
        /// 客户端请求收藏某个物品
        /// </summary>
        public void SendReqStoreUpTradeItem(uint _tradeid)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqStoreUpTradeItem.StartReqStoreUpTradeItem(fbb);
            ReqStoreUpTradeItem.AddTradeidx(fbb, _tradeid);
            ReqStoreUpTradeItem.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqStoreUpTradeItem.EndReqStoreUpTradeItem(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqStoreUpTradeItem.HashID, fbb);

        }

        /// <summary>
        /// 客户端取消收藏某个物品
        /// </summary>
        public void SendReqCancelStoreUpTradeItem(uint _tradeid, uint _type)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqCancelStoreUpTradeItem.StartReqCancelStoreUpTradeItem(fbb);
            ReqCancelStoreUpTradeItem.AddTradetype(fbb, (TradeType)_type);
            ReqCancelStoreUpTradeItem.AddTradeidx(fbb, _tradeid);
            ReqCancelStoreUpTradeItem.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqCancelStoreUpTradeItem.EndReqCancelStoreUpTradeItem(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqCancelStoreUpTradeItem.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求自己的收藏列表
        /// </summary>
        public void SendReqSelfStoreUpTradeList(uint _type)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqSelfStoreUpTradeList.StartReqSelfStoreUpTradeList(fbb);
            ReqSelfStoreUpTradeList.AddTradetype(fbb, (TradeType)_type);
            ReqSelfStoreUpTradeList.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqSelfStoreUpTradeList.EndReqSelfStoreUpTradeList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqSelfStoreUpTradeList.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求历史记录
        /// </summary>
        public void SendReqTradeRecordList(uint _type)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqTradeRecordList.StartReqTradeRecordList(fbb);
            ReqTradeRecordList.AddTradetype(fbb, (TradeType)_type);
            ReqTradeRecordList.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqTradeRecordList.EndReqTradeRecordList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqTradeRecordList.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求物品的推荐价格
        /// </summary>
        public void SendReqTradeItemRecommend(uint _type, uint _itemid)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqTradeItemRecommend.StartReqTradeItemRecommend(fbb);
            ReqTradeItemRecommend.AddTradetype(fbb, (TradeType)_type);
            ReqTradeItemRecommend.AddItemid(fbb, _itemid);
            ReqTradeItemRecommend.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqTradeItemRecommend.EndReqTradeItemRecommend(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqTradeItemRecommend.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求物品的推荐价格
        /// </summary>
        public void SendReqAllTradeNoticeByPage(uint _type, uint _startpage)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqAllTradeNoticeByPage.StartReqAllTradeNoticeByPage(fbb);
            ReqAllTradeNoticeByPage.AddPos(fbb, (TradePos)_type);
            ReqAllTradeNoticeByPage.AddStartpage(fbb, _startpage);
            ReqAllTradeNoticeByPage.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqAllTradeNoticeByPage.EndReqAllTradeNoticeByPage(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqAllTradeNoticeByPage.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求拍卖出价
        /// </summary>
        public void SendReqAuctionOfferPrice(uint _price, uint _id)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqAuctionOfferPrice.StartReqAuctionOfferPrice(fbb);
            ReqAuctionOfferPrice.AddOfferprice(fbb, _price);
            ReqAuctionOfferPrice.AddTradeidx(fbb, _id);
            ReqAuctionOfferPrice.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqAuctionOfferPrice.EndReqAuctionOfferPrice(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqAuctionOfferPrice.HashID, fbb);

        }

        /// <summary>
        /// 客户端请求拍卖出价
        /// </summary>
        public void SendReqTradeVerifyList(uint _page, uint _tradetype)
        {
            MainCharacter tChar = GameScene.Instance.MainChar;
            if (tChar == null)
                return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            ReqTradeVerifyList.StartReqTradeVerifyList(fbb);
            ReqTradeVerifyList.AddStartpage(fbb, _page);
            ReqTradeVerifyList.AddTradetype(fbb, (TradeType)_tradetype);
            ReqTradeVerifyList.AddCharid(fbb, tChar.ThisID);
            fbb.Finish(ReqTradeVerifyList.EndReqTradeVerifyList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(ReqTradeVerifyList.HashID, fbb);

        }

        
    }

    /// <summary>
    /// 拍卖历史记录
    /// </summary>
    public struct AuctionHistoryItem
    {
        /// <summary>
        /// 类型
        /// </summary>
        public int Type;

        /// <summary>
        /// 名字
        /// </summary>
        public string Name;

        /// <summary>
        /// 数量
        /// </summary>
        public uint Num;

        /// <summary>
        /// 价格
        /// </summary>
        public ulong Price;
    }

    /// <summary>
    /// 拍卖道具
    /// </summary>
    public class AuctionSellItem
    {

        /// <summary>
        /// 商店类型
        /// </summary>
        public TradeType TradeType;

        /// <summary>
        /// 拍卖ID
        /// </summary>
        public ulong TradeID;

        /// <summary>
        /// 出售数量
        /// </summary>
        public uint SellNum;

        /// <summary>
        /// 出售单价
        /// </summary>
        public ulong Price;

        /// <summary>
        /// 物品详细信息
        /// </summary>
        public ItemBase DetailInfo;

        /// <summary>
        /// 页数
        /// </summary>
        public int PageID = -1;

        /// <summary>
        /// 卖家ID
        /// </summary>
        public ulong OwnerID;

        /// <summary>
        /// 卖家名
        /// </summary>
        public string OwnerName;

        /// <summary>
        /// 物品状态
        /// </summary>
        public TradePos TradePos;

        /// <summary>
        /// 拍卖状态
        /// </summary>
        public AuctionDataT AuctionData;

        /// <summary>
        /// 拍卖剩余时间
        /// </summary>
        public ulong LeftTime;

        public bool IsAuction()
        {
            if (AuctionData != null)
            {
                if (AuctionData.auctioncharid != 0)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// 根据服务器信息初始化
        /// </summary>
        public void Init(SelfTradeData tradeInfo)
        {
            TradeID = tradeInfo.tradeidx;
            SellNum = tradeInfo.sellnum;
            Price = tradeInfo.unitprice;
            AuctionData = new AuctionDataT(tradeInfo.auctdata.Value);
            TradePos = tradeInfo.pos;
            LeftTime = GameScene.Instance.GetServerTime()/1000 + tradeInfo.lefttime;
            ByteBuffer buff = new ByteBuffer(tradeInfo.GetExpanddataArray());
            ItemData data = ItemData.GetRootAsItemData(buff);
            DetailInfo = new ItemBase();
            ItemTableBase? tableInfo = ItemTableManager.GetData((int)data.baseid);
            DetailInfo.Init(tableInfo.Value, data);

        }

        public void Init(PubTradeData tradeInfo)
        {
            OwnerID = tradeInfo.charid;
            OwnerName = tradeInfo.charname;
            TradeID = tradeInfo.tradeidx;
            SellNum = tradeInfo.sellnum;
            Price = tradeInfo.unitprice;
            AuctionData = new AuctionDataT(tradeInfo.auctdata.Value);
            LeftTime = GameScene.Instance.GetServerTime() / 1000 + tradeInfo.lefttime;

            ByteBuffer buff = new ByteBuffer(tradeInfo.GetExpanddataArray());
            ItemData data = ItemData.GetRootAsItemData(buff);
            DetailInfo = new ItemBase();
            ItemTableBase? tableInfo = ItemTableManager.GetData((int)data.baseid);
            DetailInfo.Init(tableInfo.Value, data);
        }

        public void Init(StoreTradeData tradeInfo)
        {
            TradePos = tradeInfo.pos;
            OwnerID = tradeInfo.charid;
            OwnerName = tradeInfo.charname;
            TradeID = tradeInfo.tradeidx;
            SellNum = tradeInfo.sellnum;
            Price = tradeInfo.unitprice;
            AuctionData = new AuctionDataT(tradeInfo.auctdata.Value);
            LeftTime = GameScene.Instance.GetServerTime() / 1000 + tradeInfo.lefttime;

            ByteBuffer buff = new ByteBuffer(tradeInfo.GetExpanddataArray());
            ItemData data = ItemData.GetRootAsItemData(buff);
            DetailInfo = new ItemBase();
            ItemTableBase? tableInfo = ItemTableManager.GetData((int)data.baseid);
            DetailInfo.Init(tableInfo.Value, data);
        }
    }
}
