﻿using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 匹配状态
    /// </summary>
    public enum MatchState
    {
        None        = 0,    //空闲
        Matching    = 1,    //匹配中
        Entering    = 2,    //可以进入
    }



    /// <summary>
    /// 战场战斗结果
    /// </summary>
    public enum BattleFieldOutCome
    {
        /// <summary>
        /// 胜利
        /// </summary>
        Win = 0,
        /// <summary>
        /// 平局
        /// </summary>
        Draw = 1,
        /// <summary>
        /// 失败
        /// </summary>
        Fail = 2,
    }



	public class BattleFieldManager : ClientSingleton<BattleFieldManager>
	{
        /// <summary>
        /// 匹配类型
        /// </summary>
        private enum MatchType
        {
            None    = 0,        //未知
            Single  = 1,        //单人
            Team    = 2,        //组队
        }



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyUserMatchStart>(ResponseUserMatchStart_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyTeamBattleMatchFailed>(ResponseNotifyTeamBattleMatchFailed_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.ResCancelBattleMatch>(ResponseCancelBattleMatch_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleReady>(ResponseNotifyBattleReady_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleOver>(ResponseNotifyBattleOver_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleCampScore>(ResponseNotifyBattleScore_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleState>(ResponseNotifyBattleState_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyCreateFlag>(ResponseNotifyCreateFlag_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.RspExitBattle>(ResponseExitBattle_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyStartBattleVote>(ResponseNotifyStartBattleVote_CS);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleVoteStatus>(ResponseNotifyBattleVoteStatus_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleVoteResult>(ResponseNotifyBattleVoteResult_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyLastVoteTime>(ResponseNotifyLastVoteTime_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.ResOpenAirDrop>(ResponseOpenAirDrop_SC);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.ResPickItemInAirDrop>(ResponsePickItemInAirDrop_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ResBattleWeekWins>(ResponseBattleWeekWins_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyPVPState>(ResponseNotifyPVPState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyBattleWaitStartTime>(ResponseNotifyBattleWaitStartTime);
            
        }



        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {
            m_SingleEnrollRequestTimeStamp  = 0;
            m_TeamEnrollRequestTimeStamp    = 0;
            m_CancelRequestTimeStamp        = 0;
            m_MatchType                     = MatchType.None;
            m_MatchState                    = MatchState.None;
            m_EnqueueTimeStamp              = 0;
            m_NotifyEnterTimeStamp          = 0;
            m_QuitRequestTimeStamp          = 0;
            m_BattleFieldStartTimeStamp     = 0;
            m_BattleFieldDuration           = 0;
            m_BattleVoteStartTimeStamp      = 0;
            m_IsInBattleField               = false;
            m_VoteStatus                    = default(BattleVoteStatus);
            m_OutCome                       = BattleFieldOutCome.Win;

            m_TeamMatchCheckResults?.Clear();
            m_CampScores?.Clear();
            m_BattleResults?.Clear();
            m_AwardInfosMap?.Clear();
        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
			BattleFieldTableManager.Load();
			m_ItemBag = BagManager.Instance.GetBagByType(swm.BagType.Battle).Item_Manager;
		}



        /// <summary>
        /// 是否正在战场匹配或战场中
        /// </summary>
        public bool isBusy
        {
            get { return isInBattleField || m_MatchState != MatchState.None; }
        }



		#region 报名流程的变量、属性和事件

		/// <summary>
		/// 请求单人匹配的时间戳（0表示无请求或已响应）
		/// </summary>
		private ulong m_SingleEnrollRequestTimeStamp = 0;



		/// <summary>
		/// 请求组队匹配的时间戳（0表示无请求或已响应）
		/// </summary>
		private ulong m_TeamEnrollRequestTimeStamp = 0;



		/// <summary>
		/// 请求取消匹配的时间戳（0表示无请求或已响应）
		/// </summary>
		private ulong m_CancelRequestTimeStamp = 0;



		/// <summary>
		/// 超时时间
		/// </summary>
		private const ulong kTimeOut = 1000;



		private MatchType m_MatchType =  MatchType.None;
		/// <summary>
		/// 报名类型
		/// </summary>
		public int matchType { get { return (int)m_MatchType; } }



		private MatchState m_MatchState = MatchState.None;
		/// <summary>
		/// 报名状态
		/// </summary>
		public int matchState { get { return (int)m_MatchState; } }



		private ulong m_EnqueueTimeStamp = 0;
		/// <summary>
		/// 进入等待队列时间戳(0表示未报名战场或战场已匹配)
		/// </summary>
		public ulong enqueueTimeStamp { get { return m_EnqueueTimeStamp; } }



		private ulong m_NotifyEnterTimeStamp = 0;
		/// <summary>
		/// 通知进入的时间戳(0表示未通知或已进入)
		/// </summary>
		public ulong notifyEnterTimeStamp { get { return m_NotifyEnterTimeStamp; } }



		/// <summary>
		/// 组队匹配检查结果数量
		/// </summary>
		public int teamMatchCheckResultCount { get { return m_TeamMatchCheckResults.Count; } }



		/// <summary>
		/// 存放队伍匹配的服务器检查结果
		/// </summary>
		private List<TeamCheckResult> m_TeamMatchCheckResults = new List<TeamCheckResult>(Const.kCap4 + 1);



		private GameEvent<bool> m_OnUserMatchStartDataArrived = new GameEvent<bool>();
		/// <summary>
		/// 开始匹配(单人&&全体队员)
		/// </summary>
		public GameEvent<bool> onUserMatchStartDataArrived
		{
			get { return m_OnUserMatchStartDataArrived; }
		}



		private GameEvent m_OnNotifyTeamBattleMatchFailedDataArrived = new GameEvent();
		/// <summary>
		/// 通知队长组队匹配检查结果
		/// </summary>
		public GameEvent onNotifyTeamBattleMatchFailedDataArrived
		{
			get { return m_OnNotifyTeamBattleMatchFailedDataArrived; }
		}



		private GameEvent<bool> m_OnCancelBattleMatchDataArrived = new GameEvent<bool>();
		/// <summary>
		/// 匹配是否已取消
		/// </summary>
		public GameEvent<bool> onCancelBattleMatchDataArrived
		{
			get { return m_OnCancelBattleMatchDataArrived; }
		}



		private GameEvent m_OnNotifyBattleMatchDataArrived = new GameEvent();
		/// <summary>
		/// 匹配成功
		/// </summary>
		public GameEvent onNotifyBattleMatchDataArrived
		{
			get { return m_OnNotifyBattleMatchDataArrived; }
		}



		private GameEvent m_OnRequestEnterBattle = new GameEvent();
		/// <summary>
		/// 通知已经请求进入战场
		/// </summary>
		public GameEvent onRequestEnterBattle
		{
			get { return m_OnRequestEnterBattle; }
		}

		#endregion



		#region 报名流程的通信和辅助方法

		/// <summary>
		/// 请求个人战场匹配
		/// </summary>
		public void RequestSingleBattleMatch_CS(int battleType)
		{
			ulong tServerTime = GameScene.Instance.GetServerTime();
			if (tServerTime - m_SingleEnrollRequestTimeStamp > kTimeOut)
				m_SingleEnrollRequestTimeStamp = 0;
			if (m_SingleEnrollRequestTimeStamp != 0) return;
			m_SingleEnrollRequestTimeStamp = tServerTime;

			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<swm.ReqUserBattleMatch> tOffset = swm.ReqUserBattleMatch.CreateReqUserBattleMatch(tFBB, (swm.BattleType)battleType);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqUserBattleMatch.HashID, tFBB);
		}



		/// <summary>
		/// 请求组队战场匹配
		/// </summary>
		public void RequestTeamBattleMatch_CS(int battleType)
		{
			ulong tServerTime = GameScene.Instance.GetServerTime();
			if (tServerTime - m_TeamEnrollRequestTimeStamp > kTimeOut)
				m_TeamEnrollRequestTimeStamp = 0;
			if (m_TeamEnrollRequestTimeStamp != 0) return;
			m_TeamEnrollRequestTimeStamp = tServerTime;

			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<swm.ReqTeamBattleMatch> tOffset = swm.ReqTeamBattleMatch.CreateReqTeamBattleMatch(tFBB, (swm.BattleType)battleType);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqTeamBattleMatch.HashID, tFBB);
		}



		/// <summary>
		/// 服务器返回是否开始匹配(单人&&全体队员)
		/// </summary>
		private void ResponseUserMatchStart_SC(NotifyUserMatchStart msg)
		{
			UpdateEnqueueState(msg.is_team);
			m_OnUserMatchStartDataArrived.Invoke(true);
		}



		/// <summary>
		/// (队长)服务器返回报名队伍匹配的结果以及条件检查结果
		/// </summary>
		private void ResponseNotifyTeamBattleMatchFailed_SC(NotifyTeamBattleMatchFailed msg)
		{
			//不成功的消息处理
			m_TeamMatchCheckResults.Clear();
			for (int tIdx = 0, tCount = msg.conditionLength; tIdx < tCount; tIdx++)
			{
				TeamBattleMatchCheck? tData = msg.condition(tIdx);
				if(tData.HasValue)
				{
					TeamCheckResult tResult = new TeamCheckResult(tData.Value);
					m_TeamMatchCheckResults.Add(tResult);
				}
			}
			m_OnNotifyTeamBattleMatchFailedDataArrived.Invoke();
		}



		/// <summary>
		/// 请求取消战场匹配.
		/// 队长：取消全队
		/// 队员或个人：取消自己
		/// </summary>
		public void RequestCancelBattleMatch_CS(int battleType)
		{
			ulong tServerTime = GameScene.Instance.GetServerTime();
			if (tServerTime - m_CancelRequestTimeStamp > kTimeOut)
				m_CancelRequestTimeStamp = 0;
			if (m_CancelRequestTimeStamp != 0) return;
			m_CancelRequestTimeStamp = tServerTime;

			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<swm.ReqCancelBattleMatch> tOffset = swm.ReqCancelBattleMatch.CreateReqCancelBattleMatch(tFBB, (swm.BattleType)battleType);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqCancelBattleMatch.HashID, tFBB);
		}



		/// <summary>
		/// 服务器返回是否已取消匹配。
		/// 队长取消全队的匹配。
		/// 队员或个人取消自己的匹配
		/// </summary>
		private void ResponseCancelBattleMatch_SC(ResCancelBattleMatch msg)
		{
			UpdateDequeueState();
			m_OnCancelBattleMatchDataArrived.Invoke(true);
		}



		/// <summary>
		/// 通知战场匹配成功，开始倒计时
		/// </summary>
		private void ResponseNotifyBattleReady_SC(NotifyBattleReady msg)
		{
			UpdateMatchSuccessState();
			m_OnNotifyBattleMatchDataArrived.Invoke();

            AirWallManager.Instance.Clear();
		}



		/// <summary>
		/// 请求进入战场
		/// </summary>
		public void RequestEnterBattle_CS(bool deadline = false)
		{
			UpdateEnterBattleState();
			//因为倒计时结束的调用
			if (deadline) return;
            //要先下马
            MountMgr.Instance.RequestDismount();
			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.ReqEnterBattle.StartReqEnterBattle(tFBB);
			Offset<swm.ReqEnterBattle> tOffset = swm.ReqEnterBattle.EndReqEnterBattle(tFBB);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqEnterBattle.HashID, tFBB);
			m_OnRequestEnterBattle.Invoke();
		}



		/// <summary>
		/// 获取组队报名的指定队员检查结果
		/// </summary>
		public TeamCheckResult GetCheckResultByIndex(int index)
		{
			if (index < 0 || index >= m_TeamMatchCheckResults.Count)
				return default(TeamCheckResult);
			return m_TeamMatchCheckResults[index];
		}



		/// <summary>
		/// 进入战场匹配队列，更新时间戳和报名状态
		/// </summary>
		private void UpdateEnqueueState(bool isTeam)
		{
			if (isTeam)
			{
				m_TeamEnrollRequestTimeStamp = 0;
				m_MatchType = MatchType.Team;
				m_TeamMatchCheckResults.Clear();
			}
			else
			{
				m_SingleEnrollRequestTimeStamp = 0;
				m_MatchType = MatchType.Single;
			}
			m_EnqueueTimeStamp = GameScene.Instance.GetServerTime() / 1000;
			m_MatchState = MatchState.Matching;
		}



		/// <summary>
		/// 离开战场匹配队列，更新时间戳和报名状态
		/// </summary>
		private void UpdateDequeueState()
		{
			m_MatchType = MatchType.None;
			m_CancelRequestTimeStamp = 0;
			m_EnqueueTimeStamp = 0;
			m_MatchState = MatchState.None;
		}



		/// <summary>
		/// 战场匹配成功，更新时间戳和报名状态
		/// </summary>
		private void UpdateMatchSuccessState()
		{
			m_EnqueueTimeStamp = 0;
			m_MatchState = MatchState.Entering;
			m_NotifyEnterTimeStamp = GameScene.Instance.GetServerTime() / 1000;
		}



		/// <summary>
		/// 进入战场，更新时间戳和报名状态
		/// </summary>
		private void UpdateEnterBattleState()
		{
			m_MatchType = MatchType.None;
			m_MatchState = MatchState.None;
			m_NotifyEnterTimeStamp = 0;
		}



		/// <summary>
		/// 获取今天的战场信息
		/// </summary>
		public BattleFieldInfo GetTodayBattleFieldInfo()
		{
			BattleFieldInfo tInfo = default(BattleFieldInfo);
			int tCount = BattleFieldTableManager.Instance.m_DataList.BattleFieldTableLength;
			if(tCount > 0)
			{
				//临时性获取第一个战场，实际应该通过活动查询当日的战场
				BattleFieldTableBase? tBaseData = BattleFieldTableManager.GetData(1);
				if(tBaseData.HasValue)
				{
					BattleFieldTableBase tValue = tBaseData.Value;
					tInfo.id					= tValue.id;
					tInfo.name					= tValue.name;
                    tInfo.count                 = tValue.numbers;
					tInfo.minLevel				= tValue.level;
					tInfo.maxDuration			= tValue.max_duration;
					tInfo.countDown				= tValue.count_down;
					tInfo.img_bg				= tValue.img_bg;
					tInfo.icon					= tValue.icon;
					tInfo.desc					= tValue.desc;
                    tInfo.team_member_limit     = tValue.team_member_limit;
                    tInfo.common_award          = tValue.common_award;
                    tInfo.week_award            = tValue.week_award;   

                }
			}
			return tInfo;
		}

		#endregion



		#region 战场通用的变量、属性和事件

        /// <summary>
        /// 头衔
        /// </summary>
        private class BattleTitle
        {
            /// <summary>
            /// 最佳
            /// </summary>
            public const int MVP = 1;
            /// <summary>
            /// 伤害王
            /// </summary>
            public const int DamageKing = 2;
            /// <summary>
            /// 治疗王
            /// </summary>
            public const int CureKing = 4;
            /// <summary>
            /// 击杀王
            /// </summary>
            public const int KillKing = 8;
            /// <summary>
            /// 辅助王
            /// </summary>
            public const int AssistKing = 16;
            /// <summary>
            /// 受击王
            /// </summary>
            public const int HurtKing = 32;
            /// <summary>
            /// 夺旗王
            /// </summary>
            public const int FlagKing = 64;
            /// <summary>
            /// 空投王
            /// </summary>
            public const int AirdropKing = 64;
        }



		/// <summary>
		/// 请求退出战场的时间戳（0表示无请求）
		/// </summary>
		private ulong m_QuitRequestTimeStamp = 0;



		private ulong m_BattleFieldStartTimeStamp = 0;
		/// <summary>
		/// 战场开启时间戳(毫秒)
		/// </summary>
		public ulong battleFieldStartTimeStamp { get { return m_BattleFieldStartTimeStamp; } }



		private ulong m_BattleFieldDuration = 0;
		/// <summary>
		/// 战场开启时长(毫秒)
		/// </summary>
		public ulong battleFieldDuration { get { return m_BattleFieldDuration; } }



		/// <summary>
		/// 战场结束时间戳（毫秒）
		/// </summary>
		public ulong battleFieldStopTimeStamp { get { return m_BattleFieldStartTimeStamp + m_BattleFieldDuration; } }



		private ulong m_BattleVoteStartTimeStamp = 0;
		/// <summary>
		/// 请求战场投票的时间戳(毫秒)
		/// </summary>
		public ulong battleVoteStartTimeStamp { get { return m_BattleVoteStartTimeStamp; } }



		private bool m_IsInBattleField = false;
		/// <summary>
		/// 是否正在战场中
		/// </summary>
		public bool isInBattleField
		{
			get { return m_IsInBattleField; }
			set { m_IsInBattleField = value; }
		}



		/// <summary>
		/// 竞技各方的积分（可以表示分数、夺旗数等） 
		/// </summary>
		private Dictionary<int, uint> m_CampScores = new Dictionary<int, uint>(Const.kCap4);



		private BattleVoteStatus m_VoteStatus;
		/// <summary>
		/// 投票状态
		/// </summary>
		public BattleVoteStatus voteStatus { get { return m_VoteStatus; } }



		private BattleFieldOutCome m_OutCome = BattleFieldOutCome.Win;
		/// <summary>
		/// 己方胜利(0)、平局(1)、失败(2)
		/// </summary>
		public int outCome { get { return (int)m_OutCome; } }



		/// <summary>
		/// 结算结果的数量（包括自己）
		/// </summary>
		public int battleResultCount { get { return m_BattleResults.Count; } }



		/// <summary>
		/// 存放结算结果，每人一条（提前退出的人没有结果，包括自己）
		/// </summary>
		private List<BattleResult> m_BattleResults = new List<BattleResult>(Const.kCap16 + Const.kCap4);



		/// <summary>
		/// 存放charID对应的奖品信息
		/// </summary>
		private Dictionary<ulong, List<AwardInfo>> m_AwardInfosMap = new Dictionary<ulong, List<AwardInfo>>(Const.kCap16 + Const.kCap4);

        /// <summary>
        /// 周胜场数
        /// </summary>
        private uint m_winweek = 0;
        public uint win_week
        {
            get { return m_winweek; }
        }

        /// <summary>
        /// 周胜上限
        /// </summary>
        private uint m_winweektarget = 0;
        public uint winweekTarget
        {
            get { return m_winweektarget; }
        }


        /// <summary>
        /// 双倍功勋
        /// </summary>
        private uint m_candouble = 0;
        public uint candouble
        {
            get { return m_candouble; }
        }

        /// <summary>
        /// 战场状态
        /// </summary>
        private bool m_InBattle = false;
        public bool InBattle
        {
            get { return m_InBattle; }
        }

        /// <summary>
        /// 开始时间
        /// </summary>
        private ulong m_StartTime = 0;
        public ulong StartTime
        {
            get { return m_StartTime; }
        }

        /// <summary>
        /// 当次功勋
        /// </summary>
        private uint m_curhonour = 0;
        public uint curhonour
        {
            get { return m_curhonour; }
        }

        private GameEvent m_OnNotifyTeamScoreChanged = new GameEvent();
		/// <summary>
		/// 通知战场中的阵营得分发生变化
		/// </summary>
		public GameEvent onNotifyTeamScoreChanged
		{
			get { return m_OnNotifyTeamScoreChanged; }
		}



		private GameEvent m_OnNotifyBattleOverDataArrived = new GameEvent();
		/// <summary>
		/// 服务器通知战场结束，结算信息
		/// </summary>
		public GameEvent onNotifyBattleOverDataArrived
		{
			get { return m_OnNotifyBattleOverDataArrived; }
		}



		private GameEvent<int> m_OnNotifyBattleStateDataArrived = new GameEvent<int>();
		/// <summary>
		/// 服务器通知战场状态发生变化
		/// </summary>
		public GameEvent<int> onNotifyBattleStateDataArrived
		{
			get { return m_OnNotifyBattleStateDataArrived; }
		}



		private GameEvent m_OnRefreshBattleRerollTimeStamp = new GameEvent();
		/// <summary>
		/// 服务器刷新申请战场重启的时间戳
		/// </summary>
		public GameEvent onRefreshBattleRerollTimeStamp
		{
			get { return m_OnRefreshBattleRerollTimeStamp; }
		}



		private GameEvent<int> m_OnNotifyStartBattleVoteDataArrived = new GameEvent<int>();
		/// <summary>
		/// 服务器通知玩家开始投票
		/// </summary>
		public GameEvent<int> onNotifyStartBattleVoteDataArrived
		{
			get { return m_OnNotifyStartBattleVoteDataArrived; }
		}



		private GameEvent m_OnNotifyBattleVoteStatusDataArrived = new GameEvent();
		/// <summary>
		/// 服务器更新战场投票进度
		/// </summary>
		public GameEvent onNotifyBattleVoteStatusDataArrived
		{
			get { return m_OnNotifyBattleVoteStatusDataArrived; }
		}



		private GameEvent m_OnNotifyBattleVoteResultDataArrived = new GameEvent();
		/// <summary>
		/// 服务器更新战场投票结果
		/// </summary>
		public GameEvent onNotifyBattleVoteResultDataArrived
		{
			get { return m_OnNotifyBattleVoteResultDataArrived; }
		}



		private GameEvent m_OnNotifyLastVoteTimeDataArrived = new GameEvent();
		/// <summary>
		/// 服务器向进入战场的人同步上次投票时间
		/// </summary>
		public GameEvent onNotifyLastVoteTimeDataArrived
		{
			get { return m_OnNotifyLastVoteTimeDataArrived; }
		}



        private GameEvent m_OnExitBattleDataArrived = new GameEvent();
        /// <summary>
        /// 服务器返回退出战场的结果
        /// </summary>
        public GameEvent onExitBattleDataArrived
        {
            get { return m_OnExitBattleDataArrived; }
        }

        #endregion



        #region 战场通用的通信和辅助方法

        /// <summary>
        /// 服务器通知战场状态改变
        /// </summary>
        private void ResponseNotifyBattleState_SC(NotifyBattleState msg)
		{
			if (msg.state == BattleState.Game)
			{
				m_BattleFieldStartTimeStamp = msg.start_time;
				m_BattleFieldDuration = msg.duration;
			}
			m_OnNotifyBattleStateDataArrived.Invoke((int)msg.state);
		}



		/// <summary>
		/// 服务器下发战场各方的分数
		/// </summary>
		private void ResponseNotifyBattleScore_SC(NotifyBattleCampScore msg)
		{
			m_CampScores.Clear();
			for (int tIdx = 0, tCount = msg.scoresLength; tIdx < tCount; tIdx++)
			{
				CampScore? tData = msg.scores(tIdx);
				if (tData.HasValue)
				{
					CampScore tValue = tData.Value;
					m_CampScores.Add((int)tValue.camp_type, tValue.score);
				}
			}
			m_OnNotifyTeamScoreChanged.Invoke();
		}



		/// <summary>
		/// 请求发起战场投票
		/// </summary>
		public void RequestStartBattleVote_CS(int voteType)
		{
			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<ReqStartBattleVote> tOffset = swm.ReqStartBattleVote.CreateReqStartBattleVote(tFBB, (BattleVoteType)voteType);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqStartBattleVote.HashID, tFBB);
		}



		/// <summary>
		/// 服务器通知玩家开始投票
		/// </summary>
		private void ResponseNotifyStartBattleVote_CS(NotifyStartBattleVote msg)
		{
			m_BattleVoteStartTimeStamp = msg.start_time;
			m_OnNotifyStartBattleVoteDataArrived.Invoke((int)msg.type);
		}



		/// <summary>
		/// 向服务器发送投票决定
		/// </summary>
		public void RequestDoBattleVote_CS(int voteType, bool agree)
		{
			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<ReqDoBattleVote> tOffset = swm.ReqDoBattleVote.CreateReqDoBattleVote(tFBB, (BattleVoteType)voteType, agree);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqDoBattleVote.HashID, tFBB);
		}


        /// <summary>
        /// 周胜信息
        /// </summary>
        public void ReqBattleWeekWins()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            MsgDispatcher.instance.SendFBPackage(swm.ReqBattleWeekWins.HashID, tFBB);
        }


        /// <summary>
        /// 双倍奖励
        /// </summary>
        public void ReqTakeBattleDoubleReward()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            MsgDispatcher.instance.SendFBPackage(swm.ReqTakeBattleDoubleReward.HashID, tFBB);
        }


        /// <summary>
        /// 服务器更新战场投票进度
        /// </summary>
        private void ResponseNotifyBattleVoteStatus_SC(swm.NotifyBattleVoteStatus msg)
		{
			//假设统一时间段内只有一种投票行为
			m_VoteStatus.voteType = (int)msg.type;
			m_VoteStatus.agreeCount = msg.agree;
			m_VoteStatus.totalCount = msg.total;
			m_OnNotifyBattleVoteStatusDataArrived.Invoke();
		}



		/// <summary>
		/// 服务器通知投票结果
		/// </summary>
		private void ResponseNotifyBattleVoteResult_SC(swm.NotifyBattleVoteResult msg)
		{
			m_VoteStatus.voteType = (int)msg.type;
			m_VoteStatus.campType = (int)msg.camp_type;
			m_VoteStatus.result = msg.result;
			m_OnNotifyBattleVoteResultDataArrived.Invoke();
		}



		/// <summary>
		/// 服务器同步上一次投票时间
		/// </summary>
		private void ResponseNotifyLastVoteTime_SC(swm.NotifyLastVoteTime msg)
		{
			m_BattleVoteStartTimeStamp = msg.last_vote_time;
			m_OnNotifyLastVoteTimeDataArrived.Invoke();
		}



		/// <summary>
		/// 服务器通知战场结束
		/// </summary>
		private void ResponseNotifyBattleOver_SC(NotifyBattleOver msg)
		{
			ulong tMVP			= msg.mvp;
			ulong tDamageKing	= msg.damage_king;
			ulong tCureKing		= msg.cure_king;
			ulong tKillKing		= msg.kill_king;
			ulong tAssistKing	= msg.assist_king;
            ulong hurt_king     = msg.hurt_king;
            ulong unflag_king   = msg.unflag_king;
            ulong airdrop_king  = msg.airdrop_king;

            ulong tMainCharID	= 0;
			if (GameScene.Instance.MainChar)
				tMainCharID = GameScene.Instance.MainChar.ThisID;

			//清理
			m_BattleResults.Clear();
			ClearAwardInfos();

            CampType tMainCharCamp = CampType.UNKNOWN;
            for (int tIdx = 0, tCount = msg.result_infoLength; tIdx < tCount; tIdx++)
			{
				UserBattleResult? tData = msg.result_info(tIdx);
				if (tData.HasValue)
				{
					UserBattleResult tValue = tData.Value;
					BattleResult tResult = new BattleResult(tValue);
					tResult.awardCount = ParseAwardInfos(tValue);
					ulong tCharID = tValue.charid;
					tResult.title = GetTitleInfo(tMVP, tDamageKing, tCureKing, tKillKing, tAssistKing, hurt_king, unflag_king, airdrop_king, tCharID);
					if (tCharID == tMainCharID)
                    {
                        tMainCharCamp = (CampType)tResult.campType;
                        m_candouble = tResult.doubleflag;
                        m_curhonour = tResult.honour;
                    }
                        
					m_BattleResults.Add(tResult);
				}
			}

			//胜败结果
			CampType tWinCamp = msg.win_camp;
			if (tWinCamp == CampType.UNKNOWN)
				m_OutCome = BattleFieldOutCome.Draw;
			else if (tWinCamp == tMainCharCamp)
				m_OutCome = BattleFieldOutCome.Win;
			else
				m_OutCome = BattleFieldOutCome.Fail;

			m_OnNotifyBattleOverDataArrived.Invoke();
		}



		/// <summary>
		/// 请求退出当前战场
		/// </summary>
		public void RequestExitBattle_CS()
		{
			ulong tServerTime = GameScene.Instance.GetServerTime();
			if (tServerTime - m_QuitRequestTimeStamp > kTimeOut)
				m_QuitRequestTimeStamp = 0;
			if (m_QuitRequestTimeStamp != 0) return;
			m_QuitRequestTimeStamp = tServerTime;

			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.ReqExitBattle.StartReqExitBattle(tFBB);
			Offset<swm.ReqExitBattle> tOffset = swm.ReqExitBattle.EndReqExitBattle(tFBB);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqExitBattle.HashID, tFBB);
			m_OnRequestEnterBattle.Invoke();
		}



		/// <summary>
		/// 服务器通知已经离开战场
		/// </summary>
		private void ResponseExitBattle_SC(RspExitBattle msg)
		{
			UIUtility.LogInfo("Exit Battle");

            AirWallManager.Instance.Clear();

            m_OnExitBattleDataArrived.Invoke();
        }



		/// <summary>
		/// 清理战场缓存数据
		/// </summary>
		public void ClearBattleCacheData()
		{
			//清理战场数据
			m_SingleEnrollRequestTimeStamp = 0;
			m_TeamEnrollRequestTimeStamp = 0;
			m_CancelRequestTimeStamp = 0;
			m_MatchType = MatchType.None;
			m_MatchState = MatchState.None;
			m_EnqueueTimeStamp = 0;
			m_NotifyEnterTimeStamp = 0;
			m_TeamMatchCheckResults.Clear();
			m_QuitRequestTimeStamp = 0;
			m_BattleFieldStartTimeStamp = 0;
			m_BattleFieldDuration = 0;
			m_BattleVoteStartTimeStamp = 0;
			m_CampScores.Clear();
			m_BattleResults.Clear();
			m_BoxID = 0;
			ClearAwardInfos();
			m_ItemList.Clear();
		}



		/// <summary>
		/// 清理奖励信息
		/// </summary>
		private void ClearAwardInfos()
		{
			foreach (var tPair in m_AwardInfosMap)
				UIPoolMgr.RecycleList(tPair.Value);
			m_AwardInfosMap.Clear();
		}



		/// <summary>
		/// 奖励信息另外解析
		/// </summary>
		private int ParseAwardInfos(UserBattleResult data)
		{
			List<AwardInfo> tList = UIPoolMgr.SpawnList<AwardInfo>();
			for (int tIdx = 0, tCount = data.awardLength; tIdx < tCount; tIdx++)
			{
				BattleAwardInfo? tData = data.award(tIdx);
				if (tData.HasValue)
				{
					AwardInfo tAInfo = new AwardInfo(tData.Value);
					tList.Add(tAInfo);
				}
			}
			m_AwardInfosMap.Add(data.charid, tList);
			return tList.Count;
		}



		/// <summary>
		/// 获取头衔信息
		/// </summary>
		private int GetTitleInfo(ulong mvp, ulong damageKing, ulong cureKing, ulong killKing, ulong assistKing, ulong hurt_king, ulong unflag_king, ulong airdrop_king, ulong charid)
		{
			int tTitle = 0;
			if (mvp == charid)
				tTitle |= BattleTitle.MVP;
			if (damageKing == charid)
				tTitle |= BattleTitle.DamageKing;
			if (cureKing == charid)
				tTitle |= BattleTitle.CureKing;
			if (killKing == charid)
				tTitle |= BattleTitle.KillKing;
			if (assistKing == charid)
				tTitle |= BattleTitle.AssistKing;
            if (hurt_king == charid)
                tTitle |= BattleTitle.HurtKing;
            if (unflag_king == charid)
                tTitle |= BattleTitle.FlagKing;
            if (airdrop_king == charid)
                tTitle |= BattleTitle.AirdropKing;
            return tTitle;
		}



        /// <summary>
        /// 是否MVP
        /// </summary>
        public bool IsMVP(int title)
        {
            return (title & BattleTitle.MVP) != 0;
        }



        /// <summary>
        /// 是否伤害王
        /// </summary>
        public bool IsDamageKing(int title)
        {
            return (title & BattleTitle.DamageKing) != 0;
        }



        /// <summary>
        /// 是否治疗王
        /// </summary>
        public bool IsCureKing(int title)
        {
            return (title & BattleTitle.CureKing) != 0;
        }



        /// <summary>
        /// 是否击杀王
        /// </summary>
        public bool IsKillKing(int title)
        {
            return (title & BattleTitle.KillKing) != 0;
        }



        /// <summary>
        /// 是否助攻王
        /// </summary>
        public bool IsAssistKing(int title)
        {
            return (title & BattleTitle.AssistKing) != 0;
        }

        /// <summary>
        /// 是否受击王
        /// </summary>
        public bool IsHurtKing(int title)
        {
            return (title & BattleTitle.HurtKing) != 0;
        }

        /// <summary>
        /// 是否夺旗王
        /// </summary>
        public bool IsFlagKing(int title)
        {
            return (title & BattleTitle.FlagKing) != 0;
        }

        /// <summary>
        /// 是否夺旗王
        /// </summary>
        public bool IsAirdropKing(int title)
        {
            return (title & BattleTitle.AirdropKing) != 0;
        }

        /// <summary>
        /// 获取指定索引的战斗结算信息
        /// </summary>
        public BattleResult GetResultByIndex(int index)
		{
			if (index < 0 || index >= battleResultCount)
				return default(BattleResult);
			return m_BattleResults[index];
		}



		/// <summary>
		/// 根据阵营类型获取对应的分数
		/// </summary>
		public uint GetScoreByCampType(int campType)
		{
			uint tScore;
			m_CampScores.TryGetValue(campType, out tScore);
			return tScore;
		}



		/// <summary>
		/// 根据索引获取指定玩家的指定奖励
		/// </summary>
		public AwardInfo GetCharAwardInfoByIndex(ulong charID, int index)
		{
			List<AwardInfo> tList = null;
			if (m_AwardInfosMap.TryGetValue(charID, out tList))
			{
				if (index >= 0 && index < tList.Count)
					return tList[index];
			}
			return default(AwardInfo);
		}



		/// <summary>
		/// 根据道具id获取道具icon的路径
		/// </summary>
		public string GetAwardIconPath(uint itemID)
		{
            return UIUtility.GetPathByItemId(itemID);
		}



        /// <summary>
        /// 获取匹配模式的名称
        /// </summary>
        public string GetMatchTypeName()
        {
            string tName = "未知";
            switch (m_MatchType)
            {
                case MatchType.Single:
                    tName = "单人";
                    break;
                case MatchType.Team:
                    tName = "组队";
                    break;
            }
            return tName;
        }

        #endregion



        #region 云巅战场的变量、属性和事件

        private ulong m_BoxID = 0;
		/// <summary>
		/// 当前打开的空投宝箱id
		/// </summary>
		public ulong boxID { get { return m_BoxID; } }



		/// <summary>
		/// 空投宝箱中道具数量
		/// </summary>
		public int itemCount { get { return m_ItemList.Count; } }



		/// <summary>
		/// 存放空投道具信息
		/// </summary>
		private List<BattleItemInfo> m_ItemList = new List<BattleItemInfo>(Const.kCap4);



		private ItemManager m_ItemBag = null;
		/// <summary>
		/// 道具背包管理器
		/// </summary>
		public ItemManager itemBag { get { return m_ItemBag; } }



		private GameEvent<bool> m_OnOpenAirDropDataArrived = new GameEvent<bool>();
		/// <summary>
		/// 服务器返回打开空投宝箱的结果
		/// </summary>
		public GameEvent<bool> onOpenAirDropDataArrived
		{
			get { return m_OnOpenAirDropDataArrived; }
		}

        private GameEvent m_OnWeekDataArrived = new GameEvent();
        /// <summary>
        /// 服务器通知周胜
        /// </summary>
        public GameEvent onWeekDataArrived
        {
            get { return m_OnWeekDataArrived; }
        }


        private GameEvent m_OnPickItemInAirDropDataArrived = new GameEvent();
		/// <summary>
		/// 服务器通知空投宝箱的道具被拾取
		/// </summary>
		public GameEvent onPickItemInAirDropDataArrived
		{
			get { return m_OnPickItemInAirDropDataArrived; }
		}



		private GameEvent m_OnNotifyCreateFlagDataArrived = new GameEvent();
		/// <summary>
		/// 服务器通知即将刷新旗帜
		/// </summary>
		public GameEvent onNotifyCreateFlagDataArrived
		{
			get { return m_OnNotifyCreateFlagDataArrived; }
		}


        private GameEvent<uint> m_OnStartTime = new GameEvent<uint>();
        /// <summary>
        /// 服务器通知即将刷新旗帜
        /// </summary>
        public GameEvent<uint> OnStartTime
        {
            get { return m_OnStartTime; }
        }

        #endregion



        #region 云巅战场的通信和辅助方法

        /// <summary>
        /// 服务器通知即将刷新旗帜
        /// </summary>
        private void ResponseNotifyCreateFlag_SC(swm.NotifyCreateFlag msg)
		{
			m_OnNotifyCreateFlagDataArrived.Invoke();
		}



		/// <summary>
		/// 服务器下发空投宝箱中的道具列表(通过采集Npc访问)
		/// </summary>
		private void ResponseOpenAirDrop_SC(ResOpenAirDrop msg)
		{
			m_BoxID = msg.retcode ? msg.tarid : 0;
			m_ItemList.Clear();
			for (int tIdx = 0, tCount = msg.baseidsLength; tIdx < tCount; tIdx++)
			{
				ulong tBaseID = msg.baseids(tIdx);
				ItemTableBase? tConfig = ItemTableManager.GetData((int)tBaseID);
				if (tConfig.HasValue)
				{
					BattleItemInfo tInfo = new BattleItemInfo(tConfig.Value);
					m_ItemList.Add(tInfo);
				}
			}
			m_OnOpenAirDropDataArrived.Invoke(msg.retcode);
		}



		/// <summary>
		/// 请求拾取指定宝箱中的指定道具
		/// </summary>
		public void RequestPickItemInAirDrop_CS(ulong itemID)
		{
			FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<swm.ReqPickItemInAirDrop> tOffset = swm.ReqPickItemInAirDrop.CreateReqPickItemInAirDrop(tFBB, m_BoxID, itemID);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqPickItemInAirDrop.HashID, tFBB);
		}



		/// <summary>
		/// 服务器广播某人拾取了空投宝箱的道具
		/// </summary>
		private void ResponsePickItemInAirDrop_SC(ResPickItemInAirDrop msg)
		{
			if (msg.taruid != m_BoxID) return;
			for (int tIdx = 0, tCount = m_ItemList.Count; tIdx < tCount; tIdx++)
			{
				if (m_ItemList[tIdx].id == msg.baseid)
				{
					m_ItemList.RemoveAt(tIdx);
					break;
				}
			}
			if (m_ItemList.Count == 0) m_BoxID = 0;
			m_OnPickItemInAirDropDataArrived.Invoke();
		}

        /// <summary>
        /// 周胜反馈
        /// </summary>
        private void ResponseBattleWeekWins_SC(ResBattleWeekWins msg)
        {
            m_winweek = msg.wins;
            m_winweektarget = msg.win_target;
            m_OnWeekDataArrived.Invoke();
        }

        /// <summary>
        /// 战场状态
        /// </summary>
        private void ResponseNotifyPVPState(NotifyPVPState msg)
        {
            m_InBattle = msg.is_in_pvp == 1;
        }

        /// <summary>
        /// 战场开启时间
        /// </summary>
        private void ResponseNotifyBattleWaitStartTime(NotifyBattleWaitStartTime msg)
        {
            m_StartTime = msg.wait_time * 1000 + GameScene.Instance.GetServerTime();
        }


        /// <summary>
        /// 获取指定索引的空投技能信息
        /// </summary>
        public BattleItemInfo GetItemByIndex(int index)
		{
			if (index < 0 || index >= itemCount)
				return default(BattleItemInfo);
			return m_ItemList[index];
		}

        #endregion

    }



    /// <summary>
    /// 战场信息
    /// </summary>
    public struct BattleFieldInfo
	{
		/// <summary>
		/// 战场id
		/// </summary>
		public int		id;
		/// <summary>
		/// 战场名称
		/// </summary>
		public string	name;
        /// <summary>
        /// 战场人数（单边）
        /// </summary>
        public int      count;
		/// <summary>
		/// 最小等级要求
		/// </summary>
		public int		minLevel;
		/// <summary>
		/// 战场持续时间
		/// </summary>
		public int		maxDuration;
		/// <summary>
		/// 离开倒计时长
		/// </summary>
		public int		countDown;
		/// <summary>
		/// 背景图
		/// </summary>
		public string	img_bg;
		/// <summary>
		/// 图标
		/// </summary>
		public string	icon;
		/// <summary>
		/// 描述
		/// </summary>
		public string	desc;
        /// <summary>
        /// 队伍人数要求
        /// </summary>
        public int      team_member_limit;
        /// <summary>
        /// 常规奖励
        /// </summary>
        public int common_award;
        /// <summary>
        /// 每周奖励
        /// </summary>
        public int week_award;

    }



	/// <summary>
	/// 队伍战场/竞技场匹配的条件检查结果
	/// </summary>
	public struct TeamCheckResult
	{
		/// <summary>
		/// 角色id
		/// </summary>
		public ulong id;
		/// <summary>
		/// 检查结果
		/// </summary>
		public int checkCode;



		public TeamCheckResult(TeamBattleMatchCheck result)
		{
			this.id = result.id;
			this.checkCode = (int)result.code;
		}



        public TeamCheckResult(UserArenaMatchCheckData result)
        {
            this.id = result.id;
            this.checkCode = (int)result.code;
        }
    }



	/// <summary>
	/// 战场结算结果
	/// </summary>
	public struct BattleResult
	{
		/// <summary>
		/// 角色id
		/// </summary>
		public ulong id;
		/// <summary>
		/// 击杀数
		/// </summary>
		public uint kill;
		/// <summary>
		/// 助攻数
		/// </summary>
		public uint assist;
		/// <summary>
		/// 死亡数
		/// </summary>
		public uint dead;
		/// <summary>
		/// 伤害量
		/// </summary>
		public uint damage;
		/// <summary>
		/// 治疗量
		/// </summary>
		public uint cure;
        /// <summary>
        /// 受到伤害
        /// </summary>
        public uint hurt;
        /// <summary>
        /// 打断夺旗
        /// </summary>
        public uint unflag;
        /// <summary>
        /// 空投获取
        /// </summary>
        public uint airdrop;
        /// <summary>
        /// 功勋
        /// </summary>
        public uint honour;
        /// <summary>
        /// 得分
        /// </summary>
        public uint score;
		/// <summary>
		/// 奖励数量
		/// </summary>
		public int awardCount;
		/// <summary>
		/// 阵营id
		/// </summary>
		public int campType;
		/// <summary>
		/// 头衔（用质数相乘，便于Lua判断）
		/// </summary>
		public int title;
        /// <summary>
        /// 周胜
        /// </summary>
        public uint wins;
        /// <summary>
        /// 周胜上限
        /// </summary>
        public uint win_target;
        /// <summary>
        /// 双倍是否可领
        /// </summary>
        public uint doubleflag;


        public BattleResult(UserBattleResult tValue)
		{
			id			= tValue.charid;
			campType	= (int)tValue.camp_type;
			kill		= tValue.kill_num;
			assist		= tValue.assist_num;
			dead		= tValue.dead_num;
			damage		= tValue.damage_num;
			cure		= tValue.cure_num;
            hurt        = tValue.hurt_num;
            unflag      = tValue.unflag_num;
            airdrop     = tValue.airdrop_num;
            honour      = tValue.honour;
            score		= tValue.score;
            wins            = tValue.wins;
            win_target      = tValue.win_target;
            doubleflag      = tValue.doubleflag;
            //以下2个值另行处理
            awardCount = 0;
			title		= 1;
		}
	}



	/// <summary>
	/// 奖励信息
	/// </summary>
	public struct AwardInfo
	{
		/// <summary>
		/// 奖品id
		/// </summary>
		public uint itemID;
		/// <summary>
		/// 奖品数量
		/// </summary>
		public uint count;



        public AwardInfo(BattleAwardInfo value)
		{
			this.itemID = value.itemid;
			this.count = value.num;
		}



        public AwardInfo(IntList config)
        {
            this.itemID = (uint)(config.listLength > 0 ? config.list(0) : 0);
            this.count = (uint)(config.listLength > 1 ? config.list(1) : 0);
        }
    }



	/// <summary>
	/// 战场投票状态
	/// </summary>
	public struct BattleVoteStatus
	{
		/// <summary>
		/// 投票类型
		/// </summary>
		public int voteType;
		/// <summary>
		/// 同意人数
		/// </summary>
		public uint agreeCount;
		/// <summary>
		/// 总人数
		/// </summary>
		public uint totalCount;
		/// <summary>
		/// 发起投票的阵营
		/// </summary>
		public int campType;
		/// <summary>
		/// 投票最终结果
		/// </summary>
		public bool result;
	}



	/// <summary>
	/// 空投道具信息
	/// </summary>
	public struct BattleItemInfo
	{
		/// <summary>
		/// 道具id
		/// </summary>
		public ulong id;
		/// <summary>
		/// 道具名称
		/// </summary>
		public string name;
		/// <summary>
		/// 图标路径
		/// </summary>
		public string icon;



		public BattleItemInfo(ItemTableBase value)
		{
			this.id = (ulong)value.id;
			this.name = value.name;
			this.icon = value.icon;
		}
	}
}
