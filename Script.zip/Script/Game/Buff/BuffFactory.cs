﻿using System;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// buff的工厂
    /// </summary>
    public class BuffFactory : ClientSingleton<BuffFactory>
    {
        private ObjectPool<BuffBase> m_BuffPool = new ObjectPool<BuffBase>();

        public BuffBase CreateBuff(SkillBuffTableBase _config,swm.Buff _buf)
        {
            BuffBase buffBase = m_BuffPool.Get();
//             if (!String.IsNullOrEmpty(_config.special_class))//_config.special_class != null && _config.special_class != "" )
//             {
//                 Type t = Type.GetType(_config.special_class);//"Game.BuffBase");
//                 if (t != null)
//                 {
//                     buffBase = Activator.CreateInstance(t) as BuffBase;
//                 }
//             }
// 
//             if (null == buffBase)
//             {
//                 buffBase = new BuffBase();
//             }
            buffBase.Init(_config, _buf);
            return buffBase;
        }

        public void ReleaseBuff(BuffBase buf)
        {
            buf.Reset();
            m_BuffPool.Release(buf);
        }

        private ObjectPool<BuffProxy> m_BuffProxyPool = new ObjectPool<BuffProxy>();

        public BuffProxy CreateBuffProxy(Entity owner)
        {
            BuffProxy buffProxy = m_BuffProxyPool.Get();
            buffProxy.Init(owner);
            return buffProxy;
        }

        public void ReleaseBuffProxy(BuffProxy buffProxy)
        {
            buffProxy.Reset();
            m_BuffProxyPool.Release(buffProxy);
        }
    }
}
