
using System.Collections.Generic;

namespace Bokura
{
    /// <summary>
    /// buff收发数据 单键
    /// </summary>
    public class BuffModel : ClientSingleton<BuffModel>
    {

        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyAddBuff>(ProcNotifyAddBuff);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyRemoveBuff>(ProcNotifyRemoveBuff);
            //MsgDispacther.instance.RegisterMsgProc<x2m.RefreshBuff>(ProcNotifyRefreshBuff);
        }

        public void Clear()
        {

        }

        [XLua.BlackList]
        public void ProcNotifyAddBuff(swm.NotifyAddBuff msg)
        {
            if(msg.buffsLength > 0)
            {
                Entity entity = GameScene.Instance.GetEntityByID(msg.entity_id) as Entity;
                if (entity != null)
                {
                    if(msg.refresh_all)
                    {
                        //true 的话 服务端说是清除
                        entity.BuffProxy.RemoveAllCurrentBuff();
                    }

                    for (int i = 0; i < msg.buffsLength; i++)
                    {
                        var buf = msg.buffs(i).Value;
                        entity.BuffProxy.AddBuff(buf);
                    }
                }


                // 测试
                //if (entity != null && entity.BuffProxy.BuffList.Count > 0)
                //{
                //    Bokura.LogHelper.Log(Bokura.LogCategory.WeTest, "-----------------------------------------------");
                //    foreach (var iter in entity.BuffProxy.BuffList)
                //    {
                //        if (iter.Value == null)
                //            continue;

                //        Bokura.LogHelper.Log(Bokura.LogCategory.WeTest, "ProcNotifyAddBuff : ", iter.Key, " ", iter.Value.baseid);
                //    }
                //    Bokura.LogHelper.Log(Bokura.LogCategory.WeTest, "-----------------------------------------------");
                //}
            }
        }

        void ProcNotifyRemoveBuff(swm.NotifyRemoveBuff msg)
        {
            Entity entity = GameScene.Instance.GetEntityByID( msg.entity_id) as Entity;
            if (entity != null)
            {
                entity.BuffProxy.RemoveBuff(msg.buff_id);
            }

            // 测试
            //if (entity != null && entity.BuffProxy.BuffList.Count > 0)
            //{
            //    Bokura.LogHelper.Log(Bokura.LogCategory.WeTest, "-----------------------------------------------");
            //    foreach (var iter in entity.BuffProxy.BuffList)
            //    {
            //        if (iter.Value == null)
            //            continue;

            //        Bokura.LogHelper.Log(Bokura.LogCategory.WeTest, "NotifyRemoveBuff : ", iter.Key, " ", iter.Value.baseid);
            //    }
            //    Bokura.LogHelper.Log(Bokura.LogCategory.WeTest, "-----------------------------------------------");
            //}
        }

        //void ProcNotifyRefreshBuff(x2m.RefreshBuff msg)
        //{
        //    if (msg.buffs.Count > 0)
        //    {
        //        for (int i = 0; i < msg.buffs.Count; i++)
        //        {
        //            x2m.Buff buf = msg.buffs[i];
        //            Entity entity = GameScene.Instance.GetEntityByID(buf.target.entity_type, buf.target.entity_id) as Entity;
        //            if (entity != null)
        //            {
        //                entity.BuffProxy.RefreshBuff(buf);
        //            }
        //        }
        //    }
        //}

        public void SendDeleteBuff(uint _id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqRemoveBuff.StartReqRemoveBuff(fbb);
            swm.ReqRemoveBuff.AddId(fbb, _id);
            fbb.Finish(swm.ReqRemoveBuff.EndReqRemoveBuff(fbb).Value);
            //swm.ReqRemoveBuff _msg = new x2m.ReqRemoveBuff();
            //_msg.id = _id;
            MsgDispatcher.instance.SendFBPackage(swm.ReqRemoveBuff.HashID, fbb) ;
        }
    }
}
