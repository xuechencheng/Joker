using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 实体buff的委托
    /// </summary>
    public class BuffProxy
    {
        private Dictionary<uint, BuffBase> m_buffList;

        public class BuffAddEvent : GameEvent<BuffBase>
        {

        }

        public class BuffRefreshEvent : GameEvent<BuffBase>
        {

        }

        public class BuffRemoveEvent : GameEvent<uint>
        {

        }

        public GameEvent<BuffBase> onAddBuff = new BuffAddEvent();
        public GameEvent<BuffBase> onRefreshBuff = new BuffRefreshEvent();
        public GameEvent<BuffBase> onRemoveBuff = new BuffAddEvent();

		int[] m_buffFlags = new int[(int)swm.BuffType.Count];
        int m_buffImmunity = 0;


        Entity m_owner;
        public Dictionary<uint, BuffBase> BuffList
        {
            get
            {
                return m_buffList;
            }
        }

        [XLua.BlackList]
        public BuffProxy()
        {
            m_buffList = new Dictionary<uint, BuffBase>((int)swm.BuffType.Count);
        }

        [XLua.BlackList]
        public void Init(Entity owner)
        {
            m_owner = owner;
        }

        public bool EffectVisible
        {
            set
            {
                foreach(var kv in m_buffList)
                {
                    kv.Value.EffectVisible = value;
                }
            }
        }

        /// <summary>
        /// 消亡
        /// </summary>
        public void Destory()
        {
            DeleteAllBuff();
        }

        public void Update()
        {
            foreach (var _base in m_buffList)
            {
                _base.Value.Update();
            }
        }

		public int GetBuffOverlapCountByBaseID(int baseid)
		{
			int ncount = 0;
			foreach (var _base in m_buffList)
			{
				if(_base.Value.Buf.baseid == baseid)
				{
					ncount += (int)_base.Value.Buf.overlay;
				}
			}
			return ncount;
		}

		void AddFlag(int flag)
		{
			for(int i = 0; i < (int)swm.BuffType.Count; i ++  )
			{
				if((flag& (1<<i))!=0)
				{
					m_buffFlags[i]++;
				}
			}
		}
		void RemoveFlag(int flag)
		{
			for (int i = 0; i < (int)swm.BuffType.Count; i++)
			{
				if ((flag & (1 << i)) != 0)
				{
					m_buffFlags[i]--;
				}
			}
		}

		public bool HaveBuffType(swm.BuffType bufftype)
		{
			return m_buffFlags[(int)bufftype] > 0;
		}

        public bool HaveImmunityBuff(swm.BuffType bufftype)
        {
            return (m_buffImmunity & (1<<(int)bufftype)) != 0;
        }

        void RefreshImmunity()
        {
            m_buffImmunity = 0;
            foreach(var kv in m_buffList)
            {
                m_buffImmunity |= kv.Value.SkillBuffConfig.immunity_type;
            }
        }

        /// <summary>
        /// 是否包含buff
        /// </summary>
        /// <param name="buffid"></param>
        /// <returns></returns>
        public bool ContainBuff(uint buffid)
        {
            foreach (var iter in m_buffList)
            {
                BuffBase buff = iter.Value;
                if (buff == null)
                    continue;

                if (buff.baseid == buffid)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// 增加buff
        /// </summary>
        public void AddBuff(swm.Buff _buf)
        {
            //if(_buf == null)
            //{
            //    return;
            //}
            var _config = SkillBuffTableManager.GetData((int)(_buf.baseid));
            if(_config != null)
            {
               BuffBase bBase = null;
                if (m_buffList.TryGetValue(_buf.id, out bBase))
                {
                    //已经存在 那就刷新
                    bBase.RefreshBuff(_buf);
					onRefreshBuff.Invoke(bBase);
                }
                else
                {
                    bBase = BuffFactory.Instance.CreateBuff(_config.Value, _buf);
					bBase.Owner = m_owner;

					bBase.PlayEffect();
                    m_buffList[_buf.id] = bBase;
                    RefreshImmunity();
                    onAddBuff.Invoke(bBase);
					AddFlag(_config.Value.type);

   

                }
               

			}
            else
            {
                LogHelper.LogWarning("AddBuff config not exist id : ", _buf.baseid.ToString(), "level :", _buf.level.ToString(), "failed!");
            }
        }

        /// <summary>
        /// 移除buff
        /// </summary>
        public void RemoveBuff(uint _id)
        {
            BuffBase _base = null;
            if (m_buffList.TryGetValue(_id, out _base))
            {
                if (_base != null)
                {
					RemoveFlag(_base.SkillBuffConfig.type);

                    _base.PlayEndEffect();
                    m_buffList.Remove(_id);
                    
                    RefreshImmunity();
                    onRemoveBuff.Invoke(_base);
                    BuffFactory.Instance.ReleaseBuff(_base);
                    
                }
				
            }

        }

        private List<uint> m_tmpRemoveAllList = new List<uint>(Bokura.ConstValue.kCap16);
        [XLua.BlackList]
        public void RemoveAllCurrentBuff()
        {
            m_tmpRemoveAllList.Clear();
            foreach (var _base in m_buffList)
            {
                m_tmpRemoveAllList.Add(_base.Key);
            }
            for(int i=0;i< m_tmpRemoveAllList.Count;i++)
            {
                RemoveBuff(m_tmpRemoveAllList[i]);
            }
            m_tmpRemoveAllList.Clear();
        }

        /// <summary>
        /// 更新buff
        /// </summary>
        public void RefreshBuff( swm.Buff _buf)
        {
            BuffBase _base = null;
            if (m_buffList.TryGetValue(_buf.id, out _base))
            {

                if (_base != null)
                {
                    _base.RefreshBuff(_buf);
                    onRefreshBuff.Invoke(_base);
                }
            }

        }

        /// <summary>
        /// 删除全部buff
        /// </summary>
        public void DeleteAllBuff()
        {
            foreach (var _base in m_buffList)
            {
                _base.Value.Destory();
                BuffFactory.Instance.ReleaseBuff(_base.Value);
            }
            m_buffList.Clear();
        }


        public void ModelChangelResetBuff()
        {
            foreach (var _base in m_buffList)
            {
                _base.Value.PlayEffect();
            }
        }

        public BuffBase GetTransformationPath()
        {
            if (m_buffList.Count > 0)
            {
                string _p;
                foreach (var _v in m_buffList)
                {
                    _p = _v.Value.SkillBuffConfig.model;
                    if(!string.IsNullOrEmpty(_p))
                    {
                        return _v.Value;
                    }
                }
            }
            return null;
        }

        [XLua.BlackList]
        public void Reset()
        {
            if (m_buffList != null)
                DeleteAllBuff();
            onAddBuff.RemoveAllListeners();
            onRefreshBuff.RemoveAllListeners();
            onRemoveBuff.RemoveAllListeners();
            for (int i = 0; i < m_buffFlags.Length; i++)
                m_buffFlags[i] = 0;
            m_buffImmunity = 0;
            m_owner = null;
        }
    }
}
