using UnityEngine;
using System;
using Bokura;
using UnityEngine.Rendering.LWRP;

namespace Bokura
{
    public class BuildCityBuilding : AvatarEvent
    {
        private IAvatar m_avatar;   //建筑Avatar
        private IAvatar m_scaffold; //脚手架Avatar
        private Vector3 m_position = Vector3.zero;
        private BuildCityModelBase? modelConfig;
        private BuildCityTableBase? landConfig;
        private BuildCityModelData modelData;
        private readonly char[] pathBreak = new char[] { ':' };
        private float m_eulerY = 0; //Y轴旋转角度
        private float m_scale = 1;  //模型缩放比例
        private string m_modelPath = string.Empty;
        private float m_scaffoldEulerY = 0; //脚手架Y轴旋转角度
        private float m_scaffoldScale = 1;  //脚手架缩放比例
        private string m_scaffoldPath = string.Empty;
        private bool m_IsScaffoldLoad = false;

        public BuildCityBuilding()
        {
            
        }

        public void Init()
        {
            m_avatar = IFactory.Instance.CreateAvatar(this);
            m_avatar.onCreate.AddListener(AvatarCreateDelegate);
            m_avatar.shadowType = AvatarShadowType.Decal;
        }

        public void CreateBuilding(BuildCityModelData _modelData)
        {
            modelData = _modelData;
            InitConfig(_modelData.ModelId);
            if (modelData.State == swm.LandState.Building || modelData.State == swm.LandState.LevelUp)
            {
                LoadBuildingModel(modelData.ModelId, modelData.BuildProgress);
                if (!m_IsScaffoldLoad)
                    LoadScaffoldModel(modelData.ModelId);
            }
            else if (modelData.State == swm.LandState.BuildDone || modelData.State == swm.LandState.LevelUpDone)
            {
                LoadBuildDoneModel(modelData.ModelId);
                if (!m_IsScaffoldLoad)
                    LoadScaffoldModel(modelData.ModelId);
            }
            else
            {
                LoadModel(modelData.ModelId);
                if (m_IsScaffoldLoad)
                    UnloadScaffoldModel();
            }
            landConfig = BuildCityTableManager.GetData((int)modelData.LandId);
            if (landConfig.HasValue)
                Position = UnityEngine.UI.Giant.UIUtility.ParseVector3(landConfig.Value.location);
        }

        void AvatarCreateDelegate()
        {
            m_avatar.unityObject.transform.localEulerAngles = new Vector3(0, m_eulerY, 0);
            m_avatar.unityObject.transform.localScale = new Vector3(m_scale, m_scale, m_scale);
            if (modelData != null)
                m_avatar.unityObject.name = m_avatar.unityObject.name + "_" + modelData.LandId.ToString();
            m_avatar.unityObject.LSMEnable(0);
            m_avatar.SetLayer((int)UserLayer.Layer_StaticMeshBig);
            OnAvatarLoaded.Invoke();
        }

        void ScaffoldCreateDelegate()
        {
            m_scaffold.unityObject.transform.localEulerAngles = new Vector3(0, m_scaffoldEulerY, 0);
            m_scaffold.unityObject.transform.localScale = new Vector3(m_scaffoldScale, m_scaffoldScale, m_scaffoldScale);
            m_scaffold.SetLayer((int)UserLayer.Layer_StaticMeshBig);
        }

        public void InitConfig(uint ModelId)
        {
            modelConfig = BuildCityModelManager.GetData((int)ModelId);
        }

        public void LoadModel(uint ModelId)
        {
            if (modelConfig.HasValue)
            {
                loadModelPath(modelConfig.Value.model);
            }
        }

        /// <summary>
        /// 加载建造中的模型
        /// </summary>
        /// <param name="ModelId"></param>
        public void LoadBuildingModel(uint ModelId, int progress)
        {
            if (modelConfig.HasValue)
            {
                string modelPath = BuildCityManager.Instance.BuildingManager.GetBuildingModelPath(ModelId, progress);
                loadModelPath(modelPath);
            }
        }

        /// <summary>
        /// 加载建造完成的模型
        /// </summary>
        /// <param name="ModelId"></param>
        public void LoadBuildDoneModel(uint ModelId)
        {
            if (modelConfig.HasValue)
            {
                string modelPath = BuildCityManager.Instance.BuildingManager.GetBuildingModelPath(ModelId, 100);
                loadModelPath(modelPath);
            }
        }

        private void loadModelPath(string _modelPath)
        {
            if (!string.IsNullOrEmpty(_modelPath))
            {
                m_modelPath = _modelPath;
                string[] config_path = _modelPath.Split(pathBreak, StringSplitOptions.RemoveEmptyEntries);
                if (config_path.Length == 4)
                {
                    m_eulerY = float.Parse(config_path[2]);
                    m_scale = float.Parse(config_path[3]);
                    m_avatar.LoadModel(config_path[0], config_path[1], false);
                    m_avatar.Visible = true;
                }
                else
                    LogHelper.LogError("无效的自建城建筑外观配置. path=" + _modelPath);
            }
        }

        /// <summary>
        /// 加载脚手架模型
        /// </summary>
        /// <param name="ModelId"></param>
        private void LoadScaffoldModel(uint ModelId)
        {
            if (modelConfig.HasValue)
            {
                m_scaffoldPath = modelConfig.Value.mid_model;
                if (!string.IsNullOrEmpty(m_scaffoldPath))
                {
                    string[] config_path = m_scaffoldPath.Split(pathBreak, StringSplitOptions.RemoveEmptyEntries);
                    if (config_path.Length == 4)
                    {
                        m_scaffoldEulerY = float.Parse(config_path[2]);
                        m_scaffoldScale = float.Parse(config_path[3]);
                        if (m_scaffold == null)
                        {
                            m_scaffold = IFactory.Instance.CreateAvatar(this);
                            m_scaffold.onCreate.AddListener(ScaffoldCreateDelegate);
                            m_scaffold.shadowType = AvatarShadowType.Decal;
                        }
                        m_scaffold.LoadModel(config_path[0], config_path[1], false);
                        m_scaffold.Visible = true;
                        m_IsScaffoldLoad = true;
                    }
                    else
                        LogHelper.LogError("无效的自建城建筑脚手架外观配置. path=" + m_scaffoldPath);
                }
            }
        }

        private void UnloadScaffoldModel()
        {
            if (m_scaffold != null)
            {
                m_scaffold.Release();
                IFactory.Instance.ReleaseAvatar(m_scaffold);
                m_scaffold = null;
            }
            m_scaffoldEulerY = 0;
            m_scaffoldScale = 1;
            m_scaffoldPath = string.Empty;
            m_IsScaffoldLoad = false;
        }

        /// <summary>
        /// 服务器推送刷新建筑外观消息时判断是否需要加载新外观
        /// </summary>
        /// <param name="_modelData"></param>
        /// <returns></returns>
        public bool CheckChangeBuildingModel(BuildCityModelData _modelData)
        {
            string _modelPath = string.Empty;
            if (_modelData.State == swm.LandState.Building || _modelData.State == swm.LandState.LevelUp)
                _modelPath = BuildCityManager.Instance.BuildingManager.GetBuildingModelPath(_modelData.ModelId, _modelData.BuildProgress);
            else if (modelData.State == swm.LandState.BuildDone || modelData.State == swm.LandState.LevelUpDone)
                _modelPath = BuildCityManager.Instance.BuildingManager.GetBuildingModelPath(_modelData.ModelId, 100);
            else
            {
                BuildCityModelBase? _config = BuildCityModelManager.GetData((int)_modelData.ModelId);
                if (_config.HasValue)
                    _modelPath = _config.Value.model;
            }
            if (!string.IsNullOrEmpty(_modelPath) && !_modelPath.Equals(m_modelPath))
                return true;
            return false;
        }

        public void RefreshBuilding(BuildCityModelData _modelData)
        {
            if (m_avatar != null)
            {
                if (m_avatar.unityObject != null)
                    m_avatar.unityObject.LSMDisable();
                m_avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_avatar);
                m_avatar = null;
            }
            Init();
            CreateBuilding(_modelData);
        }

        public IAvatar Avatar
        {
            get { return m_avatar; }
        }

        public Vector3 Position
        {
            get { return m_position; }
            set
            {
                m_position = value;
                if (m_avatar != null)
                    m_avatar.SetPosition(m_position);
                if (m_scaffold != null)
                    m_scaffold.SetPosition(m_position);
            }
        }

        public void Release()
        {
            if (m_avatar != null)
            {
                if (m_avatar.unityObject != null)
                    m_avatar.unityObject.LSMDisable();
                m_avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_avatar);
                m_avatar = null;
            }
            m_position = Vector3.zero;
            modelConfig = null;
            landConfig = null;
            modelData = null;
            m_eulerY = 0;
            m_scale = 1;
            m_modelPath = string.Empty;
            m_OnAvatarLoaded.RemoveAllListeners();
            if (m_scaffold != null)
            {
                m_scaffold.Release();
                IFactory.Instance.ReleaseAvatar(m_scaffold);
                m_scaffold = null;
            }
            m_scaffoldEulerY = 0;
            m_scaffoldScale = 1;
            m_scaffoldPath = string.Empty;
            m_IsScaffoldLoad = false;
        }

        private GameEvent m_OnAvatarLoaded = new GameEvent();
        public GameEvent OnAvatarLoaded
        {
            get { return m_OnAvatarLoaded; }
        }

        public swm.LandState State
        {
            get { return modelData.State; }
            set { modelData.State = value; }
        }

        /// <summary>
        /// 播放建造完成特效
        /// </summary>
        public void PlayCompleteEffect()
        {
            //临时特效播放方案
            if (modelData.ModelId == 1)
            {
                var effect = EffectMgr.Instance.Play("fx_cj_zjc_fangwuluodi_s", m_avatar.unityObject.transform.position, IResourceLoader.strSceneEffectPath, false);
                GameApplication.Instance.GetTimerManager().AddTimer(delegate ()
                {
                    effect.Stop();
                }, 3.5f);
            }
            else if (modelData.ModelId == 2)
            {
                var effect = EffectMgr.Instance.Play("fx_cj_zjc_fangwuluodi2_s", m_avatar.unityObject.transform.position, IResourceLoader.strSceneEffectPath, false);
                GameApplication.Instance.GetTimerManager().AddTimer(delegate ()
                {
                    effect.Stop();
                }, 3.5f);
            }
            else
            {
                var effect = EffectMgr.Instance.Play("fx_cj_zjc_fangwuluodi_s", m_avatar.unityObject.transform.position, IResourceLoader.strSceneEffectPath, false);
                GameApplication.Instance.GetTimerManager().AddTimer(delegate ()
                {
                    effect.Stop();
                }, 3.5f);
            }
        }
    }
}