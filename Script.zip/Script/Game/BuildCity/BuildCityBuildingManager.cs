﻿using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public class BuildCityBuildingManager
    {
        private int m_curCityId;
        public int CityId
        {
            get { return m_curCityId; }
        }

        private Dictionary<int, List<IntString>> m_buildingModelListMap = new Dictionary<int, List<IntString>>(8);
        public void Init()
        {
            GameScene.Instance.onBeginLoading.AddListener(OnBeginLoading);
            GameScene.Instance.onEndLoading.AddListener(OnEndLoading);
            //GameScene.Instance.onMainCharCreated.AddListener(delegate ()
            //{
            //    GameScene.Instance.MainChar.onPositionChangeEvent.RemoveListener(OnMainCharMove);
            //    GameScene.Instance.MainChar.onPositionChangeEvent.AddListener(OnMainCharMove);
            //});
            BuildCityManager.Instance.onAddCityBuildings.AddListener(CreateCurCityBuildings);
            LayeredSceneLoader.OnWorldMove.AddListener(OnWorldMove);
        }

        public void Load()
        {
            m_buildingModelListMap.Clear();
            for (int i = 0; i < BuildCityModelManager.Instance.m_DataList.BuildCityModelLength; i++)
            {
                var configData = BuildCityModelManager.Instance.m_DataList.BuildCityModel(i);
                List<IntString> modelPathList = new List<IntString>(5);
                for (int j = 0; j < configData.Value.mid_building_modelLength; j++)
                {
                    var tModelData = configData.Value.mid_building_model(j);
                    modelPathList.Add(tModelData.Value);
                }
                modelPathList.Sort((left, right) =>
                {
                    return left.key.CompareTo(right.key);
                });
                m_buildingModelListMap.Add(configData.Value.id, modelPathList);
            }
        }

        public void Clear()
        {
            m_curCityId = 0;
            DeleteCurCityBuildings();
        }

        private void OnBeginLoading()
        {
            if (GameScene.Instance.MainChar != null)
                GameScene.Instance.MainChar.onPositionChangeEvent.RemoveListener(OnMainCharMove);
        }

        private void OnEndLoading()
        {
            CheckUpdateCityBuildings();
            if (GameScene.Instance.MainChar != null)
                GameScene.Instance.MainChar.onPositionChangeEvent.AddListener(OnMainCharMove);
        }

        private void OnMainCharMove()
        {
            CheckUpdateCityBuildings();
        }

        private void OnWorldMove(UnityEngine.Vector3 newOffset, UnityEngine.Vector3 delta)
        {
            m_curCityId = 0;
            DeleteCurCityBuildings();
        }

        private void CheckUpdateCityBuildings()
        {
            var tMainChar = GameScene.Instance.MainChar;
            if (null != tMainChar && GameScene.Instance.IsInWorldMap)
            {
                int tPosX = (int)tMainChar.Position.x;
                int tPosZ = (int)tMainChar.Position.z;

                int inCityId = 0;
                int length = BuildCityLocationManager.Instance.m_DataList.BuildCityLocationLength;
                for (int i = 0; i < length; i++)
                {
                    var data = BuildCityLocationManager.Instance.m_DataList.BuildCityLocation(i);
                    if (data.HasValue && CheckIsInCityRect(tPosX, tPosZ, data.Value))
                    {
                        inCityId = data.Value.id;
                        break;
                    }
                }
                if (inCityId != 0)
                {
                    if (inCityId != m_curCityId)
                    {
                        if (m_curCityId != 0)
                        {
                            DeleteCurCityBuildings();
                        }
                        m_curCityId = inCityId;
                        BuildCityManager.Instance.SendReqCityLandAppearance((uint)m_curCityId);
                    }
                }
                else
                {
                    if (m_curCityId != 0)
                    {
                        BuildCityLocationBase? curCityConfig = BuildCityLocationManager.GetData(m_curCityId);
                        if (CheckRemoveCityBuilding(tPosX, tPosZ, curCityConfig.Value))
                        {
                            DeleteCurCityBuildings();
                            m_curCityId = 0;
                        }
                    }
                }
            }
            else if (!GameScene.Instance.IsInWorldMap && m_curCityId != 0)
            {
                DeleteCurCityBuildings();
                m_curCityId = 0;
            }
        }

        /// <summary>
        /// 判断是否在城市范围内
        /// </summary>
        /// <param name="posX"></param>
        /// <param name="posY"></param>
        /// <param name="config"></param>
        /// <returns></returns>
        private bool CheckIsInCityRect(int posX, int posY, BuildCityLocationBase config)
        {
            double tStartPosX = config.zx_location(0);
            double tStartPosY = config.zx_location(1);
            double tWidth = config.length_wide(0);
            double tHeight = config.length_wide(1);
            return (posX > tStartPosX && posX < tStartPosX + tWidth && posY > tStartPosY && posY < tStartPosY + tHeight);
        }

        /// <summary>
        /// 离开城市超过此距离删除建筑物
        /// </summary>
        private readonly double remove_distance = 10.0f;
        /// <summary>
        /// 判断是否删除城市建筑
        /// </summary>
        /// <param name="posX"></param>
        /// <param name="posY"></param>
        /// <param name="config"></param>
        /// <returns></returns>
        private bool CheckRemoveCityBuilding(int posX, int posY, BuildCityLocationBase config)
        {
            double tStartPosX = config.zx_location(0);
            double tStartPosY = config.zx_location(1);
            double tWidth = config.length_wide(0);
            double tHeight = config.length_wide(1);
            return (posX < tStartPosX - remove_distance || posX > tStartPosX + tWidth + remove_distance
                || posY < tStartPosY - remove_distance || posY > tStartPosY + tHeight + remove_distance);
        }

        private Dictionary<uint, BuildCityBuilding> BuildingEntitesMap = new Dictionary<uint, BuildCityBuilding>(25);
        private ObjectPool<BuildCityBuilding> BuildingEntityPool = new ObjectPool<BuildCityBuilding>();
        private void CreateCurCityBuildings()
        {
            var buildingDataMap = BuildCityManager.Instance.BuildingDataMap;
            var e = buildingDataMap.GetEnumerator();
            while (e.MoveNext())
            {
                var landId = e.Current.Key;
                if (BuildingEntitesMap.ContainsKey(landId))
                {
                    BuildingEntitesMap[landId].Release();
                    BuildingEntityPool.Release(BuildingEntitesMap[landId]);
                    BuildingEntitesMap.Remove(landId);
                }
                BuildCityBuilding buildingEntity = BuildingEntityPool.Get();
                buildingEntity.Init();
                buildingEntity.CreateBuilding(e.Current.Value);
                BuildingEntitesMap.Add(landId, buildingEntity);
            }
        }

        private void DeleteCurCityBuildings()
        {
            var e = BuildingEntitesMap.GetEnumerator();
            while (e.MoveNext())
            {
                e.Current.Value.Release();
                BuildingEntityPool.Release(e.Current.Value);
            }
            BuildingEntitesMap.Clear();
            BuildCityManager.Instance.onRemoveCityBuildings.Invoke();
        }

        /// <summary>
        /// 刷新地块建筑
        /// </summary>
        /// <param name="landId"></param>
        public void RefreshLandBuilding(uint landId)
        {
            var buildingDataMap = BuildCityManager.Instance.BuildingDataMap;
            if (buildingDataMap.ContainsKey(landId))
            {
                if (BuildingEntitesMap.ContainsKey(landId))
                {
                    BuildingEntitesMap[landId].PlayCompleteEffect();
                    BuildingEntitesMap[landId].RefreshBuilding(buildingDataMap[landId]);
                }
                else
                {
                    BuildCityBuilding buildingEntity = BuildingEntityPool.Get();
                    buildingEntity.Init();
                    buildingEntity.OnAvatarLoaded.AddListener(delegate ()
                    {
                        buildingEntity.PlayCompleteEffect();
                    });
                    buildingEntity.CreateBuilding(buildingDataMap[landId]);
                    BuildingEntitesMap.Add(landId, buildingEntity);
                }
            }
        }

        /// <summary>
        /// 服务器推送刷新建筑外观消息时判断是否需要加载新外观
        /// </summary>
        /// <param name="landId"></param>
        public bool CheckChangeLandBuilding(uint landId)
        {
            var buildingDataMap = BuildCityManager.Instance.BuildingDataMap;
            if (buildingDataMap.ContainsKey(landId))
            {
                var buildingData = buildingDataMap[landId];
                if (BuildingEntitesMap.ContainsKey(landId))
                {
                    var buildingEntity = BuildingEntitesMap[landId];
                    if (buildingEntity.CheckChangeBuildingModel(buildingData))
                    {
                        buildingEntity.PlayCompleteEffect();
                        buildingEntity.RefreshBuilding(buildingData);
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 获取地块建筑建造中模型
        /// </summary>
        /// <returns></returns>
        public string GetBuildingModelPath(uint modelId, int progress)
        {
            int key = (int)modelId;
            if (m_buildingModelListMap.ContainsKey(key))
            {
                var list = m_buildingModelListMap[key];
                for (int i = 0; i < list.Count; i++)
                {
                    if (progress <= list[i].key)
                        return list[i].value;
                }
            }
            return string.Empty;
        }
    }
}