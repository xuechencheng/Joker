using System;
using System.Collections.Generic;
using Bokura;
using swm;

namespace Bokura
{
    /// <summary>
    /// 地块基础信息
    /// </summary>
    public class BuildCityLandBaseData
    {
        /// <summary>
        /// 地块id
        /// </summary>
        public uint Id;

        /// <summary>
        /// 地块等级
        /// </summary>
        public uint Level;

        /// <summary>
        /// 拥有地块的仙门id，没有所有者则为0
        /// </summary>
        public ulong SeptId;
        
        /// <summary>
        /// 城市id
        /// </summary>
        public uint CityId;

        /// <summary>
        /// 地块类型
        /// </summary>
        public LandType Type = default(LandType);

        /// <summary>
        /// 地块的状态
        /// </summary>
        public LandState State = default(LandState);

        /// <summary>
        /// 开始拍卖的时间
        /// </summary>
        public string AuctionStartTime;
        
        /// <summary>
        /// 结束拍卖的时间
        /// </summary>
        public string AuctionEndTime;

        /// <summary>
        /// 拍卖价格
        /// </summary>
        public uint AuctionPrice;

        /// <summary>
        /// 拥有地块的仙门名字
        /// </summary>
        public string SeptName = string.Empty;

        /// <summary>
        /// 仙门购得地块的花费
        /// </summary>
        public uint BuyPrice;

        /// <summary>
        /// 仙门转让地块的花费
        /// </summary>
        public uint SellPrice;

        /// <summary>
        /// 地块配置
        /// </summary>
        private BuildCityTableBase? config;

        /// <summary>
        /// 地块位置坐标
        /// </summary>
        public UnityEngine.Vector3 LocationPos;

        /// <summary>
        /// 初始等级
        /// </summary>
        public int StartLevel;

        /// <summary>
        /// 最大等级
        /// </summary>
        public uint MaxLevel;

        /// <summary>
        /// 设置基础信息
        /// </summary>
        /// <param name="msg"></param>
        [XLua.BlackList]
        public void InitBaseDataFromMsg(RspLandBaseInfo msg)
        {
            Id = msg.land_id;
            Level = msg.level;
            SeptId = msg.sept_id;
            CityId = msg.city_id;
            Type = msg.land_type;
            State = msg.land_state;
            config = BuildCityTableManager.GetData((int)Id);
            if (config.HasValue)
            {
                LocationPos = UnityEngine.UI.Giant.UIUtility.ParseVector3(config.Value.location);
                StartLevel = config.Value.level;
                MaxLevel = (uint)config.Value.max_level;
            }
            else
                LogHelper.LogWarning("获取地块配置失败.Id=" + Id.ToString());
        }

        /// <summary>
        /// 设置拍卖信息
        /// </summary>
        /// <param name="msg"></param>
        [XLua.BlackList]
        public void InitAuctionFromMsg(RspViewAuctionInfo msg)
        {
            DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            TimeSpan toStart = new TimeSpan((long)msg.start_time * 10000);
            DateTime tStart = tInit.Add(toStart);
            AuctionStartTime = tStart.ToString("yyyy/MM/dd");
            TimeSpan toEnd = new TimeSpan((long)msg.end_time * 10000);
            DateTime tEnd = tInit.Add(toEnd);
            AuctionEndTime = tEnd.ToString("yyyy/MM/dd");
            AuctionPrice = msg.sell_price;
        }

        /// <summary>
        /// 设置可查看信息
        /// </summary>
        /// <param name="msg"></param>
        [XLua.BlackList]
        public void InitViewInfoFromMsg(RspViewLandInfo msg)
        {
            SeptName = msg.sept_name;
            BuyPrice = msg.buy_price;
            SellPrice = msg.sell_price;
        }
    }

    /// <summary>
    /// 民用地块信息
    /// </summary>
    public class BuildCityCivilLandData
    {
        /// <summary>
        /// 地块信息
        /// </summary>
        public BuildCityLandBaseData BaseData;
        
        /// <summary>
        /// 民用地块配置
        /// </summary>
        private BuildCityCivilBase? config;

        /// <summary>
        /// 当前建造中等级
        /// </summary>
        public uint BuildLevel;

        /// <summary>
        /// 当前建造中的捐赠物列表
        /// </summary>
        public List<BuildCityDonatedData> DonatedItemList = new List<BuildCityDonatedData>(3);

        /// <summary>
        /// 当前等级需要的捐赠物列表
        /// </summary>
        public List<BuildCityDonatedData> DonatedNeedList = new List<BuildCityDonatedData>(3);

        /// <summary>
        /// 修改外观次数
        /// </summary>
        public uint ChangeModelCount;

        /// <summary>
        /// 外观状态列表
        /// </summary>
        public List<BuildCityModelStateData> ModelStateList = new List<BuildCityModelStateData>(8);

        /// <summary>
        /// 升级可使用的外观列表
        /// </summary>
        public List<BuildCityModelStateData> NextLevelModelStateList = new List<BuildCityModelStateData>(4);

        /// <summary>
        /// 当前使用的外观id
        /// </summary>
        public uint ModelId;

        /// <summary>
        /// 洞府id列表
        /// </summary>
        private List<uint> HouseIdList = new List<uint>(2);

        /// <summary>
        /// 洞府数量
        /// </summary>
        private Dictionary<uint, uint> HouseDic = new Dictionary<uint, uint>(2);

        [XLua.BlackList]
        public void InitBaseDataFromMsg(RspLandBaseInfo msg)
        {
            BaseData = new BuildCityLandBaseData();
            BaseData.InitBaseDataFromMsg(msg);
            if (BaseData.State == LandState.Empty || BaseData.State == LandState.Building || BaseData.State == LandState.BuildDone)
                RefreshBuildlevelNeedList((uint)BaseData.StartLevel);
            else if (BaseData.State == LandState.LevelUp || BaseData.State == LandState.LevelUpDone)
            {
                if (BaseData.Level < BaseData.MaxLevel)
                    RefreshBuildlevelNeedList(BaseData.Level + 1);
            }
            ModelStateList.Clear();
            int length = BuildCityModelManager.Instance.m_DataList.BuildCityModelLength;
            for (int i = 0; i < length; i++)
            {
                var data = BuildCityModelManager.Instance.m_DataList.BuildCityModel(i);
                if (data.HasValue && data.Value.type == 1)
                {
                    BuildCityModelStateData modelData = new BuildCityModelStateData(data.Value);
                    if (data.Value.level <= BaseData.Level)
                        modelData.IsUnlock = true;
                    modelData.IsBuy = false;
                    ModelStateList.Add(modelData);
                }
            }
            SortModelList();
            InitNextLevelModel();
            UpdateLandLevel(BaseData.Level);
        }

        public uint GetHouseCount(int index)
        {
            if (index < HouseIdList.Count)
            {
                uint id = HouseIdList[index];
                if (HouseDic.ContainsKey(id))
                    return HouseDic[id];
            }
            return 0;
        }

        [XLua.BlackList]
        public void UpdateLandLevel(uint level)
        {
            BaseData.Level = level;
            if (BaseData.State == LandState.None || BaseData.State == LandState.Auction)
                config = BuildCityCivilManager.GetData(BaseData.StartLevel);
            else
                config = BuildCityCivilManager.GetData((int)BaseData.Level);
            HouseIdList.Clear();
            HouseDic.Clear();
            if (config.HasValue)
            {
                for (int i = 0; i < config.Value.house_numLength; i++)
                {
                    IntList? houseParams = config.Value.house_num(i);
                    uint houseId = (uint)(houseParams.Value.listLength > 0 ? houseParams.Value.list(0) : 0);
                    uint houseCount = (uint)(houseParams.Value.listLength > 1 ? houseParams.Value.list(1) : 0);
                    HouseIdList.Add(houseId);
                    HouseDic.Add(houseId, houseCount);
                }
            }
            else
                LogHelper.LogWarning("获取民用地块等级配置失败. level=" + BaseData.Level.ToString());
        }

        /// <summary>
        /// 刷新外观模型购买状态
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public void RefreshModelState(uint id)
        {
            for (int i = 0; i < ModelStateList.Count; i++)
            {
                if (ModelStateList[i].ModelId == (int)id)
                {
                    ModelStateList[i].IsBuy = true;
                    break;
                }
            }
        }

        [XLua.BlackList]
        public void RefreshModelUnlockState()
        {
            for (int i = 0; i < ModelStateList.Count; i++)
            {
                if (!ModelStateList[i].IsUnlock && ModelStateList[i].Level <= BaseData.Level)
                {
                    ModelStateList[i].IsUnlock = true;
                }
            }
        }

        /// <summary>
        /// 根据状态排序外观模型列表
        /// </summary>
        [XLua.BlackList]
        public void SortModelList()
        {
            ModelStateList.Sort(SortModelState);
        }

        private int SortModelState(BuildCityModelStateData left, BuildCityModelStateData right)
        {
            if (left.IsBuy == right.IsBuy)
            {
                if (left.IsUnlock == right.IsUnlock)
                    return left.ModelId.CompareTo(right.ModelId);
                else
                    return left.IsUnlock ? -1 : 1;
            }
            else
                return left.IsBuy ? -1 : 1;
        }

        [XLua.BlackList]
        public void InitNextLevelModel()
        {
            NextLevelModelStateList.Clear();
            for (int i = 0; i < ModelStateList.Count; i++)
            {
                if (BaseData.State == LandState.Empty)
                {
                    if (ModelStateList[i].Level == BaseData.StartLevel && !ModelStateList[i].GoodsModel)
                        NextLevelModelStateList.Add(ModelStateList[i]);
                }
                else
                {
                    if (ModelStateList[i].Level == BaseData.Level + 1 && !ModelStateList[i].GoodsModel)
                        NextLevelModelStateList.Add(ModelStateList[i]);
                }
            }
        }

        [XLua.BlackList]
        public void RefreshBuildlevelNeedList(uint buildLevel)
        {
            BuildLevel = buildLevel;
            BuildCityCivilBase? buildLevelCfg = BuildCityCivilManager.GetData((int)BuildLevel);
            if (buildLevelCfg.HasValue)
            {
                DonatedNeedList.Clear();
                int resTypeCount = buildLevelCfg.Value.resourceLength;
                for (int i = 0; i < resTypeCount; i++)
                {
                    IntList? resInfo = buildLevelCfg.Value.resource(i);
                    uint resId = (uint)(resInfo.Value.listLength > 0 ? resInfo.Value.list(0) : 0);
                    uint resCount = (uint)(resInfo.Value.listLength > 1 ? resInfo.Value.list(1) : 0);
                    BuildCityDonatedData resData = new BuildCityDonatedData();
                    resData.Init(resId, resCount);
                    DonatedNeedList.Add(resData);
                }
            }
        }
    }
    
    /// <summary>
    /// 地块建设捐赠道具信息
    /// </summary>
    public class BuildCityDonatedData
    {
        /// <summary>
        /// 捐赠道具id
        /// </summary>
        public uint Id;

        /// <summary>
        /// 已捐赠数量
        /// </summary>
        public uint CurCount;

        /// <summary>
        /// 需要捐赠的数量
        /// </summary>
        public uint NeedCount;

        /// <summary>
        /// 已捐献百分比
        /// </summary>
        public double DonatePercent;

        /// <summary>
        /// 道具配置
        /// </summary>
        public ItemTableBase? ItemConfig;

        /// <summary>
        /// 道具图标
        /// </summary>
        public string ItemIcon;

        /// <summary>
        /// 道具名称
        /// </summary>
        public string ItemName;
        
        [XLua.BlackList]
        public void Init(LandNeedItemData serverData)
        {
            Id = serverData.source_id;
            CurCount = serverData.cur_count;
            NeedCount = serverData.need_count;
            DonatePercent = Math.Round(CurCount * 1.0f / NeedCount, 4);
            ItemConfig = ItemTableManager.GetData((int)Id);
            if (ItemConfig.HasValue)
            {
                ItemIcon = ItemConfig.Value.icon;
                ItemName = ItemConfig.Value.name;
            }
            else
                LogHelper.LogWarning("获取捐赠道具配置失败. id=" + Id.ToString());
        }

        [XLua.BlackList]
        public void Init(uint id, uint needCount)
        {
            Id = id;
            NeedCount = needCount;
            CurCount = NeedCount;
            DonatePercent = 1;
            ItemConfig = ItemTableManager.GetData((int)Id);
            if (ItemConfig.HasValue)
            {
                ItemIcon = ItemConfig.Value.icon;
                ItemName = ItemConfig.Value.name;
            }
            else
                LogHelper.LogWarning("获取捐赠道具配置失败. id=" + Id.ToString());
        }

        /// <summary>
        /// 获取玩家拥有的数量
        /// </summary>
        /// <returns></returns>
        public uint GetItemOwnCount()
        {
            if (ItemConfig.HasValue)
            {
                ItemBase itemBase = BagManager.Instance.GetItemByBaseID(BagType.ItemBag, ItemConfig.Value.id);
                if (itemBase != null)
                    return itemBase.ItemNum;
            }
            return 0;
        }
    }

    /// <summary>
    /// 地块外观状态
    /// </summary>
    public class BuildCityModelStateData
    {
        /// <summary>
        /// 模型id
        /// </summary>
        public int ModelId;
// 
//         /// <summary>
//         /// 模型配置
//         /// </summary>
//         private BuildCityModelBase ModelConfig;

        /// <summary>
        /// 是否已购买
        /// </summary>
        public bool IsBuy;

        /// <summary>
        /// 是否解锁
        /// </summary>
        public bool IsUnlock;

        /// <summary>
        /// 价格道具id
        /// </summary>
        public uint PriceItemId;

        /// <summary>
        /// 价格道具数量
        /// </summary>
        public uint PriceItemCount;

        /// <summary>
        /// 外观名称
        /// </summary>
        public string Name;

        /// <summary>
        /// 外观图标
        /// </summary>
        public string Icon;

        /// <summary>
        /// 可用等级
        /// </summary>
        public uint Level;

        /// <summary>
        /// 外观描述
        /// </summary>
        public string Desc;

        /// <summary>
        /// 商品外观，为true时，这个外观只能在改变外观界面中看到，不能在选择升级时看到
        /// </summary>
        public bool GoodsModel = false;

        /// <summary>
        /// 建筑配置的produce_type字段
        /// </summary>
        public int UseType;
        
        [XLua.BlackList]
        public BuildCityModelStateData(BuildCityModelBase config)
        {
//             ModelConfig = config;
            ModelId = config.id;
            PriceItemId = (uint)(config.price(0));
            PriceItemCount = (uint)(config.price(1));
            Icon = config.icon;
            Name = config.name;
            Level = (uint)(config.level);
            Desc = config.production_desc;
            if (config.initial_optional == 0)
                GoodsModel = true;
            UseType = config.produce_type;
        }
    }

    /// <summary>
    /// 地块建筑建造信息
    /// </summary>
    public class BuildCityModelData
    {
        /// <summary>
        /// 地块Id
        /// </summary>
        public uint LandId;

        /// <summary>
        /// 城市Id
        /// </summary>
        public uint CityId;

        /// <summary>
        /// 外观Id
        /// </summary>
        public uint ModelId;

        /// <summary>
        /// 地块状态
        /// </summary>
        public LandState State;

        /// <summary>
        /// 建造进度
        /// </summary>
        public int BuildProgress;
    }

    /// <summary>
    /// 生产地块信息
    /// </summary>
    public class BuildCityProductLandData
    {
        /// <summary>
        /// 地块信息
        /// </summary>
        public BuildCityLandBaseData BaseData;

        /// <summary>
        /// 生产地块配置
        /// </summary>
        private BuildCityProduceBase? config;

        /// <summary>
        /// 当前生产大类外观id
        /// </summary>
        public uint ModelId;

        /// <summary>
        /// 当前生产大类外观名称
        /// </summary>
        public string ModelName;

        /// <summary>
        /// 当前生产大类描述
        /// </summary>
        public string ProduceDesc;

        /// <summary>
        /// 当前生产大类
        /// </summary>
        public uint ProduceType;

        /// <summary>
        /// 玩家在此地块生产中的生产原料id，未生产时为0
        /// </summary>
        public uint ProductId;
// 
//         /// <summary>
//         /// 玩家在此地块开始生产的时间
//         /// </summary>
//         private ulong time_start;

        /// <summary>
        /// 玩家在此地块生产结束的时间
        /// </summary>
        private ulong time_end;

        /// <summary>
        /// 生产剩余时间
        /// </summary>
        public string RestProduceTime = string.Empty;

        /// <summary>
        /// 转产周期：单位（天)
        /// </summary>
        public string ChangeDuration = string.Empty;

        /// <summary>
        /// 玩家在此地块已生产的产品列表
        /// </summary>
        public List<BuildCityProductionData> ProductItemList = new List<BuildCityProductionData>(4);

        /// <summary>
        /// 玩家在此地块收获的产品列表
        /// </summary>
        public List<BuildCityProductionData> ReapProductionList = new List<BuildCityProductionData>(4);

        /// <summary>
        /// 此地块所有可获得的产品列表
        /// </summary>
        public List<BuildCityProductionData> AllProducts = new List<BuildCityProductionData>(8);

        /// <summary>
        /// 此地块当前可用生产小类的列表
        /// </summary>
        public List<BuildCityProductDetailData> ProductDetailList = new List<BuildCityProductDetailData>(8);

        /// <summary>
        /// 此地块所有可用外观数据
        /// </summary>
        public List<BuildCityProductModelData> AllModels = new List<BuildCityProductModelData>(8);

        /// <summary>
        /// 此地块所有可使用的生产原料配置列表
        /// </summary>
        private List<BuildCityMaterialBase> AllMaterials = new List<BuildCityMaterialBase>(5);

        /// <summary>
        /// 玩家当前是否在此地块生产
        /// </summary>
        public bool IsPlayerProduct
        {
            get { return ProductId != 0; }
        }

        /// <summary>
        /// 玩家当前在此地块的生产是否已可收获
        /// </summary>
        public bool IsPlayerProductFinish
        {
            get { return time_end < GameScene.Instance.GetServerTime(); }
        }

        [XLua.BlackList]
        public void InitBaseDataFromMsg(RspLandBaseInfo msg)
        {
            BaseData = new BuildCityLandBaseData();
            BaseData.InitBaseDataFromMsg(msg);
            config = BuildCityProduceManager.GetData((int)BaseData.Id);
            if (config.HasValue)
            {
                AllMaterials.Clear();
                GetProduceMaterials(config.Value, AllMaterials);
                initAllProducts();
                initAllModels();
                TimeSpan tDuration = new TimeSpan(config.Value.change_time * 60 * 1000 * 10000);
                ChangeDuration = tDuration.ToString("%d");
            }
            else
                LogHelper.LogWarning("获取生产地块配置失败. landId=" + BaseData.Id.ToString());
        }

        [XLua.BlackList]
        public void InitUserDataFromMsg(RspUserProduceInfo msg)
        {
            ProductId = msg.product_id;
//             time_start = msg.start_time;
            time_end = msg.end_time;
            SetProduceType(msg.product_type);
            RefreshModelsState();
            RefreshProductDetails();     
            ProductItemList.Clear();
            for (int i = 0; i < msg.production_infoLength; i++)
            {
                LandItemData? info = msg.production_info(i);
                if (info.HasValue)
                {
                    BuildCityProductionData production = new BuildCityProductionData();
                    production.Init(info.Value.item_id, info.Value.item_count);
                    ProductItemList.Add(production);
                }
            }
        }

        /// <summary>
        /// 根据生产地块配置回传地块可用生产原料列表
        /// </summary>
        /// <param name="landConfig"></param>
        /// <param name="matConfigList"></param>
        private void GetProduceMaterials(BuildCityProduceBase landConfig, List<BuildCityMaterialBase> matConfigList)
        {
            matConfigList.Clear();
            for (int n = 0; n < landConfig.produce_typeLength; n++)
            {
                int produce_type = landConfig.produce_type(n);
                int length = BuildCityMaterialManager.Instance.m_DataList.BuildCityMaterialLength;
                for (int i = 0; i < length; i++)
                {
                    var data = BuildCityMaterialManager.Instance.m_DataList.BuildCityMaterial(i);
                    if (data.HasValue)
                    {
                        for (int j = 0; j < data.Value.produce_typeLength; j++)
                        {
                            int type = data.Value.produce_type(j);
                            if (produce_type == type && !matConfigList.Contains(data.Value))
                            {
                                matConfigList.Add(data.Value);
                                break;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 根据生产大类设置外观
        /// </summary>
        /// <param name="produceType"></param>
        public void SetProduceType(uint produceType)
        {
            ProduceType = produceType;
            for (int i = 0; i < AllModels.Count; i++)
            {
                if (AllModels[i].ProductType == produceType)
                {
                    ModelId = AllModels[i].ModelId;
                    break;
                }
            }
        }

        /// <summary>
        /// 根据外观设置生产大类
        /// </summary>
        /// <param name="modelId"></param>
        public void SetModelId(uint modelId)
        {
            ModelId = modelId;
            for (int i = 0; i < AllModels.Count; i++)
            {
                if (AllModels[i].ModelId == modelId)
                {
                    ProduceType = AllModels[i].ProductType;
                    break;
                }
            }
        }

        public bool CheckProduceEnd()
        {
            ulong time_now = GameScene.Instance.GetServerTime();
            if (time_now < time_end)
            {
                DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
                TimeSpan toNow = new TimeSpan((long)time_now * 10000);
                DateTime tNow = tInit.Add(toNow);
                TimeSpan toEnd = new TimeSpan((long)time_end * 10000);
                DateTime tEnd = tInit.Add(toEnd);
                TimeSpan Interval = tEnd.Subtract(tNow);
                RestProduceTime = Interval.ToString(@"hh\:mm\:ss");
                return false;
            }
            return true;
        }

        private List<int> tmpIdLst = new List<int>(8);
        /// <summary>
        /// 初始化所有产出列表
        /// </summary>
        private void initAllProducts()
        {
            AllProducts.Clear();
            tmpIdLst.Clear();
            for (int i = 0; i < AllMaterials.Count; i++)
            {
                if (AllMaterials[i].profitLength > 0)
                {
                    int id = AllMaterials[i].profit(0);
                    if (!tmpIdLst.Contains(id))
                        tmpIdLst.Add(id);
                }
                for (int j = 0; j < AllMaterials[i].chanceLength; j++)
                {
                    IntList? changeParam = AllMaterials[i].chance(j);
                    if (changeParam.HasValue && changeParam.Value.listLength > 0)
                    {
                        int id = changeParam.Value.list(0);
                        if (!tmpIdLst.Contains(id))
                            tmpIdLst.Add(id);
                    }
                }
            }
            for (int i = 0; i < tmpIdLst.Count; i++)
            {
                uint id = (uint)tmpIdLst[i];
                BuildCityProductionData data = new BuildCityProductionData();
                data.Init(id, 1);
                AllProducts.Add(data);
            }
        }

        /// <summary>
        /// 刷新当前可用生产小类
        /// </summary>
        public void RefreshProductDetails()
        {
            ProductDetailList.Clear();
            for (int i = 0; i < AllMaterials.Count; i++)
            {
                for (int j = 0; j < AllMaterials[i].produce_typeLength; j++)
                {
                    if (AllMaterials[i].produce_type(j) == (int)ProduceType)
                    {
                        BuildCityProductDetailData item = new BuildCityProductDetailData();
                        item.Init(AllMaterials[i], AllMaterials[i].id == (int)ProductId);
                        ProductDetailList.Add(item);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// 初始化所有可用外观列表
        /// </summary>
        private void initAllModels()
        {
            if (!config.HasValue)
                return;
            AllModels.Clear();
            tmpIdLst.Clear();
            for (int i = 0; i < config.Value.produce_typeLength; i++)
            {
                int produce_type = config.Value.produce_type(i);
                int length = BuildCityModelManager.Instance.m_DataList.BuildCityModelLength;
                for (int j = 0; j < length; j++)
                {
                    var data = BuildCityModelManager.Instance.m_DataList.BuildCityModel(j);
                    if (data.HasValue && data.Value.type == 2 && data.Value.produce_type == produce_type && !tmpIdLst.Contains(data.Value.id))
                    {
                        bool isUse = data.Value.id == ModelId;
                        BuildCityProductModelData item = new BuildCityProductModelData(data.Value, isUse);
                        AllModels.Add(item);
                        tmpIdLst.Add(data.Value.id);
                        if (isUse)
                        {
                            ModelName = item.Name;
                            ProduceDesc = item.Desc;
                        }
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// 刷新外观状态
        /// </summary>
        public void RefreshModelsState()
        {
            for (int i = 0; i < AllModels.Count; i++)
            {
                if (AllModels[i].ModelId == ModelId)
                {
                    AllModels[i].IsUse = true;
                    ModelName = AllModels[i].Name;
                    ProduceDesc = AllModels[i].Desc;
                }
                else
                    AllModels[i].IsUse = false;
            }
        }
    }

    /// <summary>
    /// 生产地块产出道具信息
    /// </summary>
    public class BuildCityProductionData
    {
        /// <summary>
        /// 道具id
        /// </summary>
        public uint Id;

        /// <summary>
        /// 道具数量
        /// </summary>
        public uint Count;

        /// <summary>
        /// 配置
        /// </summary>
        public ItemTableBase? config;

        /// <summary>
        /// 道具图标
        /// </summary>
        public string Icon;

        /// <summary>
        /// 道具名字
        /// </summary>
        public string Name;

        public void Init(uint id, uint count)
        {
            Id = id;
            Count = count;
            config = ItemTableManager.GetData((int)id);
            if (config.HasValue)
            {
                Icon = config.Value.icon;
                Name = config.Value.name;
            }
            else
                LogHelper.LogWarning("获取产出道具配置失败. id=" + Id.ToString());
        }
    }

    /// <summary>
    /// 生产原料信息
    /// </summary>
    public class BuildCityProductDetailData
    {
        /// <summary>
        /// 生产原料表编号id
        /// </summary>
        public uint ProductDetailId;

        /// <summary>
        /// 消耗道具id
        /// </summary>
        public uint CostItemId;

        /// <summary>
        /// 消耗道具配置
        /// </summary>
        private ItemTableBase? CostItemConfig;

        /// <summary>
        /// 消耗道具图标
        /// </summary>
        public string CostItemIcon;
// 
//         /// <summary>
//         /// 生产原料配置
//         /// </summary>
//         private BuildCityMaterialBase ProduceMatConfig;

        /// <summary>
        /// 最大生产数量
        /// </summary>
        public uint Max_ProduceCount;

        /// <summary>
        /// 非仙门玩家在租赁地块上的生产需要花费的金钱
        /// </summary>
        public uint Price_FullGold;

        /// <summary>
        /// 仙门内玩家生产需要花费的金钱
        /// </summary>
        public uint Price_SeptGold;

        /// <summary>
        /// 仙门内玩家生产需要花费的仙门货币
        /// </summary>
        public uint Price_SeptCoin;

        /// <summary>
        /// 当前是否使用此原料生产
        /// </summary>
        public bool IsUse;

        /// <summary>
        /// 固定收益
        /// </summary>
        public BuildCityProductionData ProfitItem;

        /// <summary>
        /// 有几率获得的收益
        /// </summary>
        public List<BuildCityProductionData> ChanceProfitList = new List<BuildCityProductionData>(3);

        [XLua.BlackList]
        public void Init(BuildCityMaterialBase config, bool isUse)
        {
//             ProduceMatConfig = config;
            IsUse = isUse;
            ProductDetailId = (uint)config.id;
            CostItemId = (uint)config.item_id;
            Max_ProduceCount = (uint)config.max_production;
            Price_FullGold = config.priceLength > 1 ? (uint)config.price(1) : 0;
            Price_SeptGold = config.discountLength > 1 ? (uint)config.discount(1) : 0;
            Price_SeptCoin = (uint)config.contribution;
            CostItemConfig = ItemTableManager.GetData(config.item_id);
            if (CostItemConfig.HasValue)
                CostItemIcon = CostItemConfig.Value.icon;
            else
                LogHelper.LogWarning("获取生产消耗道具配置失败. id=" + CostItemId.ToString());
            if (config.profitLength > 1)
            {
                uint profit_Id = (uint)config.profit(0);
                uint profit_count = (uint)config.profit(1);
                ProfitItem = new BuildCityProductionData();
                ProfitItem.Init(profit_Id, profit_count);
            }
            ChanceProfitList.Clear();
            if (config.chanceLength > 0)
            {
                for (int i = 0; i < config.chanceLength; i++)
                {
                    IntList? chanceParam = config.chance(i);
                    if (chanceParam.HasValue && chanceParam.Value.listLength > 0)
                    {
                        uint chance_id = (uint)chanceParam.Value.list(0);
                        BuildCityProductionData ChanceItem = new BuildCityProductionData();
                        ChanceItem.Init(chance_id, 1);
                        ChanceProfitList.Add(ChanceItem);
                    }
                }
            }
        }
    }

    /// <summary>
    /// 生产地块生产大类建筑信息
    /// </summary>
    public class BuildCityProductModelData
    {
        /// <summary>
        /// 生产类型
        /// </summary>
        public uint ProductType;

        /// <summary>
        /// 外观id
        /// </summary>
        public uint ModelId;

        /// <summary>
        /// 外观配置
        /// </summary>
        private BuildCityModelBase config;

        /// <summary>
        /// 外观图标
        /// </summary>
        public string Icon;

        /// <summary>
        /// 外观模型路径
        /// </summary>
        public string Model;

        /// <summary>
        /// 是否是当前使用的外观
        /// </summary>
        public bool IsUse = false;

        /// <summary>
        /// 生产描述
        /// </summary>
        public string Desc;

        /// <summary>
        /// 生产外观名称
        /// </summary>
        public string Name;

        /// <summary>
        /// 此外观可生产的产品列表
        /// </summary>
        public List<BuildCityProductionData> ProductList = new List<BuildCityProductionData>(5);

        /// <summary>
        /// 此外观可用的生产原料列表
        /// </summary>
        private List<BuildCityMaterialBase> produceMaterials = new List<BuildCityMaterialBase>(5);

        [XLua.BlackList]
        public BuildCityProductModelData(BuildCityModelBase _config, bool isUse)
        {
            config = _config;
            ProductType = (uint)(config.produce_type);
            ModelId = (uint)(config.id);
            Icon = config.icon;
            Model = config.model;
            IsUse = isUse;
            Desc = config.production_desc;
            Name = config.name;

            #region 初始化生产大类外观产出列表
            ProductList.Clear();
            produceMaterials.Clear();
            int produce_type = config.produce_type;
            int length = BuildCityMaterialManager.Instance.m_DataList.BuildCityMaterialLength;
            for (int i = 0; i < length; i++)
            {
                var data = BuildCityMaterialManager.Instance.m_DataList.BuildCityMaterial(i);
                if (data.HasValue)
                {
                    for (int j = 0; j < data.Value.produce_typeLength; j++)
                    {
                        int type = data.Value.produce_type(j);
                        if (produce_type == type && !produceMaterials.Contains(data.Value))
                        {
                            produceMaterials.Add(data.Value);
                            break;
                        }
                    }
                }
            }
            List<int> tmpIdLst = new List<int>(5);
            tmpIdLst.Clear();
            for (int i = 0; i < produceMaterials.Count; i++)
            {
                if (produceMaterials[i].profitLength > 0)
                {
                    int id = produceMaterials[i].profit(0);
                    if (!tmpIdLst.Contains(id))
                        tmpIdLst.Add(id);
                }
                for (int j = 0; j < produceMaterials[i].chanceLength; j++)
                {
                    IntList? changeParam = produceMaterials[i].chance(j);
                    if (changeParam.HasValue && changeParam.Value.listLength > 0)
                    {
                        int id = changeParam.Value.list(0);
                        if (!tmpIdLst.Contains(id))
                            tmpIdLst.Add(id);
                    }
                }
            }
            for (int i = 0; i < tmpIdLst.Count; i++)
            {
                uint id = (uint)tmpIdLst[i];
                BuildCityProductionData data = new BuildCityProductionData();
                data.Init(id, 1);
                ProductList.Add(data);
            }
            #endregion
        }
    }

    /// <summary>
    /// 景观建筑信息
    /// </summary>
    public class BuildCityLandscapeData
    {
        /// <summary>
        /// 地块id
        /// </summary>
        public uint Id;

        /// <summary>
        /// 城市id
        /// </summary>
        public uint CityId;

        /// <summary>
        /// 地块等级
        /// </summary>
        public uint Level;

        /// <summary>
        /// 当前已建造点数
        /// </summary>
        private uint buildPoint;

        /// <summary>
        /// 景观配置
        /// </summary>
        private BuildCityLandscapeBase? config;

        /// <summary>
        /// 地块名字
        /// </summary>
        public string Name;

        /// <summary>
        /// 地块描述
        /// </summary>
        public string Desc;

        /// <summary>
        /// 最大建造点数
        /// </summary>
        private uint maxPoint = 1;

        /// <summary>
        /// 等级-建造点数对应字典
        /// </summary>
        private Dictionary<uint, uint> mapLevelPoint = new Dictionary<uint, uint>(5);

        /// <summary>
        /// 在沙盘上的位置
        /// </summary>
        public int ArrowPoint;

        /// <summary>
        /// 建造进度
        /// </summary>
        public float Progress
        {
            get
            {
                return UnityEngine.Mathf.Clamp01(buildPoint * 1.0f / maxPoint);
            }
        }

        public void Init(uint landId, uint cityId, uint level)
        {
            Id = landId;
            CityId = cityId;
            Level = level;
            config = BuildCityLandscapeManager.GetData((int)Id);
            if (config.HasValue)
            {
                Name = config.Value.name;
                Desc = config.Value.desc;
                ArrowPoint = config.Value.arrow_point;
                mapLevelPoint.Clear();
                for (int i = 0; i < config.Value.build_speedLength; i++)
                {
                    IntList? buildParam = config.Value.build_speed(i);
                    if (buildParam.HasValue && buildParam.Value.listLength > 1)
                    {
                        int _level = buildParam.Value.list(0);
                        int _point = buildParam.Value.list(1);
                        mapLevelPoint.Add((uint)_level, (uint)_point);
                    }
                }
                if (mapLevelPoint.ContainsKey(Level))
                    maxPoint = mapLevelPoint[Level];
                else
                    LogHelper.LogWarning("获取景观地块建造点数失败. id=" + Id.ToString() + ", Level:" + Level.ToString());
            }
            else
                LogHelper.LogWarning("获取景观地块配置失败. id=" + Id.ToString());
        }

        public void SetBuildPoint(uint point)
        {
            buildPoint = point;
        }
    }

    /// <summary>
    /// 经营地块数据信息
    /// </summary>
    public class BuildCityBusinessLandData
    {
        /// <summary>
        /// 地块信息
        /// </summary>
        public BuildCityLandBaseData BaseData;

        /// <summary>
        /// 经营地块配置
        /// </summary>
        private BuildCityBusinessBase? config;

        /// <summary>
        /// 当前建造中等级
        /// </summary>
        public uint BuildLevel;

        /// <summary>
        /// 当前建造中的捐赠物列表
        /// </summary>
        public List<BuildCityDonatedData> DonatedItemList = new List<BuildCityDonatedData>(3);

        /// <summary>
        /// 当前等级需要的捐赠物列表
        /// </summary>
        public List<BuildCityDonatedData> DonatedNeedList = new List<BuildCityDonatedData>(3);

        /// <summary>
        /// 店铺名称
        /// </summary>
        public string ShopName;

        /// <summary>
        /// 店铺广告
        /// </summary>
        public string ShopAd;

        /// <summary>
        /// 上一等级的经营度
        /// </summary>
        public uint LastBusinessPoint;

        /// <summary>
        /// 当前经营度
        /// </summary>
        public uint CurBusinessPoint;

        /// <summary>
        /// 升级需要的经营度
        /// </summary>
        public uint MaxBusinessPoint;

        /// <summary>
        /// 经营度百分比
        /// </summary>
        public double BusinessPointPercent;

        /// <summary>
        /// 当前经营范围
        /// </summary>
        public int CurBusinessType;

        /// <summary>
        /// 当前经营活跃度
        /// </summary>
        public uint CurBusinessActivity;

        /// <summary>
        /// 最大活跃度
        /// </summary>
        public uint MaxBusinessActivity;

        /// <summary>
        /// 活跃度百分比
        /// </summary>
        public double BusinessActivityPercent;

        /// <summary>
        /// 距离下次改变经营范围的时间
        /// </summary>
        public string RestChangeBusinessTypeTime;

        /// <summary>
        /// 订单栏位列表
        /// </summary>
        public Dictionary<uint, BuildCityBusinessOrderSlot> OrderSlotMap = new Dictionary<uint, BuildCityBusinessOrderSlot>(6);

        /// <summary>
        /// 评论列表
        /// </summary>
        public List<BuildCityBusinessComment> CommentList = new List<BuildCityBusinessComment>(16);

        /// <summary>
        /// 外观状态列表
        /// </summary>
        public List<BuildCityModelStateData> ModelStateList = new List<BuildCityModelStateData>(8);

        /// <summary>
        /// 修改外观可使用的外观列表
        /// </summary>
        public List<BuildCityModelStateData> ChangeModelStateList = new List<BuildCityModelStateData>(16);

        /// <summary>
        /// 升级可使用的外观列表
        /// </summary>
        public List<BuildCityModelStateData> NextLevelModelStateList = new List<BuildCityModelStateData>(4);

        /// <summary>
        /// 修改经营范围可使用的外观列表
        /// </summary>
        public List<BuildCityModelStateData> ChangeTypeModelStateList = new List<BuildCityModelStateData>(4);

        /// <summary>
        /// 当前使用的外观id
        /// </summary>
        public uint ModelId;

        /// <summary>
        /// 昨日订单完成情况
        /// </summary>
        public BuildCityBusinessOrderReport YesterdayReport;

        /// <summary>
        /// 地块支持的经营范围
        /// </summary>
        public List<BuildCityBusinessType> BusinessTypeList = new List<BuildCityBusinessType>(2);

        [XLua.BlackList]
        public void InitBaseDataFromMsg(RspLandBaseInfo msg)
        {
            BaseData = new BuildCityLandBaseData();
            BaseData.InitBaseDataFromMsg(msg);
            if (BaseData.State == LandState.Empty || BaseData.State == LandState.Building || BaseData.State == LandState.BuildDone)
                RefreshBuildlevelNeedList((uint)BaseData.StartLevel);
            else if (BaseData.State == LandState.LevelUp || BaseData.State == LandState.LevelUpDone)
            {
                if (BaseData.Level < BaseData.MaxLevel)
                    RefreshBuildlevelNeedList(BaseData.Level + 1);
            }
            ModelStateList.Clear();
            int length = BuildCityModelManager.Instance.m_DataList.BuildCityModelLength;
            for (int i = 0; i < length; i++)
            {
                var data = BuildCityModelManager.Instance.m_DataList.BuildCityModel(i);
                if (data.HasValue && data.Value.type == 4)
                {
                    BuildCityModelStateData modelData = new BuildCityModelStateData(data.Value);
                    if (data.Value.level <= BaseData.Level)
                        modelData.IsUnlock = true;
                    modelData.IsBuy = false;
                    ModelStateList.Add(modelData);
                }
            }
            UpdateLandLevel(BaseData.Level);
        }

        [XLua.BlackList]
        public void InitBusinessDataFromMsg(RspCommercialLandInfo msg)
        {
            ShopName = msg.name;
            ShopAd = msg.advertisement;
            RefreshBusinessPoint(msg.management);
            RefreshBusinessActivity(msg.activity);
            SetBusinessType(msg.appearance_id);
            for (int i = 0; i < msg.order_listLength; i++)
            {
                var orderData = msg.order_list(i);
                if (orderData.HasValue)
                {
                    uint index = orderData.Value.index;
                    if (OrderSlotMap.ContainsKey(index))
                        OrderSlotMap[index].InitData(orderData.Value);
                    else
                        LogHelper.LogWarningFormat("设置经营地块订单信息失败，订单序号错误. 订单序号={0}, 地块id={1}", BaseData.Level, BaseData.Id);
                }
            }
            CommentList.Clear();
            for (int i = 0; i < msg.finish_order_listLength; i++)
            {
                var commentData = msg.finish_order_list(i);
                if (commentData.HasValue)
                {
                    BuildCityBusinessComment comment = new BuildCityBusinessComment();
                    comment.InitData(commentData.Value);
                    CommentList.Add(comment);
                }
            }
            RefreshModelList();
        }

        /// <summary>
        /// 刷新地块等级
        /// </summary>
        /// <param name="level"></param>
        [XLua.BlackList]
        public void UpdateLandLevel(uint level)
        {
            BaseData.Level = level;
            if (BaseData.State == LandState.None || BaseData.State == LandState.Auction)
                config = BuildCityBusinessManager.GetData(BaseData.StartLevel);
            else
                config = BuildCityBusinessManager.GetData((int)BaseData.Level);
            if (config.HasValue)
            {
                BusinessTypeList.Clear();
                int typeLength = config.Value.business_scopeLength;
                for (int i = 0; i < typeLength; i++)
                {
                    int type = config.Value.business_scope(i);
                    BuildCityBusinessType businessType = new BuildCityBusinessType();
                    if (businessType.Init(type))
                        BusinessTypeList.Add(businessType);
                }
                MaxBusinessPoint = (uint)config.Value.management;
                MaxBusinessActivity = (uint)config.Value.activity;
                if (BaseData.Level > BaseData.StartLevel)
                {
                    int lastLevel = (int)BaseData.Level - 1;
                    var lastConfig = BuildCityBusinessManager.GetData(lastLevel);
                    LastBusinessPoint = 0;
                    if (lastConfig.HasValue)
                        LastBusinessPoint = (uint)lastConfig.Value.management;
                }
                else
                    LastBusinessPoint = 0;
                RefreshBusinessPoint(CurBusinessPoint);
            }
            else
                LogHelper.LogWarningFormat("获取经营地块配置失败. level={0}", BaseData.Level);
        }

        /// <summary>
        /// 刷新经营度
        /// </summary>
        [XLua.BlackList]
        public void RefreshBusinessPoint(uint businessPoint)
        {
            CurBusinessPoint = businessPoint;
            BusinessPointPercent = 1;
            uint targetValue = MaxBusinessPoint - LastBusinessPoint;
            uint progressValue = CurBusinessPoint - LastBusinessPoint;
            if (targetValue > 0)
            {             
                BusinessPointPercent = Math.Round(progressValue * 1.0f / targetValue, 2);
                BusinessPointPercent = Math.Min(BusinessPointPercent, 1.0f);
            }
        }

        /// <summary>
        /// 刷新活跃度
        /// </summary>
        [XLua.BlackList]
        public void RefreshBusinessActivity(uint businessActivity)
        {
            CurBusinessActivity = businessActivity;
            BusinessActivityPercent = 1;
            if (MaxBusinessActivity > 0)
                BusinessActivityPercent = Math.Round(CurBusinessActivity * 1.0f / MaxBusinessActivity, 2);
        }

        /// <summary>
        /// 根据新的外观id设置经营范围
        /// </summary>
        /// <param name="modelId">新的外观id</param>
        [XLua.BlackList]
        public void SetBusinessType(uint modelId)
        {
            var modelConfig = BuildCityModelManager.GetData((int)modelId);
            if (modelConfig.HasValue)
            {
                ModelId = modelId;
                if (CurBusinessType != modelConfig.Value.produce_type)
                {
                    CurBusinessType = modelConfig.Value.produce_type;
                    uint index = 0;
                    OrderSlotMap.Clear();
                    for (int i = 0; i < config.Value.field_numberLength; i++)
                    {
                        IntList? slotParam = config.Value.field_number(i);
                        if (slotParam.HasValue && slotParam.Value.listLength > 1)
                        {
                            if (slotParam.Value.list(0) == CurBusinessType)
                            {
                                int count = slotParam.Value.list(1);
                                for (int j = 0; j < count; j++)
                                {
                                    BuildCityBusinessOrderSlot orderSlot = new BuildCityBusinessOrderSlot(index, BaseData.Level, true);
                                    OrderSlotMap.Add(orderSlot.SlotIndex, orderSlot);
                                    index++;
                                }
                                break;
                            }
                        }
                    }
                    int maxLevel = BuildCityBusinessManager.Instance.m_DataList.BuildCityBusinessLength;
                    for (int i = config.Value.level + 1; i <= maxLevel; i++)
                    {
                        var businessConfig = BuildCityBusinessManager.GetData(i);
                        if (businessConfig.HasValue)
                        {
                            for (int j = 0; j < businessConfig.Value.field_numberLength; j++)
                            {
                                IntList? slotParam = businessConfig.Value.field_number(j);
                                if (slotParam.HasValue && slotParam.Value.listLength > 1)
                                {
                                    if (slotParam.Value.list(0) == CurBusinessType)
                                    {
                                        int count = slotParam.Value.list(1);
                                        int addCount = count - OrderSlotMap.Count;
                                        for (int m = 0; m < addCount; m++)
                                        {
                                            BuildCityBusinessOrderSlot orderSlot = new BuildCityBusinessOrderSlot(index, (uint)businessConfig.Value.level, false);
                                            OrderSlotMap.Add(orderSlot.SlotIndex, orderSlot);
                                            index++;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else if (modelId != 0)
                LogHelper.LogWarningFormat("设置地块外观id错误，找不到外观配置。id={0}", modelId);
        }

        /// <summary>
        /// 刷新外观模型购买状态
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public void RefreshModelState(uint id)
        {
            for (int i = 0; i < ModelStateList.Count; i++)
            {
                if (ModelStateList[i].ModelId == (int)id)
                {
                    ModelStateList[i].IsBuy = true;
                    break;
                }
            }
        }

        /// <summary>
        /// 刷新各项操作可用外观列表
        /// </summary>
        [XLua.BlackList]
        public void RefreshModelList()
        {
            ChangeModelStateList.Clear();
            NextLevelModelStateList.Clear();
            ChangeTypeModelStateList.Clear();
            for (int i = 0; i < ModelStateList.Count; i++)
            {
                var modelState = ModelStateList[i];
                //筛选修改外观可用列表
                if (modelState.UseType == CurBusinessType)
                    ChangeModelStateList.Add(modelState);
                //筛选升级可用外观列表
                if (BaseData.State == LandState.Empty)
                {
                    if (modelState.Level == BaseData.StartLevel && !modelState.GoodsModel)
                        NextLevelModelStateList.Add(modelState);
                }
                else
                {
                    if (modelState.UseType == CurBusinessType && !modelState.GoodsModel && modelState.Level == BaseData.Level + 1)
                        NextLevelModelStateList.Add(modelState);
                }
                //筛选修改经营范围可用外观列表
                if (modelState.Level == BaseData.Level && modelState.UseType != CurBusinessType && !modelState.GoodsModel)
                    ChangeTypeModelStateList.Add(modelState);
            }
            ChangeModelStateList.Sort(SortModelState);
            NextLevelModelStateList.Sort(SortModelState);
            ChangeTypeModelStateList.Sort(SortModelState);
        }

        [XLua.BlackList]
        public void RefreshModelUnlockState()
        {
            for (int i = 0; i < ModelStateList.Count; i++)
            {
                if (!ModelStateList[i].IsUnlock && ModelStateList[i].Level <= BaseData.Level)
                {
                    ModelStateList[i].IsUnlock = true;
                }
            }
        }

        /// <summary>
        /// 根据状态排序外观模型列表
        /// </summary>
        [XLua.BlackList]
        public void SortModelList()
        {
            ChangeModelStateList.Sort(SortModelState);
            NextLevelModelStateList.Sort(SortModelState);
            ChangeTypeModelStateList.Sort(SortModelState);
        }

        private int SortModelState(BuildCityModelStateData left, BuildCityModelStateData right)
        {
            if (left.IsBuy == right.IsBuy)
            {
                if (left.IsUnlock == right.IsUnlock)
                    return left.ModelId.CompareTo(right.ModelId);
                else
                    return left.IsUnlock ? -1 : 1;
            }
            else
                return left.IsBuy ? -1 : 1;
        }

        /// <summary>
        /// 刷新升级需要的资源
        /// </summary>
        /// <param name="buildLevel"></param>
        [XLua.BlackList]
        public void RefreshBuildlevelNeedList(uint buildLevel)
        {
            BuildLevel = buildLevel;
            BuildCityBusinessBase? buildLevelCfg = BuildCityBusinessManager.GetData((int)BuildLevel);
            if (buildLevelCfg.HasValue)
            {
                DonatedNeedList.Clear();
                int resTypeCount = buildLevelCfg.Value.resourceLength;
                for (int i = 0; i < resTypeCount; i++)
                {
                    IntList? resInfo = buildLevelCfg.Value.resource(i);
                    uint resId = (uint)(resInfo.Value.listLength > 0 ? resInfo.Value.list(0) : 0);
                    uint resCount = (uint)(resInfo.Value.listLength > 1 ? resInfo.Value.list(1) : 0);
                    BuildCityDonatedData resData = new BuildCityDonatedData();
                    resData.Init(resId, resCount);
                    DonatedNeedList.Add(resData);
                }
            }
        }

        /// <summary>
        /// 设置修改经营范围的cd时间
        /// </summary>
        [XLua.BlackList]
        public void SetChangeBuisnessTime(ulong next_change_time)
        {
            ulong time_now = GameScene.Instance.GetServerTime();
            if (time_now < next_change_time)
            {
                DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
                TimeSpan toNow = new TimeSpan((long)time_now * 10000);
                DateTime tNow = tInit.Add(toNow);
                TimeSpan toEnd = new TimeSpan((long)next_change_time * 10000);
                DateTime tEnd = tInit.Add(toEnd);
                TimeSpan Interval = tEnd.Subtract(tNow);
                RestChangeBusinessTypeTime = Interval.ToString(@"hh\:mm\:ss");
            }
        }

        /// <summary>
        /// 刷新订单数据
        /// </summary>
        /// <param name="orderIndex"></param>
        /// <param name="serverData"></param>
        [XLua.BlackList]
        public void RefreshOrderData(uint orderIndex, CommercialOrderInfo serverData)
        {
            if (OrderSlotMap.ContainsKey(orderIndex))
                OrderSlotMap[orderIndex].InitData(serverData);
        }

        private float lastRefreshTime = 0;
        private const float RefreshOrderInterval = 1.0f;
        public bool CheckNeedRefreshOrderState()
        {
            bool ret = false;
            var e = OrderSlotMap.GetEnumerator();
            while (e.MoveNext())
            {
                if (e.Current.Value.CheckNeedRefreshState())
                {
                    if (!ret && UnityEngine.Time.time - lastRefreshTime > RefreshOrderInterval)
                    {
                        ret = true;
                        lastRefreshTime = UnityEngine.Time.time;
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// 获得订单栏位下次接受订单时间
        /// </summary>
        /// <param name="orderIndex"></param>
        /// <returns></returns>
        public string GetSlotStartBusinessTime(uint orderIndex)
        {
            if (OrderSlotMap.ContainsKey(orderIndex))
                return OrderSlotMap[orderIndex].NextOpenTime;
            return string.Empty;
        }

        public int GetBusinessOrderCount()
        {
            int count = 0;
            var e = OrderSlotMap.GetEnumerator();
            while (e.MoveNext())
            {
                if (e.Current.Value.IsOpen && e.Current.Value.InBusiness)
                    count++;
            }
            return count;
        }
    }

    /// <summary>
    /// 经营地块订单栏位
    /// </summary>
    public class BuildCityBusinessOrderSlot
    {
        /// <summary>
        /// 栏位索引
        /// </summary>
        public uint SlotIndex;

        /// <summary>
        /// 开启等级
        /// </summary>
        public uint OpenLevel;

        /// <summary>
        /// 栏位是否开启
        /// </summary>
        public bool IsOpen;

        /// <summary>
        /// 是否有订单在处理
        /// </summary>
        public bool InBusiness;

        /// <summary>
        /// 订单栏cd时间
        /// </summary>
        private ulong time_cd;

        /// <summary>
        /// 下次接受订单时间
        /// </summary>
        public string NextOpenTime = string.Empty;

        /// <summary>
        /// 订单数据
        /// </summary>
        public BuildCityBusinessOrder OrderData;

        [XLua.BlackList]
        public BuildCityBusinessOrderSlot(uint index, uint openLevel, bool isOpen)
        {
            SlotIndex = index;
            OpenLevel = openLevel;
            IsOpen = isOpen;
        }

        [XLua.BlackList]
        public void InitData(CommercialOrderInfo serverData)
        {
            if (serverData.source_id != 0 && serverData.state == CommercialOrderState.Doing)
            {
                OrderData = new BuildCityBusinessOrder();
                OrderData.InitData(serverData);
                InBusiness = true;
            }
            else
            {
                OrderData = null;
                InBusiness = false;
            }
            time_cd = serverData.cd_time;
        }

        [XLua.BlackList]
        public bool CheckStartBusinessTime()
        {
            ulong time_now = GameScene.Instance.GetServerTime();
            if (time_now < time_cd)
            {
                DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
                TimeSpan toNow = new TimeSpan((long)time_now * 10000);
                DateTime tNow = tInit.Add(toNow);
                TimeSpan toEnd = new TimeSpan((long)time_cd * 10000);
                DateTime tEnd = tInit.Add(toEnd);
                TimeSpan Interval = tEnd.Subtract(tNow);
                NextOpenTime = Interval.ToString(@"hh\:mm\:ss");
                return false;
            }
            return true;
        }

        /// <summary>
        /// 检测是否需要刷新订单状态
        /// </summary>
        /// <returns></returns>
        [XLua.BlackList]
        public bool CheckNeedRefreshState()
        {
            bool ret = false;
            if (IsOpen)
            {
                //只检测已开启的订单栏
                if (InBusiness)
                {
                    //接单中的栏位检查订单过期时间
                    ret = OrderData.CheckExpireTime();                   
                }
                else
                {
                    //CD中的栏位检查开始接单的时间
                    ret = CheckStartBusinessTime();
                }
            }
            return ret;
        }
    }

    /// <summary>
    /// 经营地块订单信息
    /// </summary>
    public class BuildCityBusinessOrder
    {
        /// <summary>
        /// 订单号
        /// </summary>
        public uint OrderId;

        /// <summary>
        /// 订单配置
        /// </summary>
        private BuildCityBusinessOrderBase? config;

        /// <summary>
        /// 订单结束的时间
        /// </summary>
        private ulong time_end;

        /// <summary>
        /// 订单过期的剩余时间
        /// </summary>
        public string RestOrderTime = string.Empty;

        /// <summary>
        /// 订单需求缴纳的道具列表
        /// </summary>
        public List<BuildCityDonatedData> OrderItemList = new List<BuildCityDonatedData>(3);

        /// <summary>
        /// 订单完成进度
        /// </summary>
        public uint Progress;

        /// <summary>
        /// 订单状态
        /// </summary>
        public CommercialOrderState State = default(CommercialOrderState);

        /// <summary>
        /// 订单名字
        /// </summary>
        public string Name;

        /// <summary>
        /// 订单描述
        /// </summary>
        public string Desc;

        /// <summary>
        /// 订单图标
        /// </summary>
        public string Icon;

        /// <summary>
        /// 紧急程度
        /// </summary>
        public string Priority;

        /// <summary>
        /// 订单完成奖励
        /// </summary>
        public List<BuildCityProductionData> AwardList = new List<BuildCityProductionData>(3);

        [XLua.BlackList]
        public void InitData(CommercialOrderInfo serverData)
        {
            OrderId = serverData.source_id;
            State = serverData.state;
            time_end = serverData.order_expire_time;
            Progress = serverData.order_progress;
            OrderItemList.Clear();
            int resTypeCount = serverData.item_listLength;
            for (int i = 0; i < resTypeCount; i++)
            {
                var resInfo = serverData.item_list(i);
                if (resInfo.HasValue)
                {
                    BuildCityDonatedData donatedItem = new BuildCityDonatedData();
                    donatedItem.Init(resInfo.Value);
                    OrderItemList.Add(donatedItem);
                }
            }
            config = BuildCityBusinessOrderManager.GetData((int)OrderId);
            if (config.HasValue)
            {
                Name = config.Value.name;
                Desc = config.Value.desc;
                Icon = config.Value.icon;
                Priority = config.Value.urgent;
                AwardList.Clear();
                int length = config.Value.order_rewardLength;
                for (int i = 0; i < length; i++)
                {
                    IntList? resInfo = config.Value.order_reward(i);
                    uint resId = (uint)(resInfo.Value.listLength > 0 ? resInfo.Value.list(0) : 0);
                    uint resCount = (uint)(resInfo.Value.listLength > 1 ? resInfo.Value.list(1) : 0);
                    BuildCityProductionData awardItem = new BuildCityProductionData();
                    awardItem.Init(resId, resCount);
                    AwardList.Add(awardItem);
                }
            }
            else
                LogHelper.LogWarningFormat("找不到订单配置。id={0}", OrderId);
        }

        /// <summary>
        /// 检查订单是否过期并刷新剩余时间字符串
        /// </summary>
        /// <returns></returns>
        public bool CheckExpireTime()
        {
            ulong time_now = GameScene.Instance.GetServerTime();
            if (time_now < time_end)
            {
                DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
                TimeSpan toNow = new TimeSpan((long)time_now * 10000);
                DateTime tNow = tInit.Add(toNow);
                TimeSpan toEnd = new TimeSpan((long)time_end * 10000);
                DateTime tEnd = tInit.Add(toEnd);
                TimeSpan Interval = tEnd.Subtract(tNow);
                RestOrderTime = Interval.ToString(@"hh\:mm\:ss");
                return false;
            }
            return true;
        }
    }
    
    /// <summary>
    /// 经营地块评论信息
    /// </summary>
    public class BuildCityBusinessComment
    {
        /// <summary>
        /// 评论者头像
        /// </summary>
        public string HeadIcon;

        /// <summary>
        /// 评论者名字
        /// </summary>
        public string Name;

        /// <summary>
        /// 评论内容
        /// </summary>
        public string Content;

        /// <summary>
        /// 点赞数量
        /// </summary>
        public uint LikeCount;

        [XLua.BlackList]
        public void InitData(FinishedCommercialOrderInfo serverData)
        {
            NpcTableBase? config = NpcTableManager.GetData((int)serverData.source_id);
            if (config.HasValue)
            {
                HeadIcon = config.Value.head_icon;
                Name = config.Value.name;
            }
            Content = serverData.assessment;
            LikeCount = serverData.like_count;
        }
    }

    /// <summary>
    /// 经营地块昨日订单完成情况
    /// </summary>
    public class BuildCityBusinessOrderReport
    {
        /// <summary>
        /// 昨日完成订单数量
        /// </summary>
        public uint FinishCount;

        /// <summary>
        /// 自己的排名
        /// </summary>
        public uint MyRank;

        /// <summary>
        /// 自己的分数
        /// </summary>
        public uint MyScore;

        /// <summary>
        /// 昨日订单完成情况玩家排名
        /// </summary>
        public List<BuildCityBusinessOrderRankPlayer> TopRankList = new List<BuildCityBusinessOrderRankPlayer>(10);

        /// <summary>
        /// 玩家可领取奖励
        /// </summary>
        public List<BuildCityProductionData> AwardList = new List<BuildCityProductionData>(3);

        /// <summary>
        /// 是否有奖励待领取
        /// </summary>
        public bool HasAward;

        [XLua.BlackList]
        public void InitData(RspYesterdayUserOrderInfo serverData)
        {
            FinishCount = serverData.finish_count;
            MyRank = serverData.my_rank;
            MyScore = serverData.score;
            HasAward = serverData.can_claim;
            TopRankList.Clear();
            for (int i = 0; i < serverData.order_rankLength; i++)
            {
                var rankData = serverData.order_rank(i);
                if (rankData.HasValue)
                {
                    BuildCityBusinessOrderRankPlayer rankPlayerData = new BuildCityBusinessOrderRankPlayer();
                    rankPlayerData.InitData(rankData.Value);
                    TopRankList.Add(rankPlayerData);
                }
            }
            AwardList.Clear();
            for (int i = 0; i < serverData.awardLength; i++)
            {
                var award = serverData.award(i);
                if (award.HasValue)
                {
                    BuildCityProductionData awardData = new BuildCityProductionData();
                    awardData.Init(award.Value.item_id, award.Value.item_count);
                    AwardList.Add(awardData);
                }
            }
        }
    }

    /// <summary>
    /// 经营地块订单完成玩家排名
    /// </summary>
    public class BuildCityBusinessOrderRankPlayer
    {
        /// <summary>
        /// 名字
        /// </summary>
        public string Name;

        /// <summary>
        /// 职业
        /// </summary>
        public CareerType Carreer = default(CareerType);

        /// <summary>
        /// 性别
        /// </summary>
        public CareerSex Gender = default(CareerSex);

        /// <summary>
        /// 评分
        /// </summary>
        public uint Score;

        /// <summary>
        /// 头像
        /// </summary>
        public string HeadIcon = string.Empty;

        [XLua.BlackList]
        public void InitData(UserOrderRankData serverData)
        {
            Name = serverData.name;
            Carreer = serverData.career;
            Gender = serverData.sex;
            Score = serverData.score;
            ProfessionTableBase? carrerConfig = ProfessionTableManager.GetData((int)Carreer);
            if (carrerConfig.HasValue)
                HeadIcon = carrerConfig.Value.headicon;
        }
    }

    /// <summary>
    /// 经营范围
    /// </summary>
    public class BuildCityBusinessType
    {
        /// <summary>
        /// 经营范围.1为酒楼，2为工坊
        /// </summary>
        public uint BusinessType;

        /// <summary>
        /// 经营范围名称
        /// </summary>
        public string Name;

        /// <summary>
        /// 经营范围图标
        /// </summary>
        public string Icon;

        [XLua.BlackList]
        public bool Init(int type)
        {
            BusinessType = (uint)type;
            if (type == 1)
            {
                Name = "酒楼";
                return true;
            }
            else if (type == 2)
            {
                Name = "工坊";
                return true;
            }
            return false;
        }
    }
}