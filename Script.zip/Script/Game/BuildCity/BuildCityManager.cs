using System.Collections.Generic;
using Bokura;
using swm;
using FlatBuffers;

namespace Bokura
{
    public class BuildCityManager : ClientSingleton<BuildCityManager>
    {
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<RspLandBaseInfo>(ProcRspLandBaseInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<RspViewAuctionInfo>(ProcRspViewAuctionInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<RspViewLandInfo>(ProcRspViewLandInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<RspStartLandBuild>(ProcRspStartLandBuild);
            MsgDispatcher.instance.RegisterFBMsgProc<RspLandBuildProgress>(ProcRspLandBuildProgress);
            MsgDispatcher.instance.RegisterFBMsgProc<RspDonateLandBuild>(ProcRspDonateLandBuild);
            MsgDispatcher.instance.RegisterFBMsgProc<RspLandBuildTask>(ProcRspLandBuildTask);
            MsgDispatcher.instance.RegisterFBMsgProc<RspFinishLandBuild>(ProcRspFinishLandBuild);
            MsgDispatcher.instance.RegisterFBMsgProc<RspLandAppearance>(ProcRspLandAppearance);
            MsgDispatcher.instance.RegisterFBMsgProc<RspBuyLandAppearance>(ProcRspBuyLandAppearance);
            MsgDispatcher.instance.RegisterFBMsgProc<RspUseLandAppearance>(ProcRspUseLandAppearance);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCityLandAppearance>(ProcRspCityLandAppearance);
            MsgDispatcher.instance.RegisterFBMsgProc<NotifyLandAppearance>(ProcNotifyLandAppearance);
            MsgDispatcher.instance.RegisterFBMsgProc<RspChooseProduceType>(ProcRspChooseProduceType);
            MsgDispatcher.instance.RegisterFBMsgProc<RspUserProduceInfo>(ProcRspUserProduceInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<RspStartProduce>(ProcRspStartProduce);
            MsgDispatcher.instance.RegisterFBMsgProc<RspReapProduction>(ProcRspReapProduction);
            MsgDispatcher.instance.RegisterFBMsgProc<RspChangeProductType>(ProcRspChangeProductType);
            MsgDispatcher.instance.RegisterFBMsgProc<RspFinishChangeProductType>(ProcRspFinishChangeProductType);
            MsgDispatcher.instance.RegisterFBMsgProc<RspLandscapeBuildingList>(ProcRspLandscapeBuildingList);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCommercialLandManagement>(ProcRspCommercialLandManagement);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCommercialLandInfo>(ProcRspCommercialLandInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<RspChangeCommercialLandName>(ProcRspChangeCommercialLandName);
            MsgDispatcher.instance.RegisterFBMsgProc<RspChangeCommercialLandAD>(ProcRspChangeCommercialLandAD);
            MsgDispatcher.instance.RegisterFBMsgProc<RspYesterdayUserOrderInfo>(ProcRspYesterdayUserOrderInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<RspClaimYesterdayOrderAward>(ProcRspClaimYesterdayOrderAward);
            MsgDispatcher.instance.RegisterFBMsgProc<RspChangeCommercialType>(ProcRspChangeCommercialType);
            MsgDispatcher.instance.RegisterFBMsgProc<RspDonateCommercialOrder>(ProcRspDonateCommercialOrder);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCityLandSeptID>(ProcRspCityLandSeptID);

            m_buildingManager.Init();
            onRemoveCityBuildings.AddListener(OnRemoveCityBuildings);
        }

        [XLua.BlackList]
        public void Load()
        {
            BuildCityTableManager.Load();
            BuildCityCivilManager.Load();
            BuildCityProduceManager.Load();
            BuildCityMaterialManager.Load();
            BuildCityModelManager.Load();
            BuildCityLocationManager.Load();
            BuildCityLandscapeManager.Load();
            BuildCityBusinessManager.Load();
            BuildCityBusinessOrderManager.Load();
            m_buildingManager.Load();
        }

        public void Clear()
        {
            m_curLandBaseData = null;
            m_curCivilLandData = null;
            m_curProductLandData = null;
            m_buildingDataMap.Clear();
            m_buildingManager.Clear();
        }

        private void OnRemoveCityBuildings()
        {
            m_buildingDataMap.Clear();
        }

        /// <summary>
        /// 建筑实体管理器
        /// </summary>
        private BuildCityBuildingManager m_buildingManager = new BuildCityBuildingManager();
        [XLua.BlackList]
        public BuildCityBuildingManager BuildingManager
        {
            get { return m_buildingManager; }
        }

        private BuildCityLandBaseData m_curLandBaseData;
        /// <summary>
        /// 当前基础地块信息
        /// </summary>
        public BuildCityLandBaseData CurLandBaseData
        {
            get { return m_curLandBaseData; }
        }

        private BuildCityCivilLandData m_curCivilLandData;
        /// <summary>
        /// 当前民用地块信息
        /// </summary>
        public BuildCityCivilLandData CurCivilLandData
        {
            get { return m_curCivilLandData; }
        }

        private BuildCityProductLandData m_curProductLandData;
        /// <summary>
        /// 当前生产地块信息
        /// </summary>
        public BuildCityProductLandData CurProductLandData
        {
            get { return m_curProductLandData; }
        }

        private BuildCityBusinessLandData m_curBusinessLandData;
        /// <summary>
        /// 当前经济地块信息
        /// </summary>
        public BuildCityBusinessLandData CurBusinessLandData
        {
            get { return m_curBusinessLandData; }
        }

        private Dictionary<uint, BuildCityModelData> m_buildingDataMap = new Dictionary<uint, BuildCityModelData>(20);
        /// <summary>
        /// 城市地表建筑数据
        /// </summary>
        [XLua.BlackList]
        public Dictionary<uint, BuildCityModelData> BuildingDataMap
        {
            get { return m_buildingDataMap; }
        }

        private Dictionary<uint, BuildCityLandscapeData> m_landscapeDataMap = new Dictionary<uint, BuildCityLandscapeData>(8);
        /// <summary>
        /// 城市景观建筑数据
        /// </summary>
        public Dictionary<uint, BuildCityLandscapeData> LandscapeDataMap
        {
            get { return m_landscapeDataMap; }
        }

        private Dictionary<uint, ulong> m_landSeptMap = new Dictionary<uint, ulong>(10);
        [XLua.BlackList]
        public Dictionary<uint, ulong> LandSeptMap
        {
            get { return m_landSeptMap; }
        }

        /// <summary>
        /// 通知获得选中地块的基础信息
        /// </summary>
        public GameEvent onGetLandBaseData = new GameEvent();
        /// <summary>
        /// 通知获得民用地块的可查看信息
        /// </summary>
        public GameEvent onGetCivilLandViewData = new GameEvent();
        /// <summary>
        /// 通知获得生产地块的可查看信息
        /// </summary>
        public GameEvent onGetProductLandViewData = new GameEvent();
        /// <summary>
        /// 通知开启民用地块建造请求服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspStartCivilLandBuild = new GameEvent<bool>();
        /// <summary>
        /// 通知获得民用地块建造进度信息
        /// </summary>
        public GameEvent onGetCivilLandBuildProgress = new GameEvent();
        /// <summary>
        /// 通知返回捐赠民用地块建造或升级资源后的捐赠进度及捐赠数量
        /// </summary>
        public GameEvent<uint, uint, bool> onRspDonateCivilLandBuildLevelup = new GameEvent<uint, uint, bool>();
        /// <summary>
        /// 通知请求获取建造任务服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspGetCivilLandBuildTask = new GameEvent<bool>();
        /// <summary>
        /// 通知完成民用地块建造请求服务器返回的结果及建造完成的外观id
        /// </summary>
        public GameEvent<bool, uint> onRspFinishCivilLandBuild = new GameEvent<bool, uint>();
        /// <summary>
        /// 通知获得民用地块可用外观信息
        /// </summary>
        public GameEvent onGetCivilLandModelData = new GameEvent();
        /// <summary>
        /// 通知请求购买民用地块外观服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspBuyCivilLandModel = new GameEvent<bool>();
        /// <summary>
        /// 通知请求使用民用地块外观服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspUseCivilLandModel = new GameEvent<bool>();
        /// <summary>
        /// 通知请求开始民用地块升级服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspStartCivilLandLevelup = new GameEvent<bool>();
        /// <summary>
        /// 通知获得民用地块升级进度信息
        /// </summary>
        public GameEvent onGetCivilLandLevelupProgress = new GameEvent();
        /// <summary>
        /// 通知完成民用地块升级请求服务器返回的结果和升级后的外观id
        /// </summary>
        public GameEvent<bool, uint> onRspFinishCivilLandLevelup = new GameEvent<bool, uint>();
        /// <summary>
        /// 通知GameScene创建自建城建筑
        /// </summary>
        public GameEvent onAddCityBuildings = new GameEvent();
        /// <summary>
        /// 通知GameScene删除自建城建筑
        /// </summary>
        public GameEvent onRemoveCityBuildings = new GameEvent();
        /// <summary>
        /// 通知请求选择生产类型服务器返回的结果
        /// </summary>
        public GameEvent<bool> onChooseProduceType = new GameEvent<bool>();
        /// <summary>
        /// 通知玩家生产地块信息返回
        /// </summary>
        public GameEvent onRspUserProduceInfo = new GameEvent();
        /// <summary>
        /// 通知请求开始生产服务器返回的结果
        /// </summary>
        public GameEvent<uint> onRspStartProduce = new GameEvent<uint>();
        /// <summary>
        /// 通知请求收获生产地块产出服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspReapProduction = new GameEvent<bool>();
        /// <summary>
        /// 通知请求改变生产地块生产类型服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspChangeProductType = new GameEvent<bool>();
        /// <summary>
        /// 通知请求完成转产服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspFinishChangeProductType = new GameEvent<bool>();
        /// <summary>
        /// 获取景观建筑建设进度服务器返回的结果
        /// </summary>
        public GameEvent onRspLandscapeBuildingInfo = new GameEvent();
        /// <summary>
        /// 通知获得经营地块的可查看信息
        /// </summary>
        public GameEvent onGetBusinessLandViewData = new GameEvent();
        /// <summary>
        /// 通知开启经营地块建造请求服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspStartBusinessLandBuild = new GameEvent<bool>();
        /// <summary>
        /// 通知开启经营地块升级请求服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspStartBusinessLandLevelUp = new GameEvent<bool>();
        /// <summary>
        /// 通知获得经营地块建造进度信息
        /// </summary>
        public GameEvent onGetBusinessLandBuildProgress = new GameEvent();
        /// <summary>
        /// 通知获得经营地块升级进度信息
        /// </summary>
        public GameEvent onGetBusinessLandLevelUpProgress = new GameEvent();
        /// <summary>
        /// 通知返回捐赠经营地块建造或升级资源后的捐赠进度及捐赠数量
        /// </summary>
        public GameEvent<uint, uint, bool> onRspDonateBusinessLandBuildLevelup = new GameEvent<uint, uint, bool>();
        /// <summary>
        /// 通知请求获取经营地块建造任务服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspGetBusinessLandBuildTask = new GameEvent<bool>();
        /// <summary>
        /// 通知完成经营地块建造请求服务器返回的结果及建造完成的外观id
        /// </summary>
        public GameEvent<bool, uint> onRspFinishBusinessLandBuild = new GameEvent<bool, uint>();
        /// <summary>
        /// 通知完成经营地块升级请求服务器返回的结果及建造完成的外观id
        /// </summary>
        public GameEvent<bool, uint> onRspFinishBusinessLandLevelup = new GameEvent<bool, uint>();
        /// <summary>
        /// 通知获得经营地块可用外观信息
        /// </summary>
        public GameEvent onGetBusinessLandModelData = new GameEvent();
        /// <summary>
        /// 通知请求购买经营地块外观服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspBuyBusinessLandModel = new GameEvent<bool>();
        /// <summary>
        /// 通知请求使用经营地块外观服务器返回的结果
        /// </summary>
        public GameEvent<bool> onRspUseBusinessLandModel = new GameEvent<bool>();
        /// <summary>
        /// 通知返回经营地块的经营度
        /// </summary>
        public GameEvent<uint> onRspBusinessLandBusinessPoint = new GameEvent<uint>();
        /// <summary>
        /// 通知返回经营地块的详细信息
        /// </summary>
        public GameEvent onRspBusinessLandDetail = new GameEvent();
        /// <summary>
        /// 通知经营地块店铺改名服务器返回
        /// </summary>
        public GameEvent onRspBusinessChangeName = new GameEvent();
        /// <summary>
        /// 通知经营地块店铺改名服务器返回
        /// </summary>
        public GameEvent onRspBusinessChangeAD = new GameEvent();
        /// <summary>
        /// 通知经营地块昨日订单完成情况服务器返回
        /// </summary>
        public GameEvent onRspBusinessReport = new GameEvent();
        /// <summary>
        /// 通知领取昨日订单奖励服务器返回
        /// </summary>
        public GameEvent<bool> onRspBusinessGetAward = new GameEvent<bool>();
        /// <summary>
        /// 通知改变经营范围的服务器返回
        /// </summary>
        public GameEvent<bool> onRspChangeBusinessType = new GameEvent<bool>();
        /// <summary>
        /// 通知订单备货服务器返回结果
        /// </summary>
        public GameEvent<uint, uint, bool> onRspDonateCommercialOrder = new GameEvent<uint, uint, bool>();
        /// <summary>
        /// 通知建筑外观改变
        /// </summary>
        public GameEvent<uint> onBuildingChange = new GameEvent<uint>();
        /// <summary>
        /// 通知查询地块工会id返回结果
        /// </summary>
        public GameEvent onRspLandSeptData = new GameEvent();

        #region 消息
        /// <summary>
        /// 请求地块基础信息
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqLandBaseInfo(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqLandBaseInfo.StartReqLandBaseInfo(fbb);
            ReqLandBaseInfo.AddLandId(fbb, landId);
            ReqLandBaseInfo.AddCityId(fbb, cityId);
            var msg = ReqLandBaseInfo.EndReqLandBaseInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqLandBaseInfo.HashID, fbb);
        }

        private void ProcRspLandBaseInfo(RspLandBaseInfo msg)
        {
            if (msg.land_type == LandType.Civil)
            {
                m_curCivilLandData = new BuildCityCivilLandData();
                m_curCivilLandData.InitBaseDataFromMsg(msg);
                m_curLandBaseData = m_curCivilLandData.BaseData;
                onGetLandBaseData.Invoke();
            }
            else if (msg.land_type == LandType.Production)
            {
                m_curProductLandData = new BuildCityProductLandData();
                m_curProductLandData.InitBaseDataFromMsg(msg);
                m_curLandBaseData = m_curProductLandData.BaseData;
                onGetLandBaseData.Invoke();
            }
            else if (msg.land_type == LandType.Commercial)
            {
                m_curBusinessLandData = new BuildCityBusinessLandData();
                m_curBusinessLandData.InitBaseDataFromMsg(msg);
                m_curLandBaseData = m_curBusinessLandData.BaseData;
                onGetLandBaseData.Invoke();
            }
        }

        /// <summary>
        /// 请求地块拍卖信息
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqViewAuctionInfo(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqViewAuctionInfo.StartReqViewAuctionInfo(fbb);
            ReqViewAuctionInfo.AddLandId(fbb, landId);
            ReqViewAuctionInfo.AddCityId(fbb, cityId);
            var msg = ReqViewAuctionInfo.EndReqViewAuctionInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqViewAuctionInfo.HashID, fbb);
        }

        private void ProcRspViewAuctionInfo(RspViewAuctionInfo msg)
        {
            if (m_curLandBaseData != null)
            {
                m_curLandBaseData.InitAuctionFromMsg(msg);
                if (m_curLandBaseData.Type == LandType.Civil)
                    onGetCivilLandViewData.Invoke();
                else if (m_curLandBaseData.Type == LandType.Production)
                    onGetProductLandViewData.Invoke();
                else if (m_curLandBaseData.Type == LandType.Commercial)
                    onGetBusinessLandViewData.Invoke();
            }
            else
                LogHelper.LogWarning("当前地块基础信息无效，初始化地块拍卖信息失败");
        }

        /// <summary>
        /// 请求地块可查看信息
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqViewLandInfo(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqViewLandInfo.StartReqViewLandInfo(fbb);
            ReqViewLandInfo.AddLandId(fbb, landId);
            ReqViewLandInfo.AddCityId(fbb, cityId);
            var msg = ReqViewLandInfo.EndReqViewLandInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqViewLandInfo.HashID, fbb);
        }

        private void ProcRspViewLandInfo(RspViewLandInfo msg)
        {
            if (m_curLandBaseData != null)
            {
                m_curLandBaseData.InitViewInfoFromMsg(msg);
                if (m_curLandBaseData.Type == LandType.Civil)
                    onGetCivilLandViewData.Invoke();
                else if (m_curLandBaseData.Type == LandType.Production)
                    onGetProductLandViewData.Invoke();
                else if (m_curLandBaseData.Type == LandType.Commercial)
                    onGetBusinessLandViewData.Invoke();
            }
            else
                LogHelper.LogWarning("当前地块基础信息无效，初始化地块可查看信息失败");
        }

        /// <summary>
        /// 请求开始地块建造
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="modelId"></param>
        public void SendReqStartCivilLandBuild(uint landId, uint cityId, uint modelId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqStartLandBuild.StartReqStartLandBuild(fbb);
            ReqStartLandBuild.AddLandId(fbb, landId);
            ReqStartLandBuild.AddCityId(fbb, cityId);
            ReqStartLandBuild.AddAppearanceId(fbb, modelId);
            var msg = ReqStartLandBuild.EndReqStartLandBuild(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqStartLandBuild.HashID, fbb);
        }

        private void ProcRspStartLandBuild(RspStartLandBuild msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，建造地块失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    if (m_curCivilLandData.BaseData.State == LandState.Empty)
                    {
                        if (msg.result)
                        {
                            m_curCivilLandData.BaseData.State = LandState.Building;
                            uint landId = m_curCivilLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Building;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspStartCivilLandBuild.Invoke(msg.result);
                    }
                    else if (m_curCivilLandData.BaseData.State == LandState.Normal)
                    {
                        if (msg.result)
                        {
                            m_curCivilLandData.BaseData.State = LandState.LevelUp;
                            uint landId = m_curCivilLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Building;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspStartCivilLandLevelup.Invoke(msg.result);
                    }
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，建造地块失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    if (m_curBusinessLandData.BaseData.State == LandState.Empty)
                    {
                        if (msg.result)
                        {
                            m_curBusinessLandData.BaseData.State = LandState.Building;
                            uint landId = m_curBusinessLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Building;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspStartBusinessLandBuild.Invoke(msg.result);
                    }
                    else if (m_curBusinessLandData.BaseData.State == LandState.Normal)
                    {
                        if (msg.result)
                        {
                            m_curBusinessLandData.BaseData.State = LandState.LevelUp;
                            uint landId = m_curBusinessLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.LevelUp;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspStartBusinessLandLevelUp.Invoke(msg.result);
                    }
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，建造地块失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，建造地块失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /// <summary>
        /// 请求地块建造进度
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqCivilLandBuildProgress(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqLandBuildProgress.StartReqLandBuildProgress(fbb);
            ReqLandBuildProgress.AddLandId(fbb, landId);
            ReqLandBuildProgress.AddCityId(fbb, cityId);
            var msg = ReqLandBuildProgress.EndReqLandBuildProgress(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqLandBuildProgress.HashID, fbb);
        }

        private void ProcRspLandBuildProgress(RspLandBuildProgress msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，获取地块建造进度失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    m_curCivilLandData.DonatedItemList.Clear();
                    for (int i = 0; i < msg.source_infoLength; i++)
                    {
                        var item = msg.source_info(i);
                        if (item.HasValue)
                        {
                            BuildCityDonatedData donatedItem = new BuildCityDonatedData();
                            donatedItem.Init(item.Value);
                            m_curCivilLandData.DonatedItemList.Add(donatedItem);
                        }
                    }
                    if (m_curCivilLandData.BaseData.State == LandState.Building)
                        onGetCivilLandBuildProgress.Invoke();
                    else if (m_curCivilLandData.BaseData.State == LandState.LevelUp)
                        onGetCivilLandLevelupProgress.Invoke();
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，获取民用地块建造进度失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    m_curBusinessLandData.DonatedItemList.Clear();
                    for (int i = 0; i < msg.source_infoLength; i++)
                    {
                        var item = msg.source_info(i);
                        if (item.HasValue)
                        {
                            BuildCityDonatedData donatedItem = new BuildCityDonatedData();
                            donatedItem.Init(item.Value);
                            m_curBusinessLandData.DonatedItemList.Add(donatedItem);
                        }
                    }
                    if (m_curBusinessLandData.BaseData.State == LandState.Building)
                        onGetBusinessLandBuildProgress.Invoke();
                    else if (m_curBusinessLandData.BaseData.State == LandState.LevelUp)
                        onGetBusinessLandLevelUpProgress.Invoke();
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，获取民用地块建造进度失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，获取地块建造进度失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /// <summary>
        /// 请求捐赠地块建造和升级资源
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="itemId"></param>
        /// <param name="itemCount"></param>
        public void SendReqDonateCivilLandBuildLevelup(uint landId, uint cityId, uint itemId, uint itemCount)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqDonateLandBuild.StartReqDonateLandBuild(fbb);
            ReqDonateLandBuild.AddLandId(fbb, landId);
            ReqDonateLandBuild.AddCityId(fbb, cityId);
            ReqDonateLandBuild.AddItemId(fbb, itemId);
            ReqDonateLandBuild.AddItemCount(fbb, itemCount);
            var msg = ReqDonateLandBuild.EndReqDonateLandBuild(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqDonateLandBuild.HashID, fbb);
        }

        private void ProcRspDonateLandBuild(RspDonateLandBuild msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，获取地块建造进度失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    m_curCivilLandData.DonatedItemList.Clear();
                    if (msg.is_finish)
                    {
                        if (m_curCivilLandData.BaseData.State == LandState.Building)
                            m_curCivilLandData.BaseData.State = LandState.BuildDone;
                        else if (m_curCivilLandData.BaseData.State == LandState.LevelUp)
                            m_curCivilLandData.BaseData.State = LandState.LevelUpDone;
                    }
                    else
                    {
                        for (int i = 0; i < msg.source_infoLength; i++)
                        {
                            var item = msg.source_info(i);
                            if (item.HasValue)
                            {
                                BuildCityDonatedData donatedItem = new BuildCityDonatedData();
                                donatedItem.Init(item.Value);
                                m_curCivilLandData.DonatedItemList.Add(donatedItem);
                            }
                        }
                    }
                    onRspDonateCivilLandBuildLevelup.Invoke(msg.item_id, msg.item_count, msg.is_finish);
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，捐赠地块建造资源失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    m_curBusinessLandData.DonatedItemList.Clear();
                    if (msg.is_finish)
                    {
                        if (m_curBusinessLandData.BaseData.State == LandState.Building)
                            m_curBusinessLandData.BaseData.State = LandState.BuildDone;
                        else if (m_curBusinessLandData.BaseData.State == LandState.LevelUp)
                            m_curBusinessLandData.BaseData.State = LandState.LevelUpDone;
                    }
                    else
                    {
                        for (int i = 0; i < msg.source_infoLength; i++)
                        {
                            var item = msg.source_info(i);
                            if (item.HasValue)
                            {
                                BuildCityDonatedData donatedItem = new BuildCityDonatedData();
                                donatedItem.Init(item.Value);
                                m_curBusinessLandData.DonatedItemList.Add(donatedItem);
                            }
                        }
                    }
                    onRspDonateBusinessLandBuildLevelup.Invoke(msg.item_id, msg.item_count, msg.is_finish);
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，捐赠地块建造资源失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，捐赠地块建造资源失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /// <summary>
        /// 请求获得地块建造任务
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqCivilLandBuildTask(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqLandBuildTask.StartReqLandBuildTask(fbb);
            ReqLandBuildTask.AddLandId(fbb, landId);
            ReqLandBuildTask.AddCityId(fbb, cityId);
            var msg = ReqLandBuildTask.EndReqLandBuildTask(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqLandBuildTask.HashID, fbb);
        }

        private void ProcRspLandBuildTask(RspLandBuildTask msg)
        {
            onRspGetCivilLandBuildTask.Invoke(msg.result);
        }

        /// <summary>
        /// 请求完成地块建造
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqFinishCivilLandBuild(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqFinishLandBuild.StartReqFinishLandBuild(fbb);
            ReqFinishLandBuild.AddLandId(fbb, landId);
            ReqFinishLandBuild.AddCityId(fbb, cityId);
            var msg = ReqFinishLandBuild.EndReqFinishLandBuild(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqFinishLandBuild.HashID, fbb);
        }

        private void ProcRspFinishLandBuild(RspFinishLandBuild msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，完成地块建造失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    if (m_curCivilLandData.BaseData.State == LandState.BuildDone)
                    {
                        if (msg.result)
                        {
                            m_curCivilLandData.BaseData.State = LandState.Normal;
                            m_curCivilLandData.InitNextLevelModel();
                            m_curCivilLandData.ModelId = msg.appearance_id;
                            uint landId = m_curCivilLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Normal;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspFinishCivilLandBuild.Invoke(msg.result, msg.appearance_id);
                    }
                    else if (m_curCivilLandData.BaseData.State == LandState.LevelUpDone)
                    {
                        if (msg.result)
                        {
                            m_curCivilLandData.UpdateLandLevel(m_curCivilLandData.BaseData.Level + 1);
                            m_curCivilLandData.RefreshModelUnlockState();
                            m_curCivilLandData.InitNextLevelModel();
                            m_curCivilLandData.ModelId = msg.appearance_id;
                            m_curCivilLandData.BaseData.State = LandState.Normal;
                            uint landId = m_curCivilLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Normal;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspFinishCivilLandLevelup.Invoke(msg.result, msg.appearance_id);
                    }
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，完成民用地块建造失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    if (m_curBusinessLandData.BaseData.State == LandState.BuildDone)
                    {
                        if (msg.result)
                        {
                            m_curBusinessLandData.BaseData.State = LandState.Normal;
                            m_curBusinessLandData.SetBusinessType(msg.appearance_id);
                            m_curBusinessLandData.RefreshModelList();
                            uint landId = m_curBusinessLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Normal;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspFinishBusinessLandBuild.Invoke(msg.result, msg.appearance_id);
                    }
                    else if (m_curBusinessLandData.BaseData.State == LandState.LevelUpDone)
                    {
                        if (msg.result)
                        {
                            m_curBusinessLandData.UpdateLandLevel(m_curBusinessLandData.BaseData.Level + 1);
                            m_curBusinessLandData.RefreshModelUnlockState();
                            m_curBusinessLandData.RefreshModelList();
                            m_curBusinessLandData.SetBusinessType(msg.appearance_id);
                            m_curBusinessLandData.BaseData.State = LandState.Normal;
                            uint landId = m_curBusinessLandData.BaseData.Id;
                            if (m_buildingDataMap.ContainsKey(landId))
                            {
                                m_buildingDataMap[landId].ModelId = msg.appearance_id;
                                m_buildingDataMap[landId].State = LandState.Normal;
                                m_buildingManager.RefreshLandBuilding(landId);
                                onBuildingChange.Invoke(landId);
                            }
                        }
                        onRspFinishBusinessLandLevelup.Invoke(msg.result, msg.appearance_id);
                    }
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，完成经营地块建造失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，完成地块建造失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /// <summary>
        /// 请求地块外观信息
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqCivilLandAppearance(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqLandAppearance.StartReqLandAppearance(fbb);
            ReqLandAppearance.AddLandId(fbb, landId);
            ReqLandAppearance.AddCityId(fbb, cityId);
            var msg = ReqLandAppearance.EndReqLandAppearance(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqLandAppearance.HashID, fbb);
        }

        private void ProcRspLandAppearance(RspLandAppearance msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，请求地块外观信息失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    m_curCivilLandData.ModelId = msg.cur_appearance;
                    m_curCivilLandData.ChangeModelCount = msg.change_count;
                    for (int i = 0; i < msg.appearance_listLength; i++)
                    {
                        uint modelId = msg.appearance_list(i);
                        m_curCivilLandData.RefreshModelState(modelId);
                    }
                    m_curCivilLandData.SortModelList();
                    onGetCivilLandModelData.Invoke();
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，获取民用地块外观信息失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    m_curBusinessLandData.ModelId = msg.cur_appearance;
                    m_curBusinessLandData.SetChangeBuisnessTime(msg.next_change_time);
                    for (int i = 0; i < msg.appearance_listLength; i++)
                    {
                        uint modelId = msg.appearance_list(i);
                        m_curBusinessLandData.RefreshModelState(modelId);
                    }
                    m_curBusinessLandData.SortModelList();
                    onGetBusinessLandModelData.Invoke();
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，获取民用地块外观信息失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，请求地块外观信息失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /// <summary>
        /// 请求购买地块外观
        /// </summary>
        /// <param name="modelId"></param>
        public void SendReqBuyCivilLandAppearance(uint landId, uint cityId, uint modelId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqBuyLandAppearance.StartReqBuyLandAppearance(fbb);
            ReqBuyLandAppearance.AddLandId(fbb, landId);
            ReqBuyLandAppearance.AddCityId(fbb, cityId);
            ReqBuyLandAppearance.AddAppearanceId(fbb, modelId);
            var msg = ReqBuyLandAppearance.EndReqBuyLandAppearance(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqBuyLandAppearance.HashID, fbb);
        }

        private void ProcRspBuyLandAppearance(RspBuyLandAppearance msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，请求购买地块外观失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    for (int i = 0; i < msg.appearance_listLength; i++)
                    {
                        uint modelId = msg.appearance_list(i);
                        m_curCivilLandData.RefreshModelState(modelId);
                    }
                    m_curCivilLandData.SortModelList();
                    onRspBuyCivilLandModel.Invoke(msg.result);
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，购买民用地块建造外观失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    for (int i = 0; i < msg.appearance_listLength; i++)
                    {
                        uint modelId = msg.appearance_list(i);
                        m_curBusinessLandData.RefreshModelState(modelId);
                    }
                    m_curBusinessLandData.SortModelList();
                    onRspBuyBusinessLandModel.Invoke(msg.result);
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，购买经营地块建造外观失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，请求购买地块外观失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /// <summary>
        /// 请求使用地块外观
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="modelId"></param>
        public void SendReqUseCivilLandAppearance(uint landId, uint cityId, uint modelId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqUseLandAppearance.StartReqUseLandAppearance(fbb);
            ReqUseLandAppearance.AddLandId(fbb, landId);
            ReqUseLandAppearance.AddCityId(fbb, cityId);
            ReqUseLandAppearance.AddAppearanceId(fbb, modelId);
            var msg = ReqUseLandAppearance.EndReqUseLandAppearance(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqUseLandAppearance.HashID, fbb);
        }

        private void ProcRspUseLandAppearance(RspUseLandAppearance msg)
        {
            if (m_curLandBaseData == null)
            {
                LogHelper.LogWarning("当前地块基础信息无效，请求使用地块外观失败");
                return;
            }
            if (m_curLandBaseData.Type == LandType.Civil)
            {
                if (m_curCivilLandData != null)
                {
                    if (msg.result)
                    {
                        m_curCivilLandData.ChangeModelCount++;
                        m_curCivilLandData.ModelId = msg.appearance_id;
                        uint landId = m_curCivilLandData.BaseData.Id;
                        if (m_buildingDataMap.ContainsKey(landId))
                        {
                            m_buildingDataMap[landId].ModelId = msg.appearance_id;
                            m_buildingManager.RefreshLandBuilding(landId);
                            onBuildingChange.Invoke(landId);
                        }
                    }
                    onRspUseCivilLandModel.Invoke(msg.result);
                }
                else
                    LogHelper.LogWarning("当前民用地块信息无效，修改民用地块外观失败");
            }
            else if (m_curLandBaseData.Type == LandType.Commercial)
            {
                if (m_curBusinessLandData != null)
                {
                    if (msg.result)
                    {
                        m_curBusinessLandData.ModelId = msg.appearance_id;
                        uint landId = m_curBusinessLandData.BaseData.Id;
                        if (m_buildingDataMap.ContainsKey(landId))
                        {
                            m_buildingDataMap[landId].ModelId = msg.appearance_id;
                            m_buildingManager.RefreshLandBuilding(landId);
                            onBuildingChange.Invoke(landId);
                        }
                    }
                    onRspUseBusinessLandModel.Invoke(msg.result);
                }
                else
                    LogHelper.LogWarning("当前经营地块信息无效，修改经营地块外观失败");
            }
            else
                LogHelper.LogWarningFormat("当前地块类型无效，请求购买地块外观失败。地块id:{0},地块类型:{1}", m_curLandBaseData.Id, m_curLandBaseData.Type.ToString());
        }

        /*
        /// <summary>
        /// 请求升级民用地块
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="modelId"></param>
        public void SendReqStartCivilLandLevelup(uint landId, uint cityId, uint modelId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqStartCivilLandLevelup.StartReqStartCivilLandLevelup(fbb);
            ReqStartCivilLandLevelup.AddLandId(fbb, landId);
            ReqStartCivilLandLevelup.AddCityId(fbb, cityId);
            ReqStartCivilLandLevelup.AddAppearanceId(fbb, modelId);
            var msg = ReqStartCivilLandLevelup.EndReqStartCivilLandLevelup(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqStartCivilLandLevelup.HashID, fbb);
        }

        private void ProcRspStartCivilLandLevelup(RspStartCivilLandLevelup msg)
        {
            if (m_curCivilLandData != null)
            {
                if (msg.result)
                {
                    m_curCivilLandData.BaseData.State = LandState.LevelUp;
                    uint landId = m_curCivilLandData.BaseData.Id;
                    if (m_buildingDataMap.ContainsKey(landId))
                    {
                        m_buildingDataMap[landId].ModelId = msg.appearance_id;
                        m_buildingDataMap[landId].State = LandState.LevelUp;
                        m_buildingManager.RefreshLandBuilding(landId);
                    }
                }
                onRspStartCivilLandLevelup.Invoke(msg.result);
            }
            else
                LogHelper.LogError("当前民用地块信息无效，民用地块升级失败");
        }

        /// <summary>
        /// 请求民用地块升级进度
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqCivilLandLevelupProgress(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqCivilLandLevelupProgress.StartReqCivilLandLevelupProgress(fbb);
            ReqCivilLandLevelupProgress.AddLandId(fbb, landId);
            ReqCivilLandLevelupProgress.AddCityId(fbb, cityId);
            var msg = ReqCivilLandLevelupProgress.EndReqCivilLandLevelupProgress(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqCivilLandLevelupProgress.HashID, fbb);
        }

        private void ProcRspCivilLandLevelupProgress(RspCivilLandLevelupProgress msg)
        {
            if (m_curCivilLandData != null)
            {
                m_curCivilLandData.DonatedItemList.Clear();
                for (int i = 0; i < msg.source_infoLength; i++)
                {
                    var item = msg.source_info(i);
                    if (item.HasValue)
                    {
                        BuildCityDonatedData donatedItem = new BuildCityDonatedData();
                        donatedItem.Init(item.Value);
                        m_curCivilLandData.DonatedItemList.Add(donatedItem);
                    }
                }
                onGetCivilLandLevelupProgress.Invoke();
            }
            else
                LogHelper.LogError("当前民用地块信息无效，获取民用地块升级失败");
        }

        /// <summary>
        /// 请求完成民用地块升级
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqCivilLandFinishLevelup(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqFinishCivilLandLevelup.StartReqFinishCivilLandLevelup(fbb);
            ReqFinishCivilLandLevelup.AddLandId(fbb, landId);
            ReqFinishCivilLandLevelup.AddCityId(fbb, cityId);
            var msg = ReqFinishCivilLandLevelup.EndReqFinishCivilLandLevelup(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqFinishCivilLandLevelup.HashID, fbb);
        }

        private void ProcRspFinishCivilLandLevelup(RspFinishCivilLandLevelup msg)
        {
            if (m_curCivilLandData != null)
            {
                if (msg.result)
                {
                    m_curCivilLandData.BaseData.Level += 1;
                    m_curCivilLandData.RefreshModelUnlockState();
                    m_curCivilLandData.InitNextLevelModel();
                    m_curCivilLandData.ModelId = msg.appearance_id;
                    m_curCivilLandData.BaseData.State = LandState.Normal;
                    uint landId = m_curCivilLandData.BaseData.Id;
                    if (m_buildingDataMap.ContainsKey(landId))
                    {
                        m_buildingDataMap[landId].ModelId = msg.appearance_id;
                        m_buildingDataMap[landId].State = LandState.Normal;
                        m_buildingManager.RefreshLandBuilding(landId);
                        m_buildingManager.PlayBuildingCompleteEffect(landId);
                    }
                }
                onRspFinishCivilLandLevelup.Invoke(msg.result, msg.appearance_id);
            }
            else
                LogHelper.LogError("当前民用地块信息无效，民用地块升级失败");
        }
        */

        /// <summary>
        /// 请求获取当前城市所有地块当前外观
        /// </summary>
        public void SendReqCityLandAppearance(uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqCityLandAppearance.StartReqCityLandAppearance(fbb);
            ReqCityLandAppearance.AddCityId(fbb, cityId);
            var msg = ReqCityLandAppearance.EndReqCityLandAppearance(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqCityLandAppearance.HashID, fbb);
        }

        private void ProcRspCityLandAppearance(RspCityLandAppearance msg)
        {
            m_buildingDataMap.Clear();
            for (int i = 0; i < msg.land_listLength; i++)
            {
                var item = msg.land_list(i);
                if (item.HasValue && item.Value.appearance_id != 0)
                {
                    BuildCityModelData data = new BuildCityModelData();
                    data.LandId = item.Value.land_id;
                    data.CityId = item.Value.city_id;
                    data.ModelId = item.Value.appearance_id;
                    data.State = item.Value.land_state;
                    data.BuildProgress = (int)item.Value.build_percent;
                    m_buildingDataMap[data.LandId] = data;
                }
            }
            onAddCityBuildings.Invoke();
        }

        /// <summary>
        /// 通知地块外观变化
        /// </summary>
        /// <param name="msg"></param>
        private void ProcNotifyLandAppearance(NotifyLandAppearance msg)
        {
            if (m_buildingDataMap.ContainsKey(msg.land_id))
            {
                var data = m_buildingDataMap[msg.land_id];
                uint curProgress = (uint)data.BuildProgress;
                if (data.ModelId != msg.appearance_id || data.State != msg.land_state || curProgress != msg.build_percent)
                {
                    data.ModelId = msg.appearance_id;
                    data.State = msg.land_state;
                    data.BuildProgress = (int)msg.build_percent;
                    if (m_buildingManager.CheckChangeLandBuilding(msg.land_id))
                        onBuildingChange.Invoke(msg.land_id);
                }
            }
            else
            {
                BuildCityTableBase? config = BuildCityTableManager.GetData((int)msg.land_id);
                if (config.HasValue && config.Value.city == m_buildingManager.CityId)
                {
                    BuildCityModelData data = new BuildCityModelData();
                    data.LandId = msg.land_id;
                    data.CityId = (uint)config.Value.city;
                    data.ModelId = msg.appearance_id;
                    data.State = msg.land_state;
                    data.BuildProgress = (int)msg.build_percent;
                    m_buildingDataMap[data.LandId] = data;
                    m_buildingManager.RefreshLandBuilding(msg.land_id);
                    onBuildingChange.Invoke(msg.land_id);
                }
            }
        }

        /// <summary>
        /// 选择生产地块生产类型
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="modelId"></param>
        public void SendReqChooseProduceType(uint landId, uint cityId, uint modelId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqChooseProduceType.StartReqChooseProduceType(fbb);
            ReqChooseProduceType.AddLandId(fbb, landId);
            ReqChooseProduceType.AddCityId(fbb, cityId);
            ReqChooseProduceType.AddAppearanceId(fbb, modelId);
            var msg = ReqChooseProduceType.EndReqChooseProduceType(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqChooseProduceType.HashID, fbb);
        }

        private void ProcRspChooseProduceType(RspChooseProduceType msg)
        {
            if (m_curProductLandData != null)
            {
                if (msg.result)
                {
                    m_curProductLandData.BaseData.State = LandState.Producting;
                    m_curProductLandData.SetModelId(msg.appearance_id);
                    m_curProductLandData.RefreshModelsState();
                    m_curProductLandData.RefreshProductDetails();
                    uint landId = m_curProductLandData.BaseData.Id;
                    if (m_buildingDataMap.ContainsKey(landId))
                    {
                        m_buildingDataMap[landId].ModelId = msg.appearance_id;
                        m_buildingDataMap[landId].State = LandState.Producting;
                        m_buildingManager.RefreshLandBuilding(landId);
                        onBuildingChange.Invoke(landId);
                    }
                }
                onChooseProduceType.Invoke(msg.result);
            }
            else
                LogHelper.LogWarning("当前生产地块信息无效，选择生产大类失败");
        }

        /// <summary>
        /// 请求玩家在生产地块的生产信息
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqUserProduceInfo(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqUserProduceInfo.StartReqUserProduceInfo(fbb);
            ReqUserProduceInfo.AddLandId(fbb, landId);
            ReqUserProduceInfo.AddCityId(fbb, cityId);
            var msg = ReqUserProduceInfo.EndReqUserProduceInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqUserProduceInfo.HashID, fbb);
        }

        private void ProcRspUserProduceInfo(RspUserProduceInfo msg)
        {
            if (m_curProductLandData != null)
            {
                m_curProductLandData.InitUserDataFromMsg(msg);
                onRspUserProduceInfo.Invoke();
            }
            else
                LogHelper.LogWarning("当前生产地块信息无效，获取生产地块玩家信息失败");
        }

        /// <summary>
        /// 发送开始生产请求
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="productid"></param>
        /// <param name="count"></param>
        public void SendReqStartProduce(uint landId, uint cityId, uint productid, uint count)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqStartProduce.StartReqStartProduce(fbb);
            ReqStartProduce.AddLandId(fbb, landId);
            ReqStartProduce.AddCityId(fbb, cityId);
            ReqStartProduce.AddProductId(fbb, productid);
            ReqStartProduce.AddProductCount(fbb, count);
            var msg = ReqStartProduce.EndReqStartProduce(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqStartProduce.HashID, fbb);
        }

        private void ProcRspStartProduce(RspStartProduce msg)
        {
            onRspStartProduce.Invoke(msg.product_count);
        }

        /// <summary>
        /// 发送收获请求
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqReapProduction(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqReapProduction.StartReqReapProduction(fbb);
            ReqReapProduction.AddLandId(fbb, landId);
            ReqReapProduction.AddCityId(fbb, cityId);
            var msg = ReqReapProduction.EndReqReapProduction(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqReapProduction.HashID, fbb);
        }

        private void ProcRspReapProduction(RspReapProduction msg)
        {
            if (m_curProductLandData != null)
            {
                m_curProductLandData.ReapProductionList.Clear();
                for (int i = 0; i < msg.production_infoLength; i++)
                {
                    LandItemData? info = msg.production_info(i);
                    if (info.HasValue)
                    {
                        BuildCityProductionData data = new BuildCityProductionData();
                        data.Init(info.Value.item_id, info.Value.item_count);
                        m_curProductLandData.ReapProductionList.Add(data);
                    }
                }
                if (msg.result)
                {
                    m_curProductLandData.ProductId = 0;
                    m_curProductLandData.ProductItemList.Clear();
                }
                onRspReapProduction.Invoke(msg.result);
            }
            else
                LogHelper.LogWarning("当前生产地块信息无效，收获生产道具失败");
        }

        /// <summary>
        /// 发送转产请求
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        /// <param name="product_type"></param>
        public void SendReqChangeProductType(uint landId, uint cityId, uint product_type)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqChangeProductType.StartReqChangeProductType(fbb);
            ReqChangeProductType.AddLandId(fbb, landId);
            ReqChangeProductType.AddCityId(fbb, cityId);
            ReqChangeProductType.AddAppearanceId(fbb, product_type);
            var msg = ReqChangeProductType.EndReqChangeProductType(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqChangeProductType.HashID, fbb);
        }

        private void ProcRspChangeProductType(RspChangeProductType msg)
        {
            if (m_curProductLandData != null)
            {
                if (msg.result)
                    m_curProductLandData.BaseData.State = LandState.ChangeProduct;
                onRspChangeProductType.Invoke(msg.result);
            }
            else
                LogHelper.LogWarning("当前生产地块信息无效，转产失败");
        }

        /// <summary>
        /// 发送完成转产请求
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="cityId"></param>
        public void SendReqFinishChangeProductType(uint landId, uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqFinishChangeProductType.StartReqFinishChangeProductType(fbb);
            ReqFinishChangeProductType.AddLandId(fbb, landId);
            ReqFinishChangeProductType.AddCityId(fbb, cityId);
            var msg = ReqFinishChangeProductType.EndReqFinishChangeProductType(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqFinishChangeProductType.HashID, fbb);
        }

        private void ProcRspFinishChangeProductType(RspFinishChangeProductType msg)
        {
            if (m_curProductLandData != null)
            {
                if (msg.result)
                {
                    m_curProductLandData.BaseData.State = LandState.Producting;
                    m_curProductLandData.SetModelId(msg.appearance_id);
                    m_curProductLandData.RefreshModelsState();
                    m_curProductLandData.RefreshProductDetails();
                    uint landId = m_curProductLandData.BaseData.Id;
                    if (m_buildingDataMap.ContainsKey(landId))
                    {
                        m_buildingDataMap[landId].ModelId = msg.appearance_id;
                        m_buildingDataMap[landId].State = LandState.Producting;
                        m_buildingManager.RefreshLandBuilding(landId);
                        onBuildingChange.Invoke(landId);
                    }
                }
                onRspFinishChangeProductType.Invoke(msg.result);
            }
            else
                LogHelper.LogWarning("当前生产地块信息无效，完成转产失败");
        }

        /// <summary>
        /// 发送请求城市景观建筑信息
        /// </summary>
        /// <param name="cityId"></param>
        public void SendReqLandscapeBuildingList(uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqLandscapeBuildingList.StartReqLandscapeBuildingList(fbb);
            ReqLandscapeBuildingList.AddCityId(fbb, cityId);
            var msg = ReqLandscapeBuildingList.EndReqLandscapeBuildingList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqLandscapeBuildingList.HashID, fbb);
        }

        private void ProcRspLandscapeBuildingList(RspLandscapeBuildingList msg)
        {
            m_landscapeDataMap.Clear();
            for (int i = 0; i < msg.land_listLength; i++)
            {
                var landscape = msg.land_list(i);
                if (landscape.HasValue)
                {
                    BuildCityLandscapeData data = new BuildCityLandscapeData();
                    data.Init(landscape.Value.land_id, msg.city_id, landscape.Value.level);
                    data.SetBuildPoint(landscape.Value.build_progress);
                    m_landscapeDataMap.Add(data.Id, data);
                }
            }
            onRspLandscapeBuildingInfo.Invoke();
        }

        /// <summary>
        /// 请求经营地块经营度
        /// </summary>
        /// <param name="landId"></param>
        public void SendReqCommercialLandManagement(uint landId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqCommercialLandManagement.StartReqCommercialLandManagement(fbb);
            ReqCommercialLandManagement.AddLandId(fbb, landId);
            var msg = ReqCommercialLandManagement.EndReqCommercialLandManagement(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqCommercialLandManagement.HashID, fbb);
        }

        private void ProcRspCommercialLandManagement(RspCommercialLandManagement msg)
        {
            if (m_curBusinessLandData != null)
            {
                m_curBusinessLandData.RefreshBusinessPoint(msg.management);
                onRspBusinessLandBusinessPoint.Invoke(m_curBusinessLandData.CurBusinessPoint);
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，查询经营度失败");
        }

        /// <summary>
        /// 请求经营地块详细信息
        /// </summary>
        /// <param name="landId"></param>
        public void SendReqCommercialLandInfo(uint landId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqCommercialLandInfo.StartReqCommercialLandInfo(fbb);
            ReqCommercialLandInfo.AddLandId(fbb, landId);
            var msg = ReqCommercialLandInfo.EndReqCommercialLandInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqCommercialLandInfo.HashID, fbb);
        }

        private void ProcRspCommercialLandInfo(RspCommercialLandInfo msg)
        {
            if (m_curBusinessLandData != null)
            {
                m_curBusinessLandData.InitBusinessDataFromMsg(msg);
                onRspBusinessLandDetail.Invoke();
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，查询经营地块详细信息失败");
        }

        /// <summary>
        /// 请求修改经营地块店铺名字
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="name"></param>
        public void SendReqChangeCommercialLandName(uint landId, string name)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var nameOffset = fbb.CreateString(name);
            Offset<ReqChangeCommercialLandName> tOffset = ReqChangeCommercialLandName.CreateReqChangeCommercialLandName(fbb, landId, nameOffset);
            fbb.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqChangeCommercialLandName.HashID, fbb);
        }

        private void ProcRspChangeCommercialLandName(RspChangeCommercialLandName msg)
        {
            if (m_curBusinessLandData != null)
            {
                m_curBusinessLandData.ShopName = msg.name;
                onRspBusinessChangeName.Invoke();
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，修改店铺名字失败");
        }

        /// <summary>
        /// 请求修改经营店铺广告
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="shopAD"></param>
        public void SendReqChangeCommercialLandAD(uint landId, string shopAD)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var adOffset = fbb.CreateString(shopAD);
            Offset<ReqChangeCommercialLandAD> tOffset = ReqChangeCommercialLandAD.CreateReqChangeCommercialLandAD(fbb, landId, adOffset);
            fbb.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqChangeCommercialLandAD.HashID, fbb);
        }

        private void ProcRspChangeCommercialLandAD(RspChangeCommercialLandAD msg)
        {
            if (m_curBusinessLandData != null)
            {
                m_curBusinessLandData.ShopAd = msg.advertisement;
                onRspBusinessChangeAD.Invoke();
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，修改店铺广告失败");
        }

        /// <summary>
        /// 请求经营地块昨日订单完成情况
        /// </summary>
        /// <param name="landId"></param>
        public void SendReqYesterdayUserOrderInfo(uint landId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqYesterdayUserOrderInfo.StartReqYesterdayUserOrderInfo(fbb);
            ReqYesterdayUserOrderInfo.AddLandId(fbb, landId);
            var msg = ReqYesterdayUserOrderInfo.EndReqYesterdayUserOrderInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqYesterdayUserOrderInfo.HashID, fbb);
        }

        private void ProcRspYesterdayUserOrderInfo(RspYesterdayUserOrderInfo msg)
        {
            if (m_curBusinessLandData != null)
            {
                m_curBusinessLandData.YesterdayReport = new BuildCityBusinessOrderReport();
                m_curBusinessLandData.YesterdayReport.InitData(msg);
                onRspBusinessReport.Invoke();
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，获取昨日订单完成报告失败");
        }

        /// <summary>
        /// 请求领取昨日订单完成奖励
        /// </summary>
        /// <param name="landId"></param>
        public void SendReqClaimYesterdayOrderAward(uint landId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqClaimYesterdayOrderAward.StartReqClaimYesterdayOrderAward(fbb);
            ReqClaimYesterdayOrderAward.AddLandId(fbb, landId);
            var msg = ReqClaimYesterdayOrderAward.EndReqClaimYesterdayOrderAward(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqClaimYesterdayOrderAward.HashID, fbb);
        }

        private void ProcRspClaimYesterdayOrderAward(RspClaimYesterdayOrderAward msg)
        {
            if (m_curBusinessLandData != null && m_curBusinessLandData.YesterdayReport != null)
            {
                if (msg.result)
                {
                    m_curBusinessLandData.YesterdayReport.AwardList.Clear();
                    m_curBusinessLandData.YesterdayReport.HasAward = false;
                }
                onRspBusinessGetAward.Invoke(msg.result);
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，领取昨日订单完成奖励失败");
        }

        /// <summary>
        /// 请求修改经营范围
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="ModelId"></param>
        public void SendReqChangeCommercialType(uint landId, uint ModelId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqChangeCommercialType.StartReqChangeCommercialType(fbb);
            ReqChangeCommercialType.AddLandId(fbb, landId);
            ReqChangeCommercialType.AddAppearanceId(fbb, ModelId);
            var msg = ReqChangeCommercialType.EndReqChangeCommercialType(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqChangeCommercialType.HashID, fbb);
        }

        private void ProcRspChangeCommercialType(RspChangeCommercialType msg)
        {
            if (m_curBusinessLandData != null)
            {
                if (msg.result)
                {
                    m_curBusinessLandData.SetBusinessType(msg.appearance_id);
                    uint landId = msg.land_id;
                    if (m_buildingDataMap.ContainsKey(landId))
                    {
                        m_buildingDataMap[landId].ModelId = msg.appearance_id;
                        m_buildingManager.RefreshLandBuilding(landId);
                        onBuildingChange.Invoke(landId);
                    }
                }
                onRspChangeBusinessType.Invoke(msg.result);
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，请求修改经营范围失败");
        }

        /// <summary>
        /// 请求为订单备货
        /// </summary>
        /// <param name="landId"></param>
        /// <param name="orderIndex"></param>
        /// <param name="itemId"></param>
        /// <param name="itemCount"></param>
        public void SendReqDonateCommercialOrder(uint landId, uint orderIndex, uint itemId, uint itemCount)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqDonateCommercialOrder.StartReqDonateCommercialOrder(fbb);
            ReqDonateCommercialOrder.AddLandId(fbb, landId);
            ReqDonateCommercialOrder.AddOrderIndex(fbb, orderIndex);
            ReqDonateCommercialOrder.AddItemId(fbb, itemId);
            ReqDonateCommercialOrder.AddItemCount(fbb, itemCount);
            var msg = ReqDonateCommercialOrder.EndReqDonateCommercialOrder(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqDonateCommercialOrder.HashID, fbb);
        }

        private void ProcRspDonateCommercialOrder(RspDonateCommercialOrder msg)
        {
            if (m_curBusinessLandData != null)
            {
                if (msg.order_info.HasValue)
                {
                    m_curBusinessLandData.RefreshOrderData(msg.order_index, msg.order_info.Value);
                    onRspDonateCommercialOrder.Invoke(msg.item_id, msg.item_count, msg.is_finish);
                }
                else
                    LogHelper.LogWarning("刷新订单数据失败，服务器返回订单数据无效");
            }
            else
                LogHelper.LogWarning("当前经营地块信息无效，刷新订单数据失败");
        }

        /// <summary>
        /// 请求城市所有地块所属仙门信息
        /// </summary>
        /// <param name="cityId"></param>
        public void SendReqCityLandSeptID(uint cityId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqCityLandSeptID.StartReqCityLandSeptID(fbb);
            ReqCityLandSeptID.AddCityId(fbb, cityId);
            var msg = ReqCityLandSeptID.EndReqCityLandSeptID(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(ReqCityLandSeptID.HashID, fbb);
        }

        private void ProcRspCityLandSeptID(RspCityLandSeptID msg)
        {
            m_landSeptMap.Clear();
            for (int i = 0; i < msg.sept_listLength; i++)
            {
                var landSeptInfo = msg.sept_list(i);
                if (landSeptInfo.HasValue && landSeptInfo.Value.sept_id != 0)
                    m_landSeptMap[landSeptInfo.Value.land_id] = landSeptInfo.Value.sept_id;
            }
            onRspLandSeptData.Invoke();
        }
        #endregion

        /// <summary>
        /// 判断玩家是否是拥有当前地块仙门的成员
        /// </summary>
        /// <returns></returns>
        public bool CheckLandSeptMember()
        {
            if (m_curLandBaseData != null && m_curLandBaseData.SeptId != 0 && GameScene.Instance.MainChar != null)
            {
                if (GameScene.Instance.MainChar.SociatyID == m_curLandBaseData.SeptId)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// 判断仙门建筑管理权限
        /// </summary>
        /// <returns></returns>
        public bool CheckSeptCommission()
        {
            if (CheckLandSeptMember())
                return SociatyManager.Instance.IsMainMemberLeader();
            return false;
        }

        public string GetLandscapeFinishTimeline(uint landId)
        {
            string timelineName = string.Empty;
            BuildCityLandscapeBase? config = BuildCityLandscapeManager.GetData((int)landId);
            if (config.HasValue && config.Value.build_movieLength == 2)
            {
                timelineName = config.Value.build_movie(1);
            }
            return timelineName;
        }
        
        #region temp code
        public uint GetLandId(int index)
        {
            if (index < BuildCityTableManager.Instance.m_DataList.BuildCityTableLength)
            {
                BuildCityTableBase? config = BuildCityTableManager.Instance.m_DataList.BuildCityTable(index - 1);
                if (config.HasValue)
                    return (uint)config.Value.id;
            }
            return 0;
        }
        #endregion
    }
}