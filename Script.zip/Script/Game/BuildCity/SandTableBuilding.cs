using UnityEngine;
using System;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public interface ISandTablePickable
    {
        float PickDistance { get; }

        uint CityId { get; }

        uint LandId { get; set; }

        bool Pickable { get; set; }

        uint Type { get; }

        bool Pick(Ray ray);

        void OnMouseHoverIn();

        void OnMouseHoverOut();

        void OnSelect();

        void OnUnselect();

        void ShowTopArrow(bool state);
    }

    public class SandTableBuilding : AvatarEvent, ISandTablePickable
    {
        private IAvatar m_avatar;
        private GameObject m_landObj;
        private BoxCollider m_landCollider; //地块collider
        private MeshCollider m_collider;    //建筑collider
        private BuildCityModelData m_data;
        private BuildCityModelBase? m_modelConfig;
        private BuildCityTableBase? m_landConfig;
        private float m_eulerY = 0; //Y轴旋转角度
        private float m_scale = 1;  //模型缩放比例
        //private string m_modelPath = string.Empty;
        private readonly char[] pathBreak = new char[] { ':' };
        private IAvatar m_scaffold;
        private float m_scaffoldEulerY = 0;
        private float m_scaffoldScale = 1;
        private string m_scaffoldPath = string.Empty;
        private bool m_IsScaffoldLoad = false;
        private GameObject m_arrowObj;
        private bool m_IsSelfSeptLand;

        private float m_pickDistance;
        public float PickDistance
        {
            get { return m_pickDistance; }
        }

        public uint CityId
        {
            get { return 1; }
        }

        private uint land_id;
        public uint LandId
        {
            get { return land_id; }
            set { land_id = value; }
        }

        private bool m_Pickable;
        public bool Pickable
        {
            get { return m_Pickable; }
            set { m_Pickable = value; }
        }

        public uint Type
        {
            get { return 1; }
        }

        /// <summary>
        /// 是否是自己工会的地块
        /// </summary>
        public bool IsSelfSeptLand
        {
            get { return m_IsSelfSeptLand; }
        }

        public SandTableBuilding()
        {
        }

        public void Init(uint landid, GameObject landObj)
        {
            LandId = landid;
            m_landConfig = BuildCityTableManager.GetData((int)LandId);
            m_landObj = landObj;
            if (m_landConfig.HasValue && m_landConfig.Value.type != 3)
            {
                Pickable = true;
                m_landCollider = m_landObj.AddComponent<BoxCollider>();
                Vector3 center = m_landCollider.center;
                center.y = 0.4f;
                m_landCollider.center = center;
                Vector3 size = m_landCollider.size;
                size.y = 1.2f;
                m_landCollider.size = size;
            }
            else
                Pickable = false;
        }

        public void InitData()
        {
            if (BuildCityManager.Instance.BuildingDataMap.ContainsKey(LandId))
            {
                m_data = BuildCityManager.Instance.BuildingDataMap[LandId];
                m_modelConfig = BuildCityModelManager.GetData((int)m_data.ModelId);
            }
        }

        public void RefreshSeptState()
        {
            m_IsSelfSeptLand = false;
            if (BuildCityManager.Instance.LandSeptMap.ContainsKey(LandId) && GameScene.Instance.MainChar != null)
            {
                ulong SeptId = BuildCityManager.Instance.LandSeptMap[LandId];
                if (GameScene.Instance.MainChar.SociatyID == SeptId)
                    m_IsSelfSeptLand = true;
            }
        }

        private GameEvent m_OnAvatarLoaded = new GameEvent();
        public GameEvent OnAvatarLoaded
        {
            get { return m_OnAvatarLoaded; }
        }

        void AvatarCreateDelegate()
        {
            OnAvatarLoaded.Invoke();
            m_avatar.unityObject.transform.SetParent(m_landObj.transform.parent);
            m_avatar.unityObject.transform.localPosition = m_landObj.transform.localPosition;
            m_avatar.unityObject.transform.localEulerAngles = new Vector3(0, m_eulerY, 0);
            m_avatar.unityObject.transform.localScale = new Vector3(m_scale, m_scale, m_scale);
            m_avatar.SetLayer((int)UserLayer.Layer_AvatarShow);
            m_collider = m_avatar.unityObject.GetComponent<MeshCollider>();
        }

        void ScaffoldCreateDelegate()
        {
            m_scaffold.unityObject.transform.SetParent(m_landObj.transform.parent);
            m_scaffold.unityObject.transform.localPosition = m_landObj.transform.localPosition;
            m_scaffold.unityObject.transform.localEulerAngles = new Vector3(0, m_scaffoldEulerY, 0);
            m_scaffold.unityObject.transform.localScale = new Vector3(m_scaffoldScale, m_scaffoldScale, m_scaffoldScale);
            m_scaffold.SetLayer((int)UserLayer.Layer_AvatarShow);
        }

        public void CreateBuilding()
        {
            if (m_data != null)
            {
                if (m_data.State == swm.LandState.Building || m_data.State == swm.LandState.LevelUp)
                {
                    LoadBuildingModel();
                    if (!m_IsScaffoldLoad)
                        LoadScaffold();
                }
                else if (m_data.State == swm.LandState.BuildDone || m_data.State == swm.LandState.LevelUpDone)
                {
                    LoadBuildDoneModel();
                    if (!m_IsScaffoldLoad)
                        LoadScaffold();
                }
                else
                {
                    LoadModel();
                    if (m_IsScaffoldLoad)
                        UnloadScaffold();
                }
            }
        }

        public void LoadModel()
        {
            if (m_modelConfig.HasValue)
            {
                LoadModelPath(m_modelConfig.Value.model);
            }
        }

        public void LoadBuildingModel()
        {
            if (m_modelConfig.HasValue)
            {
                string modelPath = BuildCityManager.Instance.BuildingManager.GetBuildingModelPath(m_data.ModelId, m_data.BuildProgress);
                LoadModelPath(modelPath);
            }
        }

        public void LoadBuildDoneModel()
        {
            if (m_modelConfig.HasValue)
            {
                string modelPath = BuildCityManager.Instance.BuildingManager.GetBuildingModelPath(m_data.ModelId, 100);
                LoadModelPath(modelPath);
            }
        }

        private void LoadModelPath(string _modelPath)
        {
            if (!string.IsNullOrEmpty(_modelPath))
            {
                //m_modelPath = _modelPath;
                string[] config_path = _modelPath.Split(pathBreak, StringSplitOptions.RemoveEmptyEntries);
                if (config_path.Length == 4)
                {
                    m_eulerY = float.Parse(config_path[2]);
                    m_scale = float.Parse(config_path[3]) / 10.0f;
                    if (m_avatar == null)
                    {
                        m_avatar = IFactory.Instance.CreateAvatar(this);
                        m_avatar.onCreate.AddListener(AvatarCreateDelegate);
                        m_avatar.shadowType = AvatarShadowType.Decal;
                    }
                    m_avatar.LoadModel(config_path[0], config_path[1], false);
                    m_avatar.Visible = true;
                }
                else
                    LogHelper.LogWarning("无效的自建城建筑外观配置. path=" + _modelPath);
            }
        }

        public IAvatar Avatar
        {
            get { return m_avatar; }
        }

        private void LoadScaffold()
        {
            if (m_modelConfig.HasValue)
            {
                m_scaffoldPath = m_modelConfig.Value.mid_model;
                if (!string.IsNullOrEmpty(m_scaffoldPath))
                {
                    string[] config_path = m_scaffoldPath.Split(pathBreak, StringSplitOptions.RemoveEmptyEntries);
                    if (config_path.Length == 4)
                    {
                        m_scaffoldEulerY = float.Parse(config_path[2]);
                        m_scaffoldScale = float.Parse(config_path[3]) / 10.0f;
                        if (m_scaffold == null)
                        {
                            m_scaffold = IFactory.Instance.CreateAvatar(this);
                            m_scaffold.onCreate.AddListener(ScaffoldCreateDelegate);
                            m_scaffold.shadowType = AvatarShadowType.Decal;
                        }
                        m_scaffold.LoadModel(config_path[0], config_path[1], false);
                        m_scaffold.Visible = true;
                        m_IsScaffoldLoad = true;
                    }
                }
            }
        }

        public void UnloadModel()
        {
            if (m_avatar != null)
            {
                m_avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_avatar);
                m_avatar = null;
            }
            m_eulerY = 0;
            m_scale = 1;
            //m_modelPath = string.Empty;
        }

        public void UnloadScaffold()
        {
            if (m_scaffold != null)
            {
                m_scaffold.Release();
                IFactory.Instance.ReleaseAvatar(m_scaffold);
                m_scaffold = null;
            }
            m_scaffoldEulerY = 0;
            m_scaffoldScale = 1;
            m_scaffoldPath = string.Empty;
            m_IsScaffoldLoad = false;
        }

        public void Release()
        {
            UnloadModel();
            UnloadScaffold();
            m_OnAvatarLoaded.RemoveAllListeners();
        }

        public bool Pick(Ray ray)
        {
            if (Pickable)
            {
                //如果有建筑collider用建筑collider判断点选，否则用地块collider判断
                if (m_collider != null)
                {
                    RaycastHit hit;
                    if (m_collider.Raycast(ray, out hit, 9999999))
                    {
                        m_pickDistance = hit.distance;
                        return true;
                    }
                }
                else if (m_landCollider != null)
                {
                    RaycastHit hit;
                    if (m_landCollider.Raycast(ray, out hit, 9999999))
                    {
                        m_pickDistance = hit.distance;
                        return true;
                    }
                }
            }
            return false;
        }

        public void OnMouseHoverIn()
        {
            //LogHelper.Log("OnMouseHoverIn:" + m_collider.gameObject.name);
        }

        public void OnMouseHoverOut()
        {
            //LogHelper.Log("OnMouseHoverOut:" + m_collider.gameObject.name);
        }

        public void OnSelect()
        {
            ShowTopArrow(true);
        }

        public void OnUnselect()
        {
            ShowTopArrow(false);
        }

        private Vector3 m_arrowScale = new Vector3(10, 10, 10);
        private Vector3 m_arrowOffset = new Vector3(0, 1.5f, 0);
        public void ShowTopArrow(bool state)
        {
            if (state)
            {
                if (m_arrowObj == null)
                {
                    ResourceHelper.LoadPrefabAsync("art_resource/environment/GameTesting/prefabs/", "ENV_GameTesting_Build002_SM_ZYW", delegate (UnityEngine.Object o)
                    {
                        m_arrowObj = GameObject.Instantiate(o) as GameObject;
                        m_arrowObj.transform.SetParent(m_landObj.transform.parent);
                        m_arrowObj.transform.localScale = m_arrowScale;
                        m_arrowObj.transform.localEulerAngles = Vector3.zero;
                        m_arrowObj.transform.localPosition = m_landObj.transform.localPosition + m_arrowOffset;
                        m_arrowObj.SetLayerRecursively((int)UserLayer.Layer_AvatarShow);
                    });
                }
                else
                    m_arrowObj.SetActive(true);
            }
            else
            {
                if (m_arrowObj != null)
                    m_arrowObj.SetActive(false);
            }
        }

        public void ShowHighlight(bool state)
        {

        }
    }

    public class SandTableCity : AvatarEvent
    {
        private IAvatar m_avatar;
        public Dictionary<uint, SandTableBuilding> m_buildingMap = new Dictionary<uint, SandTableBuilding>(16);
        private BuildCityLocationBase? m_cityConfig;
        private readonly char[] pathBreak = new char[] { ':' };
        public Dictionary<int, SandTableLandscape> m_LandscapeMap = new Dictionary<int, SandTableLandscape>(8);

        public SandTableCity()
        {
        }

        public void Init()
        {
            m_avatar = IFactory.Instance.CreateAvatar(this);
            m_avatar.onCreate.AddListener(AvatarCreateDelegate);
            m_avatar.shadowType = AvatarShadowType.Decal;
        }

        private GameEvent m_OnAvatarLoaded = new GameEvent();
        public GameEvent OnAvatarLoaded
        {
            get { return m_OnAvatarLoaded; }
        }

        void AvatarCreateDelegate()
        {
            OnAvatarLoaded.Invoke();
            InitBuildings();
            BuildCityManager.Instance.onBuildingChange.AddListener(RefreshLandBuilding);
        }

        public void LoadModel(uint cityId)
        {
            m_cityConfig = BuildCityLocationManager.GetData((int)cityId);
            string[] configPath = m_cityConfig.Value.city_model.Split(pathBreak, StringSplitOptions.RemoveEmptyEntries);
            m_avatar.LoadModel(configPath[0], configPath[1], false);
            m_avatar.Visible = true;
        }

        public string CityName
        {
            get
            {
                if (m_cityConfig.HasValue)
                    return m_cityConfig.Value.city_name;
                return string.Empty;
            }
        }

        public IAvatar Avatar
        {
            get { return m_avatar; }
        }

        public void Release()
        {
            if (m_avatar != null)
            {
                m_avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_avatar);
                m_avatar = null;
            }
            m_OnAvatarLoaded.RemoveAllListeners();
            BuildCityManager.Instance.onBuildingChange.RemoveListener(RefreshLandBuilding);
            var e = m_buildingMap.GetEnumerator();
            while (e.MoveNext())
            {
                e.Current.Value.Release();
            }
            m_buildingMap.Clear();
        }

        private void InitBuildings()
        {
            foreach (Transform t in m_avatar.unityObject.transform)
            {
                if (t.name.Contains("Land"))
                {
                    SandTableBuilding building = new SandTableBuilding();
                    string name = t.gameObject.name;
                    int startIndex = name.IndexOf("Land");
                    string subName = name.Substring(startIndex);
                    string[] param = subName.Split('_');
                    uint landId = uint.Parse(param[1]);
                    building.Init(landId, t.gameObject);
                    building.InitData();
                    building.CreateBuilding();
                    m_buildingMap.Add(landId, building);
                }
                else if (t.name.Contains("TmpBox"))
                {
                    SandTableLandscape landscape = new SandTableLandscape();
                    string name = t.gameObject.name;
                    int startIndex = name.IndexOf("TmpBox");
                    string subName = name.Substring(startIndex);
                    string[] param = subName.Split('_');
                    int landscapeIndex = int.Parse(param[1]);
                    landscape.Init(landscapeIndex, t.gameObject);
                    m_LandscapeMap.Add(landscapeIndex, landscape);
                }
            }
        }

        private float m_AxisYRot;
        private float m_AxisYSpeed = 4.8f;
        private Quaternion m_rotation;
        public void UpdateRotate()
        {
            float y = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalAxis);
            m_AxisYRot = m_rotation.eulerAngles.y - y * m_AxisYSpeed;
            m_rotation = Quaternion.Euler(0, m_AxisYRot, 0);
            m_avatar.unityObject.transform.rotation = m_rotation;
        }

        private float m_dragSpeed = 1.0f;
        private Vector3 m_moveTarget = Vector3.zero;
        private const float MinTargetX = -15;
        private const float MaxTargetX = 15;
        private const float MinTargetZ = -30;
        private const float MaxTargetZ = 0;
        public void UpdateMove()
        {
            float tX = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalMoveAxis);
            float tZ = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraVerticalMoveAxis);
            if (tX != 0 || tZ != 0)
            {
                m_moveTarget = m_avatar.unityObject.transform.position;
                m_moveTarget.x = Mathf.Clamp(m_moveTarget.x + tX * m_dragSpeed, MinTargetX, MaxTargetX);
                m_moveTarget.z = Mathf.Clamp(m_moveTarget.z + tZ * m_dragSpeed, MinTargetZ, MaxTargetZ);
                m_avatar.unityObject.transform.position = m_moveTarget;
            }
        }

        public void RefreshLandBuilding(uint landId)
        {
            if (m_buildingMap.ContainsKey(landId))
            {
                var building = m_buildingMap[landId];
                building.UnloadModel();
                building.InitData();
                building.CreateBuilding();
            }
        }

        /// <summary>
        /// 选中地块建筑
        /// </summary>
        /// <param name="selectLandId"></param>
        public void SelectLandBuilding(uint selectLandId)
        {
            var e = m_buildingMap.GetEnumerator();
            while (e.MoveNext())
            {
                if (e.Current.Value.LandId == selectLandId)
                    e.Current.Value.OnSelect();
                else
                    e.Current.Value.OnUnselect();
            }
            var el = m_LandscapeMap.GetEnumerator();
            while (el.MoveNext())
            {
                if (el.Current.Value.LandId == selectLandId)
                    el.Current.Value.OnSelect();
                else
                    el.Current.Value.OnUnselect();
            }
        }

        public void RefreshBuildingArrow()
        {
            var el = m_LandscapeMap.GetEnumerator();
            while (el.MoveNext())
            {
                el.Current.Value.ShowTopArrow(false);
            }
            var eb = m_buildingMap.GetEnumerator();
            while (eb.MoveNext())
            {
                eb.Current.Value.RefreshSeptState();
                if (eb.Current.Value.IsSelfSeptLand)
                    eb.Current.Value.ShowTopArrow(true);
                else
                    eb.Current.Value.ShowTopArrow(false);
            }
        }

        public void RefreshLandscapeArrow()
        {
            var eb = m_buildingMap.GetEnumerator();
            while (eb.MoveNext())
            {
                eb.Current.Value.ShowTopArrow(false);
            }
            var ed = BuildCityManager.Instance.LandscapeDataMap.GetEnumerator();
            while (ed.MoveNext())
            {
                var landscapeIndex = ed.Current.Value.ArrowPoint;
                if (m_LandscapeMap.ContainsKey(landscapeIndex))
                {
                    m_LandscapeMap[landscapeIndex].ShowTopArrow(true);
                    m_LandscapeMap[landscapeIndex].InitData(ed.Current.Value.Id);
                }
                else
                    LogHelper.LogWarningFormat("沙盘不包含对应的箭头索引.landscapeIndex={0}, landId={1}", landscapeIndex, ed.Current.Key);
            }
        }
    }

    public class SandTableBuildingPickComparer : IComparer<ISandTablePickable>
    {
        public int Compare(ISandTablePickable a, ISandTablePickable b)
        {
            return a.PickDistance.CompareTo(b.PickDistance);
        }
    }
}