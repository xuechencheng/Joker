﻿using UnityEngine;
using Bokura;

namespace Bokura
{
    public class SandTableCameraController
    {
        private Camera m_camera;
        private float m_distance;
        private float m_scrollSpeed = 3.0f;
        private const float MinScrollDistance = 0;
        private const float MaxScrollDistance = 20;

        public void Init(Camera _camera)
        {
            m_camera = _camera;
        }

        public void Dispose()
        {
            m_camera = null;
            m_distance = 0;
        }

        
        public void Update()
        {
            if (m_camera == null)
                return;

            UpdateScrollDistance();
        }

        private void UpdateScrollDistance()
        {
            float wheel = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraDistanceAxis);
            if (wheel != 0)
            {
                float lastDistance = m_distance;
                m_distance = Mathf.Clamp(m_distance + wheel * m_scrollSpeed, MinScrollDistance, MaxScrollDistance);
                float delta = m_distance - lastDistance;
                m_camera.transform.Translate(Vector3.forward * delta);
            }
        }

        public float ScrollDistance
        {
            get { return m_distance; }
        }
    }
}