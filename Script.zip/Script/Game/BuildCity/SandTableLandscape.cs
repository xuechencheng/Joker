using UnityEngine;
using System;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public class SandTableLandscape : ISandTablePickable
    {
        private GameObject m_landObj;
        private BoxCollider m_collider;    //建筑collider
        //private BuildCityLandscapeData m_landscapeData;
        private GameObject m_arrowObj;

        #region implement ISandTablePickable
        private float m_pickDistance;
        public float PickDistance
        {
            get { return m_pickDistance; }
        }

        public uint CityId
        {
            get { return 1; }
        }

        private uint land_id;
        public uint LandId
        {
            get { return land_id; }
            set { land_id = value; }
        }

        private bool m_Pickable;
        public bool Pickable
        {
            get { return m_Pickable; }
            set { m_Pickable = value; }
        }

        public uint Type
        {
            get { return 2; }
        }

        public bool Pick(Ray ray)
        {
            if (Pickable && m_collider != null)
            {
                RaycastHit hit;
                if (m_collider.Raycast(ray, out hit, 9999999))
                {
                    m_pickDistance = hit.distance;
                    return true;
                }
            }
            return false;
        }

        public void OnMouseHoverIn()
        {
            //LogHelper.Log("OnMouseHoverIn:" + m_collider.gameObject.name);
        }

        public void OnMouseHoverOut()
        {
            //LogHelper.Log("OnMouseHoverOut:" + m_collider.gameObject.name);
        }

        public void OnSelect()
        {
            //LogHelper.Log("OnSelect:" + m_collider.gameObject.name);
            ShowTopArrow(true);
        }

        public void OnUnselect()
        {
            ShowTopArrow(false);
        }

        private Vector3 m_arrowScale = new Vector3(10, 10, 10);
        private Vector3 m_arrowOffset = new Vector3(0, 3.5f, 0);
        private Vector3 m_arrowTmpOffset = new Vector3(0, 9.5f, 0);
        public void ShowTopArrow(bool state)
        {
            if (state)
            {
                if (m_arrowObj == null)
                {
                    ResourceHelper.LoadPrefabAsync("art_resource/environment/GameTesting/prefabs/", "ENV_GameTesting_Build002_SM_ZYW", delegate (UnityEngine.Object o)
                    {
                        m_arrowObj = GameObject.Instantiate(o) as GameObject;
                        m_arrowObj.transform.SetParent(m_landObj.transform.parent);
                        m_arrowObj.transform.localScale = m_arrowScale;
                        m_arrowObj.transform.localEulerAngles = Vector3.zero;
                        m_arrowObj.transform.localPosition = m_landObj.transform.localPosition + m_arrowOffset;
                        //临时处理箭头偏移
                        if(LandscapeIndex == 1)
                            m_arrowObj.transform.localPosition = m_landObj.transform.localPosition + m_arrowTmpOffset;
                        m_arrowObj.SetLayerRecursively((int)UserLayer.Layer_AvatarShow);
                    });
                }
                else
                    m_arrowObj.SetActive(true);
            }
            else
            {
                if (m_arrowObj != null)
                    m_arrowObj.SetActive(false);
            }
        }
        #endregion

        public SandTableLandscape()
        {
        }

        private int m_landscapeIndex;
        public int LandscapeIndex
        {
            get { return m_landscapeIndex; }
        }

        public void Init(int landscapeIndex, GameObject landObj)
        {
            m_landscapeIndex = landscapeIndex;
            m_landObj = landObj;
            m_collider = m_landObj.GetComponent<BoxCollider>();
        }

        public void InitData(uint landId)
        {
            land_id = landId;
            if (BuildCityManager.Instance.LandscapeDataMap.ContainsKey(LandId))
            {
                //m_landscapeData = BuildCityManager.Instance.LandscapeDataMap[LandId];
                Pickable = true;
            }
        }
    }
}