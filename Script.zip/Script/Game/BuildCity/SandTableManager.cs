using UnityEngine;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public class SandTableManager
    {
        private static SandTableManager m_instance;

        public static SandTableManager Instance
        {
            get
            {
                if (m_instance == null)
                    m_instance = new SandTableManager();
                return m_instance;
            }
        }

        private SandTableCity m_city;
        private Camera m_avatarCamera;
        private Camera m_rayCamera;
        private ISandTablePickable m_hoverBuilding;
        private List<ISandTablePickable> m_tmpList = new List<ISandTablePickable>(5);
        private SandTableBuildingPickComparer m_pickComparer = new SandTableBuildingPickComparer();
        private SandTableCameraController m_camController = new SandTableCameraController();

        public void Init(AvatarShow _avatarShow)
        {
            IVirtualInput tActiveInput = ICrossPlatformInputManager.Instance.GetActiveInput();
            if (tActiveInput != null)
            {
                tActiveInput.AddAxes(InputVirtualAxis.CameraHorizontalMoveAxis);
                tActiveInput.AddAxes(InputVirtualAxis.CameraVerticalMoveAxis);
            }
            m_city = _avatarShow.AvatarEventBase as SandTableCity;
            m_avatarCamera = _avatarShow.AvatarCamera;
            CreateRayCamera(m_avatarCamera);
            m_camController.Init(m_avatarCamera);
        }

        public void Dispose()
        {
            IVirtualInput tActiveInput = ICrossPlatformInputManager.Instance.GetActiveInput();
            if (tActiveInput != null)
            {
                tActiveInput.UnRegisterVirtualAxis(InputVirtualAxis.CameraHorizontalMoveAxis);
                tActiveInput.UnRegisterVirtualAxis(InputVirtualAxis.CameraVerticalMoveAxis);
            }
            m_city = null;
            m_avatarCamera = null;
            m_camController.Dispose();
            DisposRayCamera();
        }

        [XLua.BlackList]
        public void Update()
        {
            m_camController.Update();
            UpdateRayCamera();
            if (m_city != null)
            {
                //不同时支持移动和旋转,镜头拉近到一定距离禁用旋转
                if (m_camController.ScrollDistance > 3)
                    m_city.UpdateMove();
                else
                    m_city.UpdateRotate();
            }
            UpdateMouseHoverBuilding();
        }

        public string CityName
        {
            get
            {
                if (m_city != null)
                    return m_city.CityName;
                return string.Empty;
            }
        }

        public ISandTablePickable MouseOverBuilding
        {
            get { return m_hoverBuilding; }
        }

        private void UpdateMouseHoverBuilding()
        {
            var lastHoverBuilding = m_hoverBuilding;
            m_hoverBuilding = GetNearestBuilding(IUnityInput.Instance.mousePosition);
            if (lastHoverBuilding != m_hoverBuilding)
            {
                if (lastHoverBuilding != null)
                    lastHoverBuilding.OnMouseHoverOut();
                if (m_hoverBuilding != null)
                    m_hoverBuilding.OnMouseHoverIn();
            }
        }

        private ISandTablePickable GetNearestBuilding(Vector3 pos)
        {
            m_tmpList.Clear();
            if (m_rayCamera != null && m_city != null)
            {
                Ray ray = m_rayCamera.ScreenPointToRay(pos);
                //IRenderUtilities.Instance.DrawSingleLine(ray.origin, ray.origin + ray.direction * 1000.0f, Color.red);
                var e = m_city.m_buildingMap.GetEnumerator();
                while (e.MoveNext())
                {
                    if (e.Current.Value.Pick(ray))
                        m_tmpList.Add(e.Current.Value);
                }

                var e2 = m_city.m_LandscapeMap.GetEnumerator();
                while (e2.MoveNext())
                {
                    if (e2.Current.Value.Pick(ray))
                        m_tmpList.Add(e2.Current.Value);
                }

                if (m_tmpList.Count > 1)
                    m_tmpList.Sort(m_pickComparer);

                if (m_tmpList.Count > 0)
                    return m_tmpList[0];
            }
            return null;
        }

        #region Create SandTable Camera
        private bool m_camBlockInput;
        private bool m_camUpdate;
        private void CreateRayCamera(Camera _avatarCamera)
        {
            GameObject camObj = new GameObject("SandTableCamera", typeof(Camera));
            camObj.transform.position = _avatarCamera.transform.position;
            camObj.transform.localEulerAngles = _avatarCamera.transform.localEulerAngles;
            m_rayCamera = camObj.GetComponent<Camera>();
            m_rayCamera.useOcclusionCulling = false;
            m_rayCamera.allowMSAA = false;
            m_rayCamera.allowHDR = true;
            m_rayCamera.depth = 2;
            m_rayCamera.nearClipPlane = _avatarCamera.nearClipPlane;
            m_rayCamera.farClipPlane = _avatarCamera.farClipPlane;
            m_rayCamera.clearFlags = _avatarCamera.clearFlags;
            m_rayCamera.cullingMask = 0;
            m_rayCamera.backgroundColor = _avatarCamera.backgroundColor;
            m_camBlockInput = CameraController.Instance.BlockInput;
            m_camUpdate = CameraController.Instance.IsUpdate;
            CameraController.Instance.BlockInput = true;
            CameraController.Instance.IsUpdate = false;
        }

        private void DisposRayCamera()
        {
            GameObject.Destroy(m_rayCamera.gameObject);
            CameraController.Instance.BlockInput = m_camBlockInput;
            CameraController.Instance.IsUpdate = m_camUpdate;
        }

        private void UpdateRayCamera()
        {
            if (m_avatarCamera != null && m_rayCamera != null)
            {
                m_rayCamera.transform.position = m_avatarCamera.transform.position;
                //m_rayCamera.transform.localEulerAngles = m_avatarCamera.transform.localEulerAngles;
            }
        }
        #endregion

        /// <summary>
        /// 通知选中地块建筑
        /// </summary>
        public GameEvent<uint, uint, uint> onSelectCityBuilding = new GameEvent<uint, uint, uint>();
        public void SelectCityBuilding()
        {
            if (MouseOverBuilding != null)
            {
                m_city.SelectLandBuilding(MouseOverBuilding.LandId);
                onSelectCityBuilding.Invoke(MouseOverBuilding.CityId, MouseOverBuilding.LandId, MouseOverBuilding.Type);
            }
        }

        public void RefreshBuildingArrow()
        {
            if (m_city != null)
                m_city.RefreshBuildingArrow();
        }

        public void RefreshLandscapeArrow()
        {
            if (m_city != null)
                m_city.RefreshLandscapeArrow();
        }
    }
}