using UnityEngine;
using System.Collections;
using Bokura;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering;

namespace Bokura
{
    public class CameraController : ICameraController
    {
        protected static CameraController m_instance = null;
        public static CameraController Instance { get { if (m_instance == null) m_instance = new CameraController(ICameraHelper.Instance); return m_instance; } }
        public CameraController(ICameraHelper helper) : base(CameraControlMode.ThreeCamera, helper) { }

        #region param
        private UnityEngine.Camera m_camera { get { return ICameraHelper.MainCamera; } }
        //观察目标
        private Transform m_Target;

        //旋转速度
        private float m_speedX = 240;
        private float m_speedY = 120;

        //旋转角度
        private float m_x = 0.0F;
        private float m_y = 45.0F;

        [XLua.BlackList]
        public float GetRoteY()
        {
            return m_y;
        }

        [XLua.BlackList]
        public float GetRoteX()
        {
            return m_x;
        }
        //旋转在最大最小角度
        private float Min_Angle_y = -60;
        private float Max_Angle_y = 89;

        //观察距离
        private float m_lastRealDistance = 5F; //上一帧相机离目标点的实际距离
        private float m_realDistance = 5F; //相机离目标点的实际距离
        private float m_curDistance = 5F;    //鼠标滚轮的当前距离
        private float m_TargetDistance = 5F;
        public float TargetDistance { get { return m_TargetDistance; } set { m_TargetDistance = value; } }

        private float m_curMinDistance; //更加包围盒计算的最小距离
        public float CurMinDistance { get { return m_curMinDistance; } set { m_curMinDistance = value; } }
        private float m_slideDetla { get { return CameraConfig ? CameraConfig.MouseSlideDelta : 0.4f; } }


        private float m_oldTargetDistance;

        //滚轮改变距离时回调事件
        public GameEvent<float> onChangeDisByAxisEvent = new GameEvent<float>();

        private bool m_busemaxdis = false;
        private bool m_busemindis = false;
        private float m_usemaxdis = 0f;
        private float m_usemindis = 0f;

        //鼠标缩放距离最值
        private float m_maxDistance
        {
            get
            {
                if(m_busemaxdis==true)
                {
                    return m_usemaxdis;
                }
                else
                {
                    return CameraConfig ? CameraConfig.MaxDistance : 12.0f;
                }
                
            }
        }
        private float m_minDistance
        {
            get
            {
                if (m_busemindis == true)
                {
                    return m_usemindis;
                }
                else
                {
                    return CameraConfig ? CameraConfig.MinDistance : 0.5f;  //配置的最小距离
                }
            }
        } 
        private float m_boundOffset { get { return CameraConfig ? CameraConfig.BoundOffset : 0.2f; } }

        //鼠标缩放速率
        private float m_zoomSpeed  { get { return CameraConfig ? CameraConfig.MouseZoomSpeed : 2f; } }

        //远处观察高度偏移  读配置
        private Vector3 LookAtPosOffset { get { return new Vector3(0, (CharacterConfig != null ? CharacterConfig.LookTargetOffsetCurve.Evaluate(m_curDistance) : 1.5f),0);  } }

        //近处观察高度偏移  外部需要临时添加
        private Vector3 m_lookAtTempOffset = Vector3.zero;
        public Vector3 LookAtTempOffset { get { return m_lookAtTempOffset; } set { m_lookAtTempOffset = value; } }

        //FOV随距离变化曲线
        private AnimationCurve m_fovCurve;

        //镜头特效绑点
        private GameObject m_cameraEffectRoot;
        [XLua.BlackList]
        public GameObject CameraEffectRoot
        {
            get
            {
                if (m_cameraEffectRoot == null)
                {
                    m_cameraEffectRoot = new GameObject("camera_effect_root");
                    m_cameraEffectRoot.transform.SetParent(m_camera.transform, false);
                    m_cameraEffectRoot.transform.localEulerAngles = Vector3.zero;
                }
                return m_cameraEffectRoot;
            }
        }

        //动画旋转
        private Vector2 m_animRotateTarget;
        private float m_animRotateSpeed = 2.0f;
        private bool m_isRotating = false;
        private bool m_isChangeDistance = false;
        private float m_animDitanceSpeedRate = 2.0f;

        //投射检查layer
        private int m_detectLayer = (int)UserLayerMask.CameraBlock;

        private Quaternion m_LastCamRotation;
        private Quaternion m_camRotation
        {
            get
            {
                if (null != m_camera)
                    return m_camera.transform.rotation;
                return Quaternion.identity;
            }
        }

        /// <summary>
        /// Camera rotate sensitivity
        /// </summary>
        private int m_fCameraSensitivity = 62;
        public int CameraSensitivity { get { return m_fCameraSensitivity; }
            set {
                m_fCameraSensitivity = Mathf.Clamp(value, 25, 100);
            } }

        /// <summary>
        /// 当前摄像机位置
        /// </summary>
        private Vector3 m_curCamPos;

        /// <summary>
        /// 当前摄像机转向
        /// </summary>
        private Quaternion m_curCamQuat;

        /// <summary>
        /// 摄像机是否在播放tween动画
        /// </summary>
        private bool m_isCamTween = false;

        private Vector3 m_tweenDestPos;

        private Quaternion m_tweenDestRot;

        private Vector3 m_tweenSrcPos;

        private Quaternion m_tweenSrcRot;

        private float m_tweenRotStep;


        private float m_tweenRotStepSpeed;
        public float tweenRotStepSpeed
        {
            set { m_tweenRotStepSpeed = value; }
        }


        private GameEvent m_onRotStepEvent = new GameEvent();
        public GameEvent onRotStepEvent
        {
            get { return m_onRotStepEvent; }
        }

        private GameEvent m_onTweenEndEvent = new GameEvent();
        public GameEvent onTweenEndEvent
        {
            get { return m_onTweenEndEvent; }
        }

        #endregion


        #region property

        private bool m_bIsUpdate = true;
        private bool m_bIsUpdateBySkill = true;
        private bool m_bLockRotation = false;
        private bool m_dontSyncCharOrient = false;
        private bool m_bBlockInput = false;
        private bool m_bBlockMove = false;
        private bool m_bIsLookup = false; //仰视条件
        private bool m_bLockTarget = false;  



        private GameEvent m_OnCameraRotated = new GameEvent();
        /// <summary>
        /// 摄像机旋转就触发，不论主动或其他原因
        /// </summary>
        public GameEvent OnCameraRotated { get { return m_OnCameraRotated; } }

        public GameEvent OnPlayerActiveRotate = new GameEvent(); //当玩家主动旋转map
        //public GameEvent OnScreenSnapshootEvent = new GameEvent();

        public GameEvent<float> OnMainCameraDitanceChanged = new GameEvent<float>();


        private GameEvent m_onUpdateEvent = new GameEvent();
        public GameEvent onUpdateEvent
        {
            get { return m_onUpdateEvent; }
        }

        public bool IsLookup
        {
            set { m_bIsLookup = value; }
            get { return m_bIsLookup; }
        }
        public bool dontSyncCharOrient
        {
            set { m_dontSyncCharOrient = value; }
            get { return m_dontSyncCharOrient; }
        }
        public bool IsUpdate
        {
            get { return m_bIsUpdate&&m_bIsUpdateBySkill; }
            set { m_bIsUpdate = value; }
        }
        public bool IsUpdateBySkill
        {
            get
            {
                return m_bIsUpdateBySkill;
            }

            set
            {
                m_bIsUpdateBySkill = value;
            }
        }



        /// <summary>
        /// 锁定视角
        /// </summary>
        public bool LockRotation
        {
            get { return m_bLockRotation; }
            set { m_bLockRotation = value; }
        }

        /// <summary>
        /// 锁定目标，取消阻尼效果。
        /// </summary>
        public bool LockTarget
        {
            get { return m_bLockTarget; }
            set { m_bLockTarget = value; }
        }

        /// <summary>
        /// 禁止外部输入
        /// </summary>
        public bool BlockInput
        {
            get { return m_bBlockInput; }
            set { m_bBlockInput = value; }
        }

        /// <summary>
        /// 禁止改变摄像机位置
        /// </summary>
        public bool BlockMove
        {
            get { return m_bBlockMove; }
            set { m_bBlockMove = value; }
        }



        /// <summary>
        /// 获取观察目标的Transform
        /// </summary>
        public Transform GetTargetTransform()
        {
            return m_Target;
        }

        public float RotateX { get { return m_x; } set { m_x = value; } }
        public float RotateY { get { return m_y; } set { m_y = value; } }
        public float CurDistance { get { return m_curDistance; } set { m_curDistance = value; } }
        public Vector3 Direction
        {
            get
            {
                if (null == m_camera)
                    return Vector3.zero;
                return m_camera.transform.forward;
            }
            set {
                if (null == m_camera)
                    return;

                m_camera.transform.forward = value;
            }
        }
        public float angleY
        {
            get
            {
                var tDir = Direction;
                return Utilities.Vector2Angle(tDir.z, tDir.x);
            }
        }

        public float FollowSmoothTime { get { return m_smoothTime; }set { m_smoothTime = value; } }

        public bool isAnimRotating { get { return m_isRotating; } }

        public SysSettingSharedData Config
        {
            get { return Game.SysSettingModel.Instance.sharedData; }
        }

        public bool isSphereCastSamething = false;
        #endregion


        public float ClampAngle(float angle, float min, float max)
        {
            while (angle < -360) angle += 360;

            while (angle > 360) angle -= 360;

            return Mathf.Clamp(angle, min, max);
        }

        public override void Enter(ICameraController prev)
        {
            base.Enter(prev);
            if(!(prev is SimpleCameraController))
            {
                IsEnterAnimation = true;
                m_EnterAnimationTime = 0;
            }
            if (m_Target != null)
                m_TartgetFollowPos = m_Target.position;

            m_isCamTween = false;
        }

        public override void Leave(ICameraController prev)
        {
            base.Leave(prev);
        }


        #region Interface
        public override void Init()
        {
            if (m_Target)
            {
                m_TartgetFollowPos = m_Target.position;
            }
            if (m_camera != null)
            {
                m_camera.transform.position = m_cameraPosition;
                m_camera.transform.LookAt(GetTargetPosition());
            }

            m_LastCamRotation = m_camRotation;

            //m_detectLayer = (int)UserLayerMask.AllBlock;

            //Bokura.LevelSystemManager.Instance.SetDefaultLevelSystem();
        }
        public override void DeInit()
        {
           
        }
        public override void ResetConfig()
        {
            m_smoothTime = 0.03f;
        }

        #region Target
        //public bool m_isBindSpine = false;
        public void SetTarget(Transform _target)
        {
            m_Target = _target;
            SetTargetDetlaPos(m_Target.position);
            CritiasFoliage.FoliageManager.Instance.Target = _target;
            m_curMinDistance = CalcCurrentMinDistance();
            //m_isBindSpine = isBindSpine;
        }



        /// <summary>
        /// 设置摄像机目标的跟随位置
        /// </summary>
        public void SetTargetDetlaPos(Vector3 _pos)
        {
            m_TartgetFollowPos = _pos;
        }



        public void SetLookAtDetlaOffset(Vector3 _offset)
        {
            m_lookAtTempOffset = _offset;
        }

        #endregion

        #region Control
        public void Reset(float xAngle = 0, bool isAttack = false)
        {
            xAngle = xAngle != 0 ? xAngle : m_x;
            float speed = 2;
            if (isAttack)
            {
                AnimRotateTo(xAngle, 45, speed);
                ChangeDistanceTo(10);
                return;
            }
            switch (Config.iCameraMode)
            {
                case CameraMode.Mode3D:
                case CameraMode.Ordinary3D:
                    AnimRotateTo(xAngle, 37, speed, true);
                    ChangeDistanceTo(5);
                    break;
                case CameraMode.Mode2_5D:
                case CameraMode.ModeCustom:
                    AnimRotateTo(xAngle, 45, speed, true);
                    ChangeDistanceTo(10);
                    break;
                default:
                    break;
            }


        }

        public void ResetDistance()
        {
            switch (Config.iCameraMode)
            {
                case CameraMode.Mode3D:
                case CameraMode.Ordinary3D:
                    ChangeDistanceTo(5);
                    break;
                case CameraMode.Mode2_5D:
                case CameraMode.ModeCustom:
                    ChangeDistanceTo(10);
                    break;
                default:
                    break;
            }


        }

        public void StopAnimRotate()
        {
            m_isRotating = false;
        }

        public void AnimRotateTo(float rtx, float rty, float speed = 10.0f, bool force = false)
        {
            if (m_isRotating && !force)
                return;

            //LogHelper.LogFormat(LogCategory.GameLogic, "Src:{0} {1}  Desc:{2} {3} ", m_x, m_y, rtx, rty);
             m_x = Utilities.NormalizeAngle(m_x);
             rtx = Utilities.NormalizeAngle(rtx);
             rty = Utilities.NormalizeAngle(rty,180);
             rty = Mathf.Clamp(rty, Min_Angle_y, Max_Angle_y);
             if (rtx - m_x > 180)
                 rtx -= 360.0f;
             if (m_x - rtx > 180)
                 rtx += 360.0f;

            m_animRotateTarget.x = rtx;
            m_animRotateTarget.y = rty;
            m_animRotateSpeed = speed;
            m_isRotating = true;
        }



        /// <summary>
        /// 旋转摄像机
        /// </summary>
        public void RotateTo(float rotateX, float rotateY)
        {
            m_x = rotateX;
            m_y = rotateY;
        }

        public void RotateTo(Vector3 direction) {
            Quaternion rotation = Quaternion.LookRotation(direction);
            Vector3 euler = rotation.eulerAngles;
            RotateTo(euler.x, euler.y);
        }



        public void ChangeRotate(float xAxis, float yAxis)
        {
            m_x += xAxis * m_speedX * 0.02F;
            m_y -= yAxis * m_speedY * 0.02F;
            m_y = Utilities.NormalizeAngle(m_y, 180);
            m_y = Mathf.Clamp(m_y, Min_Angle_y, Max_Angle_y);
        }
        public void AnimChangeDistanceTo(float targetDis,float speed = 3.0f, bool _bIsChangeCurrentDis = false, bool _bIsIgnoreMinMax = false)
        {
            m_isChangeDistance = true;
            m_animDitanceSpeedRate = speed;
            ChangeDistanceTo(targetDis, _bIsChangeCurrentDis, _bIsIgnoreMinMax);
        }
        public void ChangeDistanceTo(float targetDis, bool _bIsChangeCurrentDis = false, bool _bIsIgnoreMinMax = false)
        {
           // LogHelper.LogError("targetDis:", targetDis.ToString());
            if (m_TargetDistance != targetDis)
            {
                m_TargetDistance = targetDis;
                if(!_bIsIgnoreMinMax)
                {
                    m_TargetDistance = Mathf.Clamp(m_TargetDistance, m_curMinDistance, m_maxDistance);
                }
                
                if (_bIsChangeCurrentDis)
                {
                    m_curDistance = m_TargetDistance;
                }
              //  LogHelper.LogError("ChangeDistanceTo:", m_TargetDistance.ToString());
            }
        }

        /// <summary>
        /// 更新相机缩放距离
        /// </summary>
        /// <param name="disAxis"></param>
        public void ChangeDistance(float disAxis)
        {
            m_oldTargetDistance = m_TargetDistance;
            if (disAxis != 0)
            {
#if UNITY_EDITOR || UNITY_STANDALONE
                m_TargetDistance -= disAxis * m_zoomSpeed;      //m_zoomSpeed = 2
#else
		    m_TargetDistance -= disAxis * m_zoomSpeed;   //m_zoomSpeed = 0.5
#endif
            }
            m_TargetDistance = Mathf.Clamp(m_TargetDistance, m_curMinDistance, m_maxDistance);
            if (m_oldTargetDistance != m_TargetDistance)
            {
                onChangeDisByAxisEvent.Invoke(m_TargetDistance);
            }
           
        }
        public float GetTargetDistance()
        {
            return m_TargetDistance;
        }
       

        
        public void SetUseMaxDistance(bool isuse,float setmaxdis)
        {
            m_busemaxdis = isuse;
            m_usemaxdis = setmaxdis;
        }
        public void SetUseMinDistance(bool isuse, float setmindis)
        {
            m_busemindis = isuse;
            m_usemindis = setmindis;
        }


        #endregion

        #region Camera

        public void SetCameraPosition(float _x, float _y, float _z)
        {
            SetCameraPosition(new Vector3(_x, _y, _z));
        }

        public void SetCameraPosition(Vector3 _pos)
        {
            if (m_camera != null && !m_bBlockMove)
                m_camera.transform.position = _pos;

            m_cameraPosition = _pos;
        }

        Vector3 m_cameraPosition;
        public Vector3 GetCameraPosition()
        {
            if (m_camera)
                return m_camera.transform.position;
            return m_cameraPosition;
        }

        public Vector3 GetCameraLocalEulerAngles()
        {
            if (m_camera != null)
            {
                return m_camera.transform.localEulerAngles;
            }

            return Vector3.zero;
        }

        public override bool WorldMove(Vector3 _, Vector3 delta)
        {
            if (m_camera != null)
            {
                //m_worldOffset = delta;
                //if(!m_bBlockMove) // NEVER block here, as it can make game loading mis-function
				// and to keep camera BlockMove (relatively to the scene), you need to allow position change here
                    m_camera.transform.position += delta;
                m_TartgetFollowPos += delta;
                return true;
            }
            return false;
        }


        #endregion

        #endregion

        #region Update
        private float m_radius = 0.25f;
        public float Radius
        {
            get
            {
                return m_radius;
            }
            set
            {
                m_radius = value;
            }
        }
        private Vector3 GetTargetPosition()
        {
            //var per = 1 - (m_realDistance - m_curMinDistance) / (m_maxDistance - m_curMinDistance);
            //var dir = m_lookAtTempOffset + new Vector3(0, m_lookAtPosOffset + (m_lookAtHeadOffset - m_lookAtPosOffset),0) * per;
            //return m_TartgetFollowPos + dir;
            return m_TartgetFollowPos + m_lookAtTempOffset + LookAtPosOffset;
        }

        private float m_fLastMinDis = 0;

        /// <summary>
        /// Some mecanim will change character model's position, but not change entity's position,
        /// this will leads to a problem that when zoom to the closest position, model's not in sight.
        /// Use this method to change camera's mini spring arm length to avoid it
        /// </summary>
        /// <param name="tDis"> Distance to set </param>
        /// <param name="tIsReset"> If reset, make the old offset to be the target offset </param>
        [XLua.BlackList]
        public void SetMinDisAndRevert(float tDis, bool tIsReset = false)
        {
            if (!tIsReset)
            {
                m_fLastMinDis = m_curMinDistance;
                m_curMinDistance = tDis;
            }
            else
            {
                m_curMinDistance = m_fLastMinDis;
                m_fLastMinDis = m_curMinDistance;
            }
        }

        private float m_fLockCamRotateDeg = 25.0f;
        /// <summary>
        /// Update camera locked to selected target
        /// </summary>
        void UpdateLockCamera()
        {
            if (GameScene.Instance.MainChar != null && TargetSelector.Instance != null)
                if (TargetSelector.Instance.Selected != null && TargetSelector.Instance.Selected.Avatar != null && TargetSelector.Instance.Selected.Avatar.getBoundBox() != null)
                    if (TargetSelector.Instance.Selected.CanAttack || TargetSelector.Instance.Selected is Character)
                    {
                        Vector3 dir = TargetSelector.Instance.Selected.GlobalPosition - GameScene.Instance.MainChar.GlobalPosition;
                        float iTargetHeight = TargetSelector.Instance.Selected.Avatar.getBoundBox().bounds.size.y;
                        //**************************
                        // Set spring arm length
                        //**************************
                        m_TargetDistance = iTargetHeight / Mathf.Sin(Mathf.Deg2Rad * m_fLockCamRotateDeg);

                        //**************************
                        // Set camera rotation
                        //**************************
                        Vector3 ldir;
                        float x, y, dx, dy;
                        TargetDirAngleDiff(TargetSelector.Instance.Selected, out x, out y, out dx, out dy, out ldir);
                        if (dir.magnitude > 1)
                            CameraController.Instance.AnimRotateTo(x, y, 2, true);
                    }
        }

        /// <summary>
        /// 获取相机相关鼠标输入，计算相机旋转&缩放
        /// </summary>
        protected void UpdateInput()
        {
            if (!m_bBlockInput)
            {

                //鼠标右键旋转
                float x = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalAxis) * ((float)m_fCameraSensitivity) / 50;
                float y = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraVerticalAxis) * ((float)m_fCameraSensitivity) / 50;

                //获取鼠标输入
                x = TargetSelector.Instance.IsLocking && TargetSelector.Instance.Selected != null && (TargetSelector.Instance.Selected.CanAttack || TargetSelector.Instance.Selected is Character) ? 0 : (Config.bCameraControlHorizontal ? x : 0);
                y = TargetSelector.Instance.IsLocking && TargetSelector.Instance.Selected != null && (TargetSelector.Instance.Selected.CanAttack || TargetSelector.Instance.Selected is Character) ? 0 : (Config.bCameraControlVertical ? y : 0);
                if (x != 0 || y != 0)
                {
                    m_isRotating = false;
                    m_isChangeDistance = false;
                }

                ChangeRotate(x, y);

                //鼠标滚轮缩放ww
                float wheel = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraDistanceAxis);
                wheel = Config.bCameraControlDistance ? wheel : 0;
                ChangeDistance(wheel);

                //主角旋转
                if ((x != 0.0f && y != 0.0f) || wheel != 0.0f)
                    OnPlayerActiveRotate.Invoke();
            }

            float detla = m_TargetDistance - m_curDistance;
            if (m_isChangeDistance)
            {
                m_curDistance += m_slideDetla * detla * m_animDitanceSpeedRate;
                if (Mathf.Abs(detla) < 0.001f)
                {
                    m_curDistance = m_TargetDistance;
                    m_isChangeDistance = false;
                }
            } 
            else
            {
                if (Mathf.Abs(detla) >= 0.005f)
                {
                    m_curDistance += m_slideDetla * detla;
                }
                else
                {
                    m_curDistance = m_TargetDistance;
                }
            }

            //转向
            if (m_isRotating)
            {
                float detlaY = m_animRotateTarget.y - m_y;
                float detlaX = m_animRotateTarget.x - m_x;

                if (TargetSelector.Instance.IsLocking && TargetSelector.Instance.Selected != null && (TargetSelector.Instance.Selected.CanAttack || TargetSelector.Instance.Selected is Character))
                {
                    float iMaxDeltaX = GetMaxHorizontalDeltaAngle();
                    if (Mathf.Abs(detlaX) > Mathf.Abs(iMaxDeltaX)) detlaX = iMaxDeltaX * (detlaX > 0 ? 1 : -1);
                }

                bool bx = false, by = false;
                if (Mathf.Abs(detlaX) > 0.1f)
                {
                    float tox = detlaX * m_animRotateSpeed * Time.deltaTime * 3;// * factorX;
                    if (Mathf.Abs(tox) > Mathf.Abs(detlaX)) tox = detlaX;// Prevent spring shake lead to frame drop
                    m_x += tox;
                }
                else
                {
                    m_x = m_animRotateTarget.x;
                    bx = true;
                }
                
                if (Mathf.Abs(detlaY) > 0.1f)
                {
                    float toy = detlaY * m_animRotateSpeed * Time.deltaTime * 3;// * factory;
                    if (Mathf.Abs(toy) > Mathf.Abs(detlaY)) toy = detlaY;// Prevent spring shake lead to frame drop
                    m_y += toy;
                }
                else
                {
                    m_y = m_animRotateTarget.y;
                    by = true;
                }

                if (bx && by)
                {
                    m_isRotating = false;
                }
            }

            if (!IsLookup && m_y < 0 && !TargetSelector.Instance.IsLocking)
            {
                m_curDistance = Mathf.Lerp(m_curDistance, m_curMinDistance, m_y / Min_Angle_y);
            }

        }

        protected bool IsEnterAnimation = false;
        protected float m_EnterAnimationTime = 0;
        protected float m_EnterAnimationAllTime = 1;
        protected void UpdateEnterAnimation()
        {
            IsEnterAnimation = false;
            Quaternion mRotation = Quaternion.Euler(m_y, m_x, 0);
            Vector3 mPosition = mRotation * new Vector3(0.0F, 0.0F, -m_realDistance);
            var target_pos = mPosition + GetTargetPosition();

            if(!m_bBlockMove)
            {
                ICameraHelper.MainCamera.transform.position = target_pos;
                ICameraHelper.MainCamera.transform.rotation = mRotation;
                ICameraHelper.MainCamera.transform.Rotate(Vector3.right, -m_fCamRotateOffset);
            }

            //             if (m_EnterAnimationTime > m_EnterAnimationAllTime) IsEnterAnimation = false;
            //             if (m_Target != null)  m_TartgetFollowPos = m_Target.position;
            //             m_EnterAnimationTime += Time.deltaTime;
            // 
            //             Quaternion mRotation = Quaternion.Euler(m_y, m_x, 0);
            //             Vector3 mPosition = mRotation * new Vector3(0.0F, 0.0F, -m_realDistance);
            //             var target_pos = mPosition + GetTargetPosition();
            // 
            //             var pos = Vector3.Lerp(ICameraHelper.MainCamera.transform.position, target_pos, m_EnterAnimationTime / m_EnterAnimationAllTime);
            //             var rot = Quaternion.Lerp(ICameraHelper.MainCamera.transform.rotation, mRotation, m_EnterAnimationTime / m_EnterAnimationAllTime);
            // 
            //             ICameraHelper.MainCamera.transform.position = pos;
            //             ICameraHelper.MainCamera.transform.rotation = rot;
        }

        private float m_fCamLerpMoveProgress = 0;
        private bool m_bIsCamLerpMove = false;
        private float m_fCamRotateOffset = 5.0f;

        public override void Update()
        {
            if (m_camera == null || !IsUpdate)
                return;

            if (UpdateCamTween())
                return;

            if (UpdateCameraAnimation())
                return;
             
            if(IsEnterAnimation)
            {
                UpdateFOV();
                UpdateEnterAnimation();
                return;
            }

            if (TargetSelector.Instance.IsLocking)
                UpdateLockCamera();

            UpdateTarget();

            UpdateInput();

            UpdateFOV();

            //重新计算位置和角度
            Quaternion mRotation = Quaternion.Euler(m_y, m_x, 0);
            Quaternion iRotation = m_camera.transform.rotation;
            if (m_Target )
            {
                Vector3 mPosition = mRotation * new Vector3(0.0F, 0.0F, -m_curDistance);
                Vector3 mViewPosition = mRotation * new Vector3(0.0F, 0.0F, -m_curDistance + m_camera.nearClipPlane);

                Vector3 pTarget = GetTargetPosition();
                mPosition += pTarget;
                mViewPosition += pTarget;
                //Vector3 vCamera = mPosition - m_camera.transform.position;
                Vector3 camViewPosition = (m_camera.transform.position - pTarget).normalized * ((m_camera.transform.position - pTarget).magnitude - m_camera.nearClipPlane) + pTarget;
                Vector3 vCamera = mViewPosition - camViewPosition;

                //From current camera near clip plane to next camera near clip plane, cast sphere sweep to detect collision
                //mViewPosition : current camera's near clip plane position
                //camViewPosition : next camera's near clip plane position
                RaycastHit goofhit;
                //if (Physics.SphereCast(new Ray(m_camera.transform.position, vCamera.normalized), m_radius * 0.8f, out goofhit, vCamera.magnitude, m_detectLayer))
                if (Utilities.SphereCast(camViewPosition,  m_radius * 0.9f,vCamera.normalized, out goofhit, vCamera.magnitude, m_detectLayer))
                {
                    RaycastHit rayhit;

                    Vector3 rayOri = pTarget - m_lookAtTempOffset;//视角被偏移的时候需要调整射线初始位置，防止射不到地表
                    Vector3 vEye = mPosition - rayOri;
                    if (Utilities.SphereCast(rayOri, m_radius,vEye.normalized, out rayhit, vEye.magnitude, m_detectLayer))
                    {
                        m_realDistance = rayhit.distance;
                        if (m_realDistance < m_maxDistance && m_realDistance > m_curMinDistance)
                        {
                            //校正
                            Vector3 changedpos = rayhit.point + rayhit.normal * m_radius;
                            mRotation = Quaternion.LookRotation(pTarget - changedpos);
                            m_realDistance = Vector3.Distance(changedpos, pTarget);
                        }
                        //dis = Mathf.Min(dis, m_curDistance);
                        //dis = Mathf.Clamp(dis, m_minDistance, m_maxDistance);
                        mPosition = mRotation * new Vector3(0.0F, 0.0F, -m_realDistance) + pTarget;
                    }
                    else
                    {
                        m_realDistance = m_curDistance;
                        //mPosition = m_camera.transform.position;
                        //mRotation = m_camera.transform.rotation;
                    }

                    isSphereCastSamething = true;
                }
                else
                {
                    m_realDistance = m_curDistance;

                    isSphereCastSamething = false;
                }

                //***********************************************
                // Camera position reset after play animation
                //***********************************************
                if (m_bIsCamLerpMove)
                {
                    m_fCamLerpMoveProgress = 0;
                    m_bIsCamLerpMove = false;
                }
                m_fCamLerpMoveProgress += Time.deltaTime;
                m_fCamLerpMoveProgress  = m_fCamLerpMoveProgress > 1 ? 1 : m_fCamLerpMoveProgress;

                var iLerpPos = m_camera.transform.position;

                iLerpPos    = Vector3.Lerp(iLerpPos, mPosition, m_fCamLerpMoveProgress);
                iRotation   = Quaternion.Slerp(iRotation, mRotation, m_fCamLerpMoveProgress);

                //**********************
                // Set camera position
                //**********************
                SetCameraPosition(iLerpPos);
            }

            //*******************************************
            // Set camera rotation, additionally
            // add a degree offset, so that character's
            // position is in the lower screen
            //*******************************************
            m_camera.transform.rotation = iRotation;
            m_camera.transform.Rotate(Vector3.right, -m_fCamRotateOffset);


            m_curCamPos = m_camera.transform.position;
            m_curCamQuat = m_camera.transform.rotation;

            m_onUpdateEvent.Invoke();
        }

        public override void LateUpdate()
        {
            if (m_LastCamRotation != m_camRotation)
                OnCameraRotated.Invoke();
            m_LastCamRotation = m_camRotation;

            if(m_lastRealDistance != m_realDistance )
            {
                m_lastRealDistance = m_realDistance;
                OnMainCameraDitanceChanged.Invoke(m_realDistance);
            }
        }
        private void UpdateFOV()
        {
            if (m_camera && m_fovCurve != null && pauseUpdateFOV == false)
            {
                float fov = m_fovCurve.Evaluate(m_realDistance);
                SetFov(fov);
                UpdateCameraEffectRoot(fov);
            }
        }
        //FOV变更时更新镜头特效绑点位置
        private void UpdateCameraEffectRoot(float fov)
        {
            float dis = 0.4f / Mathf.Tan(fov * 0.5f * Mathf.PI / 180);
            m_camera.nearClipPlane = Mathf.Min(0.5f, dis);
            CameraEffectRoot.transform.localPosition = new Vector3(0, 0, dis);
        }
        protected bool pauseUpdateFOV = false;
        public void SetCameraFov(bool isstart, float fov)
        {
            pauseUpdateFOV = isstart;
            if (isstart)
            {
                SetFov(fov);
            }
            else
            {
                SetFov(m_fovCurve.Evaluate(m_realDistance));
            }
            UpdateCameraEffectRoot(fov);
        }

        private float m_curCameraContrillerFov = 40.0f;
        private void SetFov( float _fov)
        {
            m_curCameraContrillerFov = _fov;
            ICameraHelper.SetFOV(m_curCameraContrillerFov);
        }



        /// <summary>
        /// 目标的跟随位置
        /// </summary>
        private Vector3 m_TartgetFollowPos = Vector3.zero;

        private float m_smoothTime = 0.03f;
        //private float m_prediction = 0.3f;
        private Vector3 m_velocity = Vector3.zero;
        public void UpdateTarget()
        {
            if (m_Target)
            {
                /*
                var targetVelocity = (m_Target.position - m_TartgetFollowPos) / (Time.deltaTime > 0 ? Time.deltaTime : 0.03f);
                float detla = Mathf.Min(1, Time.deltaTime / m_smoothTime);
                m_velocity = m_velocity * (1 - detla) + (m_Target.position + targetVelocity * m_prediction - m_TartgetFollowPos) * detla;
                m_TartgetFollowPos += m_velocity * Time.deltaTime;
                //m_TartgetFollowPos = m_Target.position; 
                */
                bool invoxelWorld = GameScene.Instance.MainChar?GameScene.Instance.MainChar.VoxelWorldID != 0:false;
                if (LockTarget || invoxelWorld)
                    m_TartgetFollowPos = m_Target.position;
                else
                    m_TartgetFollowPos = Vector3.SmoothDamp(m_TartgetFollowPos, m_Target.position, ref m_velocity, m_smoothTime);

                if (m_enableMainCharOffset)
                    UpdateMainCharOffset();
            }
        }

        bool m_enableMainCharOffset = false;
        float m_skillOffset = 0f;
        const float maxOffsetHeight = 2f;
        float m_offsetTime = 0f;
        public void EnableMainCharOffset(bool enable) {
            m_enableMainCharOffset = enable;
            m_skillOffset = 0f;
            m_offsetTime = 0f;
        }
        private void UpdateMainCharOffset() {
            if (GameScene.Instance.MainChar) {

                if (m_offsetTime > 0.35f)
                {
                    m_skillOffset -= (maxOffsetHeight / 0.35f) * Time.deltaTime;
                }
                else
                {
                    m_skillOffset += (maxOffsetHeight / 0.35f) * Time.deltaTime;
                }
                m_offsetTime += Time.deltaTime;
                if (m_skillOffset <= 0) {
                    m_skillOffset = 0f;
                    m_enableMainCharOffset = false;
                }
                m_TartgetFollowPos += new Vector3(0, m_skillOffset, 0);
            }
            

        }
#endregion


        public bool TestCameraCollision(float rotateX, float rotateY, float distance)
        {
            float rtx = rotateX;
            float rty = rotateY;

            rtx = Utilities.NormalizeAngle(rtx);
            rty = Utilities.NormalizeAngle(rty, 180);
            rty = Mathf.Clamp(rty, Min_Angle_y, Max_Angle_y);

            Quaternion mRotation = Quaternion.Euler(rty, rtx, 0);
            if (m_Target)
            {
                Vector3 mPosition = mRotation * new Vector3(0.0F, 0.0F, -distance);

                var dir = m_lookAtTempOffset + LookAtPosOffset;

                Vector3 pTarget = m_Target.position + dir;

                mPosition += pTarget;
                Vector3 vEye = mPosition - pTarget;
                Vector3 vCamera = mPosition - m_camera.transform.position;

                RaycastHit goofhit;
                if (Utilities.SphereCast(new Ray(m_camera.transform.position, vCamera.normalized), m_radius * 0.8f, out goofhit, vCamera.magnitude, m_detectLayer))
                {
                    RaycastHit rayhit;
                    if (Utilities.SphereCast(new Ray(pTarget, vEye.normalized), m_radius, out rayhit, vEye.magnitude, m_detectLayer))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
            }
            return false;
        }

        public float CalcCurrentMinDistance()
        {
            var d1 = m_minDistance;
            if (m_Target == null )
            {
                return d1;
            }
            //List<SkinnedMeshRenderer> targetRenderer;
            var targetRenderer = m_Target.GetComponentsInChildren<SkinnedMeshRenderer>(false );
            var d2 = 0f;
            foreach (var r in targetRenderer)
            {
                var b = r.localBounds;
                //if (!m_rendererBounds.ContainsKey(r))
                //    m_rendererBounds.Add(r, b);
                //else
                //{
                //    var temp = m_rendererBounds[r];
                //    temp.Encapsulate(b);
                //    m_rendererBounds[r] = temp;
                //}
                //b = m_rendererBounds[r];

                var reference = r.rootBone ?? r.transform;
                var campos = /*m_camera ? m_camera.transform.position : */m_cameraPosition;
                campos = reference.InverseTransformPoint(campos);
                var center = GetTargetPosition();
                center = reference.InverseTransformPoint(center);
                //var center = b.center;//m_target.position;
                var d = CalcMinDistanceByBounds(b, center, campos) + m_boundOffset;
                d2 = Mathf.Max(d2, d);
            }
            var ret = Mathf.Max(d1, d2);

            if (GameScene.Instance.MainChar.Mount != null)
                ret += GameScene.Instance.MainChar.Mount.CC.radius;

            return ret;
        }

        protected float CalcMinDistanceByBounds(Bounds bound, Vector3 center, Vector3 origin)
        {
            var ret = 0f;
            if (center == origin)
                return ret;

           var r = (bound.max - bound.min).magnitude / 2;

            ret = r;
            ret = Mathf.Abs(ret);
            return ret;
        }

        void TargetDirAngleDiff(Entity target, out float x, out float y, out float angledx, out float angledy, out Vector3 dir)
        {
            dir = target.GlobalPosition - GameScene.Instance.MainChar.GlobalPosition;

            //*********************************************************************
            // "x" stands for Quaternion's "y", "y" stands for Quaternion's "x",
            // y = fixed lock target degree + degree caused by altitude intercept
            //*********************************************************************
            x = Utilities.Vector2Angle(dir.z, dir.x);
            x = Utilities.NormalizeAngle(x);

            var yAltitudeInterceptOffset = Vector3.Angle(dir, new Vector3(dir.x, 0, dir.z));
            if (dir.y > 0) yAltitudeInterceptOffset *= -1;
            y = yAltitudeInterceptOffset + m_fLockCamRotateDeg;

            angledx = Utilities.AngleDiff(x, CameraController.Instance.RotateX);
            angledy = Utilities.AngleDiff(y, CameraController.Instance.RotateY);
        }

        public void RotateCameraToEntity(Entity entity, float speed = 10)
        {
            Vector3 ldir;
            float x, y, dx, dy;
            TargetDirAngleDiff(entity, out x, out y, out dx, out dy, out ldir);
            speed = Mathf.Sqrt(dx * dx + dy * dy) / speed;
            CameraController.Instance.AnimRotateTo(x, y, speed);
        }

        /// <summary>
        /// Is entity in camera view port
        /// </summary>
        /// <param name="tPoint"> Point waiting for check (Unity coord) </param>
        /// <param name="tTargetInViewPos"> Point's position in view port (out put) </param>
        /// <param name="tIgnoreX"> Is ignore view port in horizontal </param>
        /// <param name="tIgnoreY"> Is ignore view port in vertical </param>
        /// <returns> Point in sight or not </returns>
        public bool IsPointInSight(Vector3 tPoint,
                                   out Vector3 tTargetInViewPos,
                                   bool tIgnoreX = false, bool tIgnoreY = false)
        {
            tTargetInViewPos = m_camera.WorldToViewportPoint(tPoint);

            bool iNeedRotateX = false;
            bool iNeedRotateY = false;
            if (!tIgnoreX && /* Not ignore X view */
                (tTargetInViewPos.x > 1 || tTargetInViewPos.x < 0 || tTargetInViewPos.z < 0)) /* Target is out of X view */
                    iNeedRotateX = true;
            if (!tIgnoreY && /* Not ignore Y view */
                (tTargetInViewPos.y > 1 || tTargetInViewPos.y < 0 || tTargetInViewPos.z < 0)) /* Target is out of Y view */
                    iNeedRotateY = true;

            return !(iNeedRotateX || iNeedRotateY);
        }

        /// <summary>
        /// Is entity in camera's biax range
        /// </summary>
        /// <param name="tPoint"> Point waiting for check (Unity coord) </param>
        /// <param name="tTargetInViewPos"> Point's position in view port (out put) </param>
        /// <param name="tIgnoreX"> Is ignore view port in horizontal </param>
        /// <param name="tIgnoreY"> Is ignore view port in vertical </param>
        /// <param name="tLeftRange"> Left range (0 - 1, less than right range)</param>
        /// <param name="tRightRange"> right range (0 - 1, bigger than left range)</param>
        /// <param name="tLowerRange"> lower range (0 - 1, less than upper range)</param>
        /// <param name="tUpperRange"> upper range (0 - 1, less than lower range)</param>
        /// <returns> Point in biax range or not; If range is not correct, return true </returns>
        [XLua.BlackList]
        public bool IsPointInBiaxRange(Vector3 tPoint,
                                       out Vector3 tTargetInViewPos,
                                       bool tIgnoreX = false, bool tIgnoreY = false,
                                       float tLeftRange = 0, float tRightRange = 1, 
                                       float tLowerRange = 0, float tUpperRange = 1)
        {
            tTargetInViewPos = m_camera.WorldToViewportPoint(tPoint);
            if (tLeftRange > tRightRange || tLowerRange > tUpperRange)
                return true;

            bool iNeedRotateX = false;
            bool iNeedRotateY = false;
            if (!tIgnoreX && /* Not ignore X view */
                (tTargetInViewPos.x > tRightRange || tTargetInViewPos.x < tLeftRange || tTargetInViewPos.z < 0)) /* Target is out of X view */
                iNeedRotateX = true;
            if (!tIgnoreY && /* Not ignore Y view */
                (tTargetInViewPos.y > tUpperRange || tTargetInViewPos.y < tLowerRange || tTargetInViewPos.z < 0)) /* Target is out of Y view */
                iNeedRotateY = true;

            return !(iNeedRotateX || iNeedRotateY);
        }

        /// <summary>
        /// Give a max horizontal delta angle when locked, otherwise camera will
        /// shake when angle reach max horizontal delta angle, because tox can't
        /// reach the accurate angle, so the angular speed will be keep changing
        /// </summary>
        /// <returns> max horizontal delta angle </returns>
        private float GetMaxHorizontalDeltaAngle()
        {
            Entity iSelectTarget = TargetSelector.Instance.Selected;
            MainCharacter iMainChar = GameScene.Instance.MainChar;

            float iMaxDeltaX = 180;
            Vector3 iMainCharVerlocity = (iMainChar.Position - iMainChar.OldPosition) / Time.deltaTime;
            Vector3 iDir = iMainChar.LocalPosition - iSelectTarget.LocalPosition;
            iMainCharVerlocity.y = 0;
            iDir.y = 0;
            float iAlpha = Vector3.Angle(iMainCharVerlocity, iDir);
            if (iMainCharVerlocity != Vector3.zero && iAlpha > 5)
            {
                float iMainCharAngularSpeed = iMainCharVerlocity.magnitude * Mathf.Sin(Mathf.Deg2Rad * iAlpha) * Mathf.Rad2Deg / iDir.magnitude;
                iMaxDeltaX = iMainCharAngularSpeed / (m_animRotateSpeed * 3);
                if (iAlpha > iMaxDeltaX) iMaxDeltaX = 180;
            }

            return iMaxDeltaX;
        }

        #region 摄像机动画
        public void PlayCameraAnimation(Transform tartget,AnimationClip clip)
        {
            parent = m_camera.transform.parent;
            m_camera.transform.SetParent(tartget);
            EnsureAnimationComponent();
            m_animation.AddClip(clip, clip.name);
            m_animation.Play(clip.name);

        }
        protected void EnsureAnimationComponent()
        {
            if (m_animation == null)
            {
                m_animation = m_camera.gameObject.GetComponent<Animation>();
                if(m_animation == null)
                    m_animation = m_camera.gameObject.AddComponent<Animation>();
            }
        }
        public void InterruptCameraAnimation()
        {
            //*********************************************************
            // Reset main camera's parent to former parent, besides,
            // put main camera to the right scene, other wise it will
            // move to 'DontDestroyOnLoad'
            //*********************************************************
            m_camera.transform.SetParent(parent);
            UnityEngine.SceneManagement.Scene iCurScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(m_camera.gameObject, iCurScene);
            EnsureAnimationComponent();
            if (m_animation)
            {
                m_animation.Stop();
                GameObject.DestroyImmediate(m_animation);
                m_animation = null;
                parent = null;

                m_bIsCamLerpMove = true;
            }
        }
        protected Transform parent = null;
        protected Animation m_animation = null;
        //protected string m_animation = null;
        protected bool UpdateCameraAnimation()
        {
            if(m_animation != null)
            {
                if (!m_animation.isPlaying)
                    InterruptCameraAnimation();
                return true;
            }
            return false;
        }

        public override void UpdateCameraAnimation(CameraData data, float progress)
        {
            if (data == null) return;
            if (data.isCameraDistanceCurve)
            {
                CurDistance = data.cameraDistanceCurve.Evaluate(progress);
            }
            if (data.isCameraRotateXCurve)
            {
                RotateX = data.cameraRotateXCurve.Evaluate(progress);
            }
            if (data.isCameraRotateYCurve)
            {
                Instance.RotateY = data.cameraRotateYCurve.Evaluate(progress);
            }
            if (data.isCameraFollowSmoothTimeCurve)
            {
                FollowSmoothTime = data.cameraFollowSmoothTimeCurve.Evaluate(progress);
            }
            if (data.isCameraLookAtOffsetCurve)
            {
                SetLookAtDetlaOffset(new Vector3(data.cameraLookAtOffsetXCurve.Evaluate(progress),
                    data.cameraLookAtOffsetYCurve.Evaluate(progress), data.cameraLookAtOffsetZCurve.Evaluate(progress)));
            }
        }


        #endregion


        #region CameraConfig
        public CameraControllerConfig CameraConfig { get { return m_cameraConfig; } }
        public CameraCharacterConfig CharacterConfig { get { return m_CharacterConfig; } }

        protected CameraControllerConfig m_cameraConfig;
        protected CameraCharacterConfig m_CharacterConfig;
        public void LoadConfig(CameraControllerConfig config)
        {
            m_cameraConfig = config;

            if (config)
            {
                m_curDistance = config.InitDistance;
                m_fovCurve = config.FOVCurve;

                if (m_Target)
                {
                    if (config.CharacterConfig != null && config.CharacterConfig.Length > 0)
                    {
                        foreach (var c in config.CharacterConfig)
                        {
                            if (m_Target.name.StartsWith(c.PrefabName))
                            {
                                m_CharacterConfig = c;
                                break;
                            }
                        }
                    }
                }
            }


        }
        public CameraControllerConfig SaveConfig(out float rotateX, out float rotateY)
        {
            if (m_cameraConfig == null)
            {
                rotateX = rotateY = 0;
                return null;
            }
            rotateX = rotateY = 0;
            CameraControllerConfig config = new CameraControllerConfig();
            //config.MaxDistance = m_maxDistance;
            //config.MinDistance = m_curMinDistance;
            //config.BoundOffset = m_boundOffset;
            //config.InitDistance = m_curDistance;
            //config.MouseSlideDelta = m_slideDetla;
            //config.MouseZoomSpeed = m_zoomSpeed;

            //rotateX = m_x;
            //rotateY = m_y;
            //            config.CharacterConfig = new CameraCharacterConfig[m_cameraConfig.CharacterConfig.Length];
            //             for (int i = 0; i < m_cameraConfig.CharacterConfig.Length; ++i)
            //             {
            //                 var c = m_cameraConfig.CharacterConfig[i];
            //                 var c_new = new CameraCharacterConfig();
            //                 c_new.LookTargetHeadOffset = 
            //             }
            return config;
        }

        #endregion


        private bool UpdateCamTween()
        {
            if (m_camera == null)
                return true;

            if (!m_isCamTween)
                return false;

            m_tweenRotStep += Time.deltaTime * m_tweenRotStepSpeed;
            if (m_tweenRotStep > 1.0f)
            {
                m_isCamTween = false;
                m_tweenRotStep = 1.0f;
            }

            var pos = Vector3.Lerp(m_tweenSrcPos, m_tweenDestPos, m_tweenRotStep);
            var rot = Quaternion.Lerp(m_tweenSrcRot, m_tweenDestRot, m_tweenRotStep);

            var ct = m_camera.transform;
            ct.position = pos;
            ct.rotation = rot;

            m_onRotStepEvent.Invoke();

            if (!m_isCamTween)
            {
                m_onTweenEndEvent.Invoke();
            }

            return true;
        }

        public void StartTween(float rotspeed = 1.0f)
        {
            if (m_camera == null)
                return;

            m_isCamTween = true;
            m_tweenDestPos = m_curCamPos;
            m_tweenDestRot = m_curCamQuat;

            m_tweenSrcPos = m_camera.transform.position;
            m_tweenSrcRot = m_camera.transform.rotation;

            m_tweenRotStep = 0.0f;
            m_tweenRotStepSpeed = rotspeed;

        }
    }
}