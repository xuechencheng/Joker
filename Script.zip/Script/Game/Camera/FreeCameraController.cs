﻿using UnityEngine;
using System.Collections;
using Bokura;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering;

namespace Bokura
{
    //时装的相机
    public class FreeCameraController : ICameraController
    {
        protected static FreeCameraController m_instance = null;
        public static FreeCameraController Instance { get { if (m_instance == null) m_instance = new FreeCameraController(ICameraHelper.Instance); return m_instance; } }

        public FreeCameraController(ICameraHelper helper) : base(CameraControlMode.FreeCamera, helper) {  }

        //旋转角度
        float CurDistance = 5;
        Vector3 Direction = Vector3.forward;
        float m_freeMoveSpeed = 10.0f;
        float m_freeModeRotateSpeed = 45.0f;
        Vector3 m_CurMoveVel;
        Vector2 m_CurRotVel;
        float m_freeRollSpeed = 0.0f;
        public override void DeInit()
        {
            //throw new NotImplementedException();
        }

        public override void Init()
        {
            //throw new NotImplementedException();
        }

        public override void LateUpdate()
        {
            //throw new NotImplementedException();
        }
        public override void ResetConfig()
        {
            //throw new NotImplementedException();
        }
        public override void Update()
        {
            Vector2 curRot;
            curRot.x = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalAxis) * 50.0f;
            curRot.y = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraVerticalAxis) * 50.0f;
            Vector3 dir = Vector3.zero;
            float rollSpeed = 0.0f;
            bool key_rot = Mathf.Abs(curRot.x) < 0.1f && Mathf.Abs(curRot.y) < 0.1f;
            if (IUnityInput.Instance.GetKey(KeyCode.W))
            {
                dir.z = 1.0f;
            }
            if (IUnityInput.Instance.GetKey(KeyCode.S))
            {
                dir.z -= 1.0f;
            }

            if (IUnityInput.Instance.GetKey(KeyCode.A))
            {

                dir.x -= 1.0f;

            }
            if (IUnityInput.Instance.GetKey(KeyCode.D))
            {
                dir.x += 1.0f;
            }

            if (IUnityInput.Instance.GetKey(KeyCode.F) && !IUnityInput.Instance.GetKey(KeyCode.LeftShift))
            {

                rollSpeed += m_freeModeRotateSpeed;
            }
            if (IUnityInput.Instance.GetKey(KeyCode.G))
            {
                rollSpeed -= m_freeModeRotateSpeed;
            }

            if (IUnityInput.Instance.GetKeyDown(KeyCode.KeypadPlus) || IUnityInput.Instance.GetKeyDown(KeyCode.Equals))
            {
                if (IUnityInput.Instance.GetKey(KeyCode.LeftShift))
                    m_freeModeRotateSpeed *= 1.1f;
                else
                    m_freeMoveSpeed *= 1.1f;
            }


            if (IUnityInput.Instance.GetKeyDown(KeyCode.KeypadMinus) || IUnityInput.Instance.GetKeyDown(KeyCode.Minus))
            {
                if (IUnityInput.Instance.GetKey(KeyCode.LeftShift))
                    m_freeModeRotateSpeed *= 0.9f;
                else
                    m_freeMoveSpeed *= 0.9f;
            }


            if (IUnityInput.Instance.GetKey(KeyCode.Q))
            {
                var upv = Quaternion.Inverse(ICameraHelper.MainCamera.transform.localRotation) * Vector3.up;
                dir += upv;
            }
            if (IUnityInput.Instance.GetKey(KeyCode.E))
            {
                var downv = Quaternion.Inverse(ICameraHelper.MainCamera.transform.localRotation) * Vector3.down;
                dir += downv;
            }

            if (IUnityInput.Instance.GetKey(KeyCode.LeftArrow))
            {
                curRot.x -= m_freeModeRotateSpeed;
                //key_rot = true;
            }

            if (IUnityInput.Instance.GetKey(KeyCode.RightArrow))
            {
                curRot.x += m_freeModeRotateSpeed;
                //key_rot = true;
            }
            if (IUnityInput.Instance.GetKey(KeyCode.UpArrow))
            {
                curRot.y -= m_freeModeRotateSpeed;
                //key_rot = true;
            }

            if (IUnityInput.Instance.GetKey(KeyCode.DownArrow))
            {
                curRot.y += m_freeModeRotateSpeed;
                //key_rot = true;
            }


            float speedMul = 1.0f;
            if (IUnityInput.Instance.GetKey(KeyCode.RightShift) || IUnityInput.Instance.GetKey(KeyCode.LeftShift))
            {
                speedMul = 2.0f;
            }
            if (IUnityInput.Instance.GetKey(KeyCode.RightControl) || IUnityInput.Instance.GetKey(KeyCode.LeftControl))
            {
                speedMul = 4.0f;
            }
            var rdelta = (curRot - m_CurRotVel);

            if (rdelta.magnitude > m_freeModeRotateSpeed / 20.0f && key_rot)
            {

                float acc = 0.5f * Time.deltaTime * m_freeModeRotateSpeed;
                if (acc > rdelta.magnitude)
                    acc = rdelta.magnitude;
                m_CurRotVel += rdelta.normalized * acc;
            }
            else
            {
                m_CurRotVel = curRot;
            }

            var rollDelta = (rollSpeed - m_freeRollSpeed);

            if (rollDelta > m_freeModeRotateSpeed / 20.0f)
                m_freeRollSpeed += m_freeModeRotateSpeed * Time.deltaTime;
            else if (rollDelta < -m_freeModeRotateSpeed / 20.0f)
                m_freeRollSpeed -= m_freeModeRotateSpeed * Time.deltaTime;
            else
                m_freeRollSpeed = rollSpeed;
            // m_freeRollAngle += rollDelta*Time.deltaTime;


            dir.Normalize();
            dir *= m_freeMoveSpeed * speedMul;
            var cure = ICameraHelper.MainCamera.transform.localEulerAngles;

            cure.x -= m_CurRotVel.y * Time.deltaTime;
            cure.y += m_CurRotVel.x * Time.deltaTime;
            cure.x = Utilities.NormalizeAngle(cure.x, 180);

            if (cure.x > 89.0f)
                cure.x = 89.0f;
            if (cure.x < -89.0f)
                cure.x = -89.0f;




            var curtarget = Direction * CurDistance;
            cure.z += m_freeRollSpeed * Time.deltaTime;
            ICameraHelper.MainCamera.transform.localRotation = Quaternion.Euler(cure);

            var newtarget = Direction * CurDistance;

            var posdiff = newtarget - curtarget;
            //posdiff.y = 0.0f;

            var vdelta = (dir - m_CurMoveVel);
            if (vdelta.magnitude > 0.01f)
            {
                float acc = m_freeMoveSpeed * Time.deltaTime;
                if (acc > vdelta.magnitude)
                    acc = vdelta.magnitude;
                m_CurMoveVel += vdelta.normalized * acc;
            }

            //m_CurMoveVel += (dir - m_CurMoveVel) / (2.0f /Time.deltaTime);
            //if (m_CurMoveVel.magnitude < 0.1f)
            //    m_CurMoveVel = Vector3.zero;

            if (m_CurMoveVel.magnitude > 0.01f)
                ICameraHelper.MainCamera.transform.position += ICameraHelper.MainCamera.transform.localRotation * (m_CurMoveVel * Time.deltaTime);
            if (key_rot)
            {
                ICameraHelper.MainCamera.transform.position -= posdiff;
            }

            //m_camera.transform.position += new Vector3(0.0f, m_freeMoveSpeed * speedMul * Time.deltaTime, 0.0f);

        }
    }
    
}