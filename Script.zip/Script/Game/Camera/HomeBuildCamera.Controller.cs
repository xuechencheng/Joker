using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using Bokura;

namespace Bokura
{
    public class HomeBuildCameraController : ICameraController
    {
        protected static HomeBuildCameraController m_instance = null;
        public static HomeBuildCameraController Instance { get { if (m_instance == null) m_instance = new HomeBuildCameraController(ICameraHelper.Instance); return m_instance; } }
        public HomeBuildCameraController(ICameraHelper helper) : base(CameraControlMode.HomeBuildCamera, helper) { }


        private Camera m_Camera { get { return ICameraHelper.MainCamera; } }

        /// <summary>
        /// 目标位置的偏移值
        /// </summary>
        private Vector3 m_destPosOff = new Vector3(0.0f, 40.0f, -40.0f);

        /// <summary>
        /// 目标旋转固定值
        /// </summary>
        private Quaternion m_destRotVal = Quaternion.Euler(50.0f, 0.0f, 0.0f);

        /// <summary>
        /// 旋转的步长值
        /// </summary>
        private float m_rotStepVal = 1.0f;


        private float m_rotStepSpeed = 1.0f;
        /// <summary>
        /// 旋转速度
        /// </summary>
        public float rotStepSpeed
        {
            set { m_rotStepSpeed = value; }
        }


        private GameEvent m_onCameraMoveEvent = new GameEvent();
        public GameEvent onCameraMoveEvent
        {
            get { return m_onCameraMoveEvent; }
        }


        private GameEvent m_onRotStepEvent = new GameEvent();
        public GameEvent onRotStepEvent
        {
            get { return m_onRotStepEvent; }
        }


        private GameEvent m_onUpdateEvent = new GameEvent();
        public GameEvent onUpdateEvent
        {
            get { return m_onUpdateEvent; }
        }

        public override void Init()
        {

            //m_Camera

            //GameScene.Instance.MainChar.Avatar.unityObject.transform.localToWorldMatrix;

        }

        Vector3 m_destPos;
        Quaternion m_destRot;
        Vector3 m_srcPos;
        Quaternion m_srcRot;

        float m_rotStep;
        public override void Enter(ICameraController prev)
        {
            base.Enter(prev);
            //var charpos = GameScene.Instance.MainChar.Position;
            var x = HomeBuildingMgr.Instance.BuildRange.center.x * HomeBuildingViewer.GridSize;
            var z = HomeBuildingMgr.Instance.BuildRange.center.y * HomeBuildingViewer.GridSize;
            var charpos = new Vector3(x, 0.0f, z);
            charpos += HomeBuildingViewer.Instance.Offset;
            //charpos.y = 0;
            m_destPos = m_destPosOff;
            m_destPos += charpos;
            m_destRot = m_destRotVal;
            var t = GameScene.Instance.MainChar.Avatar.unityObject.transform;

            m_srcPos = t.position;
            m_srcRot = t.rotation;
            m_rotStep = 0.0f;
            m_rotStepSpeed = 1.0f;
        }

        public override void Leave(ICameraController next)
        {
            base.Leave(next);
        }

        public override void ResetConfig()
        {
        }



        public void Reset()
        {


        }



        public Camera GetMainCamera()
        {
            return m_Camera;
        }



     


        public void SetCameraPosition(Vector3 pos)
        {
            if (m_Camera != null)
                m_Camera.transform.position = pos;
        }



        public Vector3 GetCameraPosition()
        {
            if (m_Camera != null)
                return m_Camera.transform.position;

            return Vector3.zero;
        }


        public void MoveXZ(float x, float z)
        {
            if (m_Camera == null)
                return;

            if (m_rotStep != m_rotStepVal)
                return;

            m_Camera.transform.position += new Vector3(x, 0.0f, z);

            m_onCameraMoveEvent.Invoke();
        }

        public void StartTween(int building_uid, float rotspeed = 1.0f)
        {
            HomeBuilding building = HomeBuildingViewer.Instance.GetBuildingById(building_uid);
            if (building == null)
                return;

            if (m_Camera == null)
                return;

            Vector3 pos = building.Position;
            pos.y = 0.0f;

            m_destPos = m_destPosOff;
            m_destPos += pos;
            m_destRot = m_destRotVal;

            m_srcPos = m_Camera.transform.position;
            m_srcRot = m_Camera.transform.rotation;

            m_rotStep = 0.0f;
            m_rotStepSpeed = rotspeed;

        }

        public void FlushAnimMove()
        {
            m_rotStep = m_rotStepVal;
            var ct = m_Camera.transform;
            ct.position = m_destPos;
            ct.rotation = m_destRot;
        }
      
        public void SetFOV(float newValue)
        {
            if (m_Camera != null)
                m_Camera.fieldOfView = newValue;
        }


        public float GetFOV()
        {
            if (m_Camera != null)
                return m_Camera.fieldOfView;
            return 60;
        }

        public override void Update()
        {
            var ct = m_Camera.transform;

            if (m_rotStep != m_rotStepVal)
            {
                m_rotStep += Time.deltaTime * m_rotStepSpeed;
                if (m_rotStep > m_rotStepVal)
                    m_rotStep = m_rotStepVal;
                //ct.rotation = Quaternion.Lerp(m_startRot, m_destRot, m_rotStep);
                var pos = Vector3.Lerp(m_srcPos, m_destPos, m_rotStep);
                var rot = Quaternion.Lerp(m_srcRot, m_destRot, m_rotStep);
                ct.position = pos;
                ct.rotation = rot;
                // + new Vector3(0.0f, m_destPos.y- m_startPos.y, 0.0f);
                // ct.rotation = Quaternion.LookRotation(m_mainCharPos - ct.position);

                m_onRotStepEvent.Invoke();
            }

            m_onUpdateEvent.Invoke();
        }

        public override void DeInit()
        {
            
        }

        public override void LateUpdate()
        {
           
        }
    }
}