using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using Bokura;

namespace Bokura
{
    public class HomeBuildDetailCameraController : ICameraController
    {
        protected static HomeBuildDetailCameraController m_instance = null;
        public static HomeBuildDetailCameraController Instance { get { if (m_instance == null) m_instance = new HomeBuildDetailCameraController(ICameraHelper.Instance); return m_instance; } }
        public HomeBuildDetailCameraController(ICameraHelper helper) : base(CameraControlMode.HomeBuildDetailCamera, helper) { }

        private Camera m_Camera { get { return ICameraHelper.MainCamera; } }

        public override void Init()
        {
            
        }

        private Vector3 m_destPos;

        private Vector3 m_destPosOff;

        private Quaternion m_destRot;

        private Vector3 m_srcPos;

        private Quaternion m_srcRot;

        private float m_rotStep;

        private float m_rotStepSpeed = 1.0f;

        private float m_rotTime = 1.0f;

        /// <summary>
        /// 动画第一次结束
        /// </summary>
        private bool m_animFirstEnd = false;


        private uint m_building_uid;
        /// <summary>
        /// 建筑唯一id
        /// </summary>
        public uint building_uid
        {
            get { return m_building_uid; }
            set { m_building_uid = value; }
        }


        private GameEvent m_onAnimFirstEndEvent = new GameEvent();
        public GameEvent onAnimFirstEndEvent
        {
            get { return m_onAnimFirstEndEvent; }
        }

        public override void Enter(ICameraController prev)
        {
            base.Enter(prev);

        }

        public override void Leave(ICameraController next)
        {
            base.Leave(next);
        }

        public override void ResetConfig()
        {
        }


        public void Reset()
        {

        }

        public Camera GetMainCamera()
        {
            return m_Camera;
        }

        public void SetCameraPosition(Vector3 pos)
        {
            if (m_Camera != null)
                m_Camera.transform.position = pos;
        }

        public Vector3 GetCameraPosition()
        {
            if (m_Camera != null)
                return m_Camera.transform.position;

            return Vector3.zero;
        }

        public void SetDestPos(Vector3 pos)
        {
            m_destPos = pos + m_destPosOff;
        }

        public void MoveXZ(float x, float z)
        {
            if (m_Camera == null)
                return;

            m_Camera.transform.position += new Vector3(x, 0.0f, z);
        }

        public void StartTween(int building_uid, float rotStepSpeed = 1.0f)
        {
            m_building_uid = (uint)building_uid;

            var building = HomeBuildingViewer.Instance.GetBuildingById((int)m_building_uid);
            if (building == null)
                return;

            var cam = GetMainCamera();
            if (cam == null)
                return;

            //float eulery = 0.0f;
            //var trans = building.GetTrans();
            //if (trans != null)
            //{
            //    eulery = trans.eulerAngles.y;
            //}

            m_destPosOff = new Vector3(0.0f, 15.0f, -15.0f);
            SetDestPos(building.Position);
            m_destRot = Quaternion.Euler(50.0f, 0.0f, 0.0f);

            m_srcPos = cam.transform.position;
            m_srcRot = cam.transform.rotation;

            m_rotStep = 0.0f;
            m_rotStepSpeed = rotStepSpeed;
            m_animFirstEnd = false;
        }
        
        public void SetFOV(float newValue)
        {
            if (m_Camera != null)
                m_Camera.fieldOfView = newValue;
        }

        public float GetFOV()
        {
            if (m_Camera != null)
                return m_Camera.fieldOfView;

            return 60.0f;
        }

        public override void Update()
        {
            var ct = m_Camera.transform;
            
            if (m_rotStep < m_rotTime)
            {
                m_rotStep += Time.deltaTime * m_rotStepSpeed;
                if (m_rotStep > m_rotTime)
                    m_rotStep = m_rotTime;

                var pos = Vector3.Lerp(m_srcPos, m_destPos, m_rotStep);
                var rot = Quaternion.Lerp(m_srcRot, m_destRot, m_rotStep);
                ct.position = pos;
                ct.rotation = rot;
                return;
            }

            ct.position = m_destPos;
            ct.rotation = m_destRot;

            if (!m_animFirstEnd)
            {
                m_animFirstEnd = true;
                m_onAnimFirstEndEvent.Invoke();
            }
        }

        public override void DeInit()
        {
            
        }

        public override void LateUpdate()
        {
           
        }
    }
}