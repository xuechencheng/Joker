﻿using UnityEngine;
using System.Collections;
using Bokura;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering;

namespace Bokura
{
    public class ManorBuildingCameraController : ICameraController//: IManorBuildingCamera
    {
        protected static ManorBuildingCameraController m_instance = null;
        public static ManorBuildingCameraController Instance { get { if (m_instance == null) m_instance = new ManorBuildingCameraController(ICameraHelper.Instance); return m_instance; } }
        public ManorBuildingCameraController(ICameraHelper helper) : base(CameraControlMode.ManorBuildingCamera, helper) { }

        Transform m_cameraTransform;

        public float lookSpeed = 3f;
        public float moveSpeed = 20f;
        public float sprintSpeed = 50f;

        //bool m_inputCaptured;//没有用的变量 m_inputCaptured 之前有使用 但是现在已经注销 会报警告 注销掉 赋值的地方也注销 shiliang
        float m_yaw;
        float m_pitch;


        private float m_radius = 0.5f;

        bool m_Enabled;

        public bool Enabled
        {
            get
            {
                return m_Enabled;
            }

            set
            {
                m_Enabled = value;

                if (m_Enabled)
                {
                    InitCamera();
                }
                else
                {
                    m_cameraTransform = null;
                }
            }
        }
        public bool MovingUp;
        public bool MovingDown;
        bool m_LockRotation;
        public bool LockRotation
        {
            get
            {
                return m_LockRotation;
            }

            set
            {
                m_LockRotation = value;
            }
        }
        void InitCamera()
        {

            if (Camera != null)
            {
                var obj = Camera.gameObject;
                if (obj.GetComponent<AudioStudio.DefaultAudioListener>() == null)
                    obj.AddComponent<AudioStudio.DefaultAudioListener>();

                if (obj.GetComponent<Bokura.OffscreenDepthRenderer>() == null)
                    obj.AddComponent<Bokura.OffscreenDepthRenderer>();

                //if (obj.GetComponent<ScreenSnapshoot>() == null)
                //{
                //    obj.AddComponent<ScreenSnapshoot>();
                //}

#if (UNITY_STANDALONE_WIN)//mata add for HBAO+ and volumetricLight Effect
                if (obj.GetComponent<VolumetricLightRenderer>() == null)
                    obj.AddComponent<VolumetricLightRenderer>();


                if (obj.GetComponent<HBAO>() == null)
                    obj.AddComponent<HBAO>();
#endif

                m_cameraTransform = Camera.transform;
            }
        }

        public void CaptureInput()
        {
            //m_inputCaptured = true;

            m_yaw = m_cameraTransform.eulerAngles.y;
            m_pitch = m_cameraTransform.eulerAngles.x;
        }

        public void ReleaseInput()
        {
            //m_inputCaptured = false;
        }
        public Camera Camera { get { return ICameraHelper.MainCamera; } }

        private float m_JoystickForward;
        private float m_JoystickRight;
        public void JoystickMoveTo(Vector3 jsdir)
        {
            m_JoystickForward = jsdir.y * 0.01f;
            m_JoystickRight = jsdir.x * 0.01f;
        }

        public override void ResetConfig()
        {
            //throw new NotImplementedException();
        }
        private int LayerMask_Terrain = LayerMask.GetMask("Terrain");
        public override void Update()
        {
            if (!m_Enabled)
                return;
            if (m_cameraTransform == null)
                return;

            var speed = Time.deltaTime * (IUnityInput.Instance.GetKey(KeyCode.LeftShift) ? sprintSpeed : moveSpeed);
            var forward = speed * IUnityInput.Instance.GetAxisRaw("Vertical");
            var right = speed * IUnityInput.Instance.GetAxisRaw("Horizontal");

            forward = speed * m_JoystickForward;
            right = speed * m_JoystickRight;

            var up = speed * ((IUnityInput.Instance.GetKey(KeyCode.E) || MovingUp ? 1f : 0f) - 
                             (IUnityInput.Instance.GetKey(KeyCode.Q)  || MovingDown ? 1f : 0f));

            Vector3 position = m_cameraTransform.position;
            position = m_cameraTransform.position + m_cameraTransform.forward * forward + m_cameraTransform.right * right + Vector3.up * up;

            Vector3 vCamera = position - m_cameraTransform.position;

            //Vector3 vEye = position - m_cameraTransform.position;
            
            RaycastHit rayhit;
            if (Physics.SphereCast(new Ray(m_cameraTransform.position, vCamera.normalized), m_radius, out rayhit, vCamera.magnitude + 0.1f, LayerMask_Terrain))
            {
                //Bokura.LogHelper.LogErrorFormat(Bokura.LogCategory.Framework,"vCamera.magnitude={0}, rayhit.distance={1}", vCamera.magnitude, rayhit.distance);

                //校正
                //Vector3 changedpos = -vCamera.normalized * rayhit.distance;
                //position += changedpos;
                //position = rayhit.point + rayhit.normal * m_radius;
                position = m_cameraTransform.position;
            }
            

            m_cameraTransform.position = position;
// 
//             if (!m_inputCaptured)
//             {
//                 if (IUnityInput.Instance.GetMouseButtonDown(1))
//                     CaptureInput();
//             }
//             
//             if (m_inputCaptured)
//             {
//                 if (IUnityInput.Instance.GetMouseButtonUp(1))
//                     ReleaseInput();
//             }
/*

            if (/ *m_inputCaptured && * /!m_LockRotation)
            {
                var rotStrafe = ICrossPlatformInputManager.Instance.GetAxis(IVirtualInput.CameraHorizontalAxisName);// IUnityInput.Instance.GetAxis("Mouse X");
                var rotFwd = ICrossPlatformInputManager.Instance.GetAxis(IVirtualInput.CameraVerticalAxisName); // IUnityInput.Instance.GetAxis("Mouse Y");

                Rotate(rotStrafe, rotFwd);

            }*/
        }
        
        public void Rotate(float x, float y)
        {
            m_yaw = m_yaw + lookSpeed * x;
            m_pitch = Mathf.Min(90, Mathf.Max(-90, m_pitch - lookSpeed * y));
            
            m_cameraTransform.eulerAngles = new Vector3(m_pitch, m_yaw, 0);
        }

        public void LookAt(Vector3 pos)
        {
            m_cameraTransform.LookAt(pos);
        }

        public void SetPosition(Vector3 pos)
        {
            m_cameraTransform.position = pos;
        }

        public override void Init()
        {
            //throw new NotImplementedException();
        }

        public override void DeInit()
        {
            //throw new NotImplementedException();
        }

        public override void LateUpdate()
        {
            //throw new NotImplementedException();
        }
    }
}
