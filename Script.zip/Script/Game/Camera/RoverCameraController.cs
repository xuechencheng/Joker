using UnityEngine;
using System.Collections;


/// <summary>
/// The very simple FPS camera.
/// </summary>
public class RoverCameraController: MonoBehaviour {

    public Transform Target = null;


	public float rotationSensitivity = 3f;
	public float yMinLimit = -89f;
	public float yMaxLimit = 89f;
    public float speed = 0.5f;
    public float Normalspeed = 0.5f;

    private float x, y;
        

	void Awake () {
		Vector3 angles = transform.eulerAngles;
		x = angles.y;
		y = angles.x;
	}

	public void LateUpdate() {
		//Cursor.lockState = CursorLockMode.Locked;

        if(Target != null)
        {
            //���¼���λ�úͽǶ�
            Quaternion mRotation = Quaternion.Euler(45, 0, 0);
            if (Target)
            {
                Vector3 mPosition = Target.position + new Vector3(0,1,0) + mRotation * new Vector3(0.0F, 0.0F, -5);
                transform.position = mPosition;
                transform.rotation = mRotation;
            }
        }

        if(Input.GetMouseButton(1))
        {
            x += Input.GetAxis("Mouse X") * rotationSensitivity;
            y = ClampAngle(y - Input.GetAxis("Mouse Y") * rotationSensitivity, yMinLimit, yMaxLimit);

            // Rotation
            transform.rotation = Quaternion.AngleAxis(x, Vector3.up) * Quaternion.AngleAxis(y, Vector3.right);

        }
        if(Input.GetKey(KeyCode.W))
        {
            transform.position += speed * transform.forward;
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.position -= speed * transform.forward;
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.position -= speed * transform.right;
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.position += speed * transform.right;
        }
        if (Input.GetKey(KeyCode.LeftShift))
        {
            speed += 0.1f;
        }else
        {
            speed = Normalspeed;
        }
    }

	// Clamping Euler angles
	private float ClampAngle (float angle, float min, float max) {
		if (angle < -360) angle += 360;
		if (angle > 360) angle -= 360;
		return Mathf.Clamp (angle, min, max);
	}

}

