using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using Bokura;

namespace Bokura
{
    public class SeptBuildCameraController : ICameraController
    {
        protected static SeptBuildCameraController m_instance = null;
        public static SeptBuildCameraController Instance { get { if (m_instance == null) m_instance = new SeptBuildCameraController(ICameraHelper.Instance); return m_instance; } }
        public SeptBuildCameraController(ICameraHelper helper) : base(CameraControlMode.SeptBuildCamera, helper) { }



        private Camera m_Camera { get { return ICameraHelper.MainCamera; } }


        /// <summary>
        /// 目标位置的偏移值
        /// </summary>
        private Vector3 m_destPosOff = new Vector3(0.0f, 40.0f, -40.0f);

        /// <summary>
        /// 目标旋转固定值
        /// </summary>
        private Quaternion m_destRotVal = Quaternion.Euler(50.0f, 0.0f, 0.0f);


        /// <summary>
        /// 旋转速度
        /// </summary>
        private float m_rotStepSpeed = 1.0f;

        private GameEvent m_onCameraMoveEvent = new GameEvent();
        public GameEvent onCameraMoveEvent
        {
            get { return m_onCameraMoveEvent; }
        }


        private GameEvent m_onRotStepEvent = new GameEvent();
        public GameEvent onRotStepEvent
        {
            get { return m_onRotStepEvent; }
        }


        private GameEvent m_onUpdateEvent = new GameEvent();
        public GameEvent onUpdateEvent
        {
            get { return m_onUpdateEvent; }
        }

        public override void Init()
        {
        }

        Vector3 m_destPos;
        Quaternion m_destRot;
        Vector3 m_srcPos;
        Quaternion m_srcRot;

        float m_rotStep;

        private Vector3 initseepos;

        private Vector3 middlepos;

        private float leftmaxdis;

        private float rightmaxdis;

        private float topmaxdis;

        private float bottommaxdis;


        public override void Enter(ICameraController prev)
        {
            base.Enter(prev);

            var t = GameScene.Instance.MainChar.Avatar.unityObject.transform;

            m_srcPos = t.position;
            m_srcRot = t.rotation;

            m_destPos = m_destPosOff;
            m_destPos += initseepos.WorldToUnityVec();
            m_destRot = m_destRotVal;

            m_rotStep = 0.0f;
            m_rotStepSpeed = 1.0f;

            m_destPos = ClampInRange(m_destPos);
        }

        public override void Leave(ICameraController next)
        {
            base.Leave(next);
        }

        public override void ResetConfig()
        {
            var infocfg = SociatyManager.Instance.infoCfg;

            leftmaxdis = infocfg.topcam_leftmaxdis;
            rightmaxdis = infocfg.topcam_rightmaxdis;
            topmaxdis = infocfg.topcam_topmaxdis;
            bottommaxdis = infocfg.topcam_bottommaxdis;
            middlepos = infocfg.topcam_middlepos;
            initseepos = infocfg.topcam_seepos;
        }

        public void Reset()
        {


        }

        public Camera GetMainCamera()
        {
            return m_Camera;
        }

        public void SetCameraPosition(Vector3 pos)
        {
            if (m_Camera != null)
                m_Camera.transform.position = pos;
        }



        public Vector3 GetCameraPosition()
        {
            if (m_Camera != null)
                return m_Camera.transform.position;
            return Vector3.zero;
        }


        public void MoveXZ(float x, float z)
        {
            if (m_Camera == null)
                return;

            if (m_rotStep != 1.0f)
            {
                return;
            }


            Vector3 pos = m_Camera.transform.position;
            pos += new Vector3(x, 0.0f, z);
            pos = ClampInRange(pos);
            m_Camera.transform.position = pos;
        }

        public void FlushAnimMove()
        {
            m_rotStep = 1.0f;
            var ct = m_Camera.transform;
            ct.position = m_destPos;
            ct.rotation = m_destRot;
        }
      
        public void SetFOV(float newValue)
        {
            if (m_Camera != null)
                m_Camera.fieldOfView = newValue;
        }



        public float GetFOV()
        {
            if (m_Camera != null)
                return m_Camera.fieldOfView;
            return 60;
        }

        public override void Update()
        {
            var ct = m_Camera.transform;

            if (m_rotStep != 1.0f)
            {
                m_rotStep += Time.deltaTime * m_rotStepSpeed;
                if (m_rotStep > 1.0f)
                    m_rotStep = 1.0f;

                var pos = Vector3.Lerp(m_srcPos, m_destPos, m_rotStep);
                var rot = Quaternion.Lerp(m_srcRot, m_destRot, m_rotStep);
                ct.position = pos;
                ct.rotation = rot;
            }

            m_onUpdateEvent.Invoke();
        }

        public override void DeInit()
        {
            
        }

        public override void LateUpdate()
        {
           
        }

        private Vector3 ClampInRange(Vector3 inpos)
        {
            Vector3 outpos = inpos;

            var tempmiddlepos = middlepos.WorldToUnityVec();

            if (inpos.x < tempmiddlepos.x - leftmaxdis)
                outpos.x = tempmiddlepos.x - leftmaxdis;

            if (inpos.x > tempmiddlepos.x + rightmaxdis)
                outpos.x = tempmiddlepos.x + rightmaxdis;

            if (inpos.z > tempmiddlepos.z + topmaxdis)
                outpos.z = tempmiddlepos.z + topmaxdis;

            if (inpos.z < tempmiddlepos.z - bottommaxdis)
                outpos.z = tempmiddlepos.z - bottommaxdis;

            return outpos;
        }

        public void StartTween(Vector3 building_pos, float rotspeed = 1.0f)
        {
            if (m_Camera == null)
                return;

            Vector3 tempinitseepos = initseepos.WorldToUnityVec();
            Vector3 pos = building_pos.WorldToUnityVec();
            pos.y = tempinitseepos.y;

            m_destPos = m_destPosOff;
            m_destPos += pos;
            m_destRot = m_destRotVal;

            m_destPos = ClampInRange(m_destPos);

            m_srcPos = m_Camera.transform.position;
            m_srcRot = m_Camera.transform.rotation;

            m_rotStep = 0.0f;
            m_rotStepSpeed = rotspeed;

        }
    }
}