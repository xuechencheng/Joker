﻿using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using Bokura;

namespace Bokura
{
    public class SimpleCameraController :ICameraController
	{
        protected static SimpleCameraController m_instance = null;
        public static SimpleCameraController Instance { get { if (m_instance == null) m_instance = new SimpleCameraController(ICameraHelper.Instance); return m_instance; } }
        public SimpleCameraController(ICameraHelper helper) : base(CameraControlMode.SimpleCamera, helper) { }



		private Camera m_Camera { get { return ICameraHelper.MainCamera; } }



		/// <summary>
		/// 景深
		/// </summary>
		private DepthOfField m_DepthOfField;



        /// <summary>
        /// 高度雾
        /// </summary>
        private HeightFog m_HeightFog;




		private GameEvent<Vector2> m_OnDrag = null;
		public GameEvent<Vector2> onDrag
		{
			get
            {
                if (null == m_OnDrag)
                    m_OnDrag = new GameEvent<Vector2>();
                return m_OnDrag;
            }
		}



		private GameEvent<float> m_OnScroll = null;
		public GameEvent<float> onScroll
		{
			get
            {
                if (null == m_OnScroll)
                    m_OnScroll = new GameEvent<float>();
                return m_OnScroll;
            }
		}



		public override void Init()
		{
            if (null != m_Camera)
                m_HeightFog = m_Camera.GetComponent<HeightFog>();

            //添加DepthOfFiled控制
            if (m_DepthOfField == null)
			{
				GameObject tPPGo = GameObject.Find("env_PostProcess");
				if (tPPGo)
				{
					PostProcessVolume tPPV = tPPGo.GetComponent<PostProcessVolume>();
					if (null != tPPV)
					{
						DepthOfField tVolumeSetting = null;
						tPPV.profile.TryGetSettings(out tVolumeSetting);
						m_DepthOfField = tVolumeSetting;
					}
				}
			}

			IVirtualInput tActiveInput = ICrossPlatformInputManager.Instance.GetActiveInput();
			if(tActiveInput != null)
			{
				tActiveInput.AddAxes(InputVirtualAxis.CameraHorizontalMoveAxis);
				tActiveInput.AddAxes(InputVirtualAxis.CameraVerticalMoveAxis);
			}
		}



        public override void ResetConfig()
        {
        }



        public void Reset()
		{
			IVirtualInput tActiveInput = ICrossPlatformInputManager.Instance.GetActiveInput();
			if (tActiveInput != null)
			{
				tActiveInput.UnRegisterVirtualAxis(InputVirtualAxis.CameraHorizontalMoveAxis);
				tActiveInput.UnRegisterVirtualAxis(InputVirtualAxis.CameraVerticalMoveAxis);
			}
			//必须置空，否则返回重新登录账号后，景深会失效
			//因为可能引用的是旧数据
			m_DepthOfField = null;
            m_HeightFog = null;
        }



		public Camera GetMainCamera()
		{
			return m_Camera;
		}



		public void SetCameraRotation(Vector3 angle)
		{
			if (m_Camera != null)
			{
				angle.x = ClampAngle(angle.x);
				angle.y = ClampAngle(angle.y);
				angle.y = ClampAngle(angle.y);
				m_Camera.transform.rotation = Quaternion.Euler(angle);
			}
		}



		public Vector3 GetCameraRotation()
		{
			if (m_Camera != null)
			{
				Vector3 tAngles = m_Camera.transform.eulerAngles;
				tAngles.x = ClampAngle(tAngles.x);
				tAngles.y = ClampAngle(tAngles.y);
				tAngles.y = ClampAngle(tAngles.y);
				return tAngles;
			}
			return Vector3.zero;
		}



		private float ClampAngle(float angle)
		{
			angle = angle % 360;
			if (angle > 180)
				angle = angle - 360;
			else if (angle < -180)
				angle = angle + 360;
			return angle;
		}



		public void SetCameraPosition(Vector3 pos)
		{
			if (m_Camera != null)
				m_Camera.transform.position = pos;
		}



		public Vector3 GetCameraPosition()
		{
			if (m_Camera != null)
				return m_Camera.transform.position;
			return Vector3.zero;
		}



		public void SetFOV(float newValue)
		{
			if (m_Camera != null)
				m_Camera.fieldOfView = newValue;
		}



		public float GetFOV()
		{
			if (m_Camera != null)
				return m_Camera.fieldOfView;
			return 60;
		}



		/// <summary>
		/// 打开或关闭景深效果
		/// </summary>
		public void ToggleDepthOfField(bool open, float distance)
		{
			if(m_DepthOfField != null)
			{
				m_DepthOfField.enabled.value = open;
				m_DepthOfField.focusDistance.value = distance;
			}
		}



        /// <summary>
        /// 打开或关闭高度雾效果
        /// </summary>
        public void ToggleHeightFog(bool open)
        {
            if (null != m_HeightFog)
                m_HeightFog.enabled = open;
        }



		public override void Update()
		{
            //鼠标左键平移
            float tX = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalMoveAxis);
            float tY = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraVerticalMoveAxis);

            if (tX != 0 || tY != 0)
                m_OnDrag?.Invoke(new Vector2(tX, tY));

            //鼠标滚轮或双指缩放
            float tScroll = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraDistanceAxis);
            if (tScroll != 0)
                m_OnScroll?.Invoke(tScroll);
        }



        public override void DeInit()
        {
        }



        public override void LateUpdate()
        {
        }
    }
}
