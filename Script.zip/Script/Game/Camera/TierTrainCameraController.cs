using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using Bokura;

namespace Bokura
{
    public class TierTrainCameraController : ICameraController
    {
        protected static TierTrainCameraController m_instance = null;
        public static TierTrainCameraController Instance { get { if (m_instance == null) m_instance = new TierTrainCameraController(ICameraHelper.Instance); return m_instance; } }
        public TierTrainCameraController(ICameraHelper helper) : base(CameraControlMode.TierTrainCamera, helper) { }



        private Camera m_Camera { get { return ICameraHelper.MainCamera; } }



      




      

        public override void Init()
        {

            //m_Camera
        
            //GameScene.Instance.MainChar.Avatar.unityObject.transform.localToWorldMatrix;

        }

        Vector3 m_destPos;
        //Quaternion m_destRot;
        float m_rotStep = 0.0f;
        float m_destDis = 0.0f;
        float m_startDis = 0.0f;
        Vector3 m_startPos;
        //Quaternion m_startRot;
        Vector3 m_mainCharPos;

        Vector3 m_destLookAt;
        public override void Enter(ICameraController prev)
        {
            base.Enter(prev);

            var destpos = new Vector3(0.34f, 0.6f, 2.36f);
            var destlookat = new Vector3(-0.6f, 1.0f, 0.0f);
            //var rot = Quaternion.LookRotation()
            //var rot = Quaternion.Euler(-5.19f, -519.1f, 0.0f);

            var t = GameScene.Instance.MainChar.Avatar.unityObject.transform;
            m_destPos = t.rotation * destpos;
            m_destPos += t.position;

            m_destLookAt = t.rotation * destlookat;
            m_destLookAt += t.position;
            //m_destRot = t.rotation*rot ;

            m_rotStep = 0.0f;
            m_mainCharPos = t.position + t.rotation*(new Vector3(-1.0f,0.5f,0.0f));
            m_startDis = (m_mainCharPos - m_Camera.transform.position).magnitude;
            m_destDis = (m_mainCharPos - m_destPos).magnitude;
            m_startPos = m_Camera.transform.position;
           // m_startRot = m_Camera.transform.rotation;
        }
        public override void Leave(ICameraController next)
        {
            base.Leave(next);
        }

        public override void ResetConfig()
        {
        }



        public void Reset()
        {


        }



        public Camera GetMainCamera()
        {
            return m_Camera;
        }



        public void SetCameraRotation(Vector3 angle)
        {
            if (m_Camera != null)
            {
                angle.x = ClampAngle(angle.x);
                angle.y = ClampAngle(angle.y);
                angle.y = ClampAngle(angle.y);
                m_Camera.transform.rotation = Quaternion.Euler(angle);
            }
        }



        public Vector3 GetCameraRotation()
        {
            if (m_Camera != null)
            {
                Vector3 tAngles = m_Camera.transform.eulerAngles;
                tAngles.x = ClampAngle(tAngles.x);
                tAngles.y = ClampAngle(tAngles.y);
                tAngles.y = ClampAngle(tAngles.y);
                return tAngles;
            }
            return Vector3.zero;
        }



        private float ClampAngle(float angle)
        {
            angle = angle % 360;
            if (angle > 180)
                angle = angle - 360;
            else if (angle < -180)
                angle = angle + 360;
            return angle;
        }



        public void SetCameraPosition(Vector3 pos)
        {
            if (m_Camera != null)
                m_Camera.transform.position = pos;
        }



        public Vector3 GetCameraPosition()
        {
            if (m_Camera != null)
                return m_Camera.transform.position;
            return Vector3.zero;
        }



        public void SetFOV(float newValue)
        {
            if (m_Camera != null)
                m_Camera.fieldOfView = newValue;
        }



        public float GetFOV()
        {
            if (m_Camera != null)
                return m_Camera.fieldOfView;
            return 60;
        }

        public override void Update()
        {
            var ct = m_Camera.transform;
           

            if(m_rotStep!=1.0f)
            {
                m_rotStep += Time.deltaTime;
                if (m_rotStep > 1.0f)
                    m_rotStep = 1.0f;
                //ct.rotation = Quaternion.Lerp(m_startRot, m_destRot, m_rotStep);
                var pos = Vector3.Lerp(m_startPos, m_destPos, m_rotStep);
                var f = Mathf.Pow(m_rotStep,1.5f);
                var curdis = m_startDis * (1 - f) + m_destDis * f;
                var dir = pos - m_destLookAt;
               // dir.y = 0.0f;
                dir.Normalize();
                ct.position = m_destLookAt + dir * curdis;
                ct.rotation = Quaternion.LookRotation(-dir);
                // + new Vector3(0.0f, m_destPos.y- m_startPos.y, 0.0f);
               // ct.rotation = Quaternion.LookRotation(m_mainCharPos - ct.position);
            }
        }



        public override void DeInit()
        {
        }



        public override void LateUpdate()
        {
        }
    }
}
