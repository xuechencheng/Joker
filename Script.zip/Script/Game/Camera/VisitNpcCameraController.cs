﻿using UnityEngine;
using System.Collections;
using Bokura;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering;

namespace Bokura
{
    //访问npc的相机
    public class VisitNpcCameraController : ICameraController
    {
        protected static VisitNpcCameraController m_instance = null;
        public static VisitNpcCameraController Instance { get { if (m_instance == null) m_instance = new VisitNpcCameraController(ICameraHelper.Instance); return m_instance; } }
        public VisitNpcCameraController(ICameraHelper helper) : base(CameraControlMode.VisitNpcCamera, helper) { }

        float m_MoveTime = 0f;
        float m_NowMoveTime = 0f;

        protected Vector3 m_CurPosition = new Vector3(0, 0, 0);
        protected Quaternion m_CurRotation = new Quaternion(0, 0, 0,0);

        protected Vector3 m_Position = new Vector3(0, 0, 0);
        protected Quaternion m_Rotation = new Quaternion(0, 0, 0,0);


        protected Vector3 m_storePosition = new Vector3(0, 0, 0);
        protected Quaternion m_storeRotation = new Quaternion(0, 0, 0, 0);
        public override void Enter(ICameraController prev)
        {
            GameScene.Instance.EnableInput(false);
            GameScene.Instance.MainChar.IsForbidTestInput = true;
            m_storePosition = ICameraHelper.MainCamera.transform.position;
            m_storeRotation = ICameraHelper.MainCamera.transform.rotation;
            base.Enter(prev);
        }
        public override void Leave(ICameraController next)
        {
            //SetCameraRotation(m_storeRotation);
            // SetCameraPosition(m_storePosition );
            //SetCameraPosition(m_storePosition+ ICameraHelper.MainCamera.transform.forward * 5);

            GameScene.Instance.EnableInput(true);
            GameScene.Instance.MainChar.IsForbidTestInput = false;
            base.Leave(next);
        }

        public void SetTarget(Vector3 _curposition, float _angle)
        {
            m_CurPosition.x = _curposition.x;
            m_CurPosition.y = _curposition.y;
            m_CurPosition.z = _curposition.z;
            m_CurRotation = Quaternion.Euler(0, _angle, 0 );
        }

        public void Start(float _time, Vector3 _position,Vector3 _rotation,float fov=60)
        {
            if (m_NowMoveTime > m_MoveTime)
            {
                //上一个如果是动画还没结束 就立即停止
                m_MoveTime = 0;
                SetCameraPosition(m_Position);
                SetCameraRotation(m_Rotation);
            }

            ICameraHelper.SetFOV(fov);
            Vector3 pos = m_CurPosition + m_CurRotation * _position - LayeredSceneLoader.WorldOffset;
            Quaternion tRot = Quaternion.Euler(_rotation);
            tRot = m_CurRotation * tRot;

            m_Position.x = pos.x;
            m_Position.y = pos.y;
            m_Position.z = pos.z;
            m_Rotation = tRot;
            if (_time > 0)
            {
                m_NowMoveTime = 0;
                m_MoveTime = _time;

                //SetCameraRotation(tRot);
                //SetCameraPosition(m_Position+ ICameraHelper.MainCamera.transform.forward * -5);
                
            }
            else
            {
                SetCameraPosition(m_Position);
                SetCameraRotation(m_Rotation);
            }
        }

        public override void Init()
        {
            //throw new NotImplementedException();
        }

        public override void DeInit()
        {
            //throw new NotImplementedException();
        }
        public override void ResetConfig()
        {
            //throw new NotImplementedException();
        }
        public override void Update()
        {
            if(m_MoveTime<=0)
            {
                return;
            }
            if (m_NowMoveTime > m_MoveTime)
                return;

            m_NowMoveTime += Time.deltaTime;

            var pos = Vector3.Lerp(ICameraHelper.MainCamera.transform.position, m_Position, m_NowMoveTime / m_MoveTime);
            var rot = Quaternion.Lerp(ICameraHelper.MainCamera.transform.rotation, m_Rotation, m_NowMoveTime / m_MoveTime);

            SetCameraPosition( pos);
            SetCameraRotation(rot);

      
        }

        private void SetCameraPosition(Vector3 _pos)
        {
            ICameraHelper.MainCamera.transform.position = _pos;
        }

        private void SetCameraRotation(Quaternion _rot)
        {
            ICameraHelper.MainCamera.transform.rotation = _rot;
        }

        public override void LateUpdate()
        {
            //throw new NotImplementedException();
        }
    }

}