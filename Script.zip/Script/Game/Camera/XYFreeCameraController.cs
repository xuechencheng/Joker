
using UnityEngine;
using System.Collections;
using Bokura;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering;

namespace Bokura
{
    //拍照的平移xy轴相机  不在注视主角
    public class XYFreeCameraController : ICameraController
    {
        protected static XYFreeCameraController m_instance = null;
        public static XYFreeCameraController Instance { get { if (m_instance == null) m_instance = new XYFreeCameraController(ICameraHelper.Instance); return m_instance; } }

        public XYFreeCameraController(ICameraHelper helper) : base(CameraControlMode.XYFreeCamera, helper) {  }

      
        public override void DeInit()
        {
            //throw new NotImplementedException();
        }

        public override void Init()
        {
            //throw new NotImplementedException();
        }

        public override void LateUpdate()
        {
            //throw new NotImplementedException();
        }
        public override void ResetConfig()
        {
            //throw new NotImplementedException();
        }
        private Vector3 m_movepos = Vector3.zero;
        private float m_movedisscale = 0.1f;
        public override void Update()
        {
            //鼠标左键平移
         
            float x = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalAxis);
            float y = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraVerticalAxis);

            if (x != 0 || y != 0)
            {
                //m_OnDrag.Invoke(new Vector2(tX, tY));
                //LogHelper.Log("x=" + x + "  y=" + y + "  ICameraHelper.MainCamera.transform.right=" + ICameraHelper.MainCamera.transform.right);
                m_movepos.x = x* ICameraHelper.MainCamera.transform.right.x* m_movedisscale;
                m_movepos.y = y* m_movedisscale;
                m_movepos.z = x * ICameraHelper.MainCamera.transform.right.z* m_movedisscale;
                RaycastHit hit;
                //ICameraHelper.MainCamera.transform.right
                Vector3 frompos = ICameraHelper.MainCamera.transform.position+ m_movepos;
                if (frompos.y > 2000) //大于2000 不能在往上移动摄像机
                {
                    m_movepos.y = 0;
                }
                else
                {
                    //往下0.5米就到地面 则不能往下移动摄像机
                    if (Physics.Raycast(frompos + Vector3.up * 2f, Vector3.down, out hit, 2.5f, (int)Bokura.UserLayerMask.Terrain, QueryTriggerInteraction.Ignore))
                    {
                        m_movepos.y = hit.point.y + 0.5f- ICameraHelper.MainCamera.transform.position.y;
                    }
                }


                ICameraHelper.MainCamera.transform.position += m_movepos;
            }


            //鼠标滚轮或双指缩放
            //float tScroll = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraDistanceAxis);
            //if (tScroll != 0)
            //{
                //m_OnScroll.Invoke(tScroll);
            //}


        }
    }
    
}