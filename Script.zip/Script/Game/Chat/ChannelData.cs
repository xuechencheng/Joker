using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 聊天表情 坐标
    /// </summary>
    public class ChatEmotionPosition
    {
        private int m_MapBaseId = 0;
        private string m_MapName = string.Empty;
        private Vector3 m_Pos = Vector3.zero;

        public int MapBaseId
        {
            get
            {
                return m_MapBaseId;
            }
        }

        public string MapName
        {
            get
            {
                return m_MapName;
            }
        }

        public Vector3 pos
        {
            get
            {
                return m_Pos;
            }
        }

        public void refreshData(int _mapid,string _mapName,Vector3 _pos)
        {
            m_MapBaseId = _mapid;
            m_MapName = _mapName;
            m_Pos.x = _pos.x;
            m_Pos.y = _pos.y;
            m_Pos.z = _pos.z;
        }

    }

    /// <summary>
    /// 聊天设置
    /// </summary>
    public class ChatSettingData
    {
        private List<uint> _keys = new List<uint>(Bokura.ConstValue.kCap32);
        //频道设置
        private Dictionary<uint, bool> m_ChannelSetting = new Dictionary<uint, bool>(Bokura.ConstValue.kCap32);
        public Dictionary<uint, bool> ChannelSetting
        {
            get
            {
                return m_ChannelSetting;
            }
        }
        //语音设置
        private Dictionary<uint, bool> m_VoiceSetting = new Dictionary<uint, bool>(Bokura.ConstValue.kCap32);
        public Dictionary<uint, bool> VoiceSetting
        {
            get
            {
                return m_VoiceSetting;
            }
        }

        //其他
        private bool m_world_notifymoney = true;//世界频道收费是否提示
        public bool world_notifymoney
        {
            get
            {
                return m_world_notifymoney;
            }
            set
            {
                m_world_notifymoney = value;
            }
        }

        public void init()
        {
            AddChannelToList(swm.ChatPosType.WORLD);
            AddChannelToList(swm.ChatPosType.TEAM);
            AddChannelToList(swm.ChatPosType.RECRUIT);
            AddChannelToList(swm.ChatPosType.NEARBY);
            AddChannelToList(swm.ChatPosType.CAREER);
            AddChannelToList(swm.ChatPosType.SEPT);
            AddChannelToList(swm.ChatPosType.BATTLE);
            AddChannelToList(swm.ChatPosType.CLINET_TOTAL);
            AddChannelToList(swm.ChatPosType.CLINET_SYSTEM);
            AddChannelToList(swm.ChatPosType.CLINET_FIGHTINFO,false);

            AddVoiceToList(swm.ChatPosType.WORLD);
            AddVoiceToList(swm.ChatPosType.TEAM);
            AddVoiceToList(swm.ChatPosType.NEARBY);
            AddVoiceToList(swm.ChatPosType.CAREER);
            AddVoiceToList(swm.ChatPosType.SEPT);
            AddVoiceToList(swm.ChatPosType.BATTLE);

            m_world_notifymoney = true;
        }
        public void clear()
        {
            _keys.Clear();
            if(m_ChannelSetting != null && m_ChannelSetting.Count > 0)
            {
                _keys.AddRange(m_ChannelSetting.Keys);

                for (int i = 0; i < _keys.Count; i++)
                {
                    m_ChannelSetting[_keys[i]] = true;
                }
            }

            _keys.Clear();
            if (m_VoiceSetting != null && m_VoiceSetting.Count > 0)
            {
                _keys.AddRange(m_VoiceSetting.Keys);
                for (int i = 0; i < _keys.Count; i++)
                {
                    m_VoiceSetting[_keys[i]] = true;
                }
            }


            m_world_notifymoney = true;//世界频道收费是否提示
        }

        public void SetChannelDataByPos(swm.ChatPosType _chatPosType,bool _value)
        {
            uint _key = (uint)_chatPosType;
            if (m_ChannelSetting.ContainsKey(_key))
            {
                m_ChannelSetting[_key] = _value;
            }
        }

        private void AddChannelToList(swm.ChatPosType _chatPosType,bool _bSetting = true)
        {
            uint _key = (uint)_chatPosType;
            if(!m_ChannelSetting.ContainsKey(_key))
            {
                m_ChannelSetting[_key] = _bSetting;
            }
        }

        public void SetVoiceDataByPos(swm.ChatPosType _chatPosType, bool _value)
        {
            uint _key = (uint)_chatPosType;
            if (m_VoiceSetting.ContainsKey(_key))
            {
                m_VoiceSetting[_key] = _value;
            }
        }

        private void AddVoiceToList(swm.ChatPosType _chatPosType, bool _bSetting = true)
        {
            uint _key = (uint)_chatPosType;
            if (!m_VoiceSetting.ContainsKey(_key))
            {
                m_VoiceSetting[_key] = _bSetting;
            }
        }

        /// <summary>
        /// 检查频道设置
        /// </summary>
        /// <param name="_chatPosType"></param>
        /// <returns></returns>
        public bool CheckChannelSettingByChatPos(swm.ChatPosType _chatPosType)
        {
            bool b;
            if(!m_ChannelSetting.TryGetValue((uint)_chatPosType,out b))
            {
                b = true;
            }
            return b;
        }

        /// <summary>
        /// 检查语音设置
        /// </summary>
        /// <param name="_chatPosType"></param>
        /// <returns></returns>
        public bool CheckVoiceSettingByChatPos(swm.ChatPosType _chatPosType)
        {
            bool b;
            if (!m_VoiceSetting.TryGetValue((uint)_chatPosType, out b))
            {
                b = true;
            }
            return b;
        }
    }



    //频道数据管理
    public class ChannelData
    {
        private swm.ChatPosType m_chatChannelType = swm.ChatPosType.UNKNOWN;//聊天频道类型
        private List<ChatData> m_chatDataList = new List<ChatData>();
        private int m_maxChatData = ChatModel.MaxChannelChatData;

        private Dictionary<ulong, ChannelData> m_PrivateChannelList;//私聊频道列表  私聊频道使用频道递归 其他频道用不到这个列表
        private bool m_bIsGetHistoryData = false;
        private ulong m_PrivateChannelId = 0;
        private ulong m_UnReadMessageNumber = 0;//未读消息数量
        private bool m_bIsNeedStoreUnReadMessage = true;

        public bool IsNeedStoreUnReadMessage
        {
            get
            {
                return m_bIsNeedStoreUnReadMessage;
            }
            set
            {
                m_bIsNeedStoreUnReadMessage = value;
            }
        }
        public ulong UnReadMessageNumber
        {
            get
            {
                return m_UnReadMessageNumber;
            }
            set
            {
                m_UnReadMessageNumber = value;
            }
        }

        public ulong PrivateChannelId
        {
            get
            {
                return m_PrivateChannelId;
            }
            set
            {
                m_PrivateChannelId = value;
            }
        }
        public bool IsGetHistoryData
        {
            set
            {
                m_bIsGetHistoryData = value;
            }
            get
            {
                return m_bIsGetHistoryData;
            }
        }
        public int MaxChatData
        {
            set
            {
                m_maxChatData = value;
            }
            get
            {
                return m_maxChatData;
            }
        }
        public swm.ChatPosType ChatChannelType
        {
            set
            {
                m_chatChannelType = value;
                if(m_chatChannelType == swm.ChatPosType.PRIVATE)
                {
                    m_PrivateChannelList = new Dictionary<ulong, ChannelData>();
                }
            }
            get
            {
                return m_chatChannelType;
            }
        }

        public List<ChatData> ChatDataList
        {
            get
            {
                return m_chatDataList;
            }
        }
        //私聊频道使用
        public ChannelData GetPrivateChannelDataById(ulong _id)
        {
            ChannelData _channelData = null;
            if(!m_PrivateChannelList.TryGetValue(_id,out _channelData))
            {
                _channelData = new ChannelData();
                _channelData.ChatChannelType = ChatChannelType;
                _channelData.m_PrivateChannelId = _id;
                m_PrivateChannelList[_id] = _channelData;
            }
            return _channelData;
        }
        /// <summary>
        /// 检查是否有未读信息
        /// </summary>
        /// <returns></returns>
        public bool CheckIsHasUnReadMessager()
        {
            bool _b = false;
            if(m_chatChannelType == swm.ChatPosType.PRIVATE)
            {
                foreach(var _data in m_PrivateChannelList)
                {
                    if(_data.Value.UnReadMessageNumber > 0)
                    {
                        _b = true;
                        break;
                    }
                }
            }
            return _b;
        }
        /// <summary>
        /// 获取未读消息数量
        /// </summary>
        /// <returns></returns>
        public int GetUnReadMessager()
        {
            int _num = 0;
            if (m_chatChannelType == swm.ChatPosType.PRIVATE)
            {
                foreach (var _data in m_PrivateChannelList)
                {
                    if (_data.Value.UnReadMessageNumber > 0)
                    {
                        _num++;
                    }
                }
            }
            return _num;
        }
        //

        public void Clear()
        {
            UnReadMessageNumber = 0;
            if (null != m_PrivateChannelList)
            {
                m_PrivateChannelList.Clear();
            }
            m_chatDataList.Clear();
        }
        /// <summary>
        /// 删除所有聊天数据
        /// </summary>
        /// <param name="_bIsSend"></param>
        public void RemoveAllChatData(bool _bIsSend = false)
        {
            for(int i =0;i< m_chatDataList.Count;i++)
            {
                ChatData _RemoveData = m_chatDataList[i];
                ChatModel.Instance.RemoveChataData(_RemoveData, _bIsSend);
            }
            Clear();
        }
        /// <summary>
        /// 添加一个聊天数据
        /// </summary>
        /// <param name="_clientId"></param>
        /// <param name="_msg"></param>
        /// <param name="_insertIndex"></param>
        /// <returns></returns>
        public ChatData AddChatData(ulong _clientId, swm.ChatMsgT _msg,int _insertIndex = -1)
        {
            ChatData _data = ChatData.Get(); //new ChatData();
            _data.ClientId = _clientId;
            _data.ChannelType = (int)m_chatChannelType;
            _data.Parse(_msg);
            if(_insertIndex != -1)
            {
                m_chatDataList.Insert(_insertIndex,_data);
            }
            else
            {
                if(m_chatDataList.Count>0)
                {
                    ChatData _lastChatData = m_chatDataList[m_chatDataList.Count - 1];
                    _data.PreCreateTime = _lastChatData.CreateTime;
                }
                m_chatDataList.Add(_data);
            }

            if(IsNeedStoreUnReadMessage && m_chatChannelType == swm.ChatPosType.PRIVATE && _insertIndex == -1)//_insertIndex != -1 表示不是插入的历史
            {
                ChatModel.Instance.SetUnReadMessageNumber(m_UnReadMessageNumber + 1, m_PrivateChannelId);
            }
            
            if (m_chatDataList.Count > m_maxChatData)
            {
                ChatData _RemoveData = m_chatDataList[0];
                m_chatDataList.RemoveAt(0);
                ChatModel.Instance.RemoveChataData(_RemoveData);
                _RemoveData.Release();
            }
            return _data;
        }

        /// <summary>
        /// 重新 全部计算前一个时间
        /// </summary>
        public void ReCalcPreCreateTime()
        {
            if(m_chatDataList.Count>=2)
            {
                ulong _preTime = m_chatDataList[0].CreateTime;
                for (int i = 1;i< m_chatDataList.Count;i++)
                {
                    m_chatDataList[i].PreCreateTime = _preTime;
                    _preTime = m_chatDataList[i].CreateTime;
                }
            } 
        }

        /// <summary>
        /// 根据时间 获得插入位置
        /// </summary>
        /// <param name="_createTime"></param>
        /// <param name="_index"></param>
        /// <returns></returns>
        public bool GetChatDataByCreateTime(ulong _createTime,out int _index)
        {
            bool _bIsHas = false;
            _index = 0;
            if (m_chatDataList.Count > 0)
            {
                for (int i = 0; i < m_chatDataList.Count; i++)
                {
                    ChatData _d = m_chatDataList[i];
                    if (_d.CreateTime == _createTime)
                    {
                        _bIsHas = true;
                    }
                    else if( _createTime > _d.CreateTime)
                    {
                        _index = i+1;
                    }
                }
            }
            return _bIsHas;
        }
        /// <summary>
        /// 根据客户端id 得到聊天数据
        /// </summary>
        /// <param name="_ClientId"></param>
        /// <returns></returns>
        public ChatData GetChatDataByClientId( ulong _ClientId )
        {
            ChatData _data = null;
            if( m_chatDataList.Count > 0 )
            {
               
                 for (int i = 0; i < m_chatDataList.Count; i++)
                 {
                    ChatData _d = m_chatDataList[i];
                    if( _d.ClientId == _ClientId)
                    {
                        _data = _d;
                        break;
                    }
                }
            }
            return _data;
        }

        /// <summary>
        /// 通过id 获得最近的一次聊天数据
        /// </summary>
        /// <param name="_playerId"></param>
        /// <returns></returns>
        public ChatData GetRecentlyChatDataById(ulong _playerId = 0)
        {
            ChatData _data = null;

            if (m_chatDataList.Count > 0)
            {
                for (int i = m_chatDataList.Count - 1; i >= 0; i--)
                {
                    ChatData _d = m_chatDataList[i];
                    if (_d.SenderId == _playerId)
                    {
                        _data = _d;
                        break;
                    }
                }
            }
            return _data;
        }
    }
}
