using System;
using System.Collections.Generic;
using System.Text;
using Bokura;

namespace Bokura
{
    public enum E_CHATSTYLE
    {
        CHATSTYLE_UNKNOW = 0,
        CHATSTYLE_NORMALTALK = 1,//文本普通聊天的样式
        CHATSTYLE_SYSTEMTALK = 2,//系统的样式
        CHATSTYLE_MONSTERTALK = 3,//怪物说话
    }

    //聊天数据
    public class ChatData
    {
        private static ObjectPool<ChatData> s_pool = new ObjectPool<ChatData>();

        private ulong m_clientId;
        private int m_channelType;//聊天频道
        private ulong m_createTime = 0;//消息创建的时间
        private ulong m_preCreateTime = 0;//上一条消息创建的时间

        private string m_content;//内容 原始数据
        private ulong m_senderId;//发送者的id
        private ulong m_receiveId;//接受者id
        private string m_data= string.Empty;//富文本额外数据
        private string m_linkContent= string.Empty;//带富文本的内容

        private uint m_baseiId = 0;//npc 等可能需要这个id 玩家不需要 也不填写这个值
        private string m_name = string.Empty;//名字 可以预存 如果没有再用其他方法
        private uint m_neartalk_cdtime = 0;//附近聊天气泡持续时间（毫秒）

        private bool m_usetalkicon = false;         // 使用气泡icon(同时不使用气泡文字)
        private string m_talkicon = string.Empty;             // 气泡icon路径

        private bool m_change_talk_img_bg = false;      // 是否改变说话气泡背景框图片
        private string m_talk_img_bg = string.Empty;    // 说话气泡背景框图片

        private E_CHATSTYLE m_ChatStyle = E_CHATSTYLE.CHATSTYLE_UNKNOW;

        private swm.EntityType m_entityType = swm.EntityType.Unknown;

        public swm.EntityType SwmEntityType
        {
            get
            {
                return m_entityType;
            }
            set
            {
                m_entityType = value;
            }
        }

        public E_CHATSTYLE ChatStyle//决定聊天显示的样式
        {
            get
            {
                return m_ChatStyle;
            }
            set
            {
                m_ChatStyle = value;
            }
        }
        public ulong  PreCreateTime
        {
            get
            {
                return m_preCreateTime;
            }
            set
            {
                m_preCreateTime = value;
            }
        }
        public ulong CreateTime
        {
            get
            {
                return m_createTime;
            }
            set
            {
                m_createTime = value;
            }
        }
        public ulong SenderId
        {
            set
            {
                m_senderId = value;
            }
            get
            {
                return m_senderId;
            }
        }
        public ulong ReceiveId
        {
            set
            {
                m_receiveId = value;
            }
            get
            {
                return m_receiveId;
            }
        }
        public string Content
        {
            set
            {
                m_content = value;
            }
            get
            {
                return m_content;
            }
        }

        public uint Neartalk_cdtime
        {
            set
            {
                m_neartalk_cdtime = value;
            }
            get
            {
                return m_neartalk_cdtime;
            }
        }

        public bool usetalkicon
        {
            get { return m_usetalkicon; }
            set { m_usetalkicon = value; }
        }

        public string talkicon
        {
            get { return m_talkicon; }
            set { m_talkicon = value; }
        }

        public bool change_talk_img_bg
        {
            get { return m_change_talk_img_bg; }
            set { m_change_talk_img_bg = value; }
        }

        public string talk_img_bg
        {
            get { return m_talk_img_bg; }
            set { m_talk_img_bg = value; }
        }
        public string linkContent
        {
            set
            {
                m_linkContent = value;
            }
            get
            {
                if(string.IsNullOrEmpty(m_linkContent))
                {
                    if(!string.IsNullOrEmpty(m_data))
                    {
                        //有额外数据 或者链接数据 例如:数据type-插入起始位置-插入结束位置-额外数据...;数据type-插入起始位置-插入结束位置-额外数据...
                        string[] dataArr = m_data.Split(';');
                        int dataArrLen = dataArr.Length;
                        int _currentEndPos = 0;
                        int ContentLen = m_content.Length;
                        for (int i =0; i< dataArrLen; i++)
                        {
                            string[] data = dataArr[i].Split('~');
                            int len = data.Length;
                            if (len > 3)
                            {
                                int dataType = 0;
                                int.TryParse(data[0], out dataType);
                                if(dataType != 0)
                                {
                                    int startPos = 0;
                                    int endPos = 0;
                                    int.TryParse(data[1], out startPos);
                                    int.TryParse(data[2], out endPos);
                                    if(startPos <= ContentLen && endPos <= ContentLen)
                                    {
                                        if (startPos > _currentEndPos)
                                        {
                                            string str = m_content.Substring(_currentEndPos, startPos - _currentEndPos);
                                            m_linkContent = Bokura.Utilities.BuildString(m_linkContent, str);
                                        }
                                        _currentEndPos = endPos;
                                        if ((InlineTextInputfield.InputContentType)dataType == InlineTextInputfield.InputContentType.EMOTION)
                                        {
                                            //表情
                                            if (len >= 4)
                                            {
                                                string exData = data[3];
                                                m_linkContent = Bokura.Utilities.BuildString(m_linkContent, exData);
                                            }
                                        }
                                        else if ((InlineTextInputfield.InputContentType)dataType == InlineTextInputfield.InputContentType.HREFLINK)
                                        {
                                            //超级链接
                                            if (len >= 5)
                                            {
                                                string str = m_content.Substring(startPos, endPos - startPos);
                                                string id0 = data[3];
                                                string id1 = data[4];
                                                string id2 = m_senderId.ToString();
                                                string id3 = string.Empty;
                                                if(len >= 6)
                                                {
                                                    id3 = data[5];
                                                }
                                                string color = string.Empty;
                                                if(len >= 7)
                                                {
                                                    color = data[6];
                                                }
                                                str = ChatModel.Instance.GetHreLinkFormatString(id0, id1, id2,id3, str, color);
                                                m_linkContent = Bokura.Utilities.BuildString(m_linkContent, str);
                                            }
                                        }
                                    }
     
                                }
                            }
                        }
                        if (ContentLen > _currentEndPos)
                        {
                            string str = m_content.Substring(_currentEndPos, ContentLen - _currentEndPos);
                            m_linkContent = Bokura.Utilities.BuildString(m_linkContent, str);
                        }

                        if (string.IsNullOrEmpty(m_linkContent))
                        {
                            m_linkContent = m_content;
                        }
                    }
                    else
                    {
                        m_linkContent = m_content;
                    }
                }
                return m_linkContent;
            }
        }

        public string Data
        {
            set
            {
                m_data = value;
            }
            get
            {
                return m_data;
            }
        }
        public int ChannelType
        {
            set
            {
                m_channelType = value;
            }
            get
            {
                return m_channelType;
            }
        }
        public ulong ClientId
        {
            set
            {
                m_clientId = value;
            }
            get
            {
                return m_clientId;
            }
        }

        public uint BaseId
        {
            get
            {
                return m_baseiId;
            }
            set
            {
                m_baseiId = value;
            }
        }
        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }
        public void Parse(swm.ChatMsgT _msg)
        {
            Content             = _msg.chat_msg;
            m_senderId          = _msg.sponsor;
            ReceiveId           = _msg.target;
            CreateTime          = _msg.time;
            Name                = _msg.sendername;
            Data                = _msg.data;
            m_neartalk_cdtime   = _msg.neartalk_cdtime;
            m_ChatStyle         = (E_CHATSTYLE)_msg.chatstyle;
 
        }
        public static ChatData Get()
        {
           return  s_pool.Get();
        }
        public void Release()
        {
            m_clientId = 0;
            m_channelType = 0;//聊天频道
            m_createTime = 0;//消息创建的时间
            m_preCreateTime = 0;//上一条消息创建的时间
            m_content = string.Empty;//内容 原始数据
            m_senderId = 0; ;//发送者的id
            m_receiveId = 0;//接受者id
            m_data = string.Empty;//富文本额外数据
            m_linkContent = string.Empty;//带富文本的内容
            m_baseiId = 0;//npc 等可能需要这个id 玩家不需要 也不填写这个值
            m_name = string.Empty;//名字 可以预存 如果没有再用其他方法
            m_neartalk_cdtime = 0;//附近聊天气泡持续时间（毫秒）
            m_usetalkicon = false;         // 使用气泡icon(同时不使用气泡文字)
            m_talkicon = string.Empty;             // 气泡icon路径
            m_change_talk_img_bg = false;      // 是否改变说话气泡背景框图片
            m_talk_img_bg = string.Empty;    // 说话气泡背景框图片
            m_ChatStyle = E_CHATSTYLE.CHATSTYLE_UNKNOW;
            m_entityType = swm.EntityType.Unknown;

            s_pool.Release(this);
        }
    }
}
