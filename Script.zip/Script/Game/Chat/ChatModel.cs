using System.Collections.Generic;
using Bokura;
using System.IO;

namespace Bokura
{

    public class ChatTotalData
    {
        public int ChannnelType;
        public int ClientId;
        public ChatTotalData( int _ChannelType,int _ClientId)
        {
            ChannnelType = _ChannelType;
            ClientId = _ClientId;
        }
    }

    /// <summary>
    /// 聊天数据模块
    /// </summary>
    public class ChatModel : ClientSingleton<ChatModel>
    {
        public static string strHrefLinkFormat = "<@{0} {1} {2} {3}><color={4}>{5}</color></@>";
        public static string strEmotionFormat = "<{0}>";
        public class AddChataEvent : GameEvent<ChatData>
        {

        }
        public class RemoveChataEvent : GameEvent<ChatData>
        {

        }

        public string GetHreLinkFormatString(string id0,string id1,string id2,string id3, string _str,string _color)
        {
            if(string.IsNullOrEmpty(_color))
            {
                _color = "#00B2FB";
            }
            return Bokura.Utilities.BuildFormatString(strHrefLinkFormat, id0,id1,id2, id3, _color,_str);
        }

        public class ChannelDataEvent : GameEvent<ChannelData>
        {

        }

        public class PrivateHistoryEvent : GameEvent<ulong>
        {

        }

        public class UnReadMessageEvent :GameEvent<ulong,ulong,ChannelData>
        {

        }

        private ChatSettingData m_CurrentPlayerChatSettingData = new ChatSettingData();//聊天设置
        private MemoryStream m_writeStream = new MemoryStream(3 * 1024);
        private BinaryWriter m_binaryWrite;

        public static int MaxChannelChatData = 100;//频道最多保存数据 默认100

        private ulong m_chatDataClientId = 1;//客户端自己的id
        private Dictionary<int, ChannelData> m_chatChannelData = new Dictionary<int, ChannelData>(Bokura.ConstValue.kCap32);//频道列表
        private List<ChatData> m_totalDataIndexStore = new List<ChatData>(MaxChannelChatData);//全部的索引

        public GameEvent<ChatData> onAddChat = new AddChataEvent();//增加一个聊天数据
        public GameEvent<ChatData> onRemoveChat = new RemoveChataEvent();//删除一个聊天数据
        public ChannelDataEvent onRemoveAllChannelChatDataEvent = new ChannelDataEvent();//删除频道的所有数据

        public PrivateHistoryEvent onAddAllPrivateHistoryDataEvent = new PrivateHistoryEvent();//收到了私聊频道的历史数据
        public PrivateHistoryEvent onRemoveAllPrivateHistoryDataEvent = new PrivateHistoryEvent();//删除了私聊频道的历史数据
        public UnReadMessageEvent onUnReadMessageNumberChangeEvent = new UnReadMessageEvent();//未读信息数量刷新

        public GameEvent<ulong> onWorldChatMoneyChangeEvent = new GameEvent<ulong>();//世界聊天花费变更

        private swm.ChatMsgT m_tempChatMsg = new swm.ChatMsgT();
        /// <summary>
        /// 临时聊天协议数据
        /// </summary>
        public swm.ChatMsgT tempChatMsg
        {
            get { return m_tempChatMsg; }
        }

        private ulong m_WorldChatMoney = 0;//世界聊天当前花费

        private List<ChatEmotionPosition> m_ChatEmotionPositionList = new List<ChatEmotionPosition>(9);
        public List<ChatEmotionPosition> ChatEmotionPositionList
        {
            get
            {
                return m_ChatEmotionPositionList;
            }
        }

        public List<ChatData> TotalDataIndex
        {
            get
            {
                return m_totalDataIndexStore;
            }
        }

        public ChatSettingData CurrentPlayerChatSettingData
        {
            get
            {
                return m_CurrentPlayerChatSettingData;
            }
        }

        public ulong WorldChatMoney
        {
            get
            {
                return m_WorldChatMoney;
            }
        }

        [XLua.BlackList]
        public void Init()
        {
            m_binaryWrite = new BinaryWriter(m_writeStream);
            m_CurrentPlayerChatSettingData.init();
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ChatMsg>(ProcChat);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspChatHistory>(ProcRspChatHistory);

            //其他特殊处理消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.PersonalNpcMsg>(ProcPersonalNpcMsg);
            

            //注册系统逻辑事件
            NotifyModel.Instance.onSystemInfoMessageEvent.AddListener((int _type, int _id, string _content, Ts_InfoBase? _infoBase) => {
                ClientAddSimpleChatMsg(swm.ChatPosType.CLINET_SYSTEM,_content);
            });

            NotifyModel.Instance.onSeptMessageEvent.AddListener((int _type, int _id, string _content, Ts_InfoBase? _infoBase) =>
            {
                ClientAddSimpleChatMsg(swm.ChatPosType.SEPT, _content);
            });

            NotifyModel.Instance.onWorldMessageEvent.AddListener((int _type, int _id, string _content, Ts_InfoBase? _infoBase) =>
            {
                ClientAddSimpleChatMsg(swm.ChatPosType.WORLD, _content);
            });

            ClientSyncDataMgr.Instance.OnRecvServerData.AddListener(ProcessSyncChatSettingClientData);

            GameScene.Instance.onNotifyParamChange.AddListener(ProcNotifyParamChange);
        }
        /// <summary>
        /// 清除所有数据
        /// </summary>
        public void Clear()
        {
            foreach(var _data in m_chatChannelData )
            {
                _data.Value.Clear();
            }
//             m_writeStream.Dispose();
//             m_binaryWrite.Dispose();
            m_WorldChatMoney = 0;
            m_CurrentPlayerChatSettingData.clear();
            m_chatChannelData.Clear();
            m_totalDataIndexStore.Clear();
        }

        /// <summary>
        /// 获取聊天超链接枚举类型对应的值
        /// </summary>
        public int GetChatLinkType(swm.ChatLinkType _type)
        {
            return (int)(_type);
        }

        /// <summary>
        /// 设置频道 未读信息数量
        /// </summary>
        /// <param name="_num"></param>
        /// <param name="_id"></param>
        /// <param name="_bIsSend"></param>
        public void SetUnReadMessageNumber(ulong _num, ulong _id, bool _bIsSend = true)
        {
            SetUnReadMessageNumber(_num,GetChannelByType(swm.ChatPosType.PRIVATE, _id),_bIsSend);
        }
        /// <summary>
        /// 设置是否记录未读信息 
        /// </summary>
        /// <param name="_b"></param>
        /// <param name="_id"></param>
        public void SetIsNeedStoreUnReadMessage(bool _b,ulong _id)
        {
           ChannelData _channelData = GetChannelByType(swm.ChatPosType.PRIVATE, _id);
            if(null != _channelData)
            {
                _channelData.IsNeedStoreUnReadMessage = _b;
            }
        }

        /// <summary>
        /// 增加主角当前坐标
        /// </summary>
        /// <returns></returns>
        public ChatEmotionPosition AddCurrentMainCharChatEmotionPosition()
        {
            ChatEmotionPosition _data = null;
            if(m_ChatEmotionPositionList.Count >= 9)
            {
                int _index = m_ChatEmotionPositionList.Count - 1;
                _data = m_ChatEmotionPositionList[_index];
                m_ChatEmotionPositionList.RemoveAt(_index);
            }
            else
            {
                _data = new ChatEmotionPosition();
            }
            uint _currentMapId = GameScene.Instance.CurrentMapId;
            MapInfoAssets.Item _config = MapInfoTableManager.GetData((int)_currentMapId);
            _data.refreshData((int)_currentMapId, _config.name, GameScene.Instance.MainChar.Position);

            m_ChatEmotionPositionList.Insert(0, _data);

            return _data;
        }

        /// <summary>
        /// 检查聊天这边是否有未读的私聊消息
        /// </summary>
        /// <returns></returns>
        public bool CheckIsHasUnReadPrivateMessage()
        {
            ChannelData _channelData = GetChannelByType(swm.ChatPosType.PRIVATE);
            return _channelData.CheckIsHasUnReadMessager();
        }
        /// <summary>
        /// 获得 未读私有消息人的数量（就是多少人给我发来私有消息 未读的）
        /// </summary>
        /// <returns></returns>
        public int GetUnReadPrivateMessageMemberNum()
        {
            ChannelData _channelData = GetChannelByType(swm.ChatPosType.PRIVATE);
            return _channelData.GetUnReadMessager();
        }
        public void SetUnReadMessageNumber(ulong _num, ChannelData _channelData, bool _bIsSend = true)
        {
            if(null != _channelData)
            {
                {
                    _channelData.UnReadMessageNumber = _num;
                    if (_bIsSend)
                    {
                        onUnReadMessageNumberChangeEvent.Invoke(_num, _channelData.PrivateChannelId, _channelData);
                    }
                }
            }
        }

        /// <summary>
        /// 重置临时创建的聊天消息数据
        /// </summary>
        private void ClearTempChatMsg()
        {
            m_tempChatMsg.chat_msg = string.Empty;
            m_tempChatMsg.sponsor = 0;
            m_tempChatMsg.target = 0;
            m_tempChatMsg.time = 0;
            m_tempChatMsg.sendername = string.Empty;
            m_tempChatMsg.data  = string.Empty;
        }
        /// <summary>
        /// 客户端增加一个简单的数据  不经过服务器
        /// </summary>
        /// <param name="_chatPos"></param>
        /// <param name="_content"></param>
        public void ClientAddSimpleChatMsg(swm.ChatPosType _chatPos,string _content,
            E_CHATSTYLE _chatStyle = E_CHATSTYLE.CHATSTYLE_SYSTEMTALK,ulong _sponsor = 0,uint neartalk_cdtime = 10000)
        {
            ClearTempChatMsg();
            m_tempChatMsg.chat_pos = _chatPos;
            m_tempChatMsg.chat_msg = _content;
            m_tempChatMsg.chatstyle = (uint)_chatStyle;
            if(_sponsor == 0)
            {
                if(null != GameScene.Instance.MainChar)
                {
                    m_tempChatMsg.sponsor = GameScene.Instance.MainChar.ThisID;
                }
            }
            else
            {
                m_tempChatMsg.sponsor = _sponsor;
            }
            
            m_tempChatMsg.time = GameScene.Instance.GetServerTime();
            m_tempChatMsg.neartalk_cdtime = neartalk_cdtime;
            AddChatDataByMsg(m_tempChatMsg);
        }
        void AddChatDataByMsg(swm.ChatMsg _msg, bool _bIsSendMessage = true, bool _bIsAddtotalData = true, bool _bIsInsertHidtory = false)
        {
            m_recvChatMsg.FromMsg(_msg);
            AddChatDataByMsg(m_recvChatMsg, _bIsSendMessage, _bIsAddtotalData, _bIsInsertHidtory);
        }

        /// <summary>
        /// 增加一个聊天数据
        /// </summary>
        /// <param name="_msg"></param>
        /// <param name="_bIsSendMessage"></param>
        /// <param name="_bIsAddtotalData"></param>
        /// <param name="_bIsInsertHidtory"></param>
        /// <param name="talk_img_bg"></param>
        public void AddChatDataByMsg(swm.ChatMsgT _msg,bool _bIsSendMessage = true,bool _bIsAddtotalData = true, bool _bIsInsertHidtory = false,
                    string talk_img_bg = "", string talk_icon = "")
        {
            /// 检查频道设置
//             if (!m_CurrentPlayerChatSettingData.CheckChannelSettingByChatPos(_msg.chat_pos))
//             {
//                 return;//频道聊天被关闭
//             }
            
            int _ChannelType = (int)_msg.chat_pos;
            ulong _privateId = 0;
            int _insertIndex = -1;
            uint _npcBaseId = 0;
            string _name = string.Empty;
            swm.EntityType entityType = swm.EntityType.Unknown;
            if(_msg.sponsor > 0)
            {
                entityType = GameScene.GetEntityTypeById(_msg.sponsor);
            }
            BlackManData _bData = FriendModel.Instance.GetBlackManDataById(_msg.sponsor);
            if( null != _bData)
            {
                return;//在黑名单里面 就不接收 对方发来的任何消息
            }
            if (_msg.chat_pos == swm.ChatPosType.NEARBY)//附近聊天检查
            {
                //附近聊天
                
                if (entityType == swm.EntityType.Npc)//如果是npc发的附近聊天 那必须在9屏内 否则 无视
                {
                    Npc et = GameScene.Instance.GetEntityByID(_msg.sponsor) as Npc;
                    if (null == et)
                    {
                        //没有这个npc 消息无视
                        return;
                    }
                    _npcBaseId = et.BaseID;
                    _name = et.NpcConfig.Value.name;
                }
                else if(entityType == swm.EntityType.ClientNpc)
                {
                    ClientNpc et = GameScene.Instance.GetEntityByID(_msg.sponsor) as ClientNpc;
                    if (null == et)
                    {
                        //没有这个ClientNpc 消息无视
                        return;
                    }
                    _npcBaseId = et.BaseID;
                    _name = et.NpcConfig.Value.name;
                }
            }


            if (_msg.chat_pos == swm.ChatPosType.PRIVATE)//私聊检查
            {
                _bIsAddtotalData = false;
                if (_msg.sponsor != GameScene.Instance.MainChar.ThisID)
                {
                    _privateId = _msg.sponsor;
                }
                else
                {
                    _privateId = _msg.target;
                }
            }
            ChannelData _ChannelData = GetChannelByType(_ChannelType, _privateId);
            if (_bIsInsertHidtory)
            {
                //如果是插入历史记录
                if(_ChannelData.GetChatDataByCreateTime(_msg.time,out _insertIndex))
                {
                    return;
                }

            }
            ulong _ClientId = GetNewClientId();
            ChatData _data = _ChannelData.AddChatData(_ClientId, _msg, _insertIndex);
            if(null != _data)
            {
                if (talk_img_bg.Length > 0)
                {
                    _data.change_talk_img_bg = true;
                    _data.talk_img_bg = talk_img_bg;
                }
                else
                {
                    _data.change_talk_img_bg = false;
                    _data.talk_img_bg = talk_img_bg;
                }

                if (talk_icon.Length > 0)
                {
                    _data.usetalkicon = true;
                    _data.talkicon = talk_icon;

                    // 有图像的话就不显示文字
                    _data.Content = "";
                }
                else
                {
                    _data.usetalkicon = false;
                    _data.talkicon = talk_icon;
                }

                _data.SwmEntityType = entityType;
                if (_npcBaseId != 0)
                {
                    _data.BaseId = _npcBaseId;
                    _data.Name = _name;
                    _data.ChatStyle = E_CHATSTYLE.CHATSTYLE_MONSTERTALK;//npc说话的样式
                }
                
                if (_bIsAddtotalData)
                {
                    /// 检查综合频道设置
                    if (m_CurrentPlayerChatSettingData.CheckChannelSettingByChatPos(_msg.chat_pos))
                    {
                        m_totalDataIndexStore.Add(_data);
                    }
                }
                
                if(_bIsSendMessage)
                {
                    //派发增加消息
                    onAddChat.Invoke(_data);
                }
            }
        }

        /// <summary>
        /// 从全部列表里面 删除数据索引
        /// </summary>
        /// <param name="_removeData"></param>
        /// <param name="_bIsSend"></param>
        public void RemoveChataData( ChatData _removeData,bool _bIsSend = true )
        {
            if(m_totalDataIndexStore.Count>0)
            {
                m_totalDataIndexStore.Remove(_removeData);
                //                 for(int i = 0; i < m_totalDataIndexStore.Count;i++)
                //                 {
                //                     ChatTotalData _totalData = m_totalDataIndexStore[i];
                //                     if( _totalData.ChannnelType == _removeData.ChannelType && _totalData.ClientId == _removeData.ClientId)
                //                     {
                //                         m_totalDataIndexStore.RemoveAt(i);
                //                         break;
                //                     }
                //                 }
            }
            if (_bIsSend)
            {
                //派发删除消息
                onRemoveChat.Invoke(_removeData);
            }
        }

        /// <summary>
        /// 清除 类型 频道里面的所有数据
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_privateId"></param>
        public void RemoveChannelAllChatData(swm.ChatPosType _type, ulong _privateId = 0)
        {
            ChannelData _channel = GetChannelByType(_type, _privateId);
            if(null != _channel)
            {
                _channel.RemoveAllChatData();
                onRemoveAllChannelChatDataEvent.Invoke(_channel);
                if(_type == swm.ChatPosType.PRIVATE)
                {
                    onRemoveAllPrivateHistoryDataEvent.Invoke(_privateId);
                }
            }
        }

        /// <summary>
        /// 通过类型获得频道
        /// </summary>
        /// <param name="_type">频道类型</param>
        /// <returns></returns>
        /// 
        public ChannelData GetChannelByType(swm.ChatPosType _type, ulong _privateId = 0)
        {
            return GetChannelByType((int)_type, _privateId);
        }
        public ChannelData GetChannelByType( int _type,ulong _privateId = 0 )
        {
            ChannelData _ChannelData = null;
            if (!m_chatChannelData.TryGetValue(_type, out _ChannelData))
            {
                _ChannelData = new ChannelData();
                _ChannelData.ChatChannelType = (swm.ChatPosType)_type;
                m_chatChannelData[_type] = _ChannelData;
            }
            if(_ChannelData.ChatChannelType == swm.ChatPosType.PRIVATE && _privateId != 0)
            {
                _ChannelData = _ChannelData.GetPrivateChannelDataById(_privateId);
            }
            return _ChannelData;
        }
        /// <summary>
        /// 通过 类型 id 获得 聊天数据列表
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_privateId"></param>
        /// <returns></returns>
        public List<ChatData> GetChatDataListByChannelType(int _type,ulong _privateId = 0)
        {
            List<ChatData> _data = null;
            if((swm.ChatPosType)_type == swm.ChatPosType.CLINET_TOTAL)
            {
                _data = m_totalDataIndexStore;
            }
            else
            {
                ChannelData _ChannelData = GetChannelByType(_type, _privateId);
                if (_ChannelData != null)
                {
                    _data = _ChannelData.ChatDataList;
                }
            }
            return _data;
        }
        public List<ChatData> GetChatDataListByChannelType(swm.ChatPosType _type,ulong _privateId = 0)
        {
            return GetChatDataListByChannelType((int)_type, _privateId);
        }

        /// <summary>
        /// 通过频道和ClientId获得聊天数据
        /// </summary>
        /// <param name="_channelType">频道类型</param>
        /// <param name="_clientId">频道客户端id</param>
        /// <returns></returns>
        public ChatData GetChatDataByChannelAndClientId(int _channelType, ulong _clientId, ulong _privateId = 0)
        {
            ChatData _data = null;
            ChannelData _ChannelData = GetChannelByType(_channelType, _privateId);
            if (null != _ChannelData)
            {
                _data = _ChannelData.GetChatDataByClientId(_clientId);
            }
            return _data;
        }

        /// <summary>
        /// 获得自己在这个频道的 最近一次发言数据
        /// </summary>
        /// <param name="_type"></param>
        /// <returns></returns>
        public ChatData GetOwnRecentlyChannelChatData(swm.ChatPosType _type, ulong _privateId = 0)
        {
            ChatData _data = null;
            ChannelData _ChannelData = GetChannelByType(_type, _privateId);
            if (null != _ChannelData)
            {
                _data = _ChannelData.GetRecentlyChatDataById(GameScene.Instance.MainChar.ThisID);
            }
            return _data;
        }
       
        /// <summary>
        /// 获得 客户端的自定义id
        /// </summary>
        /// <returns></returns>
        public ulong GetNewClientId()
        {
//             if (m_chatDataClientId > 900000000)
//             {
//                 m_chatDataClientId = 1;
//             }
            return ++m_chatDataClientId;
        }

        //网络
        /// <summary>
        /// 发送聊天
        /// </summary>
        /// <param name="_channelType">频道</param>
        /// <param name="_content">内容</param>
        /// <param name="_receivePlayerId">私聊的对方id</param>
        public void SendChat(int _channelType,string _content,string _data,ulong _receivePlayerId=0,E_CHATSTYLE _chatStyle = E_CHATSTYLE.CHATSTYLE_NORMALTALK)
        {
            SendChat((swm.ChatPosType)_channelType, _content, _data, _receivePlayerId);
        }
        swm.ChatMsgT m_sendChatMsg = new swm.ChatMsgT();
        public void SendChat(swm.ChatPosType _channelType, string _content, string _data, ulong _receivePlayerId = 0, E_CHATSTYLE _chatStyle = E_CHATSTYLE.CHATSTYLE_NORMALTALK)
        {
            if(null == _data)
            {
                _data = string.Empty;
            }
 
            //x2m.ChatMsg msg = new x2m.ChatMsg();
            m_sendChatMsg.sponsor = GameScene.Instance.MainChar.ThisID;//UserDataMgr.Instance.MainUserData.Value.data.Value.entity_id;
            m_sendChatMsg.chat_pos = _channelType;
            m_sendChatMsg.chat_msg = _content;
            m_sendChatMsg.data = _data;
            m_sendChatMsg.chatstyle = (uint)_chatStyle;
            m_sendChatMsg.time = GameScene.Instance.GetServerTime();
            m_sendChatMsg.sendername = GameScene.Instance.MainChar.Name;//UserDataMgr.Instance.MainUserData.Value.data.Value.name;
            if (_channelType == swm.ChatPosType.PRIVATE)
            {
                m_sendChatMsg.target = _receivePlayerId;
            }
            //var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            //fbb.Finish(m_sendChatMsg.ToMsg(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(m_sendChatMsg);
            //MsgDispatcher.instance.SendPackage(msg);
        }

        /// <summary>
        /// 请求 私聊频道的聊天历史记录
        /// </summary>
        /// <param name="_channelType"></param>
        /// <param name="_receivePlayerId"></param>
        public void SendReqChatHistory( ulong _receivePlayerId)
        {
            //如果请求过聊天历史记录 就不会重复请求
            ChannelData _channelData = GetChannelByType(swm.ChatPosType.PRIVATE, _receivePlayerId);
            if(!_channelData.IsGetHistoryData)
            {
                _channelData.IsGetHistoryData = true;
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqChatHistory.StartReqChatHistory(fbb);
                swm.ReqChatHistory.AddUserid(fbb, _receivePlayerId);
                fbb.Finish(swm.ReqChatHistory.EndReqChatHistory(fbb).Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqChatHistory.HashID, fbb);

                //x2m.ReqChatHistory msg = new x2m.ReqChatHistory();
                //msg.userid = _receivePlayerId;
                //MsgDispatcher.instance.SendPackage(msg);
            }
        }

        /// <summary>
        /// 发送 请求删除私聊记录
        /// </summary>
        /// <param name="_receivePlayerId"></param>
        public void SendReqClearChatHistory(ulong _receivePlayerId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqClearChatHistory.StartReqClearChatHistory(fbb);
            swm.ReqClearChatHistory.AddUserid(fbb,_receivePlayerId);
            fbb.Finish(swm.ReqClearChatHistory.EndReqClearChatHistory(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqClearChatHistory.HashID, fbb);
            //x2m.ReqClearChatHistory msg = new x2m.ReqClearChatHistory();
            //msg.userid = _receivePlayerId;
            //MsgDispatcher.instance.SendPackage(msg);
            RemoveChannelAllChatData(swm.ChatPosType.PRIVATE, _receivePlayerId);
        }
        /// <summary>
        /// 发送 设置记录已读
        /// </summary>
        /// <param name="_id"></param>
        public void SendReqSetChatHistoryRead(ulong _id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSetChatHistoryRead.StartReqSetChatHistoryRead(fbb);
            swm.ReqSetChatHistoryRead.AddUserid(fbb,_id);
            fbb.Finish(swm.ReqSetChatHistoryRead.EndReqSetChatHistoryRead(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSetChatHistoryRead.HashID, fbb);
            //x2m.ReqSetChatHistoryRead msg = new x2m.ReqSetChatHistoryRead();
            //msg.userid = _id;
            //MsgDispatcher.instance.SendPackage(msg);
            SetUnReadMessageNumber(0, _id);
        }

        /// <summary>
        /// 接收到聊天消息
        /// </summary>
        swm.ChatMsgT m_recvChatMsg = new swm.ChatMsgT();
        private void ProcChat(swm.ChatMsg _msg)
        {
            m_recvChatMsg.FromMsg(_msg);
            AddChatDataByMsg(m_recvChatMsg);
        }

        /// <summary>
        /// 接收 获取私聊聊天记录
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspChatHistory(swm.RspChatHistory _msg)
        {
            if( _msg.recordsLength > 0)
            {
                for (int i = 0; i < _msg.recordsLength; i++)
                {
                   AddChatDataByMsg(_msg.records(i).Value, false, false, true);
                }
                ChannelData _ChannelData = GetChannelByType(swm.ChatPosType.PRIVATE, _msg.userid);
                if(null != _ChannelData)
                {
                    _ChannelData.ReCalcPreCreateTime();
                }
                onAddAllPrivateHistoryDataEvent.Invoke(_msg.userid);
            }

        }

        // npc头顶冒泡信息（个人） 特殊处理
        private void ProcPersonalNpcMsg(swm.PersonalNpcMsg _msg)
        {
            Entity _npc = GameScene.Instance.GetNpcEntityByBaseId(_msg.baseid, true, true);
            if(null != _npc)
            {
                ClientAddSimpleChatMsg(swm.ChatPosType.NEARBY, _msg.chat_msg,
                    E_CHATSTYLE.CHATSTYLE_MONSTERTALK, _npc.ThisID,(uint)_msg.time);
            }
        }

        /// <summary>
        /// 接收 设置
        /// </summary>
        /// <param name="t"></param>
        /// <param name="data"></param>
        private void ProcessSyncChatSettingClientData(ClientSyncDataType t, byte[] data)
        {
            if (t == ClientSyncDataType.ChatSettingData)
            {
                if (null != data )
                {
                    MemoryStream ms = new MemoryStream(data);
                    BinaryReader br = new BinaryReader(ms);
                    int _channelCount = br.ReadInt32();
                    for(int i =0; i < _channelCount;i++)
                    {
                        uint _key = br.ReadUInt32();
                        bool _value = br.ReadBoolean();
                        m_CurrentPlayerChatSettingData.SetChannelDataByPos((swm.ChatPosType)_key, _value);

                    }
                    int _voiceCount = br.ReadInt32();
                    for (int i = 0; i < _voiceCount; i++)
                    {
                        uint _key = br.ReadUInt32();
                        bool _value = br.ReadBoolean();
                        m_CurrentPlayerChatSettingData.SetVoiceDataByPos((swm.ChatPosType)_key, _value);

                    }
                    m_CurrentPlayerChatSettingData.world_notifymoney = br.ReadBoolean();
                    ms.Dispose();
                    br.Dispose();
                }
            }
        }

        /// <summary>
        /// 世界聊天花费变更
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_value"></param>
        private void ProcNotifyParamChange(swm.NotifyType _type, ulong _value)
        {
            if(_type == swm.NotifyType.WorldChatCost)
            {
                m_WorldChatMoney = _value;
                onWorldChatMoneyChangeEvent.Invoke(m_WorldChatMoney);
            }
        }

        //客户端消息
        public void SaveChatSetting()
        {
            m_writeStream.SetLength(0);
            m_writeStream.Position = 0;
            m_binaryWrite.Write(m_CurrentPlayerChatSettingData.ChannelSetting.Count);
            foreach (var kv in m_CurrentPlayerChatSettingData.ChannelSetting)
            {
                m_binaryWrite.Write(kv.Key);
                m_binaryWrite.Write(kv.Value);
            }
            m_binaryWrite.Write(m_CurrentPlayerChatSettingData.VoiceSetting.Count);
            foreach (var kv in m_CurrentPlayerChatSettingData.VoiceSetting)
            {
                m_binaryWrite.Write(kv.Key);
                m_binaryWrite.Write(kv.Value);
            }

            m_binaryWrite.Write(m_CurrentPlayerChatSettingData.world_notifymoney);

            ClientSyncDataMgr.Instance.SetData(ClientSyncDataType.ChatSettingData, m_writeStream.GetBuffer(), 0, (int)m_writeStream.Position);
            ClientSyncDataMgr.Instance.SaveData();
        }
    }
}
