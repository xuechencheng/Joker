using Bokura;
using System.Collections.Generic;

namespace Bokura
{
    public class ClientSingleton<T> : ISingletonInterface where T : new()
	{
        static protected T m_instance;
        public static T Instance
        {
            get { return m_instance; }
        }



        /// <summary>
        /// 注册单例
        /// </summary>
        [XLua.BlackList]
        public static void Register()
		{
			if(m_instance == null)
				m_instance = ClientSingletonManager.Instance.CreateSingleton<T>();
		}
	}



    class ClientSingletonManager : ISingletonManager<ClientSingletonManager>
    {
        List<ISingletonInterface> m_singletonList = new List<ISingletonInterface>(15);


        /// <summary>
        /// create a singleton
        /// </summary>
        public T CreateSingleton<T>() where T : new()
        {
            T singleton = new T();
            m_singletonList.Add(singleton as ISingletonInterface);
            return singleton;
        }

        /// <summary>
        /// register all client logic singleton
        /// </summary>
        public void RegisterSingleton()
        {
            GameScene.Register();


			UICurveMgr.Register();
			AnnouncementManager.Register();
			ServersManager.Register();
			RoleCreationManager.Register();
			RoleSelectionManager.Register();
            MakeupOutGameManager.Register();
			AutoPathFinder.Register();
			AutoAttackManager.Register();
			SociatyManager.Register();
			BattleFieldManager.Register();
			RandomNameManager.Register();
			SceneSpawnManager.Register();
            RankListManager.Register();
            ThreeDPreviewManager.Register();
            InlineSpriteManager.Register();
            AvatarShowManager.Register();
            ArenaManager.Register();
            SensitiveWordManager.Register();
            DailyActivityManager.Register();
            MapManager.Register();
            MiniMapManager.Register();
            UI_AreaTigger.Register();
            ScreenNarratorManager.Register();

            RedDotModel.Register();
            MiniGameModel.Register();

            WaterMoveManager.Register();
            WeatherManager.Register();
            AltarManager.Register();
            WeatherCloudManager.Register();
            StrongholdsManager.Register();
            IdentityManager.Register();
            FeatureArticleManager.Register();
            YuhengManager.Register();
            FormulaManager.Register();
            InvestCrusadeManager.Register();


            AirWallManager.Register();

            SysSettingModel.Register();

            BuffFactory.Register();
            BuffModel.Register();
            EffectFactory.Register();
            GameCopyModel.Register();
            TableManager.Register();
            TriggerManager.Register();
            UIAnimationManager.Register();
            UIManager.Register();
            ActionEffectManager.Register();
            QingKungTouchPointManager.Register();
            InteractionPointManager.Register();
            NpcModelBindCommonDataManager.Register();
            ItemFactory.Register();
            ChatModel.Register();
            NotifyModel.Register();
			SkillManager.Register();
            SkillShowManager.Register();
            EffectMgr.Register();
            BagManager.Register();
            MissionModel.Register();
            
            MailModel.Register();
            MailFactory.Register();
            MailManager.Register();
			TeamModel.Register();
            TitleModel.Register();
            GeneralMessageModel.Register();

            TeamDropModel.Register();
			UISkillAttacker.Register();
            FriendModel.Register();
            PlayerInfoModel.Register();
			ShopModel.Register();

           // ManorModel.Register();

            FashionModel.Register();

			MountMgr.Register();

			EntityEffectTextManager.Register();
            LifeSkillModel.Register();

            DramaManager.Register();

			PKManager.Register();

            UserScriptModel.Register();

            StarMgr.Register();

            AchievementModel.Register();
            ClientSyncDataMgr.Register();
            GuideMgr.Register();

            ActionEmojiManager.Register();
            DeliveryManager.Register();
            FunctionNoticeManager.Register();
            CarryStageManager.Register();
            FieldEventManager.Register();

            CollectionManager.Register();
            BuildCityManager.Register();
            BattleLog.Register();
            ClientNpcEntityManager.Register();
            PhotoManager.Register();
            AuctionManager.Register();
            EquipManager.Register();
            MobileBlockMgr.Register();
            NpcShowManager.Register();
            TierTrainMgr.Register();
            GMCommandManager.Register();

            //qi peng
            ExamMgr.Register();
            InvisibleShaderConfigMgr.Register();
            CDManager.Register();

            //Chen Jize
            CRNPCMgr.Register();
            TreasureMapMgr.Register();
            XiandaoExpModel.Register();

            HomeModel.Register();
            HomeWorkerModel.Register();
            HomeFieldModel.Register();

            HomeBuildingMgr.Register();
            HomeBuildingViewer.Register();
            AITaskMgr.Register();
            HomePlantBuildingMgr.Register();

            ClientInteractionPointMgr.Register();
        }

    }
}