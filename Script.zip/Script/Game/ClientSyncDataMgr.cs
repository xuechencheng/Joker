using System;
using System.Collections.Generic;
using System.IO;

using Bokura;
namespace Bokura
{
    public enum ClientSyncDataType
    {
        SettingData,
        GuideData,
        TimelineData,
        ChatSettingData,
        Count,
    }



    /// <summary>
    /// 管理需要在服务器保存的零散数据
    /// </summary>
    public class ClientSyncDataMgr : ClientSingleton<ClientSyncDataMgr>
    {
        List<ArraySegment<byte>> m_chunkDatas = new List<ArraySegment<byte>>((int)ClientSyncDataType.Count);

        VMemoryStream m_memstream = new VMemoryStream();
        BinaryReader m_binReader;// = new BinaryReader()

        VMemoryStream m_writeStream = new VMemoryStream(16*1024,0);
        BinaryWriter m_binWriter;



        public Event<ClientSyncDataType, byte[]> OnRecvServerData = new Event<ClientSyncDataType, byte[]>();



        public ClientSyncDataMgr()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SyncUserClientData>(ProcSyncUserClientData);
            for(int tIdx = 0, tCount = (int)ClientSyncDataType.Count; tIdx < tCount; tIdx ++)
                m_chunkDatas.Add(new ArraySegment<byte>());

            UserDataMgr.Instance.onUserDataSync.AddListener(OnSyncUserData);
        }

        void OnSyncUserData()
        {
            //客户端自定义数据 请求
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqUserClientData.StartReqUserClientData(fbb);
            fbb.Finish(swm.ReqUserAllBagData.EndReqUserAllBagData(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUserClientData.HashID, fbb);
        }


        private int DataLeft
        {
            get { return (int)m_memstream.Length - (int)m_memstream.Position; }
        }



        private void ProcSyncUserClientData(swm.SyncUserClientData data)
        {
            //LogHelper.Log("receive SyncUserClientData from server - data length :", data.dataLength.ToString());
            var bytedata = data.GetDataBytes();
            if (!bytedata.HasValue)
            {
                GuideMgr.Instance.OnRecvUserData.Invoke();
                return;
            }
            var bs = bytedata.Value;
            m_memstream.Buffer = bs.Array;
            m_memstream.Origin = bs.Offset;
            m_memstream.SetLength(bs.Count);
            m_memstream.Position = 0;
            if (m_binReader==null)
                m_binReader = new BinaryReader(m_memstream);

            while (DataLeft > 3)
            {
                var chunkid = m_binReader.ReadByte();
                var chunksize = m_binReader.ReadUInt16();
                if (chunksize > DataLeft)
                    break;
                var chunkdata = new byte[chunksize];
                m_binReader.Read(chunkdata, 0, chunksize);
                if(chunkid<(int)ClientSyncDataType.Count)
                {
                    m_chunkDatas[chunkid] = new ArraySegment<byte>(chunkdata);
                }
            }

            for(int tIdx = 0, tCount = m_chunkDatas.Count; tIdx < tCount; tIdx ++)
            {
                if( m_chunkDatas[tIdx].Array != null)
                    OnRecvServerData.Invoke((ClientSyncDataType)tIdx, m_chunkDatas[tIdx].Array);
            }
        }



        public void SetData(ClientSyncDataType dt, byte[] data)
        {
            m_chunkDatas[(int)dt] =  new ArraySegment<byte>(data);
        }



        public void SetData(ClientSyncDataType dt, byte[] data, int offset, int len)
        {
            m_chunkDatas[(int)dt] = new ArraySegment<byte>(data,offset,len);
        }



        public void SaveData()
        {
            m_writeStream.Position = 0;
            if (m_binWriter == null)
                m_binWriter = new BinaryWriter(m_writeStream);
            if(m_chunkDatas.Count > 255)
            {
                throw new Exception("ClientSyncData over flow!");
            }
            for (int i = 0; i < m_chunkDatas.Count; i ++)
            {
                var chunkdata = m_chunkDatas[i];
                if ( chunkdata.Count == 0)
                    continue;

                int next = (int)m_writeStream.Position + 3 + chunkdata.Count;
                if(next>m_writeStream.Capacity)
                {
                    throw new Exception("ClientSyncData over flow!");
                }

                m_binWriter.Write((byte)i);
                m_binWriter.Write((ushort)chunkdata.Count);
                m_binWriter.Write(chunkdata.Array, chunkdata.Offset, chunkdata.Count);
            }

            var data = m_writeStream.Buffer;
            int datalen = (int)m_writeStream.Position;

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            fbb.StartVector(1, datalen, 1);
            for (int i = datalen - 1; i >= 0; i--) fbb.AddByte(data[i]);
            var datav = fbb.EndVector();

            swm.SyncUserClientData.StartSyncUserClientData(fbb);
            swm.SyncUserClientData.AddData(fbb, datav);
            var msg = swm.SyncUserClientData.EndSyncUserClientData(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.SyncUserClientData.HashID, fbb);
        }
    }
}