namespace Bokura
{
    public class CollectionData
    {
        public uint collectid;
        public uint lastusetime;
        public uint usedNum;

        public bool hasRedDot;
        public bool hasFinished;
        public ulong getTime;

        public CollectionsTableBase cfg;

        [XLua.BlackList]
        public void Clear()
        {
            lastusetime = 0;
            usedNum = 0;

            hasRedDot = false;
            hasFinished = false;
        }
    }

//     public class CollectionGroupData
//     {
//         public uint groupid;
// 
//         public bool hasRedDot;
//         public bool hasFinished;
//         public int count;
// 
//         public CollectionGroupTableBase cfg;
// 
//         public void CheckFinished()
//         {
//             count = 0;
//             int collectLen = cfg.collect_listLength;
//             bool ret = true;
//             bool hasred = false;
//             for (int i = 0; i < collectLen; i++)
//             {
//                 int collectId = cfg.collect_list(i);
//                 var collectionData = CollectionManager.Instance.GetCollectionData((uint)collectId);
//                 if (collectionData.hasFinished == false)
//                     ret = false;
//                 else
//                     count += 1;
//                 if (collectionData.hasRedDot)
//                     hasred = true;
//             }
// 
//             hasRedDot = hasred;
//             hasFinished = ret;
//         }
// 
//         [XLua.BlackList]
//         public void Clear()
//         {
//             hasRedDot = false;
//             hasFinished = false;
//             count = 0;
//         }
//     }
}
