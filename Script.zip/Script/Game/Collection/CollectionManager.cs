using Bokura;
using System;
using System.Collections.Generic;
using FlatBuffers;
namespace Bokura
{
    public class CollectionManager : ClientSingleton<CollectionManager>
    {
        public class ProcRefreshCollectionEvent : GameEvent<CollectionData> { }

        public ProcRefreshCollectionEvent procCollectionRefreshEvent = new ProcRefreshCollectionEvent();
        public ProcRefreshCollectionEvent procCollectionCompleteEvent = new ProcRefreshCollectionEvent();

        public GameEvent<bool> procRedPoint = new GameEvent<bool>();
        public GameEvent<List<swm.PlotReview>> taskProcess = new GameEvent<List<swm.PlotReview>>();
        public GameEvent refreshUi = new GameEvent();

        private Dictionary<uint, CollectionData> m_CollectionDatas;
        Dictionary<int, Dictionary<int, List<CollectionData>>> m_CollectClassList;

        private List<string> typeList = new List<string>(ConstValue.kCap16);
        private Dictionary<string, int> idList = new Dictionary<string, int>();
        private Dictionary<int,List<string>> subTypeList = new Dictionary<int,List<string>>(ConstValue.kCap16);

        public int TotalLen
        {
            get { return CollectionTableManager.Instance.KeyToIdList.Count; }
        }


        public int FinishCount
        {
            get { return m_CollectionDatas.Count; }
        }

        public int AllGroupCount
        {
            get { return CollectionGroupTableManager.Instance.KeyToIdList.Count; }
        }

        public CollectionManager()
        {
            m_CollectionDatas = new Dictionary<uint, CollectionData>(ConstValue.kCap16);
            m_CollectClassList = new Dictionary<int, Dictionary<int, List<CollectionData>>>(ConstValue.kCap16);
        }

        public List<string> GetTypeList()
        { 
            return typeList;
        }

        public List<string> GetSubInfoList(int type)
        {
            if (subTypeList.ContainsKey(type))
                return subTypeList[type];
            return null;
        }

        public int GetIdByName(string name)
        {
            if (idList.ContainsKey(name))
                return idList[name];
            return 0;
        }

        public int GetAllSubNum(int type)
        {
            int ret = 0;
            if (m_CollectClassList.ContainsKey(type))
            {
                foreach(var item in m_CollectClassList[type].Values)
                {
                    ret += item.Count;
                }
            }

            return ret;
        }

        public int GetSubNum(int type, int subType)
        {
            int ret = 0;
            if (m_CollectClassList.ContainsKey(type))
            {
                if (m_CollectClassList[type].ContainsKey(subType))
                    ret = m_CollectClassList[type][subType].Count;
                
            }

            return ret;
        }

        public int GetExistSubNum(int type, int subType)
        {
            int ret = 0;
            if (m_CollectClassList.ContainsKey(type))
            {
                if (m_CollectClassList[type].ContainsKey(subType))
                {
                    var lst = m_CollectClassList[type][subType];
                    for (int i = 0; i < lst.Count; ++i)
                    {
                        if (lst[i].hasFinished)
                            ++ret;
                    }
                }
            }

            return ret;
        }

        public int GetAllExistSubNum(int type)
        {
            int ret = 0;
            if (m_CollectClassList.ContainsKey(type))
            {
                foreach (var item in m_CollectClassList[type].Values)
                {
                    for (int i = 0; i < item.Count; ++i)
                    {
                        if (item[i].hasFinished)
                            ++ret;
                    }
                }
            }

            return ret;
        }

        public List<CollectionData> GetCollectionData(int type, int subtype)
        {
            if (m_CollectClassList.ContainsKey(type))
            {
                if (m_CollectClassList[type].ContainsKey(subtype))
                {
                    return  m_CollectClassList[type][subtype];
                }
            }
            return null;
        }

        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAllCollections>(ProcRspAllCollections);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshCollection>(ProcRefreshCollection);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCollectionPlotReview>(ProcRspCollectionPlotReview);
            
        }
        [XLua.BlackList]
        public void Load()
        {
            foreach (var item in CollectionsTableManager.Instance.KeyToIdList)
            {
                CollectionData newItem = new CollectionData();
                int id = (int)item.Key;
                var cfg = CollectionsTableManager.GetData(id);
                newItem.cfg = cfg.Value;
                newItem.collectid = (uint)cfg.Value.id;
                m_CollectionDatas.Add((uint)cfg.Value.id, newItem);
                if (!typeList.Contains(cfg.Value.type_name))
                {
                    typeList.Add(cfg.Value.type_name);
                    idList.Add(cfg.Value.type_name, cfg.Value.type);
                }
                    

                if (subTypeList.ContainsKey(cfg.Value.type))
                {
                    if (!subTypeList[cfg.Value.type].Contains(cfg.Value.subtype_name))
                    {
                        subTypeList[cfg.Value.type].Add(cfg.Value.subtype_name);
                        idList.Add(cfg.Value.subtype_name, cfg.Value.subtype);
                    }
                        
                }
                else
                {
                    List<string> lst = new List<string>();
                    lst.Add(cfg.Value.subtype_name);
                    subTypeList.Add(cfg.Value.type, lst);
                    idList.Add(cfg.Value.subtype_name, cfg.Value.subtype);
                }

                if (m_CollectClassList.ContainsKey(cfg.Value.type))
                {
                    Dictionary<int, List<CollectionData>> lst = m_CollectClassList[cfg.Value.type];
                    if (lst.ContainsKey(cfg.Value.subtype))
                    {
                        List<CollectionData> temp = lst[cfg.Value.subtype];
                        if (!temp.Contains(newItem))
                        {
                            temp.Add(newItem);
                        }
                    }
                    else
                    {
                        List<CollectionData> temp = new List<CollectionData>(ConstValue.kCap16);
                        lst.Add(cfg.Value.subtype, temp);
                        temp.Add(newItem);
                    }
                }
                else
                {
                    Dictionary<int, List<CollectionData>> lst = new Dictionary<int, List<CollectionData>>(ConstValue.kCap16);
                    m_CollectClassList.Add(cfg.Value.type, lst);
                    List<CollectionData> temp = new List<CollectionData>(ConstValue.kCap16);
                    lst.Add(cfg.Value.subtype, temp);
                    temp.Add(newItem);
                }
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            foreach (var item in m_CollectionDatas)
                item.Value.Clear();
        }

        #region Data
        public CollectionData GetCollectionDataByID(uint collectid)
        {
            if (m_CollectionDatas.ContainsKey(collectid))
                return m_CollectionDatas[collectid];
            return null;
        }

        private void _RefreshCollectionData(swm.Collection data, bool init = true)
        {
            var collectionData = GetCollectionDataByID(data.collectid);
            if (collectionData == null)
                return;

            bool bGet = false;
            if (!collectionData.hasFinished)
            {
                bGet = true;
            }

            bool bUse = false;
            if (collectionData.lastusetime != data.lastusetime)
            {
                collectionData.lastusetime = data.lastusetime;
                bUse = true;
            }

            collectionData.getTime = data.add_stamp;            
            collectionData.hasRedDot = data.red_dots;
            collectionData.usedNum = data.used_num;
            collectionData.hasFinished = true;

            if (bGet && !init)
            {
                procCollectionCompleteEvent.Invoke(collectionData);
            }
            if (bUse && !init)
            {
                procCollectionRefreshEvent.Invoke(collectionData);
            }
            
        }
        #endregion

        public void SendReqUseCollection(uint collectid, UnityEngine.Vector3 dir, UnityEngine.Vector3 targetPos, ulong targetID)
        {

            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            swm.SpellDatas.StartSpellDatas(tFBB);

            Offset<swm.Vector3> dirOffset = swm.Vector3.CreateVector3(tFBB, dir.x, dir.y, dir.z);
            swm.SpellDatas.AddDir(tFBB, dirOffset);
            swm.SpellDatas.AddTargetid(tFBB, targetID);
            Offset<swm.Vector3> targetPosOffset = swm.Vector3.CreateVector3(tFBB, targetPos.x, targetPos.y, targetPos.z);
            swm.SpellDatas.AddTargetpos(tFBB, targetPosOffset);
            Offset<swm.SpellDatas> spellDatastOffset = swm.SpellDatas.EndSpellDatas(tFBB);
            Offset<swm.ReqUseCollection> tOffset = swm.ReqUseCollection.CreateReqUseCollection(tFBB, collectid, spellDatastOffset);
            tFBB.Finish(tOffset.Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqUseCollection.HashID, tFBB);
        }
        public void SendClickRedDot(int collectId)
        {
            var data = m_CollectionDatas[(uint)collectId];
            data.hasRedDot = false;

            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            swm.ReqClickRedDotsCollection.StartReqClickRedDotsCollection(tFBB);

            swm.ReqClickRedDotsCollection.AddCollectid(tFBB, (uint)collectId);

            tFBB.Finish(swm.ReqClickRedDotsCollection.EndReqClickRedDotsCollection(tFBB).Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqClickRedDotsCollection.HashID, tFBB);
        }

        private void ProcRspAllCollections(swm.RspAllCollections msg)
        {
            var len = msg.datasLength;
            for (int i = 0; i < len; i++ )
            {
                _RefreshCollectionData(msg.datas(i).Value);
            }

            procRedPoint.Invoke(HasRedPoint());
            refreshUi.Invoke();
        }

        private void ProcRefreshCollection(swm.RefreshCollection msg)
        {
            _RefreshCollectionData(msg.data.Value, false);

            procRedPoint.Invoke(HasRedPoint());
        }

        private void ProcRspCollectionPlotReview(swm.RspCollectionPlotReview msg)
        {
            if (msg.reviewLength == 0)
                return;

            List<swm.PlotReview> ret = new List<swm.PlotReview>();

            for (int i = 0; i < msg.reviewLength; ++i)
            {
                swm.PlotReview item = msg.review(i).Value;
                ret.Add(item);
            }

            taskProcess.Invoke(ret);

        }

        

        public void SendReqCollections()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqAllCollections.StartReqAllCollections(tFBB);
            tFBB.Finish(swm.ReqAllCollections.EndReqAllCollections(tFBB).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAllCollections.HashID, tFBB);
        }

        public void SendReqCollectionTypeInfo(uint id)
        {
            CollectionData data = GetCollectionDataByID(id);
            if (data == null || data.cfg.clinet_messageLength == 0)
                return;


            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.CollectionMessageType[] vec = new swm.CollectionMessageType[data.cfg.clinet_messageLength];
            for (int i = 0; i < data.cfg.clinet_messageLength; ++i)
            {
                vec[i] = (swm.CollectionMessageType)data.cfg.clinet_message(i);
            }
            VectorOffset typeVector = swm.ReqCollectionTypeInfo.CreateTypeVector(tFBB, vec);

            swm.ReqCollectionTypeInfo.StartReqCollectionTypeInfo(tFBB);
            swm.ReqCollectionTypeInfo.AddCollectid(tFBB, id);
            swm.ReqCollectionTypeInfo.AddType(tFBB, typeVector);
            tFBB.Finish(swm.ReqCollectionTypeInfo.EndReqCollectionTypeInfo(tFBB).Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqCollectionTypeInfo.HashID, tFBB);
        }

        public bool HasRedPoint()
        {
            foreach(var item in m_CollectionDatas)
            {
                if (item.Value.hasRedDot)
                    return true;
            }

            return false;
        }
    }
}
