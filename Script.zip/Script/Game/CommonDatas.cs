using UnityEngine;
using System.Collections.Generic;
using System.Collections;
/*
namespace Bokura
{

	
	namespace Datas
	{
       

		public class MapEntityAttrs
		{
			public uint prop_str;        // 力量 strength
			public uint prop_int;        // 智力 intelligence
			public uint prop_sta;        // 耐力 stamina
			public uint prop_dex;        // 敏捷 dexterity

			public uint pdef;            // 物防（护甲）
			public uint mdef;            // 魔防（抗性）

			public uint min_pdam;        // 物攻
			public uint max_pdam;
			public uint min_mdam;        // 魔攻
			public uint max_mdam;

			public float crit_pct;       // 暴击率   
			public float crit_effect;    // 暴击效果

            public uint prof_armforce;      // 生活属性 - 臂力
            public uint prof_technique;     // 生活属性 - 技巧
            public uint prof_inspiration;   // 生活属性 - 灵感

            public float attack_speed;      // 攻击速度
            public float cooldown_dec;      // 冷却缩减

            public void FromMsg(swm.MapEntityAttrs msg)
			{
				prop_str = msg.prop_str;
				prop_int = msg.prop_int;
				prop_sta = msg.prop_sta;
				prop_dex = msg.prop_dex;

				pdef = msg.pdef;
				mdef = msg.mdef;

				min_pdam = msg.min_pdam;
				max_pdam = msg.max_pdam;
				min_mdam = msg.min_mdam;
				max_mdam = msg.max_mdam;

				crit_pct = msg.crit_pct;
				crit_effect = msg.crit_effect;

                attack_speed = msg.attack_speed;
                cooldown_dec = msg.cooldown_dec;

                prof_armforce = msg.prof_armforce;
                prof_technique = msg.prof_technique;
                prof_inspiration = msg.prof_inspiration;
            }
		}
		public struct Buff
		{
			public uint id;        // 唯一ID
			public uint baseid;    // 基本表ID
			public uint level;     // 等级
			public ulong begintime;    // 起始时间
			public uint overtime;  // 持续时间
			public uint overlay;   // 层数

			public void FromMsg(swm.Buff msg)
			{
				id = msg.id;
				baseid = msg.baseid;
				level = msg.level;
				begintime = msg.begintime;
				overtime = msg.overtime;
				overlay = msg.overlay;
			}
		}
		public class MapUser
		{
            private swm.CareerType m_CareerType = swm.CareerType.Unknown;
			public swm.CareerType career_type
            {
                get { return m_CareerType; }
                set
                {
                    if (m_CareerType == value) return;
                    m_CareerType = value;
                    m_ProfessionConfig = ProfessionTableManager.GetData((int)m_CareerType);
                }
            }



            private ProfessionTableBase? m_ProfessionConfig;



            public string headIcon
            {
                get
                {
                    if (m_ProfessionConfig.HasValue) return m_ProfessionConfig.Value.headicon;
                    else return string.Empty;
                }
            }



			public swm.CareerSex career_sex;
			public uint weaponid;
			public bool is_show_weapon;
			public uint teamid;
			public ulong septid;
			public uint killer_value;
			public PKMode pkmode_type;
			/// <summary>
			/// 当前吟唱动作id
			/// </summary>
			public uint chant_id;
			/// <summary>
			/// 吟唱对象id
			/// </summary>
			public ulong chant_tar_uid;
			/// <summary>
			/// 吟唱开始时间
			/// </summary>
			public ulong chant_begin_time;
			/// <summary>
			/// 吟唱结束时间
			/// </summary>
			public ulong chant_end_time;
			public byte[] makeup_data;
            public uint manorbaseid;

            public MapUser Clone()
            {
                MapUser _data = new MapUser();
                _data.career_type = career_type;
                _data.career_sex = career_sex;
                _data.weaponid = weaponid;
                _data.is_show_weapon = is_show_weapon;
                _data.teamid = teamid;
                _data.septid = septid;
                _data.killer_value = killer_value;
                _data.pkmode_type = pkmode_type;
                _data.chant_id = chant_id;
                _data.chant_tar_uid = chant_tar_uid;
                _data.chant_begin_time = chant_begin_time;
                _data.chant_end_time = chant_end_time;
                _data.makeup_data = new byte[makeup_data.Length];
                for (int i = 0; i < makeup_data.Length; i++) { _data.makeup_data[i] = makeup_data[i]; }
                _data.manorbaseid = manorbaseid;
                return _data;
            }
			public void FromMsg(swm.MapUser msg)
			{
				career_type = msg.career_type;
				career_sex = msg.career_sex;
				weaponid = msg.weaponid;
				is_show_weapon = msg.is_show_weapon;
				teamid = msg.teamid;
				septid = msg.septid;
				killer_value = msg.killer_value;
				pkmode_type = (PKMode)msg.pkmode_type;
				chant_id = msg.chant_id;
				chant_tar_uid = msg.chant_tar_uid;
				chant_begin_time = msg.chant_begin_time;
				chant_end_time = msg.chant_end_time;
                makeup_data = new byte[msg.makeup_dataLength];
				for (int i = 0; i < msg.makeup_dataLength; i++) { makeup_data[i] = msg.makeup_data(i); }
                manorbaseid = msg.manorbaseid;
            }
		}

		public class MapNpc
		{
			public uint baseid ;
			public swm.CareerType career_type;
			public swm.CareerSex career_sex;
            public ulong borntime;
            public MapNpc Clone()
            {
                MapNpc _data = new MapNpc();
                _data.baseid = baseid;
                _data.career_type = career_type;
                _data.career_sex = career_sex;
                _data.borntime = borntime;
                return _data;
            }

            public MapNpc FromMsg(swm.MapNpc msg)
            {
                baseid = msg.baseid;
                borntime = msg.borntime;
                career_type = msg.career_type;
                career_sex = msg.career_sex;
                return this;
            }

            public MapNpc FromMapNpcData(MapNpc msg)
            {
                baseid = msg.baseid;
                borntime = msg.borntime;
                career_type = msg.career_type;
                career_sex = msg.career_sex;
                return this;
            }
        }

		// 陷阱数据
		public class MapTrap
		{
			public uint baseid;
			public swm.EntityType owner_type;
			public ulong owner_id ;
			public ulong overtime;
		}

		// 坐骑数据
		public class MapMount
		{
			public uint baseid;
			public uint skinid;
		}

        //采集npc数据
        public class GatherResource
        {
            public uint baseid = 0;
        }



        public struct ClickFly
        {
            public Vector3 cur_pos;    // 起始点
            public Vector3 cur_dir;    // 起始朝向
            public Vector3 vec;        // 速度向量
            public Vector3 tpos;       // 终点
            public long btime ;       // 开始时间
            public long ctime;       // 当前时间
            public long etime;       // 结束时间
            public float airforce;     // 空气阻力系数
            public void FromMsg(swm.ClickFly data)
            {
                cur_pos = data.cur_pos.FBVec3Vec3();
                cur_dir = data.cur_dir.FBVec3Vec3();
                vec = data.vec.FBVec3Vec3();
                tpos = data.tpos.FBVec3Vec3();
                btime = (long)data.btime;
                ctime = (long)data.ctime;
                etime = (long)data.etime;
                airforce = data.airforce;
            }
        }

        public struct BeatBack
        {
            public Vector3 startpos;    // 起始点
            public Vector3 startdir;    // 起始朝向
            public Vector3 tpos;        // 终点
            public float speed;        // 速度
            public long btime;        // 开始时间
            public long etime;        // 结束时间
            public long ctime;        // 当前时间
            public int type;         // 类型(BlinkType_BEATBACK or BlinkType_IMPACT)
            public void FromMsg(swm.BeatBack data)
            {
                startpos = data.startpos.FBVec3Vec3();
                startdir = data.startdir.FBVec3Vec3();
                tpos = data.tpos.FBVec3Vec3();
                speed = data.speed;
                btime = (long)data.btime;
                etime = (long)data.etime;
                ctime = (long)data.ctime;
                type = (int)data.type;
            }
        }

        public struct Rush
        {
            public Vector3 startpos;    // 起始点
            public Vector3 startdir;    // 起始朝向
            public Vector3 tpos;        // 终点
            public float speed;        // 速度
            public long btime;        // 开始时间
            public long etime;        // 结束时间
            public long ctime;        // 当前时间
            public int type;         // 类型(BlinkType_BEATBACK or BlinkType_IMPACT)
            public void FromMsg(swm.Rush data)
            {
                startpos = data.startpos.FBVec3Vec3();
                startdir = data.startdir.FBVec3Vec3();
                tpos = data.tpos.FBVec3Vec3();
                speed = data.speed;
                btime = (long)data.btime;
                etime = (long)data.etime;
                ctime = (long)data.ctime;
                type = (int)data.type;
            }
        }


        public struct MoveTrailData
        {
            public ClickFly? clickfly;    // 击飞
            public BeatBack? beatback;
            public Rush? rush;
            public void FromMsg(swm.MoveTrailData data)
            {
                if (data.clickfly.HasValue)
                {
                    Bokura.LogHelper.Log("[HC]data.clickfly.HasValue");
                    var fly = new ClickFly();
                    fly.FromMsg(data.clickfly.Value);
                    clickfly = fly;
                    //clickfly.Value.FromMsg(data.clickfly.Value);
                }
                else
                    clickfly = null;

                if (data.beatback.HasValue)
                {
                    var d = new BeatBack();
                    d.FromMsg(data.beatback.Value);
                    beatback = d;
                }
                else
                    beatback = null;
                if (data.rush.HasValue)
                {
                    var d = new Rush();
                    d.FromMsg(data.rush.Value);
                    rush = d;
                }
                else
                    rush = null;
            }
        }
        public struct EntityMoveData
        {
            public MoveTrailData? trail;

            public void FromMsg(swm.EntityMoveData data)
            {
                if (data.trail.HasValue)
                {
                    Bokura.LogHelper.Log("[HC]data.trail.HasValue");


                    var d = new MoveTrailData();
                    d.FromMsg(data.trail.Value);
                    trail = d;
                }
                else
                    trail = null;

            }
        }
        public struct EntityAiTestData
        {
            public float hearing_radius;
            public float vision_radius;
            public float vision_angle;
            public void FromMsg(swm.AITestData data)
            {
                hearing_radius = data.hearing;
                vision_radius = data.vision;
                vision_angle = data.vision_angle;
            }
        }


        public class MapEntityData
		{

			public swm.EntityType entity_type;
			public ulong entity_id;
			public string name;
			public uint level;
			public float model_radius;
			public float model_radius2;
			public uint max_hp;
			public uint cur_hp;
			public uint max_mp;
			public uint cur_mp;
			public uint max_anger;
			public uint cur_anger;
			public Vector3 cur_pos;
			public Vector3 cur_dir;
			public Vector3 dst_pos;
			public uint move_speed;
			public uint attack_speed;
            public bool i_careful;
            public bool i_observable = true;
            public bool in_attack;
            public uint vehicleID;
            public uint[] titleIDs;
            public string out_of_band;
			/// <summary>
			/// 阵营类型
			/// </summary>
			public uint camp_type;

            public bool is_die = false;

			public List<int> fashions;
            public EntityMoveData? move_data;
            public EntityAiTestData? ai_data;
            public uint vox_world_id;
            public MapEntityData Clone()
            {
                MapEntityData _data = new MapEntityData();
                _data.entity_type = entity_type;
                //_data.entity_id = entity_id;
                _data.name = name;
                _data.level = level;
                _data.model_radius = model_radius;
                _data.model_radius2 = model_radius2;
                _data.max_hp = max_hp;
                _data.cur_hp = cur_hp;
                _data.max_mp = max_mp;
                _data.cur_mp = cur_mp;
                _data.max_anger = max_anger;
                _data.cur_anger = cur_anger;
                _data.camp_type = camp_type;
                _data.cur_pos = new Vector3(cur_pos.x, cur_pos.y, cur_pos.z);
                _data.cur_dir = new Vector3(cur_dir.x, cur_dir.y, cur_dir.z);
                _data.dst_pos = new Vector3(dst_pos.x, dst_pos.y, dst_pos.z);
                _data.move_speed = move_speed;
                _data.attack_speed = attack_speed;
                _data.in_attack = in_attack;
                _data.i_careful = i_careful;
                _data.i_observable = i_observable;
                _data.is_die = is_die;
                _data.vox_world_id = vox_world_id;
                _data.vehicleID = vehicleID;
                if (titleIDs != null)
                {
                    _data.titleIDs = new uint[titleIDs.Length];
                    for (int i = 0; i < titleIDs.Length; i++) { _data.titleIDs[i] = titleIDs[i]; }
                }
                _data.out_of_band = out_of_band;
                return _data;
            }

            public void FromMsg(swm.MapEntityData msg)
			{
				entity_type = GameScene.GetEntityTypeById(msg.entity_id);
				entity_id = msg.entity_id;
				if(msg.name!=null)
					name = msg.name;
				level = msg.level;
				model_radius = msg.model_radius;
				model_radius2 = msg.model_radius2;
				max_hp = msg.max_hp;
				cur_hp = msg.cur_hp;
				max_mp = msg.max_mp;
				cur_mp = msg.cur_mp;
				max_anger = msg.max_anger;
				cur_anger = msg.cur_anger;
				camp_type = msg.camp_type;
                vox_world_id = msg.vox_world_id;

				if (msg.cur_pos != null)
				{
                    cur_pos = msg.cur_pos.Value.FBVec3Vec3();

                }
				
				if (msg.cur_dir!=null)
				{
                    cur_dir = msg.cur_dir.Value.FBVec3Vec3();
				}

				if (msg.dst_pos != null)
				{
                    dst_pos = msg.dst_pos.Value.FBVec3Vec3();

                }

				move_speed = msg.move_speed;
				attack_speed = msg.attack_speed;
				in_attack = msg.is_fighting;
                i_careful = msg.iscatfoot;
                i_observable = msg.isobservable;
                vehicleID = msg.move_speed;//todo

                is_die = msg.is_die;
                if (msg.user_data != null)
                {
                    titleIDs = new uint[msg.user_data.Value.title_idvecLength];
                    for (int i = 0; i < titleIDs.Length; i++) { titleIDs[i] = msg.user_data.Value.title_idvec(i); }
                    out_of_band = msg.user_data.Value.title_out_of_band;
                }
                if (msg.move_data.HasValue)
                {
                    //Bokura.LogHelper.Log("[HC]msg.move_data.HasValue");
                    var d = new EntityMoveData();
                    d.FromMsg(msg.move_data.Value);
                    move_data = d;
                }
                else
                {
                    move_data = null;
                    //Bokura.LogHelper.Log("[HC]msg.move_data.HasValue false");
                }

                if (msg.ai_data.HasValue)
                {
                    //Bokura.LogHelper.Log("[HC]msg.ai_data.HasValue");
                    var d = new EntityAiTestData();
                    d.FromMsg(msg.ai_data.Value);
                    ai_data = d;
                }
                else
                {
                    ai_data = null;
                    //Bokura.LogHelper.Log("[HC]msg.ai_data.HasValue false");
                }
                

            }
            public void OnTitleChange(uint[] ids)
            {
                titleIDs = ids;
            }
        }
	}

}
*/