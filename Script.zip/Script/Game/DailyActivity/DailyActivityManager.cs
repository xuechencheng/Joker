using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;
using x2m;
using UnityEngine;
using System;
using UnityEngine.Profiling;
using System.Runtime.CompilerServices;
using LitJson;

namespace Bokura
{
    /// <summary>
    /// 日常活动数据层。
    /// TODO：没有处理跨天的逻辑
    /// </summary>
    public class DailyActivityManager : ClientSingleton<DailyActivityManager>
    {
        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspActivityList>(ResponseActivityList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspActiveInfo>(ResponseActivenessList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspPickActivePrizeById>(ResponseReceiveActivenessAward_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspQueryActivityInfo>(ResponseValidateActivityState_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyActivityChange>(ResponseNotifyActivityChange_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspActivityByIdList>(ProcRspActivityByIdList_SC);

            RedDotModel.Instance.onRedDotEvent.AddListener(RefreshRedPoint_SC);
            UserDataMgr.Instance.onUserDataSync.AddListener(CheckNotice);
        }

        Dictionary<string, string> MassiveConfig = new Dictionary<string, string>(Const.kCap32);

        public string GetMassiveConfig(string key)
        {
            if (MassiveConfig.ContainsKey(key))
                return MassiveConfig[key];
            return "";
        }

        private void LoadMassiveConfig()
        {
            if (MassiveConfig.Count > 0)
                return;

            string tConfigData = TableManager.LoadFileTable("c_massive_config.json", "/Datas/");
            if (!string.IsNullOrEmpty(tConfigData))
            {
                JsonData tJsonData = JsonMapper.ToObject(tConfigData);
                if (tJsonData != null)
                {
                    IEnumerator<string> iter = tJsonData.Keys.GetEnumerator();
                    while (iter.MoveNext())
                    {
                        if (tJsonData[iter.Current].IsArray)
                        {
                            if (iter.Current == "equip_starup_slot_npc")
                            {
                                foreach (JsonData item in tJsonData[iter.Current])
                                {
                                    EquipManager.Instance.npcSlotList.Add(int.Parse(item["slot"].ToString()), int.Parse(item["npc_id"].ToString()));
                                }
                            }
                            else if (iter.Current == "equip_starup_relation_percent")
                            {
                                foreach (JsonData item in tJsonData[iter.Current])
                                {
                                    EquipManager.Instance.backList.Add(int.Parse(item["prestige_level"].ToString()), int.Parse(item["percent"].ToString()));
                                }
                            }
                        }
                        else
                            MassiveConfig.Add(iter.Current, tJsonData[iter.Current].ToString());
                    }
                }
            }

            string posStr = MassiveConfig["activity_icon_pos"];
            string[] posList = posStr.Split('|');
            for (int i = 0; i < posList.Length; ++i)
            {
                string[] lst = posList[i].Split('_');
                if (lst.Length == 2)
                {
                    activityItemPos.Add(new UnityEngine.Vector3(float.Parse(lst[0]), float.Parse(lst[1]), 0));
                }
            }

            posStr = MassiveConfig["equip_quality_name"];
            posList = posStr.Split('-');
            for (int i = 0; i < posList.Length; ++i)
            {
                EquipManager.Instance.qualityString.Add(posList[i]);
            }
        }

        List<UnityEngine.Vector3> activityItemPos = new List<UnityEngine.Vector3>();

        public UnityEngine.Vector3 GetActivityItemPosByIndex(int index)
        {
            if (index >= activityItemPos.Count)
                return activityItemPos[activityItemPos.Count - 1];
            return activityItemPos[index];
        }

        private int maxActiveness = 0;
        public int MaxActiveness
        {
            get { return maxActiveness; }
        }

        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
            DailyActivityTableManager.Load();
            ActivenessTableManager.Load();
            WeekActiveManager.Load();
            IntroduceTableManager.Load();
            LoadMassiveConfig();

            //每日活动列表和奖励
            DailyActivityTableBaseList tActivityConfigs = DailyActivityTableManager.Instance.m_DataList;
            for (int tIdx = 0, tCount = tActivityConfigs.DailyActivityTableLength; tIdx < tCount; tIdx++)
            {
                DailyActivityTableBase tConfigValue = tActivityConfigs.DailyActivityTable(tIdx).Value;
                DailyActivity tActivity = new DailyActivity(tConfigValue);
                m_DailyActivityList.Add(tActivity);
               
                for (int tAwardIdx = 0, tAwardCount = tConfigValue.awardLength; tAwardIdx < tAwardCount; tAwardIdx++)
                    m_ActivityAwards.Add(GetKeyByIndex(tActivity.id, tAwardIdx), new AwardInfo(tConfigValue.award(tAwardIdx).Value));

                if (m_DicTabDaily.ContainsKey(tConfigValue.tab))
                    m_DicTabDaily[tConfigValue.tab].Add(tActivity);
                else
                {
                    List<DailyActivity> lst = new List<DailyActivity>();
                    lst.Add(tActivity);
                    m_DicTabDaily.Add(tConfigValue.tab, lst);
                }    
            }
            m_DailyActivityList.Sort(SortByWeight);

            m_ActivityIdMap.Clear();
            for(int i=0;i< m_DailyActivityList.Count;i++)
            {
                m_ActivityIdMap.Add(m_DailyActivityList[i].id, i);
            }
            CheckDay();

            //每日活跃列表和奖励
            ActivenessTableBaseList tActivenessConfigs = ActivenessTableManager.Instance.m_DataList;
            for (int tIdx = 0, tCount = tActivenessConfigs.ActivenessTableLength; tIdx < tCount; tIdx++)
            {
                ActivenessTableBase tConfigValue = tActivenessConfigs.ActivenessTable(tIdx).Value;
                ActivenessConfig tActiveness = new ActivenessConfig(tConfigValue);
                m_ActivenessList.Add(tActiveness);
                m_ActivenessIdMap.Add(tActiveness.id, tIdx);
                if (tActiveness.activeness > maxActiveness)
                    maxActiveness = tActiveness.activeness;
                for (int tAwardIdx = 0, tAwardCount = tConfigValue.awardLength; tAwardIdx < tAwardCount; tAwardIdx++)
                    m_ActivenessAwards.Add(GetKeyByIndex(tActiveness.id, tAwardIdx), new AwardInfo(tConfigValue.award(tAwardIdx).Value));
            }

            //每周活动列表
            WeekActiveBaseList tWeekActivityConfigs = WeekActiveManager.Instance.m_DataList;
            for (int tIdx = 0, tCount = tWeekActivityConfigs.WeekActiveLength; tIdx < tCount; tIdx++)
            {
                WeekActiveBase tConfigValue = tWeekActivityConfigs.WeekActive(tIdx).Value;
                WeeklyActivity tActivity = new WeeklyActivity(tConfigValue);
                m_WeeklyActivityList.Add(tActivity);
            }
            m_WeeklyActivityList.Sort(SortByWeight);
        }

        public int CurIntroduceID = 0;

        public List<IntroduceTableBase> GetIntroduceList()
        {
            List<IntroduceTableBase> lst = new List<IntroduceTableBase>();
            IntroduceTableBaseList tConfigs = IntroduceTableManager.Instance.m_DataList;
            for (int tIdx = 0, tCount = tConfigs.IntroduceTableLength; tIdx < tCount; tIdx++)
            {
                IntroduceTableBase tConfigValue = tConfigs.IntroduceTable(tIdx).Value;
                lst.Add(tConfigValue);
            }
            return lst;
        }

        public IntroduceTableBase GetIntroduceByID(int id)
        {
            IntroduceTableBase? item = IntroduceTableManager.GetData(id);
            if (item != null)
                return item.Value;
            else
                return default(IntroduceTableBase);
        }

        public DailyActivity GetDailyActivity(int id)
        {
            for (int i = 0; i< m_DailyActivityList.Count; ++i)
            {
                if (m_DailyActivityList[i].id == id)
                    return m_DailyActivityList[i];
            }
            return null;
        }

        /// <summary>
        /// 活动页签信息
        /// </summary>
        private Dictionary<int, List<DailyActivity>> m_DicTabDaily = new Dictionary<int, List<DailyActivity>>(Const.kCapacity);

        public List<int> GetActivityTab()
        {
            List<int> ret = new List<int>();
            foreach(var item in m_DicTabDaily.Keys)
            {
                ret.Add(item);
            }
            return ret;
        }

        public List<DailyActivity> GetActivityByTab(int key)
        {
            if (m_DicTabDaily.ContainsKey(key))
            {
                return m_DicTabDaily[key];
            }

            return null;
        }

        void CheckDay()
        {
            for (int tIdx = 0, tCount = m_DailyActivityList.Count; tIdx < tCount; tIdx++)
            {
                DailyActivity tActivity = m_DailyActivityList[tIdx];
                tActivity.isOpenedToday = IsTodayOpened(tActivity.openDate);
                m_DailyActivityList[tIdx] = tActivity;
            }
        }

        private int noticTimerID = -1;

        void CheckNotice()
        {
            float tNextTime = 0;
            ulong serverTime = GameScene.Instance.GetServerTime();
            if (GameScene.Instance.ServerRecordTime != 0)
            {
                CheckDay();
                tNextTime = -1;
                for (int tIdx = 0, tCount = m_DailyActivityList.Count; tIdx < tCount; tIdx++)
                {
                    DailyActivity tActivity = m_DailyActivityList[tIdx];
                    if (!tActivity.isOpenedToday)
                        continue;
                    if (tActivity.noticeTime == null)
                    {
                        if (string.IsNullOrEmpty(tActivity.time))
                            continue;
                        tActivity.CreateOpenTime(serverTime);
                        if (tActivity.noticeTime == null)
                        {
                            tActivity.isOpenedToday = false;
                            m_DailyActivityList[tIdx] = tActivity;
                            continue;
                        }
                        
                        m_DailyActivityList[tIdx] = tActivity;
                    }

                    int len = tActivity.noticeTime.Length;

                    for (int i = 0; i < len; ++i)
                    {                
                        if (tActivity.sentRecord[i] == 0)
                            continue;

                        if (serverTime >= tActivity.GetNoticeTime(i))
                        {
                            m_OnPushView.Invoke(tActivity.sentRecord[i]);                       
                            tActivity.sentRecord[i] = 0;
                            m_DailyActivityList[tIdx] = tActivity;
                        }
                        else
                        {
                            float delt = (tActivity.GetNoticeTime(i) - serverTime) * 0.001f;
                            if (tNextTime == -1)
                            {
                                tNextTime = delt;
                            }
                            else
                            {
                                tNextTime = Math.Min(delt, tNextTime);
                            }
                        }
                    }
                }
            }
            else
            {
                tNextTime = 15;
            }

            if (tNextTime == -1)
                return;

            noticTimerID = GameApplication.Instance.m_TimerManager.AddTimer(CheckNotice, tNextTime).ID;
        }



        /// <summary>
        /// （大退/小退）清理缓存
        /// </summary>
        public void Clear()
		{
            m_TempDailyActivityList.Clear();
            for (int tIdx = 0, tCount = m_DailyActivityList.Count; tIdx < tCount; tIdx++)
            {
                DailyActivity tActivity     = m_DailyActivityList[tIdx];
                tActivity.curNum            = 0;
                tActivity.state             = 0;
                tActivity.isOpenedToday     = false;
                m_DailyActivityList[tIdx]   = tActivity;
            }
            for (int tIdx = 0, tCount = m_ActivenessList.Count; tIdx < tCount; tIdx++)
            {
                ActivenessConfig tConfig    = m_ActivenessList[tIdx];
                tConfig.state               = 0;
                m_ActivenessList[tIdx]      = tConfig;
            }

            m_CurrentActivenessValue        = 0;
            m_RedPointNum                   = 0;

            if (noticTimerID != -1)
            {
                GameApplication.Instance.m_TimerManager.RemoveTimer(noticTimerID);
            }
        }



        /// <summary>
        /// 每日活动列表
        /// </summary>
        private List<DailyActivity> m_DailyActivityList = new List<DailyActivity>(Const.kCapacity);

        private List<DailyActivity> m_TempDailyActivityList = new List<DailyActivity>(Const.kCapacity);
        public List<DailyActivity> TempDailyActivityList
        {
            get
            {
                return m_TempDailyActivityList;
            }
        }

        /// <summary>
        /// 每周活动列表
        /// </summary>
        private List<WeeklyActivity> m_WeeklyActivityList = new List<WeeklyActivity>(Const.kCapacity);



        public int weeklyCount { get { return m_WeeklyActivityList.Count; } }



        /// <summary>
        /// 活动id与索引映射
        /// </summary>
        private Dictionary<int, int> m_ActivityIdMap = new Dictionary<int, int>(Const.kCap8);



        public int activityCount { get { return m_DailyActivityList.Count; } }



        /// <summary>
        /// 每日活跃列表
        /// </summary>
        private List<ActivenessConfig> m_ActivenessList = new List<ActivenessConfig>(Const.kCap8);



        /// <summary>
        /// 活跃id与索引映射
        /// </summary>
        private Dictionary<int, int> m_ActivenessIdMap = new Dictionary<int, int>(Const.kCap8);



        public int activenessCount { get { return m_ActivenessList.Count; } }



        /// <summary>
        /// 每日活动奖励
        /// </summary>
        private Dictionary<int, AwardInfo> m_ActivityAwards = new Dictionary<int, AwardInfo>(Const.kCap16);



        /// <summary>
        /// 每日活跃奖励
        /// </summary>
        private Dictionary<int, AwardInfo> m_ActivenessAwards = new Dictionary<int, AwardInfo>(Const.kCap16);



        private int m_CurrentActivenessValue = 0;
        /// <summary>
        /// 当前活跃值
        /// </summary>
        public int currentActivenessValue { get { return m_CurrentActivenessValue; } }



        private int m_RedPointNum = 0;
        /// <summary>
        /// 待处理红点数量
        /// </summary>
        public int redPointNum { get { return m_RedPointNum; } }



        /// <summary>
        /// 国际惯例：周一到周日为1,2,3,4,5,6,0。
        /// 这里需要：周一到周日为1,2,3,4,5,6,7。
        /// 转换一下：(0 + 6) % 7 + 1 = 7, (1 + 6) % 7 + 1 = 1, ... , (6 + 6) % 7 + 1 = 6;
        /// </summary>
        public int todayOfWeek { get { return ((int)System.DateTime.Now.DayOfWeek + 6) % 7 + 1; } }



        private GameEvent m_OnDailyActivityDataArrived = new GameEvent();
        /// <summary>
        /// 服务器返回每日活动信息
        /// </summary>
        public GameEvent onDailyActivityDataArrived
        {
            get { return m_OnDailyActivityDataArrived; }
        }



        private GameEvent<int> m_OnValidateActivityResultArrived = new GameEvent<int>();
        /// <summary>
        /// 服务器返回验证结果
        /// </summary>
        public GameEvent<int> onValidateActivityResultArrived
        {
            get { return m_OnValidateActivityResultArrived; }
        }



        private GameEvent m_OnActivityChangeDataArrived = new GameEvent();
        /// <summary>
        /// 服务器通知活动改变
        /// </summary>
        public GameEvent onActivityChangeDataArrived
        {
            get { return m_OnActivityChangeDataArrived; }
        }



        private GameEvent m_OnActivenessDataArrived = new GameEvent();
        /// <summary>
        /// 服务器返回每日活跃信息
        /// </summary>
        public GameEvent onActivenessDataArrived
        {
            get { return m_OnActivenessDataArrived; }
        }



        private GameEvent<bool> m_OnReceiveActivenessAwardResultArrived = new GameEvent<bool>();
        /// <summary>
        /// 服务器返回领取活跃度奖励结果
        /// </summary>
        public GameEvent<bool> onReceiveActivenessAwardResultArrived
        {
            get { return m_OnReceiveActivenessAwardResultArrived; }
        }



        private GameEvent m_OnRefreshRedPoint = new GameEvent();
        /// <summary>
        /// 服务器刷新红点
        /// </summary>
        public GameEvent onRefreshRedPoint
        {
            get { return m_OnRefreshRedPoint; }
        }


        private GameEvent<int> m_OnPushView = new GameEvent<int>();
        /// <summary>
        /// 服务器刷新红点
        /// </summary>
        public GameEvent<int> onPushView
        {
            get { return m_OnPushView; }
        }

        private GameEvent m_OnActivityByIdListChangeEvent = new GameEvent();//客户端请求某些活动的状态变化事件
        public GameEvent OnActivityByIdListChangeEvent
        {
            get { return m_OnActivityByIdListChangeEvent; }
        }


        /// <summary>
        /// 请求活动列表
        /// </summary>
        public void RequestActivityList_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqActivityList.StartReqActivityList(tFBB);
            Offset<swm.ReqActivityList> tOffset = swm.ReqActivityList.EndReqActivityList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqActivityList.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回活动列表
        /// </summary>
        private void ResponseActivityList_SC(RspActivityList msg)
        {
            for (int tIdx = 0, tCount = msg.act_listLength; tIdx < tCount; tIdx++)
            {
                ActivityElemInfo? tInfo         = msg.act_list(tIdx);
                UpdateActivityInfo(tInfo);
            }
            m_OnDailyActivityDataArrived.Invoke();
        }



        /// <summary>
        /// 请求验证活动状态
        /// </summary>
        public void RequestValidateActivityState_CS(uint activityId)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqQueryActivityInfo> tOffset = swm.ReqQueryActivityInfo.CreateReqQueryActivityInfo(tFBB, activityId);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqQueryActivityInfo.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回活动状态验证结果
        /// </summary>
        private void ResponseValidateActivityState_SC(RspQueryActivityInfo msg)
        {
            int tIndex = -1;
            if (m_ActivityIdMap.TryGetValue((int)msg.act_id, out tIndex))
            {
                DailyActivity tActivity     = m_DailyActivityList[tIndex];
                tActivity.state             = (int)msg.act_state;
                //每次都重新判断今天是否开放，考虑跨越两天的情况
                tActivity.isOpenedToday     = IsTodayOpened(tActivity.openDate);
                m_DailyActivityList[tIndex] = tActivity;
                m_OnValidateActivityResultArrived.Invoke(tIndex);
            }
        }



        /// <summary>
        /// 服务器通知活动状态发生变化
        /// </summary>
        private void ResponseNotifyActivityChange_SC(NotifyActivityChange msg)
        {
            for (int tIdx = 0, tCount = msg.change_listLength; tIdx < tCount; tIdx++)
            {
                ActivityElemInfo? tInfo = msg.change_list(tIdx);
                UpdateActivityInfo(tInfo);
            }
            m_OnActivityChangeDataArrived.Invoke();
        }



        /// <summary>
        /// 请求活跃列表
        /// </summary>
        public void RequestActivenessList_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqActiveInfo.StartReqActiveInfo(tFBB);
            Offset<swm.ReqActiveInfo> tOffset = swm.ReqActiveInfo.EndReqActiveInfo(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqActiveInfo.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回活跃列表
        /// </summary>
        private void ResponseActivenessList_SC(RspActiveInfo msg)
        {
            m_CurrentActivenessValue = (int)msg.cur_value;
            for (int tIdx = 0, tCount = msg.show_listLength; tIdx < tCount; tIdx++)
            {
                ActiveStageInfo? tInfo = msg.show_list(tIdx);
                if (tInfo.HasValue)
                {
                    ActiveStageInfo tInfoValue = tInfo.Value;
                    int tIndex = -1;
                    if (m_ActivenessIdMap.TryGetValue((int)tInfoValue.active_id, out tIndex))
                    {
                        ActivenessConfig tConfig = m_ActivenessList[tIndex];
                        tConfig.state = (int)tInfoValue.show_state;
                        m_ActivenessList[tIndex] = tConfig;
                    }
                }
            }
            m_OnActivenessDataArrived.Invoke();
        }



        /// <summary>
        /// 请求领取活跃度奖励
        /// </summary>
        public void RequestReceiveActivenessAward_CS(uint activenessId)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqPickActivePrizeById> tOffset = swm.ReqPickActivePrizeById.CreateReqPickActivePrizeById(tFBB, activenessId);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqPickActivePrizeById.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回领取活跃度奖励的结果
        /// </summary>
        private void ResponseReceiveActivenessAward_SC(RspPickActivePrizeById msg)
        {
            m_OnReceiveActivenessAwardResultArrived.Invoke(msg.result == 0);
            if (msg.result == 0)
            {
                int id = (int)msg.pick_id;
                if (m_ActivenessIdMap.ContainsKey(id))
                {
                    int idx = m_ActivenessIdMap[id];
                    if (m_ActivenessList.Count > idx)
                    {
                        ActivenessConfig config = m_ActivenessList[idx];
                        List<ItemBase> ShowItems = new List<ItemBase>();
                        List<uint> ShowItemNums = new List<uint>();
                        for (int i = 0; i < config.awardCount; ++i)
                        {
                            AwardInfo info = GetActivenessAwardInfoByIndex(config.id, i);
                            ItemBase item = BagManager.Instance.GetItemByBaseID(BagType.ItemBag, (int)info.itemID);
                            if(item != null)
                            {
                                ShowItems.Add(item);
                                ShowItemNums.Add(info.count);
                            }

                        }
                        BagManager.Instance.onDropBatchItemsEvent.Invoke(ShowItems, ShowItemNums, 1);
                    }
                }  
            }
        }



        /// <summary>
        /// 服务器刷新红点
        /// </summary>
        private void RefreshRedPoint_SC(RedDotData msg)
        {
            if(msg.RedDotType == swm.RedDotType.ACTIVE)
            {
                //0表示没有红点
                m_RedPointNum = (int)msg.Num;
                m_OnRefreshRedPoint.Invoke();
            }
        }



        /// <summary>
        /// 更新活动信息
        /// </summary>
        private void UpdateActivityInfo(ActivityElemInfo? info)
        {
            if (info.HasValue)
            {
                ActivityElemInfo tInfoValue     = info.Value;
                int tIndex                      = -1;
                if (m_ActivityIdMap.TryGetValue((int)tInfoValue.act_id, out tIndex))
                {
                    DailyActivity tActivity     = m_DailyActivityList[tIndex];
                    tActivity.curNum            = (int)tInfoValue.cur_num;
                    tActivity.maxNum            = (int)tInfoValue.max_num;
                    tActivity.state             = (int)tInfoValue.act_state;
                    //每次都重新判断今天是否开放，考虑跨越两天的情况
                    tActivity.isOpenedToday     = IsTodayOpened(tActivity.openDate);
                    m_DailyActivityList[tIndex] = tActivity;
                }
            }
        }

        /// <summary>
        /// 客户端请求某些活动的状态
        /// </summary>
        /// <param name="_ids"></param>
        public void SendReqActivityByIdList(List<uint> _ids)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            var fids = swm.ReqActivityByIdList.CreateIdsVector(fbb, _ids.ToArray());

            swm.ReqActivityByIdList.StartReqActivityByIdList(fbb);
            swm.ReqActivityByIdList.AddIds(fbb, fids);
            var msg = swm.ReqActivityByIdList.EndReqActivityByIdList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqActivityByIdList.HashID, fbb);
        }

        /// <summary>
        /// 接收请求某些活动的状态
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspActivityByIdList_SC(swm.RspActivityByIdList _msg)
        {
            m_TempDailyActivityList.Clear();
            int tIndex = 0;
            for (int i=0; i<_msg.act_listLength;i++)
            {
                ActivityElemInfo _info = _msg.act_list(i).Value;
                if (m_ActivityIdMap.TryGetValue((int)_info.act_id, out tIndex))
                {
                    DailyActivity tActivity = m_DailyActivityList[tIndex];
                    tActivity.curNum = (int)_info.cur_num;
                    tActivity.maxNum = (int)_info.max_num;
                    tActivity.state = (int)_info.act_state;
                    m_TempDailyActivityList.Add(tActivity);
                }   
            }
            if(m_TempDailyActivityList.Count > 0)
            {
                m_OnActivityByIdListChangeEvent.Invoke();
            }
        }

        /// <summary>
        /// 根据道具id获取道具icon的路径
        /// </summary>
        public string GetAwardIconPath(uint itemID)
        {
            ItemTableBase? tConfig = ItemTableManager.GetData((int)itemID);
            if (tConfig.HasValue)
                return tConfig.Value.icon;
            return string.Empty;
        }




        /// <summary>
        /// 获取指定索引的每日活动信息
        /// </summary>
        public DailyActivity GetDailyActivityByIndex(int index)
        {
            DailyActivity tData = default(DailyActivity);
            if (index >= 0 && index < activityCount)
                tData = m_DailyActivityList[index];
            return tData;
        }




        /// <summary>
        /// 获取指定索引的每周活动信息
        /// </summary>
        public WeeklyActivity GetWeeklyActivityByIndex(int index)
        {
            WeeklyActivity tData = default(WeeklyActivity);
            if (index >= 0 && index < weeklyCount)
                tData = m_WeeklyActivityList[index];
            return tData;
        }




        /// <summary>
        /// 获取指定索引的每日活跃信息
        /// </summary>
        public ActivenessConfig GetActivenessConfigByIndex(int index)
        {
            if (index < 0 || index >= activenessCount)
                return default(ActivenessConfig);
            return m_ActivenessList[index];
        }



        /// <summary>
        /// 根据索引获取每日活动的奖励
        /// </summary>
        public AwardInfo GetActivityAwardInfoByIndex(int activityId, int awardIndex)
        {
            AwardInfo tInfo;
            if (!m_ActivityAwards.TryGetValue(GetKeyByIndex(activityId, awardIndex), out tInfo))
                tInfo = default(AwardInfo);
            return tInfo;
        }



        /// <summary>
        /// 根据索引获取每日活跃的奖励
        /// </summary>
        public AwardInfo GetActivenessAwardInfoByIndex(int activenessId, int awardIndex)
        {
            AwardInfo tInfo;
            if (!m_ActivenessAwards.TryGetValue(GetKeyByIndex(activenessId, awardIndex), out tInfo))
                tInfo = default(AwardInfo);
            return tInfo;
        }



        /// <summary>
        /// 根据两个索引唯一确定一个键
        /// </summary>
        private int GetKeyByIndex(int indexA, int indexB)
        {
            return indexA * 100 + indexB;
        }



        /// <summary>
        /// 权重越大，排列越靠前
        /// </summary>
        private int SortByWeight(DailyActivity left, DailyActivity right)
        {
            return left.weight > right.weight ? -1 : 1;
        }



        /// <summary>
        /// 权重越大，排列越靠前
        /// </summary>
        private int SortByWeight(WeeklyActivity left, WeeklyActivity right)
        {
            return left.weight > right.weight ? -1 : 1;
        }



        /// <summary>
        /// 今天是否开放
        /// </summary>
        private bool IsTodayOpened(int openDate)
        {
            DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            TimeSpan toNow = new TimeSpan((long)GameScene.Instance.GetServerTime() * 10000);
            DateTime tNow = tInit.Add(toNow);

            return ((1<<(int)tNow.DayOfWeek) & openDate) != 0;
        }



        /// <summary>
        /// 今天是否有可以参与的节日活动
        /// </summary>
        public bool HasFestivalActivitiesToday()
        {
            var tMainChar = GameScene.Instance.MainChar;
            int tMainCharLevel = null != tMainChar ? tMainChar.Level : 0;
            int FestivalType = (int)ActivityType.Festival;
            for (int tIdx = 0, tCount = activityCount; tIdx < tCount; tIdx++)
            {
                DailyActivity tData = m_DailyActivityList[tIdx];
                if (tData.type == FestivalType /*是节日活动*/&& tData.isOpenedToday /*今天开放*/&& tMainCharLevel >= tData.level /*等级到达*/)
                    return true;
            }
            return false;
        }



        /// <summary>
        /// 是否有即将解锁的活动
        /// </summary>
        public bool HasPrevueActivities()
        {
            var tMainChar = GameScene.Instance.MainChar;
            int tMainCharLevel = null != tMainChar ? tMainChar.Level : 0;
            for (int tIdx = 0, tCount = activityCount; tIdx < tCount; tIdx++)
            {
                DailyActivity tData = m_DailyActivityList[tIdx];
                if (tMainCharLevel < tData.level /*等级未到达*/)
                    return true;
            }
            return false;
        }

    }



    public enum ActivityType
    {
        None = 0,
        /// <summary>
        /// 日常
        /// </summary>
        Daily = 1,
        /// <summary>
        /// 限时
        /// </summary>
        Limit = 2,
        /// <summary>
        /// 节日
        /// </summary>
        Festival = 3,
        /// <summary>
        /// 预告(不满足开启条件的所有活动)
        /// </summary>
        Prevue = 4,
    }



    /// <summary>
    /// 活跃度配置
    /// </summary>
    public struct ActivenessConfig
    {
        public int id;
        public int activeness;
        public int awardCount;
        public int state;



        [XLua.BlackList]
        public ActivenessConfig(ActivenessTableBase config)
        {
            this.id = config.id;
            this.activeness = config.activeness;
            this.awardCount = config.awardLength;
            this.state = 0;
        }
    }



    public class DailyActivity
    {
        /// <summary>
        /// 活动id
        /// </summary>
        public int id;
        /// <summary>
        /// 活动名称
        /// </summary>
        public string name;
        /// <summary>
        /// 活动类型
        /// </summary>
        public int type;
        /// <summary>
        /// 开放时间
        /// </summary>
        public string time;
        /// <summary>
        /// 开放日期
        /// </summary>
        [XLua.BlackList]
        //public string startTime;
        /// <summary>
        /// 开放时间字符串
        /// </summary>
        public ulong[] noticeTime;
        /// <summary>
        /// 开放时间
        /// </summary>
        public int openDate;
        /// <summary>
        /// 今天是否开放
        /// </summary>
        public bool isOpenedToday;
        /// <summary>
        /// 活动信息
        /// </summary>
        public string info;
        /// <summary>
        /// 完成次数
        /// </summary>
        public int curNum;
        /// <summary>
        /// 总次数
        /// </summary>
        public int maxNum;
        /// <summary>
        /// 等级要求
        /// </summary>
        public int level;
        /// <summary>
        /// 单次活跃度
        /// </summary>
        public int activeValue;
        /// <summary>
        /// 主要产出的物品id
        /// </summary>
        public uint mainAwardId;
        /// <summary>
        /// 奖励总数
        /// </summary>
        public int awardCount;
        /// <summary>
        /// 活动状态
        /// </summary>
        public int state;
        /// <summary>
        /// 参与活动的具体逻辑
        /// </summary>
        public string script;

        /// <summary>
        /// 活动图标
        /// </summary>
        public string icon;

        /// <summary>
        /// 活动喊话
        /// </summary>
        public string activity_dialog;


        /// <summary>
        /// 模式
        /// </summary>
        public string model_desc;

        /// <summary>
        /// 推荐时间
        /// </summary>
        public int retroduce_time;

        /// <summary>
        /// 显示优先级
        /// </summary>
        [XLua.BlackList]
        public int weight;

        public int[] notice;
        public int[] sentRecord;

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public ulong GetNoticeTime(int _Idx)
        {
            if (null != noticeTime)
                return (ulong)noticeTime[_Idx];
            else
                return 0;
        }

        [XLua.BlackList]
        public DailyActivity(DailyActivityTableBase config)
        {
            this.id             = config.id;
            this.name           = config.name;
            this.type           = config.page;
            this.time           = config.describe_time;
            this.curNum         = 0;
            this.maxNum         = 1;
            this.level          = 0;
            for (int tIdx = 0, tCount = config.unlock_conditionLength; tIdx < tCount; tIdx++)
            {
                IntList? tList = config.unlock_condition(tIdx);
                if (tList.HasValue)
                {
                    IntList tListValue = tList.Value;
                    if (tListValue.listLength >= 2 && tListValue.list(0) == 1)
                    {
                        this.level = tListValue.list(1);
                        break;
                    }
                }
            }

            this.openDate       = GetOpenDate(config);
            this.isOpenedToday  = false;
            this.activeValue    = config.active;
            this.info           = config.activity_information;
            this.mainAwardId    = (uint)config.mainaward;
            this.awardCount     = config.awardLength;
            this.state          = 0;
            this.script         = config.script;
            this.weight         = config.weight;
            this.noticeTime = null;
            this.sentRecord = null;
            this.notice = new int[config.noticeLength*2];
            for (int i = 0; i < config.noticeLength; ++i)
            {
                this.notice[i*2] = config.notice(i).Value.list(0);
                this.notice[i*2+1] = config.notice(i).Value.list(1);
            }
            this.icon = config.icon;
            this.activity_dialog = config.activity_dialog;
            this.model_desc = config.model_desc;
            this.retroduce_time = config.retroduce_time;
        }

        public void CreateOpenTime(ulong time)
        {
            DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            TimeSpan toNow = new TimeSpan((long)time * 10000);
            DateTime tNow = tInit.Add(toNow);

            DateTime _Today = new DateTime(tNow.Year, tNow.Month, tNow.Day);
            DailyActivityTableBase config = DailyActivityTableManager.GetData(id).Value;
            for (int i = 0; i < config.start_timeLength; ++i)
            {
                if (config.start_time(i).Value.listLength == 1)
                    break;

                int day = config.start_time(i).Value.list(0) % 7;
                if ((int)tNow.DayOfWeek != day)
                    continue;

                toNow = new TimeSpan(config.start_time(i).Value.list(1), config.start_time(i).Value.list(2), 0);
                for (int j = 0; j < notice.Length; j = j + 2)
                {
                    DateTime _cur = _Today.Add(toNow);
                    _cur = _cur.AddMinutes(-notice[j]);
                    if (_cur.Ticks < tNow.Ticks)
                        continue;

                    int tIndex = 0;
                    if (noticeTime == null)
                    {
                        noticeTime = new ulong[1];
                        sentRecord = new int[1];
                    }
                    else
                    {
                        tIndex = noticeTime.Length;
                        Array.Resize(ref noticeTime, tIndex + 1);
                        Array.Resize(ref sentRecord, tIndex + 1);
                    }

                    TimeSpan delt = new TimeSpan(_cur.Ticks - tInit.Ticks);
                    noticeTime[tIndex] = (ulong)delt.TotalSeconds * 1000;
                    sentRecord[tIndex] = notice[j + 1];
                }
            }   
        }


        /// <summary>
        /// 星期天 = 0，星期一 = 1，...，星期六 = 6
        /// </summary>
        private const int kEveryDay = 1 << 0 | 1 << 1 | 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6;



        /// <summary>
        /// 获取活动开放日期
        /// </summary>
        public static int GetOpenDate(DailyActivityTableBase config)
        {
            int tOpenDate = 0;
            int day = 0;
            for (int i = 0; i < config.start_timeLength; ++i)
            {
                if (config.start_time(i).Value.listLength == 1)
                    break;

                day = config.start_time(i).Value.list(0) % 7;
                tOpenDate |= (1 << (day % 7/*配置里星期天是7，国际惯例是0*/));
            }

            //如果没有配星期，只配了时间，默认是每天
            return (tOpenDate != 0) ? tOpenDate : kEveryDay;
        }
    }



    public struct WeeklyActivity
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int id;
        /// <summary>
        /// 活动名称
        /// </summary>
        public string name;
        /// <summary>
        /// 开放时间
        /// </summary>
        public string openTime;
        /// <summary>
        /// 每周开放日期
        /// </summary>
        public int dayOfWeek;
        /// <summary>
        /// 显示权重
        /// </summary>
        [XLua.BlackList]
        public int weight;



        [XLua.BlackList]
        public WeeklyActivity(WeekActiveBase config)
        {
            this.id         = config.id;
            this.name       = config.name;
            this.openTime   = config.time;
            this.dayOfWeek  = config.cycle;
            this.weight     = config.weight;
        }
    }


}
