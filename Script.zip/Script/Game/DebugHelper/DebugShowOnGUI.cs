﻿#if REMOTE_DEBUG

using UnityEngine;
using UnityEngine.Profiling;
using System;
using System.Collections;
using Bokura;

public class DebugShowOnGUI : MonoBehaviour
{
    public static bool isOpen = false;
    private static DebugShowOnGUI me = null;

    public static void OpenOnGUI()
    {
        if (!isOpen)
        {
            if (me == null)
            {
                GameObject go = GameObject.Find("DebugShowOnGUI");
                if (go == null)
                {
                    go = new GameObject("DebugShowOnGUI");
                    DontDestroyOnLoad(go);
                }

                if (go != null)
                {
                    me = go.GetComponent<DebugShowOnGUI>();

                    if (me == null)
                    {
                        me = go.AddComponent<DebugShowOnGUI>();
                    }
                }
            }

            me.enabled = true;

            isOpen = true;
        }
    }

    public static void CloseOnGUI()
    {
        if (me != null)
        {
            me.enabled = false;
        }

        isOpen = false;
    }

    const float INTERVAL_UPDATE_DURATION = 0.2f;	// duration of each FPS update interval, in seconds
    private float m_lastIntervalTime;               // time of last FPS calculate interval

    /// FPS calculation.
    private float m_fps;        // current FPS
    private int m_frames = 0;   // num of frames over current interval
    //private float m_timeFrame;  // num of ms in current frame

    private void Start()
    {
        m_frames = 0;
        m_lastIntervalTime = Time.time;
    }

    private void Update()
    {
        m_frames++;
        float timeNow = Time.time;
        if (timeNow > m_lastIntervalTime + INTERVAL_UPDATE_DURATION)
        {
            m_fps = m_frames / (timeNow - m_lastIntervalTime);
            //m_timeFrame = 1000.0f / Math.Max(m_fps, 0.00001f);
            m_frames = 0;

            m_lastIntervalTime = timeNow;
        }
    }


    Rect position = new Rect(50.0f, 5.0f, 100, 25);

    private void OnGUI()
    {
        GUI.Box(position, string.Format("FPS:{0}", m_fps.ToString("f2")));
    }
}

#endif
