﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

#if UNITY_EDITOR

public class WorldMatLUTDebug : MonoBehaviour
{

    public Texture2D mImage;
    public int curXIndex;
    public int curYIndex;
    public int curMapIndex;
	
	// Update is called once per frame
	void Update ()
    {
        var wml = IWorldMatLUT.Instance as WorldMatLUT;
        var mainChar = GameScene.Instance.MainChar;
        var wpos = mainChar.Position;
        //string sceneName = string.Empty;
        //WorldHelper.WorldPos2MapPos(wpos, ref pos, ref sceneName);
        uint mapIndex = 0;
        Vector3 pos = WorldHelper.WorldPos2MapPos(wpos, ref mapIndex);

        //获得区域块尺寸
        Vector3 size;
        size.x = wml.mConfig.sx;
        //size.y = mConfig.sy;
        size.z = wml.mConfig.sz;

        int xIndex = (int)(pos.x / size.x);
        int yIndex = (int)(pos.z / size.z);
        if(wml != null && (curXIndex != xIndex || curYIndex != yIndex || curMapIndex != mapIndex) )
        {
            wml.mMatTableAgent.set(xIndex, yIndex, mapIndex);
            var curMatTable = wml.mLRUList.AllocItem();
            updateImage(curMatTable, pos);
            curYIndex = xIndex;
            curXIndex = yIndex;
            curMapIndex = (int)mapIndex;
            wml.mLRUList.FreeItem(curMatTable);
        }
	}

    void updateImage(WorldMatLUT.WorldMatTable curMatTable, Vector3 wPos)
    {
        Texture2D tex = new Texture2D(curMatTable.xSize, curMatTable.ySize);
        for (int y = 0; y < curMatTable.ySize; y++)
        {
            for (int x = 0; x < curMatTable.xSize; x++)
            {
                Color col;
                float height = 172;

                byte m = curMatTable.get(wPos, x, y, out height);
                if (m == 0)
                {
                    col = new Color(1, 0, 0);
                }
                else if (m == 1)
                {
                    col = new Color(0, 1, 0);
                }
                else if (m == 2)
                {
                    col = new Color(0, 0, 1);
                }
                else
                {
                    col = new Color(1, 1, 0);
                }

                //if(y > 256)
                //{
                //    col = new Color(1, 0, 0);
                //}
                //else
                //{
                //    col = new Color(1, 1, 0);
                //}

                tex.SetPixel(x, y, col);
            }
        }

        var mainChar = GameScene.Instance.MainChar;
        var pos = mainChar.Position;

        int xOffset = (int)(pos.x % curMatTable.xSize);
        int yOffset = (int)(pos.z % curMatTable.ySize);
        for(int x = -20; x < 20; x++)
        {
            for(int y = -20; y < 20; y++)
            {
                int xxx = xOffset + x;
                int yyy = yOffset + y;
                if(xxx >= 0 && xxx < curMatTable.xSize && yyy >= 0 && yyy < curMatTable.ySize)
                {
                    tex.SetPixel(xxx, yyy, new Color(1, 1, 1));
                }
            }
        }

        tex.Apply(true);
        mImage = tex;
    }

}

#endif
