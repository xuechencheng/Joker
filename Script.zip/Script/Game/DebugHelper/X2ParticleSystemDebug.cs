﻿#if __X2_OLD_VFX__
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Bokura.Particle;

#if UNITY_EDITOR
public class X2ParticleSystemDebug : MonoBehaviour
{

    public List<GameObject> mAllFXList = new List<GameObject>();
    public List<GameObject> mActiveFXList = new List<GameObject>();
    // Use this for initialization
//     void Start () {
// 		
// 	}
	
	// Update is called once per frame
	void Update ()
    {
        var pool = X2ParticleSystem.Instance.mPool;
        var cache = pool.mGameObjectCache;
        int count = cache.Count();
        mAllFXList.Clear();
        mActiveFXList.Clear();

        for (int i = 0; i < count; i++)
        {
            var go = cache.getItemByIndex(i);
            mAllFXList.Add(go);

            if(cache.IsUsed(i))
            {
                mActiveFXList.Add(go);
            }
            else
            {
                mActiveFXList.Add(null);
            }
        }
    }
}
#endif


#endif//#if __X2_OLD_VFX__