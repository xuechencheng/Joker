using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Bokura;

namespace Bokura
{
    public class ActionEffectManager : ISingleton<ActionEffectManager>
    {
        class ActionEffectData
        {
            private static readonly ObjectPool<ActionEffectData> s_pool = new ObjectPool<ActionEffectData>();

            public Magic.MagicContext context;   
            public Animator AttachAnimator;
            public Animator EffectAnimator;

            public int Uid;
            public GameObject AttachEntity;
            public GameObject Effect;
            public float Frame;
            public bool isDestroyAfterDuration = true; //是否在剔除时间后自动删除
            public bool customDuration; //是否使用自定义剔除时间
            public float Duration;  //自定义剔除时间
            public Transform BindBonePostion; //只绑定位置
            public float fadeouttime;
            public Vector3 BindOffset = Vector3.zero;
            public SpawnInstanceCategory category = SpawnInstanceCategory.Effect;
            public static float DefaultPower = 1.0f;
            public static Color DefaultColor = new Color(0, 0, 0, 1);
            public static ActionEffectData Get()
            {
                return s_pool.Get();
            }
            public void Update()
            {
                if(context.avatar != null && Effect != null)
                {
                    if (context.avatar.Visible != Effect.activeSelf)
                        Effect.SetActive(context.avatar.Visible);
                }
                if(BindBonePostion != null)
                {
                    Effect.transform.position = BindBonePostion.position + BindBonePostion.rotation * BindOffset;
                }
            }
            public void Release(bool Immediate = false)
            {
                if (!Immediate && fadeouttime > 0)
                    Bokura.Particle.X2ParticleFadeOut.Instance.FadeOut(Effect, AttachEntity, fadeouttime);
                else
                {
                    GameFXPool.FreeFX(Effect);
                    //LogHelper.LogWarningFormat("effect immediate destroy.{0}", Effect.name);
                    //GameObject.Destroy(Effect);
                }

                if (category == SpawnInstanceCategory.Weapon) context.avatar?.RefreshAllAnimator(RefreshAnimatorWay.Remove, EffectAnimator);
                AttachAnimator = null;
                EffectAnimator = null;
                AttachEntity = null;
                Effect = null;
                BindBonePostion = null;

                Frame = 0;
                isDestroyAfterDuration = true;
                customDuration = false;
                Duration = 0;
                fadeouttime = 0;
                BindOffset = Vector3.zero;
                category = SpawnInstanceCategory.Effect;
                Uid = 0;
                context = default(Magic.MagicContext);

                s_pool.Release(this);
            }
        }

        [XLua.BlackList]
        public static void Register()
        {
            if (m_instance == null)
            {
                m_instance = ClientSingletonManager.Instance.CreateSingleton<ActionEffectManager>();

                MecanimEventManager.AddListener(MecanimEventFunctionTypes.SpawnGameObject, m_instance.OnSpawnGameObject);
                MecanimEventManager.AddListener(MecanimEventFunctionTypes.SpawnFootPrint, m_instance.OnSpawnFootprint);
                MecanimEventManager.AddListener(MecanimEventFunctionTypes.PlayRadialPostProcess, m_instance.OnPlayRadialPostProcess);
                MecanimEventManager.AddListener(MecanimEventFunctionTypes.PlayMaterialChange, m_instance.OnPlayMaterialChange);
            }
        }

        public void Load(string strModelNamePath, string strPath, LoadCallback _func)
        {
            GameFXPool.LoadFX(strPath, strModelNamePath, (UnityEngine.Object o) =>
            {
                if (o != null)
                {
                    var clone = GameFXPool.CreateFX(o, null);
                    if (_func != null)
                        _func(clone);
                }
            });
        }
        //private static float m_delayDestroyDetlaTime = 20f;
        private static List<ActionEffectData> m_effectList = new List<ActionEffectData>(Const.kCap16);
		private static List<ActionEffectData> m_TempList = new List<ActionEffectData>(Const.kCap16);


		bool m_enableSpawnGameObject = true;
		public bool EnableSpawnGameObject
		{
			get
			{
				return m_enableSpawnGameObject;
			}
			set
			{
				m_enableSpawnGameObject = value;
			}
		}
        
        public void OnSpawnGameObject(GameObject attach, MagicDataBase e)
        {
            var me = e as Magic.MecanimFixEffectData;

            if (!me.mecanimEffect.isAutoPlay &&
                !IsForcePlayActionEventByUID(me.mecanimEffect.uid))
            {
                //非自动播放事件并且没有主动播放
                return;
            }
            if (!m_enableSpawnGameObject )
                return;
            if (me.mecanimEffect.loopfire)
            {
                var exists = m_effectList.Exists((ActionEffectData data) => { return data.Uid == me.mecanimEffect.uid; });
                if (exists) return;
            }
            AvatarAttachment bone = me.effect.attach;
            if (bone == AvatarAttachment.MainCamera)
            {
                if (GameScene.Instance.MainChar.Avatar.unityObject != attach)
                    return;
            }

            if (GameScene.Instance != null && GameScene.Instance.MainChar != null && GameScene.Instance.MainChar.Mount != null)
            {
                if (attach == GameScene.Instance.MainChar.Mount.Avatar.unityObject)
                {
                    if (GameScene.Instance.MainChar.IsInWater())
                    {
                        return;
                    }
                }
            }


            var uid = me.mecanimEffect.uid;
            var bindBone = me.effect.bindBone;// ea.bindBone;
            var bindBonePosition = me.effect.bindPosition;// ea.bindPosition;
            var positionOffset = me.effect.offset;// ea.posOffset;
            var rotationOffset = me.effect.rotate;// ea.rotOffset;
            var scale = me.effect.scale;

            //特效资源的路径和名称应该从传入的参数中解析得到，而不是硬性指定，资源可能位于不同的文件夹中
            string tFileName = me.effect.fxname;
            string tABPath = me.effect.fxpath;

            if (string.IsNullOrEmpty(tABPath))
                return;


            Load(tFileName, tABPath, (Object o) =>
            {
                if(attach == null)
                {
                    GameFXPool.FreeFX(o as GameObject);
                    LogHelper.LogWarningFormat("attcher have been destory.");
                    return;
                }

                GameObject go = o as GameObject;
                if (go != null)
                {
                    Transform bind = null;
                    if (bone == AvatarAttachment.MainCamera)
                        bind = ICameraHelper.Instance.MainCameraTransform;
                    else
                        bind = GetBone(attach.transform, bone);

                    bool isWeapon = false;
                    if (bind)
                    {
                        if (bindBone)
                        {
                            if (me.mecanimEffect.category == SpawnInstanceCategory.Weapon)
                            {
                                var srcnode = LuaFastCall.SearchChildTransform(go.transform, Bokura.AvatarAttachmentToBoneNode.WeaponAttachmentBone[(int)me.mecanimEffect.weaponAttachmentBone]);
                                if (srcnode)
                                {
                                    go.transform.SetParent(bind);
                                    var transform = srcnode.localToWorldMatrix.inverse * go.transform.localToWorldMatrix;
                                    go.transform.localPosition = transform.ExtractPosition();
                                    go.transform.localRotation = transform.ExtractRotation();
                                    isWeapon = true;
                                }
                            }

                            if(!isWeapon)
                            {
                                go.transform.SetParent(bind);
                                go.transform.localPosition = positionOffset;
                                go.transform.rotation = bind.rotation * Quaternion.Euler(rotationOffset);
                            }
                        }
                        else
                        {
                            var pos = bind.TransformPoint(positionOffset);
                            var rot = bind.rotation * Quaternion.Euler(rotationOffset);
                            go.transform.position = pos;
                            go.transform.rotation = rot;
                        }
                    }
                    else
                    {
                        LogHelper.LogWarningFormat("bing bone not found {0}.", bone);
                        var pos = attach.transform.TransformPoint(positionOffset);
                        var rot = attach.transform.rotation * Quaternion.Euler(rotationOffset);
                        go.transform.position = pos;
                        go.transform.rotation = rot;
                    }
                    go.transform.localScale = new Vector3(go.transform.localScale.x * scale.x, go.transform.localScale.y * scale.y, go.transform.localScale.z * scale.z);
                    go.SetActive(true);

                    ActionEffectData data = ActionEffectData.Get();

                    if (isWeapon)
                    {
                        data.EffectAnimator = go.GetComponentInChildren<Animator>();
                        e.context.avatar?.RefreshAllAnimator( RefreshAnimatorWay.Add,data.EffectAnimator);
                    }

                    data.context = me.context;
                    data.AttachAnimator = attach.GetComponentInChildren<Animator>();
                    data.Uid = uid;
                    data.AttachEntity = attach;
                    data.Effect = go;
                    data.BindBonePostion = bindBonePosition ? bind : null;
                    data.BindOffset = positionOffset;
                    data.Frame = Time.realtimeSinceStartup;
                    data.isDestroyAfterDuration = me.mecanimEffect.isDestroyAfterDuration;// ea.isDestroyAfterDuration;
                    data.customDuration = me.mecanimEffect.customDuration;
                    data.Duration = (float)me.duration;
                    data.fadeouttime = me.effect.fadeouttime;
                    data.category = me.mecanimEffect.category;
                    m_effectList.Add(data);
                }
            });
        }

        public void OnPlayAudioMaterial(GameObject attach, MecanimEvent e)
        {
            var ea = e._EventAction as PlayAudioFromMaterialAction;
            AvatarAttachment bone = ea.boneindex == 0 ? AvatarAttachment.LeftSole : AvatarAttachment.RightSole;
            var bind = GetBone(attach.transform, bone);
            if (bind)
            {
                var map_pos = bind.position + LayeredSceneLoader.WorldOffset;
                var fxName = IWorldMatLUT.Instance.getMaterialName(map_pos);
                AudioCtrl.PlayFootSteps(fxName, (uint)ea.eventID, attach); //根据材质播放音效
            }
        }

        public void OnSpawnFootprint(GameObject attach, MagicDataBase e)
        {
            if (GameScene.Instance != null && GameScene.Instance.MainChar != null)
            {
                if (GameScene.Instance.MainChar.isCurrCloudState())
                {
                    return;
                }
                //if (GameScene.Instance.MainChar.Avatar.unityObject == attach)
                //{
                //    GameScene.Instance.MainChar.FlockScare();
                //}
            }

            var me = e as Magic.MecanimFixEffectData;
            //var ea = e._EventAction as SpawnFootPrintAction;
            AvatarAttachment bone = me.effect.attach;// string.IsNullOrEmpty(ea.bindBoneName) ? AvatarAttachment.None : (AvatarAttachment)System.Enum.Parse(typeof(AvatarAttachment), ea.bindBoneName);
            var bind = GetBone(attach.transform, bone);
            if (bind)
            {
                var scale = me.effect.scale;
                var pos = bind.TransformPoint(me.effect.offset);
                var rot = bind.rotation * Quaternion.Euler(me.effect.rotate);
                var map_pos = pos.UnityToWorldVec();

                WaterMoveManager.Instance.CheckPlayerIsInWater(map_pos, pos);

                if ((!IWorldMatLUT.Instance.isInWater(map_pos)) && (!WeatherManager.Instance.isRaining()))
                {
                    var fxName = IWorldMatLUT.Instance.getFootFx(map_pos);
                    if (!string.IsNullOrEmpty(fxName))
                    {
                        Load(fxName, IResourceLoader.strBuffEffectPath, (Object o) =>
                        {
                            GameObject go = o as GameObject;
                            if (go != null)
                            {

                                go.transform.position = pos;
                                go.transform.rotation = rot;
                                go.transform.localScale = new Vector3(go.transform.localScale.x * scale.x, go.transform.localScale.y * scale.y, go.transform.localScale.z * scale.z);
                                go.SetActive(true);


                                ActionEffectData data = ActionEffectData.Get();
                                //data.e = e;
                                data.AttachAnimator = attach.GetComponentInChildren<Animator>();
                                data.Uid = me.mecanimEffect.uid;// ea.uid;
                                data.AttachEntity = attach;
                                data.Effect = go;
                                data.Frame = Time.realtimeSinceStartup;
                                data.customDuration = me.mecanimEffect.customDuration;// ea.customDuration;
                                data.Duration = (float)me.duration;// ea.DurationTime;
                                data.fadeouttime = me.effect.fadeouttime;
                                m_effectList.Add(data);
                            }
                        });
                    }
                }
            }

        }

        public void DestoryGameObject(GameObject go, int uid)
        {
            //LogHelper.LogWarning("this function is empty.");
            for (int i = m_effectList.Count - 1; i >= 0; i--)
            {
                if (m_effectList[i].AttachEntity == go && m_effectList[i].Uid == uid)
                {
                    m_effectList[i].Release();
                    m_effectList.RemoveAt(i);
                }
            }
        }


        public void OnPlayRadialPostProcess(GameObject go, MagicDataBase e)
        {
            var me = e as RadialBlurData;
            if(GameScene.Instance.MainChar.Avatar.unityObject == go)
            {
                GameScene.Instance.MainChar.StartRadialPostProcess(me.strength, (int)me.sampleCount, (float)me.duration,me.strengthCurve);
            }
        }

        public void OnPlayCameraAnimation(GameObject go, MecanimEvent e)
        {
            if (GameScene.Instance.MainChar.Avatar.unityObject == go)
            {
                var animator = go.GetComponentInChildren<Animator>();
                if (animator != null)
                    CameraController.Instance.PlayCameraAnimation(animator.transform,(e._EventAction as PlayCameraAnimationAction).clip);
            }
        }

        /// <summary>
        /// 清空指定对象的所有特效对象(角色创建和选择功能使用)
        /// </summary>
        public void StopActionEffect(GameObject go)
		{
			if (go == null) return;
			m_TempList.Clear();
			for (int tIdx = 0, tCount = m_effectList.Count; tIdx < tCount; tIdx++)
			{
				ActionEffectData tData = m_effectList[tIdx];
				if (tData.AttachEntity != go)
					m_TempList.Add(tData);
				else
				{
					//GameObject.Destroy(tData.Effect);
					tData.Release();
				}
			}
			m_effectList.Clear();
			List<ActionEffectData> tTmp = m_effectList;
			m_effectList = m_TempList;
			m_TempList = tTmp;
		}



		/// <summary>
		/// 清空数据，并销毁特效对象
		/// </summary>
		public void Clear()
		{
			for (int tIdx = 0, tCount = m_effectList.Count; tIdx < tCount; tIdx++)
			{
				ActionEffectData tData = m_effectList[tIdx];
				tData.Release(true);
			}
		}




        public void Update()
        {
            for (int i = m_effectList.Count -1 ; i >= 0; i--)
            {
                var effect = m_effectList[i];
                float detla = Time.realtimeSinceStartup - effect.Frame;

                if (!effect.isDestroyAfterDuration)
                {
                    //非自动剔除特效
                    effect.Update();
                    continue;
                }

                if (effect.customDuration)
                {
                    //超过美术剪辑的时长，删除特效
                    if (detla > effect.Duration)
                    {
                        effect.Release();
                        m_effectList.RemoveAt(i);
                        continue;
                    }
                }

                //动作切换了，删除特效
                
                if (effect.AttachAnimator != null)
                {
                    
                    var stateinfo = effect.AttachAnimator.GetCurrentAnimatorStateInfo(effect.context.layer);
                    var nextstateinfo = effect.AttachAnimator.GetNextAnimatorStateInfo(effect.context.layer);

                    //float normaltime = stateinfo.normalizedTime - (int)stateinfo.normalizedTime;
                    if (
                        stateinfo.fullPathHash != effect.context.fullPathHash
                        && nextstateinfo.fullPathHash != effect.context.fullPathHash
                        )
                    {
                        effect.Release();
                        m_effectList.RemoveAt(i);
                        continue;
                    }
                   
                }
                 
                //超过特效的最大持续时间（程序自定），删除特效
                //if (detla > m_delayDestroyDetlaTime)
                //{
                //    effect.Release();
                //    m_effectList.RemoveAt(i);
                //    continue;
                //}

                //角色删除时，特效也没了，但数据还在，先这么处理。
                if(effect.Effect == null || effect.AttachEntity == null)
                {
                    effect.Release();
                    m_effectList.RemoveAt(i);
                }
                effect.Update();
            }
            Utilities.ProfilerBegin("ActionEffectManager.UpdateCameraAnimation");
            UpdateCameraAnimation();
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("ActionEffectManager.UpdateMaterialProperty");
            UpdateMaterialProperty();
            Utilities.ProfilerEnd();
        }



        #region Material
        List<Entity> Dels = new List<Entity>();
        Dictionary<Entity, MaterialChangeEffectEx> entityMaterials = new Dictionary<Entity, MaterialChangeEffectEx>();
        public void OnPlayMaterialChange(GameObject go, MagicDataBase e)
        {
            var me = e as MaterialData;
            var entity = GameScene.Instance.GetEntityByGameObject(go);

            if (entity == null) { return; }
            if(!entityMaterials.ContainsKey(entity))
            {
                var change = MaterialChangeEffectEx.Get();                
                change.colour = me.colour * me.colourCurve.Evaluate(0);
                change.basecolor = me.colour;
                change.colourCurve = me.colourCurve;
                change.power = me.power;
                change.reset = false;
                change.isBody = me.isBody;
                change.isPrimaryWeapon = me.isPrimaryWeapon;
                change.isSecondaryWeapon = me.isSecondaryWeapon;

                change.isChangeMat = me.isChangeMat;
                change.changeMatName = me.changeMatName;
                change.tintColor = me.tintColor;
                change.dissolveThreshold = me.dissolveThreshold * me.dissolveThresholdCurve.Evaluate(0);
                change.dissolveColor = me.dissolveColor;
                change.edgeSize = me.edgeSize * me.edgeSizeCurve.Evaluate(0);
                change.basedissolveThreshold = me.dissolveThreshold;
                change.dissolveThresholdCurve = me.dissolveThresholdCurve;
                change.baseedgeSize = me.edgeSize;
                change.edgeSizeCurve = me.edgeSizeCurve;
                change.during = (float)me.duration;

                entity.MessageInvoke(change);
                entityMaterials.Add(entity, change);
                if(me.isChangeMat)
                {
                    change.loading = true;
                    ResourceHelper.LoadResourceAsync(IResourceLoader.strSharedMaterialPath, me.changeMatName,IResourceLoader.strMatSuffix, (UnityEngine.Object o) => {
                        change.loading = false;
                        if (o == null)
                            return;
                        //Bokura.LogHelper.Log("[ActionEffect]DoReplaceMaterial", go);

                        Bokura.Common.GameObjectMaterialReplacementExtensions.ReplaceMaterial(entity.Avatar.unityObject, o as Material, (GameObject go1) =>
                        {
                            bool isChange = false;
                            if (me.isBody && !go1.CompareTag(UserTags.PrimaryWeaponTag) && !go1.CompareTag(UserTags.SecondaryWeaponTag))
                            {
                                isChange = true;
                            }
                            if (me.isPrimaryWeapon && go1.CompareTag(UserTags.PrimaryWeaponTag))
                            {
                                isChange = true;
                            }
                            if (me.isSecondaryWeapon && go1.CompareTag(UserTags.SecondaryWeaponTag))
                            {
                                isChange = true;
                            }
                            return isChange;
                        });
                    });
                }
            }

        }

        void UpdateMaterialProperty()
        {
            foreach (var e in entityMaterials)
            {
                if (e.Value != null && e.Key != null)
                {
                    e.Value.lefttime += Time.deltaTime;
                    var normalize = e.Value.lefttime / e.Value.during;
                    if (e.Value.colourCurve != null)
                        e.Value.colour = e.Value.basecolor * e.Value.colourCurve.Evaluate(normalize);
                    else
                        LogHelper.LogWarning("MaterialProperty Color Curve is null.");

                    if (e.Value.edgeSizeCurve != null)
                        e.Value.edgeSize = e.Value.baseedgeSize * e.Value.edgeSizeCurve.Evaluate(normalize);
                    else
                        LogHelper.LogWarning("MaterialProperty edgeSize Curve is null.");

                    if (e.Value.dissolveThresholdCurve != null)
                        e.Value.dissolveThreshold = e.Value.basedissolveThreshold * e.Value.dissolveThresholdCurve.Evaluate(normalize);
                    else
                        LogHelper.LogWarning("MaterialProperty basedissolveThreshold Curve is null.");

                    if (normalize > 1.0f)
                    {
                        e.Value.reset = true;
                        //LogHelper.Log("[ActionEffect]end", e.Value.changeMatName, e.Value.loading, e.Key.Avatar);
                        if (e.Value.isChangeMat)
                        {
                            if (!e.Value.loading)
                            {
                                if (e.Key.Avatar != null)
                                    Bokura.Common.GameObjectMaterialReplacementExtensions.RecoverMaterial(e.Key.Avatar.unityObject);
                                else
                                    LogHelper.LogWarning("MaterialProperty Avatar.unityObject is null.");
                                Dels.Add(e.Key);
                            }
//                             else
//                                 LogHelper.Log("[ActionEffect]loading", e.Value.changeMatName);
                        }
                        else
                            Dels.Add(e.Key);
                    }
                    e.Key.MessageInvoke(e.Value);
                    //if (e.Value.reset) e.Value.Release();
                }
            }

            foreach (var e in Dels)
            {
                MaterialChangeEffectEx ex = null;
                if (entityMaterials.TryGetValue(e, out ex))
                {
                    ex.colour = Magic.MaterialBehaviour.DefaultColor;
                    ex.power = Magic.MaterialBehaviour.DefaultPower;
                    e.MessageInvoke(ex);

                    ex.Release();
                }
                entityMaterials.Remove(e);
            }
            Dels.Clear();
        }
        #endregion
        #region Camera Animation
        void UpdateCameraAnimation()
        {
            if(IsPlayCustomCameraAniamtion )
            {
                if(StartTime < CameraCurve.during)
                {
                    StartTime += Time.deltaTime;

                    float progress = StartTime / CameraCurve.during;

                    var offset = Vector3.SignedAngle(Vector3.forward, GameScene.Instance.MainChar.Avatar.unityObject.transform.forward, Vector3.up);
                    if (CameraCurve.isCameraRotateXCurve)
                        offset += CameraCurve.cameraRotateXCurve.Evaluate(progress);
                    var delta = offset - CameraController.Instance.RotateX;
                    if (delta > 180) delta -= 360;
                    if (delta < -180) delta += 360;
                    if (Mathf.Abs( delta) > 1 )
                        CameraController.Instance.RotateX += Mathf.Sign(delta) * 1;
                    else
                        CameraController.Instance.RotateX = offset;

                    if (CameraCurve.isCameraRotateYCurve && SysSettingModel.Instance.sharedData.iCameraMode != CameraMode.Mode2_5D)
                        CameraController.Instance.RotateY = CameraCurve.cameraRotateYCurve.Evaluate(progress);
                    if (CameraCurve.isCameraDistanceCurve)
                        CameraController.Instance.CurDistance = CameraCurve.cameraCurDistanceCurve.Evaluate(progress);
                    if (CameraCurve.isCameraFollowSmoothTimeCurve)
                        CameraController.Instance.FollowSmoothTime = CameraCurve.cameraFollowSmoothTimeCurve.Evaluate(progress);
                    if (CameraCurve.isCameraLookAtOffsetCurve)
                    {
                        var voffset = new Vector3(CameraCurve.cameraLookAtOffsetXCurve.Evaluate(progress), CameraCurve.cameraLookAtOffsetYCurve.Evaluate(progress), CameraCurve.cameraLookAtOffsetZCurve.Evaluate(progress));
                        CameraController.Instance.SetLookAtDetlaOffset(voffset);
                    }

                }
                else
                {
                    IsPlayCustomCameraAniamtion = false;
                    CameraController.Instance.BlockInput = false;
                    CameraController.Instance.FollowSmoothTime = LastCameraFollowSmoothTimeCurve;
                    CameraController.Instance.SetLookAtDetlaOffset(Vector3.zero);
                    if (CameraCurve != null && CameraCurve.isCameraDistanceCurve)
                        CameraController.Instance.ChangeDistanceTo(CameraCurve.cameraCurDistanceCurve.Evaluate(1)); 
                }

            }
        }
        public void StopCustomCameraAnimation()
        {
            IsPlayCustomCameraAniamtion = false;
            CameraController.Instance.BlockInput = false;
            CameraController.Instance.FollowSmoothTime = LastCameraFollowSmoothTimeCurve;
            CameraController.Instance.SetLookAtDetlaOffset(Vector3.zero);
        }
        float StartTime = 0;
        float LastCameraFollowSmoothTimeCurve = 0;
        bool IsPlayCustomCameraAniamtion = false;
        PlayCustomCameraAniamtionAction CameraCurve = null;
        //float RotateCharOffset = 0;
        void OnPlayCustomCameraAniamtion(GameObject go, MecanimEvent e)
        {
            if (go != GameScene.Instance.MainChar.Avatar.unityObject)
                return;
            if (!SysSettingModel.Instance.sharedData.bCameraQingKung)
                return;

            StartTime = 0;
            //RotateCharOffset = Vector3.SignedAngle(Vector3.forward, go.transform.forward, Vector3.up);
            IsPlayCustomCameraAniamtion = true;
            CameraController.Instance.BlockInput = true;
            LastCameraFollowSmoothTimeCurve = CameraController.Instance.FollowSmoothTime;
            CameraCurve = e._EventAction as PlayCustomCameraAniamtionAction;
        }
        #endregion

        public static void ForeachChildRecurvise(Transform t, UnityAction<Transform> action)
        {
            action(t);
            for (int i = 0; i < t.childCount; i++)
            {
                ForeachChildRecurvise(t.GetChild(i), action);
            }
        }
        public static Transform GetBone(Transform entity, AvatarAttachment bone)
        {
            var bonestr = Bokura.AvatarAttachmentToBoneNode.CharacterAttachmentBone[(int)bone];
            return Game.LuaFastCall.SearchChildTransform(entity, bonestr);
        }

        #region 控制播放时机
        ////不自动播放的事件uid列表
        //public static int[] m_nonAutoPlayActionUids = new int[1]
        //{
        //    -819656926
        //};
        //public bool INonAutoPlay(int uid)
        //{
        //    for (int i = 0; i < m_nonAutoPlayActionUids.Length; i++)
        //    {
        //        if (uid == m_nonAutoPlayActionUids[i]) return true;
        //    }
        //    return false;
        //}

        //正在播放的非自动事件uid列表
        public static List<int> m_forcePlayActionUids;
        public static List<int> ForcePlayActionUids
        {
            get
            {
                if (m_forcePlayActionUids == null)
                {
                    m_forcePlayActionUids = new List<int>(32);
                }
                return m_forcePlayActionUids;
            }
        }
        public bool IsForcePlayActionEventByUID(int uid)
        {
            return ForcePlayActionUids.Contains(uid);
        }
        //非自动事件开始播放
        public void StartForcePlayActionEvent(int uid)
        {
            ForcePlayActionUids.Add(uid);
        }
        //非自动事件停止播放
        public void StopForcePlayActionEvent(int uid)
        {
            ForcePlayActionUids.Remove(uid);
            
            for (int i = m_effectList.Count - 1; i >= 0; i--)
            {
                if (m_effectList[i].Uid == uid)
                {
                    m_effectList[i].Release();
                    //GameFXPool.FreeFX(m_effectList[i].Effect);
                    m_effectList.RemoveAt(i);
                }
            }
        }
        #endregion
    }
}