﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class EffectElement
    {
        private GameObject m_unityObject;

        private Animator m_gameAnimator;//动画文件

        private AnimationKey m_gameAnimationKey;//动画关键帧控件

        private LoadCallback m_endFuc;

        public GameObject UnityOgject
        {
            get
            {
                return m_unityObject;
            }
        }

        public void Load(string strPathFolder,string strModelName, LoadCallback _fuc)
        {
            ResourceHelper.LoadPrefabAsync(strPathFolder, strModelName,(UnityEngine.Object o) =>
            {
                if (o != null)               
                {
                    m_unityObject = GameObject.Instantiate(o) as GameObject;
                }

                

                if (m_unityObject)
                {
                    //m_gameInstance.SetActive(false);
                    m_gameAnimator = m_unityObject.GetComponent<Animator>();

                    m_gameAnimationKey = m_unityObject.GetComponent<AnimationKey>();
                    if (m_gameAnimationKey != null)
                    {
                        m_gameAnimationKey.procKeyStringEvent = (gameObject, keyName) =>
                        {
                            if (keyName == "end")
                            {
                                //动画结束
                                if(m_endFuc != null)
                                {
                                    m_endFuc(m_unityObject);
                                }
                                Destory();
                            }
                        };
                    }
                }
                _fuc(m_unityObject);
            });
        }

        public void SetEndFuc(LoadCallback _fuc)
        {
            m_endFuc = _fuc;
        }

        public void Play(string _animName)
        {
            if (m_gameAnimator)
            {
                m_gameAnimator.Play(_animName);
            }
        }

        public void Destory()
        {
            m_endFuc = null;
            SetParent(null);
            if (m_unityObject)
            {
                UnityEngine.Object.Destroy(m_unityObject);
                m_unityObject = null;
            }
            m_gameAnimator = null;
            m_gameAnimationKey = null;
            //IUILoader.Instance.Unload(m_animationPath);
        }

        public void SetParent(Transform parent)
        {
            if(m_unityObject)
            {
               m_unityObject.transform.SetParent(parent, false);
            }
        }

        public void SetParentByGameObject(GameObject gParent)
        {
            SetParent(gParent.transform);
        }
    }
}
