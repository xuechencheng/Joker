﻿namespace Bokura
{
    public class EffectFactory : ClientSingleton<EffectFactory>
    {

        public delegate void CallBackCreateEffect(EffectElement obj);
        public void CreateEffect(string strPathFolder, string strModelName, CallBackCreateEffect _fuc)
        {
            EffectElement el = new EffectElement();
            el.Load(strPathFolder, strModelName, (UnityEngine.Object o) =>
            {
                if (o == null)
                {
                    _fuc(null);
                }
                else
                {
                    _fuc(el);
                }
            });
        }
    }
}
