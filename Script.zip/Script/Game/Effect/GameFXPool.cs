using UnityEngine;
using Bokura;

namespace Bokura
{
    public class GameFXPool
    {
        static public void LoadFX(string strAssetBundlePath, string strName, LoadCallback callback)
        {
            IParticleSystem.Instance.LoadFX(strAssetBundlePath, strName, callback);
        }

        static public GameObject CreateFX(UnityEngine.Object o, Vector3 pos, Quaternion rot, Entity ety)
        {
            var type = GetEntityFilterType(ety);
            return IParticleSystem.Instance.CreateEffectObject(o as GameObject, pos, rot, type);
        }

        static public GameObject CreateFX(UnityEngine.Object o, Entity ety)
        {
            return CreateFX(o, Vector3.zero, Quaternion.identity, ety);
        }

        static FilterType GetEntityFilterType(Entity ety)
        {
            FilterType type = FilterType.NONE;
            MovableEntity mety = ety as MovableEntity;
            if (mety != null)
            {
                if(mety.IsQingKung())
                {
                    type |= FilterType.SPACE_IN_SKY;
                }
            }

            return type;
        }

        static public void FreeFX(GameObject go)
        {
            IParticleSystem.Instance.FreeEffectObject(go);
        }

    }
}
