﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using Bokura;

namespace Bokura
{
    class TriggerComponent : MonoBehaviour
    {
        public class TriggerEnterEvent : GameEvent<Collider>
        {

        }
        public GameEvent<Collider> onRefreshMapEntityData = new TriggerEnterEvent();
        public void OnTriggerEnter(Collider other)
        {
            onRefreshMapEntityData.Invoke(other);
        }


        static public TriggerComponent Get(GameObject go)
        {
            TriggerComponent ob = go.GetComponent<TriggerComponent>();
            if (ob == null) ob = go.AddComponent<TriggerComponent>();
            return ob;

        }
    }
}
