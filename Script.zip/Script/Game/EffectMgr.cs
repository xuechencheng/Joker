using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{

	//目前简易处理，后续优化
	class EffectMgr : ClientSingleton<EffectMgr>
	{
		const float EffectLifeTime = 5.0f;
        #region 内部结构
        public class AnimEvent
        {
            public int CurrentAnimID;
            public int NextAnimID;
            public float StartTime;
            public bool Showed = false;
            public bool Stoped = false;
            public float Delay;
			public float AnimTime = 0.0f;

			int m_updateCount = 0;
            public float CreateTime = 0.0f;
            //public Animator animator;
            public Entity entity;

			public virtual bool stopByAnimDone
			{
				get { return true; }
			}

            const float m_showDiff = 0.3f;

            public virtual void Show() { }
            public virtual void Stop() { }
            public virtual bool isStop() { return Stoped; }
            public virtual void Update()
            {
				m_updateCount++;
                if (NextAnimID == 0)
                {
                    if(!Showed)
                    {
                        var time = Time.time - CreateTime;
                        if (time >= Delay && time < Delay + m_showDiff)
                        {
                            //LogHelper.Log("show effect:" + time + " " +Delay);
                            Show();

                        }
                    }
 
                    return;

                }
                if (entity == null || entity.Avatar == null || (entity.Avatar.animator == null))
                {
                    Stop();
                    return;
                }
                

                var stateinfo = entity.Avatar.GetCurrentAnimatorStateInfo(0);
                var nextinfo = entity.Avatar.GetNextAnimatorStateInfo(0);
		
	
                if (!Showed && (nextinfo.shortNameHash == NextAnimID || stateinfo.shortNameHash == NextAnimID || NextAnimID==0))
                {
                    float normalizetime;
                    float time;
                    if (nextinfo.shortNameHash == NextAnimID)
                    {
						if (AnimTime == 0.0f)
							AnimTime = nextinfo.length;
						//var clipinfo = entity.Avatar.animator.GetCurrentAnimatorClipInfo(0);

						normalizetime = nextinfo.normalizedTime - (int)nextinfo.normalizedTime;
						time = normalizetime * AnimTime ;

					}
                    else
                    {
						if (AnimTime == 0.0f)
							AnimTime = stateinfo.length;
						normalizetime = stateinfo.normalizedTime - (int)stateinfo.normalizedTime;
                        time = normalizetime * AnimTime ;

					}

					if (time >= Delay && time < Delay + m_showDiff)
                    {
                        //LogHelper.Log("show effect:" + time + " " +Delay);
						Show();

                    }
                }
				else if(Showed && (stopByAnimDone))
				{
					if (stateinfo.shortNameHash != NextAnimID && nextinfo.shortNameHash != NextAnimID)
					{
						if (entity.Avatar.animator.MainAnimator != null && entity.Avatar.animator.MainAnimator.layerCount == 1)
							Stop();
						else
						{
							var stateinfo1 = entity.Avatar.GetCurrentAnimatorStateInfo(1);
							if (stateinfo1.shortNameHash != CurrentAnimID && stateinfo1.shortNameHash != NextAnimID)
							{
								Stop();
							}
						}
						return;
					}
				}
				else if(!Showed && m_updateCount>10) //错过了对应动作 直接stop
				{
					Stop();
				}

            }
        }

        public class EffectInfoGroup
        {
            EffectInfo[] m_infos;
            public EffectInfoGroup(int count)
            {
                m_infos = new EffectInfo[count];
            }
            public void Stop()
            {
                for(int i = 0; i < m_infos.Length; i ++ )
                {
                    m_infos[i]?.Stop();
                    if (m_infos[i] != null)
                    {
                        if(m_infos[i].material != null)
                            m_infos[i].material.Stop();

                        if (m_infos[i].radialblur != null) {
                            m_infos[i].radialblur.Stop();
                        }
                    }
                }
            }
            public void SetMaterial(int idx, BuffMaterialConfigWrap material)
            {
                m_infos[idx].material = material;
            }

            public void SetRadialBlur(int idx, RadialBlurConfigWrap radiablur) {
                m_infos[idx].radialblur = radiablur;
            }
            public void Set(int idx, EffectInfo ei)
            {
                m_infos[idx] = ei;
            }

            public bool Visible
            {
                set
                {
                    for (int i = 0; i < m_infos.Length; i++)
                    {
                        if(m_infos[i]!=null)
                        {
                            m_infos[i].Visible = value;
                        }
                    }
                }
            }
        }

        public class EffectInfo : AnimEvent
        {
			public GameObject effect;
			public Entity target;
            public Vector3 targetPos;
            public ISkillConfig.Effect effectInfo;
			public float offsety = 0.0f;
            public bool isbullet = false;
            public float bulletfadespeed = 0.06f;
            public Quaternion firstQuaternion;
            public bool m_bIsVisible = true;
            public BuffMaterialConfigWrap material;
            public RadialBlurConfigWrap radialblur;

            public bool Visible
            {
                get
                {
                    return effect ? effect.activeSelf : false;
                }
                set
                {
                    m_bIsVisible = value;
                    if (effect)
                        effect.SetActive(value);
                }
            }
            public override bool stopByAnimDone
			{
				get
				{
					return effectInfo.fade == ISkillConfig.Effect.FadeType.FadeAction;
				}
			}
			public override void Stop()
            {
                if (effect)
				{
                    if ((effectInfo != null && effectInfo.fadeoutTime>0.0f) || isbullet)
                    {
                        if(isbullet)
                            Bokura.Particle.X2ParticleFadeOut.Instance.FadeOut(effect,null, bulletfadespeed);
                        else
                            Bokura.Particle.X2ParticleFadeOut.Instance.FadeOut(effect, null, 1/(30.0f*effectInfo.fadeoutTime));
                    }
                    else
                        GameFXPool.FreeFX(effect);
                    effect = null;
				}
				Stoped = true;
			}
            public override void Show()
            {
                if (Showed)
                    return;
                StartTime = Time.time;
                //if(effect!=null)
                //	effect = GameObject.Instantiate(effect) as GameObject;
                UpdateEffectPos();
                Showed = true;
            }

			public override void Update()
			{
				base.Update();
                if(effect != null && effectInfo.BindAttach && effectInfo.Bindmode  == ISkillConfig.BindMode.OnlyPosition)
                {
                    effect.transform.rotation = firstQuaternion;
                }
				if (effect!=null && effectInfo.attachobject == (int)ISkillConfig.Effect.AttachObjectType.CASTER_TARGET_LINK && target.Avatar!=null)
				{
					var srcpos = entity.Avatar.GetAttachmentTransform(AvatarAttachment.Spine).position;
					var destt = target.Avatar.GetAttachmentTransform(AvatarAttachment.Spine);
					Vector3 destpos;
					if (destt != null)
						destpos = destt.position;
					else
						destpos = target.LocalPosition;

					var dir = destpos - srcpos;
					var len = dir.magnitude;
					dir.Normalize();
					effect.transform.rotation = Quaternion.LookRotation(dir);
					effect.transform.position = srcpos;
					effect.transform.localScale = new Vector3(1.0f,1.0f,len);
				}
				if (Showed && effectInfo.fade == ISkillConfig.Effect.FadeType.FadeLifeTime)
				{
					if (Time.time - StartTime > effectInfo.lefttime)
					{
						Stop();
					}
				}

			}

			public void UpdateEffectPos()
            {
                if (effect != null)
                {
                    if (m_bIsVisible)
                    {
                        if (!effect.activeSelf)          //避免重复激活组件，导致基于事件模式的音效等播放两次
                            effect.SetActive(true);
                    }
                    else
                    {
                        if (effect.activeSelf)          //避免重复激活组件，导致基于事件模式的音效等播放两次
                            effect.SetActive(false);
                    }

                    effect.transform.localPosition += effectInfo.offset;
                    effect.transform.localRotation = Quaternion.Euler(effectInfo.rotate);
                    var newscale = effect.transform.localScale;
                    newscale.x *= effectInfo.scale.x;
                    newscale.y *= effectInfo.scale.y;
                    newscale.z *= effectInfo.scale.z;

                    effect.transform.localScale = newscale;

					if (effectInfo.attachobject == (int)ISkillConfig.Effect.AttachObjectType.TARGET_POS)
                    {
                        effect.transform.position = effectInfo.offset + targetPos;

                    }
                    else if(effectInfo.attachobject != (int)ISkillConfig.Effect.AttachObjectType.CASTER_TARGET_LINK)
					{
						var attachentity = effectInfo.attachobject == (int)ISkillConfig.Effect.AttachObjectType.CASTER ? entity : target;
						if (attachentity != null)
						{
							if (attachentity.Avatar != null && effectInfo.attach != AvatarAttachment.None)
							{
                                var attachnode = attachentity.Avatar.GetAttachmentTransform(effectInfo.attach);
                                if (effectInfo.attach == AvatarAttachment.MainCamera) {
                                    attachnode = CameraController.Instance.CameraEffectRoot.transform;
                                }
								
								if (attachnode)
								{
									if (effectInfo.BindAttach)
									{
										effect.transform.SetParent(attachnode, false);
										effect.transform.localPosition = (effectInfo.offset + new Vector3(0, offsety, 0));
									}
									else
									{
										effect.transform.position = attachnode.transform.position + attachnode.transform.rotation*(effectInfo.offset+new Vector3(0, offsety,0));
										effect.transform.localRotation = attachnode.transform.rotation * effect.transform.localRotation;
									}
								}
								else if(attachentity.Avatar.unityObject)
								{
									if (effectInfo.BindAttach)
									{
										effect.transform.SetParent(attachentity.Avatar.unityObject.transform, false);
										effect.transform.localPosition = (effectInfo.offset + new Vector3(0, offsety, 0));
									}
									else
									{
										effect.transform.position = attachentity.Avatar.unityObject.transform.rotation* (effectInfo.offset + new Vector3(0, offsety, 0)) + attachentity.LocalPosition;
										effect.transform.localRotation = attachentity.Avatar.unityObject.transform.rotation * effect.transform.localRotation; ;
									}
								}
							}
							else
							{
								if(attachentity.Avatar != null && attachentity.Avatar.unityObject)
								{
									if (effectInfo.BindAttach)
									{
										effect.transform.SetParent(attachentity.Avatar.unityObject.transform, false);
										effect.transform.localPosition = effectInfo.offset;
									}
									else
									{
										effect.transform.position = attachentity.Avatar.unityObject.transform.rotation * effectInfo.offset + attachentity.LocalPosition;
									}
								}
								
								effect.transform.rotation = Quaternion.Euler(0.0f, attachentity.DirAngle, 0.0f) * effect.transform.rotation;
							}
						}

					}

                    firstQuaternion = effect.transform.rotation;
                }
            }

        }

        public class CameraShakeConfigWrap : AnimEvent
        {
            //public ISkillConfig.CameraShakeConfig config;
            public float ShakeTime;
            public float Fps;
            public float ShakeDetla;
            private float m_frameTime;
            public Camera camera;
            private Transform tr;
            public bool isAutoStop = false;

            public override bool stopByAnimDone
            {
                get
                {
                    return isAutoStop;
                }
            }
            public override void Show()
            {
                if (Showed)
                    return;
                StartTime = Time.time;
                m_frameTime = 0;
                camera = Bokura.ICameraHelper.Instance.MainCamera;
                Showed = true;
                if (camera == null)
                    Stoped = true;
                else
                {
                    tr = camera.transform;
                }
            }
            public override void Stop()
            {
                //Stoped = true;
            }
            public override void Update()
            {
                base.Update();
                if (!tr)
                    return;
                if (Showed && camera != null)
                {
                    if (ShakeTime > 0)
                    {
                        ShakeTime -= Time.deltaTime;
                        m_frameTime += Time.deltaTime;
                        if (m_frameTime > 1.0 / Fps)
                        {
                            m_frameTime = 0;
                            tr.position = tr.position + UnityEngine.Random.insideUnitSphere * (ShakeDetla * 10);
                        }

                    }
                    else
                    {
                        Stoped = true;
                    }
                }
            }
        }

        public class MaterialShaderConfigWrap : AnimEvent
        {
            public float time;
            public float power;
            public Color color;
            public Entity enemy;
          //  private MaterialPropertyBlock block = new MaterialPropertyBlock();
            public override void Show()
            {
                if (enemy != null)
                {
                    enemy.SetMaterialProperty("_RimColor", color);
                    enemy.SetMaterialProperty("_RimPower", power);
                }
                Showed = true;
            }
            public override void Stop()
            {

			}
			public override bool isStop() { return Stoped; }
            public override void Update()
            {
                //base.Update();
                if (enemy == null)
                {
                    Stoped = true;
                    return;
                }
                if (Showed)
                {
                        time -= Time.deltaTime;
                    if(time < 0)
                    {
						color -= color * 0.1f;
						//block.SetColor("_RimColor", color);

						enemy.SetMaterialProperty("_RimColor", color);
						if (time < -1f)
						{
							enemy.SetMaterialProperty("_RimColor", new Color(0, 0, 0, 1));
							enemy.SetMaterialProperty("_RimPower", 1f);
							Stoped = true;
						}

					}
				}
            }
        }
        public class FlowMaterialConfigWarp : AnimEvent
        {
            public float time;
            public string tex;
            public Texture2D tex2d;
            public Color color;
            public float strength;
            public Vector2 speed = new Vector2(0, 1);
            public Vector2 uv = new Vector2(0.5f, 0.5f);
            public Vector4 factor = new Vector4();
            public override void Show()
            {
                entity.SetMaterialKeyWord("_X2M_FLOW_ON",true);
                //entity.SetMaterialProperty("_FlowEnabled", 1);
                entity.SetMaterialProperty("_FlowColor", color);
                entity.SetMaterialProperty("_FlowStrength", strength);
                entity.SetMaterialProperty("_FlowFactor", factor);
                if (tex2d) entity.SetMaterialProperty("_FlowEffectMap", tex2d);

                Showed = true;
            }
            public override void Stop()
            {
                //Stoped = true;
            }
            public override bool isStop() { return Stoped; }

            public override void Update()
            {
                base.Update();
                if (Showed)
                {
                    time -= Time.deltaTime;
                    if (time < 0)
                    {
                        entity.SetMaterialKeyWord("_X2M_FLOW_ON", false);
                        //entity.SetMaterialProperty("_FlowEnabled", 1);
                        Stoped = true;
                    }
                }
            }
        }
        public class BuffMaterialConfigWrap : AnimEvent
        {
            public float time;
            public float power;
            public Color color;
            public AnimationCurve colourCurve = AnimationCurve.Linear(0, 1, 1, 1);//衰减曲线
            public Entity enemy;
            //  private MaterialPropertyBlock block = new MaterialPropertyBlock();
            public override void Show()
            {
                if (enemy != null)
                {
                    enemy.SetMaterialProperty("_RimColor", color);
                    enemy.SetMaterialProperty("_RimPower", power);
                }
                Showed = true;
            }
            public override void Stop()
            {
                Showed = false;
                Stoped = true;
                if (enemy != null)
                {
                    enemy.SetMaterialProperty("_RimColor", new Color(0, 0, 0, 1));
                    enemy.SetMaterialProperty("_RimPower", 1f);
                }
            }
            public override bool isStop() { return Stoped; }
            public override void Update()
            {
                //base.Update();
                if (enemy == null)
                {
                    Stoped = true;
                    return;
                }
                if (Showed)
                {
                    CreateTime += Time.deltaTime;
                    enemy.SetMaterialProperty("_RimColor", color * colourCurve.Evaluate(CreateTime / time));
                    if (CreateTime >= time)
                    {
                        enemy.SetMaterialProperty("_RimColor", new Color(0, 0, 0, 1));
                        enemy.SetMaterialProperty("_RimPower", 1f);
                        Stoped = true;
                    }
                }
            }
        }

        public class RadialBlurConfigWrap : AnimEvent
        {
            public float time;
            public float strength;
            public int samplecount;
            public float radialBlurRadialStrength;
            public float radialBlurRadialRadius;
            public Vector2 radialBlurCenter;
            UnityEngine.Rendering.PostProcessing.PostProcessVolume volume;
            public override void Show()
            {
                //if(entity.IsMainCharacter())
                //{
                //    (entity as MainCharacter).StartRadialPostProcess(strength, samplecount, time);
                //}
                StartTime = Time.time;

                var blur = ScriptableObject.CreateInstance<UnityEngine.Rendering.PostProcessing.RadialBlur>();
                blur.enabled.Override(true);
                blur.blurEnable.Override(true);
                blur.radialBlurStrength.Override(strength);
                blur.radialBlurSamples.Override((int)(samplecount));
                blur.radialBlurRadialStrength.Override(radialBlurRadialStrength);
                blur.radialBlurRadialRadius.Override(radialBlurRadialRadius);
                blur.radialBlurCenter.Override(radialBlurCenter);

                //setting = blur;
                volume = UnityEngine.Rendering.PostProcessing.PostProcessManager.instance.QuickVolume(0, 100, blur);

                Showed = true;
                Stoped = true;
            }
            public override void Stop()
            {
                if (volume) {
                    UnityEngine.Rendering.PostProcessing.RuntimeUtilities.Destroy(volume.gameObject);
                }
                //Stoped = true;
            }
            public override bool isStop() { return Stoped; }

        }
        #endregion
        Queue<AnimEvent> m_playlist = new Queue<AnimEvent>();
		HashSet<AnimEvent> m_skillEffectList = new HashSet<AnimEvent>();
		List<AnimEvent> m_needRemoveSkillEffectList = new List<AnimEvent>();
		float m_updateCD;
		public EffectInfo Play(string effectname, Entity ety, AvatarAttachment attach = AvatarAttachment.Root, string effectDirectory = null, bool autodelete = true, float scale = 1)
		{
            if (string.IsNullOrEmpty(effectname))
				return null;
			EffectInfo info = new EffectInfo();
			var path = System.IO.Path.GetFileNameWithoutExtension(effectname);
			var directory = string.IsNullOrEmpty(effectDirectory) ? IResourceLoader.strSkillEffectPath : effectDirectory;
            GameFXPool.LoadFX(directory, path, (UnityEngine.Object o) =>
			{
				if(o)
				{
					if (info.Stoped)
						return;
					info.StartTime = Time.time;
                    info.CreateTime = Time.time;
                    info.effect = GameFXPool.CreateFX(o, ety);
                    if (info.effect!=null)
					{
						//TODO: 这里效率有点低需要优化
						var trailtrenders = info.effect.GetComponentsInChildren<TrailRenderer>();
						if (trailtrenders != null)
						{
							for (int i = 0; i < trailtrenders.Length; i++)
							{
								if (trailtrenders[i])
									trailtrenders[i].Clear();
							}
						}
						info.effect.SetActive(info.m_bIsVisible);

                        if (attach == AvatarAttachment.MainCamera)
                        {
                            info.effect.transform.SetParent(CameraController.Instance.CameraEffectRoot.transform, false);
                            //info.effect.transform.localPosition += Vector3.forward * 0.8f;
                        }
                        else
                        {
                            if (ety != null)
                            {
                                if (ety.Avatar != null && ety.Avatar.unityObject)
                                {
                                    var parentnode = ety.Avatar.GetAttachmentTransform(attach);
                                    if (parentnode != null)
                                        info.effect.transform.SetParent(parentnode, false);
                                    else
                                        info.effect.transform.SetParent(ety.Avatar.unityObject.transform, false);
                                }
                                else
                                {
                                    info.effect.transform.position = ety.LocalPosition;
                                }

                            }
                        }
                        info.effect.transform.localScale = Vector3.one * scale;

                        if (autodelete)
							m_playlist.Enqueue(info);
					}
					
				}
				else
				{
                    LogHelper.LogWarning("effect not found!:" , path);

				}

			});
			return info;
		}

		public EffectInfo Play(ISkillConfig.Effect effect, int nAnimID, Entity ety)
		{
			return Play(effect, nAnimID, ety, Vector3.zero,null);
		}

        public EffectInfoGroup PlayByConfig(string effectConfigName, Entity ety)
        {
            
            var config = loadEffectConfig(effectConfigName);
            if(config!=null && config.effects!=null && config.effects.Count>0)
            {
                EffectInfoGroup ge = new EffectInfoGroup(config.effects.Count);
                for (int i = 0; i < config.effects.Count; i++)
                {
                    ge.Set(i, Play(config.effects[i], 0, ety));

                    if (config.effects[i].materialChange != null)
                    {
                        ge.SetMaterial(i, EffectMgr.Instance.Play(config.effects[i].materialChange, ety));
                    }

                    //if configured GrassAnimation call and play
                    if (config.effects[i].grassData.hasGrassAnimation)
                    {
                        CastGrassAnimation(config.effects[i].grassData, ety.LocalPosition);
                        
                    }

                    if (config.effects[i].radialBlur.hasRadialBlur && ety.IsMainCharacter()) {
                        ge.SetRadialBlur(i, EffectMgr.Instance.Play(config.effects[i].radialBlur, 0, ety));
                        // var data = config.effects[i].radialBlur;
                        //LogHelper.LogError("设置雷达模糊");
                    }
                }
                return ge;
            }
            else
            {
                if(config==null)
                {
                    LogHelper.LogWarning("PlayByConfig Not Found!", effectConfigName);
                }
                else
                {
                    LogHelper.LogWarning("PlayByConfig Effect Empty!", effectConfigName);

                }
            }
            return null;
        }

        private void CastGrassAnimation(CritiasFoliage.CutoffGrassAnimateData data, Vector3 pos)
        {//cmj
         //call OnAttackGrass()
            CritiasFoliage.FoliageTileManager.Instance.m_interactiveMap.CastGrassAnimateBindEffect(data, pos);
        }

        static public bool IsEffectFilted(int filterType, int[] buffidlist, Entity ety)
		{

			if (filterType != (int)FilterType.NONE )
			{
				MovableEntity mve = ety as MovableEntity;
				if (mve == null)
					return false;

				int spacefilter = filterType & (int)FilterType.SPACE_MASK;
				if (spacefilter != 0)
				{
					if (mve.IsFlying)
					{
						if ((spacefilter & (int)FilterType.SPACE_IN_SKY) == 0)
							return true;
					}
					else
					{
						if ((spacefilter & (int)FilterType.SPACE_IN_LAND) == 0)
							return true;
					}
				}



				int bufffiler = filterType & (int)FilterType.BUFF_MASK;
				if (buffidlist != null)
				{
					bool exist = false;
					for (int i = 0; i < buffidlist.Length; i++)
					{
						if (ety.BuffProxy.GetBuffOverlapCountByBaseID(buffidlist[i]) > 0)
						{
							exist = true;
							break;
						}
					}

					if (bufffiler == (int)FilterType.EXIST_BUFF)
					{
						if (!exist)
							return true;
					}
					else if (bufffiler == (int)FilterType.NOT_EXIST_BUFF)
					{
						if (exist)
							return true;
					}
				}

			}
			return false;
		}

		public EffectInfo Play(ISkillConfig.Effect effect, int nAnimID, Entity ety, Vector3 targetPos, Entity target, float offsety = 0)
		{
			if (effect == null || string.IsNullOrEmpty(effect.path))
				return null;

			if (IsEffectFilted(effect.filterType, effect.buffidlist, effect.buffFilterByWho == ISkillConfig.FilterByWho.BY_CASTER ? ety : target))
				return null;

            EffectInfo info = new EffectInfo();
            if (effect.attach == AvatarAttachment.MainCamera && !ety.IsMainCharacter())
            {
                //LogHelper.LogError("镜头特效只有主角播放");
                return info;
            }
            //LogHelper.Log("play effect" + effect.path);

            var path = effect.path;// System.IO.Path.GetFileNameWithoutExtension(effect.path);

			if (ety != null && ety.Avatar!=null && ety.Avatar.animator!=null)
				info.CurrentAnimID = ety.Avatar.GetCurrentAnimatorStateInfo(0).shortNameHash;
			else
				info.CurrentAnimID = 0;
			info.NextAnimID = nAnimID;
			info.entity = ety;
			info.effectInfo = effect;
			info.targetPos = targetPos;
			info.target = target;
			info.Delay = effect.delay;
			info.offsety = offsety;
            info.CreateTime = Time.time;
            //if (effect.attach == AvatarAttachment.End)
            //{
            //	LogHelper.LogError("Attach error!" + effect.path);
            //}
            //info.stopByAnimDone = effect.stopByAnimDone;
            //LogHelper.Log("play effect:" + effect.path + " delay:" + info.Delay);

            GameFXPool.LoadFX(IResourceLoader.strEffectPath, path, (UnityEngine.Object o) =>
			{
				if (o == null)
				{
                    LogHelper.LogWarning("effect not found!:", path);
					return;
				}

				if (info.Stoped)
					return;


				//info.startTime = Time.time;
				Vector3 pos = Vector3.zero;
				if(effect.attachobject == 0 )
				{
					if (ety != null)
						pos = ety.LocalPosition;
				}
				else if(effect.attachobject == 1)
				{
					if (target != null)
						pos = target.LocalPosition;
				}

                info.effect = GameFXPool.CreateFX(o, pos, Quaternion.identity, ety);
				if(info.effect==null)
				{
                    LogHelper.LogWarning("effect not found!:", path);
					return;
				}
					var showinfo = info;
				if (!showinfo.Showed)
					info.effect.SetActive(false);
				else
					info.UpdateEffectPos();

			});
			if((nAnimID ==0 || ety == null )&&info.Delay==0.0f&&info.effectInfo.fade == ISkillConfig.Effect.FadeType.FadeLifeTime)
			{
				info.Show();
				m_playlist.Enqueue(info);
			}
			else
			{
				m_skillEffectList.Add(info);

			}

			return info;
		}
        public CameraShakeConfigWrap Play(ISkillConfig.CameraShakeConfig shakeconfig, int nAnimID, Entity ety)
        {
            if (IsEffectFilted(shakeconfig.filterType, null, ety ))
                return null;

            CameraShakeConfigWrap info = new CameraShakeConfigWrap();
            if (ety != null && ety.Avatar != null && ety.Avatar.animator != null)
                info.CurrentAnimID = ety.Avatar.GetCurrentAnimatorStateInfo(0).shortNameHash;
            else
                info.CurrentAnimID = 0;
            info.NextAnimID = nAnimID;
            info.entity = ety;

            info.isAutoStop = shakeconfig.IsAutoStop;
            info.ShakeDetla = shakeconfig.ShakeDetla;
            info.ShakeTime = shakeconfig.ShakeTime;
            info.Fps = shakeconfig.Fps;
            info.Delay = shakeconfig.DelayTime;

            if ((nAnimID == 0 || ety == null)&&info.Delay==0.0f)
            {
                info.Show();
                m_playlist.Enqueue(info);
            }
            else
            {
                m_skillEffectList.Add(info);

            }
            return info;
        }
        public MaterialShaderConfigWrap Play(Bokura.ISkillConfig.HurtMaterialConfig config, Entity enemy)
        {

            MaterialShaderConfigWrap info = new MaterialShaderConfigWrap();
            //if (ety != null && ety.Avatar != null && ety.Avatar.animator != null)
            //    info.CurrentAnimID = ety.Avatar.animator.GetCurrentAnimatorStateInfo(0).shortNameHash;
            //else
            //    info.CurrentAnimID = 0;
            //info.NextAnimID = nAnimID;
            //info.entity = ety;

            info.time = config.time;
            info.color = config.color;
            info.power = config.power;
            info.enemy = enemy;
            info.Delay = config.DelayTime;

            info.Show();
            m_skillEffectList.Add(info);

            return info;
        }
        public FlowMaterialConfigWarp Play(Bokura.ISkillConfig.FlowMaterialConfig config, Entity entity)
        {

            IResourceLoader.Instance.LoadAssetAsync(IResourceLoader.strSkillEffectTexturePath, config.tex, IResourceLoader.strSpriteSuffix, (Object o) => {
                FlowMaterialConfigWarp info = new FlowMaterialConfigWarp();
                info.tex = config.tex;
                info.tex2d = o as Texture2D;
                info.color = config.color;
                info.strength = config.strength;
                info.Delay = config.DelayTime;
                info.time = config.durationTime;
                info.factor = new Vector4(config.speed.x, config.speed.y, config.uv.x, config.uv.y);

                info.entity = entity;
                //info.Show();
                m_skillEffectList.Add(info);
            });


            return null;
        }

        public BuffMaterialConfigWrap Play(Bokura.ISkillConfig.BuffMaterialConfig config, Entity enemy)
        {

            BuffMaterialConfigWrap info = new BuffMaterialConfigWrap();

            info.time = config.time;
            info.color = config.color;
            info.power = config.power;
            info.enemy = enemy;
            info.Delay = config.delayTime;
            info.colourCurve = config.colourCurve;

            info.Show();
            m_skillEffectList.Add(info);

            return info;
        }

        /*public RadialBlurConfigWrap Play(ISkillConfig.RadialBlurConfig data)
        {
            var blur = ScriptableObject.CreateInstance<UnityEngine.Rendering.PostProcessing.RadialBlur>();
            blur.enabled.Override(true);
            blur.blurEnable.Override(true);
            blur.radialBlurStrength.Override(data.strength);
            blur.radialBlurSamples.Override((int)(data.sampleCount));
            blur.radialBlurRadialStrength.Override(data.radialBlurRadialStrength);
            blur.radialBlurRadialRadius.Override(data.radialBlurRadialRadius);
            blur.radialBlurCenter.Override(data.radialBlurCenter);

            //setting = blur;
            UnityEngine.Rendering.PostProcessing.PostProcessManager.instance.QuickVolume(0, 100, blur);
            return null;
        }*/

        public RadialBlurConfigWrap Play(Bokura.ISkillConfig.RadialBlurConfig config, int nAnimID, Entity ety)
        {

            RadialBlurConfigWrap info = new RadialBlurConfigWrap();
            info.entity = ety;

            info.time = config.time;
            info.strength = config.strength;
            info.samplecount = config.sampleCount;
            info.Delay = config.DelayTime;
            info.radialBlurRadialStrength = config.radialBlurRadialStrength;
            info.radialBlurCenter = config.radialBlurCenter;
            info.radialBlurRadialRadius = config.radialBlurRadialRadius;
            info.Show();
            

            m_skillEffectList.Add(info);

            return info;
        }

        public EffectInfo Play(string effectname, Vector3 targetPos, string effectDirectory = null, bool autodelete = true, float scale = 1)
        {
            return Play(effectname, targetPos, Vector3.zero, effectDirectory , autodelete, scale);
        }
        public EffectInfo Play(string effectname, Vector3 targetPos, Vector3 dir, string effectDirectory = null, bool autodelete = true, float scale = 1 )
        {
            if (string.IsNullOrEmpty(effectname))
                return null;
            EffectInfo info = new EffectInfo();
            var path = System.IO.Path.GetFileNameWithoutExtension(effectname);
            var directory = string.IsNullOrEmpty(effectDirectory) ? IResourceLoader.strSkillEffectPath : effectDirectory;
            GameFXPool.LoadFX(directory, path, (UnityEngine.Object o) =>
            {
                if (o)
                {
                    if (info.Stoped)
                        return;
                    info.StartTime = Time.time;
                    info.CreateTime = Time.time;
                    info.effect = IParticleSystem.Instance.CreateEffectObject(o as GameObject);
                    if (info.effect != null)
                    {
                        info.effect.SetActive(info.m_bIsVisible);
                        info.effect.transform.localScale = new Vector3(scale, scale, scale);

                        info.effect.transform.position = targetPos;
                        if(dir != Vector3.zero)
                            info.effect.transform.rotation = Quaternion.FromToRotation(Vector3.up, dir);
                        if (autodelete)
                            m_playlist.Enqueue(info);
                    }

                }
                else
                {
                    LogHelper.LogWarning("effect not found!:", path);

                }

            });
            return info;
        }

        public void Update()
		{
			if(m_updateCD<Time.time)
			{

				while(m_playlist.Count>0 && (Time.time - m_playlist.Peek().StartTime)> EffectLifeTime)
				{
					var info = m_playlist.Dequeue();
					info.Stop();
				}
					
				m_updateCD = Time.time + 1.0f;
			}


			foreach(var v in m_skillEffectList)
			{
				v.Update();
				if(v.Showed && v.isStop())
				{
					m_needRemoveSkillEffectList.Add(v);
				}
			}

			if(m_needRemoveSkillEffectList.Count>0)
			{
				foreach(var v in m_needRemoveSkillEffectList)
				{
					m_skillEffectList.Remove(v);
					if(v.Showed)
					{
						m_playlist.Enqueue(v);
					}
				}

				m_needRemoveSkillEffectList.Clear();
			}
		}


        Dictionary<string, IEffectConfig> m_effectConfigList = new Dictionary<string, IEffectConfig>(128);
        IEffectConfig loadEffectConfig(string sEffectName)
        {


            IEffectConfig effectConfig = null;
            if (m_effectConfigList.TryGetValue(sEffectName, out effectConfig))
            {
                return effectConfig;
            }
            UnityEngine.Object o = ResourceHelper.LoadResourceSync(IResourceLoader.strEffectConfigPath, sEffectName, IResourceLoader.strAssetSuffix);
            if (o != null)
            {
                effectConfig = o as IEffectConfig;
                m_effectConfigList.Add(sEffectName, effectConfig);

            }
            return effectConfig;
        }

    }
}