﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 用于表示3D预览所需的实体
    /// </summary>
    public class AvatarShow
    {
        /// <summary>
        /// 模型Avatar
        /// </summary>
        private IAvatar m_Avatar;

        /// <summary>
        /// 3D环境
        /// </summary>
        private Transform m_Env3D;
        /// <summary>
        /// 类型
        /// </summary>
        private AvatarShowType m_Type;
        /// <summary>
        /// 对应的实体对象
        /// </summary>
        private AvatarEvent m_EntityBase;
        /// <summary>
        /// 对应的预览对象
        /// </summary>
        private ThreeDPreview m_Preview;
        private GameEvent m_OnInited = null;
        /// <summary>
        /// 初始化完成事件
        /// </summary>
        public GameEvent onInited
        {
            get
            {
                if (null == m_OnInited)
                    m_OnInited = new GameEvent();
                return m_OnInited;
            }
        }
        /// <summary>
        /// Avatar的旋转
        /// </summary>
        private Vector3 m_AvatarRot = Vector3.zero;
        /// <summary>
        /// 摄像机的配置参数
        /// </summary>
        private AvatarShowConfig m_CamConfig;
        /// <summary>
        /// 界面的配置参数
        /// </summary>
        private AvatarShowPanelConfig m_PanelConfig;
        /// <summary>
        /// 界面的3D环境配置参数
        /// </summary>
        private AvatarShowPanelEnvConfig m_PanelEnvConfig;
        /// <summary>
        /// 模型名称
        /// </summary>
        private string m_ModelName;
        /// <summary>
        /// 处理Timeline开始事件
        /// </summary>
        private UnityAction m_OnTimelineStartCallback = null;
        /// <summary>
        /// 世界偏移
        /// </summary>
        private Vector3 worldOffset
        {
            get { return null != m_Preview ? m_Preview.worldOffset : Vector3.zero; }
        }
        public Entity Entity
        {
            get { return m_EntityBase as Entity; }
        }
        [XLua.BlackList]
        public AvatarEvent AvatarEventBase
        {
            get { return m_EntityBase; }
        }
        /// <summary>
        /// AvatarShow相机
        /// </summary>
        [XLua.BlackList]
        public Camera AvatarCamera
        {
            get { return m_Preview ? m_Preview.previewCam : null; }
        }
        /// <summary>
        /// 组件缓存
        /// </summary>
        private static readonly List<UniqueShadow> s_CacheList = new List<UniqueShadow>(Const.kCap2);
        /// <summary>
        /// 缓存配置
        /// </summary>
        private static readonly Dictionary<long, AvatarShowConfig> s_CacheConfigs = new Dictionary<long, AvatarShowConfig>(Const.kCap32);
        /// <summary>
        /// 缓存模型名称
        /// </summary>
        private static readonly Dictionary<long, string> s_CacheModelNames = new Dictionary<long, string>(Const.kCap32);
        /// <summary>
        /// Building模型路径分隔符
        /// </summary>
        private readonly char[] buildingPathSp = new char[] { ':' };
        [XLua.BlackList]
        public static void Clear()
        {
            s_CacheList.Clear();
            s_CacheConfigs.Clear();
            s_CacheModelNames.Clear();
        }
        [XLua.BlackList]
        public AvatarShow()
        {
            m_OnTimelineStartCallback = OnTimelineStart;
        }
        [XLua.BlackList]
        public AvatarShow Init(UserAvatarData data)
        {
            m_Type                      = AvatarShowType.Character;
            swm.CareerType tCareer      = (swm.CareerType)data.career;
            swm.CareerSex tSex          = (swm.CareerSex)data.sex;
            m_CamConfig                 = GetConfig(m_Type, UIUtility.GetCareerAndSexInOne((int)tCareer, (int)tSex), data.panelID, tSex);
            m_PanelConfig               = AvatarShowManager.Instance.GetPanelConfig(data.panelID);
            m_PanelEnvConfig            = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            swm.MapEntityDataT tData    = new swm.MapEntityDataT();
            tData.cur_pos               = Vector3.zero.Vec3();
            tData.cur_dir               = Vector3.forward.Vec3();
            tData.attack_speed          = 1000;
            swm.MapUserT user_data      = new swm.MapUserT();
            tData.user_data             = user_data;
            user_data.career_type       = tCareer;
            user_data.career_sex        = tSex;

            //时装
            user_data.fids              = (data.fids != null) ? new List<uint>(data.fids) : null;
            Character tChar             = new Character(tData.entity_id);
            tChar.init();

            //脸部
            tChar.SetMakeupData(data.makeup);
            m_Avatar                    = tChar.Avatar;
            m_EntityBase                = tChar;
            m_Avatar.EnableLOD          = false;

            tChar.OnAvatarLoaded.AddListener(OnAvatarLoaded);
            tChar.Layer                 = Const.kAvatarShowLayer;
            tChar.SyncLoad              = true;
            tChar.Visible               = true;
            tChar.SetData(tData);
            return this;
        }
        
        [XLua.BlackList]
        public AvatarShow Init(NpcAvatarData data)
        {
            m_Type                      = AvatarShowType.Npc;
            m_CamConfig                 = GetConfig(m_Type, (int)data.baseID, data.panelID);
            m_PanelConfig               = AvatarShowManager.Instance.GetPanelConfig(data.panelID);
            m_PanelEnvConfig            = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            swm.MapEntityDataT tData    = new swm.MapEntityDataT();
            tData.cur_pos               = Vector3.zero.Vec3();
            tData.cur_dir               = Vector3.forward.Vec3();

            swm.MapNpcT tNpcData        = new swm.MapNpcT();
            tData.npc_data              = tNpcData;
            tNpcData.baseid             = data.baseID;
            tNpcData.career_sex         = swm.CareerSex.Unknown;
            tNpcData.career_type        = swm.CareerType.Unknown;

            Npc tNpc                    = new Npc(0);
            tNpc.init();
            m_EntityBase                = tNpc;
            m_Avatar                    = tNpc.Avatar;
            m_Avatar.EnableLOD          = false;

            tNpc.OnAvatarLoaded.AddListener(OnAvatarLoaded);
            tNpc.Layer                  = Const.kAvatarShowLayer;
            tNpc.SyncLoad               = true;
            tNpc.Visible                = true;
            tNpc.SetNpcConfigById((int)data.baseID);
            tNpc.SetData(tData);
            return this;
        }
        [XLua.BlackList]
        public AvatarShow Init(MountAvatarData data)
        {
            m_Type                      = AvatarShowType.Mount;
            m_CamConfig                 = GetConfig(m_Type, data.baseID, data.panelID);
            m_PanelConfig               = AvatarShowManager.Instance.GetPanelConfig(data.panelID);
            m_PanelEnvConfig            = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            swm.MapEntityDataT tData    = new swm.MapEntityDataT();
            tData.cur_pos               = Vector3.zero.Vec3();
            tData.cur_dir               = Vector3.forward.Vec3();

            Mount tMount                = new Mount(tData);
            m_EntityBase                = tMount;
            m_Avatar                    = tMount.Avatar;
            m_Avatar.EnableLOD          = false;

            tMount.OnAvatarLoaded.AddListener(OnAvatarLoaded);
            tMount.Layer                = Const.kAvatarShowLayer;
            tMount.SyncLoad             = true;
            tMount.Visible              = true;
            tMount.init(null, data.baseID, data.skinID);
            tMount.OnAddToScene();
            return this;
        }
        [XLua.BlackList]
        public AvatarShow Init(WeaponAvatarData data)
        {
            m_Type                  = AvatarShowType.Weapon;
            m_CamConfig             = GetConfig(m_Type, (int)data.baseID, data.panelID);
            m_PanelConfig           = AvatarShowManager.Instance.GetPanelConfig(data.panelID);
            m_PanelEnvConfig        = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            Weapon tWeapon          = new Weapon();
            m_EntityBase            = tWeapon;
            m_Avatar                = tWeapon.Avatar;
            m_Avatar.EnableLOD      = false;

            tWeapon.OnAvatarLoaded.AddListener(OnAvatarLoaded);
            tWeapon.init(null, m_ModelName, false, data.baseID);
            tWeapon.Show(true);
            return this;
        }
        [XLua.BlackList]
        public AvatarShow Init(BuildingAvatarData data)
        {
            m_Type                      = AvatarShowType.Building;
            m_CamConfig                 = GetConfig(m_Type, (int)data.baseID, data.panelID);
            m_PanelConfig               = AvatarShowManager.Instance.GetPanelConfig(data.panelID);
            m_PanelEnvConfig            = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            BuildCityBuilding tBuilding = new BuildCityBuilding();
            tBuilding.Init();
            m_EntityBase                = tBuilding;
            m_Avatar                    = tBuilding.Avatar;
            m_Avatar.EnableLOD          = false;

            tBuilding.OnAvatarLoaded.AddListener(OnAvatarLoaded);
            tBuilding.InitConfig(data.baseID);
            tBuilding.LoadModel(data.baseID);
            return this;
        }
        [XLua.BlackList]
        public AvatarShow Init(SandTableAvatarData data)
        {
            m_Type                  = AvatarShowType.SandTable;
            m_CamConfig             = GetConfig(m_Type, (int)data.baseID, data.panelID);
            m_PanelConfig           = AvatarShowManager.Instance.GetPanelConfig(data.panelID);
            m_PanelEnvConfig        = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            SandTableCity tCity     = new SandTableCity();
            tCity.Init();
            m_EntityBase            = tCity;
            m_Avatar                = tCity.Avatar;
            m_Avatar.EnableLOD      = false;

            tCity.OnAvatarLoaded.AddListener(OnAvatarLoaded);
            tCity.LoadModel(data.baseID);
            return this;
        }
        [XLua.BlackList]
        public AvatarShow Init(GameObject _AvatarObj, string _ConfigPath /*AvatarShow配置文件的资源路径*/, int _PanelId /*展示的界面id*/)
        {
            m_Type                  = AvatarShowType.None;
            m_CamConfig             = GetConfig(_ConfigPath, _PanelId);
            m_PanelConfig           = AvatarShowManager.Instance.GetPanelConfig(_PanelId);
            m_PanelEnvConfig        = UIUtility.GetAvatarShowEnvConfig(m_PanelConfig?.env3d);
            if (null != _AvatarObj)
            {
                GameObject tCopy    = GameObject.Instantiate(_AvatarObj, null);
                ShowEntity tEty     = new ShowEntity(tCopy);
                m_EntityBase        = tEty;
                m_Avatar            = tEty.Avatar;
                m_Avatar.EnableLOD  = false;
                OnAvatarLoaded();
            }
            return this;
        }
        /// <summary>
        /// 获取配置
        /// </summary>
        private AvatarShowConfig GetConfig(AvatarShowType _Type, int _Uid, int _PanelId, swm.CareerSex _Sex = swm.CareerSex.Unknown)
        {
            AvatarShowConfig tResult;
            long tKey = GetCacheKeyByConfig(_Type, _Uid, _PanelId);
            if (!s_CacheConfigs.TryGetValue(tKey, out tResult))
            {
                tResult = null;
                m_ModelName = GetModelName(_Type, _Uid, _Sex);
                if (!string.IsNullOrEmpty(m_ModelName))
                {
                    AvatarShowConfigs tAsset = UIUtility.GetAvatarShowConfig(_Type, m_ModelName);
                    if (null != tAsset)
                        tResult = tAsset.GetConfigByPanelId(_PanelId);
                }
                s_CacheConfigs.Add(tKey, tResult);
                s_CacheModelNames.Add(tKey, m_ModelName);
            }
            else
                m_ModelName = s_CacheModelNames[tKey];
            return tResult;
        }
        /// <summary>
        /// 获取配置
        /// </summary>
        private AvatarShowConfig GetConfig(string _ConfigPath, int _PanelId)
        {
            m_ModelName = string.Empty;
            AvatarShowConfig tResult = null;
            if (!string.IsNullOrEmpty(_ConfigPath))
            {
                AvatarShowConfigs tAsset = UIUtility.GetAvatarShowConfig(_ConfigPath);
                if (null != tAsset)
                {
                    tResult = tAsset.GetConfigByPanelId(_PanelId);
                    m_ModelName = tAsset.name;
                }
            }
            return tResult;
        }
        /// <summary>
        /// 获取模型名称
        /// </summary>
        private string GetModelName(AvatarShowType type, int uid, swm.CareerSex sex = swm.CareerSex.Unknown)
        {
            string tModelName = string.Empty;
            switch (type)
            {
                case AvatarShowType.Character:
                    //uid由career和sex组成，见GiantUIUtility.GetCareerAndSexInOne
                    uid = (uid - (int)sex) / 10;
                    RoleTableBase? tCharConfig = RoleTableManager.GetData(uid);
                    if (tCharConfig.HasValue)
                    {
                        RoleTableBase tConfigValue = tCharConfig.Value;
                        tModelName = (sex == swm.CareerSex.Male ? tConfigValue.male_normal_model : tConfigValue.female_normal_model);
                    }
                    break;
                case AvatarShowType.Npc:
                    NpcTableBase? tNpcConfig = NpcTableManager.GetData(uid);
                    if (tNpcConfig.HasValue)
                    {
                        NpcTableBase tConfigValue = tNpcConfig.Value;
                        tModelName = tConfigValue.model;
                    }
                    break;
                case AvatarShowType.Weapon:
                    GoldWeaponTableBase? tWeaponConfig = GoldWeaponTableManager.GetData(uid);
                    if (tWeaponConfig.HasValue)
                    {
                        GoldWeaponTableBase tConfigValue = tWeaponConfig.Value;
                        tModelName = tConfigValue.model;
                    }
                    break;
                case AvatarShowType.Mount:
                    MountTableBase? tMountConfig = MountTableManager.GetData(uid);
                    if (tMountConfig.HasValue)
                    {
                        MountTableBase tConfigValue = tMountConfig.Value;
                        tModelName = tConfigValue.model;
                    }
                    break;
                case AvatarShowType.Building:
                    BuildCityModelBase? tBuildingConfig = BuildCityModelManager.GetData(uid);
                    if (tBuildingConfig.HasValue)
                    {
                        BuildCityModelBase tConfigValue = tBuildingConfig.Value;
                        string[] fullPath = tConfigValue.model.Split(buildingPathSp, StringSplitOptions.RemoveEmptyEntries);
                        if (fullPath.Length == 4)
                            tModelName = fullPath[1];
                        else
                            LogHelper.LogError("无效的自建城建筑外观配置. id=" + uid.ToString() + ", path=" + tConfigValue.model);
                    }
                    break;
                case AvatarShowType.SandTable:
                    tModelName = "ENV_ZJC_Build001_SM_ZYW001";
                    break;
            }
            return tModelName;
        }
        /// <summary>
        /// 获取缓存的键
        /// </summary>
        private long GetCacheKeyByConfig(AvatarShowType type, long uid, int panelId)
        {
            return 10000 * (long)type + 100 * uid + (long)panelId;
        }
        private void OnAvatarLoaded()
        {
            SetLayer(Const.kAvatarShowLayer);
            SetAvatarPositionAndRotation();
            SetCameraPositionAndRotation();
            ForbiddenUniqueShadowScript();
            m_OnInited?.Invoke();
        }
        /// <summary>
        /// 禁用UniqueShadow组件，避免光照异常
        /// </summary>
        private void ForbiddenUniqueShadowScript()
        {
            if(null != m_Avatar.unityObject)
            {
                s_CacheList.Clear();
                m_Avatar.unityObject.GetComponentsInChildren(true, s_CacheList);
                for (int tIdx = 0, tCount = s_CacheList.Count; tIdx < tCount; tIdx++)
                    s_CacheList[tIdx].enabled = false;
            }
        }
        /// <summary>
        /// 获取预览
        /// </summary>
        public RenderTexture GetPreview(bool _OverrideSize = false, int _Width = 512, int _Height = 512)
        {
            if(null == m_Env3D)
            {
                m_Env3D = AvatarShowManager.Instance.GetPanelEnv3D(m_PanelConfig?.env3d);
                if(m_Env3D)
                    m_Env3D.gameObject.SetActive(true);
                //应用世界偏移，避免AvatarShow之间互相影响
                SetEnvPosition();
            }
            if (null == m_Preview)
            {
                //允许外部重载RT的尺寸，否则使用界面配置参数
                if (!_OverrideSize && null != m_PanelConfig)
                {
                    Vector2Int tSize = m_PanelConfig.aspect;
                    _Width = tSize.x;
                    _Height = tSize.y;
                }
                //3D背景和2D背景不能共存
                m_Preview = ThreeDPreviewManager.Instance.GetPreview(_Width, _Height, m_Env3D ? null : m_PanelConfig?.background, null != m_CamConfig ? m_CamConfig.fieldOfView : AvatarShowConfigs.kDefaultFOV);
                //应用世界偏移，避免AvatarShow之间互相影响
                SetAvatarPositionAndRotation();
                SetCameraPositionAndRotation();
                SetEnvPosition();
                //应用光照设置
                SetLightParams();
                m_Preview.DoRender();
            }
            return m_Preview.renderTex;
        }

        /// <summary>
        /// 尝试播放Timeline
        /// </summary>
        public void TryPlayTimeline(Timeline.TimelineDesc _Desc)
        {
            if(null != _Desc && null != Entity && m_Preview)
            {
                _Desc.notifyServer  = false;
                _Desc.overrideCam   = m_Preview.previewCam;
                _Desc.ovrrideLayer  = Const.kAvatarShowLayer;
                _Desc.worldPos      = m_Preview.worldOffset;
                _Desc.onStart       += m_OnTimelineStartCallback;
                Entity.PlayDrama(_Desc);
            }
        }

        /// <summary>
        /// 处理Timeline开始事件
        /// </summary>
        private void OnTimelineStart()
        {
            //Timeline可能修改摄像机的FOV，因此需要重设背景板位置
            if (m_Preview)
                m_Preview.DoBackgroundInit();
        }

        /// <summary>
        /// 设置3D场景的世界位置和偏移
        /// </summary>
        private void SetEnvPosition()
        {
            if(m_Env3D && m_PanelEnvConfig)
            {
                m_Env3D.SetPositionAndRotation(worldOffset + m_PanelEnvConfig.envPos, m_PanelEnvConfig.envRot);
                m_Env3D.localScale = m_PanelEnvConfig.envScale;
            }
        }

        /// <summary>
        /// 设置Avatar的世界位置和旋转角度
        /// </summary>
        private void SetAvatarPositionAndRotation()
        {
            if(null != m_Avatar && m_Avatar.unityObject)
                m_Avatar.unityObject.transform.SetPositionAndRotation(worldOffset, Quaternion.Euler(m_AvatarRot));
        }

        /// <summary>
        /// 设置摄像机的世界位置和旋转角度
        /// </summary>
        private void SetCameraPositionAndRotation()
        {
            if (null == m_CamConfig) return;
            Vector3 tPos = m_CamConfig.camPos;
            Quaternion tRot = Quaternion.Euler(m_CamConfig.camRot);
            if (null != m_Avatar)
            {
                GameObject tGo = m_Avatar.unityObject;
                if (tGo)
                {
                    //配置里记录的是摄像机相对于Avatar的位置和角度，需要转换到世界坐标系中
                    tPos = tGo.transform.TransformPoint(tPos);
                    tRot = tGo.transform.rotation * tRot;
                }
            }
            m_Preview?.SetCameraPositionAndRotation(tPos, tRot);
        }

        /// <summary>
        /// 设置AvatarShow的旋转(不会影响摄像机)
        /// </summary>
        public void SetRotation(Vector3 _NewAngles)
        {
            m_AvatarRot = _NewAngles;
            SetAvatarPositionAndRotation();
        }

        public Transform SearchChildTransform(string _Name)
        {
            if (m_Avatar == null)
                return null;

            if (m_Avatar.unityObject == null)
                return null;

            return Utilities.SearchChildTransform(m_Avatar.unityObject.transform, _Name);
        }

        public Transform GetAvatarTrans()
        {
            if (m_Avatar == null)
                return null;

            if (m_Avatar.unityObject == null)
                return null;

            return m_Avatar.unityObject.transform;
        }

        /// <summary>
        /// 旋转到指定的槽位
        /// </summary>
        /// <returns>是否旋转到指定方向</returns>
        public bool Rotation2Slot(string _SlotName, Quaternion _Src, Quaternion _Target, float _Percent)
        {
            if (m_Avatar == null)
                return true;

            Transform tAvatarTrans = m_Avatar.unityObject.transform;
            if (tAvatarTrans == null)
                return true;

            float tAngle = Quaternion.Angle(tAvatarTrans.rotation, _Target);
            if (Mathf.Abs(tAngle) <= 0.05f)
            {
                tAvatarTrans.rotation = _Target;
                return true;
            }
            else
            {
                Quaternion tRealQuat = Quaternion.Lerp(_Src, _Target, _Percent);
                tAvatarTrans.rotation = tRealQuat;

                return false;
            }
         
        }

        public void SetCameraPosRot(Vector3 _Pos, Vector3 _Angles)
        {
            if(m_Preview)
            {
                Quaternion tRot = Quaternion.Euler(_Angles);
                m_Preview.SetCameraPositionAndRotation(_Pos, tRot);
            }
        }
        /// <summary>
        /// 获取AvatarShow的旋转
        /// </summary>
        public Vector3 GetRotation()
        {
            return m_AvatarRot;
        }
        /// <summary>
        /// 设置灯光的角度、颜色和强度
        /// </summary>
        private void SetLightParams()
        {
            if(m_Preview)
                m_Preview.SetLightParams(m_CamConfig);
        }
        /// <summary>
        /// 显示/隐藏
        /// </summary>
        public void SetVisibility(bool _Visible)
        {
            if(null != m_Avatar)
            {
                var tGo = m_Avatar.unityObject;
                if(tGo)
                    tGo.SetActive(_Visible);
            }
        }
        
        /// <summary>
        /// 允许重设背景
        /// </summary>
        public void SetTexture(Texture _Background)
        {
            if(m_Preview)
                m_Preview.SetTexture(_Background);
        }
        /// <summary>
        /// 设置Layer
        /// </summary>
        private void SetLayer(int _Layer)
        {
            if (null != m_Avatar)
                m_Avatar.SetLayer(_Layer);
        }
        /// <summary>
        /// 播放动作
        /// </summary>
        public void PlayAnimation(string stateName, int layer, float normalizedTime = float.NegativeInfinity)
        {
            if (null != m_Avatar)
                LuaFastCall.PlayAnimation(m_Avatar.unityObject, stateName, layer, normalizedTime);
        }
        [XLua.BlackList]
        public void DoLateUpdate()
        {
        }
        /// <summary>
        /// 释放资源，销毁对象
        /// </summary>
        [XLua.BlackList]
        public void Dispose()
        {
            m_Avatar = null;
            if (null != m_EntityBase)
            {
                if (m_Type == AvatarShowType.Weapon)
                    (m_EntityBase as Weapon)?.Release();
                else if (m_Type == AvatarShowType.None)
                    (m_EntityBase as ShowEntity)?.Release();
                else if (m_Type == AvatarShowType.Building)
                    (m_EntityBase as BuildCityBuilding)?.Release();
                else if (m_Type == AvatarShowType.SandTable)
                    (m_EntityBase as SandTableCity)?.Release();
                else
                    (m_EntityBase as Entity)?.Release();
                m_EntityBase = null;
            }
            if (m_Preview)
            {
                ThreeDPreviewManager.Instance.DestroyPreview(m_Preview);
                m_Preview = null;
            }
            if (m_Env3D)
            {
                AvatarShowManager.Instance.RecyclePanelEnv3D(m_PanelConfig?.env3d, m_Env3D);
                m_Env3D = null;
            }
            if(null != m_OnInited)
            {
                m_OnInited.RemoveAllListeners();
                m_OnInited = null;
            }
            m_AvatarRot         = Vector3.zero;
            m_CamConfig         = null;
            m_PanelConfig       = null;
            m_PanelEnvConfig    = null;
            m_ModelName         = null;
            m_Type              = AvatarShowType.None;
        }
    }
}