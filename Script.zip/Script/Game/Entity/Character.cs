#define MOVE_WORLD

using UnityEngine;
using System;
using System.Collections.Generic;
using Bokura;
using Bokura.Clothify;
using swm.pinchingface;
using x2m.MakeUp;

namespace Bokura
{
    public class Character : MovableEntity
    {
        public enum JumpState
        {
            None,
            Jumping1,
            Jumping2,
        }
        

        protected JumpState m_jumpState = JumpState.None;
        // public override bool IsJumping
        // {
        //     get
        //     {
        //         return m_jumpState == JumpState.Jumping1 || m_jumpState == JumpState.Jumping2;
        //     }
        // }
        protected Vector3 m_falldestpos = Vector3.zero; //掉落位置
        uint m_falldestposVoxWorldID;

        public Event<int> OnLevelChange = new Event<int>();
        public Event<long> OnExpChange = new Event<long>();
        public Event<bool> OnIsOnGroundChange = new Event<bool>();
        public Event<JumpState> OnJumpStatusChange = new Event<JumpState>();
        public GameEvent onRideMountChange = new GameEvent();
        public GameEvent onRefreshMountChange = new GameEvent();
        public Event onPKModeChange = new Event();
      
        public Event ChallengeTargetChange = new Event();
        public Event DuelTargetChange = new Event();
        public Event<int> OnKillQiChange = new Event<int>();

        

        public Event MoveStart = new Event();
        [XLua.BlackList]
        public GameObject headRoot = null;
        //swm.MapMountT m_mountData;
        //public swm.MapUserT m_userData;// = new swm.MapUserT();
        protected byte[] m_makeupData = null;

        public void SetMakeupData(byte[] makeupData)
        {
            m_makeupData = makeupData;
        }

        /// <summary>
        /// id of Sociaty/Sept this char is in
        /// </summary>
        public ulong SociatyID
        {
            get { return m_data.user_data.septid; }
            //帮会id改变来自于创建/加入/退出/请离帮会
            set { m_data.user_data.septid = value; }
        }
        /// <summary>
        /// 头像图标
        /// </summary>
        public string headIcon
        {
            get {
                if (m_professionConfig.HasValue)
                    return m_professionConfig.Value.headicon;
                else
                    return string.Empty;
                //return m_userData.hea;
            }
        }
        /// <summary>
        /// Check if this char is in Sociaty/Sept
        /// </summary>
        public bool IsInSociaty()
        {
            return SociatyID != 0;
        }
        /// <summary>
        /// 是否逃兵
        /// </summary>
        public bool IsDeserter
        {
            get
            {
                const int kDebuffID_Deserter = 200001;//逃兵Debuff
                return m_buffProxy != null && m_buffProxy.GetBuffOverlapCountByBaseID(kDebuffID_Deserter) > 0;
            }
        }

        float m_AdjustSpeed;
        float m_AdjustTargetSpeed;
        public float AdjustTargetSpeed { get { m_AdjustTargetSpeed = Mathf.Clamp(m_AdjustTargetSpeed, speed * 0.5f, speed * 1.5f); return m_AdjustTargetSpeed; } set { m_AdjustTargetSpeed = Mathf.Clamp(value, speed * 0.5f, speed * 1.5f); } }
        public float AdjustSpeed { get { return m_AdjustSpeed; } set { m_AdjustSpeed = value; } }
        /// <summary>
        /// 当前采集进度（0-1）
        /// </summary>
        public float ChantProgress
        {
            get
            {
                ulong tCurrServerTime = GameScene.Instance.GetServerTime();
                if (ChantStopTimeStamp <= ChantStartTimeStamp || tCurrServerTime < ChantStartTimeStamp) return 0;
                return (tCurrServerTime - ChantStartTimeStamp) / (float)(ChantStopTimeStamp - ChantStartTimeStamp);
            }
        }
        /// <summary>
        /// 是否反向读条（从右到左）
        /// </summary>
        public bool ChantBack
        {
            get
            {
                //if (m_data.state_data != null) ;
                var chantid = m_data.state_data?.chant?.chant_id;
                if (!chantid.HasValue)
                    return false ;
                ChantTableBase? tConfig = ChantTableManager.GetData((int)chantid.Value);
                bool tBack = false;
                if (tConfig.HasValue && tConfig.Value.direction == 1)
                    tBack = true;
                return tBack;
            }
        }

        public uint ManorBaseID
        {
            get
            {
                return m_data.user_data.manorbaseid;
            }
            set
            {
                m_data.user_data.manorbaseid = value;
            }
        }

        /// <summary>
        /// 吟唱开始时间戳
        /// </summary>
        public ulong ChantStartTimeStamp
        {
            get
            {
                var time = m_data?.state_data?.chant.start_time;
                return time.HasValue? time.Value:0;
               // return m_userData.chant_begin_time;
            }
        }
        /// <summary>
        /// 吟唱停止时间
        /// </summary>
        public ulong ChantStopTimeStamp
        {
            get
            {
                var time = m_data?.state_data?.chant.end_time;
                return time.HasValue ? time.Value : 0;
            }
        }
        private GameEvent<bool> m_OnChantStateChanged = new GameEvent<bool>();
        /// <summary>
        /// 吟唱状态改变事件
        /// </summary>
        public GameEvent<bool> onChantStateChanged { get { return m_OnChantStateChanged; } }
        /// <summary>
        /// 开始/结束吟唱，并更新动作
        /// </summary>
        public void setIsChant(bool _IsChant, ChantTableBase? config)
        {
            m_bIsChant = _IsChant;
            if (config.HasValue)
                SetAnimID(SM.Entity.States.GATHER, Animator.StringToHash(config.Value.chant_action_name));
        }
        public override Entity Clone(ulong _id = 0, CloneUsage _Usage = CloneUsage.NpcVisit)
        {
            Character tEntity = new Character(_id);
            tEntity.SyncLoad = true;
            var tData = m_data.Clone();
            if (_Usage == CloneUsage.Drama)
                tData = HandleDataForDrama(tData);
            tData.user_data.mountid = 0;
            tData.user_data.mountskinid = 0;
            tData.change_id = currentTransformId;
            //捏脸数据要另外设置
            tEntity.SetMakeupData(m_makeupData);
            tEntity.init();
            tEntity.SetData(tData);
            if(IsInTransform )
            {
                tEntity.TransformAddtoScene(GetCurrentTransformationModel());
            }
            else
            {
                tEntity.OnAddToScene();
            }
            
            tEntity.Position = Position;
            tEntity.Direction = Direction;
            if (SecondaryWeapon != null && tEntity.SecondaryWeapon != null )
            {
                tEntity.SecondaryWeapon.Attachment = SecondaryWeapon.Attachment;
                tEntity.SecondaryWeapon.Show(SecondaryWeapon.IsShow);
            }
            return tEntity;
        }
        [XLua.BlackList]
        public override void ResetStateForDrama()
        {
            base.ResetStateForDrama();
            //载具状态
            VehicleId = 0;
            //坐骑状态
            ReleaseMount(IsMainCharacter());
            //武器状态
            //IsShowGoldWeapon = false;
            //吟唱状态
            SetChantData(0, 0, 0);
        }
        /// <summary>
        /// 设置吟唱动作、开始和结束时间戳（毫秒）
        /// </summary>
        public void SetChantData(uint chantID, ulong beginTimeStamp, ulong endTimeStamp)
        {
            if (m_data == null)
                m_data = new swm.MapEntityDataT();
            if (m_data.state_data == null)
                m_data.state_data = new swm.AgentStateDataT();

            if (m_data.state_data.chant == null)
                m_data.state_data.chant = new swm.ChantStateDataT();

            m_data.state_data.chant.chant_id = chantID;
            m_data.state_data.chant.start_time = beginTimeStamp;
            m_data.state_data.chant.end_time = endTimeStamp;
            CheckChantState();
        }

        /// <summary>
        /// 检查吟唱状态是否发生改变
        /// </summary>
        protected void CheckChantState()
        {
            bool tNewChantState = true;
            ulong tCurrServerTime = GameScene.Instance.GetServerTime();
            
            if (m_data.state_data.chant == null || ChantStopTimeStamp < tCurrServerTime || ChantStopTimeStamp <= ChantStartTimeStamp)
                tNewChantState = false;
            else
                tNewChantState = true;
            if (m_bIsChant != tNewChantState)
            {                
                m_bIsChant = tNewChantState;
                if(m_bIsChant)
                {
                    ChantTableBase? tConfig = ChantTableManager.GetData((int)m_data.state_data.chant.chant_id);

                    setIsChant(true, tConfig);

                }

                m_OnChantStateChanged.Invoke(m_bIsChant);
            }
        }
        //捏脸相关;
        private PinchingFaceResultDataT m_pinchingFaceResultData = null;
        private MakeUpAnimationController m_headAnimCtrl = null;
        
        private string m_headModelName;
        private string m_hairModelName;
        private string m_hornModelName;
        private bool isLoadHeadFinished = false;
        private bool isLoadHairFinished = false;
        private bool isMakeupFaceTexture = true;

        ProfessionTableBase? m_professionConfig;
        //
        //protected float m_curJumpPower;
        //protected float m_jumpPrepareTime = 0.0f;
        //const float m_fallCheckDistance = 1.0f;

        public int RideMountBaseID
        {
            get
            {
                if (m_isMountDisappearing) return 0;
                return (int)m_data.user_data.mountid;

            }
        }
        public int RideMountSkinID
        {
            get
            {
                return (int)m_data.user_data.mountskinid;

            }
        }

        //public bool IsShowGoldWeapon
        //{
        //    get
        //    {
        //        return false;// m_userData.is_show_weapon;
        //    }
        //    set
        //    {
        //        m_userData.is_show_weapon = value;
        //    }
        //}

        private bool m_isMountDisappearing = false;
        public bool IsMountDisappearing
        {
            get
            {
                return m_isMountDisappearing;
            }
        }

        private bool m_isJumpingFromMount = false;
        public bool IsJumpingFromMount
        {
            get
            {
                return m_isJumpingFromMount;
            }
            set
            {
                m_isJumpingFromMount = value;
            }
        }

        protected Mount m_mount;
        public Mount Mount
        {
            get
            {
                if (m_isMountDisappearing) return null;
                return m_mount;
            }
        }
        protected Vector3 m_qingKungStartPos = Vector3.zero; //轻功起点位置
        protected Vector3 m_qingKungTopPos = Vector3.zero; //轻功最高点位置
        protected Vector3 m_qingKungLandPos = Vector3.zero; //轻功着陆的位置
        protected float m_qingKungDurationTime = 1000; //当前阶段持续时间

        protected QingKungStep m_qingqungStep = QingKungStep.QingKungNone; //轻功当前步骤 2/3/4是轻功动作，5是上升动�???
        protected bool m_continueQingKung = true;
        public Vector3 QingKungStartPos { get { return m_qingKungStartPos; } set { m_qingKungStartPos = value; } }
        public Vector3 QingKungTopPos { get { return m_qingKungTopPos; } set { m_qingKungTopPos = value; } }
        public float QingKungDurationTime { get { return m_qingKungDurationTime; } set { m_qingKungDurationTime = value; } }

        public uint QingKungLandPosVoxelWorldID;
        public Vector3 QingKungLandPos { get { return m_qingKungLandPos; } set { m_qingKungLandPos = value; } }
        public QingKungStep QingKungStep { get { return m_qingqungStep; } set { m_qingqungStep = value; } }
        public bool CanContinueQingKung { get { return m_continueQingKung; } set { m_continueQingKung = value; } }

        public Vector3 FallDestPos
        {
            get
            {
                if (m_falldestposVoxWorldID == VoxelWorldID)
                    return m_falldestpos;
                else
                {
                    //LogHelper.Log("FallDestPos", m_falldestposVoxWorldID, VoxelWorldID);
                    Vector3 pos;// = m_falldestpos;
                    if (m_falldestposVoxWorldID != 0)
                        pos = MobileBlockMgr.Instance.LocalPos2WorldPos(m_falldestpos, m_falldestposVoxWorldID);
                    else
                        pos = m_falldestpos;
                    if (VoxelWorldID != 0)
                    {
                        pos = MobileBlockMgr.Instance.WorldPos2LocalPos(pos, VoxelWorldID);
                    }
                    //LogHelper.Log("FallDestPos", m_falldestposVoxWorldID, VoxelWorldID, pos);
                    m_falldestpos = pos;
                    m_falldestposVoxWorldID = VoxelWorldID;
                    return pos;
                }
            }
            set
            {
                m_falldestpos = value;
                m_falldestposVoxWorldID = VoxelWorldID;
            }
        }

        #region //下降滑翔;
        protected Vector3 m_commonGlidingCurrPos = Vector3.zero;
        protected Vector3 m_commonGlidingCurrDir = Vector3.zero;
        protected Vector3 m_commonGlidingTargetPos = Vector3.zero;
        protected ulong m_commonGlidingTime = 0;

        public Vector3 CommonGlidingCurrPos { get { return m_commonGlidingCurrPos; } set { m_commonGlidingCurrPos = value; } }
        public Vector3 CommonGlidingCurrDir { get { return m_commonGlidingCurrDir; } set { m_commonGlidingCurrDir = value; } }
        public Vector3 CommonGlidingTargetPos { get { return m_commonGlidingTargetPos; } set { m_commonGlidingTargetPos = value; } }
        public ulong CommonGlidingTime { get { return m_commonGlidingTime; } set { m_commonGlidingTime = value; } }
        #endregion //下降滑翔;

        /// <summary>
        /// 当前职业类型
        /// </summary>
        public override swm.CareerType CareerType
        {
            get { return m_data.user_data.career_type; }
        }
        private RoleTableBase? m_RoleConfig;
        /// <summary>
        /// 角色配置
        /// </summary>
        protected RoleTableBase? RoleConfig
        {
            get
            {
                if (!m_RoleConfig.HasValue)
                    m_RoleConfig = RoleTableManager.GetData((int)CareerType);
                return m_RoleConfig;
            }
        }
        public bool IsWarrior
        {
            get { return CareerType == swm.CareerType.Warrior; }
        }
        public bool IsPastor
        {
            get { return CareerType == swm.CareerType.Pastor; }
        }
        public bool IsMage
        {
            get { return CareerType == swm.CareerType.Mage; }
        }
        public bool IsArcher
        {
            get { return CareerType == swm.CareerType.Archer; }
        }

        bool m_isInTierTraining;
        public bool IsInTierTraining
        {
            get
            {
                return m_isInTierTraining;
            }
            set
            {
                m_isInTierTraining = value;
            }
        }

        public override bool IsFlying
        {
            get
            {
                return Mount ? Mount.IsAirMode : false;
            }

            set
            {
                base.IsFlying = value;
            }
        }
        public override bool Moveing
        {
            get
            {
                if (Mount)
                    return Mount.Moveing;

                return base.Moveing;
            }
        }

        public bool IsCareful
        {
            get
            {
                return m_data.iscatfoot;

            }
            set
            {
                if (m_data.iscatfoot != value)
                {
                    m_data.iscatfoot = value;

                    OnVehicleChange();
                }
            }
        }

        protected static uint carefulVehicleId = 3;
        public uint VehicleId
        {
            get
            {
                if (m_data.vehicle_id > 0)
                    return m_data.vehicle_id;
                if (IsCareful)
                    return carefulVehicleId;
                return 0;
            }
            set
            {
                if (m_data.vehicle_id != value)
                {
                    //载具发生变化
                    m_data.vehicle_id = value;
                    OnVehicleChange();
                }
            }
        }

        VehicleTableBase? m_vehicleConfig;
        public VehicleTableBase? VehicleConfig
        {
            get
            {
                if (m_vehicleConfig == null)
                    m_vehicleConfig = VehicleTableManager.GetData((int)VehicleId);
                return m_vehicleConfig;
            }
        }

        protected override void FillMapEntityData(swm.MapEntityData _data)
        {
            base.FillMapEntityData(_data);

            //if (_data.user_data != null)
            //{
            //    if (_data.user_data.Value.fidsLength > 0)
            //    {
            //        int len = _data.user_data.Value.fidsLength;
            //        m_data.user_data.fids = new List<uint>(len);
            //        for (int i = 0; i < _data.user_data.Value.fidsLength; ++i)
            //        {
            //            m_data.fashions.Add((int)_data.user_data.Value.fids(i));
            //        }
            //    }
            //}
        }
        public override bool haveSkill()
        {
            return true;
        }
        public override void SetNetData(swm.SyncMainUserData _data)
        {
            if (_data.user_data != null)
            {
                if (m_data == null)
                    m_data = new swm.MapEntityDataT();
                if (m_data.user_data == null)
                    m_data.user_data = new swm.MapUserT();
                m_data.user_data.FromMsg(_data.user_data.Value);

                //CheckChantState();
            }

            //propertyComponent.SetNetData(_data);

            base.SetNetData(_data);
        }

        public override void SetNetData(swm.MapEntityData _data)
        {

            base.SetNetData(_data);
            CheckChantState();
        }

        [XLua.BlackList]
        public void SetNeedMakeupFaceTexture(bool isNeed)
        {
            isMakeupFaceTexture = isNeed;
        }

        [XLua.BlackList]
        public bool IsNeedMakeupFaceTexture()
        {
            return (isMakeupFaceTexture && (IsMainCharacter() || (m_thisid == 0)));
        }

        [XLua.BlackList]
        public void trySetMakeupDataToChar()
        {
            if (isLoadHeadFinished && isLoadHairFinished)
            {
                if (!isSetMakeupToChar)
                {
                    isSetMakeupToChar = true;
                    if (m_pinchingFaceResultData != null)
                    {
                        if (m_headAnimCtrl != null)
                        {
                            m_headAnimCtrl.RefreshPinchingfaceBoneDatas(m_pinchingFaceResultData.boneDatas);
                        }

                        MakeupInGameManager.Instance.SetMakeupDataToEntity(this, m_pinchingFaceResultData, () => { OnMakeupFinished(); });
                    }
                }
            }
        }
        [XLua.BlackList]
        public void OnMakeupFinished()
        {
            if (m_pinchingFaceResultData != null)
            {
                PinchingFaceResultDataAssistant.Push(m_pinchingFaceResultData);
                m_pinchingFaceResultData = null;
            }
        }
        public override void SetData(swm.MapEntityDataT data)
        {
            if (m_data == null)
                m_data = new swm.MapEntityDataT();
            //if(data.user_data!=null)
            //if(m_data.user_data==null)
            //   m_data.user_data.FromMsg(data.user_data)
            m_data.user_data = data?.user_data;
            base.SetData(data);
        }
        public override bool IsMale()
        {
            return this.Sex == swm.CareerSex.Male;
        }

        public override swm.CareerSex Sex
        {
            get
            {
                return m_data.user_data.career_sex;
            }
        }
        public JumpState JumpStatus
        {
            get { return m_jumpState; }
            set {
                if (m_jumpState != value)
                {
                    m_jumpState = value;
                    OnJumpStatusChange.Invoke(m_jumpState);
                }
            }
        }
        private EffectMgr.EffectInfoGroup m_serverChangeEffect = null;
        public override int Level
        {
            get
            {
                return base.Level;
            }

            set
            {
                var oldlevel = base.Level;
                if (oldlevel != value)
                {

                    base.Level = value;
                    OnLevelChange.Invoke(oldlevel);
                    if(m_serverChangeEffect != null)
                    {
                        m_serverChangeEffect.Stop();
                        m_serverChangeEffect = null;
                    }
                    m_serverChangeEffect = EffectMgr.Instance.PlayByConfig("effect_buff_common_levelup_01", this);//播放升级特效
                }

            }
        }

        long m_exp;
        public long Exp
        {
            get
            {
                return m_exp;
            }
            set
            {
                var oldval = m_exp;
                if (oldval != value)
                {
                    m_exp = value;
                    OnExpChange.Invoke(oldval);
                }
            }
        }
        protected EarthSwords m_earthSwords;
        public EarthSwords earthSwords
        {
            get
            {
                return m_earthSwords;
            }
        }
        private bool isSetMakeupToChar = false;
        public Character(ulong id) : base(id)
        {
            m_layer = (Int32)(UserLayer.Layer_Character);
            m_avatar.onLevel0HeadLoaded += OnHeadModelLoaded;
            m_avatar.shadowType = AvatarShadowType.Decal;

        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public Character() : base()
        {

        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public override void InitEntity(ulong id)
        {
            base.InitEntity(id);
            m_layer = (Int32)(UserLayer.Layer_Character);
            m_avatar.onLevel0HeadLoaded += OnHeadModelLoaded;
            m_avatar.shadowType = AvatarShadowType.Decal;
        }

        ~Character()
        {

        }
        /// <summary>
        /// 销毁并移除坐骑
        /// </summary>
        protected void ReleaseMount(bool isMainChar = false)
        {
            if (null != m_mount)
            {
                m_mount.CancelOwnerCarry();
                GameScene.Instance.RemoveEntity(m_mount);
                if (isMainChar)
                {
                    m_mount.ReleaseMainMount();
                }
                m_mount = null;
                if (isMainChar)
                {
                    OnMountChanged();
                }
            }
        }
        public override void Release()
        {
            base.Release();
            if (m_earthSwords != null)
            {
                m_earthSwords.Destroy();
                m_earthSwords = null;
            }
            ReleaseMount();

            if(m_serverChangeEffect != null)
            {
                m_serverChangeEffect.Stop();
                m_serverChangeEffect = null;
            }
        }

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public override void ResetEntity()
        {
            base.ResetEntity();
            OnLevelChange.RemoveAllListeners();
            OnExpChange.RemoveAllListeners();
            OnIsOnGroundChange.RemoveAllListeners();
            OnJumpStatusChange.RemoveAllListeners();
            onPKModeChange.RemoveAllListeners();

            ChallengeTargetChange.RemoveAllListeners();
            DuelTargetChange.RemoveAllListeners();
            OnKillQiChange.RemoveAllListeners();
            MoveStart.RemoveAllListeners();
            onRideMountChange.RemoveAllListeners();
            onRefreshMountChange.RemoveAllListeners();
            m_OnChantStateChanged.RemoveAllListeners();
            OnDodgeEnegyChanged.RemoveAllListeners();

            m_jumpState = JumpState.None;
            m_falldestpos = Vector3.zero;
            headRoot = null;
            //m_mountData = null;
            //m_userData = null;// new swm.MapUserT();
            m_makeupData = null;
            m_AdjustSpeed = 0.0f;
            m_AdjustTargetSpeed = 0.0f;
            m_bIsChant = false;
            if (m_pinchingFaceResultData != null)
            {
                PinchingFaceResultDataAssistant.Push(m_pinchingFaceResultData);
                m_pinchingFaceResultData = null;

            }
           
            m_headModelName = string.Empty;
            m_hairModelName = string.Empty;
            m_hornModelName = string.Empty;
            isLoadHeadFinished = false; 
            isLoadHairFinished = false;
            isMakeupFaceTexture = true;
            ReleaseMountDelay();
            m_isMountDisappearing = false;
            m_isJumpingFromMount = false;
            m_mount = null;
            m_qingKungStartPos = Vector3.zero;
            m_qingKungTopPos = Vector3.zero;
            m_qingKungLandPos = Vector3.zero;
            m_qingKungDurationTime = 1000;
            m_qingqungStep = QingKungStep.QingKungNone;
            m_continueQingKung = true;
            m_RoleConfig = null;
            m_exp = 0;
            m_isOnGround = false;
            m_earthSwords = null;
            isSetMakeupToChar = false;

            m_bIsChallengeTarget = false;
            m_bIsDuelTarget = false;
            JumpLastDir = Vector3.zero;
            m_tWaitForSeconds = 0.8f;
            m_oldShield = false;
            m_b_isBeAttachTo = false;
            m_ul_BeAttachToRoleId = 0;
            m_ul_AttachRoleId = 0;
            m_DodgeEnegyValue = 5;
            m_DodgeEnegyMaxValue = 5;

            ClothSleep(false);
        }

        public bool IsRedName //是否红名
        {
            get
            {
                return false;
            }
        }

        public override bool Selectable
        {
            get
            {
                return true;
            }
        }

        public bool IsInCounterAttack
        {
            get
            {
                return false;
            }
        }

        public swm.PKModeType CurPKMode
        {
            get
            {
                return m_data.user_data.pkmode_type;
            }
            set
            {
                m_data.user_data.pkmode_type = value;
                OnPkModeChange();
            }
        }

        public uint KillQi  //杀气
        {
            get
            {
                return m_data.user_data.killer_value;
            }
            set
            {
                if (m_data.user_data.killer_value != value)
                {
                    var oldvalue = (int)m_data.user_data.killer_value;
                    m_data.user_data.killer_value = value;
                    RefreshCanAttack();
                    OnKillQiChange?.Invoke(oldvalue);

                }
            }
        }

        public bool IsTopLevel
        {
            get
            {
                return Level >= 60;
            }
        }
        bool m_bIsChallengeTarget = false;
        public bool IsChallengeTarget
        {
            get
            {
                return m_bIsChallengeTarget;
            }
            set
            {
                if (value != m_bIsChallengeTarget)
                {
                    m_bIsChallengeTarget = value;
                    ChallengeTargetChange.Invoke();
                    RefreshCanAttack();
                }
            }
        }

        bool m_bIsDuelTarget = false;
        public bool IsDuleTarget
        {
            get
            {
                return m_bIsDuelTarget;
            }
            set
            {
                if (value != m_bIsDuelTarget)
                {
                    m_bIsDuelTarget = value;
                    DuelTargetChange.Invoke();
                    RefreshCanAttack();
                }
            }

        }

        public UnityEngine.Vector3 JumpLastDir;

        public bool IsDashBlock()
        {
            var dir = Motion != Vector3.zero ? Motion : Direction; //dir.y = 0;
            dir.y = dir.y < 0 ? 0 : dir.y;
            float distance = /*2*/m_cc.height / 2;// m_cc ? (m_cc.radius * 1.2f) : 0.3f;
            Vector3 v3Center1 = LocalPosition + m_cc.center - Vector3.up * m_cc.height * 0.5f;
            Vector3 v3Center2 = v3Center1 + Vector3.up * m_cc.height;
            //if (Utilities.SphereCast(LocalPosition + Vector3.up * 0.5f, 0.3f, dir, out hit, distance))
            if (Physics.CapsuleCast(v3Center1, v3Center2, m_cc.radius, dir, distance))
                return true;
            return false;
        }
        public bool IsCanCrossingBlock()
        {
            var dir = Direction; dir.y = 0;
            if (Utilities.RayCast(LocalPosition + Vector3.up * 2, dir, 0.3f))
                return false;
            return true;
        }
        public bool IsLowGround()
        {
            if (Utilities.RayCast(LocalPosition, Vector3.down, 1))
                return true;
            return false;
        }

        public bool IsOnCloudGround()
        {
            bool temp = IsOnGround();
            if (!temp)
            {
                if (isCurrInCloud())
                {
                    if (Position.y <= WeatherCloudManager.CLOUD_MOVE_MIN_Y)
                    {
                        return true;
                    }

                    if (isCurrCloudEnterFly())
                    {
                        return true;
                    }
                }
            }

            return temp;
        }
        private bool m_isOnGround = false;
        protected bool bIsOnGround
        {
            get { return m_isOnGround; }
            set
            {
                if (m_isOnGround != value)
                {
                    m_isOnGround = value;
                    OnIsOnGroundChange.Invoke(m_isOnGround);
                }
            }
        }
        public override bool IsOnGround()
        {
            if (m_cc == null || !m_cc.enabled)
            {
                bIsOnGround = false;
                return false;
            }else if (!m_cc.isGrounded || IsMainCharacter())
            {
                var dis = GetGroundDistance();
                if (dis > FallCheckDistance)
                {
                    bIsOnGround = false;
                    return false;
                }
            }

            bIsOnGround = true;
            return bIsOnGround;
        }

        public void SetRideMount(int mountbaseId, int skinid)
        {
            if (m_data.user_data == null)
            {
                m_data.user_data = new swm.MapUserT();
            }
            m_data.user_data.mountid = (uint)mountbaseId;
            m_data.user_data.mountskinid = (uint)skinid;
            OnRideMountChange(mountbaseId == 0);
        }

        public override void Dodge()
        {
            base.Dodge();

        }

        public override bool IsCharacter()
        {
            return true;
        }
        /// <summary>
        /// 模型创建成功的回调
        /// </summary>
        protected override void OnAvatarCreateDelegate()
        {
            base.OnAvatarCreateDelegate();

            m_headBillboard = new HeadBillboard();
            m_headBillboard.Init(this);
            CC = m_avatar.unityObject.GetComponent<CharacterController>();
            CC.enabled = true;
            CC.radius = 0.25f;

            m_avatar.unityObject.layer = m_layer;

            if (IsInTransform)
            {
                main.Instance.StartCoroutine(ResetShadow());
                return;
            }
            OnWeaponChanged(0);
            /*
            if (RoleConfig.HasValue)
            {
                RoleTableBase tConfigValue = RoleConfig.Value;
                //TODO: 临时装备武器代码
                if (PrimaryWeapon != null)
                {
                    PrimaryWeapon.Release();
                    PrimaryWeapon = null;
                }
                var tWeapon = new Weapon();
                tWeapon.Attachment = AvatarAttachment.Back;
                tWeapon.init(this, tConfigValue.first_weapon, !SyncLoad);
                //确保武器的初始显示状态与宿主一致
                tWeapon.Show(Visible);
                PrimaryWeapon = tWeapon;
                RefreshPrimaryWeaponPos();

                if (SecondaryWeapon != null)
                {
                    SecondaryWeapon.Release();
                    SecondaryWeapon = null;
                }
                if (tConfigValue.weapon_num > 1)
                {
                    var tShieldWeapon = new Weapon();
                    tShieldWeapon.Attachment = AvatarAttachment.Back;
                    tShieldWeapon.init(this, tConfigValue.second_weapon, !SyncLoad);
                    tShieldWeapon.Show(IsShield);
                    SecondaryWeapon = tShieldWeapon;
                    //if(IsShield)

                    //ChangeShieldState();
                }
            }
            */

            TryLoadMakeupData();
        }

        System.Collections.IEnumerator ResetShadow()
        {
            yield return null;

            bool isReset = IsMainCharacter();
            if (!isReset)
            {
                if (m_thisid == 0)
                {
                    if ((GameScene.Instance.currState == GameState.Login)
                    || (GameScene.Instance.currState == GameState.RoleCreate)
                    || (GameScene.Instance.currState == GameState.RoleSelect))
                    {
                    
                        isReset = true;
                    }
                }
            }
            if (isReset)
            {

                if (Avatar != null && Avatar?.unityObject != null)
                {
                    UniqueShadow shadow = Avatar?.unityObject?.GetComponent<UniqueShadow>();
                    if (shadow != null)
                    {
                        //重置一下阴影显示
                        shadow.ResetMaterial();
                        //shadow.enabled = false;
                    }
                }
            }
        }

        public void OnMountChanged()
        {
            if (IsMainCharacter())
            {
                AdjustTargetSpeed = AdjustSpeed = speed;
                if (Mount != null)
                    CameraController.Instance.SetTarget(Mount.Avatar.unityObject.transform);
                else
                    CameraController.Instance.SetTarget(Avatar.unityObject.transform);
            }
        }
        public void TryLoadMakeupData()
        {
            if (m_makeupData != null)
            {
                LoadHead();
            }
            else
            {
                if (IsMainCharacter())
                {
                    RoleSelectionManager.Instance.GetLastMakeupData(ref m_makeupData);
                }

                if (m_makeupData != null)
                {
                    LoadHead();
                }
                else
                {
                    //temp;
                    //LoadHead();
                    if (ThisID == 0)
                    {
                        LoadHead();
                    }
                    else
                    {
                        ulong[] uids = new ulong[1];
                        uids[0] = ThisID;

                        MakeupOutGameManager.Instance.ReqFacialFeature(uids);
                    }
                }
            }
        }

        /// <summary>
        /// 加载头部模型和头发模型;
        /// </summary>
        private void LoadHead()
        {
          
            if (RoleConfig.HasValue)
            {
                RoleTableBase tConfigValue = RoleConfig.Value;
                string tHeadName = m_headModelName;
                string tHairName = m_hairModelName;
                bool tIsFemale = (this.Sex == swm.CareerSex.Female);

                if (m_pinchingFaceResultData == null)
                {
                    if (m_makeupData != null)
                    {
                        m_pinchingFaceResultData = PinchingFaceResultDataAssistant.Pop();
                        PinchingFaceResultDataAssistant.ByteToPinchingFaceResultData(ref m_pinchingFaceResultData, m_makeupData);

                        BasePartConfig bc = PinchingFaceResultDataAssistant.GetExchangeBasePartConfig(m_pinchingFaceResultData, BodyComponentType.Face);
                        if (bc != null)
                        {
                            tHeadName = bc.name;
                        }

                        bc = PinchingFaceResultDataAssistant.GetExchangeBasePartConfig(m_pinchingFaceResultData, BodyComponentType.Hair);
                        if (bc != null)
                        {
                            tHairName = bc.name;
                        }

                    }
                }

                if (string.IsNullOrEmpty(tHeadName))
                {
                    tHeadName = tIsFemale ? tConfigValue.female_head_model : tConfigValue.male_head_model;
                }
                LoadHeadModel(tHeadName, !IsMainCharacter() && !SyncLoad);

                if (string.IsNullOrEmpty(tHairName))
                {
                    if (m_data.user_data.fids != null && m_data.user_data.fids.Count > 0)
                    {
                        var tFid = m_data.user_data.fids[(int)swm.FashionSlot.HairStyle];
                        if (tFid > 0)
                        {
                            var tFashionConfig = FashionTableManager.GetData((int)tFid);
                            if (tFashionConfig.HasValue)
                                tHairName = tFashionConfig.Value.model;
                        }
                    }
                }

                if (string.IsNullOrEmpty(tHairName))
                {
                    tHairName = tIsFemale ? tConfigValue.female_hair_model : tConfigValue.male_hair_model;
                }

                LoadHairModel(tHairName, !IsMainCharacter() && !SyncLoad);
            }
        }
        private void OnHeadModelLoaded(UnityEngine.Object o)
        {
            headRoot = o as GameObject;

            if (m_pinchingFaceResultData != null)
            {
                BasePartConfig bc = PinchingFaceResultDataAssistant.GetExchangeBasePartConfig(m_pinchingFaceResultData, BodyComponentType.Horn);
                if (bc != null)
                {
                    ChangeDecoration(bc.name, null);
                }
            }

            isLoadHeadFinished = true;

            if (IsMainCharacter() || (m_thisid == 0))
            {
                if (headRoot != null)
                {
                    m_headAnimCtrl = headRoot.GetComponent<MakeUpAnimationController>();

                    if (m_headAnimCtrl == null)
                    {
                        m_headAnimCtrl = headRoot.AddComponent<MakeUpAnimationController>();
                    }

                    if (m_headAnimCtrl != null)
                    {
                        m_headAnimCtrl.Startup(this);
                    }
                }
            }
            else
            {
                Animator headAnimator = headRoot.GetComponent<Animator>();
                if (headAnimator != null)
                {
                    headAnimator.runtimeAnimatorController = null;
                }
            }
            if (m_thisid == 0)
            {
                if (headRoot != null)
                {
                    //在选角时设置细节贴图
                    Texture2D detailTex = MakeUpUtility.GetSrcTexture(
                            "art_resource/entities/characters/chr_head/tex/chr_fm_head_dm_m.tga");
                    MakeUpUtility.SetMaterialTexture(headRoot.transform.GetChild(2).GetComponent<SkinnedMeshRenderer>(),0,MakeUpUtility.sp_DetailMap,detailTex);
                    //这里会load多次，应该在加载脚本时Cache，进游戏时Release
                    detailTex = null;
                    Game.RoleSelectionIBLSystem.ApplyTextureConfig();

                }
            }
            else
            {
                MakeUpUtility.SetMaterialTexture(headRoot.transform.GetChild(2).GetComponent<SkinnedMeshRenderer>(),0,MakeUpUtility.sp_DetailMap,null);
            }

            trySetMakeupDataToChar();
        }

        private void LoadHeadModel(string headname, bool async, LoadCallback callback = null)
        {
            m_headModelName = headname;
            m_avatar.LoadPart(AvatarPart.Head, IResourceLoader.strCharacterHeadPath, headname, async, callback);
        }

        /// <summary>
        /// 同步操作;
        /// </summary>
        /// <param name="modelName"></param>
        /// <param name="cb"></param>
        public void ChangeDecoration(string modelName, LoadCallback cb)
        {
            m_avatar.LoadSubPart(AvatarPart.Head, IResourceLoader.strCharacterDecorationPath, modelName, "head_root", (obj)=> {
                if (obj != null)
                {

                    m_hornModelName = modelName;

                    Transform t = (obj as GameObject).transform.Find("head_root");
                    if (t != null)
                    {
                        t.localEulerAngles = Vector3.zero;
                        t.localPosition = Vector3.zero;
                        t.localScale = Vector3.one;
                    }

                    main.Instance.StartCoroutine(ResetShadow());
                }

                cb?.Invoke(obj);
            });
        }
        public override void OnAvatarChanged(GameObject go)
        {
            base.OnAvatarChanged(go);

            if(PrimaryWeapon != null)
                PrimaryWeapon.Attachment = GetPrimaryWeaponPos(PrimaryWeapon);
        }

        public void ClearDecoration()
        {
            m_hornModelName = "";
            m_avatar.LoadSubPart(AvatarPart.Head, IResourceLoader.strCharacterDecorationPath, "", "head_root", null);

            main.Instance.StartCoroutine(ResetShadow());
        }

        public MakeUpAnimationController GetHeadAnimationController()
        {
            return m_headAnimCtrl;
        }

        public void GetHairModelName(out string name)
        {
            name = m_hairModelName;
        }

        public string GetHairModelName()
        {
            return m_hairModelName;
        }

        public void GetHeadModelName(out string name)
        {
            name = m_headModelName;
        }

        public string GetHeadModelName()
        {
            return m_headModelName;
        }

        public void GetDecorationModelName(out string name)
        {
            name = m_hornModelName;
        }

        public string GetDecorationModelName()
        {
            return m_hornModelName;
        }
        private LoadCallback m_onLoadHairModelCallback = null;
        private void LoadHairModel(string hairname, bool async, LoadCallback cb = null)
        {
            m_onLoadHairModelCallback = cb;
            m_avatar.LoadPart(AvatarPart.Hair, IResourceLoader.strCharacterHairPath, hairname, async, OnLoadHairModelFinished);
        }

        public void OnLoadHairModelFinished(UnityEngine.Object o)
        {
            if ((GameScene.Instance.currState == GameState.Login)
                || (GameScene.Instance.currState == GameState.RoleCreate)
                || (GameScene.Instance.currState == GameState.RoleSelect))
            {
                if (m_thisid == 0)
                {
                    MakeupInGameManager.Instance.ChangeMakeupHairMat(o as GameObject);
                }
            }

            m_hairModelName = o ? o.name.Replace("(Clone)", "") : "";
            main.Instance.StartCoroutine(ResetShadow());

            if (m_onLoadHairModelCallback != null)
            {
                m_onLoadHairModelCallback.Invoke(o);

                m_onLoadHairModelCallback = null;
            }

            isLoadHairFinished = true;

            trySetMakeupDataToChar();
        }
        protected override void OnDataUpdate()
		{
			base.OnDataUpdate();
            //策划说不要了。。。
			//if (m_userData.career_type == swm.CareerType.Mage)
			//{
			//	if (m_earthSwords == null)
			//	{
			//		m_earthSwords = new EarthSwords();
			//		m_earthSwords.Init(this);
			//	}

			//}
			//else
			//{
			//	if (m_earthSwords != null)
			//	{
			//		m_earthSwords.Destroy();
			//		m_earthSwords = null;
			//	}
			//}

            m_professionConfig = ProfessionTableManager.GetData((int)CareerType);
			if (m_professionConfig.HasValue)
			{
				m_fHitBlockTime = m_professionConfig.Value.hitblocktime / 1000.0f;
			}
            
            DoLoadModel();
            IsNeedAppearPlay = false;
            RefreshMount();
        }
        protected virtual void RefreshMount(bool isDisappear = false)
        {
            if (!Actived)
                return;
            bool hasMount = false;
            Vector3? mountVoxPos = null;// = Vector3.zero;
            uint mountVoxID = 0;
            if (m_mount != null)//如果有坐骑
            {
                mountVoxID = m_mount.VoxelWorldID;
                //if (VoxelWorldID != 0)
                mountVoxPos = m_mount.Position;
                if (m_mount.Config.id == RideMountBaseID)//原坐骑相同 不处理
                {
                    if (m_mount.Avatar != null)
                    {
                        return;
                    }
                }

                if (IsJumpingFromMount)
                {
                    IsJumpingFromMount = false;
                    Jump2Trigger = 1;
                }
                if (isDisappear)//下坐骑
                {
                    m_isMountDisappearing = true;
                    m_mount.Disappear();
                    Game.GameApplication.Instance.GetTimerManager().AddTimer(() =>
                    {
                        ReleaseMountDelay();
                    }, m_tWaitForSeconds);
                }
                else//否则 先释放掉原来的坐骑
                {
                    ReleaseMount();
                }
                hasMount = true;
            }
            if (RideMountBaseID != 0)
            {
                m_mount = GameScene.Instance.GetNewMount();
                m_mount.InitEntity(0);
                m_mount.init(this, RideMountBaseID, RideMountSkinID);
                m_mount.VoxelWorldID = VoxelWorldID;

                m_mount.Position = Position;
                m_mount.Direction = Direction;
                m_isMountDisappearing = false;
                GameScene.Instance.AddEntity(m_mount);
            }
            else
            {
                SetAvatarDirection();
                SetAvatarPosition();
            }

            if (Mount)
            {
                if (VoxelWorldID != 0)
                {
                    Mount.Position = Position;

                    Mount.VoxelWorldID = VoxelWorldID;
                    if(m_mount.Avatar!=null)
                    {
                        m_mount.Avatar.SetPosition(Mount.Position);
                    }                   

                }
            }
            else
            {
                if (mountVoxID != 0)
                {
                    VoxelWorldID = mountVoxID;
                    Position = mountVoxPos.Value;
                    SetAvatarPosition();
                   // LogHelper.Log("[HC]Set Pos", Position);
                }
                if (hasMount) OnMountChanged();
            }
            onRefreshMountChange.Invoke();
        }

        float m_tWaitForSeconds = 0.8f;
        void ReleaseMountDelay()
        {
            if (m_isMountDisappearing)
            {
                if (m_mount)
                {
                    GameScene.Instance.RemoveEntity(m_mount);
                    m_mount = null;
                }
                
                m_isMountDisappearing = false;
                
            }
        }

        protected override void OnPositionChange()
        {
            base.OnPositionChange();
            if (Mount)
            {
                Mount.Position = Position;
                //if (IsMainCharacter())
                //{
                //	LogHelper.Log("set pos:" + Position);
                //}
            }
        }

        protected override void OnDirectionChange()
        {
            base.OnDirectionChange();
            if (Mount)
            {
                Mount.Direction = Direction;
            }
        }
        protected override void OnActivedChange()
        {
            base.OnActivedChange();
            IsNeedAppearPlay = false;
            RefreshMount();
        }

        bool m_isNeedAppearPlay;
        public bool IsNeedAppearPlay
        {
            get
            {
                return m_isNeedAppearPlay;
            }
            set
            {
                //LogHelper.LogError("IsNeedAppearPlay " + value);
                m_isNeedAppearPlay = value;
            }
        }

        protected void OnRideMountChange(bool isDisappear)
        {
            IsNeedAppearPlay = !isDisappear;//这个判断是否播放上马动作 动作在状态机enter里播放
            RefreshMount(isDisappear);
            onRideMountChange.Invoke();
        }

        public override void OnAddToScene()
        {
            base.OnAddToScene();
            DoLoadModel();
        }
        protected override void CreateStateMachine()
        {
            m_sm = SM.Factory.CreateSM(this);
        }

        protected override void ReleaseStateMachine()
        {
            SM.Factory.ReleaseCharacterSM(m_sm);
            m_sm = null;
        }

        public override void RefreshCanAttack()
		{
			if(IsFriendly)
			{
				CanAttack = false;
				return;
			}
			if(GameScene.Instance.MainChar == null)
			{
				CanAttack = false;
				return;
			}
			var maincharmode = GameScene.Instance.MainChar.CurPKMode;
            var maincharCamp = GameScene.Instance.MainChar.CampType;
	
			CanAttack = (maincharmode == swm.PKModeType.Killing && IsTopLevel) || 
                (BattleFieldManager.Instance.InBattle && CampType != maincharCamp) ||/*(maincharmode == swm.PKModeType.Camp && m_data.camp_type != maicharcamptype) ||*/
                //maincharmode == swm.PKModeType.Killing ||
                (maincharmode != swm.PKModeType.Killing && IsInHitBackList) || //自己不是杀戮木事，对方攻击列表中
                IsChallengeTarget || IsDuleTarget || (maincharmode == swm.PKModeType.Peace && KillQi > 0);
		}
		public override void OnRemoveFromScene()
        {
            base.OnRemoveFromScene();
            if (m_headBillboard != null)
            {
                m_headBillboard.Dispose();
                m_headBillboard = null;
            }

            if (m_earthSwords != null)
            {
                m_earthSwords.Destroy();
                m_earthSwords = null;
            }
        }
		protected virtual void OnPkModeChange()
		{
			RefreshCanAttack();
			onPKModeChange.Invoke();
			
		}
		bool m_oldShield = false;

        private void ChangeShieldState() {
            if (SecondaryWeapon == null)
                return;

            var isshield = IsShield;
            //if(IsMainCharacter())
            //    LogHelper.Log("[HC]BufferChange", isshield);

            if (isshield != m_oldShield)
            {
                m_oldShield = isshield;
                //设置玩家状态
                if (isshield)
                {
                    //副武器
                    if (SecondaryWeapon != null)
                    {
                        SecondaryWeapon.Attachment = AvatarAttachment.LeftHandProp;
                        SecondaryWeapon.Show(true);
                        PlayEffect("fx_dun_chuxian", AvatarAttachment.Root);
                        main.Instance.StartCoroutine(ResetShadow());
                    }
                }
                else
                {
                    //取消盾牌
                    if (SecondaryWeapon != null)
                    {
                        SecondaryWeapon.Attachment = AvatarAttachment.Back;
                        SecondaryWeapon.Show(false);
                        //取消盾牌特效
                        PlayEffect("fx_dun_posui", AvatarAttachment.LeftHand);
                        main.Instance.StartCoroutine(ResetShadow());
                    }
                }

            }
        }
		protected override void OnBuffChange(BuffBase buff)
		{
			
			base.OnBuffChange(buff);
            ChangeShieldState();

        }
		//protected override void OnFlagStateChange(swm.MapEntityFlags oldstate)
  //      {
  //          base.OnFlagStateChange(oldstate);

  //      }

		public override void setMotion(float x, float z)
		{
			if (Mount)
			{
                Mount.setMotion(x,z);
				return;
			}
			base.setMotion(x, z);
		}

		public override void setMotionY(float y)
		{
			if(Mount)
			{
				Mount.setMotionY(y);
				return;
			}
			base.setMotionY(y);
		}

        protected override void DoLoadModel(string _path = "")
        {
            string modulepath = string.Empty;
             if(string.IsNullOrEmpty(_path))
            {
                modulepath = GetCurrentTransformationModel();
            }
            else
            {
                modulepath = _path;
            }
                
//             if (VehicleId != 0)
//             {
//                 //进入变身
//                 if (VehicleConfig != null && !string.IsNullOrEmpty(VehicleConfig.Value.model))
//                 {
//                     modulepath = VehicleConfig.Value.model;
//                 }
//                 else
//                 {
//                     LogHelper.LogError("Invalid vehicle id :", VehicleId.ToString());
//                 }
//             }
//             else
            if(string.IsNullOrEmpty(modulepath))
            {
                //正常角色
                if (m_data.user_data.fids != null && m_data.user_data.fids.Count > 0)
                {
                    var fid = m_data.user_data.fids[(int)swm.FashionSlot.Dress];
                    if (fid != 0)
                    {
                        var config = FashionTableManager.GetData((int)fid);
                        if (config.HasValue)
                        {
                            if (!this.IsMainCharacter())
                            {
                                if (GameScene.Instance.currState == GameState.RoleCreate || GameScene.Instance.currState == GameState.RoleSelect)
                                {
                                    if (!string.IsNullOrEmpty(config.Value.highprecision_model))
                                    {
                                        modulepath = config.Value.highprecision_model;
                                    }
                                }
                            }
                            if (modulepath == null)
                                modulepath = config.Value.model;
                        }
                    }
                }
            }

            LoadModel(modulepath);
            if (IsMainCharacter())
            {
                (this as MainCharacter).ToggleCarefulCameraEffect(VehicleId != 0);
                GameScene.Instance.onRefreshCarefulStateUI.Invoke();
            }
        }
		public override void LoadModel(string modelPath = null)
        {
			if (string.IsNullOrEmpty(modelPath))
			{
                //fallback
				string tModelName = "chr_mm_warrior";
                if (RoleConfig.HasValue)
                {
                    RoleTableBase tConfigValue = RoleConfig.Value;
                    //是否在角色创建或选择界面
                    bool tIsInRoleCreateOrSelectScene = (GameScene.Instance.currState == GameState.RoleCreate || GameScene.Instance.currState == GameState.RoleSelect);
                    //是否女人
                    bool tIsFemale = (Sex == swm.CareerSex.Female);
                    if(tIsInRoleCreateOrSelectScene)
                        tModelName = tIsFemale ? tConfigValue.female_show_model : tConfigValue.male_show_model;
                    else
                        tModelName = tIsFemale ? tConfigValue.female_normal_model : tConfigValue.male_normal_model;
                }

                if (tModelName == CurModelPath)
					return;

                //ReleaseStateMachine();
                AvatarLoadModel(IResourceLoader.strCharacterPath, tModelName, !IsMainCharacter() && !SyncLoad);
                CurModelPath = tModelName;
			}
			else
			{
				if (modelPath == CurModelPath)
					return;

                //ReleaseStateMachine();
                string rootPath;
                if(!IsInTransform)
                {
                    rootPath = IResourceLoader.strCharacterPath;
                }
                else
                {
                    rootPath = IResourceLoader.strNpcPath;//变身路径中npc目录下
                }
                 
                AvatarLoadModel(rootPath, modelPath, !IsMainCharacter() && !SyncLoad);

                CurModelPath = modelPath;
			}
        }
        public void ChangeBodyModel(string modelpath)
        {
            m_avatar.LoadPart(AvatarPart.Body, IResourceLoader.strCharacterPath, modelpath, !SyncLoad);
        }
        public void ChangeHairModel(string modelpath,LoadCallback cb=null)
        {
            if (m_hairModelName == modelpath)
            {
                cb?.Invoke(null);
                return;
            }
            m_hairModelName = modelpath;
            LoadHairModel(modelpath, !SyncLoad, cb);
        }

        public void ChangeFaceModel(string modelpath, LoadCallback cb = null)
        {
            if (m_headModelName == modelpath)
            {
                cb?.Invoke(null);
                return;
            }
            m_headModelName = modelpath;
            LoadHeadModel(modelpath, !IsMainCharacter() && !SyncLoad, (o)=>{
                if (cb != null)
                {
                    GameObject headRoot = o as GameObject;
                    if (headRoot)
                    {
                        cb(o);
                    }
                }
            });
        }

        /// <summary>
        /// 穿戴饰品
        /// </summary>
        /// <param name="modelpath">模型名称</param>
        /// <param name="targetAttachment">目标绑点</param>
        public void DressDecoration(int fashionid)
        {
            if (fashionid <= 0)
                return;

            var config = FashionTableManager.GetData(fashionid);

            var slot = (swm.FashionSlot)config.Value.slottype;

            TakeOffDecoration(slot);
                
            var decoration = new Decoration();
            decoration.init(this, config.Value.model, !SyncLoad);

            AvatarAttachment targetAttachment = (AvatarAttachment)config.Value.target_binding;
            decoration.Attachment = targetAttachment;
            //确保武器的初始显示状态与宿主一�???
            decoration.Avatar.Visible = Visible;

            switch (slot)
            {
                case swm.FashionSlot.Waist:// 腰饰
                    {
                        Waist = decoration;
                    }
                    break;
                case swm.FashionSlot.HairAccessory:// 发饰
                    {
                        HairAccessory = decoration;
                    }
                    break;
                case swm.FashionSlot.BackDecoration:// 背饰
                    {
                        BackDecoration = decoration;
                    }
                    break;
            }
        }
        public void TakeOffDecoration(swm.FashionSlot slot)
        {
            switch (slot)
            {
                case swm.FashionSlot.Waist:// 腰饰
                    {
                        if (Waist != null)
                        {
                            Waist.Release();
                            Waist = null;
                        }
                    }
                    break;
                case swm.FashionSlot.HairAccessory:// 发饰
                    {
                        if (HairAccessory != null)
                        {
                            HairAccessory.Release();
                            HairAccessory = null;
                        }
                    }
                    break;
                case swm.FashionSlot.BackDecoration:// 背饰
                    {
                        if (BackDecoration != null)
                        {
                            BackDecoration.Release();
                            BackDecoration = null;
                        }
                    }
                    break;
            }
        }
         protected override void OnQingKungStart()
        {
            base.OnQingKungStart();
        }
        protected override void OnQingKungStop()
        {
            base.OnQingKungStop();
            VisibleByAction = true;
        }

		public override int BlinkTo(Vector3 target, float speed)
		{
			if (Mount)
				return Mount.BlinkTo(target, speed);
			else
				return base.BlinkTo(target, speed);
		}

        public override void Update()
        {
            if (VoxelWorldID != 0 && !VoxelWorldLoaded)
                return;

            base.Update();
            if (m_sm == null)
                return;

            m_AdjustSpeed += (AdjustTargetSpeed - m_AdjustSpeed) * 0.1f;
            if (!Mount&& m_b_isBeAttachTo==false)
            {
                if (!IsInDirectMove)
                {
                    if (UseGravity /*&& VoxelWorldID == 0*/ )
                    {
                        if (VoxelWorldID == 0)
                            m_motion.y = -10.0f * Time.deltaTime;
                        else
                            m_motion.y = -1.0f * Time.deltaTime;
                    }
                }

                if (m_cc != null)
                {
                    //var oldposition = Avatar.unityObject.transform.localPosition;
                    if (!IsInDirectMove)
                    {
                        ApplyMove(m_motion);
                    }
                    var position = Avatar.unityObject.transform.localPosition;

                    //if (IsMainCharacter())
                    //{
                    //    var delta = position - oldposition;
                    //    LogHelper.Log("[HC]ApplyMove", oldposition, position, m_motion.x, m_motion.y, m_motion.z, "->", delta.x, delta.y, delta.z );
                    //}

#if MOVE_WORLD
                    if (VoxelWorldID == 0)
                        position += LayeredSceneLoader.WorldOffset;
#endif
                    OldPosition = Position;
                    Position = position;

                }

            }

            if (m_earthSwords != null)
            {
                m_earthSwords.Update();
            }

        }

        protected override void OnMoveStart()
        {
            MoveStart.Invoke();
        }

        public override void ApplyMove(Vector3 d)
        {
            if (Mount)
                return;
            if (m_cc && m_cc.enabled)
            {
                
                m_cc.Move(d);
            }
            else
            {
                Position += d;
            }
        }

        public override void SetAvatarPosition()
        {
            if (Mount)
            {
                return;
            }
            base.SetAvatarPosition();
        }

        protected override void SetAvatarDirection()
        {
            if (Mount && !m_isMountDisappearing)
            {
                return;
            }
            base.SetAvatarDirection();
        }

        protected override void OnVoxelWorldChange(uint oldid)
        {
            if(Mount)
            {
                Mount.VoxelWorldID = VoxelWorldID;
                return;
            }
            base.OnVoxelWorldChange(oldid);
        }

        public override bool IsNeedMove()
        {
            if (!CanMove)
                return false;
            var destpos = m_destPos;
            destpos.y = Position.y;
            return (destpos - Position).magnitude > Utility.MoveMinDistance;
        }
        #region 闪避
        private float m_DodgeEnegyValue = 5;
        private float m_DodgeEnegyMaxValue = 5;
        public float DodgeEnegyValue
        {
            get { return m_DodgeEnegyValue; }
        }
        public float DodgeEnegyMaxValue
        {
            get { return m_DodgeEnegyMaxValue; }
        }
        public GameEvent<float> OnDodgeEnegyChanged = new UnityEventFloat();
        public void SetDodgeEnegy(float v, float mv)
        {
            m_DodgeEnegyMaxValue = mv;
            m_DodgeEnegyValue = v > 0 ? v : 0 ;
            if (OnDodgeEnegyChanged != null)
                OnDodgeEnegyChanged.Invoke(m_DodgeEnegyValue);
        }

        #endregion
        

        private bool m_isCloudFlyDown;
        public bool IsCloudFlyDown
        {
            get
            {
                return (m_isCloudFlyDown && isCurrInCloud() && isEnterFly);
            }
            set
            {
                m_isCloudFlyDown = value;
            }
        }
        private bool m_isCloudFlyUp;
        public bool IsCloudFlyUp
        {
            get
            {
                return (m_isCloudFlyUp && isCurrInCloud() && isEnterFly);
            }
            set
            {
                m_isCloudFlyUp = value;
            }
        }

        public bool isCloudFlyMove()
        {
            return ((IsCloudFlyUp || IsCloudFlyDown));
        }

        /// <summary>
        /// 载具变化
        /// </summary>
        void OnVehicleChange()
        {
            //OnRefreshTransformationChange();
        }
        /// <summary>
        /// 进入变身 预处理
        /// </summary>
        protected override void OnEnterTransformation()
        {
            base.OnEnterTransformation();
            m_headModelName = string.Empty;
            m_hairModelName = string.Empty;

            isSetMakeupToChar = false;
            if (earthSwords != null)
                earthSwords.Hide();
        }
        /// <summary>
        /// 退出变身 后处理
        /// </summary>
        protected override void OnQuitTransformation()
        {
            if (earthSwords != null)
                earthSwords.CancelHide();
        }

        public void ClothSleep(bool enter)
        {
            if (m_avatar.unityObject == null)
                return;

            if (enter)
            {
                m_avatar.unityObject.ClothEnterSleep();
            }
            else
            {
                m_avatar.unityObject.ClothExitSleep();
            }
        }

        public override void RemoveAllEffects()
        {
            base.RemoveAllEffects();

            //**********************************************
            // Remove effects attached to character
            //**********************************************
            if (RoleCreationManager.Instance != null)
                RoleCreationManager.Instance.StopActionEffect(this);

            //*************************************************
            // Remove depth of field (only QingKung's for now)
            //*************************************************
            if (UnityEngine.Rendering.PostProcessing.PostProcessManager.instance != null)
            {
                var setting = UnityEngine.Rendering.PostProcessing.PostProcessManager.instance.GetPostProcessSetting<UnityEngine.Rendering.PostProcessing.RadialBlur>();
                if (setting)
                {
                    setting.enabled.value = false;
                    setting.blurEnable.value = false;
                }
            }
        }
    }
}