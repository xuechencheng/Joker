#define MOVE_WORLD
using System;
using Bokura;
using UnityEngine;
using swm;
using System.Collections;
using System.Collections.Generic;

namespace Bokura
{
    public class ClientNpc : MovableEntity
    {
        private NpcTableBase? m_npcConfig;
        private string m_currentModelPath = string.Empty;
        public GameEvent OnMoveArrivedEvent = new GameEvent();



        private swm.MapNpcT m_npcData = new swm.MapNpcT();
        public swm.MapNpcT NpcData
        {
            get { return m_npcData; }
        }



        public NpcTableBase? NpcConfig
        {
            get
            {
                return m_npcConfig;
            }
        }

        public override bool Selectable
        {
            get
            {
                return m_npcConfig != null ?
                    (m_npcConfig.Value.type != (int)swm.NpcType.NPCTYPE_TIGGER &&
                    m_npcConfig.Value.type != (int)swm.NpcType.NPCTYPE_GATHER) : false;
            }
        }
        public override uint BaseID
        {
            get
            {
                return m_npcData.baseid;
            }
        }
        public override CareerSex Sex
        {
            get
            {
                return m_npcData.career_sex;
            }
        }

        public AiStatusType MoveType = AiStatusType.Idle;
        public bool ActionShow = false;
        public string ActionName = "";



        public override Entity Clone(ulong _id = 0, CloneUsage _Usage = CloneUsage.NpcVisit)
        {
            ClientNpc _entity = new ClientNpc(_id);
            _entity.SyncLoad = true;
            var tData = m_data.Clone();
            if (_Usage == CloneUsage.Drama)
                tData = HandleDataForDrama(tData);
            _entity.init();
            _entity.SetData(tData);
            _entity.OnAddToScene();
            _entity.Position = Position;
            _entity.Direction = Direction;
            return _entity;
        }



        public ClientNpc(ulong id):base(id)
        {
            m_layer = (Int32)(UserLayer.Layer_NPC);
            m_avatar.shadowType = AvatarShadowType.Decal;

        }

        ~ClientNpc()
        {
        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public ClientNpc() : base()
        {
        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public override void InitEntity(ulong id)
        {
            base.InitEntity(id);
            m_layer = (Int32)(UserLayer.Layer_NPC);
            m_avatar.shadowType = AvatarShadowType.Decal;
        }

        public override void SetData(MapEntityDataT data)
        {
            m_npcData = data.npc_data;
            base.SetData(data);
        }

        public override void RefreshCanAttack()
        {
            CanAttack = m_npcConfig.HasValue ? m_npcConfig.Value.under_attack != 0 : false;

        }

        protected override void OnDataUpdate()
        {
            base.OnDataUpdate();
            if (m_data != null)
            {
                m_npcConfig = NpcTableManager.GetData((int)BaseID);
                LoadModel();
            }
        }
        public bool m_UpdateMove = false;
        public override void Update()
        {
            base.Update();
            if (m_UpdateMove==true&&m_cc != null)
            {

                //if (!m_syncer.IsSyncPos && m_directMoveDistance == 0.0f)
                //{
                   
                //    if (m_ForceMoveVec.sqrMagnitude > 0.001f)
                //        ApplyMove(m_motion + m_ForceMoveVec * Time.deltaTime);
                //    else
                //        ApplyMove(m_motion);

                    
                //}
                ApplyMove(m_motion);
                var position = Avatar.unityObject.transform.position;
#if MOVE_WORLD
                position += LayeredSceneLoader.WorldOffset;
#endif
                Position = position;

            }

            if (m_InThrowPhase)
                UpdateThrow();
        }


        public override void SetNetData(MapEntityData _data)
        {
            m_npcData.FromMsg(_data.npc_data.Value);

            base.SetNetData(_data);
            RefreshCanAttack();
        }

        public override void init()
        {
            base.init();
            m_npcConfig = NpcTableManager.GetData((int)BaseID);

        }

        public override void LoadModel(string modelpath = null)
        {

            if (string.IsNullOrEmpty(modelpath))
            {
                if (m_npcConfig != null && m_npcConfig.Value.model != m_currentModelPath)
                {
                    if (string.IsNullOrEmpty(m_npcConfig.Value.model))
                    {
                        LogHelper.LogWarning("ClientNpc:NPC Config Model Is Empty!id=", m_npcConfig.Value.id.ToString());
                        return;
                    }
                    //ReleaseStateMachine();
                    AvatarLoadModel(IResourceLoader.strNpcPath, m_npcConfig.Value.model, !SyncLoad);
                    Actived = true;
                    m_currentModelPath = m_npcConfig.Value.model;
                }
            }
            else if (m_currentModelPath != modelpath)
            {
                //ReleaseStateMachine();
                AvatarLoadModel(IResourceLoader.strNpcPath, modelpath, !SyncLoad);
                m_currentModelPath = modelpath;
                Actived = true;

            }
            Visible = Visible;
        }

        public override bool IsNeedMove()
        {
            return base.IsNeedMove();
        }
        public override UnityEngine.Vector3 GetAdjustGroundPosition()
        {
            var rayoffset = Mathf.Clamp((DestPos - LogicPostition).y, 2, 5);
            RaycastHit hitinfo;
            var src = Position.WorldToUnityVec() + new UnityEngine.Vector3(0, rayoffset, 0);
            if (!Physics.Raycast(src, UnityEngine.Vector3.down, out hitinfo, 10.0f, (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction.Ignore))
            {
                return UnityEngine.Vector3.zero;
            }

            return new UnityEngine.Vector3(Position.x, hitinfo.point.y, Position.z);
        }

        private void procClientNpcPositionChange(UnityEngine.Vector3 _pos)
        {
            Position = _pos;
        }

        private void procClientNpcDirectionChange(UnityEngine.Vector3 _dir)
        {
            Direction = _dir;
        }

        public override void OnAddToScene()
        {
            base.OnAddToScene();
            RefreshMissionState(false);
            m_headBillboard = new HeadBillboard();
            m_headBillboard.Init(this);
        }

        protected override void OnAvatarCreateDelegate()
        {
            base.OnAvatarCreateDelegate();
            CC = m_avatar.unityObject.GetComponent<CharacterController>();
            if(CC != null) CC.enabled = false;
            if (m_headBillboard != null)
                m_headBillboard.Init(this);
        }

        protected override void OnDie()
        {
            base.OnDie();
            if (!string.IsNullOrEmpty(m_npcConfig.Value.die_effect))
            {
                EffectMgr.Instance.Play(m_npcConfig.Value.die_effect, this, AvatarAttachment.Root, IResourceLoader.strSceneEffectPath);
            }
        }

        protected override void CreateStateMachine()
        {
            m_sm = SM.Factory.CreateSM(this);
        }

        protected override void ReleaseStateMachine()
        {
            SM.Factory.ReleaseClientNpcSM(m_sm);
            m_sm = null;
        }

        public override void OnRemoveFromScene()
        {
            base.OnRemoveFromScene();
            m_headBillboard.Dispose();
            m_headBillboard = null;
        }

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public override void ResetEntity()
        {
            base.ResetEntity();
            m_npcConfig = null;
            m_npcData = new swm.MapNpcT();
            m_currentModelPath = string.Empty;
            OnMoveArrivedEvent.RemoveAllListeners();
            MoveType = AiStatusType.Idle;
        }

        #region Throw
        private bool m_InThrowPhase = false;
        
        private float m_CurTime;

        private float m_VerticalVel;
        private UnityEngine.Vector3 m_HorizontalVel;

        private float m_ScaleRate;
        private int deltaTime;
        private int TotalTime;
        private static float gravity = 9.8f;

        [XLua.BlackList]
        public void ApplyThrow(UnityEngine.Vector3 from, UnityEngine.Vector3 to, float initScale, float deathTime, float time = 1)
        {
            float deltaY = (from - to).y;
            to = new UnityEngine.Vector3(to.x, 0, to.z);
            from = new UnityEngine.Vector3(from.x, 0, from.z);

            float val = time / Time.deltaTime;
            deltaTime = Mathf.CeilToInt(val);
            val = (time + deathTime) / Time.deltaTime;
            TotalTime = Mathf.CeilToInt(val);
            m_CurTime = 0;

            m_ScaleRate = (1 - initScale) / deltaTime;
            m_HorizontalVel = (to - from).normalized * ((to - from).magnitude / deltaTime);
            
            m_VerticalVel = ((gravity * time * time - 2 * deltaY) / (2 * time));

            m_InThrowPhase = true;
        }

        private void UpdateThrow()
        {
            if (m_CurTime < deltaTime)
            {
                float delta = Time.deltaTime;
                m_CurTime++;

                UnityEngine.Vector3 curVelocity = m_HorizontalVel;

                float oldVSpeed = m_VerticalVel;
                m_VerticalVel = m_VerticalVel - gravity * delta;
                float deltaY = (oldVSpeed + m_VerticalVel) * delta / 2;

                UnityEngine.Vector3 deltaOffset = UnityEngine.Vector3.up * deltaY + curVelocity;

                Avatar.unityObject.transform.position += deltaOffset;

                Avatar.unityObject.transform.localScale += UnityEngine.Vector3.one * m_ScaleRate;
            }
            else if(deltaTime <= m_CurTime && m_CurTime < TotalTime)
            {
                Died = true;
                m_CurTime++;
            }
            else
            {
                m_InThrowPhase = false;
                ClientNpcEntityManager.Instance.LaterRemoveEntityList.Add(ThisID);
            }
        }
        #endregion
    }
}
