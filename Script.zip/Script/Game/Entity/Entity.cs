using UnityEngine;
using System;
using System.Collections.Generic;
using Magic;
using UnityEngine.Playables;

namespace Bokura
{
	public class Entity : AvatarEvent
    {
        public const string RimColor = "_RimColor";
        public const string RimPower = "_RimPower";
        public static float DefaultPower = 1.0f;
        public static Color DefaultColor = new Color(0, 0, 0, 1);

        protected static float FallCheckDistance = 0.1f;

        /// <summary>
        /// 对于角色贴地的检测
        /// </summary>
        protected const float FallCheckDistanceByGround = 3.0f;

        protected Vector3 m_position = Vector3.zero;
        protected Vector3 m_direction = Vector3.forward;
        protected float m_dirAngle = 0.0f;
		protected float m_pitch = 0.0f;
        protected IAvatar m_avatar;
        protected ulong m_thisid;
        protected bool m_bDied = false;//先默认不死  这个值应该在m_data 里面有 但是现在在临时改 先这样用
        protected bool m_bDeleted;

        protected bool m_bVisible = true;
        protected bool m_bVisibleBySkill = true;
        protected bool m_bVisibleByCamera = true;
        protected bool m_bVisibleByAction = true;
        protected bool m_bVisibleByLevelSystem = true;
        protected bool m_bVisibleByTreasure = true;

        /// <summary>
        /// 是否能够选择
        /// </summary>
        protected bool m_bCanSelect = true;

        protected bool m_bActived = true;
        protected int m_layer = 0;
        protected HeadBillboard m_headBillboard;

        protected BuffProxy m_buffProxy;

        protected UnityEngine.Transform m_targetSelNode;

        protected swm.MapEntityDataT m_data;

        //protected SM.IStateMacine<SM.Entity.States> m_sm;

        protected EntitySyncer m_syncer;

        private RoleTableBase? m_roleTableConfig = null;

        protected uint m_fightPower = 0;

		private Vector3 m_TopTitleOffset = Vector3.zero;
        public override Vector3 TopTitleOffset
		{
			get { return m_TopTitleOffset; }
			set { m_TopTitleOffset = value; }
        }

        private float m_toMainCharacterSqrMagnitude = 0;//距离主角距离的平方;
        public float ToMainCharacterSqrMagnitude
        {
            get { return m_toMainCharacterSqrMagnitude; }
            set { m_toMainCharacterSqrMagnitude = value; }
        }

        public List<Entity> Defenders = new List<Entity>(8);
        public List<GameObject> DefendersObj = new List<GameObject>(8);

        private GameEvent m_TopTitleEvent = new GameEvent();
        public override GameEvent TopTitleEvent
		{
			get { return m_TopTitleEvent; }
		}

        public class AttackTargetChangeEvent : GameEvent<Entity> { }
        AttackTargetChangeEvent m_OnTargetChanged = new AttackTargetChangeEvent();
        public AttackTargetChangeEvent OnTargetChanged
        {
            get { return m_OnTargetChanged; }
        }

        public override Transform HeadTarget
		{
			get { return m_headBillboard.transform; }
		}

		public Entity m_curAttackTarget;

		public Entity CurAttackTarget
		{
			get
			{
				return m_curAttackTarget;
			}
			set
			{
				m_curAttackTarget = value;
                OnTargetChanged.Invoke(m_curAttackTarget);
			}
		}

        public AudioStudio.AnimationSound m_curAnimationSound;

        public AudioStudio.AnimationSound CurAnimationSound
        {
            get
            {
                if (m_curAnimationSound == null && Avatar.unityObject != null)
                {
                    m_curAnimationSound = m_avatar.unityObject.GetComponentInChildren<AudioStudio.AnimationSound>();
                    if (m_curAnimationSound == null)
                        m_curAnimationSound = m_avatar.unityObject.GetOrAddComponent<AudioStudio.AnimationSound>();
                    m_curAnimationSound.PlayerControl = this.IsMainCharacter();
                }
                return m_curAnimationSound;
            }
            set
            {
                m_curAnimationSound = value;
            }
        }
        bool m_bInHitbacklist = false;
        public bool IsInHitBackList
        {
            get
            {
                return m_bInHitbacklist;
            }
            set
            {
                if (value != m_bInHitbacklist)
                {
                    m_bInHitbacklist = value;
                    InHitbackChange.Invoke();
                    RefreshCanAttack();
                }

            }
        }

        bool m_isTreatMainchar = false;
        public bool IsTreatMainchar {
            get {
                return m_isTreatMainchar;
            }
            set {
                m_isTreatMainchar = value;
                TreatmaincharChange.Invoke();
            }
        }

        [XLua.BlackList]
        public bool NeedAnimBlend
        {
            get
            {
                if (Avatar != null)
                    return Avatar.NeedAnimBlend;
                else
                    return false;
            }
        }
        //public void BuildDefenders(List<x2m.SkillEffect> effects)
        //{
        //    Defenders.Clear();
        //    for (int i = 0; i < effects.Count; i++)
        //    {
        //        var effect = effects[i];
        //        var entity = GameScene.Instance.GetEntityByID(effect.entity.entity_type, effect.entity.entity_id);
        //        if (entity != null)
        //        {
        //            Defenders.Add(entity);
        //        }
        //    }
        //}
        public void BuildDefenders(Entity defender)
        {
            if (defender != null)
            {
                Defenders.Add(defender);
            }
        }

        private uint m_currenTransformId = 0;//当前变身id
        public uint currentTransformId
        {
            get
            {
                return m_currenTransformId;
            }
            set
            {
                if(m_currenTransformId != value)
                {
                    m_currenTransformId = value;
                    PorcTransformIdChange();
                }
            }
        }
        /// <summary>
        /// 处理变身
        /// </summary>
        protected virtual void PorcTransformIdChange()
        {

        }

        [XLua.BlackList]
        public bool hasHurt = false;//閸欐鍤悰銊у箛濮ｅ繑顐奸弨璇插毊閸欘亪娓剁憴锕€褰傛稉鈧▎?

        [XLua.BlackList]
        public void RefreshDefenders(swm.NotifyHitEffect hiteffect)
        {
            hasHurt = false;
            for (int i = 0; i < Defenders.Count; i++)
            {
                if (Defenders[i] != null && Defenders[i].Avatar != null)
                {
                    Defenders[i].Avatar.MaterialProterties.SetColor(RimColor, DefaultColor);
                    Defenders[i].Avatar.MaterialProterties.SetFloat(RimPower, DefaultPower);
                }
            }
            Defenders.Clear();
            for (int i = 0; i < hiteffect.effectsLength; i++)
            {
                var effect = hiteffect.effects(i);
                if (effect != null && effect.HasValue)
                {
                    var entity = GameScene.Instance.GetEntityByID(effect.Value.entity_id);
                    if (entity != null)
                    {
                        Defenders.Add(entity);
                    }
                }
            }
            GetDefendersObj();
        }

        [XLua.BlackList]
        public void GetDefendersObj()
        {
            DefendersObj.Clear();
            for (int i = 0; i < Defenders.Count; i++)
            {
                DefendersObj.Add(Defenders[i].Avatar.unityObject);
            }
        }

        public GameEvent onFillMapEntityDataEvent = new GameEvent();
        protected NpcTaskStateInfo m_missionState = null;//
        public Event OnRefreshMissionState = new Event();

        public GameEvent<byte> OnRefreshResourceMissionState = new GameEvent<byte>();

        protected GameEvent<uint> m_onRefreshCollectionState = new GameEvent<uint>();
        /// <summary>
        /// 刷新收集状态
        /// </summary>
        public GameEvent<uint> onRefreshCollectionState
        {
            get { return m_onRefreshCollectionState; }
        }

        protected GameEvent<Entity> m_onRefreshTaskState = new GameEvent<Entity>();
        /// <summary>
        /// 刷新任务状态（小地图用）
        /// </summary>
        public GameEvent<Entity> OnRefreshTaskState { get { return m_onRefreshTaskState; } }

        protected GameEvent<Entity> m_onChangeResourceState = new GameEvent<Entity>();
        /// <summary>
        /// 采集资源状态变化（小地图用）
        /// </summary>
        public GameEvent<Entity> OnChangeResourceState { get { return m_onChangeResourceState; } }

        public GameEvent OnDataChange = new GameEvent();

		public Event OnHpMpChange = new Event();

		public GameEvent OnAngerChange = new GameEvent();

        public GameEvent onIsInAttackEvent = new GameEvent();

        public GameEvent onAvatarReLoad = new GameEvent();

        public Event InHitbackChange = new Event();

        public Event TreatmaincharChange = new Event();

        /// <summary>
        /// 带id的攻击事件
        /// </summary>
        public GameEvent<Entity> onIsInAttackWithIdEvent = new GameEvent<Entity>();

        private GameEvent m_OnPositionChangeEvent = new GameEvent();
        /// <summary>
        /// 位置变化事件
        /// </summary>
        public override GameEvent onPositionChangeEvent
        {
            get { return m_OnPositionChangeEvent; }
        }
        public GameEvent onVisibleChangeEvent = new GameEvent();

        public GameEvent onTitleNameChangeEvent = new GameEvent();

		private GameEvent m_OnMainCharacterDied = new GameEvent();
		public GameEvent onMainCharacterDied { get { return m_OnMainCharacterDied; } }

        private GameEvent m_onEntityDieChange = new GameEvent();
        public GameEvent onEntityDieChange { get { return m_onEntityDieChange; } }

        private GameEvent<bool> m_onSetTempShowHead = new GameEvent<bool>();
        public GameEvent<bool> onSetTempShowHead { get { return m_onSetTempShowHead; } }
        public Event OnCanAttackChange = new Event();

        public GameEvent onBeAttackEvent = new GameEvent();
        #region property

        public int Layer
		{
            get { return m_layer; }
            set
            {
                m_layer = value;
                Avatar.SetLayer(m_layer);
            }
		}
        public NpcTaskStateInfo EntityMissionState
        {
            get
            {
                return m_missionState;
            }
            set
            {

                m_missionState = value;
            }
        }

		public float Pitch
		{
			get
			{
				return m_pitch;
			}
			set
			{
				m_pitch = value;

				if (m_avatar != null)
					m_avatar.SetDirection(m_direction.x, m_pitch, m_direction.z);
			}
		}

        public uint FightPower
        {
            get
            {
                return m_fightPower;
            }
        }

        public EntitySyncer Syncer
        {
            get
            {
                return m_syncer;
            }
        }
        public swm.MapEntityDataT Data
        {
            get
            {
                return m_data;
            }
        }
		public uint CampType
		{
            get { return m_data.camp_type; }
		}

        protected bool m_SyncLoad = false;
        public bool SyncLoad
        {
            get { return m_SyncLoad; }
            set { m_SyncLoad = value; }
        }

        protected bool m_bTimeLineing = false;
        public bool TimeLineing
        {
            get { return m_bTimeLineing; }
            set {
                if(m_bTimeLineing != value)
                {
                    m_bTimeLineing = value;
                    OnTimeLineChanged();
                }
            }
        }

        protected virtual void OnTimeLineChanged() { }

        bool m_canAttack = false;
		public bool CanAttack
		{
			get
			{
				return m_canAttack;
			}
			set
			{

				if(value != m_canAttack)
				{
					m_canAttack = value;
					OnCanAttackChange.Invoke();
				}
			}
		}

		public override string ToString()
		{
			return Utilities.BuildString(base.ToString(), "<",EntityType.ToString(),":", ThisID.ToString(), ">");
		}

		public virtual void RefreshCanAttack()
		{
			CanAttack = !IsFriendly || IsNpc();
	
		}
        public Vector3 GetBoxColliderCenter()
        {
            Vector3 offset = Vector3.zero;
            if (null != m_avatar)
            {
                BoxCollider bounds = m_avatar.getBoundBox() as BoxCollider;
                if (null != bounds)
                {
                    offset = bounds.center;
                }
            }
            return offset;
        }
        public float GetBoxColliderMinSize()
        {
            float _size = 1.0f;
            if(null != m_avatar)
            {
                BoxCollider bounds = m_avatar.getBoundBox() as BoxCollider;
                if(null != bounds)
                {
                    _size = Math.Min(bounds.size.x, bounds.size.z);
                    if (_size < 1.0f)
                    {
                        _size = 1.0f;
                    }
                }
            }
            return _size;
        }
        protected virtual void FillMapEntityData(swm.MapEntityData _data)
        {
            m_data.FromMsg(_data);
            OnIsInAttackChange();//FromMsg will change entity's attack state, when this happens, function 'OnIsAttackChange' is necessary
            onFillMapEntityDataEvent.Invoke();
        }

        protected virtual void FillMapEntityData(swm.SyncMainUserData _data) {
            ConstructMapEntityData(_data);
            OnIsInAttackChange();//FromMsg will change entity's attack state, when this happens, function 'OnIsAttackChange' is necessary
            onFillMapEntityDataEvent.Invoke();
        }

        ushort cell_server_id = 0;
        EffectMgr.EffectInfoGroup m_serverChangeEffect = null;
        public void SetIsSameServeIdWithMainChar()
        {
            if (!IsMainCharacter())
            {
                bool _b = false;
                if (GameScene.Instance.MainChar != null)
                {
                    _b = GameScene.Instance.MainChar.cell_server_id == cell_server_id;
                }
                if (_b)
                {
                    if (m_serverChangeEffect != null)
                    {
                        //m_serverChangeEffect.Visible = false;
                        m_serverChangeEffect.Stop();
                        m_serverChangeEffect = null;
                    }

                    //SetMaterialProperty("_Color", new Color(1, 1, 1, 1));
                    //SetMaterialProperty("_RimColor", new Color(0, 0, 0, 1));
                    //SetMaterialProperty("_RimPower", 1);
                }
                else
                {
                    if(GameScene.Instance.OpenServerIdBox && IsAvatarLoaded)
                    {
                        if (m_serverChangeEffect == null)
                        {
                            m_serverChangeEffect = EffectMgr.Instance.PlayByConfig("fx_buff_serverchange_effect", this);
                        }
                        
                    }
                    if(m_serverChangeEffect != null)
                    {
                        m_serverChangeEffect.Visible = GameScene.Instance.OpenServerIdBox;
                    }
                    //SetMaterialProperty("_RimColor", new Color(5, 0, 5, 1));
                    //SetMaterialProperty("_Color", new Color(5, 0, 5, 1));
                    //SetMaterialProperty("_RimPower", 2);
                }
            }

        }
        private void ConstructMapEntityData(swm.SyncMainUserData msg)
        {
            if (m_data == null)
                m_data = new swm.MapEntityDataT();

            m_data.entity_id = msg.entity_id;
            m_data.name = msg.name;
            m_data.level = msg.level;
            m_data.model_radius = msg.model_radius;
            m_data.model_radius2 = msg.model_radius2;
            m_data.max_hp = msg.max_hp;
            m_data.cur_hp = msg.cur_hp;
            m_data.max_mp = msg.max_mp;
            m_data.cur_mp = msg.cur_mp;
            m_data.is_die = msg.is_die;
            m_data.change_id = msg.change_id;
            max_anger = (int)msg.max_ap;
            cur_anger = (int)msg.cur_ap;

            if (msg.cur_pos.HasValue)
            {
                m_data.cur_pos.FromMsg(msg.cur_pos.Value);
            }
            if (msg.cur_dir.HasValue)
            {
                m_data.cur_dir.FromMsg(msg.cur_dir.Value);
            }
            //if (msg.dst_pos.HasValue)
            //{
            //    dst_pos.FromMsg(msg.dst_pos.Value);
            //}
            if (msg.attrs.HasValue) {
                m_data.move_speed = msg.attrs.Value.move_speed;
                m_data.attack_speed = (uint)(msg.attrs.Value.attack_speed);

            }
            //m_data.is_fighting = msg.is_fighting;
            // m_data.camp_type = msg.camp_type;
            // m_data.cell_server_id = msg.cell_server_id;
            //if (msg.buffsLength > 0 && buffs == null)
            //    buffs = new List<BuffT>(msg.buffsLength);
            //if (buffs != null && msg.buffsLength < buffs.Count)
            //    buffs.RemoveRange(msg.buffsLength, buffs.Count - msg.buffsLength);
            //for (int i = 0; i < msg.buffsLength; i++)
            //{
            //    if (i >= buffs.Count)
            //        buffs.Add(new BuffT());
            //    buffs[i].FromMsg(msg.buffs(i).Value);
            //}
            if (msg.user_data.HasValue)
            {
                if (m_data.user_data == null)
                    m_data.user_data = new swm.MapUserT();               
                m_data.user_data.FromMsg(msg.user_data.Value);
            }
            //if (msg.npc_data.HasValue)
            //{
            //     if (npc_data == null)
            //        npc_data = new MapNpcT();
            //     npc_data.FromMsg(msg.npc_data.Value);
            //}
            ////if (msg.trap_data.HasValue)
            // {
            //    if (trap_data == null)
            //        trap_data = new MapTrapT();
            //    trap_data.FromMsg(msg.trap_data.Value);
            //}
            // if (msg.mount_data.HasValue)
            //{
            //     if (mount_data == null)
            //         mount_data = new MapMountT();
            //     mount_data.FromMsg(msg.mount_data.Value);
            // }
            // if (msg.resource_data.HasValue)
            // {
            //     if (resource_data == null)
            //         resource_data = new MapResourceT();
            //    resource_data.FromMsg(msg.resource_data.Value);
            //}
            //if (msg.ai_data.HasValue)
            //{
            //    if (ai_data == null)
            //        ai_data = new MapAIT();
            //    ai_data.FromMsg(msg.ai_data.Value);
            //}
            //if (msg.move_data.HasValue)
            //{
            //    if (move_data == null)
            //        move_data = new EntityMoveDataT();
            //    move_data.FromMsg(msg.move_data.Value);
            //}
            //if (msg.ai_test_data.HasValue)
            //{
            //    if (ai_test_data == null)
            //        ai_test_data = new AITestDataT();
            //    ai_test_data.FromMsg(msg.ai_test_data.Value);
            // }
            // isinvisible = msg.isinvisible;
            //is_die = msg.is_die;
            //if (msg.machine_data.HasValue)
            //{
            //    if (machine_data == null)
            //        machine_data = new MapMachineT();
            //    machine_data.FromMsg(msg.machine_data.Value);
            // }
            //iscatfoot = msg.iscatfoot;
            // vox_world_id = msg.vox_world_id;
            //vehicle_id = msg.vehicle_id;
            //interaction_id = msg.interaction_id;
            // interaction_action = msg.interaction_action;
            // hug_targetid = msg.hug_targetid;
        }

        public virtual void SetNetData(swm.SyncMainUserData _data) {
            //濞屸剝婀乧ell_server_id

            if (m_data == null)
                m_data = new swm.MapEntityDataT();

            //濞屸剝婀乼itle
            bool isTitleNameChange = false;
            //ConstructMapEntityData(_data);
            m_titleName = null;

            FillMapEntityData(_data);

            //濞屸剝婀乥uff
            /*if (m_buffProxy != null && _data.buffsLength > 0)
            {
                for (int i = 0; i < _data.buffsLength; i++)
                {
                    m_buffProxy.AddBuff(_data.buffs(i).Value);
                }
            }*/

            SetData(m_data);
            if (isTitleNameChange)
            {
                //缂佸婢樿ぐ鍧楀极閻楀牆绁﹂柡鍫濐槸瑜板宕犻弽鐢电闁哄洤鐡ㄩ敓??
                onTitleNameChangeEvent.Invoke();
            }
            if (m_data.state_data != null)
                SetNetDataEnd();
        }

        protected virtual void SetNetDataEnd() {
            if (m_data.state_data == null)
                return;
            if(m_data.state_data.trail != null )
            {
                var val = m_data.state_data.trail;
                var trailtype = val.type;
                switch (trailtype)
                {
                    case swm.BlinkType.BEATFLOWN:
                        SkillManager.Instance.ClickEntityFly(this, val.vox_world_id, val.startpos.Vec3(), val.tdir.Vec3(), val.vec.Vec3(), (long)val.starttime, (long)val.curtime, (long)val.endtime, val.tpos.Vec3(), val.airforce, (long)val.endtime, val.tpos.Vec3());
                        break;
                    case swm.BlinkType.IMPACT:
                    case swm.BlinkType.BEATBACK:
                        SkillManager.Instance.BeatEntityBack(this, val.vox_world_id, val.startpos.Vec3(), val.startdir.Vec3(), val.tpos.Vec3(), val.speed, (long)val.starttime, (long)val.curtime, (long)val.endtime, (int)val.type);
                        break;
                    case swm.BlinkType.TRACK:
                    case swm.BlinkType.QUICKDODGE:
                    case swm.BlinkType.ONRUSH:
                        SkillManager.Instance.RushEntity(this, val.vox_world_id, val.startpos.Vec3(), val.startdir.Vec3(), val.tpos.Vec3(), val.speed, (long)val.starttime, (long)val.curtime, (long)val.endtime, (int)val.type);
                        break;
                }
            }
            
            if(m_data.state_data.qingkung !=null)
            {
                var self = this as Character;
                var qingkung = m_data.state_data.qingkung;
                if (qingkung.state == swm.QingKungState.Flying)
                {
                    var fly = qingkung.fly_data.up_data;
                    self.QingKungStep = (QingKungStep)qingkung.fly_data.id;
                    self.Position = fly.curpos.Vec3();
                    self.Direction = fly.land_pos.Vec3() - fly.curpos.Vec3();
                    self.QingKungTopPos = fly.to_pos.Vec3();
                    self.QingKungLandPos = fly.land_pos.Vec3();
                    self.QingKungDurationTime = (fly.curtime - fly.start_time) / 1000.0f;
                    //StateMachine?.Resume(SM.Entity.States.QingKungEnter);
                    // switch (self.QingKungStep)
                    // {
                    //     case QingKungStep.QingKungMove:
                    //         CrossFadeAll(AnimatorStateID.QingGongMove, 0.1f, self.QingKungDurationTime);
                    //         break;
                    //     case QingKungStep.QingKungTwo:
                    //         CrossFadeAll(AnimatorStateID.QingGongTwo, 0.1f, self.QingKungDurationTime);
                    //         break;
                    //     case QingKungStep.QingKungThree:
                    //         CrossFadeAll(AnimatorStateID.QingGongThree, 0.1f, self.QingKungDurationTime);
                    //         break;
                    //     case QingKungStep.QingKungFour:
                    //         CrossFadeAll(AnimatorStateID.QingGongFour, 0.1f, self.QingKungDurationTime);
                    //         break;
                    //     case QingKungStep.QingKungSitu:
                    //         CrossFadeAll(AnimatorStateID.QingGongSitu, 0.1f, self.QingKungDurationTime);
                    //         break;
                    //     case QingKungStep.QingKungGliding:
                    //         CrossFadeAll(AnimatorStateID.QingGongGliding, 0.1f, self.QingKungDurationTime);
                    //         break;
                    // }
                }
                else if (qingkung.state == swm.QingKungState.Falling)
                {
                    var fall = qingkung.fly_data.fall_data;
                    self.QingKungStep = (QingKungStep)qingkung.fly_data.id;
                    self.Position = fall.curpos.Vec3();
                    self.Direction = fall.land_pos.Vec3() - fall.curpos.Vec3();
                    self.QingKungLandPos = fall.land_pos.Vec3();
                    self.QingKungDurationTime = (fall.curtime - fall.start_time) / 1000.0f;
                    //StateMachine?.Resume(SM.Entity.States.QingKungFall);
                }
                else if (qingkung.state == swm.QingKungState.Peak)
                {
                    var peak = qingkung.peak_data;
                    self.Position = peak.curpos.Vec3();
                    self.Direction = peak.to_pos.Vec3() - peak.curpos.Vec3();
                    self.QingKungTopPos = peak.to_pos.Vec3();
                    // if (peak.curtime < peak.ttime)
                    //     StateMachine?.Resume(SM.Entity.States.QingKungPeakEnter);
                    // else
                    //     StateMachine?.Resume(SM.Entity.States.QingKungPeakStay);
                }
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="_data"></param>
        public virtual void SetNetData(swm.MapEntityData _data)
        {
            cell_server_id = _data.cell_server_id;
            SetIsSameServeIdWithMainChar();
            
            if (m_data == null)
                m_data = new swm.MapEntityDataT();

           // propertyComponent.SetNetData(_data);

            bool isTitleNameChange = CheckTitleNameIsChange(_data, m_data);
            m_titleName = null;

            FillMapEntityData(_data);
            
            if (m_buffProxy != null && _data.buffsLength > 0)
			{
				for (int i = 0; i < _data.buffsLength; i++)
				{
					m_buffProxy.AddBuff(_data.buffs(i).Value);
				}
			}
            

            SetData(m_data);
            if (isTitleNameChange)
            {
                onTitleNameChangeEvent.Invoke();
            }
            if (m_data.state_data != null)
                SetNetDataEnd();
        }

        public void OnTitleNameChange(uint[] newIds)
        {
            if (m_data != null)
            {
                if (m_data.user_data.title_idvec == null)
                    m_data.user_data.title_idvec = new List<uint>(2);
                m_data.user_data.title_idvec.Clear();

                if (newIds != null)
                {
                    m_data.user_data.title_idvec.AddRange(newIds);
                }

                //m_data.OnTitleChange(newIds);
            }
        }
		public virtual void SetData(swm.MapEntityDataT data)
		{
			m_data = data;
            VoxelWorldID = m_data.vox_world_id;
            m_currenTransformId = m_data.change_id;

            Direction = m_data.cur_dir.Vec3();
            Position = m_data.cur_pos.Vec3();
            Died = m_data.is_die;

            OnDataUpdate();
		}
        bool CheckTitleNameIsChange(swm.MapEntityData _data, swm.MapEntityDataT data)
        {
            bool isChange = false;
            if (data.user_data!=null && data.user_data.title_idvec!=null)
            {
                if ( _data.user_data.Value.title_idvecLength != data.user_data.title_idvec.Count)
                {
                    isChange = true;
                }
                else
                {
                    for (int i = 0; i < _data.user_data.Value.title_idvecLength; i++)
                    {
                        if (data.user_data.title_idvec[i] != _data.user_data.Value.title_idvec(i))
                        {
                            isChange = true;
                            break;
                        }
                    }
                }
            }
            else
            {
                isChange = true;
            }
            return isChange;
        }

        //--------------------------
        public virtual int Level
        {
            //缂佹稑顦遍敓??
            get
            {
                return (int)m_data.level;
            }

			set
			{
				if (m_data.level != value)
				{
                    m_data.level = (uint)value;
				}
			}
		}
        public virtual uint BaseID
        {
            //id
            get
            {
					return 0;
            }

            //set
            //{
            //    m_data.baseid = value;
            //}
        }

		public virtual swm.CareerType CareerType
        {
			//闁煎崬濂旈敓??
			get
			{

				return swm.CareerType.Unknown;
			}
		}

		public virtual swm.CareerSex Sex
		{
			get
			{

				return swm.CareerSex.Unknown;
			}
		}
		protected float m_fHitBlockTime = 0.0f;
		public float HitBlockTime
		{
			get
			{
				return m_fHitBlockTime;
			}
		}
		public RoleTableBase RoleTableConfig
        {
            get
            {
                if(null == m_roleTableConfig || m_roleTableConfig.Value.id != (int)CareerType)
                {
                    m_roleTableConfig = RoleTableManager.GetData((int)CareerType);
                }
                return m_roleTableConfig.Value;
            }
        }

        public uint CurHP { get { return m_data.cur_hp; } }

        public uint MaxHP { get { return m_data.max_hp; } }
        public uint CurMP { get { return m_data.cur_mp; } }
        public uint MaxMP { get { return m_data.max_mp; } }

		public bool IsShield
        {
            //闁绘鍩栭敓??
            get
            {
				const int dun_buffid = 101102102;//闁烩晝鐫ff

				return m_buffProxy != null && m_buffProxy.GetBuffOverlapCountByBaseID(dun_buffid) > 0;
            }

        }

        /// <summary>
        /// 鐠у嫭绨柌鍥肠閻樿埖鈧?
        /// </summary>
        public virtual uint resColState
        {
            get { return 0; }
        }
        public bool AvatarValid
		{
			get
			{
				return Avatar != null && Avatar.unityObject != null;
			}
		}

        public virtual swm.EntityType EntityType
		{
			get
			{
                if (m_data != null)
                {
                    return GameScene.GetEntityTypeById(m_data.entity_id);
                }
                return default(swm.EntityType);
			}
		}
        public bool m_IsClientEntity = false; ///是否为客户端创建的角色 不是服务器创建的
        public bool IsClientEntity
        {
            get
            {
                return m_IsClientEntity;
            }
            set
            {
                m_IsClientEntity = value;
            }
        }
        public float AttackSpeed
		{
			get
			{
				return (float)m_data.attack_speed / 1000.0f;
			}
		}
        
        //------------------------------------
        public BuffProxy BuffProxy
        {
            get
            {
                return m_buffProxy;
            }
        }
        public string Name
        {
            get
            {
                if(m_data != null)
                {
                    return m_data.name;
                }
                return string.Empty;
            }

        }

        string m_titleName;
        public string TitleName
        {
            get
            {
                if (m_titleName != null)
                    return m_titleName;

                m_titleName = null;
                if (m_data != null&& m_data.user_data!=null&&m_data.user_data.title_idvec!=null && m_data.user_data.title_idvec.Count>0)
                {

                    string imgBg = "";
                    var sb = Utilities.GetStringBuilder();
                    sb.Length = 0;
                    var vlist = m_data.user_data.title_idvec;
                    for (int i = 0; i < vlist.Count; i++)
                    {
                        TitleTableBase? tid = TitleTableManager.GetData((int)vlist[i]);
                        if (tid != null)
                        {
                            sb.Append(tid.Value.name.Replace("XXX", m_data.user_data.title_out_of_band));
                            imgBg = tid.Value.bgimg;
                        }
                    }
                    sb.Append(",");
                    sb.Append(imgBg);
                    m_titleName = sb.ToString();
                }
                else
                {
                    m_titleName = string.Empty;
                }
                return m_titleName;
            }
        }

        public bool IsAvatarLoaded
		{
			get
			{
				return m_avatar != null && m_avatar.unityObject;
			}
		}

        public Vector3 GlobalPosition
        {
            get
            {
                if (VoxelWorldID == 0)
                    return Position;
                else
                {
                    return MobileBlockMgr.Instance.LocalPos2WorldPos(Position, VoxelWorldID);
                }
            }
        }
        public virtual Vector3 Position
        {
            get
            {
                return m_position;
            }

            set
            {
                if( m_position != value)
                {
                    m_position = value;
                    SetAvatarPosition();
                    OnPositionChange();
                }     
            }
        }

        public void SetPosition(Vector3 pos, uint VoxID)
        {
            if(VoxelWorldID == VoxID)
            {
                Position = pos;
            }
            else
            {                            
                Position = MobileBlockMgr.Instance.ConvertPos(pos,VoxID,VoxelWorldID);
            }
        }

        public Vector3 LocalDirection
        {
            get
            {
                if (VoxelWorldID != 0)
                    return MobileBlockMgr.Instance.WorldDir2LocalDir(Direction, VoxelWorldID);
                else
                    return Direction;
            }
            set
            {
                if (VoxelWorldID != 0)
                    Direction = MobileBlockMgr.Instance.LocalDir2WorldDir(value, VoxelWorldID);
                else
                    Direction = value;
            }
        }

        public virtual Vector3 Direction
        {
            get
            {
                return m_direction;
            }

            set
            {
                value.y = 0;
                if (value == Vector3.zero)
                {
                    LogHelper.LogWarning("direction is zero!");
                    return;
                }

                if (null == Avatar) {
                    LogHelper.LogWarning("Avatar is null!");
                    return;
                }

				
                if (m_direction != value || Avatar.GetDirection() != value || value.sqrMagnitude > 0.0f)
                {
                    m_direction = value;
                    m_direction.Normalize();
                    m_dirAngle = Utilities.Vector2Angle(m_direction.z, m_direction.x);
                    SetAvatarDirection();
                    OnDirectionChange();
                    //if(IsCharacter()&&!IsMainCharacter())
                    //{
                    //    LogHelper.Log("[HC] Direction", m_dirAngle);
                    //}
                }
			}
        }

        public float DirAngle
        {
            get
            {
                return m_dirAngle;
            }
            set
            {
				if(m_dirAngle!=value)
				{
					m_dirAngle = value;

					Utilities.Angle2Vector2(value, out m_direction.z, out m_direction.x);

					m_direction.Normalize();
					OnDirectionChange();
                    if (!(CarryTrigger && m_isbeCarry == true))
                    {
                        SetAvatarDirection();
                    }
                        
				}
            }
        }

        public ulong ThisID
        {
            get
            {
                return m_thisid;
            }
        }
        public string ThisIDToString
        {
            get
            {
                return m_thisid.ToString();
            }
        }

        public Vector3 LocalPosition
        {
            get
            {
				if(Avatar!=null)
				{
					var obj = Avatar.unityObject;
					if (obj)
						return obj.transform.position;
                    else
                    {
                        if(VoxelWorldID==0)
                            return Position - LayeredSceneLoader.WorldOffset;
                        else
                        {
                            var pos = MobileBlockMgr.Instance.LocalPos2WorldPos(Position, VoxelWorldID);
                            return pos - LayeredSceneLoader.WorldOffset;
                        }
                    }

				}
				return Vector3.zero;
            }
        }

        public IAvatar Avatar
        {
            get
            {
                return m_avatar;
            }
        }

        public bool Deleted
        {
            get
            {
                return m_bDeleted;
            }

            set
            {
                m_bDeleted = value;
            }
        }

        /// <summary>
        /// 闂呮劘妫屽璁抽閸斻劎鏁?
        /// </summary>
        public virtual bool HideDiedAnim
        {
            get
            {
                return false;
            }
        }

        public bool Died
        {
            get
            {
				//return m_data !=null && m_data.cur_hp == 0;//闁绘粍婢樺﹢顏呯▔瀹ュ牆鍘撮柣顫姀椤㈠懘寮伴姘剨閿??0闁哄鍎遍崹浠嬪棘椤撶噥鍔ラ敓??  闁汇垼椴稿﹢鍥礉閿涘嫷浼傞柛娆愬灴閳ь兛鐒﹂瀛樼閳ヨ尙鐟㈠璺虹У閿??
                return m_bDied;
            }
            set
            {
                if(m_bDied != value)
                {
                    m_bDied = value;
                    if (LastSkillShow != null)
                        Avatar.StopMagicAction((uint)(LastSkillShow.SkillID));

                    if (m_bDied && IsMainCharacter())
                        onMainCharacterDied.Invoke();
                    if (m_bDied)
                        OnDie();
                    else
                        OnRelive();
                    onEntityDieChange.Invoke();
                }

            }
        }

        //死亡后可以采集（剥皮）
        public virtual bool GatherwhileDie {
            get {
                return false;
            }
        }

        int cur_anger;
        int max_anger;
		//闁诡剚甯楅敓??
		public int Anger
		{
			get
			{
				return cur_anger;
			}
			set
			{
				if (cur_anger != value)
				{
                    cur_anger = value;
					OnAngerChange.Invoke();
				}
			}
		}

		public int MaxAnger
		{
			get
			{
				return max_anger;
			}
		}

        public bool IsWeak
        {
            get
            {
                return m_buffProxy.HaveBuffType(swm.BuffType.Weak);
            }
        }

		public bool IsDizzy
		{
			get
			{
				return m_buffProxy!=null&&(
                    m_buffProxy.HaveBuffType(swm.BuffType.Dizzy) ||
                    m_buffProxy.HaveBuffType(swm.BuffType.Charm) ||
                    m_buffProxy.HaveBuffType(swm.BuffType.Weak));
			}
		}
		public bool IsDanceDizzy
		{
			get
			{
				return false;// m_data != null && m_data.flags != null && m_data.flags.is_dance_dizzy;
			}
		}

		public bool IsYingZhi
		{
			get
			{
				return false;// m_buffProxy!=null&&m_buffProxy.HaveBuffType(swm.BuffType.;// m_data != null && m_data.flags != null && m_data.flags.is_yingzhi;
			}
		}

		public bool IsDingShen
		{
			get
			{
				return m_buffProxy != null && m_buffProxy.HaveBuffType(swm.BuffType.Stun);
			}
		}

        public bool IsCharm
        {
            get
            {
                return m_buffProxy != null && m_buffProxy.HaveBuffType(swm.BuffType.Charm);
            }
        }

        public bool IsForbidJumpandFly {
            get {
                return m_buffProxy != null && m_buffProxy.HaveBuffType(swm.BuffType.ProhibitJumpAndFly);
            }
        }

		public bool IsFrozen
		{
			get
			{
				return false;// m_data != null && m_data.flags != null && m_data.flags.is_frozen;
			}
		}

		public bool CanMove
		{
			get
			{
				return !(IsDingShen || IsDizzy || IsFrozen || IsYingZhi);
			}
		}
        uint m_voxelWorldID=0;
        public uint VoxelWorldID
        {
            get
            {
                return m_voxelWorldID;
            }
            set
            {
                if(m_voxelWorldID!=value)
                {
                    var oldvalue = m_voxelWorldID;
                    m_voxelWorldID = value;
                    OnVoxelWorldChange(oldvalue);
                    //LogHelper.Log("VoxelWorldID Change", oldvalue, m_voxelWorldID);
                }
                
            }
        }

        bool m_bVoxelWorldLoaded =false;
        public bool VoxelWorldLoaded
        {
            get
            {
                return m_bVoxelWorldLoaded;
            }
            set
            {
                m_bVoxelWorldLoaded = value;
            }
        }
        

		public virtual bool IsFlying
		{
			get
			{
				return false;// m_data.flags!=null && m_data.flags.is_flying;
			}
			set
			{
				//if (m_data.flags == null)
				//	m_data.flags = new x2m.MapEntityFlags();
				//m_data.flags.is_flying = value;
			}
		}

		// public virtual bool IsJumping
		// {
		// 	get
		// 	{
		// 		return m_sm != null &&( m_sm.CurStateID == SM.Entity.States.JUMP || m_sm.CurStateID == SM.Entity.States.JUMP2);
		// 	}
		// }
		// public virtual bool IsInAir
		// {
		// 	get
		// 	{
		// 		return IsFlying || (m_sm != null && (m_sm.CurStateID == SM.Entity.States.JUMP || m_sm.CurStateID == SM.Entity.States.JUMP2 || m_sm.CurStateID == SM.Entity.States.FALL));
		// 	}
		// }

        // public bool IsInAttackState {
        //     get {
        //         return m_sm != null && m_sm.CurStateID == SM.Entity.States.ATTACK;
        //     }
        // }
        
        /// <summary>
        /// 缂備胶鍘ч幃搴ㄥ矗椤栨繍娼岄敓??
        /// </summary>
        public virtual bool ActuallyVisible
        {
            get { return m_bVisible && m_bVisibleByTimeline && m_bVisibleBySkill && m_bVisibleByCamera && m_bVisibleByAction && m_bVisibleByLevelSystem && m_bVisibleByTreasure; }
        }
		public virtual bool Visible
        {
            get
            {
                return m_bVisible;
            }

            set
            {
                // bool b = false;
                bool oldV = ActuallyVisible;
                m_bVisible = value;
                if(oldV!=ActuallyVisible)
                {
                    OnVisibleChange();
                }
                
			}
		}

        public virtual bool CanSelect
        {
            //閹碱剝绻嶉悩鑸碘偓浣规 npc 閺勵垯绗夐懗鍊燁潶闁鑵戦惃?
            get { return m_bCanSelect && Selectable && (m_bCarryTrigger == false|| m_bCarryTrigger == true && m_isbeCarry == false); }
            set {
                m_bCanSelect = value;
            }
        }
        protected bool m_bVisibleByTimeline = true;
        /// <summary>
        /// 閸撗冩簚娑擃厽妲搁崥锕€褰茬憴?
        /// </summary>
        [XLua.BlackList]
        public virtual bool VisibleByTimeline
        {
            get { return m_bVisibleByTimeline; }
            set
            {
                bool tOldValue = ActuallyVisible;
                m_bVisibleByTimeline = value;
                if (tOldValue != ActuallyVisible)
                    OnVisibleChange();
            }
        }
        public virtual bool VisibleBySkill
        {
            get
            {
                return m_bVisibleBySkill;
            }
            set
            {
                bool oldV = ActuallyVisible;
                m_bVisibleBySkill = value;
                if (oldV != ActuallyVisible)
                {
                    OnVisibleChange();
                }
            }
        }
        
        public virtual bool VisibleByAction
        {
            get
            {
                return m_bVisibleByAction;
            }
            set
            {
                bool oldV = ActuallyVisible;
                m_bVisibleByAction = value;
                if (oldV != ActuallyVisible)
                {
                    OnVisibleChange();
                }
            }
        }
        public virtual bool VisibleByCamera
        {
            get
            {
                return m_bVisibleByCamera;
            }
            set
            {
                bool oldV = ActuallyVisible;
                m_bVisibleByCamera = value;
                if (oldV != ActuallyVisible)
                {
                    OnVisibleChange();
                }
            }
        }

        /// <summary>
        /// 妤傛ü鑵戞担搴ｎ伂閺堢儤甯堕崚鑸垫▔缁€?;
        /// </summary>
        public virtual bool VisibleByLevelSystem
        {
            get
            {
                return m_bVisibleByLevelSystem;
            }
            set
            {
                bool oldV = ActuallyVisible;
                m_bVisibleByLevelSystem = value;
                if (oldV != ActuallyVisible)
                {
                    OnVisibleChange();
                }
            }
        }

        public virtual bool VisibleByTreasure
        {
            get
            {
                return m_bVisibleByTreasure;
            }
            set
            {
                bool oldV = ActuallyVisible;
                m_bVisibleByTreasure = value;
                if (oldV != ActuallyVisible)
                {
                    OnVisibleChange();
                }
            }
        }
        /// <summary>
        /// 闁哄嫷鍨伴幆浣糕攽閳ь剙煤娴兼瑧绐楃憸鏉垮船閹奸攱绋夌拋宕囩Ъ闁告瑯鍨甸～鍡涘箑瑜嬮埀顑跨劍鐎垫洘娼悾灞解挅濞寸姴澧庡▓鎴﹀矗椤栨繍娼岄柟顑讲鍋撴担钘夊闁哄牜鍓涚划宥嗙閸撲焦鐣遍柟绗涘棭鏀?
        /// </summary>
        public bool Actived
        {
            get { return m_bActived; }
            set
            {
                if(m_bActived != value)
                {
                    m_bActived = value;
                    OnActivedChange();
                }
            }
        }
        public HeadBillboard Billboard
        {
            get
            {
                return m_headBillboard;
            }
        }

        public Transform TargetSelNode
        {
            get
            {
                if (m_targetSelNode)
                    return m_targetSelNode;
                else if (Avatar!=null&& Avatar.unityObject)
                    return Avatar.unityObject.transform;
                else
                    return null;

            }
        }

		public virtual float Radius
		{
			get
			{
				return m_data.model_radius;
			}
		}

        public virtual bool Selectable
        {
            get
            {
                return false;
            }
        }

        public virtual float HitEffectScale {
            get {
                return 1f;
            }
        }

        int[] m_animID = new int[(int)SM.Entity.States.COUNT];

		// public int AnimID
		// {
		// 	get
		// 	{
		// 		if(m_sm!=null)
		// 		{
		// 			return m_animID[(int)m_sm.CurStateID];
		// 		}
		// 		else
		// 		{
		// 			return 0;
		// 		}
		// 	}
		// }

        /// <summary>
        /// 是否再攻击状态
        /// </summary>
        protected bool m_oldIsInAttack = false;

        public bool IsInAttack
		{
			get
			{
				return m_data.is_fighting;// m_data.flags!=null && m_data.flags.is_fighting;

			}
			set
			{
				if(m_data.is_fighting != value)
				{
                    m_oldIsInAttack = m_data.is_fighting;

                    m_data.is_fighting = value;
					OnIsInAttackChange();
				}
			}
		}

        public bool IsInvisible
        {
            get
            {
                return m_data.isinvisible;

            }
            set
            {
                m_data.isinvisible = value;
                OnInvisibleChange();
            }
        }

        //重伤
        bool m_hurtbadly;
        public bool IsHurtBadly
        {
            get
            {
                return m_hurtbadly;

            }
            set
            {
                m_hurtbadly = value;
            }
        }
        
        public virtual bool IsInClickFly
        {
            get
            {
                return false;
            }
        }

		bool m_isInAttackChangeTrigger = false;
		public bool IsInAttackChangeTrigger
		{
			get
			{
				return m_isInAttackChangeTrigger;
			}
		}

        protected bool m_underAttackTrigger = false;

        public bool UnderAttackTrigger
        {
            get
            {
                return m_underAttackTrigger;
            }
        }

		protected bool m_attackTrigger;
		public bool AttackTrigger
		{
			get
			{
				return m_attackTrigger;
			}
			set
			{
				m_attackTrigger = value;
			}
		}

		bool m_bAttackedTarget;
		public bool AttackedTarget
		{
			get
			{
				return m_bAttackedTarget;
			}
			set
			{
				m_bAttackedTarget = value;
			}
		}

		float m_fAttackNormalizeStart = 0.0f;
		public float AttackNormalizeStart
		{
			get
			{
				return m_fAttackNormalizeStart;
			}
			set
			{
				m_fAttackNormalizeStart = value;
			}
		}
  
        // public SM.IStateMacine<SM.Entity.States> StateMachine
        // {
        //     get
        //     {
        //         return m_sm;
        //     }
        // }

        //SM.Entity.States m_acturalAnimState;
        int m_updateAnimStateDelay;
        //SM.Entity.States m_curAnimState;
		// public SM.Entity.States CurAnimState
		// {
		// 	get
		// 	{
		// 		return m_curAnimState;
		// 	}
		// }

        //SM.Entity.States m_curUpBodyAnimState;

        // public SM.Entity.States CurUpBodyAnimState
        // {
        //     get
        //     {
        //         return m_curUpBodyAnimState;
        //     }
        // }

        GameEvent m_onAvatarLoaded = new GameEvent();
		public GameEvent OnAvatarLoaded
		{
			get
			{
				return m_onAvatarLoaded;
			}
			set
			{
				m_onAvatarLoaded = value;
			}
		}
		//public GameEvent<swm.MapEntityFlags> OnFlagChange = new GameEvent<swm.MapEntityFlags>();
		public GameEvent OnStateMachineCreate = new GameEvent();

		SkillShowBase m_lastSkillShow;
		public SkillShowBase LastSkillShow
		{
			get
			{
				return m_lastSkillShow;
			}
			set
			{
				m_lastSkillShow = value;
			}
		}

        int m_curCastingSkillID;
        public int CurCastingSkillID
        {
            get
            {
                return m_curCastingSkillID;
            }
            set
            {
                m_curCastingSkillID = value;
            }
        }

		public virtual bool HaveAttackLayer
		{
			get
			{
				return false;
			}
		}

		bool m_useAttackLayer = true;
		public bool UseAttackLayer
		{
			get
			{
				return m_useAttackLayer;
			}
			set
			{
				m_useAttackLayer = value;
			}
		}

		bool m_forceStopAttack = false;
		public bool NeedForceStopAttack
		{
			get
			{
				return m_forceStopAttack;
			}
			set
			{
				m_forceStopAttack = value;
			}
		}
		public bool IsTeamMember
		{
			get
			{
				return TeamModel.Instance.TeamData.GetMemberDataById(ThisID)!=null;
			}
		}

		public bool IsFriend
		{
			get
			{
				return FriendModel.Instance.GetFriendDataById(ThisID) != null;
			}
		}

		public bool IsSociatyMember
		{
			get
			{
				return SociatyManager.Instance.GetMemberDataById(ThisID) != null;
			}
			
		}

		public bool IsFriendly
		{
			get
			{
				return IsMainCharacter() || IsTeamMember;
			}
		}
        #endregion

        public Entity(ulong id)
        {
            m_thisid = id;
            CreateAvatar();
            CreateBuffProxy();
        }

        void CreateAvatar()
        {
            if (m_avatar != null)
                LogHelper.LogError("avatar has been exsit.");
            m_avatar = IFactory.Instance.CreateAvatar(this);
            m_avatar.onCreate.AddListener(AvatarCreateDelegate);
        }

        void CreateBuffProxy()
        {
            m_buffProxy = BuffFactory.Instance.CreateBuffProxy(this);
            m_buffProxy.onAddBuff.AddListener(OnBuffChange);
            m_buffProxy.onRemoveBuff.AddListener(OnBuffChange);
        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public Entity()
        {
            
        }
        /// <summary>
        /// 在构造之后调用的第一个函数
        /// </summary>
        public virtual void init()
        {

            CreateEntitySyncer();

            //ReleaseStateMachine();
            CreateStateMachine();
            OnStateMachineCreate.Invoke();

            //m_sm.OnPostStateChange.RemoveListener(OnPostStateChange);
            m_sm.OnPostStateChange.AddListener(OnPostStateChange);
        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public virtual void InitEntity(ulong id)
        {
            m_thisid = id;
            CreateAvatar();
            CreateBuffProxy();
            m_bDeleted = false;
        }

        /// <summary>
        /// 所属的模型发生变化
        /// </summary>
        public virtual void OnAvatarChanged(GameObject go)
        {
            m_avatar?.OnAvatarChanged(go);
        }
        protected virtual void OnBuffChange(BuffBase buff)
		{

		}
        public virtual Entity Clone(ulong _id = 0, CloneUsage _Usage = CloneUsage.NpcVisit)
        {
            Entity _entity = new Entity(_id);
            _entity.SyncLoad = true;
            var tData = m_data.Clone();
            if (_Usage == CloneUsage.Drama)
                tData = HandleDataForDrama(tData);
            _entity.init();
            _entity.SetData(tData);
            _entity.OnAddToScene();
            _entity.Position = Position;
            return _entity;
        }
        /// <summary>
        /// 修改数据，确保剧场播放前实体的状态正确
        /// </summary>
        [XLua.BlackList]
        public swm.MapEntityDataT HandleDataForDrama(swm.MapEntityDataT _Src)
        {
            //死亡状态
            _Src.is_die = false;
            //战斗状态
            _Src.is_fighting = false;
            //增减益状态
            _Src.buffs?.Clear();
            //潜行状态
            _Src.isinvisible = false;
            //载具状态
            _Src.vehicle_id = 0;
            //搬运状态
            _Src.state_data.hug_targetid = 0;
            //坐骑状态
            var user_data = _Src.user_data;
            if(null != user_data)
            {
                user_data.mountid = 0;
                user_data.mountskinid = 0;
            }
            var chantdata = _Src.state_data.chant;
            if(null != chantdata)
            {
                //武器状态
                //tUserData.is_show_weapon = true;
                //吟唱状态

                chantdata.chant_id = 0;
                chantdata.target_id = 0;
                chantdata.start_time = 0;
                chantdata.end_time = 0;
            }
            //移动状态
            _Src.state_data.move = null;

            return _Src;
        }
        /// <summary>
        ///  重置状态，确保剧场播放前实体的状态正确
        /// </summary>
        [XLua.BlackList]
        public virtual void ResetStateForDrama()
        {
            IsInAttack = false;
            //增减益状态
            if (null != BuffProxy)
                BuffProxy.EffectVisible = false;
            //潜行状态
            IsInvisible = false;
            //搬运状态
            SetCarry(false, false);
            StopLineTeToOtherRole();
            //动作表情
            ActionEmojiManager.Instance.StopAcitonEmoji(ThisID);
            Died = false;
            //动作状态
            m_sm?.ChangeState(SM.Entity.States.IDLE);
        }
		public virtual bool IsOnGround()
		{
            var distance = GetGroundDistance();
            return distance < FallCheckDistance && distance > -0.5f; //在碰撞下面时，一个体素块的误差
        }

        public virtual float GetGroundDistance()
		{
            RaycastHit hitinfo;
			if (!Utilities.RayCast(LocalPosition + Vector3.up , Vector3.down, out hitinfo, 1000.0f))
			{
				return 1000.0f;
			}
            return hitinfo.distance - 1;
		}

        void AvatarCreateDelegate()
		{
			OnAvatarCreateDelegate();
            if (m_onAvatarLoaded != null)
				m_onAvatarLoaded.Invoke();
		}
        public void SetActive(bool active)
        {
            m_avatar?.unityObject?.SetActive(active);
        }
        public virtual void SetAvatarPosition()
		{
			if(m_avatar!=null)
				m_avatar.SetPosition(m_position);

		}

		protected virtual void SetAvatarDirection()
		{
			if (m_avatar != null)
				m_avatar.SetDirection(m_direction.x, m_pitch, m_direction.z);
		}
		protected virtual void OnAvatarCreateDelegate()
        {
            if(VoxelWorldID!=0)
            {
                MobileBlockMgr.Instance.AddEntity(VoxelWorldID, this);
            }
			if(Avatar.unityObject != null)
				m_targetSelNode = Avatar.unityObject.transform.Find("target_sel_node");

            Avatar.SetDirection(m_direction.x, m_pitch, m_direction.z);
			SetAvatarPosition();
            if(m_layer!=0)
			    Avatar.SetLayer(m_layer);

            SetActive(Actived);

            Avatar.onEnterStateMachine -= OnAnimStateMachineEnter;
			Avatar.onEnterStateMachine += OnAnimStateMachineEnter;

            if (m_buffProxy != null)
                m_buffProxy.ModelChangelResetBuff();

            SetIsSameServeIdWithMainChar();
          
            if(m_nCurCrossFadeAllAnimId!=0)
            {
                CrossFadeAll(m_nCurCrossFadeAllAnimId);
            }
        }
		protected virtual void OnIsInAttackChange()
		{
			m_isInAttackChangeTrigger = true;

			onIsInAttackEvent.Invoke();
            onIsInAttackWithIdEvent.Invoke(this);

        }

        protected virtual void OnInvisibleChange()
        {
            if (IsInvisible)
            {
                SetInvisibleShader();
            }
            else
            {
                ResumeInvisibleShader();
            }
        }

        protected virtual void OnActivedChange()
		{
            SetActive(Actived);
		}
        protected virtual void OnVisibleChange()
        {
            if (null != m_avatar)
            {
                m_avatar.Visible = ActuallyVisible;
            }
            if (null != m_headBillboard)
            {
                m_headBillboard.Visible = ActuallyVisible;
            }
            if(null != m_buffProxy)
            {
                m_buffProxy.EffectVisible = ActuallyVisible;
            }
            onVisibleChangeEvent.Invoke();
        }

        protected virtual void OnVoxelWorldChange(uint oldid)
        {
            var pos = Position;

            if(oldid!=0)
            {
                MobileBlockMgr.Instance.RemoveEntity(oldid, this);

            }

            if (m_voxelWorldID!=0)
            {
                MobileBlockMgr.Instance.AddEntity(m_voxelWorldID, this);
            }
            
            Position = MobileBlockMgr.Instance.ConvertPos(pos, oldid, m_voxelWorldID);
        }

		public void DirectTo(Vector3 pos)
		{
			var v = pos - GlobalPosition;
			v.y = 0;
			if(v.sqrMagnitude>0.0f)
			{
				v.Normalize();
				Direction = v;
			}

		}
		public void SetHpMp(uint hp, uint maxHp, uint mp, uint maxMp)
		{
			m_data.cur_hp = hp;
			m_data.max_hp = maxHp;
			m_data.cur_mp = mp;
			m_data.max_mp = maxMp;
			OnHpMpChange.Invoke();
		}
        public void SetFightPower(uint _value)
        {
            m_fightPower = _value;
        }
        public void SetAnger(uint anger, uint maxAnger)
		{
			cur_anger = (int)anger;
			max_anger = (int)maxAnger;
			OnAngerChange.Invoke();
		}

        protected virtual void OnDataUpdate()
        {
			OnDataChange.Invoke();
			RefreshCanAttack();
            OnInvisibleChange();
        }

        public virtual void DumpMapEntityData(swm.MapEntityDataT data)
        {
            //data.entity_id = ThisID;
            //data.entity_type = EntityType;
            //data.name = Name;
            //data.level = (uint)Level;
            //data.cur_hp = CurHP;
            //data.cur_mp = CurMP;
            //data.max_hp = MaxHP;
            //data.max_mp = MaxMP;
            //data.cur_dir =  Direction;
            //data.cur_pos =  Position;
            //data.cur_anger = (uint)Anger;
            //data.max_anger = (uint)MaxAnger;
            //data.attack_speed = (uint)(AttackSpeed * 1000.0f);
    //        if (m_data.user_data != null)
    //        {
				//data.user_data = new x2m.MapUser();
				//data.user_data.career_sex = m_data.user_data.career_sex;
				//data.user_data.career_type = m_data.user_data.career_type;
				//data.user_data.is_show_weapon = m_data.user_data.is_show_weapon;
				//data.user_data.weaponid = m_data.user_data.weaponid;
    //        }
            //if (m_data.flags != null)
            //{
            //    data.flags = new x2m.MapEntityFlags();
            //    data.flags.is_shield = m_data.flags.is_shield;
            //    data.flags.is_dizzy = m_data.flags.is_dizzy;
            //    data.flags.is_frozen = m_data.flags.is_frozen;
            //    data.flags.is_bati = m_data.flags.is_bati;
            //    data.flags.is_taunt = m_data.flags.is_taunt;
            //    data.flags.is_click_fly = m_data.flags.is_click_fly;
            //    data.flags.is_dance_dizzy = m_data.flags.is_dance_dizzy;
            //    data.flags.is_yingzhi = m_data.flags.is_yingzhi;
            //    data.flags.is_dingshen = m_data.flags.is_dingshen;
            //    data.flags.is_flying = m_data.flags.is_flying;
            //    data.flags.is_fighting = m_data.flags.is_fighting;
            //}
            //for (int i = 0; i < m_data.buffs.Count; ++i)
            //{
            //    var buff = m_data.buffs[i];
            //    var buff_new = new x2m.Buff();
            //    buff_new.id = buff.id;
            //    buff_new.baseid = buff.baseid;
            //    buff_new.level = buff.level;
            //    buff_new.target = buff.target;
            //    buff_new.overlay = buff.overlay;
            //    buff_new.begintime = buff.begintime;
            //    buff_new.overtime = buff.overtime;
            //}
            //if (m_data.npc_data != null)
            //{
            //    data.npc_data = new x2m.MapNpc();
            //    data.npc_data.baseid = m_data.npc_data.baseid;
            //    data.npc_data.career_type = m_data.npc_data.career_type;
            //    data.npc_data.career_sex = m_data.npc_data.career_sex;
            //}
            //if (m_data.trap_data != null)
            //{
            //    data.trap_data = new x2m.MapTrap();
            //    data.trap_data.baseid = m_data.trap_data.baseid;
            //    data.trap_data.owner_type = m_data.trap_data.owner_type;
            //    data.trap_data.owner_id = m_data.trap_data.owner_id;
            //    data.trap_data.overtime = m_data.trap_data.overtime;
            //}
            //if (m_data.mount_data != null)
            //{
            //    data.mount_data = new x2m.MapMount();
            //    data.mount_data.baseid = m_data.mount_data.baseid;
            //    data.mount_data.skinid = m_data.mount_data.skinid;
            //}
        }

        public virtual string GetOperateStr()
        {
            return string.Empty;
        }

        public virtual void Release()
        {
            VoxelWorldID = 0;
            if (m_serverChangeEffect != null)
            {
                m_serverChangeEffect.Stop();
                m_serverChangeEffect = null;
            }

            if (m_buffProxy != null)
            {
                m_buffProxy.Destory();
                BuffFactory.Instance.ReleaseBuffProxy(m_buffProxy);
                m_buffProxy = null;
            }
            if (m_sm != null)
                m_sm.OnPostStateChange.RemoveListener(OnPostStateChange);
            ReleaseStateMachine();

            if (m_avatar != null)
            {
                m_avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_avatar);
                m_avatar = null;
            }
            
			//if (m_skillfactory != null)
			//{
			//    m_skillfactory.RemoveAllSkill();
			//    m_skillfactory = null;
			//}
			//if (m_bagManager != null)
			//{
			//    m_bagManager.DeleteAllBag();
			//    m_bagManager = null;
			//}
			m_bDeleted = true;
        }

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public virtual void ResetEntity()
        {
            TreatmaincharChange.RemoveAllListeners();
            InHitbackChange.RemoveAllListeners();
            TopTitleEvent.RemoveAllListeners();
            onFillMapEntityDataEvent.RemoveAllListeners();
            OnRefreshMissionState.RemoveAllListeners();
            OnRefreshResourceMissionState.RemoveAllListeners();
            OnDataChange.RemoveAllListeners();
            OnHpMpChange.RemoveAllListeners();
            OnAngerChange.RemoveAllListeners();
            onIsInAttackEvent.RemoveAllListeners();
            onIsInAttackWithIdEvent.RemoveAllListeners();
            onPositionChangeEvent.RemoveAllListeners();
            onVisibleChangeEvent.RemoveAllListeners();
            onTitleNameChangeEvent.RemoveAllListeners();
            onMainCharacterDied.RemoveAllListeners();
            onEntityDieChange.RemoveAllListeners();
            onSetTempShowHead.RemoveAllListeners();
            OnCanAttackChange.RemoveAllListeners();
            OnAvatarLoaded.RemoveAllListeners();
            //OnFlagChange.RemoveAllListeners();
            OnStateMachineCreate.RemoveAllListeners();

            m_position = Vector3.zero;
            m_direction = Vector3.forward;
            m_dirAngle = 0.0f;
            m_pitch = 0.0f;
            m_bDied = false;
            m_bVisible = true;
            m_bCanSelect = true;
            m_bVisibleByTimeline = true;
            m_bVisibleBySkill = true;
            m_bActived = true;
            m_layer = 0;
            m_fightPower = 0;
            m_TopTitleOffset = Vector3.zero;
            m_missionState = null;
            m_SyncLoad = false;
            m_canAttack = false;
            cell_server_id = 0;
            m_fHitBlockTime = 0.0f;
            m_isInAttackChangeTrigger = false;
            m_underAttackTrigger = false;
            m_attackTrigger = false;
            m_bAttackedTarget = false;
            m_fAttackNormalizeStart = 0.0f;
            m_acturalAnimState = SM.Entity.States.IDLE;
            m_updateAnimStateDelay = 0;
            m_curAnimState = SM.Entity.States.IDLE;
            m_curUpBodyAnimState = SM.Entity.States.IDLE;
            m_curCastingSkillID = 0;
            m_useAttackLayer = true;
            m_forceStopAttack = false;
            m_isInvisibleShader = false;
            if (m_cachedOrgShaderDic != null)
                m_cachedOrgShaderDic.Clear();
            if (m_rendererParts != null)
                m_rendererParts.Clear();

            m_targetSelNode = null;
            m_data = null;
            m_syncer = null;
            m_roleTableConfig = null;
            DefendersObj.Clear();
            m_curAttackTarget = null;
            m_curAnimationSound = null;
            m_lastSkillShow = null;
            m_b_isBeAttachTo = false;
            m_ul_BeAttachToRoleId = 0;
            m_ul_AttachRoleId = 0;
            m_bInHitbacklist = false;
        }
        
		// public void SetAnimID(SM.Entity.States state, int nAnimID)
		// {
		// 	m_animID[(int)state] = nAnimID;
		// }

		// public int GetAnimID(SM.Entity.States state)
		// {
		// 	return m_animID[(int)state];
		
		// }
		public int RequestAttack(string animname = "Attack", bool bAttackedTarget = false)
		{
			int newAnimID = UnityEngine.Animator.StringToHash(animname);
			if (newAnimID == 0)
            {
                LogHelper.LogWarning("RequestAttack Trigger is 0", animname, " ", Time.time.ToString(), " id:", ThisID.ToString());
                return 0;
            }
			if(Avatar!=null && Avatar.animator!=null && !Avatar.animator.HasAnim( newAnimID))
			{
                LogHelper.LogWarning("anim state", animname, " not found!");
            }

			m_attackTrigger = true;
			//SetAnimID(SM.Entity.States.ATTACK, newAnimID);
			m_bAttackedTarget = bAttackedTarget;
			return newAnimID;
            //LogHelper.Log("RequestAttack----------------------------------" + animname + " " + AnimID + " " + Time.time + " id:" + ThisID);
        }

        public void ForceStopAttack()
		{
			m_forceStopAttack = true;
		}

        public int UnderAttack(string animname = "hurt01")
        {
			if (string.IsNullOrEmpty(animname))
				animname = "hurt01";
			if (animname == "none")
				return 0;
			var newanimid = UnityEngine.Animator.StringToHash(animname);
			return UnderAttack(newanimid);
		}

        [XLua.BlackList]
        public bool CanEnterUnderAttackState()
        {
            if (null == m_sm)
            {
                return false;
            }
            if(BuffProxy!=null && BuffProxy.HaveImmunityBuff(swm.BuffType.Stun))
            {
                return false;              
            }
            return (m_sm.CurStateID == SM.Entity.States.IDLE ||
                m_sm.CurStateID == SM.Entity.States.MOVE ||
                m_sm.CurStateID == SM.Entity.States.STUN ||
                m_sm.CurStateID == SM.Entity.States.UNDER_ATTACK ||
                m_sm.CurStateID == SM.Entity.States.ATTACK_IDLE ||
                m_sm.CurStateID == SM.Entity.States.ACTION ||
                m_sm.CurStateID == SM.Entity.States.EMOTE)
                && !m_attackTrigger;
        }

		public int UnderAttack(int animNameHash)
		{
			if (null == m_sm)
			{
				return 0;
			}

            if (onBeAttackEvent != null) onBeAttackEvent.Invoke();
			if (CanEnterUnderAttackState())
			{
			
				if (animNameHash!=0 && Avatar != null  && !Avatar.animator.HasAnim( animNameHash))
				{
                    //LogHelper.LogWarning(animNameHash.ToString());
                    return 0;
				}

				//SetAnimID(SM.Entity.States.UNDER_ATTACK, animNameHash);
				m_underAttackTrigger = true;
				return animNameHash;
			}
			return 0;

		}
		public void setTextEffect(string _prefab, int _value)
		{
            EntityEffectTextManager.Instance.Play(this, _prefab, _value);
		}

        public bool IsHasAvatarObject()
        {
            return (null != m_avatar && null != m_avatar.unityObject);
        }

        public override bool IsCharacter()
        {
            return EntityType == swm.EntityType.Player;
        }

        public override bool IsNpc()
        {
            return EntityType == swm.EntityType.Npc;
        }

        public override bool IsGatherResource()
        {
            return EntityType == swm.EntityType.Resource;
        }

        public override bool IsClientNpc()
        {
            return EntityType == swm.EntityType.ClientNpc;
        }

        public bool IsTrap()
		{
			return EntityType == swm.EntityType.Trap;
		}

        public bool IsMachine()
        {
            return EntityType == swm.EntityType.Machine;
        }
        public virtual Entity GetOwner()
		{
			return null;
		}

		public bool IsOwnerMainCharacter()
		{
			if (IsMainCharacter())
				return true;
			var owner = GetOwner();
			if (owner != null)
				return owner.IsMainCharacter();
			else
				return false;
		}

        public virtual void OnMouseIn()
        {

        }

        public virtual void OnMouseLeave()
        {

        }

        public virtual void OnAddToScene()
        {

        }
        protected virtual void CreateEntitySyncer()
        {
            m_syncer = new EntityInSyncer(this);
        }
        protected virtual void CreateStateMachine()
        {
            m_sm = SM.Factory.CreateSM(this);			
		}

        protected virtual void ReleaseStateMachine()
        {
            SM.Factory.ReleaseEntitySM(m_sm);
            m_sm = null;
        }

        public virtual void OnRemoveFromScene()
        {
            EntityEffectTextManager.Instance.DestoryAllEntityTextEffect(this);
            Defenders.Clear();
        }

        // protected virtual void OnPostStateChange(SM.Entity.States preState, SM.Entity.States curState)
        // {
        // }

		protected virtual void OnPositionChange()
		{
			onPositionChangeEvent.Invoke();

		}

		protected virtual void OnDirectionChange()
		{

		}

        protected virtual void OnDie()
        {
            if (Avatar.unityObject != null)
                Bokura.Clothify.EventHandler.OnEnterDie(Avatar.unityObject);
        }
        protected virtual void OnRelive()
        {
            if (Avatar.unityObject != null)
                Bokura.Clothify.EventHandler.OnExitDie(Avatar.unityObject);
        }
        public virtual void LoadModel(string modelpath = null)
		{
           
		}

        protected void AvatarLoadModel(string strAssetBundlesPath, string strModelName, bool bAsync)
        {
            if(IsAvatarLoaded)
            {
                onAvatarReLoad.Invoke();
            }
            if(m_avatar != null)
            {
                m_avatar.LoadModel(strAssetBundlesPath, strModelName, bAsync);
            }
        }

        public override void Update()
        {
            if(m_updateAnimStateDelay>0)
            {
                m_updateAnimStateDelay--;
                if(m_updateAnimStateDelay==0)
                {
                    m_curAnimState = m_acturalAnimState;
                }
            }

			Utilities.ProfilerBegin("Entity.EntitySyncer.Update");
            {
                if (m_syncer != null && !TimeLineing)
                    m_syncer.Update();
            }
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("Entity.Avatar.Update");
            {
                if (m_avatar != null)
                    m_avatar.Update();
            }
			Utilities.ProfilerEnd();

			// Utilities.ProfilerBegin("Entity.IStateMacine.Update");
            // {
            //     if (m_sm != null && !TimeLineing)
            //         m_sm.Update();
            // }
			// Utilities.ProfilerEnd();

			m_underAttackTrigger = false;
            m_attackTrigger = false;
            m_isInAttackChangeTrigger = false;

			Utilities.ProfilerBegin("Entity.BuffProxy.Update");
            {
                if (null != m_buffProxy)
                {
                    m_buffProxy.Update();
                }
            }
			Utilities.ProfilerEnd();
            //if (Avatar != null && Avatar.animator && Avatar.animator.layerCount > 1 && Avatar.animator.GetLayerWeight(1) > 0.0f)
            //{
            //    var stateinfo = Avatar.animator.GetCurrentAnimatorStateInfo(1);
            //    if (stateinfo.shortNameHash == AnimatorStateID.none)
            //    {
            //        Avatar.animator.SetLayerWeight(1, 0.0f);
            //    }
            //}
            if (m_bCarryBackTrigger==true)
            {
                tempuseCarryBacktime+= Time.deltaTime;
                if(tempuseCarryBacktime> useCarryBacktime)
                {
                    tempuseCarryBacktime = useCarryBacktime;
                    m_bCarryBackTrigger = false;
                    SetCarry(false, false);
                    //LogHelper.Log(" m_bCarryBackTrigger = false; Position=" + Position.ToString() );
                    GameScene.Instance.MainChar.CheckIsCloseEntity(true);
                }
                Position = Vector3.Slerp( CarryBackFromPos,CarryBackTarPos, tempuseCarryBacktime /useCarryBacktime);
            }
		}
       

        public virtual bool IsNeedDel()
        {
            return m_bDeleted;
        }

		protected static Collider[] overlayercollders = new Collider[64];
		public bool CheckInMyBoxRange(Vector3 center, Vector3 halfextend, Entity other )
		{
			//center = Position + center;
			center = Avatar.unityObject.transform.TransformPoint(center);
			int ncount = Physics.OverlapBoxNonAlloc(center, halfextend, overlayercollders, Avatar.unityObject.transform.rotation, (int)(UserLayerMask.Character | UserLayerMask.MainCharacter| UserLayerMask.NPC));
			for(int i = 0; i < ncount; i ++ )
			{
				if (overlayercollders[i].gameObject == other.Avatar.unityObject)
					return true;
			}
			return false;

		}

		public float GetAngleLocation(Entity ety)
		{
			var d = ety.Position - Position;
			d.y = 0.0f;
			if(d.sqrMagnitude < 0.001f)
			{
				return 0.0f;
			}
			d.Normalize();
			//Vector2 v1 = new Vector2(Direction.x,Direction.z);
			//Vector2 v2 = new Vector2(d.x, d.z);
			float a = Direction.x * d.x + Direction.z * d.z;
			var pd = new Vector3(Direction.z, 0, -Direction.x);
			float pa = pd.x * d.x + pd.z * d.z;
			//float a = Vector3.Dot(v1, v2);
			if(pa < 0.0f)
			{
				return -Mathf.Acos(a) * Mathf.Rad2Deg;

			}
			else
			{
				return Mathf.Acos(a) * Mathf.Rad2Deg;

			}
		}

        #region Animator

        void OnAnimStateMachineEnter(int stateid, int layer)
        {
            if (layer == 0)
            {
                m_acturalAnimState = (SM.Entity.States)stateid;
                m_updateAnimStateDelay = 3;
            }
            else if (layer == 1)
            {
                m_curUpBodyAnimState = (SM.Entity.States)stateid;
            }

        }
        public void SetAnimatorParam(int paramid, float f,float damptime,float deltatime)
        {
            m_avatar.SetAnimParamFloat(paramid, f, damptime,deltatime);
        }
        public void SetAnimatorParam(int paramid, float f)
        {
            m_avatar.SetAnimParamFloat(paramid, f);
        }
        public void SetAnimatorParamBool(int paramid, bool b)
        {
            m_avatar.SetAnimParamBool(paramid, b);
        }
        public float GetAnimatorParam(int paramid )
        {
            return m_avatar.animator.GetFloat(paramid);
        }
        int m_nCurCrossFadeAllAnimId = 0;
        public bool CrossFadeAll(int animid, float fadetime=0.1f, float normalize = 0.0f ,bool forcePlay = true)
		{
            bool ret = Avatar.animator.CrossFadeAll(animid, fadetime, normalize, forcePlay);
            m_nCurCrossFadeAllAnimId = animid;
            CrossFadeAnimPostProcess(animid, false);
            return ret;
        }

        protected virtual void CrossFadeAnimPostProcess(int animid, bool forceplay) { }

        // public void CrossFadeAll(SM.Entity.States state, int animid, float fadetime = 0.1f, float normalize = 0.0f)
        // {
        //     if (HasAnim(animid))
		// 		m_curAnimState = state;
		// 	else
		// 	{
        //         LogHelper.LogWarning("GameStateNotFound!", animid.ToString());
        //         return;
		// 	}
		// 	CrossFadeAll(animid, fadetime, normalize);
        //     //LogHelper.Log("cross fade anim!");
        // }
        public float GetCurAnimLength()
        {
            if (m_avatar == null)
                return 0;

            if (m_avatar.animator == null)
                return 0;

            RuntimeAnimatorController runanimator = m_avatar.animator.MainAnimator.runtimeAnimatorController;
            if (runanimator == null)
                return 0;

            AnimationClip[] clips = runanimator.animationClips;
            if (clips.Length <= 0)
                return 0;

            string curanimname = "";
            AnimatorClipInfo[] animclips = m_avatar.animator.MainAnimator.GetCurrentAnimatorClipInfo(0);
            if (animclips.Length <= 0)
            {
                AnimatorClipInfo[] nextanimclips = m_avatar.animator.MainAnimator.GetNextAnimatorClipInfo(0);
                if (nextanimclips.Length >= 0)
                {
                    AnimatorClipInfo animclip = nextanimclips[0];
                    curanimname = animclip.clip.name;
                }
            }
            else
            {
                AnimatorClipInfo animclip = animclips[0];
                curanimname = animclip.clip.name;
            }
            
            //LogHelper.Log("[HC]GetAnimLength         ", curanimname);

            foreach (var clip in clips)
            {
                if (clip.name == curanimname)
                {
                    //LogHelper.Log("[HC]GetAnimLength         ", clip.length);

                    return clip.length;
                }
            }

            return 0;

            //if (m_avatar != null && m_avatar.animator && m_avatar.animator.layerCount > 0)
            //{
            //    AnimatorClipInfo []clipinfolist = m_avatar.animator.GetCurrentAnimatorClipInfo(0);
            //    if (clipinfolist.Length <= 0)
            //        return 0;

            //    AnimatorClipInfo clipinfo = clipinfolist[0];
            //    if (clipinfo.clip == null)
            //        return 0;

            //    return clipinfo.clip.length;
            //}

            //return 0;
        }

        public float GetCurAnimNormalizedTime()
        {
            var stateinfo = m_avatar.GetCurrentAnimatorStateInfo(0);
            if (stateinfo.normalizedTime == 0)
                return 0;
            int n = (int)stateinfo.normalizedTime;
            if (n == 0)
                return 0;
            return stateinfo.normalizedTime % n;
        }

        public bool HasAnim(int animid)
		{
            if (Avatar != null && Avatar.animator != null)
            {
                return Avatar.animator.HasAnim(animid);
            }

            return false;
		}
        public bool IsPlayingAnimtion( int animid, int layer = 0)
        {
            return Avatar.animator.IsPlayingAnimtion( animid, layer);
        }

        public void SetAnimatorSpeed(float speed = 1.0f)
        {
            if(Avatar != null && Avatar.animator != null)
            {
                Avatar.animator.speed = speed;
            }
        }
        public void SetAnimLayerWeight(int layer, float weight)
        {
            //if(IsMainCharacter())
            //    LogHelper.Log("SetAnimWeight", layer, weight);

            Avatar.animator.SetLayerWeight(layer, weight);
            
        }
        public float GetAnimLayerWeight(int layer)
        {
            return Avatar.animator.GetLayerWeight(layer);
        }
        #endregion
        public virtual void RemoveAllEffects()
        {
            
        }

        #region MaterialProperty
        public void SetMaterialKeyWord(string name, bool value)
        {
            if (m_avatar != null && m_avatar.MaterialProterties != null)
            {
                if(value)
                    m_avatar.MaterialProterties.EnableKeyword(name);
                else
                    m_avatar.MaterialProterties.DisableKeyword(name);
            }

        }

        public void SetMaterialProperty(string name,float value)
        {
            if (m_avatar != null && m_avatar.MaterialProterties != null)
                m_avatar.MaterialProterties.SetFloat(name, value);
        }
        public void SetMaterialProperty(string name, Vector4 value)
        {
            if (m_avatar != null && m_avatar.MaterialProterties != null)
                m_avatar.MaterialProterties.SetVector(name, value);
        }
        public void SetMaterialProperty(string name, Color value)
        {
            if (m_avatar!=null && m_avatar.MaterialProterties != null)
                m_avatar.MaterialProterties.SetColor(name, value);
        }
        public void SetMaterialProperty(string name, Texture2D value)
        {
            if (m_avatar != null && m_avatar.MaterialProterties != null)
                m_avatar.MaterialProterties.SetTexture2D(name, value);
        }
        #endregion


        public static implicit operator bool(Entity ety)
		{
			return ety != null;
        }

        private MovableEntity GetMovableEntity()
        {
            return this as MovableEntity;
        }

        #region Skill Effect
        public override void MessageInvoke<T>(T t)
        {
            if (typeof(T) == typeof(AttackEffect))
            {
                CastAttackEffect(t as AttackEffect);
            }
            else if (typeof(T) == typeof(HurtEffect))
            {
                CastHurtEffect(t as HurtEffect);
            }
            else if (typeof(T) == typeof(HurtEffectStart))
            {
                CastHurtEffectStart(t as HurtEffectStart);
            }
            else if (typeof(T) == typeof(MaterialChangeEffectEx))
            {
                CastMaterialChangeEx(t as MaterialChangeEffectEx);
            }
            else if (typeof(T) == typeof(DefendMaterialChangeEffectEx))
            {
                CastDefendMaterialChangeEx(t as DefendMaterialChangeEffectEx);
            }
            else if (typeof(T) == typeof(BulletEffect))
            {
                CastBulletEffect(t as BulletEffect);
            }
            else if (typeof(T) == typeof(FireBulletEffect))
            {
                CastFireBulletEffect(t as FireBulletEffect);
            }
            else if (typeof(T) == typeof(DestroyBulletEffect))
            {
                CastDestroyBulletEffect(t as DestroyBulletEffect);
            }
            else if (typeof(T) == typeof(WwiseAudioStart))
            {
                CastWwiseAudioStart(t as WwiseAudioStart);
            }
            else if (typeof(T) == typeof(WwiseAudioStop))
            {
                CastWwiseAudioStop(t as WwiseAudioStop);
            }
            else if (typeof(T) == typeof(AudioStudio.AudioEventPC))
            {
                CastDefendWwiseAudio(t as AudioStudio.AudioEventPC);
            }
            else if (typeof(T) == typeof(EventStart))
            {
                CastEventStart(t as EventStart);
            }
            else if (typeof(T) == typeof(GrassEventStart))
            {
                CastGrassEventStart(t as GrassEventStart);
            }
            else if (typeof(T) == typeof(DefendGrassEventStart))
            {
                CastDefendGrassEventStart(t as DefendGrassEventStart);
            }

        }

        private void CastMaterialChangeEx(MaterialChangeEffectEx change)
        {
            if (this.Avatar != null)
            {
                if (change.isChangeMat)
                {
                    if (change.isBody)
                    {
                        this.Avatar.MaterialProterties.SetColor(MaterialChangeEffectEx.TintColorContent, change.tintColor);
                        this.Avatar.MaterialProterties.SetFloat(MaterialChangeEffectEx.DissolveThresholdContent, change.dissolveThreshold);
                        this.Avatar.MaterialProterties.SetColor(MaterialChangeEffectEx.DissolveColorContent, change.dissolveColor);
                        this.Avatar.MaterialProterties.SetFloat(MaterialChangeEffectEx.EdgeSizeContent, change.edgeSize);
                    }
                    if (GetMovableEntity() != null)
                    {
                        if (change.isPrimaryWeapon && GetMovableEntity().PrimaryWeapon != null)
                        {
                            GetMovableEntity().PrimaryWeapon.Avatar.MaterialProterties.SetColor(MaterialChangeEffectEx.TintColorContent, change.tintColor);
                            GetMovableEntity().PrimaryWeapon.Avatar.MaterialProterties.SetFloat(MaterialChangeEffectEx.DissolveThresholdContent, change.dissolveThreshold);
                            GetMovableEntity().PrimaryWeapon.Avatar.MaterialProterties.SetColor(MaterialChangeEffectEx.DissolveColorContent, change.dissolveColor);
                            GetMovableEntity().PrimaryWeapon.Avatar.MaterialProterties.SetFloat(MaterialChangeEffectEx.EdgeSizeContent, change.edgeSize);
                        }
                        if (change.isSecondaryWeapon && GetMovableEntity().SecondaryWeapon != null)
                        {
                            GetMovableEntity().SecondaryWeapon.Avatar.MaterialProterties.SetColor(MaterialChangeEffectEx.TintColorContent, change.tintColor);
                            GetMovableEntity().SecondaryWeapon.Avatar.MaterialProterties.SetFloat(MaterialChangeEffectEx.DissolveThresholdContent, change.dissolveThreshold);
                            GetMovableEntity().SecondaryWeapon.Avatar.MaterialProterties.SetColor(MaterialChangeEffectEx.DissolveColorContent, change.dissolveColor);
                            GetMovableEntity().SecondaryWeapon.Avatar.MaterialProterties.SetFloat(MaterialChangeEffectEx.EdgeSizeContent, change.edgeSize);
                        }
                    }
                }
                else
                {
                    if (change.isBody)
                    {
                        this.Avatar.MaterialProterties.SetColor(RimColor, change.colour);
                        this.Avatar.MaterialProterties.SetFloat(RimPower, change.power);
                    }
                    if (GetMovableEntity() != null)
                    {
                        if (change.isPrimaryWeapon && GetMovableEntity().PrimaryWeapon != null)
                        {
                            GetMovableEntity().PrimaryWeapon.Avatar.MaterialProterties.SetColor(RimColor, change.colour);
                            GetMovableEntity().PrimaryWeapon.Avatar.MaterialProterties.SetFloat(RimPower, change.power);
                        }
                        if (change.isSecondaryWeapon && GetMovableEntity().SecondaryWeapon != null)
                        {
                            GetMovableEntity().SecondaryWeapon.Avatar.MaterialProterties.SetColor(RimColor, change.colour);
                            GetMovableEntity().SecondaryWeapon.Avatar.MaterialProterties.SetFloat(RimPower, change.power);
                        }
                    }
                }
            }
        }

        private void CastDefendMaterialChangeEx(DefendMaterialChangeEffectEx change)
        {
            for (var i = 0; i < Defenders.Count; i++)
            {
                if (Defenders[i].Avatar != null)
                {
                    Defenders[i].Avatar.MaterialProterties.SetColor(RimColor, change.colour);
                    Defenders[i].Avatar.MaterialProterties.SetFloat(RimPower, change.power);
                }
            }
        }

        private void CastBulletEffect(BulletEffect effect)
        {
            ((ScriptPlayable<BulletBehaviour>)effect.playable).GetBehaviour().UpdateProgress();
        }
        private void CastFireBulletEffect(FireBulletEffect effect)
        {
            if (effect.bulletDefenders == null)
            {
                return;
            }

            for (var i = 0; i < effect.bulletDefenders.Count; i++)
            {
                if (effect.bulletDefenders[i].unityObject == null)
                {
                    continue;
                }
                BulletComponent bc = new BulletComponent(effect.bulletDefenders[i].unityObject);
                bc.Init(effect, effect.bulletDefenders[i].unityObject.transform);
            }
        }
        private void CastDestroyBulletEffect(DestroyBulletEffect effect)
        {
            effect.behaviour.DestroyBullet();
        }

        private void CastHurtActionStart(string actionId)
        {
            if (string.IsNullOrEmpty(actionId))
                return;

            for (var i = 0; i < Defenders.Count; i++)
            {
                if (Defenders[i].IsInClickFly || Defenders[i].Died)
                    continue;

                // 占领交互点的时候不播放受击行为
                var movableentity = Defenders[i] as MovableEntity;
                if (movableentity != null && movableentity.IsInInteractionPoint)
                    continue;

                if (Defenders[i].UnderAttack(Animator.StringToHash(actionId)) != 0)
                {
                    if (!(Defenders[i].StateMachine.CurStateID == SM.Entity.States.MOVE))
                        Defenders[i].DirectTo(GlobalPosition);
                }
            }
        }

        private void CastAttackEffect(AttackEffect effect)
        {
            ((ScriptPlayable<EffectBehaviour>)effect.playable).GetBehaviour().AttackPrepareFrame();
        }

        private void CastHurtEffect(HurtEffect effect)
        {
            //LogHelper.LogWarning("CastHurtEffect");
            for (var i = 0; i < Defenders.Count; i++)
            {
                var behaviour = ((ScriptPlayable<DefendEffectBehaviour>)effect.playable).GetBehaviour();
                if (behaviour.data != null && IsEffectFilted(behaviour.data.filterType))
                {
                    if (Defenders[i] != null && Defenders[i].m_avatar != null)
                    {
                        behaviour.DefendPrepareFrame(m_avatar.unityObject);
                    }
                }
            }
        }

        private void CastHurtEffectStart(HurtEffectStart effect)
        {
            //LogHelper.LogWarning("CastHurtEffect");
            var behaviour = ((ScriptPlayable<DefendEffectBehaviour>)effect.playable).GetBehaviour();
            for (var i = 0; i < Defenders.Count; i++)
            {
                if (behaviour.data != null && IsEffectFilted(behaviour.data.filterType))
                {
                    if (Defenders[i] != null && Defenders[i].m_avatar != null)
                    {
                        Transform attacker = null;
                        if(Defenders[i].IsNpc())
                        {
                            //var npc = Defenders[i] as Npc;
                            //if (npc != null && npc.NpcConfig.HasValue && npc.NpcConfig.Value.type == (int)swm.NpcType.NPCTYPE_MONSTER)
                                attacker = Avatar.unityObject.transform;
                        }
                        behaviour.DefendBehaviourPlay(Defenders[i].m_avatar.unityObject, HitEffectScale, attacker);
                    }
                }
            }
            behaviour.SetInit();
        }
        private void CastWwiseAudioStart(WwiseAudioStart audio)
        {
            if (CurAnimationSound != null)
            {
                CurAnimationSound.IsUpdatePosition = audio.isUpdatePosition;
                CurAnimationSound.Play(audio.playEvent);
            }

        }

        private void CastWwiseAudioStop(WwiseAudioStop audio)
        {
            if (CurAnimationSound != null)
            {
                if (audio.stop)
                {
                    CurAnimationSound.Stop(audio.playEvent);
                }
                if (audio.stopEvent != null)
                {
                    CurAnimationSound.Play(audio.stopEvent);
                }
            }

        }

        private void CastDefendWwiseAudio(AudioStudio.AudioEventPC ae)
        {
            for (var i = 0; i < Defenders.Count; i++)
            {
                if (Defenders[i].CurAnimationSound != null)
                    Defenders[i].CurAnimationSound.Play(ae);
                else
                    ae.Post(Defenders[i].Avatar.unityObject, IsMainCharacter());
            }
        }

        private void CastEventStart(EventStart start)
        {

        }

        private void CastGrassEventStart(GrassEventStart start)
        {
            if (GetMovableEntity() == null)
                return;
            GrassEventStart(start.startData, GetMovableEntity().Avatar.unityObject.transform);
        }

        private void CastDefendGrassEventStart(DefendGrassEventStart start)
        {
            for (var i = 0; i < Defenders.Count; i++)
            {
                if (Defenders[i].m_avatar != null && Defenders[i].m_avatar.unityObject != null)
                {
                    GrassEventStart(start.startData, Defenders[i].m_avatar.unityObject.transform);
                }
            }
        }

        private void GrassEventStart(CritiasFoliage.CutoffGrassAnimateData data, Transform trans)
        {
            var InteractiveMap = CritiasFoliage.FoliageTileManager.Instance.m_interactiveMap;
            if (InteractiveMap == null || data == null)
                return;
            InteractiveMap.CastGrassAnimate(data, trans);
        }

        static CastMagicData m_castMagicData= new CastMagicData();
        static MagicExportClient m_clientData;
        public void CastMagic(uint skillId,uint motionId, List<IAvatar> targets,Vector3 targetPos)
        {
            if (m_avatar != null && GameScene.Instance.MainChar != null)
            {
                m_castMagicData.skillId = skillId;
                m_castMagicData.motionId = motionId;
                m_castMagicData.defender = targets;
                m_castMagicData.distance = (GameScene.Instance.MainChar.Position - Position).magnitude;
                m_castMagicData.isMainCharacter = IsMainCharacter();
                m_castMagicData.targetPos = targetPos;
                m_castMagicData.humidity = (MagicHumidityType)WeatherManager.Instance.humidityType;
                m_castMagicData.isFlashing = WeatherManager.Instance.isCurrFlashing();
                m_castMagicData.attacker = m_avatar.unityObject;
                m_avatar.CastMagic(m_castMagicData);
                m_attackTrigger = true;
                //SetAnimID(SM.Entity.States.ATTACK, 0);

            }
        }
        public void CastDefenderMagic(CastDefenderData data)
        {
            if (m_avatar != null)
            {
                var actionName = GetHurtActionName(data);
                if (data.showAction)
                {
                    CastHurtActionStart(actionName);
                }
                if (data.casterIsMainCharacter)
                {
                    CastHurtMaterial();
                }
                m_avatar.CastDefenderMagic(data);
            }
        }

        /// <summary>
        /// 获取受击动作名并设置受击开始时间(与受击特效等时间差值用)
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string GetHurtActionName(CastDefenderData data)
        {
            string actionName = "";
            m_clientData = Bokura.Timeline.TimeLineMagicManager.GetExportClient(data.skillId);
            for (int i = 0; i < m_clientData.actions.Count; i++)
            {
                ActionData temp = m_clientData.actions[i];
                if (temp.groupId != data.hitIDX && temp.groupId != -1)
                {
                    continue;
                }
                if (!temp.isAttack)
                {
                    actionName = temp.actionId;
                    data.startTime = temp.start;
                    break;
                }
            }
            return actionName;
        }

        /// <summary>
        /// 构建受击闪白
        /// </summary>
        public void CastHurtMaterial()
        {
            for (var i = 0; i < Defenders.Count; i++)
            {
                if (Defenders[i].m_avatar != null && Defenders[i].m_avatar.unityObject != null)
                {
                    ActionEffectManager.Instance.OnPlayMaterialChange(Defenders[i].m_avatar.unityObject, MecanimEventManager.MaterialCommon);
                }
            }
        }

        #endregion

        public void StopMagicAction(uint skillId)
        {
            if (m_avatar != null)
            {
                m_avatar.StopMagicAction(skillId);
            }
        }

        public void PlayBubbleAndSound(string talk, string eventname)
        {
            AudioCtrl.PlaySound(eventname, Avatar.unityObject);
        }

        public virtual void PlayDrama(Timeline.TimelineDesc desc)
        {
            desc.stopAll = true;
            desc.career = (int)CareerType;
            desc.sex = (int)Sex;
            desc.AddActor(0, this);
            DramaManager.Instance.PlayDrama(desc);
        }

        public void PlaySlowMotionSkill(bool isOn)
        {
            m_avatar.EnableBulletTime(isOn);
        }

        public bool IsEffectFilted(int filterType)
        {
            if (filterType != (int)FilterType.NONE)
            {
                if (GetMovableEntity() == null)
                    return false;

                int spacefilter = filterType & (int)FilterType.SPACE_MASK;
                if (spacefilter != 0)
                {
                    if (GetMovableEntity().IsFlying)
                    {
                        if ((spacefilter & (int)FilterType.SPACE_IN_SKY) == 0)
                            return true;
                    }
                    else
                    {
                        if ((spacefilter & (int)FilterType.SPACE_IN_LAND) == 0)
                            return true;
                    }
                }

            }
            return true;
        }

		public bool IsInRange(Entity target, float maxDistance)
		{
			if (target == null) return false;
			return Vector3.SqrMagnitude(Position - target.Position) <= maxDistance * maxDistance;
		}

        public float GetTargetDistance(Entity target)
        {
            return (target.GlobalPosition - GlobalPosition).magnitude;
        }

        public float GetTargetDisDir(Entity target, out Vector3 dir)
        {
            if(!target)
            {
                dir = Direction;
                return 0.0f;
            }
            if(target.VoxelWorldID!=VoxelWorldID)
            {
                var targetpos = target.Position;
                if(target.VoxelWorldID!=0)
                {
                    targetpos = MobileBlockMgr.Instance.LocalPos2WorldPos(targetpos, target.VoxelWorldID);
                }
                if(VoxelWorldID!=0)
                {
                    targetpos = MobileBlockMgr.Instance.WorldPos2LocalPos(targetpos, VoxelWorldID);
                }
                dir = (targetpos - Position);
                return dir.magnitude;

            }
            else
            {
                dir = (target.Position - Position);
                return dir.magnitude;
            }            
        }
        
        public float GetTargetDistance(Vector3 target)
        {
            return (target - GlobalPosition).magnitude;
        }

        public bool IsIdleAnimState()
        {
            return m_curAnimState == SM.Entity.States.IDLE;
        }

        #region  切换隐身shader
        private static int m_shaderAlphaNameID = 0;
        public static int ShaderAlphaNameID
        {
            get
            {
                if (m_shaderAlphaNameID == 0)
                {
                    m_shaderAlphaNameID = Shader.PropertyToID("_Alpha");
                }
                return m_shaderAlphaNameID;
            }
        }
        private bool m_isInvisibleShader;
        private Dictionary<string, List<Shader>> m_cachedOrgShaderDic= null;
        private Dictionary<string, List<Shader>> CachedOrgShaderDic
        {
            get
            {
                if (m_cachedOrgShaderDic == null)
                {
                    m_cachedOrgShaderDic = new Dictionary<string, List<Shader>>(8);
                }
                return m_cachedOrgShaderDic;
            }
            set
            {
                m_cachedOrgShaderDic = value;
            }
        }
        private List<Renderer> m_rendererParts = null;
        private List<Renderer> RendererParts
        {
            get
            {
                if (m_rendererParts == null)
                {
                    m_rendererParts = new List<Renderer>(8);
                }
                return m_rendererParts;
            }
            set
            {
                m_rendererParts = value;
            }
        }

        public void SetInvisibleShader(float alphaval = 0.5f)
        {
            if (m_isInvisibleShader) return;
            if (Avatar == null || Avatar.unityObject == null) return;
            var root = Avatar.unityObject.GetComponentInChildren<Animator>(true);
            if (root == null) return;
            var partSkinneds = root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var partMeshs = root.GetComponentsInChildren<MeshRenderer>(true);

            RendererParts.Clear();

            for (int i = 0; i < partSkinneds.Length; i++)
            {
                if (partSkinneds[i].gameObject.name.Equals("uniqueDecal"))
                {
                    continue;
                }

                if (partSkinneds[i].gameObject.name.Equals("DynamicDecalRenderer"))
                {
                    continue;
                }

                RendererParts.Add(partSkinneds[i]);
            }

            for (int i = 0; i < partMeshs.Length; i++)
            {
                if (partMeshs[i].gameObject.name.Equals("uniqueDecal"))
                {
                    continue;
                }

                if (partMeshs[i].gameObject.name.Equals("DynamicDecalRenderer"))
                {
                    continue;
                }

                RendererParts.Add(partMeshs[i]);
            }

            for (int i = 0; i < RendererParts.Count; i++)
            {
                Renderer renderer = RendererParts[i];
                if (renderer == null)
                    continue;

                List<Shader> orgSds = null;
                if (CachedOrgShaderDic.ContainsKey(renderer.gameObject.name))
                {
                    orgSds = CachedOrgShaderDic[renderer.gameObject.name];
                    orgSds.Clear();
                }
                else
                {
                    orgSds = new List<Shader>(8);
                    CachedOrgShaderDic.Add(renderer.gameObject.name, orgSds);
                }

                Material[] materials = renderer.materials;
                if (materials != null)
                {
                    for (int j = 0; j < materials.Length; j++)
                    {
                        Material curmat = materials[j];
                        if (curmat == null)
                            continue;

                        if (curmat.shader == null)
                            continue;

                        orgSds.Add(curmat.shader);

                        Shader sd = InvisibleShaderConfigMgr.Instance.MatchShaderVsb(curmat.shader.name);

                        if (sd != null)
                        {
                            //LogHelper.LogError("shader.name:"+ m_parts[i].materials[j].shader.name + " Matchsd:"+sd);
                            curmat.shader = sd;
                            curmat.SetFloat(ShaderAlphaNameID, alphaval);
                        }
                    }
                }
            }

            m_isInvisibleShader = true;
        }
        [XLua.BlackList]
        public void RefreshMaterialAlpha(float alphaval)
        {
            if (!m_isInvisibleShader)
                return;

            if (RendererParts == null)
                return;

            if (RendererParts.Count <= 0)
                return;

            for (int i = 0; i < RendererParts.Count; i++)
            {
                Renderer renderer = RendererParts[i];
                if (renderer == null)
                    continue;

                Material[] materials = renderer.materials;
                if (materials == null)
                    continue;

                if (materials.Length <= 0)
                    continue;

                for (int j = 0; j < materials.Length; j++)
                {
                    materials[j].SetFloat(ShaderAlphaNameID, alphaval);
                }
            }
        }

        public void ResumeInvisibleShader()
        {
            if (!m_isInvisibleShader) return;
            if (Avatar == null || Avatar.unityObject == null) return;
            var root = Avatar.unityObject.GetComponentInChildren<Animator>(true);
            if (root == null) return;
            var partSkinneds = root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var partMeshs = root.GetComponentsInChildren<MeshRenderer>(true);
            
            RendererParts.Clear();
            
            for (int i = 0; i < partSkinneds.Length; i++)
            {
                RendererParts.Add(partSkinneds[i]);
            }
            for (int i = 0; i < partMeshs.Length; i++)
            {
                RendererParts.Add(partMeshs[i]);
            }

            for (int i = 0; i < RendererParts.Count; i++)
            {
                Renderer renderer = RendererParts[i];
                if (renderer == null)
                    continue;

                Material[] materials = renderer.materials;
                if (materials == null)
                    continue;

                for (int j = 0; j < materials.Length; j++)
                {
                    Material curmat = materials[j];
                    if (curmat == null)
                        continue;

                    if (CachedOrgShaderDic.ContainsKey(renderer.gameObject.name) &&
                        CachedOrgShaderDic[renderer.gameObject.name].Count > j)
                    {
                        curmat.shader = CachedOrgShaderDic[renderer.gameObject.name][j];
                    }
                }
            }

            m_isInvisibleShader = false;
        }

        #endregion

        #region //----------------------------
        public bool IsInWater()
        {
            return (IWorldMatLUT.Instance.isInWater(GlobalPosition) || IWorldMatLUT.Instance.isLightInWater(GlobalPosition));
        }
        //深水区
        public bool IsHeightInWater()
        {
            return IWorldMatLUT.Instance.isInWater(GlobalPosition);
        }
        private GameEvent m_cloundChangedEvent = new GameEvent();
        public GameEvent OnCloundChangedEvent
        {
            get { return m_cloundChangedEvent; }
        }

        private bool isInCloud = false;
        /// <summary>
        /// 当前是否在云海里;
        /// </summary>
        /// <returns></returns>
        public bool isCurrInCloud()
        {
            return isInCloud;
        }

        public bool SetCurrInCloud(bool value)
        {
            isInCloud = value;

            m_cloundChangedEvent?.Invoke();

            return isInCloud;
        }

        /// <summary>
        /// 是否在传送中;
        /// </summary>

        private bool isTransmitting = false;
        public bool isCloudTransmitting()
        {
            return isTransmitting;
        }

        public bool SetCloudTransmitting(bool value)
        {
            isTransmitting = value;

            m_cloundChangedEvent?.Invoke();

            return isTransmitting;
        }

        public bool isCurrCloudState()
        {
            return (isTransmitting || isInCloud);
        }

        public bool isIntoCloud = false;

        public Vector3 m_enterToCloudPos = Vector3.zero;
        public Vector3 EnterCloudPos
        {
            get { return m_enterToCloudPos; }
            set { m_enterToCloudPos = value; }
        }
        #endregion//-----------------------------云海系统;
        protected bool m_b_isBeAttachTo = false;
        public bool b_isBeAttachTo  //当前角色被绑定到其他的avatar  则不更新位置 方向
        {
            set
            {
                m_b_isBeAttachTo = value;
                ShowNameAndBeChoose(!m_b_isBeAttachTo);
            }
            get
            {
                return m_b_isBeAttachTo;
            }
        }
        protected ulong m_ul_BeAttachToRoleId = 0;
        public ulong ul_BeAttachToRoleId  //当前角色被绑定到其他的角色id
        {

            set
            {
                m_ul_BeAttachToRoleId = value;
            }
            get
            {
                return m_ul_BeAttachToRoleId;
            }
        }
        protected ulong m_ul_AttachRoleId = 0;
        public ulong ul_AttachRoleId  ///当前角色绑定了其他的角色id
        {

            set
            {
                m_ul_AttachRoleId = value;
            }
            get
            {
                return m_ul_AttachRoleId;
            }
        }
        //当该角色被绑定到其他玩家角色avatar上时  关闭显示角色名字和被选中的特效
        public void ShowNameAndBeChoose(bool isshow)
        {
            onSetTempShowHead.Invoke(isshow);
        }

        #region //--------------- npc 搬运相关

        protected uint m_LastAttachNpcID = 0;
        public uint LastAttachNpcID ///被丢下的其他角色ID
        {
            set
            {
                m_LastAttachNpcID = value;
            }
            get
            {
                return m_LastAttachNpcID;
            }
        }

        protected Vector3 m_AttachNpcPos = Vector3.zero;
        public Vector3 AttachNpcPos  //被丢下的其他角色位置
        {
            set
            {
                m_AttachNpcPos = value;
            }
            get
            {
                return m_AttachNpcPos;
            }
        }

        private bool m_bCarryTrigger = false;
        public bool CarryTrigger
        {
            get
            {
                return m_bCarryTrigger;
            }
        }
        public bool m_isbeCarry = false;
        public void SetCarry(bool v,bool isbeCarry)
        {
            m_bCarryTrigger = v;
            m_isbeCarry = isbeCarry;
        }
        bool m_bCarryBackTrigger = false;
        public bool CarryBackTrigger
        {
            get
            {
                return m_bCarryBackTrigger;
            }
        }

        float useCarryBacktime = 0.5f;
        float tempuseCarryBacktime = 0f;
        Vector3 CarryBackFromPos;
        Vector3 CarryBackTarPos;
        public void SetCarryBack(Vector3 pos, Vector3 tarpos)
        {
            m_bCarryBackTrigger = true;
            tempuseCarryBacktime = 0f;
            CarryBackFromPos= pos;
            CarryBackTarPos= tarpos;
            useCarryBacktime = 0.5f;
            LogHelper.Log("SetCarryBack "+pos.ToString()+" tarpos="+ tarpos.ToString());
        }

        CarryLineTx m_CarryLineTx=null;
        public void ShowLineTeToOtherRole(AvatarAttachment aato,Entity to,string txname,string handtxname,string path)
        {
            // CarryLineTx
            //m_ToEntity.Avatar.unityObject
            
            if(m_CarryLineTx==null)
            {
                m_CarryLineTx = Avatar.unityObject.AddComponent<CarryLineTx>();
                
            }
            m_CarryLineTx.IniShowEffect(this, to);
            m_CarryLineTx.ShowEffect(aato, txname, handtxname,path);
        }
        public void StopLineTeToOtherRole()
        {
            if (m_CarryLineTx != null)
            {
                m_CarryLineTx.ReleseEffect();
                GameObject.Destroy(m_CarryLineTx);
                m_CarryLineTx = null;
            }

        }
        [XLua.BlackList]
        public void CarryAnimaMoveToPos(Vector3 frompos, Transform toTransform, float toScale, float time)
        {
            if (m_CarryLineTx != null)
            {
                m_CarryLineTx.AnimaMoveToPos( frompos, toTransform, toScale, time);
            }
        }
        [XLua.BlackList]
        public void CarrySetToPos(Transform toTransform, float toScale)
        {
            if (m_CarryLineTx != null)
                m_CarryLineTx.SetToPos(toTransform, toScale);
        }
        #endregion //搬运相关 end
    }
    /// <summary>
    ///  克隆体的用途
    /// </summary>
    public enum CloneUsage
    {
        /// <summary>
        /// Npc访问
        /// </summary>
        NpcVisit = 0,
        /// <summary>
        /// 剧场
        /// </summary>
        Drama = 1,
    }
}

