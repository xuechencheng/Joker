using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bokura;
using UnityEngine;

namespace Bokura
{
   public class GatherResourceEntity : MovableEntity
    {
        //采集npc数据
        public class GatherResource
        {
            public uint baseid = 0;
            public uint colstate = 0;           // 资源收集状态
        }

        //private const string DisappearAnimName = "disappear";   // 消失
        private const string CanGatherAnimName = "cangather";   // 可采集
        private const string UnGatherAnimName = "ungather";     // 不可采集

        private ResourceTableBase? m_GatherResourceConfig = null;

        private GatherResource m_GatherData = new GatherResource();

        private string m_currentModelPath = string.Empty;

        protected swm.TaskNpcState m_taskState = swm.TaskNpcState.None;

        /// <summary>
        /// 常驻特效
        /// </summary>
        private EffectMgr.EffectInfo m_stayeff = null;
        private EffectMgr.EffectInfo m_cangathereff = null;

        public ResourceTableBase? GatherResourceConfig
        {
            get
            {
                return m_GatherResourceConfig;
            }
        }

        public override uint BaseID
        {
            get
            {
                return m_GatherData.baseid;
            }
        }


        /// <summary>
        /// 资源采集状态
        /// </summary>
        public override uint resColState
        {
            get { return m_GatherData.colstate; }
        }


        public GatherResourceEntity(ulong id):base(id)
        {
            m_layer = (Int32)(UserLayer.Layer_NPC);
        }

        [XLua.BlackList]
        public override bool Selectable
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public GatherResourceEntity() : base()
        {
        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public override void InitEntity(ulong id)
        {
            base.InitEntity(id);
            m_layer = (Int32)(UserLayer.Layer_NPC);
        }

        [XLua.BlackList]
        public override void Release()
        {
            //LogHelper.Log(LogCategory.GameLogic, "GatherResourceEntity:Release EntityId : ", m_thisid);

            //RefreshDeadEffect();

            if (m_stayeff != null)
            {
                m_stayeff.Stop();
                m_stayeff = null;
            }

            if (m_cangathereff != null)
            {
                m_cangathereff.Stop();
                m_cangathereff = null;
            }

            base.Release();

            //Game.GameApplication.Instance.GetTimerManager().AddTimer(() =>
            //{
            //    base.Release();

            //    if (m_stayeff != null)
            //    {
            //        m_stayeff.Stop();
            //        m_stayeff = null;
            //    }

            //    if (m_cangathereff != null)
            //    {
            //        m_cangathereff.Stop();
            //        m_cangathereff = null;
            //    }

            //}, 2.0f);
        }

        private void VisibleEffects(bool value)
        {
            if (m_stayeff != null)
            {
                m_stayeff.Visible = value;
            }

            if (m_cangathereff != null)
            {
                m_cangathereff.Visible = value;
            }
        }

        public override bool Visible
        {
            set
            {
                if (base.Visible != value)
                {
                    VisibleEffects(value);
                }

                base.Visible = value;


            }
        }

        public override bool VisibleByTimeline
        {
            set
            {
                VisibleEffects(value);
                base.VisibleByTimeline = value;
            }
        }



        public override bool VisibleBySkill
        {
            set
            {
                VisibleEffects(value);
                base.VisibleBySkill = value;
            }
        }

        public override bool VisibleByAction
        {
            set
            {
                VisibleEffects(value);
                base.VisibleByAction = value;
            }
        }
        public override bool VisibleByCamera
        {
            get
            {
                return m_bVisibleByCamera;
            }
            set
            {
                VisibleEffects(value);
                base.VisibleByCamera = value;
            }
        }

        public override bool VisibleByLevelSystem
        {
            set
            {
                VisibleEffects(value);
                base.VisibleByLevelSystem = value;
            }
        }

        public override bool VisibleByTreasure
        {
            set
            {
                VisibleEffects(value);
                base.VisibleByTreasure = value;
            }
        }

        /// <summary>
        /// 隐藏死亡动画
        /// </summary>
        public override bool HideDiedAnim
        {
            get
            {
                if (m_GatherResourceConfig.HasValue)
                {
                    return m_GatherResourceConfig.Value.death_hide > 0;
                }

                return false;
            }
        }

        protected override void OnDataUpdate()
        {
            base.OnDataUpdate();

            if (m_data != null)
            {
                m_GatherResourceConfig = ResourceTableManager.GetData((int)BaseID);

                LoadModel();
            }
        }

        public override void SetNetData(swm.MapEntityData _data)
        {
            if(null != _data.resource_data)
            {
                m_GatherData.baseid = _data.resource_data.Value.baseid;
                m_GatherData.colstate = _data.resource_data.Value.state;

            }
            OnAvatarLoaded.AddListener(onAvatarLoaded);

            base.SetNetData(_data);
        }

        public override void init()
        {
            base.init();
            m_GatherResourceConfig = ResourceTableManager.GetData((int)BaseID);
        }

        public override void LoadModel(string modelpath = null)
        {
            if (string.IsNullOrEmpty(modelpath))
            {
                //m_NpcConfig = NpcTableManager.GetData((int)(m_data.baseid));
                if (m_GatherResourceConfig != null && !string.IsNullOrEmpty(m_GatherResourceConfig.Value.model) && m_GatherResourceConfig.Value.model != m_currentModelPath)
                {
                    //ReleaseStateMachine();
                    //AvatarLoadModel(IResourceLoader.strResourcePath, m_GatherResourceConfig.Value.model, false);
                    AvatarLoadModel(IResourceLoader.strResourcePath, m_GatherResourceConfig.Value.model, !SyncLoad);
                    Actived = true;
                    m_currentModelPath = m_GatherResourceConfig.Value.model;
                    //Entity_Type = x2m.EntityType.ENTITY_NPC;
                }
            }
            else if (m_currentModelPath != modelpath)
            {
                //ReleaseStateMachine();
                //AvatarLoadModel(IResourceLoader.strResourcePath, modelpath, false);
                AvatarLoadModel(IResourceLoader.strResourcePath, modelpath, !SyncLoad);
                m_currentModelPath = modelpath;
                Actived = true;
            }

            Visible = Visible;
        }

        protected override void OnAvatarCreateDelegate()
        {
            base.OnAvatarCreateDelegate();

            if (m_headBillboard != null)
                m_headBillboard.Init(this);

            RefreshBornEffect();
            LoadStayEff();
        }

        public override void OnAddToScene()
        {
            base.OnAddToScene();

            m_headBillboard = new HeadBillboard();
            m_headBillboard.Init(this);
        }

        public void RefreshResourceMissionStateChange(byte _state)
        {
            OnRefreshResourceMissionState.Invoke(_state);
            if (CanMainCharGather())
            {
                if (Avatar != null && Avatar.unityObject != null && Visible)
                {
                    if (m_cangathereff == null && m_GatherResourceConfig.Value.active_showLength == 2)
                    {
                        m_cangathereff = EffectMgr.Instance.Play(m_GatherResourceConfig.Value.active_show(0), this, AvatarAttachment.Root, IResourceLoader.strSceneEffectPath, false, float.Parse(m_GatherResourceConfig.Value.active_show(1)));
                        m_cangathereff.Visible = ActuallyVisible;
                    }
                }
            }
            else
            {
                if (m_cangathereff != null)
                {
                    m_cangathereff.Stop();
                    m_cangathereff = null;
                }
            }
        }

        protected override void CreateStateMachine()
        {
            m_sm = SM.Factory.CreateSM(this);
        }

        protected override void ReleaseStateMachine()
        {
            SM.Factory.ReleaseMovableEntitySM(m_sm);
            m_sm = null;
        }

        public override void OnRemoveFromScene()
        {
            base.OnRemoveFromScene();
            if(null != m_headBillboard)
            {
                m_headBillboard.Dispose();
                m_headBillboard = null;
            }
        }

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public override void ResetEntity()
        {
            base.ResetEntity();
            m_GatherResourceConfig = null;
            m_GatherData = new GatherResource();
            m_currentModelPath = string.Empty;
            m_taskState = swm.TaskNpcState.None;
        }

        /// <summary>
        /// 是否可采集
        /// </summary>
        /// <returns></returns>
        public bool CanGather()
        {
            return (m_GatherData.colstate == (uint)swm.ResourceCollectionState.Collection);
        }

        private void onAvatarLoaded()
        {
            TreasureMapMgr.Instance.FilterEntity(this);
            if (CanMainCharGather())
            {
                if (Avatar != null && Avatar.unityObject != null && Visible)
                {
                    if (m_cangathereff == null && m_GatherResourceConfig.Value.active_showLength == 2)
                    {
                        m_cangathereff = EffectMgr.Instance.Play(m_GatherResourceConfig.Value.active_show(0), this, AvatarAttachment.Root, IResourceLoader.strSceneEffectPath, false, float.Parse(m_GatherResourceConfig.Value.active_show(1)));
                        m_cangathereff.Visible = ActuallyVisible;
                    }
                }
            }
            else
            {
                if (m_cangathereff != null)
                {
                    m_cangathereff.Stop();
                    m_cangathereff = null;
                }
            }
        }

        [XLua.BlackList]
        public void RefreshCollectionState(uint colstate)
        {
            uint oldstate = m_GatherData.colstate;
            m_GatherData.colstate = colstate;

            // 状态发生改变的时候才播放动画和特效
            if (oldstate != colstate)
            {
                RefreshStateEffect();
            }

            if (CanMainCharGather())
            {
                if (Avatar != null && Avatar.unityObject != null && Visible)
                {
                    if (m_cangathereff == null && m_GatherResourceConfig.Value.active_showLength == 2)
                        m_cangathereff = EffectMgr.Instance.Play(m_GatherResourceConfig.Value.active_show(0), this, AvatarAttachment.Root, IResourceLoader.strSceneEffectPath, false, float.Parse(m_GatherResourceConfig.Value.active_show(1)));
                }
            }
            else
            {
                if (m_cangathereff != null)
                {
                    m_cangathereff.Stop();
                    m_cangathereff = null;
                }
            }

            m_onRefreshCollectionState.Invoke(colstate);
            m_onChangeResourceState.Invoke(this);
        }

        private void RefreshStateEffect(bool playeffect = true)
        {
            if (!IsUnCol2CanColState())
                return;

            string effectname = "";
            if (m_GatherData.colstate == (uint)swm.ResourceCollectionState.Collection)
            {
                CrossFadeAll(Animator.StringToHash(CanGatherAnimName), 0.1f, 0, false);

                if (m_GatherResourceConfig.HasValue)
                {
                    effectname = m_GatherResourceConfig.Value.cangather_eff;
                }
            }
            else if (m_GatherData.colstate == (uint)swm.ResourceCollectionState.NoCollection)
            {
                CrossFadeAll(Animator.StringToHash(UnGatherAnimName), 0.1f, 0, false);

                if (m_GatherResourceConfig.HasValue)
                {
                    effectname = m_GatherResourceConfig.Value.ungather_eff;
                }
            }

            //播放变身特效(临时效果)
            if (playeffect)
            {
                if (Avatar != null && Avatar.unityObject != null)
                {
                    EffectMgr.Instance.Play(effectname, Avatar.unityObject.transform.position, null, true);
                }
            }
        }

        private void LoadStayEff()
        {
            string effectname = "";
            if (m_GatherResourceConfig.HasValue)
            {
                effectname = m_GatherResourceConfig.Value.stay_eff;
            }

            if (effectname.Length <= 0)
                return;

            if (Avatar != null && Avatar.unityObject != null && Visible)
            {
                m_stayeff = EffectMgr.Instance.Play(effectname, this, AvatarAttachment.Root, IResourceLoader.strSceneEffectPath, false);
                m_stayeff.Visible = ActuallyVisible;
            }
        }

        private void RefreshBornEffect()
        {
            if (IsDisappear2BornState())
            {

            }
            else if (IsUnCol2CanColState())
            {
                RefreshStateEffect(false);
            }
        }

        private void RefreshDeadEffect()
        {
            if (!IsDisappear2BornState())
                return;

            //CrossFadeAll(Animator.StringToHash(DisappearAnimName), 0.1f, 0, false);

            //播放变身特效
            //if (m_GatherResourceConfig.HasValue)
            //{
            //    string effectname = m_GatherResourceConfig.Value.ungather_eff;

            //    if (Avatar.unityObject != null)
            //    {
            //        EffectMgr.Instance.Play(effectname, Avatar.unityObject.transform.position, null, true);
            //    }
            //}
        }

        [XLua.BlackList]
        public bool IsEntityClose(Entity entity)
        {
            if (entity.Died)
                return false;

            if (!m_GatherResourceConfig.HasValue)
                return false;

            double sqrClose = m_GatherResourceConfig.Value.close_dis;
            sqrClose = sqrClose * sqrClose;

            float sqrDis = (entity.Position - Position).sqrMagnitude;
            if (sqrDis < sqrClose)
                return true;

            return false;
        }

        /// <summary>
        /// 是否从无到有状态
        /// </summary>
        /// <returns></returns>
        private bool IsDisappear2BornState()
        {
            if (!m_GatherResourceConfig.HasValue)
                return false;

            return m_GatherResourceConfig.Value.resourcetype == (int)swm.ResourceType.Normal;
        }

        private bool IsUnCol2CanColState()
        {
            if (!m_GatherResourceConfig.HasValue)
                return false;

            return m_GatherResourceConfig.Value.resourcetype == (int)swm.ResourceType.Forever;
        }

        private bool CanMainCharGather()
        {
            if (m_GatherResourceConfig.Value.defaultstate == 1)
            {
                return true;
            }

            if (m_GatherResourceConfig.Value.type == 0)
            {
                bool b = MissionModel.Instance.CheckIsHasResourceStateByBaseId(BaseID);
                if (!b)
                {
                    return b;
                }

                return CanGather();
            }
            else if (m_GatherResourceConfig.Value.type == 1)
            {
                var gatherType = (swm.GatheringProfessionType)m_GatherResourceConfig.Value.need_type;
                int currentGatherId = (int)LifeSkillModel.Instance.GetCurrentGatheringDataIdByType(gatherType);
                if (currentGatherId == 0)
                {
                    return false;
                }

                var configCollectBase = LifeSkillModel.Instance.GetCollectTableData(gatherType, currentGatherId);
                if (configCollectBase.Value.gather_level < m_GatherResourceConfig.Value.need_level)
                {
                    return false;
                }

                var equip = BagManager.Instance.GetEquipPageItemByEnum(swm.EquipSlot.PROFGATHER);
                if (equip == null)
                {
                    return false;
                }

                return true;
            }
            else if (m_GatherResourceConfig.Value.type == 2)
            {
                var b = MissionModel.Instance.CheckIsHasResourceStateByBaseId(BaseID);
                return b;
            }
            return false;
        }
    }
}
