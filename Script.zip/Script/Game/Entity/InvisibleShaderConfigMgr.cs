﻿using LitJson;
using System;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 
    /// </summary>
	public class InvisibleShaderConfigMgr : ClientSingleton<InvisibleShaderConfigMgr>
    {
        private Dictionary<string, Shader> m_InvisibleConfigDic = null;
        
        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {
            m_InvisibleConfigDic = null;
        }
        
        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
        {
            //touchpoints.Clear();
            string strData = TableManager.LoadFileTable("InvisibleShaderConfig.json", "/Datas/");
            if (string.IsNullOrEmpty(strData))
            {
                return;
            }
            // parse json
            JsonData jsonData;
            try
            {
                jsonData = JsonMapper.ToObject(strData);
                int tCount = jsonData.Count;
                if (tCount > 0)
                {
                    m_InvisibleConfigDic = new Dictionary<string, Shader>();
                    for (int tIdx = 0; tIdx < tCount; tIdx++)
                    {
                        JsonData tSubData = jsonData[tIdx];
                        InvisibleConfig tConfig = JsonMapper.ToObject<InvisibleConfig>(tSubData.ToJson());
                        
                        Shader sd = ResourceHelper.LoadShaderSync(
                            "Shaders/Character/Invisiable/", tConfig.invisibleShaderName) as Shader;

                        //缓存到字典
                        for (int i = 0; i < tConfig.orgShaderNames.Length; i++)
                        {
                            m_InvisibleConfigDic.Add(tConfig.orgShaderNames[i],
                                sd);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Bokura.LogHelper.LogError("Error occurred when parsing json table InvisibleShaderConfig.json : " + e.ToString());
                return;
            }
        }


        public Shader MatchShaderVsb(string orgShderName)
        {
            if (m_InvisibleConfigDic == null)
                return null;

            if (m_InvisibleConfigDic.ContainsKey(orgShderName))
            {
                return m_InvisibleConfigDic[orgShderName];
            }

            return m_InvisibleConfigDic["Default"];
        }
    }

    /// <summary>
    /// 隐身shader映射配置
    /// </summary>
    [System.Serializable]
    public struct InvisibleConfig
    {
        public string invisibleShaderName;
        public string[] orgShaderNames;
    }
}
