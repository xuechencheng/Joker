using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class JoystickController
    {
        private MainCharacter Owner = null;
        public JoystickController(MainCharacter owner)
        {
            Owner = owner;
        }
        protected Vector3 Position { get { return Owner.Position; } }
        private Vector3 m_joystickDir = Vector3.zero;
        public Vector3 JoystickDir { get { return m_joystickDir; }set { m_joystickDir = value; } }


        public void JoystickMoveTo(Vector3 jsdir, bool onlyupdown = false)
        {
            if (ICameraHelper.Instance.isFreeMode)
                return;
            if (Owner.CheckCantControl() || Owner.Died )
                return;

			//停止自动寻路
			if (Owner.IsInFindingPath)
				Owner.Stop();

            if (null == GameScene.Instance.MainCamera)
            {
                return;
            }

            // 在家园编辑模式不能移动
            bool homeinedit = HomeModel.Instance.IsEditMode();
            if (homeinedit)
                return;

            var septmodel = SociatyManager.Instance;
            if (septmodel != null)
            {
                // 在建筑物顶视角查看模式不播放特效
                if (septmodel.buildingTopViewMode)
                    return;
            }

            Vector3 worlddir;
            var ldir = new Vector3(jsdir.x, 0, -jsdir.y);
            worlddir = GameScene.Instance.MainCamera.cameraToWorldMatrix.MultiplyVector(ldir);

           if(!Owner.Mount || !Owner.Mount.IsAirMount) worlddir.y = 0;

            worlddir.Normalize();
            worlddir *= Owner.speed * (1.5f + ServersManager.Instance.RTT / 1000.0f);
            //m_lastJoystickDir = worlddir;
            if(!onlyupdown) Owner.MoveByJoyStick = true;

           
            float y_move = Owner.NeedFlyUp ?( Owner.speed * 1.5f ) : 0;
            y_move -= Owner.NeedFlyDown ? (Owner.speed * 1.5f ) : 0;

            if (Mathf.Abs(y_move) < float.Epsilon)
            {
                y_move += Owner.IsCloudFlyUp ? (Owner.speed * 1.5f) : 0;
                y_move -= Owner.IsCloudFlyDown ? (Owner.speed * 1.5f) : 0;
            }
                

            RaycastHit hit;
            var src = Owner.LocalPosition + Vector3.up * 0.6f;
            if (Utilities.RayCast(src, worlddir, out hit, worlddir.magnitude, (int)UserLayerMask.AllBlock, QueryTriggerInteraction.Ignore))
            {
                var dir = (hit.point - src) * 0.8f;

                dir.y += y_move;
                Owner.MoveObstacle = true;
                Owner.MoveTo(Position + dir);         
            }
            else
            {
                worlddir.y += y_move;
                Owner.MoveObstacle = false;
                Owner.MoveTo(Position + worlddir);
                //LogHelper.LogFormat("moveto {0} {1}", Position, Position + worlddir);
            }
            
        }
        public void JoystickRefreshMove(Vector3 jsdir)
        {
            if (null == GameScene.Instance.MainCamera)
            {
                return;
            }
            if (Owner.CheckCantControl() || Owner.Died )
                return;

            var ldir = new Vector3(jsdir.x, 0, -jsdir.y);

            Vector3 worlddir = GameScene.Instance.MainCamera.cameraToWorldMatrix.MultiplyVector(ldir);
            worlddir.y = 0;
            worlddir.Normalize();
            m_joystickDir = worlddir;
            Owner.MoveByJoyStick = true;

        }
        public void JoystickMoveStop()
        {
            Owner.Stop();
            m_joystickDir = Vector3.zero;
        }
        /*
        [XLua.BlackList]
        public void ServerMoveTo(swm.MoveToDown msg)
        {
            if (GameScene.Instance.GetServerTime() < msg.serv_time)
            {
                return;
            }
            //预测服务器当前坐标
            var dir = msg.to_pos.FBVec3Vec3() - msg.cur_pos.FBVec3Vec3(); dir.y = 0;
            var dt = (GameScene.Instance.GetServerTime() - msg.serv_time) / 1000.0f;
            var spos = msg.cur_pos.FBVec3Vec3() + dir.normalized * dt * Owner.speed;


            
            //校正角色移动速度
            var mpos = Owner.Position; mpos.y = 0;
            var pos = spos; pos.y = 0;
            var destPos = msg.to_pos.FBVec3Vec3();destPos.y = 0;
            var sdir = destPos - pos;
            var cdir = destPos - mpos;
            float projection = Vector3.Dot(sdir, cdir) / sdir.magnitude;
            projection = projection < 0 ? 0 : projection;
            var adjustspeed = (projection < 0.5f || sdir.magnitude < 0.5f) ? Owner.speed : (projection / sdir.magnitude * Owner.speed);
            //Owner.RealPosition = pos;
            Owner.AdjustTargetSpeed = adjustspeed;


#if !REALEASE
            if( GameApplication.ShowTestCube)
            {
                GameScene.GetTempCube(10, spos, Color.black);
                GameScene.GetTempCube(1, msg.cur_pos.FBVec3Vec3(), Color.cyan);
                GameScene.GetTempCube(2, msg.to_pos.FBVec3Vec3(), Color.green);
            }
#endif
        }
        */
        [XLua.BlackList]
        public void ServerFallStart(swm.FallStart msg)
        {
            if (Owner.StateMachine != null && (Owner.StateMachine.CurStateID == SM.Entity.States.ATTACK || Owner.IsQingKung()))
                return;
            var endpos = msg.end_pos.FBVec3Vec3() + new Vector3(0, 0.25f, 0);//加半个体素边长
            var dir = endpos - msg.fall_pos.FBVec3Vec3();
            if (msg.rest_time > 0 && dir.y < 0 && dir.magnitude > 3)
            {
                if (Owner.Position.y - endpos.y > 3 && !Owner.isCurrCloudState())
                {
                    Vector3 adjustpos = Vector3.zero;
                    if (AdjustLandPos(endpos, out adjustpos))
                    {
                        Owner.CC.enabled = false;
                        Owner.FallDestPos = adjustpos;

                        if (GameApplication.ShowTestCube)
                            GameScene.GetTempCube(123, Owner.FallDestPos, Color.black);

                    }
                }

            }

        }
        protected bool AdjustLandPos(Vector3 landpos,out Vector3 adjustpos)
        {
            landpos += new Vector3(0, 0.5f, 0);//加半个体素边长
            var unity_land_pos = landpos - LayeredSceneLoader.WorldOffset;
            RaycastHit hit;
            if (Utilities.RayCast(unity_land_pos, Vector3.down, out hit, 2, (int)UserLayerMask.AllBlock))
            {
                var hitpos = hit.point + LayeredSceneLoader.WorldOffset;
                if (Mathf.Abs(hitpos.y - landpos.y) > 1f)
                {
                    LogHelper.LogErrorFormat("服务器体素数据与客户端碰撞误差超过0.5f，请检查是否是最新bake数据。体素坐标:{0} 碰撞位置:{1}", landpos - new Vector3(0, 0.5f, 0), hitpos);
                    adjustpos = landpos;
                    return false;
                }
                else
                {
                    adjustpos = hitpos;
                    return true;
                }
            }
            else
            {
                adjustpos = landpos;
                return true;
            }
        }
        [XLua.BlackList]
        public void ServerFallMove(swm.FallMove msg)
        {
            var endpos = msg.end_pos.FBVec3Vec3() + new Vector3(0, 0.25f, 0);
            Vector3 adjustpos = Vector3.zero;
            if (AdjustLandPos(endpos, out adjustpos))
            {
                Owner.FallDestPos = adjustpos;

                if (GameApplication.ShowTestCube)
                    GameScene.GetTempCube(123, Owner.FallDestPos, Color.black);

            }

        }

        [XLua.BlackList]
        public bool IsCanRotState()
        {
            if (Owner == null || Owner.StateMachine == null)
                return false;
            if (Owner.StateMachine.CurStateID == SM.Entity.States.ATTACK ||
                Owner.StateMachine.CurStateID == SM.Entity.States.QingKungFall ||
                Owner.StateMachine.CurStateID == SM.Entity.States.QingKungEnter   )
                return false;
            return true;
        }

        private float m_lasttimemoveto = 0;

        [XLua.BlackList]
        public void Update()
        {
            cloudUpdateInput();

            if (!Owner.MoveByJoyStick && 
                (Owner.NeedFlyUp || Owner.NeedFlyDown) && 
                Time.realtimeSinceStartup - m_lasttimemoveto > 0.1f &&
                Owner.Mount && Owner.Mount.IsAirMount 
                )
            {
                JoystickMoveTo(Vector3.zero,true);
                m_lasttimemoveto = Time.realtimeSinceStartup;
            }

            if (Owner.IsInFindingPath) //自动寻路
            {
                var dir = Owner.DestPos - Owner.Position;
                dir.y = 0;
                dir.Normalize();
                if (dir.magnitude > 0.0f)
                    Owner.Direction = dir;


                var cdir = CameraController.Instance.Direction;
                cdir.y = 0; cdir.Normalize();
                var mdir = Owner.Direction;
                mdir.y = 0; mdir.Normalize();
                float detla = Vector3.Angle(cdir, mdir);
                Vector3 normal = Vector3.Cross(cdir, mdir);
                bool findpathadjust = SysSettingModel.Instance.sharedData.bCameraFindPathAdjust && Owner.IsInFindingPath && !TargetSelector.Instance.IsLocking;
                if (findpathadjust)
                {
                    if (detla > 1)
                    {
                        float ry = CameraController.Instance.RotateY;
                        float iRotateAngleX = 2f * Time.deltaTime * 30;
                        float rx = CameraController.Instance.RotateX + Mathf.Sign(normal.y) * (iRotateAngleX > detla ? detla : iRotateAngleX);
                        CameraController.Instance.AnimRotateTo(rx, ry, 5f,true);
                    }
                }
            }else if (IsCanRotState())
            {
                /*
                m_joystickDir.y = 0;
                float angle = Vector3.Angle(Owner.Direction, m_joystickDir);
                Vector3 c = Vector3.Cross(Owner.Direction, m_joystickDir);
                float sign = Mathf.Sign(c.y);
                //操作镜头时，旋转调慢一点，使其平滑
                float CameraRotation = ICrossPlatformInputManager.Instance.GetAxis(IVirtualInput.CameraHorizontalAxisName);
                bool isOperCamera = CameraRotation != 0;
                float threshold = isOperCamera ? 3 : (Owner.IsQingKung() ? 1 : 10);
                //LogHelper.Log("camera :", angle.ToString(), " isOperCamera :", isOperCamera.ToString());
                //坐骑上的转在movestate里处理
                if (!Owner.Mount)
                {
                    if (angle > threshold && Owner.StateMachine.CurStateID != SM.Entity.States.ATTACK)
                    {
                        Owner.DirAngle += sign * threshold;
                    }
                    else
                    {
                        Owner.Direction = m_joystickDir;
                    }
                }
                */

                //移动时摄像机自动校正
                bool moveadjust = SysSettingModel.Instance.sharedData.bCameraMoveAdjust && Owner.MoveByJoyStick && !TargetSelector.Instance.IsLocking;
                moveadjust = moveadjust && Owner.StateMachine.CurStateID == SM.Entity.States.MOVE && Owner.StateMachine.CurStateDuration > 0.1f;
                if (moveadjust)
                {
                    var cdir = CameraController.Instance.Direction;
                    cdir.y = 0; cdir.Normalize();
                    var mdir = Owner.Direction;
                    mdir.y = 0; mdir.Normalize();
                    float detla = Vector3.Angle(cdir, mdir);

                    if (detla > 30)
                    {
                        Vector3 normal = Vector3.Cross(cdir, mdir);
                        float ry = CameraController.Instance.RotateY;
                        float rx = CameraController.Instance.RotateX + Mathf.Sign(normal.y) * 2f;
                        CameraController.Instance.AnimRotateTo(rx, ry, 1.5f,true);
                    }
                }
            }

        }

        private void cloudUpdateInput()
        {
            if (Owner.isCurrInCloud())
            {
                //float x = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraHorizontalAxis);
                float y = ICrossPlatformInputManager.Instance.GetAxis(InputVirtualAxis.CameraVerticalAxis);

                if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
                {
                    if (Input.touchCount >= 2)
                    {
                        int index = 0;
                        bool isHaveFinger = false;
                        for (int i = 0; i < Input.touchCount; i++)
                        {
                            if (!UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject(Input.GetTouch(i).fingerId))
                            {
                                index = i;
                                isHaveFinger = true;
                                break;
                            }
                        }

                        if (isHaveFinger)
                        {

                            if (Input.GetTouch(index).phase == TouchPhase.Canceled || Input.GetTouch(index).phase == TouchPhase.Ended)
                            {
                                Owner.IsCloudFlyUp = false;
                                Owner.IsCloudFlyDown = false;
                            }
                            else if (Input.GetTouch(index).phase == TouchPhase.Moved)
                            {
                                if (Owner.isEnterFly)
                                {
                                    if (y > 0)
                                    {
                                        Owner.IsCloudFlyUp = true;
                                        Owner.IsCloudFlyDown = false;
                                    }
                                    else if (y < 0)
                                    {
                                        Owner.IsCloudFlyUp = false;
                                        Owner.IsCloudFlyDown = true;
                                    }
                                }
                                else
                                {
                                    Owner.IsCloudFlyUp = false;
                                    Owner.IsCloudFlyDown = false;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (Input.GetMouseButtonUp(1))
                    {
                        Owner.IsCloudFlyUp = false;
                        Owner.IsCloudFlyDown = false;
                    }
                    else if (Input.GetMouseButton(1))
                    {
                        if (Owner.isEnterFly)
                        {
                            if (y > 0)
                            {
                                Owner.IsCloudFlyUp = true;
                                Owner.IsCloudFlyDown = false;
                            }
                            else if (y < 0)
                            {
                                Owner.IsCloudFlyUp = false;
                                Owner.IsCloudFlyDown = true;
                            }
                        }
                        else
                        {
                            Owner.IsCloudFlyUp = false;
                            Owner.IsCloudFlyDown = false;
                        }
                    }
                }
            }
        }
    }
}
