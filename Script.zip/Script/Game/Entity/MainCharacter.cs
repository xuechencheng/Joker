using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using Bokura;

namespace Bokura
{
    public class SnakePosParam
    {
        public Vector3 m_pos;
    }

    public class MainCharacter : Character
    {

        #region 常量


        ///// <summary>
        ///// 检测npc说话距离
        ///// </summary>
        //private const float CheckNpcSpeakDistance = 3.0f;

        /// <summary>
        /// 检测npc躲避距离
        /// </summary>
        private const float CheckNpcDodgeDistance = 0.5f;

        #endregion

        private Transform m_HeadBone = null;
        public Vector3 HeadPostition { get { return m_HeadBone != null ? m_HeadBone.position.UnityToWorldVec() : (Position + new Vector3(0, 2, 0)); } }
        private bool m_bIsInited = false;
        IPathAgent m_pathAgent;

        private ulong m_CurrentCloseEntityId = 0;
        public ulong CurrentCloseEntityId
        {
            get
            {
                return m_CurrentCloseEntityId;
            }
            set
            {
                m_CurrentCloseEntityId = value;
            }
        }

        bool m_syncOrientBreak;
        public static int SnakeMaxNumber = 20;
        private List<SnakePosParam> m_snakePosList = null;
        protected Vector3 m_realPosition = Vector3.zero;

        private JoystickController m_joystick;
        public JoystickController Joystick { get { return m_joystick; } }

        protected swm.MapEntityAttrsT m_attrs = new swm.MapEntityAttrsT();

        bool m_moveobstacle = false; //移动时检测到障碍物
        public bool MoveObstacle { get { return m_moveobstacle; } set { m_moveobstacle = value; } }

        /// <summary>
        /// 是否在战场中
        /// </summary>
        public bool IsInBattleField { get { return BattleFieldManager.Instance.isInBattleField; } }
        private uint m_enterInteractionGroupId = 0;
        /// <summary>
        /// 进入交互区域
        /// </summary>
        public uint enterInteractionGroupId
        {
            get { return m_enterInteractionGroupId; }
            set { m_enterInteractionGroupId = value; }
        }

        private bool m_IsInFindingPath = false;
		/// <summary>
		/// 正在自动寻路中...
		/// </summary>
		public bool IsInFindingPath { get { return m_IsInFindingPath; } }

        /// <summary>
        /// Is camera automatically adjust view when attack
        /// </summary>
        private bool m_bISAttackRotateCamOn = false;
        public bool ISAttackRotateCamOn { get { return m_bISAttackRotateCamOn; } set { m_bISAttackRotateCamOn = value; } }

        /// <summary>
        /// 检测npc的上一次移动位置
        /// </summary>
        private Vector3 m_lastMovePosByCheckNpc = Vector3.zero;

        public EntityOutSyncer OutSyncer { get { return Syncer as EntityOutSyncer; } }

		private GameEvent<bool> m_OnFindPathStateChanged = new GameEvent<bool>();
		/// <summary>
		/// 寻路状态改变：开始/停止
		/// </summary>
		public GameEvent<bool> onFindPathStateChanged { get { return m_OnFindPathStateChanged; } }

        public GameEvent onMoveEvent = new GameEvent();

		private GameEvent<bool> m_OnAutoAttackStateChanged = new GameEvent<bool>();
		/// <summary>
		/// 自动战斗状态改变：开始/停止
		/// </summary>
		public GameEvent<bool> onAutoAttackStateChanged { get { return m_OnAutoAttackStateChanged; } }

        private GameEvent<ulong, Entity> m_OnCloseEntityChanged = new GameEvent<ulong, Entity>();
        /// <summary>
        /// 采集状态改变：开始/停止
        /// </summary>
        public GameEvent<ulong, Entity> OnCloseGatherIdChanged { get { return m_OnCloseEntityChanged; } }

        LoadCallback m_onCameraConfigLoad;

        public GameEvent<int, int> OnQingKungEnergyChanged = new GameEvent<int, int>();

        public GameEvent OnLeaveIdleMove = new GameEvent();
        public GameEvent OnEnterIdleMove = new GameEvent();

        /// <summary>
        /// 移动摇杆事件
        /// </summary>
        public GameEvent<bool> onMoveByJoyStickEvent = new GameEvent<bool>();

        public GameEvent OnRefreshVehicleEvent = new GameEvent();

        //static public Event<SM.Entity.States, SM.Entity.States> OnMainCharPostStateChange = new Event<SM.Entity.States, SM.Entity.States>();
		
        /// <summary>
		/// 自动寻路状态变化
		/// </summary>
        private void FindPathStateEventChanged(bool start)
        {
			if (IsInFindingPath != start)
			{
				m_IsInFindingPath = start;
				onFindPathStateChanged.Invoke(start);
			}
		}

        public MainCharacter(ulong id):base(id)
        {
            m_avatar.DontDestoryOnLoad();
            m_avatar.shadowType = AvatarShadowType.Unique;

            m_pathAgent = IPathAgent.Instance;
			m_layer = (Int32)UserLayer.Layer_MainCharacter;

            m_onCameraConfigLoad = this.OnCameraConfigLoad;

			m_skillMgr = SkillManager.Instance;
			m_skillMgr.SetMainCharacter(this);

            m_joystick = new JoystickController(this);

            LayeredSceneLoader.OnWorldMove.AddListener(WorldMove);
			onMainCharacterDied.AddListener(OnMainCharactorDie);

			AutoPathFinder.Instance.Init(MoveByPathFind, ProcBlinkFinishedFuc);
			AutoAttackManager.Instance.SetMainChar(this);
            TeamModel.Instance.SetMainChar(this);

            CameraController.Instance.OnMainCameraDitanceChanged.AddListener(CameraDitanceChanged);
            CameraController.Instance.OnPlayerActiveRotate.AddListener(CameraRotateChanged);
            GameScene.Instance.onGameStateChange.AddListener((prev, next) => { if (next < GameState.InGame) RemoveAllEffects(); });

            SkillManager.Instance.OnCastSkillBegin.AddListener(OnAttackCameraRotate);
        }

        private bool m_bIsBlinkFinishedWaitIdle = false;//跳转等待idle落地
        private int m_CalcBlinkState = 0;
        private bool ProcBlinkFinishedFuc()
        {
            if(CheckIsOnGroundIdle())
            {
                AutoPathFinder.Instance.MoveToStop();
                m_bIsBlinkFinishedWaitIdle = false;
                m_CalcBlinkState = 0;
            }
            else
            {
                m_bIsBlinkFinishedWaitIdle = true;
                m_CalcBlinkState = 0;
            }
            return true;
        }

        public bool CheckIsOnGroundIdle()
        {
            return (StateMachine.CurStateID == SM.Entity.States.IDLE || 
                StateMachine.CurStateID == SM.Entity.States.ATTACK_IDLE ||
                StateMachine.CurStateID == SM.Entity.States.EMOTE ||
                StateMachine.CurStateID == SM.Entity.States.CarryStage ||
                StateMachine.CurStateID == SM.Entity.States.RIDE) && IsOnCloudGround();
        }
        ~MainCharacter()
        {
            LayeredSceneLoader.OnWorldMove.RemoveListener(WorldMove);
        }
        public bool IsInited
        {
            get
            {
                return m_bIsInited;
            }
        }

        public bool MainCharNetDataSetted = false;
		public swm.MapEntityAttrsT Attrs
		{
			get
			{
				return m_attrs;
			}

			set
			{
				m_attrs = value;
				//if(m_attrs.move_speed!=0)
				//	speed = m_attrs.move_speed;
			}
		}
        public List<SnakePosParam> SnakePosList
        {
            get
            {
                return m_snakePosList;
            }
        }

        public override Vector3 Direction
		{
			get
			{
				return base.Direction;
			}

			set
			{
				base.Direction = value;
				Joystick.JoystickDir = base.Direction;
			}
		}

		public bool SyncOrientBreak
		{
			get
			{
				return m_syncOrientBreak;
			}
			set
			{
				m_syncOrientBreak = value;
			}
		}

		SkillManager m_skillMgr;
		public SkillManager SkillMgr
		{
			get
			{
				return m_skillMgr;
			}
		}

        int m_pendingSkill = 0;
        public int PendingSkill
        {
            set
            {
                //LogHelper.Log("set pendingskill", value.ToString());
                m_pendingSkill = value;
            }
            get
            {
                return m_pendingSkill;
            }
        }

        public override bool IsTurn
        {
            get
            {
                return Joystick.JoystickDir != Direction;
                //return m_joystickDir != Direction;
            }
        }
        bool m_CanControl = true;
		/// <summary>
		/// 可以控制移动
		/// </summary>
		public bool CanControl
		{
			get { return m_CanControl; }
			set
			{
                //LogHelper.LogError("canControl " + value);
				if(m_CanControl!=value)
				{
					m_CanControl = value;
					OnCanControlChange.Invoke(value);
				}
				
			}
		}
        private bool m_CanJump = true;
        /// <summary>
        /// 可以跳跃或轻功
        /// </summary>
        public bool canJump
        {
            get { return m_CanJump; }
            set { m_CanJump = value; }
        }
        float m_flyJumpCD = 0.0f;
        public float FlyJumpCD
        {
            set
            {
                m_flyJumpCD = value;
            }
            get
            {
                return m_flyJumpCD;
            }
        }

        public IPathAgent PathAgent
        {
            get
            {
                return m_pathAgent;
            }
        }
		private bool m_MoveByJoyStick = false;
		/// <summary>
		/// 当前是否由摇杆控制移动中
		/// </summary>
		public bool MoveByJoyStick
        {
            get { return m_MoveByJoyStick; }
			set
            {
                m_MoveByJoyStick = value;

                onMoveByJoyStickEvent.Invoke(m_MoveByJoyStick);
            }
        }

        public Event<bool> OnCanControlChange = new Event<bool>();

        public override void Release()
        {
            EntityEffectTextManager.Instance.DestoryAllEntityTextEffect(this);
            setMotion(0, 0);
            OutSyncer?.StopSyncMove();
            ReleaseMount(true);
            m_bIsBlinkFinishedWaitIdle = false;
            m_CalcBlinkState = 0;
        }

        public void ReleaseMainCharacter()//释放主角 调用这个接口
        {
            ReleaseMount(true);
            base.Release();
        }
        protected override void ReleaseStateMachine()
        {
            SM.Factory.ReleaseMainCharacterSM(m_sm);
            m_sm = null;
        }

        public override void OnAddToScene()
		{
            if(!IsHasAvatarObject())
            {
                base.OnAddToScene();

            }
        }
        protected override void OnPkModeChange()
		{
			base.OnPkModeChange();
			var entitys = GameScene.Instance.GetTypeEntityList(swm.EntityType.Player);
			foreach(var v in entitys)
			{
				v.RefreshCanAttack();
			}
		}

        protected override void OnPositionChange()
        {
            base.OnPositionChange();

            CheckCloseNpc();
        }

        #region Message
        public override void Dodge()
        {
            if (Mount != null)
            {
                MountMgr.Instance.RequestDismount();
            }
            if (CheckCantControl())
                return;

            if (StateMachine.CurStateID == SM.Entity.States.DODGE && !CanContinueDodage)
                return;

            if (IsInInteractionPoint)
            {
                NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_OPERATE_LIMIT);
                return;
            }

            CanContinueDodage = false;
            var dir = Joystick.JoystickDir.magnitude > 0 ? Joystick.JoystickDir : Direction; //用joystock的方向会比较及时响应
            //发送闪避
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.RequestQuickDodge.StartRequestQuickDodge(fbb);
            swm.RequestQuickDodge.AddPos(fbb, Utility.Vec3FBVec3(fbb, Position));
            if (VoxelWorldID == 0)
                swm.RequestQuickDodge.AddDir(fbb, Utility.Vec3FBVec3(fbb, dir));
            else
            {
                var localdir = MobileBlockMgr.Instance.WorldDir2LocalDir(dir, VoxelWorldID);
                swm.RequestQuickDodge.AddDir(fbb, Utility.Vec3FBVec3(fbb, localdir));
            }
            fbb.Finish(swm.RequestQuickDodge.EndRequestQuickDodge(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.RequestQuickDodge.HashID, fbb);
        }
        protected void RequestQingKongEnd()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqQingKungEnd.StartReqQingKungEnd(fbb);
            var moveto = swm.ReqQingKungEnd.EndReqQingKungEnd(fbb);
            fbb.Finish(moveto.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqQingKungEnd.HashID, fbb);

        }
        public void RequestQingKongLand()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqQingKungFastLand.StartReqQingKungFastLand(fbb);
            swm.ReqQingKungFastLand.AddPos(fbb, swm.Vector3.CreateVector3(fbb, Position.x, Position.y, Position.z));
            swm.ReqQingKungFastLand.AddDir(fbb, swm.Vector3.CreateVector3(fbb, Direction.x, Direction.y, Direction.z));
            var moveto = swm.ReqQingKungFastLand.EndReqQingKungFastLand(fbb);
            fbb.Finish(moveto.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqQingKungFastLand.HashID, fbb);
        }

        public void ReqInteractionComplete_CS(uint interaction_id, uint action_id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var offset = swm.ReqInteractionComplete.CreateReqInteractionComplete(fbb, interaction_id, action_id);
            fbb.Finish(offset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqInteractionComplete.HashID, fbb);
        }

        public float StartQingKong(bool IsUp = false)
        {
            if (!canJump || IsInAttack) return -1;
            //GameScene.Instance.CurrentMapId
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null || mapinfo.noqingkung) return -1;
            if (CanContinueQingKung && m_curQingKungEnergy > 0)
            {
                VoxelWorldID = 0;
                var nextstep = StateMachine.CurStateID == SM.Entity.States.QingKungPeakStay ? QingKungStep.QingKungNone : QingKungStep;
                switch (QingKungStep)
                {
                    case QingKungStep.QingKungNone:
                        nextstep = (IsNeedMove() ? QingKungStep.QingKungMove : QingKungStep.QingKungSitu);
                        break;
                    case QingKungStep.QingKungMove:
                    case QingKungStep.QingKungSitu:
                    case QingKungStep.QingKungFour:
                    case QingKungStep.QingKungUp:
                    case QingKungStep.QingKungUp2:
                    case QingKungStep.QingKungGliding://滑翔
                        nextstep = QingKungStep.QingKungTwo;
                        break;
                    default:
                        nextstep = QingKungStep + 1;
                        break;
                }

                Stop();
                nextstep = IsUp ? QingKungStep.QingKungUp : nextstep;

                CanContinueQingKung = false;
                QingKungStep = nextstep;
                //if(StateMachine.CurStateID == SM.Entity.States.QingKungEnter)
                StateMachine.Resume(SM.Entity.States.QingKungEnter);
                

                Debug.Assert(nextstep > 0, string.Format("StartQingKong nextstep {0}", nextstep));
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqQingKung.StartReqQingKung(fbb);
                swm.ReqQingKung.AddPos(fbb, swm.Vector3.CreateVector3(fbb, Position.x, Position.y, Position.z));
                swm.ReqQingKung.AddDir(fbb, swm.Vector3.CreateVector3(fbb, Direction.x, Direction.y, Direction.z));
                swm.ReqQingKung.AddTime(fbb, GameScene.Instance.GetServerTime());
                swm.ReqQingKung.AddId(fbb, (uint)nextstep);
                var moveto = swm.ReqQingKung.EndReqQingKung(fbb);
                fbb.Finish(moveto.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqQingKung.HashID, fbb);

                var Data = QingKungTableManager.GetData((int)nextstep, (int)CareerType);
                if(Data.HasValue)
                {
                   return Data.Value.over_time;
                }
                return -1f;
            }
            return -1;
        }
        public void SendQingKungStartFall()
        {
            var dir = Direction.magnitude > 0.1f ? Direction : Avatar.GetDirection();

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqQingKungStartFall.StartReqQingKungStartFall(fbb);
            swm.ReqQingKungStartFall.AddCliPos(fbb, swm.Vector3.CreateVector3(fbb, Position.x, Position.y, Position.z));
            swm.ReqQingKungStartFall.AddCliDir(fbb, swm.Vector3.CreateVector3(fbb, dir.x, 0, dir.z));
            //swm.ReqQingKungStartFall.AddNormalizedtime(fbb, normalizeTime);
            swm.ReqQingKungStartFall.AddCliTime(fbb, GameScene.Instance.GetServerTime());
            //swm.ReqQingKungTurn.AddEntityId(fbb, ThisID);
            var moveto = swm.ReqQingKungStartFall.EndReqQingKungStartFall(fbb);
            fbb.Finish(moveto.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqQingKungStartFall.HashID, fbb);
        }
        private float m_LastSendQingKungMoveTime = 0;
        public void SendQingKungMove(ulong normalizeTime = 0)
        {

            m_LastSendQingKungMoveTime = Time.realtimeSinceStartup;
            if(IsQingKung() && StateMachine.CurStateID != SM.Entity.States.QingKungPeakStay)
            {

                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqQingKungTurn.StartReqQingKungTurn(fbb);
                swm.ReqQingKungTurn.AddPos(fbb, swm.Vector3.CreateVector3(fbb, Position.x, Position.y, Position.z));
                swm.ReqQingKungTurn.AddDir(fbb, swm.Vector3.CreateVector3(fbb, Direction.x, 0, Direction.z));
                swm.ReqQingKungTurn.AddNormalizedtime(fbb, normalizeTime);
                swm.ReqQingKungTurn.AddTime(fbb, GameScene.Instance.GetServerTime());
                swm.ReqQingKungTurn.AddEntityId(fbb, ThisID);
                var moveto = swm.ReqQingKungTurn.EndReqQingKungTurn(fbb);
                fbb.Finish(moveto.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqQingKungTurn.HashID, fbb);
                //LogHelper.Log("SendQingKungMove", Position.ToString());
            }
        }

        public void RequestQingKungPeak()
        {
            if (StateMachine.CurStateID == SM.Entity.States.QingKungPeakStay || StateMachine.CurStateID == SM.Entity.States.QingKungPeakStay) return;
            Vector3? tpos= QingKungTouchPointManager.Instance.GetNearTouchPoint();
            if(tpos.HasValue)
            {
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqQingKungPeak.StartReqQingKungPeak(fbb);
                swm.ReqQingKungPeak.AddCliPos(fbb, swm.Vector3.CreateVector3(fbb, Position.x, Position.y, Position.z));
                swm.ReqQingKungPeak.AddCliTime(fbb,GameScene.Instance.GetServerTime());
                swm.ReqQingKungPeak.AddTpos(fbb, swm.Vector3.CreateVector3(fbb, tpos.Value.x, tpos.Value.y, tpos.Value.z));
                var moveto = swm.ReqQingKungPeak.EndReqQingKungPeak(fbb);
                fbb.Finish(moveto.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqQingKungPeak.HashID, fbb);
            }
            //LogHelper.Log("RequestQingKungPeak ", tpos.HasValue.ToString());

        }
        public void SendQingKungDashBlock()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqQingKungBlockLand.StartReqQingKungBlockLand(fbb);
            var moveto = swm.ReqQingKungBlockLand.EndReqQingKungBlockLand(fbb);
            fbb.Finish(moveto.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqQingKungBlockLand.HashID, fbb);
        }

        // 滑翔转向;
        public void SendRequestGlidingTurnDir()
        {
            if (Time.realtimeSinceStartup - m_LastSendQingKungMoveTime < 0.1f)
                return;
            m_LastSendQingKungMoveTime = Time.realtimeSinceStartup;

            Vector3 destdir = DestPos - Position;
            destdir.y = 0.0f;

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.RequestGlidingTurnDir.StartRequestGlidingTurnDir(fbb);
            swm.RequestGlidingTurnDir.AddDir(fbb, swm.Vector3.CreateVector3(fbb, destdir.x, 0, destdir.z));
            var moveto = swm.RequestGlidingTurnDir.EndRequestGlidingTurnDir(fbb);
            fbb.Finish(moveto.Value);
            MsgDispatcher.instance.SendFBPackage(swm.RequestGlidingTurnDir.HashID, fbb);
        }
        #endregion

        public override int MoveTo(Vector3 p, OnMoveStopDelegate onstop=null)
		{
            onMoveEvent.Invoke();//这个要放上面  base.MoveTo可能会去调用stop的
            base.MoveTo(p , onstop);
            return 0;
		}

        public bool CheckCantControl()
		{
			if (SkillManager.Instance.forceAttack.Target)
				return true;
			return (!m_CanControl || (StateMachine!=null && (StateMachine.CurStateID == SM.Entity.States.STUN ))) ;
		}

        public override void OnJumpStart()
		{
			base.OnJumpStart();

            Vector3 to_pos, dir;
            //float z, x;
            //Bokura.Utilities.Angle2Vector2(DirAngle, out z, out x);
            if(IsNeedMove())
            {
                dir = (DestPos - Position);
                dir.y = 0;
                dir.Normalize();
                to_pos = DestPos;
                LastDestPos = DestPos;
            }
            else
            {
                dir = Vector3.zero;
                to_pos = Position + Vector3.up;
                LastDestPos = Position;
            }
            OutSyncer?.SendJumpMsg(VoxelWorldID, Position, to_pos,dir);
            //LogHelper.Log("OnJumpStart ", Position.ToString(), " ", to_pos.ToString());
        }
        public override void OnJumpStop()
		{
			base.OnJumpStop();
            LastDestPos = Position;
        }
		public override bool IsMainCharacter()
        {
            return true;
        }
        protected override void CreateEntitySyncer()
        {
            m_syncer = new EntityOutSyncer(this);
        }
        protected override void CreateStateMachine()
        {
            m_sm = SM.Factory.CreateSM(this);
            TargetSelector.Instance.onSelectTargetChange.AddListener(OnLockTargetChange);
        }
        public void OnLockTargetChange(Entity e)
        {
            //if (m_sm.CurStateID == SM.Entity.States.ATTACK)
            //{
            //    if (TargetSelector.Instance.Locked != null)
            //    {
            //        var v = TargetSelector.Instance.Locked.TargetSelNode.position - GameScene.Instance.MainChar.Billboard.transform.position;
            //        v.y = 0;
            //        v.Normalize();
            //        GameScene.Instance.MainChar.Direction = v;
            //        Joystick.JoystickDir = GameScene.Instance.MainChar.Direction;
            //    }
            //}
            if (TeamModel.Instance.CheckMainCharactorIsMaster())
            {
                TeamModel.Instance.SendForwardLeaderAttack(IsInAttack);                
            }
        }

        protected override void OnIsInAttackChange()
        {
            if (IsInAttack != m_oldIsInAttack)
            {
                base.OnIsInAttackChange();
            }

            if (IsInAttack)
                AudioCtrl.SetState("IsBattle", "true");
            else
                AudioCtrl.SetState("IsBattle", "");

            if (TeamModel.Instance.CheckMainCharactorIsMaster())
            {
                TeamModel.Instance.SendForwardLeaderAttack(IsInAttack);
              
            }
        }    

		//转向锁定目标
		public void DirectToLocked()
		{
			var locked = TargetSelector.Instance.Selected ;
			if (locked != null)
			{
				DirectTo(locked.GlobalPosition);
                Joystick.JoystickDir = Direction;
			}
		}
        protected override void OnQingKungStart()
        {
            base.OnQingKungStart();
            IsQingKunging = true;
            QingKungTouchPointManager.Instance.EnableTuchPoint();
            CameraController.Instance.IsLookup = true;
            CameraController.Instance.LockTarget = true;
            CameraController.Instance.CurMinDistance = CameraController.Instance.CalcCurrentMinDistance() + 1;
        }
        protected override void OnQingKungStop()
        {
            base.OnQingKungStop();
            QingKungTouchPointManager.Instance.DisableTuchPoint();
            QingKungStep = QingKungStep.QingKungNone;
            LastDestPos = Position;
            Syncer.PushMoveData(VoxelWorldID, Position, Position, DirAngle,GameScene.Instance.GetServerTime(), true);
            CameraController.Instance.StopAnimRotate();

            CameraController.Instance.IsLookup = false;
            CameraController.Instance.LockTarget = false;
            CameraController.Instance.CurMinDistance = CameraController.Instance.CalcCurrentMinDistance();

            if (SysSettingModel.Instance.sharedData.iCameraMode == CameraMode.Mode2_5D)
                CameraController.Instance.Reset();
            if (IsQingKunging)
            {
                RequestQingKongEnd();
                IsQingKunging = false;
            }
            //if (CameraDistance > 0)
            //    Bokura.ICameraController.Instance.ChangeDistanceTo(CameraDistance);

        }
        public void MoveByScreenPoint(Vector2 pt)
		{
			//if (IsSpecAnimPlaying)
			//	return;
			var startray = GameScene.Instance.MainCamera.ScreenPointToRay(pt);

			RaycastHit hitinfo;
            Utilities.RayCast(startray, out hitinfo, 100000, (int)Bokura.UserLayerMask.AllBlock);
			var destpos = hitinfo.point;

            MoveByWorldPoint(destpos);
        }
        private GameEvent onRefreshMechanismOperateStr = new GameEvent();

        public GameEvent OnRefreshMechanismOperateStr
        {
            get { return onRefreshMechanismOperateStr; }
        }

        public void RefreshMechanismOperateStr()
        {
            OnRefreshMechanismOperateStr?.Invoke();
        }

        public bool MoveByWorldPoint(Vector3 targetPos, OnMoveStopDelegate onStop = null, bool force = false,float stopdistance = 0.01f, bool sendMount = true)
		{
            m_FindPathTargetPosition = targetPos;
            m_needSendMount = sendMount;
            // 角色在交互点,不能移动
            if (IsInInteractionPoint)
            {
                NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_OPERATE_LIMIT);
                return false;
            }

            if (!m_CanControl && !force || Died)
			{
				if (onStop != null)
					onStop(false);
				return false;
			}

			if (m_pathAgent != null)
            {
                //LogHelper.Log("[HC]MoveByWorldPoint Stop");

                //停止当前的移动，准备寻路
                Stop();
                //LogHelper.Log("[HC]MoveByWorldPoint Start ", GlobalPosition, targetPos);
                AutoPathFinder.Instance.Init(GlobalPosition, targetPos, onStop, stopdistance);
				return AutoPathFinder.Instance.DoTask();
            }
            return false;
        }
		private GameEvent<Vector3> m_OnFindPathStart = new GameEvent<Vector3>();
		/// <summary>
		/// 寻路开始
		/// </summary>
		public GameEvent<Vector3> onFindPathStart { get { return m_OnFindPathStart; } }
		private GameEvent<bool> m_OnFindPathStop = new GameEvent<bool>();
		/// <summary>
		/// 分段寻路结束，true表示还有下一段寻路
		/// </summary>
		public GameEvent<bool> onFindPathStop { get { return m_OnFindPathStop; } }
		private Vector3 m_FindPathTarget;

        
        /// <summary>
        /// 自动寻路的阶段终点
        /// </summary>
        public Vector3 FindPathTarget { get { return m_FindPathTarget; } }

        /// <summary>
        /// 记录寻路的目的地点
        /// </summary>
        private Vector3 m_FindPathTargetPosition;
        private bool m_needSendMount = true;
        public Vector3 FindPathTargetPosition { get { return m_FindPathTargetPosition; } }

        private int m_currentOffset = 0;
        public int CurrentOffset { get { return m_currentOffset; } }

        private float m_FindPathStopDistance;

        /// <summary>
        /// 寻路停下来的距离
        /// </summary>
        public float FindPathStopDistance { get { return m_FindPathStopDistance; } }
        void Path2LocalPos(Vector3[] path)
        {
            if (VoxelWorldID != 0)
            {
                for (int i = 0; i < path.Length; i++)
                {
                    path[i] = MobileBlockMgr.Instance.WorldPos2LocalPos(path[i], VoxelWorldID);
                }
            }
        }

        private List<Vector3> m_MainPath = new List<Vector3>(Bokura.ConstValue.kCap32);
        public List<Vector3> MainPath
        {
            get
            {
                return m_MainPath;
            }
        }
        public void FindMainPath(Vector3 start, Vector3 dest)
        {
            m_MainPath.Clear();
            m_pathAgent.FindMainPath(start, dest, m_MainPath);
            //DrawMainPathBox();
        }
        List<GameObject> _mainBox = new List<GameObject>(32);
        private void DrawMainPathBox()
        {
            for(int i=0;i<_mainBox.Count;i++)
            {
                GameObject.DestroyImmediate(_mainBox[i]);
            }
            _mainBox.Clear();
            for(int i=0;i< m_MainPath.Count;i++)
            {
                GameObject FrameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
                FrameObject.name = "DrawMainPathBox"+i;
                FrameObject.GetComponent<BoxCollider>().enabled = false;
                FrameObject.transform.position = m_MainPath[i] - LayeredSceneLoader.WorldOffset;
                _mainBox.Add(FrameObject);
            }

        }

        public void FindPath(Vector3 destPos)
        {
            AutoPathFinder.Instance.Init(MoveByPathFind, null);

        }

        /// <summary>
        /// 寻路移动到目标点
        /// </summary>
        private bool MoveByPathFind(Vector3 targetPos, OnMoveStopDelegate onStop = null,float distance = 1)
		{
            //LogHelper.Log("MC:MoveByPathFind ", Position.ToString(), "=>", targetPos.ToString(), distance.ToString());
			m_FindPathTarget = targetPos;
            m_FindPathStopDistance = distance;
            var startpos = GlobalPosition;
            if (!m_pathAgent.PathUpdate(startpos, targetPos))
            {
                //目标点不可到达
                NotifyModel.Instance.GetInfoAndDispathTypeEvent(TsInfoID.TS_GAMECOPY_POS_UNREACHABLE);
                if (onStop != null) onStop.Invoke(false);
                return false;
            }
			//开始触发第一个目标点
			Vector3[] tPath = m_pathAgent.onStop(startpos);
            Path2LocalPos(tPath);
            if (tPath != null && tPath.Length > 0)
			{
                //LogHelper.Log("MBPF: Path Found");
				FindPathStateEventChanged(true);
				MoveByWayPoint(tPath, 0, onStop);
				onFindPathStart.Invoke(targetPos);
				return true;
			}
			else
			{
                //直线过去
                tPath = new Vector3[] { targetPos };
                FindPathStateEventChanged(true);
                MoveByWayPoint(tPath, 0, onStop);
                onFindPathStart.Invoke(targetPos);
                return true;
			}
		}
		public override void MoveByWayPoint(Vector3[] wayPoints, int nOffset, OnMoveStopDelegate onStop)
		{
          
            //LogHelper.Log("MC:MoveByWayPoint ", nOffset.ToString());
            //foreach (var p in wayPoints)
            //    LogHelper.Log("MC:MBWP", nOffset.ToString(), p.ToString());
            m_currentOffset = nOffset;
            if (wayPoints != null && nOffset < wayPoints.Length)
            {
                
                m_FindPathTarget = wayPoints[nOffset];
            }

			base.MoveByWayPoint(wayPoints, nOffset, isArrive =>
			{
                //LogHelper.Log("MC:MoveByWayPoint arrive ", nOffset.ToString(), isArrive ? " Done" : " Stopped");
                //foreach (var p in wayPoints)
                //    LogHelper.Log("MC:WPA", nOffset.ToString(), p.ToString());
				if (isArrive && !IsArrivePathFindTarget())
				{
					//继续分段寻路
					Vector3[] tPath = m_pathAgent.onStop(Position);
                    Path2LocalPos(tPath);
                    if (tPath != null && tPath.Length > 0)
					{
						MoveByWayPoint(tPath, 0, onStop);
						onFindPathStop.Invoke(true);
                        return;
					}
				}
				if (onStop != null)
					onStop(isArrive);
				//终止正在进行的寻路任务
				FindPathStateEventChanged(false);
				onFindPathStop.Invoke(false);
				ClearWayPoints();
			});

            //战斗状态就不要骑马了
            if (IsInAttack)
                return;
            //都跑到终点了，还上个毛马
            if (wayPoints == null || nOffset >= wayPoints.Length)
                return;

            //没马说个球
            if (MountMgr.Instance.GetMountCount() == 0)
				return;
            
			//计算自动寻路距离
			float tPathLength = 0;
			int tCount = wayPoints.Length;
			Vector3 tPrevPos = Position;
			for (int tIdx = 0; tIdx < tCount; tIdx++)
			{
				Vector3 tWayPoint = wayPoints[tIdx];
                tPathLength += (tWayPoint - tPrevPos).magnitude;
				tPrevPos = tWayPoint;
			}

			//获取当前区域是否可以骑马
			bool tCanRide = GameScene.Instance.CheckCurrentMapRidable();

			//根据情况自动上下坐骑
			int tMinPathLength = AutoPathFinder.Instance.minPathLength;
			
			if (tCanRide /*能骑马*/&& tPathLength >= tMinPathLength /*要骑马*/&& RideMountBaseID == 0 /*没骑马*/ && !IsInTransform/*不在变身状态*/ && m_needSendMount)
            {
				if (MountMgr.Instance.CurEnableMount != null)
					MountMgr.Instance.RequestMount();
				return;
			}
			if (!tCanRide /*不能骑马*/&& RideMountBaseID != 0/*骑着马*/)
			{
				if (MountMgr.Instance.CurEnableMount != null)
					MountMgr.Instance.RequestDismount();
				return;
			}
		}

        public void OnMainCharactorDie() {
            Stop(true);
        }

		public override void Stop(bool sendstopmsg = true)
		{
			base.Stop(sendstopmsg);
			MoveByJoyStick = false;

        }
        public override void init()
        {
            if(!m_bIsInited)
            {
                m_bIsInited = true;
                base.init();
            }
            ResetSnakePos();
        }

        private void ResetSnakePos()
        {
            if (null == m_snakePosList)
            {
                m_snakePosList = new List<SnakePosParam>(SnakeMaxNumber);//组队5个人的跟随位
                for (int i = 0; i < SnakeMaxNumber; i++)
                {
                    SnakePosParam _data = new SnakePosParam();
                    _data.m_pos = new Vector3(Position.x, Position.y, Position.z);
                    m_snakePosList.Add(_data);
                }
            }
            else
            {
                SnakePosParam _data;
                for (int i = 0; i < m_snakePosList.Count; i++)
                {
                    _data = m_snakePosList[i];
                    _data.m_pos.x = Position.x;
                    _data.m_pos.y = Position.y;
                    _data.m_pos.z = Position.z;
                }
            }
        }
        public void SendMoveStop()
        {
            OutSyncer?.SendMoveStopMsg(VoxelWorldID, DestPos, Direction);
		}

        protected override void OnMoveStop(bool arrive, bool sendstopmsg = true)
        {
            DestPos = Position;
            if(sendstopmsg)
                SendMoveStop();
            base.OnMoveStop(arrive, sendstopmsg); //回调出现在sendmovestop后面，防止服务器动作的被stop打断。
        }

        float cachedCameraDistance;
        void AvatarUpdated()
        {
            CameraController.Instance.SetTarget(Avatar.unityObject.transform);

            Avatar.EnableGrassCollider = true;
            //m_avatar.unityObject.AddComponent<Game.MobileBlockTouchCheck>();
        }
		protected override void OnAvatarCreateDelegate()
        {
            base.OnAvatarCreateDelegate();
            AvatarUpdated();
            CameraReset(true);

            m_HeadBone = Avatar.GetAttachmentTransform(AvatarAttachment.Head);

            if (Avatar.animator != null) //主角不裁剪。
                Avatar.animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;

            AudioCtrl.SetDefaultAudioListener(Avatar.unityObject);

            Scarer = m_avatar.unityObject.AddComponent<FlockScare>();
            GroupEntityManager.Instance.SetFlockScare(Scarer);
        }
        //protected override void DoChangeBody(string modelpath, UnityEngine.Object objBody, UnityEngine.Object objHead, UnityEngine.Object objHair)
        //{
        //    base.DoChangeBody(modelpath, objBody, objHead, objHair);

        //    AvatarUpdated();

        //    OnMountChanged();
        //}
        protected override void OnDataUpdate()
        {
            base.OnDataUpdate();
            AdjustSpeed = speed;
            AdjustTargetSpeed = speed;
        }

        public bool IsArrivePathFindTarget()
        {
            float dis = Vector3.Distance(m_FindPathTargetPosition, Position);
            return (dis < m_FindPathStopDistance);
  
        }

        public override bool IsArriveTarget()
        {
            if(IsInFindingPath)
            {
                //寻路中 如果当前位置和目标位置  在判断半径范围内 就认为到达目的地
                if (IsArrivePathFindTarget())
                    return true;
            }
            
            var destpos = m_FindPathTargetPosition; destpos.y = m_FindPathTarget.y;
            var stopdistance = Vector3.Distance(destpos, m_FindPathTarget) < 0.1f ? m_FindPathStopDistance : Utility.MoveMinDistance;

            destpos = m_FindPathTarget;
            destpos.y = Position.y;
            return Vector3.Distance(destpos, Position) < stopdistance;
        }
        private bool m_bIsForbidTestInput = false;
        public bool IsForbidTestInput { get { return m_bIsForbidTestInput; } set { m_bIsForbidTestInput = value; } }

        protected void UpdateSpecialBehavior()
        {
            if (Died)
            {
                return;
            }
            if (m_bIsForbidTestInput) return;
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.GetComponent<UnityEngine.UI.InputField>())
                    return;
                if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.GetComponent<UnityEngine.UI.Giant.EnhancedInputField>())
                    return;
            }

            if (IUnityInput.Instance.GetKeyUp(KeyCode.Space))
            {
                if (JumpState.Jumping2 == JumpStatus || (IsQingKung() && m_sm.CurStateID != SM.Entity.States.QingKungStun))
                    StartQingKong();
                else
                    Jump();
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Q))
            {
                Dodge();
            }
        }

        protected void UpdateTest()
        {
            if(Died)
            {
                return;
            }
            //TODO: test code
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.GetComponent<UnityEngine.UI.InputField>())
                    return;
                if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.GetComponent<UnityEngine.UI.Giant.EnhancedInputField>())
                    return;
            }

            if (IUnityInput.Instance.GetKeyDown(KeyCode.K))
            {
                RequestAttack();
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha1))
            {
                PrimaryWeapon.Attachment = AvatarAttachment.RightHandProp;
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha2))
            {
                PrimaryWeapon.Attachment = AvatarAttachment.Back;
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha3))
            {
                PrimaryWeapon.Attachment = AvatarAttachment.None;
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha4))
            {
                if (m_earthSwords != null)
                    m_earthSwords.Destroy();
                m_earthSwords = new EarthSwords();
                m_earthSwords.Init(this);
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha5))
            {
                if (m_earthSwords != null)
                {
                    m_earthSwords.AttackTarget(TargetSelector.Instance.Selected, () =>
                    {
                        //LogHelper.Log("attacked");
                    });
                }
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha6))
            {
                if (m_earthSwords != null)
                {
                    m_earthSwords.AttackTargetSkySword(TargetSelector.Instance.Selected, () =>
                    {
                        //LogHelper.Log("attacked!");
                    });
                }
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.Alpha7))
            {
                SkillShowManager.Instance.AddSkillAlert(60201, 1, Position, Direction);
            }
            if (IUnityInput.Instance.GetKey(KeyCode.X))
            {
                StartRadialPostProcess(0.5f, 10, 1);
            }
            if (IUnityInput.Instance.GetKey(KeyCode.C))
            {
                SetFlyingPostProcess(false);
            }

			if (IUnityInput.Instance.GetKey(KeyCode.Alpha8))
			{
				MoveTo(Position + Vector3.up * 10);
			}
			if (IUnityInput.Instance.GetKey(KeyCode.Alpha9))
			{
				MoveTo(Position + (new Vector3(1, 1, 1)) * 10);
			}
			if (IUnityInput.Instance.GetKey(KeyCode.Y))
			{
                
                var forward = GameScene.Instance.MainCamera.cameraToWorldMatrix.MultiplyVector(Vector3.back);
                DirectMoveTo(Position + forward * 10.0f,speed,null);
			}
			if (IUnityInput.Instance.GetKey(KeyCode.U))
			{
                Stop();
			}

            if (IUnityInput.Instance.GetKeyDown(KeyCode.I))
			{
				RequestFlyUpBegin();
			}
            if (IUnityInput.Instance.GetKeyUp(KeyCode.I))
            {
				RequestFlyUpEnd();
			}

			if (IUnityInput.Instance.GetKeyDown(KeyCode.K))
			{
				RequestFlyDownBegin();
			}
            if (IUnityInput.Instance.GetKeyUp(KeyCode.K))
            {
				RequestFlyDownEnd();
			}

#if !RELEASE
            #region  Guide Runtime Tools
            if (IUnityInput.Instance.GetKey(KeyCode.LeftControl) && IUnityInput.Instance.GetMouseButtonDown(0))
            {
                PointerEventData data = new PointerEventData(EventSystem.current);
                data.position = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

                List<RaycastResult> results = new List<RaycastResult>();
                EventSystem.current.RaycastAll(data, results);

                foreach (var item in results)
                {
                    var obj = item.gameObject;
                    if (!obj.activeSelf)
                        continue;

                    GameObject parent = GetPanelParent(obj.transform);

                    var scrollList = obj.GetComponent<UnityEngine.UI.Giant.ScrollList>();
                    if (scrollList)
                    {
                        int num = scrollList.GetTotalCount();

                        //UnityEngine.UI.Giant.UICtrlContent content;
                        for (int i = 0; i < num; i++)
                        {

                        }
                        break;
                    }

                    var btn = obj.GetComponent<UnityEngine.UI.Button>();
                    if (btn)
                    {
                        LogUIPath(parent, obj);
                        break;
                    }

                    var img = obj.GetComponent<UnityEngine.UI.Image>();
                    if (img)
                    {
                        var dirParent = obj.transform.parent;
                        btn = dirParent.GetComponent<UnityEngine.UI.Button>();
                        if (btn)
                        {
                            LogUIPath(parent, dirParent.gameObject);
                            break;
                        }
                    }
                }
            }
            if (IUnityInput.Instance.GetKey(KeyCode.LeftAlt) && IUnityInput.Instance.GetMouseButtonDown(0))
            {
                LogPosition();
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.F1))
            {
                GMCommandManager.Instance.SendCMD("openguide 1");
            }

            if (GuideMgr.Instance.isGuideTool)
            {
                if (IUnityInput.Instance.GetKey(KeyCode.UpArrow))
                {
                    GuideMgr.Instance.GuideBtn.SetHighLightOffset(new Vector3(0, 1, 0));
                }
                else if (IUnityInput.Instance.GetKey(KeyCode.DownArrow))
                {
                    GuideMgr.Instance.GuideBtn.SetHighLightOffset(new Vector3(0, -1, 0));
                }
                else if (IUnityInput.Instance.GetKey(KeyCode.LeftArrow))
                {
                    GuideMgr.Instance.GuideBtn.SetHighLightOffset(new Vector3(-1, 0, 0));
                }
                else if (IUnityInput.Instance.GetKey(KeyCode.RightArrow))
                {
                    GuideMgr.Instance.GuideBtn.SetHighLightOffset(new Vector3(1, 0, 0));
                }
                else if (IUnityInput.Instance.GetKey(KeyCode.N))
                {
                    GuideMgr.Instance.GuideBtn.SetHighLightScale(1.05f);
                }
                else if (IUnityInput.Instance.GetKey(KeyCode.M))
                {
                    GuideMgr.Instance.GuideBtn.SetHighLightScale(0.95f);
                }

                if (IUnityInput.Instance.GetKeyDown(KeyCode.Return))
                {
                    //Vector3 offset = GuideMgr.Instance.GuideBtn.GetOffset();
                    //float scale = GuideMgr.Instance.GuideBtn.GetScale();
                    //LogHelper.Log(LogCategory.Guide, "Offset: ", offset);
                    //LogHelper.Log(LogCategory.Guide, "Scale: ", scale);
                }
            }
            #endregion
#endif

        }
#if !RELEASE
        private void LogPosition()
        {
            //Vector2 pos = Input.mousePosition;
            //LogHelper.Log(LogCategory.Guide, "Current position: " , pos);
        }
        private void LogUIPath(GameObject parent, GameObject target)
        {
            if (parent == null)
                return;

//             var directParent = target.transform.parent;
//             string dirParentName = directParent.name;
//             string parentName = parent.name;
//             string childName = target.name;
//             int ignoreIndex = parentName.IndexOf('(');
//             parentName = parentName.Substring(0, ignoreIndex);
//             ignoreIndex = childName.IndexOf('(');
//             childName = childName.Substring(0, ignoreIndex);
//             ignoreIndex = dirParentName.IndexOf('(');
//             dirParentName = dirParentName.Substring(0, ignoreIndex - 1);

            //LogHelper.Log(LogCategory.Guide, "UI Path: " + parentName + "," + dirParentName + "/" + childName);
        }
        private GameObject GetPanelParent(Transform obj)
        {
            Transform parent = obj.parent;

            while (parent != null)
            {
                string name = parent.name;
                if (name.Contains("ui_panel_"))
                    break;
                parent = parent.parent;
            }
            
            return parent == null ? null : parent.gameObject;
        } 
#endif


        public override void Update()
		{
            if(GameScene.Instance.MainCamera == null || m_avatar.unityObject == null)
                return;
            
#if !RELEASE
            UpdateTest();
#endif
            //if (ICameraHelper.Instance.isFreeMode)
            //{
            //    Position = CameraController.Instance.GetCameraPosition() + LayeredSceneLoader.WorldOffset;
            //    return;
            //}
            if (!Died)
            {
                Joystick.Update();
            }
            
#if UNITY_STANDALONE_WIN
            UpdateSpecialBehavior();
#endif

            //IDebugBlackboard.Output("CameraRotation", "m_x={0}, m_y={1}, mainchar.DirAngle={2}", ICameraController.Instance.rotateX, ICameraController.Instance.rotateY, this.DirAngle);

            m_curRadialTime += Time.deltaTime;
            if(!m_bStopRadial && m_curRadialTime < m_RadialTime)
            {
                var ft = m_curRadialTime / m_RadialTime;
                var v = m_Strength * (StrengthCurve != null ? StrengthCurve.Evaluate(ft) : 1);
                SetFlyingPostProcessParam(v, m_SampleCount);
            }
            else
            {
                SetFlyingPostProcess(false);
                m_bStopRadial = true;
            }
            
            FlockScare();

            base.Update();
            if(m_sm!=null && m_syncer != null)
                m_syncer.PushState(m_sm.CurStateID, AnimID);

            UpdateAirWallEffect();
        }

        RaycastHit m_airEffecthitinfo;
        private readonly int AirEffectIntervalTime = 2;//特效播放间隔
        private float m_AirEffectTimer = 2;
        /// <summary>
        /// 玩家碰撞空气墙播放特效
        /// </summary>
        private void UpdateAirWallEffect()
        {
            m_AirEffectTimer += Time.deltaTime;
            if (m_AirEffectTimer < AirEffectIntervalTime) return;
            if (m_AirEffectTimer > 9999999999) m_AirEffectTimer = AirEffectIntervalTime;

            if (Utilities.RayCast(Position + Vector3.up, Avatar.unityObject.transform.forward, out m_airEffecthitinfo, 0.8f, (int)Bokura.UserLayerMask.AirWall))
            {
                EffectMgr.Instance.Play("fx_bianshen_dl_s", m_airEffecthitinfo.point, null, true, 1);//播放特效
                m_AirEffectTimer = 0;
            }
        }

        public override bool IsNeedMove()
        {
            if(NeedFlyUp || NeedFlyDown )
                return (m_destPos - Position).magnitude > Utility.MoveMinDistance;
            if (IsInFindingPath && IsArriveTarget())
            {
                return false;
            }
            return base.IsNeedMove();
        }
        
        float m_lastSendMoveTime;
        bool m_isStoped;
        public override void ApplyMove(Vector3 d)
		{
            if (m_sm == null)
                return;

			Vector3 xzdir = new Vector3(d.x, 0.0f,d.z);
			
            var movedir = DestPos - Position;
            if (MoveObstacle)
            {
                xzdir = movedir.magnitude > 0.2f ? movedir : d;
                immediate = true;
            }
            else if (isCloudFlyMove())
            {
                xzdir = DestPos - Position;
            }
            else if((MoveByJoyStick || IsInFindingPath) && xzdir.magnitude > 0) //移动状体不带y方向
            {
                xzdir = movedir.magnitude > 30 ? (movedir.normalized * 30) : movedir; // DestPos - Position;//xzdir.normalized * speed * 1.5f;
                xzdir.y = 0.0f;
                ///xzdir = xzdir.normalized * speed * 1.2f;
            }
            else
            {
                xzdir = Vector3.zero; //操纵杆停下来的时候，不发消息。
            }

            if (xzdir.magnitude > 0 )
            {
                immediate = (xzdir.x == d.x && xzdir.z == d.z) ? true : immediate; //短距离的motion,直接发送，避免服务器收到的目标点不连续。
                xzdir = MobileBlockMgr.Instance.WorldDir2LocalDir(xzdir, VoxelWorldID);
                var voxworld = VoxelWorldID;
                if (Mount)
                    voxworld = Mount.VoxelWorldID;
                Syncer.PushMoveData(voxworld, Position, Position + xzdir, DirAngle, GameScene.Instance.GetServerTime(), immediate);
            }
            
            base.ApplyMove(d);
        }
        
        public override void Jump()
        {
            if (!canJump || IsForbidJumpandFly) return;
            base.Jump();
        }
        public Entity GetOverlapEntity()
		{
			var bounds = Avatar.getBoundBox().bounds;
			int ncount = Physics.OverlapBoxNonAlloc(Position, bounds.extents, overlayercollders, Avatar.unityObject.transform.rotation, (int)(UserLayerMask.Character | UserLayerMask.NPC));
			if(ncount>0)
			{
				var gameobj = overlayercollders[0].gameObject;
				foreach(var kv in GameScene.Instance.AllEntitys)
				{
					if (kv.Value.Avatar.unityObject == gameobj)
						return kv.Value;
				}
			}

			return null;
		}

		//public override void DirectMoveTo(Vector3 p, float speed, OnMoveStopDelegate onstop)
		//{
		//	base.DirectMoveTo(p, speed, onstop);
		//	if(m_directMoveDistance > 0.0f)
		//	{
		//		var blinkto = new x2m.BlinkTo();
		//		blinkto.from_pos = Utility.Vector32NetPos(Position);
		//		blinkto.to_pos = Utility.Vector32NetPos(p);
		//		blinkto.type = x2m.BlinkType.BLINKTYPE_ONRUSH;
		//		MsgDispatcher.instance.SendPackage(blinkto);
		//	}
		//}

		public void BindSkillJoystick(SkillJoyStick joystick)
		{
			joystick.UpdateCircleObjectPosDelegate = (out Vector3 pos, out Quaternion rot) =>
			{
                if (GameScene.Instance.MainChar == null)
                {
                    pos = Vector3.zero;
                    rot = Quaternion.identity;
                    return;
                }
				pos = LocalPosition;
                if(VoxelWorldID!=0)
                {
                    if(Avatar!=null&&Avatar.unityObject)
                    {
                        pos = Avatar.unityObject.transform.position;
                    }
                }
				//pos.y += 10.0f;
				rot = Quaternion.Euler(0, CameraController.Instance.RotateX, 0);
			};
		}
        public override void SetAvatarPosition()
        {
            base.SetAvatarPosition();

            if (null != m_snakePosList && Actived )
            {
                SnakePosParam _firstPos = m_snakePosList[0];
                float len = (Position-_firstPos.m_pos).sqrMagnitude;
                if(len >= 1.0f)
                {
                    for(int i = m_snakePosList.Count-1;i>0;i--)
                    {
                        int nextIndex = i - 1;
                        SnakePosParam _curData = m_snakePosList[i];
                        _curData.m_pos.x = m_snakePosList[nextIndex].m_pos.x;
                        _curData.m_pos.y = m_snakePosList[nextIndex].m_pos.y;
                        _curData.m_pos.z = m_snakePosList[nextIndex].m_pos.z;
                    }
                    _firstPos.m_pos.x = Position.x;
                    _firstPos.m_pos.y = Position.y;
                    _firstPos.m_pos.z = Position.z;
                    GameScene.Instance.DispatchMainCharSnakePosChange();
                }
            }

            CheckIsCloseEntity();

            if (HomeBuildingMgr.Instance != null)
            {
                HomeBuildingMgr.Instance.CheckIsCloseBuilding();
            }
        }

        /// <summary>
        /// 检查是否接近采集物品点
        /// </summary>
        /// <returns></returns>
        public void CheckIsCloseEntity(bool _isNotCheckOldIsEqual = false)
        {
            // 角色在交互点,不能刷新按钮
            if (IsInInteractionPoint)
                return;

            // 同时主角进入交互区域
            if (enterInteractionGroupId > 0)
                return;

            Entity _closeEntity = GameScene.Instance.CheckMainCharacterCloseEntity();
            ulong tmpId = 0;
            if (null != _closeEntity)
            {
                tmpId = _closeEntity.ThisID;
            }

            if (_isNotCheckOldIsEqual || m_CurrentCloseEntityId != tmpId)
            {
                m_CurrentCloseEntityId = tmpId;
                OnCloseGatherIdChanged.Invoke(m_CurrentCloseEntityId, _closeEntity);
            }
        }

        /// <summary>
        /// 检测紧密的npc
        /// </summary>
        private void CheckCloseNpc()
        {
            if ((m_lastMovePosByCheckNpc - Position).sqrMagnitude <= 0.01f)
                return;

            m_lastMovePosByCheckNpc = Position;

            GameScene.Instance.CheckMainCharacterCloseNpc(CheckNpcDodgeDistance);                 
        }

        protected override void RefreshMount(bool isDisappear = false)
        {
            base.RefreshMount(isDisappear);
            if (Mount && Mount.IsAirMount)
            {
                CameraController.Instance.IsLookup = true;
            }
            else
            {
                CameraController.Instance.IsLookup = false;
            }
        }
        public void ResetCamera(bool isAttack = false)
        {
            CameraController.Instance.Reset(DirAngle,false);
        }

        private bool m_bStopRadial = false;
        private float m_RadialTime = 0;
        private float m_curRadialTime = 0;
        private float m_Strength = 0;
        private int m_SampleCount = 0;
        private AnimationCurve StrengthCurve = null;
        public void StartRadialPostProcess(float fStrength, int SampleCount,float time,AnimationCurve strengthCurve = null)
        {
            m_bStopRadial = false;
            m_RadialTime = time;
            m_curRadialTime = 0;
            m_SampleCount = SampleCount;
            m_Strength = fStrength;
            StrengthCurve = strengthCurve;
            var v = m_Strength * ( StrengthCurve != null ? StrengthCurve.Evaluate(0) : 1);
            SetFlyingPostProcess(true);
            SetFlyingPostProcessParam(v, m_SampleCount);
        }
        public void SetFlyingPostProcess(bool bEnable)
        {
            var setting = UnityEngine.Rendering.PostProcessing.PostProcessManager.instance.GetPostProcessSetting<UnityEngine.Rendering.PostProcessing.RadialBlur>();
            if (setting)
            {
                setting.enabled.value = bEnable;
                setting.blurEnable.value = bEnable;
            }
        }

        public void SetFlyingPostProcessParam(float fStrength, int SampleCount)
        {
            var setting = UnityEngine.Rendering.PostProcessing.PostProcessManager.instance.GetPostProcessSetting<UnityEngine.Rendering.PostProcessing.RadialBlur>();
            if (setting)
            {
                setting.radialBlurStrength.value = fStrength;
                setting.radialBlurSamples.value = SampleCount;
            }
        }

        /// <summary>
        /// Remove all effects attached to main character when change game state
        /// </summary>
        public override void RemoveAllEffects()
        {
            base.RemoveAllEffects();
        }

        public void WorldMove(Vector3 _, Vector3 delta)
        {
            var avatar = Mount && Mount.Avatar != null ? Mount.Avatar: Avatar;
            if (avatar == null)
            {
                LogHelper.LogWarning("avatar is null.");
                return;
            }
            var obj = avatar.unityObject;
            if (obj) obj.transform.position += delta;
        }

        public void LockOperAndCamera()
        {
            CanControl = false;
            CameraController.Instance.LockRotation = true;
        }
        public void UnLockOperAndCamera()
        {
            CanControl = true;
            CameraController.Instance.LockRotation = false;

        }

        public void CameraReset(bool reload = false)
        {
            if (VehicleId == carefulVehicleId)
            {
                cachedCameraDistance = CameraController.Instance.GetTargetDistance();
            }

            if (reload)
            {
                ResourceHelper.LoadResourceAsync("prefabs/gameconfig/", "cameraconfig", IResourceLoader.strAssetSuffix,m_onCameraConfigLoad);
            }
            CameraController.Instance.Reset();
            if (VehicleId == carefulVehicleId)
            {
                //谨慎状态的变身
                //调整镜头高度
                CameraController.Instance.SetLookAtDetlaOffset(new Vector3(0, -0.8f, 0));//可改为配置
                CameraController.Instance.ChangeDistanceTo(2.4f);
            }
            else
            {
                CameraController.Instance.SetLookAtDetlaOffset(Vector3.zero);
                if (cachedCameraDistance > 0)
                    CameraController.Instance.ChangeDistanceTo(cachedCameraDistance);
            }
        }
        /// <summary>
        /// 获取主角色在指定界面的AvatarShow
        /// </summary>
        public AvatarShow GetCharacterShow(int panelId)
        {
            UserAvatarData tAvatarData = GetAvatarShowData(panelId);
            AvatarShow tShow = AvatarShowManager.Instance.GetAvatarShow(tAvatarData);
            tAvatarData.Dispose();
            return tShow;
        }
        /// <summary>
        /// 获取主角的AvatarShow所需数据
        /// </summary>
        [XLua.BlackList]
        public UserAvatarData GetAvatarShowData(int panelId)
        {
            UserAvatarData tAvatarData = new UserAvatarData();
            tAvatarData.panelID = panelId;
            tAvatarData.charID = ThisID;
            tAvatarData.career = (int)CareerType;
            tAvatarData.sex = (int)Sex;
            //捏脸数据浅拷贝
            tAvatarData.makeup = m_makeupData;

            //时装
            List<uint> tFashionData = UnityEngine.UI.Giant.UIPoolMgr.SpawnList<uint>();
            List<uint> tFashionList = m_data?.user_data?.fids;
            if (null != tFashionList)
            {
                for (int tIdx = 0, tCount = tFashionList.Count; tIdx < tCount; tIdx++)
                    tFashionData.Add(tFashionList[tIdx]);
            }
            tAvatarData.fids = tFashionData;
            return tAvatarData;
        }
        protected CameraControllerConfig cameraconfig = null;
        public void SetCameraMouseSlide(float s,float z)
        {
            if (cameraconfig != null)
            {
                cameraconfig.MouseSlideDelta = s;
                cameraconfig.MouseZoomSpeed = z;
            }
        }
        void OnCameraConfigLoad(UnityEngine.Object o)
        {
            var c = o as CameraControllerConfig;
            if (c != null)
            {
                cameraconfig = c;
                CameraController.Instance.LoadConfig(c);
                CameraController.Instance.SetTarget(Avatar.unityObject.transform);
                CameraController.Instance.Reset();

                TargetSelector.Instance.MaxSelectDistance = c.SelectTartgetMaxDistance;
                TargetSelector.Instance.OverViewDelayOverTime = c.TargetLeaveCameraOverTime;
                TargetSelector.Instance.SelectViewRange = c.CameraTargetSelectRange;
            }
            else
            {
                LogHelper.LogWarning("CameraControllerConfig load fail!");
            }
        }

        bool m_bDistanceVisible = true;
        bool m_bRotateVisible = true;

        public bool isInFeatureArticleState = false;

        void CameraDitanceChanged(float distance)
        {
            if (CameraController.Instance.isSphereCastSamething)
            {
                isInFeatureArticleState = false;
            }
            if (isInFeatureArticleState)
            {
                return;
            }
            if (Mount == null)
                m_bDistanceVisible = distance > 0.8f;
            else
            {
                m_bDistanceVisible = distance >= CameraController.Instance.CurMinDistance;
                Mount.VisibleByCamera = m_bDistanceVisible;
            }

            VisibleByCamera = IsQingKunging || (m_bDistanceVisible && m_bRotateVisible);

            //bool issetweaponshow = !IsInInteractionPoint;

            //if (issetweaponshow)
            //{
            //    PrimaryWeapon?.ShowAvataWithoutState(VisibleByCamera);
            //}
        }
        void CameraRotateChanged()
        {
            if (CameraController.Instance.isSphereCastSamething)
            {
                isInFeatureArticleState = false;
            }
            if (isInFeatureArticleState)
            {
                return;
            }

            m_bRotateVisible = CameraController.Instance.RotateY > -50f;
            VisibleByCamera = IsQingKunging || (m_bDistanceVisible && m_bRotateVisible);

            //bool issetweaponshow = !IsInInteractionPoint;

            //if (issetweaponshow)
            //{
            //    PrimaryWeapon?.ShowAvataWithoutState(VisibleByCamera);
            //}
        }

        void OnAttackCameraRotate(SkillBase skill)
        {
            if (m_bISAttackRotateCamOn)
            {
                Entity iTarget = TargetSelector.Instance.Selected;
                if (iTarget != null && iTarget.CanAttack)
                {
                    //临时写死的不进行矫正的技能，啥也不干
                    //剑仙的斗星移技能
                    //治疗、增减益技能也过滤掉
                    if (skill.ID == 1021141 ||
                        (skill.Config.skilltag & (int)SkillTag.CastSkillCamRotateFilter) != 0) { }
                    else if ((skill.Config.joystick_type == 2 || skill.Config.joystick_type == 3) && (skill.DestPos - iTarget.Position).magnitude > 0.1f)
                    {
                        AttackRotateCamera(skill.DestPos - LayeredSceneLoader.WorldOffset);
                    }
                    else
                        AttackRotateCamera(TargetSelector.Instance.Selected.LocalPosition);
                }
            }
        }

        public void AttackRotateCamera(Vector3 tTargetPos)
        {
            CameraController iCamCtl = CameraController.Instance;
            float iRotationX = iCamCtl.RotateX, iRotationY = iCamCtl.RotateY;
            Vector3 iTargetInViewPos = Vector3.zero;
            //Vector3 iCam2MainChar = GameScene.Instance.MainChar.LocalPosition - iCamCtl.GetCameraPosition(); iCam2MainChar.y = 0;
            //Vector3 iTar2MainChar = GameScene.Instance.MainChar.LocalPosition - tTargetPos; iTar2MainChar.y = 0;
            //float iAngle = Vector3.SignedAngle(iTar2MainChar, iCam2MainChar, Vector3.up);
            if (!iCamCtl.IsPointInBiaxRange(tTargetPos, out iTargetInViewPos, false, true, 0.167f, 0.833f)/* ||
                Mathf.Abs(iAngle) < 90*/)
            {
                iCamCtl.StopAnimRotate();

                Vector3 iCam2MainChar = GameScene.Instance.MainChar.LocalPosition - iCamCtl.GetCameraPosition();
                Vector3 iTarget2MainChar = GameScene.Instance.MainChar.LocalPosition - tTargetPos;
                iCam2MainChar.y = 0;
                iTarget2MainChar.y = 0;

                //************************************************************************
                // Calculate rotate angle on X, plus current rotation gets target rotation.
                // See detail algorithm in document
                //************************************************************************
                float iMaxHorDegree = Mathf.Atan(Mathf.Tan(Bokura.ICameraHelper.Instance.MainCamera.fieldOfView / 2 * Mathf.Deg2Rad) * Bokura.ICameraHelper.Instance.MainCamera.aspect) * Mathf.Rad2Deg * 0.5f;
                float iRotateAngle = 90 - iMaxHorDegree + Mathf.Acos(iCam2MainChar.magnitude * Mathf.Sin(iMaxHorDegree * Mathf.Deg2Rad) / iTarget2MainChar.magnitude) * Mathf.Rad2Deg - Vector3.Angle(iCam2MainChar, iTarget2MainChar);
                iRotationX = iCamCtl.RotateX + iRotateAngle * (iTargetInViewPos.x > 0.5f ? 1 : -1) * (iTargetInViewPos.z > 0 ? 1 : -1);

                iCamCtl.AnimRotateTo(iRotationX, iRotationY, 3, false);

                //iCamCtl.StopAnimRotate();
                //iCam2MainChar.y = 0;
                //iTar2MainChar.y = 0;
                //iCam2MainChar *= -1;
                //iRotationX += Vector3.SignedAngle(iCam2MainChar, iTar2MainChar, Vector3.up);
                //iCamCtl.AnimRotateTo(iRotationX, iRotationY, 3, false);
            }
            else
            {
                Vector3 iCam2MainChar = GameScene.Instance.MainChar.LocalPosition - iCamCtl.GetCameraPosition(); iCam2MainChar.y = 0;
                Vector3 iTar2MainChar = GameScene.Instance.MainChar.LocalPosition - tTargetPos; iTar2MainChar.y = 0;
                float iAngle = Vector3.SignedAngle(iTar2MainChar, iCam2MainChar, Vector3.up);
                if (Mathf.Abs(iAngle) < 90)
                {
                    iCamCtl.StopAnimRotate();
                    iRotationX += (150 - Mathf.Abs(iAngle)) * (iAngle > 0 ? 1 : -1);
                    iCamCtl.AnimRotateTo(iRotationX, iRotationY, 3, false);
                }
            }
        }
#region 空中战斗飞行相关

        private bool m_needFlyDown;
		public bool NeedFlyDown
		{
			get
			{
				return m_needFlyDown;
			}
		}
		private bool m_needFlyUp;
		public bool NeedFlyUp
		{
			get
			{
				return m_needFlyUp;
			}
		}
		public void RequestFlyUpBegin()
		{
			m_needFlyUp = true;
		}
		public void RequestFlyUpEnd()
		{
			m_needFlyUp = false;
		}

		public void RequestFlyDownBegin()
		{
			m_needFlyDown = true;
		}

		public void RequestFlyDownEnd()
		{
			m_needFlyDown = false;
		}

        private bool IsQingKunging = false;
        private int m_curQingKungEnergy = 0;
        private int m_maxQingKungEnergy = 100;
        public void SetQingKungEnergy(int cur,int max)
        {
            m_curQingKungEnergy = cur;
            m_maxQingKungEnergy = max;
            OnQingKungEnergyChanged.Invoke(m_curQingKungEnergy,m_maxQingKungEnergy);
        }
#endregion

        //播放谨慎||隐身的镜头前特效
        private EffectMgr.EffectInfo m_carefulEffectInfo;
        public void ToggleCarefulCameraEffect(bool value)
        {
            if (value)
            {
                //var cameraTrs = ICameraHelper.Instance.MainCameraTransform;
                m_carefulEffectInfo = EffectMgr.Instance.Play("fx_3_bianshen_camera_dl", this, AvatarAttachment.MainCamera,null,false);
            }
            else
            {
                if (m_carefulEffectInfo != null)
                {
                    m_carefulEffectInfo.Stop();
                    m_carefulEffectInfo = null;
                }
            }
        }

        /// <summary>
        /// 进入的交互点的id
        /// </summary>
        /// <param name="interactiongroupid"></param>
        public void EnterInteractionGroupId(uint interactiongroupid)
        {
            m_enterInteractionGroupId = interactiongroupid;
        }
        
        /// <summary>
        /// 进入地图复位一些属性
        /// </summary>
        public void ResetInIntoMap()
        {
            m_forbidMove = false;
            m_interactionState = Game.MovableEntity.InteractionState.None;

            interaction_id = 0;
            interaction_action = 0;
            m_enterInteractionGroupId = 0;

            //SetCCRadius(m_ccOrgRadius);

            ClothSleep(false);
            ResetSnakePos();

            onSetTempShowHead.Invoke(true);

            if ((StateMachine.CurStateID != SM.Entity.States.StateEnterClouding) && (StateMachine.CurStateID != SM.Entity.States.StateExitClouding))
            {
                StateMachine.ChangeState(SM.Entity.States.IDLE);
            }
        }

        protected FlockScare Scarer = null;
        public void FlockScare()
        {
            if (Scarer != null) Scarer.CheckProximityToLandingSpots();
        }
#region Humiture Status
        public bool isCold
        {
            get { return WeatherManager.Instance.temperatureType == swm.TemperatureType.Cold; }
        }
        public bool isHot
        {
            get { return WeatherManager.Instance.temperatureType == swm.TemperatureType.Hot; }
        }
        public bool isNormal
        {
            get { return WeatherManager.Instance.temperatureType == swm.TemperatureType.Normal; }
        }
        #endregion

        public override bool CanSelect
        {
            get
            {
                return false;
            }
        }
    }
}
