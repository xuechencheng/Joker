﻿//场景机关类, 机关特有的属性和方法在此处理;

using System;

using UnityEngine;
using Bokura;

namespace Bokura
{
    public class MechanismEntity : MovableEntity
    {

        public MechanismEntity(ulong id) : base(id)
        {
            m_layer = (Int32)(UserLayer.Layer_NPC);
        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public MechanismEntity() : base()
        {
        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public override void InitEntity(ulong id)
        {
            base.InitEntity(id);
            m_layer = (Int32)(UserLayer.Layer_NPC);
        }

        [XLua.BlackList]
        public override void Release()
        {
            base.Release();
        }

        ~MechanismEntity()
        {
        }

        public uint m_machineDataBaseid;
        public uint m_machineDataState;

        private bool isMachineTriggerTypeOperate = false;
        private float m_checkRangeSqr = 0;

        public override uint BaseID
        {
            get
            {
                return m_machineDataBaseid;
            }
        }

        public bool IsMachineTriggerTypeOperate()
        {
            return isMachineTriggerTypeOperate;
        }

        public float CheckRangeSqr()
        {
            return m_checkRangeSqr;
        }

        public override void SetNetData(swm.MapEntityData _data)
        {
            base.SetNetData(_data);
            if (_data.machine_data != null)
            {
                m_machineDataBaseid = _data.machine_data.Value.baseid;
                m_machineDataState = _data.machine_data.Value.state;
            }
        }

        public override void OnAddToScene()
        {
            base.OnAddToScene();

            MechanismAssets.Item item = IMechanismMgr.Instance.GetItem(m_machineDataBaseid);
            if (item != null)
            {
                if (!item.isStatic)
                {
                    AvatarLoadModel(item.modelPath, item.modelName, true);
                }

                isMachineTriggerTypeOperate = ((item.triggerTypes & (int)Bokura.MachineTriggerType.Operate) == 1);

                m_checkRangeSqr = (float)(item.check_range * item.check_range);
            }

        }

        Bokura.Mechanism m_mm = null;

        public override string GetOperateStr()
        {
            if (m_mm != null)
            {
                return m_mm.GetOperateStr();
            }

            return "";
        }

        protected override void OnAvatarCreateDelegate()
        {
            base.OnAvatarCreateDelegate();

            if (m_avatar.unityObject != null)
            {
                MechanismAssets.Item item = IMechanismMgr.Instance.GetItem(m_machineDataBaseid);
                if (item != null)
                {
                    if (!item.isStatic)
                    {
                        Position = item.position;
                        Direction = item.forward;

                        m_mm = m_avatar.unityObject.GetComponent<Bokura.Mechanism>();
                        if (m_mm == null)
                        {
                            m_mm = m_avatar.unityObject.AddComponent<Bokura.Mechanism>();
                        }

                        if (m_mm != null)
                        {
                            m_mm.item = item;
                        }
                    }
                }
            }
        }

    }
}

