using System.Collections.Generic;
using UnityEngine;
using System;
using Bokura;

namespace Bokura
{
    public class MovableEntity : Entity
    {
        #region 常量
        public static float kMovePropJumpSpeed { get { return (int)swm.kMovePropJumpV0.Value / 1000.0f; } }
        public static float kMovePropJumpGrivity { get { return (int)swm.kMovePropJumpGravity.Value / 1000.0f; } }
        public static float kMovePropFallGrivity { get { return (int)swm.kMovePropFallGravity.Value / 1000.0f; } }
        public static float kMovePropFallMaxSpeed { get { return (int)swm.kMovePropFallMaxSpd.Value / 1000.0f; } }

        public static float kQingKungFallGrivity { get { return (int)swm.kMovePropQingKungFallGravity.Value / 1000.0f; } }
        public static float kQingKungGrivity { get { return (int)swm.kMovePropQingKungGravity.Value / 1000.0f; } }
        public static float kQingKungFallSpeed { get { return (int)swm.kMovePropQingKungFallSpd.Value / 1000.0f; } }
        public static float kQingKungEnergyRecovery { get { return (int)swm.kQingKungRecovery.Value ; } }
        public static float kQingKungEnergyCost { get { return -(int)swm.kQingKungCost.Value ; } }

        public static float kCommonGlidingSpeed { get { return (int)swm.kMoveGliding.Value / 1000.0f; } }
        public static float kCommonGlidingGrivity { get { return (int)swm.kMoveGlidingGravity.Value / 1000.0f; } }

        #endregion

        #region 美术的默认参数 默认来自ArtConfigComponent
        protected Bokura.ArtConfigComponent ArtConfig = null;
        public float MotionWalkSpeed { get { return ArtConfig ? ArtConfig.MotionWalkSpeed : 5.0f; } }
        public float MotionRunSpeed { get { return ArtConfig ? ArtConfig.MotionRunSpeed : 8.0f; } }
        #endregion

        public delegate void OnMoveStopDelegate(bool bArrive);
        public GameEvent OnQingKungEnter = new GameEvent();
        public GameEvent<bool> OnQingKungStay = new GameEvent<bool>();
        public GameEvent OnQingKungLeave = new GameEvent();

        public GameEvent OnJumpStartEvent = new GameEvent();
        public GameEvent OnJumpStopEvent = new GameEvent();
        public GameEvent OnMoveStopEvent = new GameEvent();
        public GameEvent<bool> onTransformationChange = new GameEvent<bool>();

        public bool IsQingKungNormalFall = true;
        public bool CanQingKungInterrupte = true;

        OnMoveStopDelegate onMoveStop;
		//int m_moveID;
		protected Vector3 m_destPos = Vector3.zero;
        protected Vector3 m_lastdestPos = Vector3.zero;
        //protected Vector3 m_lastMoveDir = Vector3.zero;
        Vector3[] m_waypoints;

		protected float m_directMoveDistance = 0.0f;
		protected Vector3 m_directMoveDir = Vector3.zero;
		protected Vector3 m_directMovePos;
        protected Vector3 m_directMoveTargetPos;

        protected float m_directMoveSpeed;
		OnMoveStopDelegate m_directMoveCallback;

		float m_speed = 2.5f;

        protected bool m_bIsChant = false;
        /// <summary>
        /// 是否正在采集
        /// </summary>
        public bool IsChant
        {
            get { return m_bIsChant; }
        }

        //int m_damageEffectIndex = 0;

        public List<GameObject> DamageEffectArr = new List<GameObject>();

        #region Property

        #region 交互动作
        public enum ActionType
        {
            Common, //普通动作
            Interaction //交互点动作
        }

        /// <summary>
        /// 交互状态
        /// </summary>
        public enum InteractionState
        {
            None,
            EnterIdle,
            Idle,
            Exit
        }

        public class InteractionStateInfo
        {
            public uint interaction_id;        // 交互id
            public uint action_id;             // 动作id
        }

        private uint m_CommonActionId = 0;
        public uint CommonActionId { get{ return m_CommonActionId; } set { m_CommonActionId = value; } }

        private UnityEngine.Vector3 m_CommonTrunPos = UnityEngine.Vector3.zero; //转向目标
        public UnityEngine.Vector3 CommonTrunPos { get { return m_CommonTrunPos; } set { m_CommonTrunPos = value; } }

        private UnityEngine.Vector3 m_CommonTrunDir = UnityEngine.Vector3.zero; //转向目标
        public UnityEngine.Vector3 CommonTrunDir { get { return m_CommonTrunDir; } set { m_CommonTrunDir = value; } }

        private ActionType m_CommonType = ActionType.Common;
        public ActionType CommonType { get { return m_CommonType; } set { m_CommonType = value; } }
        protected InteractionState m_interactionState = InteractionState.None;
        /// <summary>
        /// 交互状态
        /// </summary>
        public InteractionState interactionState
        {
            get { return m_interactionState; }
            set { m_interactionState = value; }
        }
        protected InteractionStateInfo m_interactionInfo = new InteractionStateInfo();
        /// <summary>
        /// 交互状态信息
        /// </summary>
        public InteractionStateInfo interactionInfo
        {
            get { return m_interactionInfo; }
        }

        public uint interaction_id
        {
            get { return m_data != null ? m_data.interaction_id : 0; }
            set { m_data.interaction_id = value; }
        }
        private Vector3 m_interaction_pos;
        public Vector3 interaction_pos
        {
            get { return m_interaction_pos; }
            set { m_interaction_pos = value; }
        }
        private Vector3 m_interaction_dir;
        public Vector3 interaction_dir
        {
            get { return m_interaction_dir; }
            set { m_interaction_dir = value; }
        }
        public bool IsInInteractionPoint { get { return interaction_id != 0; } }

        public uint interaction_action
        {
            get { return m_data.interaction_action; }
            set { m_data.interaction_action = value; }
        }
        public ulong interaction_serve_target_id { get; set; }
        #endregion

        protected CharacterController m_cc;
        public CharacterController CC
        {
            get { return m_cc; }
            set { if (m_cc != value) { m_cc = value; } }
        }

        public uint WeaponId {
            get { return m_data.user_data.weaponid; }
            set {
                if (m_data.user_data.weaponid != value)
                {
                    var oldid = m_data.user_data.weaponid;
                    m_data.user_data.weaponid = value;
                    OnWeaponChanged(oldid);
                }
            }
        }

        protected void OnWeaponChanged(uint old_weaponid)
        {
            if(WeaponId > 0)
            {
                if (PrimaryWeapon != null)
                    PrimaryWeapon.SwitchWeapon(WeaponId);
                else
                {
                    PrimaryWeapon = new Weapon();
                    PrimaryWeapon.init(this, WeaponId);
                }
            }
            else
            {
                PrimaryWeapon?.Release();
                PrimaryWeapon = null;
            }

            RefreshAnimatorStateClip();
        }
        protected string[] strAnimationClipPath = { "","art_resource/animations/characters/chr_mm_z/","art_resource/animations/characters/chr_fm_j/" ,"", "art_resource/animations/characters/chr_fm_m/",  };
        protected List<KeyValuePair<string, string[]>> strAnimatoionClipNames = new List<KeyValuePair<string, string[]>>()
        {
           new KeyValuePair<string,string[]>("att_run",new string[] { "", "anim_chr_mm_z@att_run", "anim_chr_fm_j@att_run", "", "anim_chr_fm_m@att_run" } ),
           new KeyValuePair<string,string[]>("attIdle",new string[] { "", "anim_chr_mm_z@attIdle", "anim_chr_fm_j@attIdle","", "anim_chr_fm_m@attIdle" } ),
           new KeyValuePair<string,string[]>("attIdleToStand",new string[] { "", "anim_chr_mm_z@attIdleToStand", "anim_chr_fm_j@attIdleToStand", "", "anim_chr_fm_m@attIdleToStand" } ),
           new KeyValuePair<string,string[]>("att_runToAttIdle",new string[] { "", "anim_chr_mm_z@att_runToAttIdle", "anim_chr_fm_j@att_runToAttIdle", "", "anim_chr_fm_m@att_runToAttIdle" } ),

        };

        protected void RefreshAnimatorStateClip()
        {
            if (PrimaryWeapon == null) return;
            if (strAnimationClipPath.Length < (int)PrimaryWeapon.WeaponCategory) return;

            if (Avatar == null || Avatar.animator.MainAnimator == null) return;
            var overriderController = Avatar.animator.MainAnimator.runtimeAnimatorController as AnimatorOverrideController;

            if (overriderController == null) return;

            var path = strAnimationClipPath[(int)PrimaryWeapon.WeaponCategory];
            if (string.IsNullOrEmpty(path)) return;
            foreach(var clips in strAnimatoionClipNames)
            {
                if(clips.Value.Length > (int)PrimaryWeapon.WeaponCategory)
                {
                    var clipname = clips.Value[(int)PrimaryWeapon.WeaponCategory];
                    var clip = IResourceLoader.Instance.LoadAssetSync(path, clipname, IResourceLoader.strFbxSuffix, false, typeof(AnimationClip));
                    overriderController[clips.Key] = clip as AnimationClip;

                }
            }

        }
        public Vector3[] WayPoint { get { return m_waypoints; } }
        public virtual bool UseGravity
        {
            get
            {
                return !IsFlying && EnableGravity && (m_sm != null && m_sm.UseGravity) && !isCurrCloudEnterFly() && !TimeLineing;
            }
        }

        public virtual bool Moveing
		{
			get
			{
				return m_sm!=null && m_sm.CurStateID == SM.Entity.States.MOVE;
			}
		}

        #region 位置与方向

        private Vector3 m_logicPosition;
        public Vector3 LogicPostition { get { return m_logicPosition; } set { m_logicPosition = value; } }

        public override Vector3 Position
		{
			get
			{
				return base.Position;
			}

			set
			{
				if(m_position != value)
				{
                    if (!IsNeedMove())
                    {
                        DestPos = value;
						base.Position = value;
					}
					else
                    {
                        base.Position = value;
					}
				}
			}
        }

        private Vector3 m_v3OldPosition;
        public Vector3 OldPosition { get { return m_v3OldPosition; } set { m_v3OldPosition = value; } }

        public virtual float speed { get { return m_speed; } set { m_speed = value; } }

        public Vector3 MoveDir
		{
			get
			{
                Vector3 dir = DestPos - Position;
                if (dir.magnitude > 0)
                    return dir;
				return Direction;
			}
		}
        public Vector3 LastDestPos { get { return m_lastdestPos; } set { m_lastdestPos = value; } }
        public Vector3 DestPos { get { return m_destPos; } set { m_destPos = value; } }
        protected Vector3 m_motion = Vector3.zero;
        public Vector3 Motion { get { return m_motion; } set { m_motion = value; } }
        public Vector3 LocalMotion
        {
            get
            {
                if(m_avatar !=null && m_avatar.unityObject )
                {
                    return Quaternion.Inverse(m_avatar.unityObject.transform.rotation) * m_motion;
                }
                return m_motion;
            }
        }
        #endregion


		protected int m_jumpTrigger;

		public bool JumpTrigger
		{
			get
			{
				return m_jumpTrigger>0;
			}

		}

        protected bool m_flyTrigger;

        public bool FlyTrigger
        {
            get
            {
                return m_flyTrigger;
            }
            set
            {
                m_flyTrigger = value;
            }
        }
        protected bool m_dodgeTrigger;
		public bool DodgeTrigger
		{
			get
			{
				return m_dodgeTrigger;
			}
			set
			{
				m_dodgeTrigger = value;
			}
		}

        private bool m_InHandWeaponState = false;
        public bool InHandWeaponState {
            get {
                return m_InHandWeaponState;
            }
        }
        public void IntoHandWeaponState() {
            m_InHandWeaponState = true;
            if (PrimaryWeapon != null)
            {
                PrimaryWeapon.Attachment = GetPrimaryWeaponPos(PrimaryWeapon);
            }
            if (SecondaryWeapon != null)
            {
                SecondaryWeapon.Attachment = AvatarAttachment.LeftHandProp;
            }
        }

        public bool OutHandWeaponState() {
            if (!m_InHandWeaponState)
                return false;
            m_InHandWeaponState = false;
            PrimaryWeapon.Attachment = Bokura.AvatarAttachment.Back;
            CrossFadeAll(AnimatorStateID.AttIdleToStand);
            //if (Avatar.animator && Avatar.animator.HasState(2, AnimatorStateID.AttIdleToStand))
            //{
            //    Avatar.animator.CrossFade(AnimatorStateID.AttIdleToStand, 0.0f, 2, 0.0f);
            //}

            if (SecondaryWeapon != null)
                SecondaryWeapon.Attachment = Bokura.AvatarAttachment.Back;
            return true;
        }

        Weapon m_primaryWeapon;
		public Weapon PrimaryWeapon
		{
			get
			{
				return m_primaryWeapon;
			}
			set
			{
				m_primaryWeapon = value;
			}
		}

		Weapon m_secondaryWeapon;
		public Weapon SecondaryWeapon
		{
			get
			{
				return m_secondaryWeapon;
			}
			set
			{
				m_secondaryWeapon = value;
			}
		}

		Weapon m_godWeapon;
        // 腰饰
        Decoration m_waist;
        public Decoration Waist
        {
            get
            {
                return m_waist;
            }
            set
            {
                m_waist = value;
            }
        }
        // 发饰
        Decoration m_hairAccessory;
        public Decoration HairAccessory
        {
            get
            {
                return m_hairAccessory;
            }
            set
            {
                m_hairAccessory = value;
            }
        }
        // 背饰
        Decoration m_backDecoration;
        public Decoration BackDecoration
        {
            get
            {
                return m_backDecoration;
            }
            set
            {
                m_backDecoration = value;
            }
        }
        public override bool Visible
		{
			set
			{
				if(base.Visible!=value)
				{
					base.Visible = value;
					if (m_primaryWeapon != null)
						m_primaryWeapon.Show(value);
					if (m_secondaryWeapon != null)
						m_secondaryWeapon.ShowAvataWithoutState(value);
                    if (m_waist != null)
                        m_waist.Avatar.Visible = value;
                    if (m_hairAccessory != null)
                        m_hairAccessory.Avatar.Visible = value;
                    if (m_backDecoration != null)
                        m_backDecoration.Avatar.Visible = value;
				}

                base.Visible = value;

            }

		}
        protected override void OnVisibleChange()
        {
            if (m_primaryWeapon != null)
                m_primaryWeapon.Show(ActuallyVisible);
            if (m_secondaryWeapon != null)
                m_secondaryWeapon.ShowAvataWithoutState(ActuallyVisible);
            if (m_waist != null)
                m_waist.Avatar.Visible = ActuallyVisible;
            if (m_hairAccessory != null)
                m_hairAccessory.Avatar.Visible = ActuallyVisible;
            if (m_backDecoration != null)
                m_backDecoration.Avatar.Visible = ActuallyVisible;
            base.OnVisibleChange();
        }
        public virtual bool CanLeaveAttack
		{
			get
			{
				return false;
			}
		}

        public virtual bool IsTurn
        {
            get
            {
                return false;
            }
        }
        bool m_bFlyStunTrigger;
        public bool FlyStunTrigger
        {
            get
            {
                return m_bFlyStunTrigger;
            }
        }

        bool m_bStunTrigger;
		public bool StunTrigger
		{
			get
			{
				return m_bStunTrigger;
			}
		}

		// SM.MovableEntity.StunInfo m_stunInfo;
		// public SM.MovableEntity.StunInfo StunInfo
		// {
		// 	get
		// 	{
		// 		return m_stunInfo;
		// 	}
		// }

		bool m_movableInAttack = false;
		public bool MovableInAttack
		{
			get
			{
				return m_movableInAttack;
			}
			set
			{
				m_movableInAttack = value;
			}
		}

		protected bool m_enableGravity = true;
		public bool EnableGravity
		{
			set
			{
				m_enableGravity = value;
			}
			get
			{
				return m_enableGravity;
			}
		}

		public bool IsInDirectMove
		{
			get
			{
				return m_directMoveDistance > 0.0f;
			}
		}

        public bool IsInMove
        {
            get
            {
                if (m_sm != null)
                    return m_sm.CurStateID == SM.Entity.States.MOVE || m_sm.CurStateID == SM.Entity.States.RIDEMOVE;
                else
                    return false;
            }
        }

        public Vector3 DirectMoveTargetPos
        {
            get
            {
                return m_directMoveTargetPos;
            }
        }
        public override bool IsInClickFly
        {
            get
            {
                return false;
                //LogHelper.Log("[HC] IsInClickFly", m_stunInfo.effectType);
                // return m_sm!=null && m_sm.CurStateID == SM.Entity.States.STUN && (m_stunInfo.effectType == SM.MovableEntity.StunType.ClickFly
                //     || m_stunInfo.effectType == SM.MovableEntity.StunType.Immobile
                //     );
            }
        }

        float m_rotateSpeed = 15.0f;
		public float RotateSpeed
		{
			get
			{
				return m_rotateSpeed;
			}
			set
			{
				m_rotateSpeed = value;
			}
		}

        //dodage
        protected Vector3 m_dodageDestPos = Vector3.zero;

        uint m_dodgeDestPosVoxWorldID;

        [XLua.BlackList]
        public uint DodgeDestPosVoxWorldID
        {
            get
            {
                return m_dodgeDestPosVoxWorldID;
            }
            set
            {
                m_dodgeDestPosVoxWorldID = value;
            }
        }

        public Vector3 DodageDestPos
        {
            get
            {
                if (m_dodgeDestPosVoxWorldID == VoxelWorldID)
                    return m_dodageDestPos;
                else
                {
                    //LogHelper.Log("FallDestPos", m_falldestposVoxWorldID, VoxelWorldID);
                    Vector3 pos;// = m_falldestpos;
                    if (m_dodgeDestPosVoxWorldID != 0)
                        pos = MobileBlockMgr.Instance.LocalPos2WorldPos(m_dodageDestPos, m_dodgeDestPosVoxWorldID);
                    else
                        pos = m_dodageDestPos;
                    if (VoxelWorldID != 0)
                    {
                        pos = MobileBlockMgr.Instance.WorldPos2LocalPos(pos, VoxelWorldID);
                    }
                    //LogHelper.Log("FallDestPos", m_falldestposVoxWorldID, VoxelWorldID, pos);
                    //m_dodageDestPos = pos;                    
                    return pos;
                }

            }
            set
            {
               // m_dodgeDestPosVoxWorldID = VoxelWorldID;
                m_dodageDestPos = value;
            }
        }

        protected bool m_canContinueDodage = true;
        public bool CanContinueDodage { get { return m_canContinueDodage; } set { m_canContinueDodage = value; } }
        protected bool m_forbidMove = false;
        /// <summary>
        /// 是否禁止移动
        /// </summary>
        public bool forbidMove
        {
            get { return m_forbidMove; }
            set { m_forbidMove = value; }
        }

        #endregion

        public MovableEntity(ulong id) : base(id)
        {

        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public MovableEntity() : base()
        {
        }

        ~MovableEntity()
        {            
        }

        //变身代码

        private string m_curModelPath;
        public string CurModelPath
        {
            get
            {
                return m_curModelPath;
            }
            set
            {
                m_curModelPath = value;
            }
        }

        /// <summary>
        /// 是否在变身状态 
        /// </summary>
        public bool IsInTransform
        {
            get
            {
                return currentTransformId != 0;
            }
        }

        protected virtual void TransformAddtoScene(string _path)
        {
            base.OnAddToScene();
            DoLoadModel(_path);
        }

        protected virtual void DoLoadModel(string _path = "")
        {

        }

        /// <summary>
        /// 处理变身
        /// </summary>
        protected override void PorcTransformIdChange()
        {
            OnRefreshTransformationChange();
        }
        /// <summary>
        /// 获得当前变身模型 可能由多个数据来设置了  比如  载具的VehicleId  或者是变身buf决定的变身 
        /// </summary>
        /// <returns></returns>
        protected virtual string GetCurrentTransformationModel()
        {
            string _path = string.Empty;
            //string buffTransform = string.Empty;
            if ( currentTransformId != 0)
            {
                NpcTableBase?  _npcConfig = NpcTableManager.GetData((int)currentTransformId);
                if(_npcConfig.HasValue)
                {
                    _path = _npcConfig.Value.model;
                }
            }

//             if (!string.IsNullOrEmpty(buffTransform))
//             {
//                 _path = buffTransform;
//             }
//             else if (VehicleId != 0)
//             {
//                 //进入载具变化
//                 if (VehicleConfig != null && !string.IsNullOrEmpty(VehicleConfig.Value.model))
//                 {
//                     _path = VehicleConfig.Value.model;
//                 }
//             }
            return _path;
        }

        /// <summary>
        /// 刷新检查 模型是否变身变化了
        /// </summary>
        protected virtual void OnRefreshTransformationChange()
        {
            string strPath = GetCurrentTransformationModel();
            bool bIsSameModel = string.Equals(strPath, m_curModelPath);
            if (!bIsSameModel)
            {
                //和当前模型不一样
                PlayTransformationEffect(IsInTransform);
                if (IsInTransform)
                {
                    OnEnterTransformation();
                }
                else
                {
                    OnQuitTransformation();
                }

                DoLoadModel();
                onTransformationChange.Invoke(IsInTransform);
            }
        }

        /// <summary>
        /// 播放变身特效
        /// </summary>
        /// <param name="enter"></param>
        protected virtual void PlayTransformationEffect(bool enter)
        {
            EffectMgr.Instance.Play("fx_bianshen_dl_s", LocalPosition, null, true, enter ? 1 : 3);//播放变身特效
        }

        /// <summary>
        /// 进入变身 预处理
        /// </summary>
        protected virtual void OnEnterTransformation()
        {
            m_curModelPath = string.Empty;

        }
        /// <summary>
        /// 退出变身 后处理
        /// </summary>
        protected virtual void OnQuitTransformation()
        {
            
        }

        //结束变身代码

        public override void Release()
		{
			base.Release();
			if (m_primaryWeapon != null)
			{
				m_primaryWeapon.Release();
				m_primaryWeapon = null;
			}
			if (m_secondaryWeapon != null)
			{
				m_secondaryWeapon.Release();
				m_secondaryWeapon = null;
			}
            if (m_waist != null)
            {
                m_waist.Release();
                m_waist = null;
            }
            if (m_hairAccessory != null)
            {
                m_hairAccessory.Release();
                m_hairAccessory = null;
            }
            if (m_backDecoration != null)
            {
                m_backDecoration.Release();
                m_backDecoration = null;
            }
		}

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public override void ResetEntity()
        {
            base.ResetEntity();
            
            OnQingKungEnter.RemoveAllListeners();
            OnQingKungStay.RemoveAllListeners();
            OnQingKungLeave.RemoveAllListeners();
            OnJumpStartEvent.RemoveAllListeners();
            OnJumpStopEvent.RemoveAllListeners();
            OnMoveStopEvent.RemoveAllListeners();
            IsQingKungNormalFall = true;
            CanQingKungInterrupte = true;
            onMoveStop = null;
            m_destPos = Vector3.zero;
            m_lastdestPos = Vector3.zero;
            m_waypoints = null;
            m_directMoveCallback = null;
            m_directMoveDistance = 0.0f;
            m_directMoveDir = Vector3.zero;
            m_directMovePos = Vector3.zero;
            m_directMoveTargetPos = Vector3.zero;
            m_directMoveSpeed = 0.0f;

            m_speed = 2.5f;
            m_cc = null;
            m_motion = Vector3.zero;
            m_jumpTrigger = 0;
            m_flyTrigger = false;
            m_dodgeTrigger = false;
            m_godWeapon = null;
            m_bFlyStunTrigger = false;
            m_bStunTrigger = false;
            #region reset m_stuninfo
            // m_stunInfo.air_force = 0.0f;
            // m_stunInfo.destPos = Vector3.zero;
            // m_stunInfo.dir = Vector3.zero;
            // m_stunInfo.dis = 0.0f;
            // m_stunInfo.effectType = SM.MovableEntity.StunType.BeatBack;
            // m_stunInfo.end_time = 0.0f;
            // m_stunInfo.immtime = 0.0f;
            // m_stunInfo.speed = 0.0f;
            // m_stunInfo.start_time = 0.0f;
            // m_stunInfo.time = 0.0f;
            // m_stunInfo.vel = Vector3.zero;
            #endregion
            m_movableInAttack = false;
            m_enableGravity = true;
            m_rotateSpeed = 15.0f;
            m_dodageDestPos = Vector3.zero;
            m_canContinueDodage = true;
            m_firstSpineNodePos = Vector3.zero;
            m_SpineNode = null;
            #region reset EC
            //EC.controllerId = 0;
            //EC.current = null;
            EC.layer = 0;
            EC.fullPathHash = 0;
            //EC.tagHash = 0;
            #endregion
            TopTitleState = TopTitlePosState.End;
            m_bEmoteStunTrigger = false;
            m_sEmoteActionName = "";
            m_iEmoteInterruptType = 0;
            b_IsPlayEa = false;
            m_bIsEmoteMove = false;
            m_Jump2Trigger = 0;
            m_DeliveryTrigger = false;
            m_StopDeliveryTrigger = false;
            m_isEnterFly = false;
            m_curSkillConfig = null;
            m_curModelPath = string.Empty;

        }

        public virtual void Jump()
		{
			if (IsDingShen||IsYingZhi || Died)
				return;
			if (IsMainCharacter() && SkillManager.Instance.forceAttack.Target)
				return;
            if(this is Character)
            {
                var ch = this as Character;
                if(ch.Mount != null && ch.Mount.IsLandMount && ch.Mount.IsLandMode)
                {
                    ch.Mount.Jump();
                    ch.Mount.OnJumpStart();
                    return;
                }
            }
            m_jumpTrigger = 2;
		}

        public virtual void Dodge()
		{
			if (IsDingShen || IsYingZhi)
				return;
			if (IsMainCharacter() && SkillManager.Instance.forceAttack.Target)
				return;
			//RequestPlayAnim(ANIM_DODGE);
			m_dodgeTrigger = true;

		}

		public void Dizzy()
		{
            if (IsCharm)
                SetAnimID(SM.Entity.States.STUN, AnimatorStateID.CharmStart);
            else if (IsWeak)
                SetAnimID(SM.Entity.States.STUN, AnimatorStateID.WeakStart);
            else
                SetAnimID(SM.Entity.States.STUN, AnimatorStateID.StunStart);
			m_stunInfo.effectType = SM.MovableEntity.StunType.Dizzy;
		}

		// public void Stun(string animID, SM.MovableEntity.StunInfo stuninfo = default(SM.MovableEntity.StunInfo))
		// {
		// 	Stun(Animator.StringToHash(animID), stuninfo);
		// 	//SetAnimID(SM.Entity.States.STUN, Animator.StringToHash(animID));
		// 	//m_stunInfo = stuninfo;
		// 	//m_bStunTrigger = true;
		// }
		// public void Stun(int animID, SM.MovableEntity.StunInfo stuninfo = default(SM.MovableEntity.StunInfo))
		// {
        //     Stop(false);
		// 	SetAnimID(SM.Entity.States.STUN, animID);
		// 	m_stunInfo = stuninfo;
		// 	m_bStunTrigger = true;
        //     //LogHelper.Log("[HC]STUN!", m_stunInfo.effectType);
        // }
        public void FlyStun()
        {
            m_bFlyStunTrigger = true;
        }
        public virtual void OnJumpStart()
		{
            OnJumpStartEvent.Invoke();
        }
        public virtual void OnJumpStop()
		{
            OnJumpStopEvent.Invoke();
        }
        public override bool IsOnGround()
        {
            if (!UseGravity)
                return true;
            return base.IsOnGround();
        }

        protected override void OnVoxelWorldChange(uint oldid)
        {
            var dest = DestPos;
            var lastdest = LastDestPos;
            base.OnVoxelWorldChange(oldid);
            DestPos = MobileBlockMgr.Instance.ConvertPos(dest, oldid, VoxelWorldID);
            LastDestPos = MobileBlockMgr.Instance.ConvertPos(lastdest, oldid, VoxelWorldID);
            if(IsMainCharacter() || (IsMount()&&(this as Mount).Owner.IsMainCharacter()))
            {
                MobileBlockMgr.Instance.SendEnterVoxelWorld(ThisID, VoxelWorldID, Position);
            }
        }

        protected override void OnDataUpdate()
		{
			base.OnDataUpdate();
		
			if(m_data!=null)
				m_speed = m_data.move_speed / 1000.0f;
		}

        public override void DumpMapEntityData(swm.MapEntityDataT data)
        {
            base.DumpMapEntityData(data);

            data.move_speed = (uint)(speed * 1000);
        }
        public override void SetData(swm.MapEntityDataT data)
        {
            base.SetData(data);
            LogicPostition = data.cur_pos.Vec3();
            //Position = GetAdjustGroundPosition();
        }
        [XLua.BlackList]
        public override void ResetStateForDrama()
        {
            Stop();
            base.ResetStateForDrama();
        }
        protected override void OnActivedChange()
        {
            base.OnActivedChange();
            if(Actived)
                Position = GetAdjustGroundPosition();
        }

        public override void SetNetData(swm.SyncMainUserData _data)
        {
            base.SetNetData(_data);
            CheckInteractionState();
        }

        public void RefreshTaskState(NpcTaskStateInfo _info, bool _bIsCheck = true)
        {
            if (EntityMissionState != _info)
            {
                bool _bIsChange = true;
                if (EntityMissionState != null && _info != null &&
                    EntityMissionState.NpcTaskInfoState == _info.NpcTaskInfoState &&
                   EntityMissionState.RoleTaskInfoType == _info.RoleTaskInfoType)
                {
                    _bIsChange = false;
                }

                EntityMissionState = _info;
                if (_bIsCheck && _bIsChange)
                {
                    OnRefreshMissionState.Invoke();
                    m_onRefreshTaskState.Invoke(this);
                }
            }
        }
        public void RefreshMissionState(bool _bIsCheck = true)
        {
            NpcTaskStateInfo _info = MissionModel.Instance.GetNpcMissionState(BaseID);
            RefreshTaskState(_info, _bIsCheck);
        }

        public override void SetNetData(swm.MapEntityData _data)
        {
            base.SetNetData(_data);

            CheckInteractionState();
        }
        protected override void SetNetDataEnd()
        {
            if (m_data.state_data.move != null)
            {
                var move = m_data.state_data.move;
                DestPos = move.tpos.Vec3();
                Position = move.curpos.Vec3();
                Direction = DestPos - Position;
                StateMachine.Resume(SM.Entity.States.MOVE);
            }
            else if (m_data.state_data.jump != null)
            {
                var jump = m_data.state_data.jump;
                DestPos = jump.tpos.Vec3();
                Position = jump.curpos.Vec3();
                Direction = DestPos - Position;
                var dur = (jump.curtime - jump.starttime) / 1000.0f;
                StateMachine.Resume(SM.Entity.States.JUMP, dur);
            }
            else if (m_data.state_data.jump2 != null)
            {
                var jump2 = m_data.state_data.jump2;
                DestPos = jump2.tpos.Vec3();
                Position = jump2.curpos.Vec3();
                Direction = DestPos - Position;
                var dur = (jump2.curtime - jump2.starttime) / 1000.0f;
                StateMachine.Resume(SM.Entity.States.JUMP2, dur);
            }
            else if (m_data.state_data.fall != null)
            {
                var fall = m_data.state_data.fall;
                DestPos = fall.tpos.Vec3();
                Position = fall.curpos.Vec3();
                Direction = DestPos - Position;
                var dur = (fall.curtime - fall.starttime) / 1000.0f;
                StateMachine.Resume(SM.Entity.States.FALL, dur);
            }else if(m_data.ai_data != null && m_data.ai_data.cur_action > 0)
            {
                uint id = m_data.ai_data.cur_action;
                CommonType = MovableEntity.ActionType.Common;
                CommonTrunPos = Vector3.zero;
                CommonActionId = id;

                StateMachine.Resume(SM.Entity.States.ACTION);
            }
            else if(m_data.interaction_id > 0)
            {
                CommonType = MovableEntity.ActionType.Interaction;
                interaction_pos = m_data.cur_pos.Vec3();
                interaction_dir = m_data.cur_dir.Vec3();
                StateMachine.Resume(SM.Entity.States.ACTION);
            }

            base.SetNetDataEnd();
        }
        /// <summary>
        /// 检测交互点
        /// </summary>
        protected virtual void CheckInteractionState()
        {
            // 占领交互点
            if (interaction_id <= 0)
                return;

            CommonType = MovableEntity.ActionType.Interaction;
            CommonTrunPos = UnityEngine.Vector3.zero;
            CommonActionId = interaction_action;

            interactionInfo.interaction_id = interaction_id;
            interactionInfo.action_id = interaction_action;
            interactionState = MovableEntity.InteractionState.EnterIdle;

            OnInteractionPointLoadedEvent();
        }

        private void OnInteractionPointLoadedEvent()
        {
            if (interaction_id <= 0)
                return;

            // 这里如果在交互点的话, 直接同步交互点位置
            // 如果九屏同步位置和交互点位置偏差比较大的话,信任交互点位置
            var seat = InteractionPointManager.Instance.GetInterationActionTypeFromID((int)interaction_id);
            if (seat != null)
            {
                Position = seat.startPosition;
                Direction = seat.startForward;
            }
        }
        public override void OnAddToScene()
        {
            base.OnAddToScene();

            InteractionPointManager.Instance.interactionPointLoadedEvent.AddListener(OnInteractionPointLoadedEvent);
        }

		protected override void CreateStateMachine()
		{
			m_sm = SM.Factory.CreateSM(this);
		}

        protected override void ReleaseStateMachine()
        {
            SM.Factory.ReleaseMovableEntitySM(m_sm);
            m_sm = null;
        }
        // protected override void OnPostStateChange(SM.Entity.States preState, SM.Entity.States curState)
        // {
		// 	base.OnPostStateChange(preState, curState);
        //     if(preState == SM.Entity.States.QingKungPeakStay)
        //     {
        //         if(curState == SM.Entity.States.QingKungEnter || curState == SM.Entity.States.QingKungGliding)
        //         {
        //             if(OnQingKungStay != null)
        //                 OnQingKungStay.Invoke(false);
        //         }
        //     }
        //     if (curState == SM.Entity.States.QingKungPeakStay)
        //     {
        //         if (OnQingKungStay != null)
        //             OnQingKungStay.Invoke(true);
        //     }
        // }

		protected override void OnAvatarCreateDelegate()
		{
			base.OnAvatarCreateDelegate();

            m_SpineNode = Avatar.GetAttachmentTransform(AvatarAttachment.Spine);
            if (m_SpineNode) m_firstSpineNodePos = m_SpineNode.position - Avatar.unityObject.transform.position;
            //m_SkillEffect.Destory();
            Avatar.onAnimEvent += onAnimEvent;

            ArtConfig = Avatar.unityObject.GetComponentInChildren<Bokura.ArtConfigComponent>();
        }

        public override void OnRemoveFromScene()
        {
            base.OnRemoveFromScene();

            DelAllHpHurtEffect();

            InteractionPointManager.Instance.interactionPointLoadedEvent.RemoveListener(OnInteractionPointLoadedEvent);

            //DelAllEffect();
            //m_ProfessionSkillList.Clear();
            //m_ProfessionSubSkillList.Clear();
            //m_SkillShow.OnDestory();
            //m_SkillEffect.Destory();
        }

        [XLua.BlackList]
        public void LookAtTarget(Vector3 pos,float duration = 2, bool restrain = false)
        {
            if (Avatar.animator != null)
            {
                Avatar.animator.LookAtTarget(pos, duration, restrain);
            }
        }
        [XLua.BlackList]
        public void SetMaxWeight(float maxWeight)
        {
            if (Avatar.animator != null)
            {
                Avatar.animator.SetMaxWeight(maxWeight);
            }
        }

        public void SetHp()
        {

        }

        public void ResetHp()
        {

        }
        public void DelHpHurtEffect(int index)
        {            
            GameObject.Destroy(DamageEffectArr[index]);
            DamageEffectArr.RemoveAt(index);
        }

        public void DelAllHpHurtEffect()
        {
            DamageEffectArr.Clear();
        }
        public void PlayEffect(string effect_name, AvatarAttachment _bind)
        {
			EffectMgr.Instance.Play(effect_name, this);
        }

        public virtual void Stop(bool sendstopmsg = true)
		{
            //LogHelper.Log("[HC]MovableEntity Stop");

            if (m_destPos!=Position)
			{
                var arrive = IsArriveTarget();
                DestPos = Position;
                OnMoveStop(arrive);                
            }
            else
            {
                OnMoveStop(true, sendstopmsg);
            }
			if(IsInDirectMove)
			{

				m_directMoveDistance = 0.0f;
				if (m_directMoveCallback != null)
				{
					m_directMoveCallback(true);
					m_directMoveCallback = null;
				}
			}
		}

        public virtual int BlinkTo(Vector3 target, float speed)
        {
            if (target == Position)
                return 0;           
            DirectMoveTo(target, speed, (bool barrive) =>
            {
            });            
            return 0;
        }
        private float DetectGroundOffsetUp = 1f;
        protected static float EnterVoxelWorldThreshold = 0.5f;
        public override float GetGroundDistance()
        {
            if (CC == null)
                return base.GetGroundDistance();
            //根据碰撞盒来判断是否在地面。
            var raypos = new UnityEngine.Vector3(LocalPosition.x, CC.bounds.min.y + CC.radius + DetectGroundOffsetUp, LocalPosition.z);
            RaycastHit hitinfo;
            if (!Utilities.SphereCast(raypos, CC.radius, UnityEngine.Vector3.down, out hitinfo, 1000))
            {
                return 1000.0f;
            }
            
            if(raypos.y < hitinfo.point.y)
            {
                Bokura.LogHelper.LogError("ray error. ray:", raypos.ToString(), hitinfo.point.ToString());
                return 0.0f;
            }
            var dis = (raypos.y - hitinfo.point.y) - CC.radius - DetectGroundOffsetUp;

            //TODO：需要移动到一个更好的位置
            if (IsMainCharacter() && StateMachine.CurStateID!= SM.Entity.States.STUN )
            {
                uint voxid;
                if (dis < EnterVoxelWorldThreshold)
                    voxid = (uint)MobileBlockMgr.Instance.GetBlockIDByGameObject(hitinfo.collider.gameObject);
                else
                    voxid = 0;
                if (voxid != VoxelWorldID)
                {
                    VoxelWorldID = (uint)voxid;
                    //LogHelper.Log("[HC]Ground dis", dis);
                }
                //Bokura.LogHelper.Log("[GetGroundDistance]", dis);

            }
            return dis;
        }

        [XLua.BlackList]
        public virtual void SimulateLogicPosition()
        {
            float step;
            Vector3 curmovedir;
            Utility.LerpMove(LogicPostition, DestPos, speed * Time.deltaTime, out step, out curmovedir, false);
            LogicPostition += curmovedir * step;

        }

        Vector3 m_prevRaycastPos;
       
        public virtual Vector3 GetAdjustGroundPosition()
        {
            if (LogicPostition == Vector3.zero)
                return Position;
            if (m_prevRaycastPos.x == m_position.x && m_prevRaycastPos.z == m_position.z )
                return m_prevRaycastPos;
            var rayoffset = Mathf.Clamp((DestPos - LogicPostition).y, 2, 5);
            //var rayoffset = 0.0f;

            RaycastHit hitinfo;
            //var src = LogicPostition.WorldToUnityVec() + new Vector3(0, rayoffset, 0);
            var src = Position.WorldToUnityVec() + new Vector3(0, rayoffset, 0);
            if (!Physics.Raycast(src, Vector3.down, out hitinfo, 10.0f, (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction.Ignore))
            {
                return Position;
            }

            m_prevRaycastPos = new Vector3(Position.x, hitinfo.point.y, Position.z);
            return m_prevRaycastPos;
            //return new Vector3(Position.x, LogicPostition.y - hitinfo.distance + rayoffset, Position.z);
        }
        public virtual void setMotion(float x, float z)
		{
            //if (!IsMainCharacter() && IsCharacter())
            //{
            //    if(m_motion.x!=x||m_motion.z!=z)
            //        LogHelper.Log("[HC]SetMotion", x, z);
            //}

            m_motion.x = x;
			m_motion.z = z;
           
		}
		public virtual void setMotionY(float y)
		{
            if (IsMainCharacter())
            {
                //if(m_motion.y!=y)
                //    LogHelper.Log("[HC]SetMotionY", y);
            }
            m_motion.y = y;
		}
        public virtual void resetMotion()
        {
            m_motion = Vector3.zero;
        }
        public virtual int MoveTo(Vector3 p, OnMoveStopDelegate onstop = null)
		{
            //LogHelper.Log("[HC]MoveTo ", this.ToString(), p.ToString());
            var tCallback = onMoveStop;
			onMoveStop = onstop;
			if (tCallback != null)
				tCallback(false);

			DestPos = p;
            m_lastdestPos = p;
            if(!IsNeedMove())
            {
                onMoveStop = null;
                DestPos = Position;

                if (onstop!=null)
                    onstop(true);
            }

			return 0;
		}

		public virtual void DirectMoveTo(Vector3 p, float speed, OnMoveStopDelegate onstop)
		{
			if (m_directMoveDistance > 0.0f && m_directMoveCallback != null)
				m_directMoveCallback(false);
            m_directMoveTargetPos = p;
			m_directMovePos = Position;
			m_directMoveDir = (p - m_directMovePos);
			m_directMoveDistance = m_directMoveDir.magnitude;
			if(m_directMoveDistance>0.0f)
			{
				m_directMoveDir.Normalize();
				m_directMoveSpeed = speed;
			}
			else
			{
				if(onstop!=null)
				{
					onstop(true);
				}
				return;
			}
			m_directMoveCallback = onstop;
		}
		public virtual void MoveByWayPoint(Vector3[] wpts, int nOffset, OnMoveStopDelegate onstop)
		{
			if(nOffset==0)
			{
				m_waypoints = wpts;
				
			}
			if (m_waypoints == null || nOffset >= m_waypoints.Length)
			{
                if(onstop != null)
                    onstop(true);
				return;
			}

            Vector3 v = (wpts[nOffset] - Position).normalized;
            v.y = 0;
            Direction = v;
            //LogHelper.Log("[HC]MoveByWayPoint", nOffset, wpts.Length);
            MoveTo(wpts[nOffset], (bool barrive) =>
			{
                //LogHelper.Log("[HC]MoveByWayPoint Stop", barrive, nOffset, wpts.Length);
                if (barrive)
				{
					MoveByWayPoint(m_waypoints, nOffset + 1, onstop);
				}
				else
				{
					if (onstop != null)
						onstop(false);
				}
			});
		}
		/// <summary>
		/// 清理路点数据
		/// </summary>
		public void ClearWayPoints()
		{
			m_waypoints = null;
		}
		public void SyncNetMove(Vector3 from, Vector3 to)
		{
			MoveTo(to, null);
		}
        

        public override void Update()
		{
            if (onMoveStop != null && IsArriveTarget())
                Stop();

            base.Update();
            if(m_sm!=null)
            {
                m_jumpTrigger--;
                Jump2Trigger--;
                m_dodgeTrigger = false;
                m_bStunTrigger = false;
                m_bFlyStunTrigger = false;
                FlyTrigger = false;
            }
            UpdateDirectMoveToTargetPos();
            Utilities.ProfilerBegin("Entity.UpdateTopTitle");
            {
                UpdateTopTitle();
                if (m_TopTitleOffsetBySkill)
                    UpdateSkillTopTitleOffset();

            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("Entity.UpdateWeapon");
            {
                UpdateWeapon();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("Entity.OnEventUpdate");
            {

                OnEventUpdate();
            }
            Utilities.ProfilerEnd();

#if !RELEASE
            if (GameApplication.ShowTestCube)  UpdateDebugInfo();
#endif
        }

        private bool m_TopTitleOffsetBySkill = false;
        public void SetTopTitleOffsetBySkill(bool enable)
        {
            m_TopTitleOffsetBySkill = enable;
        }
        private void UpdateSkillTopTitleOffset()
        {
            TopTitleOffset = GetSpineOffset();
            if (TopTitleEvent != null)
                TopTitleEvent.Invoke();
        }

        public Vector3 GetSpineOffset() {
            return m_SpineNode.transform.position - Avatar.unityObject.transform.position - m_firstSpineNodePos;
        }

        public virtual bool IsArriveTarget()
        {
            return !IsNeedMove();
        }

        private Vector3 m_firstSpineNodePos;
        private Transform m_SpineNode;
        private Magic.MagicContext EC;
        private enum TopTitlePosState { Changing, Ending, End}
        private TopTitlePosState TopTitleState = TopTitlePosState.End;
        protected virtual void onAnimEvent(Magic.MagicContext context, AnimEvent animEvent, List<EventParam> paramlist)
        {
            //LogHelper.LogFormat("onAnimEvent {0}", eventName);
            switch(animEvent)
            {
                case AnimEvent.RefreshTopTitle:
                    EC = context;
                    TopTitleState = TopTitlePosState.Changing;
                    break;
                case AnimEvent.SwitchWeaponToLeftHand:
                    if (PrimaryWeapon != null && PrimaryWeapon.Attachment != AvatarAttachment.LeftHandProp)
                        PrimaryWeapon.Attachment = AvatarAttachment.LeftHandProp;
                    break;
                case AnimEvent.SwitchWeaponToRightHand:
                    if (PrimaryWeapon != null && PrimaryWeapon.Attachment != AvatarAttachment.RightHandProp)
                        PrimaryWeapon.Attachment = AvatarAttachment.RightHandProp;
                    break;
                case AnimEvent.SwitchWeaponToBack:
                    if (PrimaryWeapon != null && PrimaryWeapon.Attachment != AvatarAttachment.Back && !IsInAttackState)
                        PrimaryWeapon.Attachment = AvatarAttachment.Back;
                    break;
                case AnimEvent.SwitchShieldToLeftHand:
                    if (SecondaryWeapon != null && SecondaryWeapon.Attachment != AvatarAttachment.LeftHandProp)
                    {
                        SecondaryWeapon.Attachment = AvatarAttachment.LeftHandProp;
                        SecondaryWeapon.Show(true);
                    }
                    break;
                case AnimEvent.SwitchShieldToBack:
                    if (SecondaryWeapon != null && SecondaryWeapon.Attachment != AvatarAttachment.Back)
                        SecondaryWeapon.Attachment = AvatarAttachment.Back;
                    break;
                case AnimEvent.HideAvatar:
                    VisibleByAction = false;
                    break;
                case AnimEvent.ShowAvatar:
                    VisibleByAction = true;
                    break;
                case AnimEvent.HidePWeapon:
                    PrimaryWeapon?.ShowByAction(false);
                    break;
                case AnimEvent.ShowPWeapon:
                    PrimaryWeapon?.ShowByAction(true);
                    break;
                case AnimEvent.HideSWeapon:
                    SecondaryWeapon?.ShowByAction(false);
                    break;
                case AnimEvent.ShowSWeapon:
                    SecondaryWeapon?.ShowByAction(true);
                    break;
                case AnimEvent.HidePWeaponAndRevert:
                    ChangePWeaponVisible(context.fullPathHash, MagicType.Mecanim, false);
                    break;
                case AnimEvent.HideSWeaponAndRevert:
                    ChangeSWeaponVisible(context.fullPathHash, MagicType.Mecanim, false);
                    break;
                case AnimEvent.ShowPWeaponAndRevert:
                    ChangePWeaponVisible(context.fullPathHash, MagicType.Mecanim, true);
                    break;
                case AnimEvent.ShowSWeaponAndRevert:
                    ChangeSWeaponVisible(context.fullPathHash, MagicType.Mecanim, true);
                    break;
                case AnimEvent.SwitchWeaponToLeftHandAndRevert:
                    if (PrimaryWeapon != null /*&& PrimaryWeapon.Attachment != AvatarAttachment.LeftHandProp*/)
                    {
                        var attachment = PrimaryWeapon.Attachment;
                        AddRevertEvent(RevertEventEnum.RevertSwitchWeapon, context.fullPathHash, () =>
                        {
                            PrimaryWeapon.Attachment = attachment;
                        });
                        PrimaryWeapon.Attachment = AvatarAttachment.LeftHandProp;
                    }
                    break;
                case AnimEvent.SwitchWeaponToRightHandAndRevert:
                    if (PrimaryWeapon != null /*&& PrimaryWeapon.Attachment != AvatarAttachment.RightHandProp*/)
                    {
                        var attachment = PrimaryWeapon.Attachment;
                        AddRevertEvent(RevertEventEnum.RevertSwitchWeapon, context.fullPathHash, () =>
                        {
                            PrimaryWeapon.Attachment = attachment;
                        });
                        PrimaryWeapon.Attachment = AvatarAttachment.RightHandProp;
                    }
                    break;
                case AnimEvent.SwitchWeaponToBackAndRevert:
                    if (PrimaryWeapon != null /*&& PrimaryWeapon.Attachment != AvatarAttachment.Back*/)
                    {
                        var attachment = PrimaryWeapon.Attachment;
                        AddRevertEvent(RevertEventEnum.RevertSwitchWeapon, context.fullPathHash, () =>
                        {
                            PrimaryWeapon.Attachment = attachment;
                        });
                        PrimaryWeapon.Attachment = AvatarAttachment.Back;
                    }
                    break;
                case AnimEvent.HideAvatarAndRevert:
                    ChangeAvatarVisible(context.fullPathHash, MagicType.Mecanim, false);
                    break;
                case AnimEvent.DodgeEnd:
                    CanContinueDodage = true;
                    break;
                case AnimEvent.QingKungEnd:
                    if (IsCharacter())
                        (this as Character).CanContinueQingKung = true;
                    break;
                case AnimEvent.Take:
                    if(StateMachine.CurStateID == SM.Entity.States.ATTACK_IDLE || StateMachine.CurStateID ==  SM.Entity.States.IDLE)
                        RefreshPrimaryWeaponPos();
                    break;
                case AnimEvent.DestoryGameObject:
                    if (paramlist != null && paramlist.Count > 0)
                        ActionEffectManager.Instance.DestoryGameObject(Avatar.unityObject,paramlist[0].paramType);
                    break;
            }

            StateMachine.OnAnimationEvent(animEvent);
        }

        #region AnimEvent
        protected enum RevertEventEnum{ RevertPrimaryWeapon, RevertSecondaryWeapon, RevertSwitchWeapon, RevertAvatarVisibility }
        
 
        protected void AddRevertEvent(RevertEventEnum e,int actionid,Action action)
        {
            if (Avatar == null || Avatar.animator == null) return;
            KeyValuePair<int, Action> v;
            if(!AnimRevertEvents.TryGetValue(e,out v))
            {
                AnimRevertEvents.Add(e, new KeyValuePair < int, Action >(actionid, action));
            }
            else
            {
                if (Avatar != null && Avatar.animator != null)
                {
                    var curhashid = Avatar.GetCurrentAnimatorStateInfo(0).fullPathHash;
                    var nexthashid = Avatar.GetNextAnimatorStateInfo(0).fullPathHash;
                    if(v.Key == curhashid && actionid == nexthashid)
                    {
                        AnimRevertEvents[e] = new KeyValuePair<int, Action>(nexthashid, v.Value);
                    }
                }

            }
        }
        List<RevertEventEnum> delEvents = new List<RevertEventEnum>(Bokura.ConstValue.kCap8);
        Dictionary<RevertEventEnum, KeyValuePair<int, Action>> AnimRevertEvents = new Dictionary<RevertEventEnum, KeyValuePair<int, Action>>(Bokura.ConstValue.kCap8);   
        protected void OnEventUpdate()
        {
            if (Avatar == null || Avatar.animator == null) return;
            var curhashid = Avatar.GetCurrentAnimatorStateInfo(0).fullPathHash;
            var nexthashid = Avatar.GetNextAnimatorStateInfo(0).fullPathHash;
            foreach (var kv in AnimRevertEvents)
            {
                if(kv.Value.Key != curhashid && kv.Value.Key  != nexthashid)
                {
                    delEvents.Add(kv.Key);
                    kv.Value.Value.Invoke();
                }
            }
            foreach (var del in delEvents)
            {
                AnimRevertEvents.Remove(del);
            }
            delEvents.Clear();
        }
        /// <summary>
        /// Change primary weapon's visibility, when timeline interrupted revert,
        /// it is used for mecanim and skill
        /// </summary>
        /// <param name="tFullPathHash"> Context anim full path hash </param>
        /// <param name="tType"> Which magic type </param>
        /// <param name="tIsVisible"> Is visible or not after changing </param>
        public void ChangePWeaponVisible(int tFullPathHash, MagicType tType, bool tIsVisible)
        {
            if (PrimaryWeapon != null)
            {
                bool show;
                switch (tType)
                {
                    case MagicType.Mecanim:
                        show = PrimaryWeapon.IsShowByAction;
                        AddRevertEvent(RevertEventEnum.RevertPrimaryWeapon, tFullPathHash, () =>
                        {
                            PrimaryWeapon?.ShowByAction(show);
                        });
                        PrimaryWeapon.ShowByAction(tIsVisible);
                        break;
                    case MagicType.Skill:
                        show = PrimaryWeapon.IsShowBySkill;
                        AddRevertEvent(RevertEventEnum.RevertPrimaryWeapon, tFullPathHash, () =>
                        {
                            PrimaryWeapon?.ShowBySkill(show);
                        });
                        PrimaryWeapon.ShowBySkill(tIsVisible);
                        break;
                }
            }
        }

        /// <summary>
        /// Change second weapon's visibility, when timeline interrupted revert,
        /// it is used for mecanim and skill
        /// </summary>
        /// <param name="tFullPathHash"> Context anim full path hash </param>
        /// <param name="tType"> Which magic type </param>
        /// <param name="tIsVisible"> Is visible or not after changing </param>
        public void ChangeSWeaponVisible(int tFullPathHash, MagicType tType, bool tIsVisible)
        {
            if (SecondaryWeapon != null)
            {
                bool show;
                switch (tType)
                {
                    case MagicType.Mecanim:
                        show = SecondaryWeapon.IsShowByAction;
                        AddRevertEvent(RevertEventEnum.RevertSecondaryWeapon, tFullPathHash, () =>
                        {
                            SecondaryWeapon?.ShowByAction(show);
                        });
                        SecondaryWeapon.ShowByAction(tIsVisible);
                        break;
                    case MagicType.Skill:
                        show = SecondaryWeapon.IsShowBySkill;
                        AddRevertEvent(RevertEventEnum.RevertSecondaryWeapon, tFullPathHash, () =>
                        {
                            SecondaryWeapon?.ShowBySkill(show);
                        });
                        SecondaryWeapon.ShowBySkill(tIsVisible);
                        break;
                }
            }
        }

        /// <summary>
        /// Change avatar's visibility, when timeline interrupted revert,
        /// it is used for mecanim and skill
        /// </summary>
        /// <param name="tFullPathHash"> Context anim full path hash </param>
        /// <param name="tType"> Which magic type </param>
        /// <param name="tIsVisible"> Is visible or not after changing </param>
        public void ChangeAvatarVisible(int tFullPathHash, MagicType tType, bool tIsVisible)
        {
            bool iVisibility;
            switch (tType)
            {
                case MagicType.Mecanim:
                    iVisibility = VisibleByAction;
                    VisibleByAction = tIsVisible;
                    AddRevertEvent(RevertEventEnum.RevertAvatarVisibility, tFullPathHash, () =>
                    {
                        VisibleByAction = iVisibility;
                    });
                    break;
                case MagicType.Skill:
                    iVisibility = VisibleBySkill;
                    VisibleBySkill = tIsVisible;
                    AddRevertEvent(RevertEventEnum.RevertAvatarVisibility, tFullPathHash, () =>
                    {
                        VisibleBySkill = iVisibility;
                    });
                    break;
            }
        }

        public void UpdateTopTitle()
        {
            if (TopTitleState != TopTitlePosState.End)
            {
                if (TopTitleState == TopTitlePosState.Ending)
                {
                    if (TopTitleOffset.magnitude > 0.01f)
                        TopTitleOffset *= 0.5f;
                    else
                    {
                        TopTitleOffset = Vector3.zero;
                        TopTitleState = TopTitlePosState.End;
                    }
                }
                else
                {
                    var stateinfo = Avatar.GetCurrentAnimatorStateInfo(EC.layer);
                    var nextstateinfo = Avatar.GetNextAnimatorStateInfo(EC.layer);
                    //var instancecode = Avatar.animator.runtimeAnimatorController.GetInstanceID();

                    //if (instancecode == EC.controllerId)
                    {
                        if (stateinfo.fullPathHash != EC.fullPathHash && nextstateinfo.fullPathHash != EC.fullPathHash)
                        {
                            TopTitleState = TopTitlePosState.Ending;
                        }
                        else if (m_SpineNode)
                        {
                            TopTitleOffset = m_SpineNode.transform.position - Avatar.unityObject.transform.position - m_firstSpineNodePos;
                            //GameScene.RefreshCube(m_data.entity_id, pos, Color.blue); //���Դ���
                        }
                        else
                        {
                            TopTitleState = TopTitlePosState.Ending;
                        }
                    }
                    //else
                    //{
                    //    TopTitleState = TopTitlePosState.Ending;
                    //}
                }

                if (TopTitleEvent != null)
                    TopTitleEvent.Invoke();
            }
        }
        #endregion


        public void UpdateDirectMoveToTargetPos()
        {
            if (IsInDirectMove)
            {
                float curMoveDistance = m_directMoveSpeed * Time.deltaTime;
                if (curMoveDistance > m_directMoveDistance)
                {
                    curMoveDistance = m_directMoveDistance;
                    m_directMoveDistance = 0.0f;
                }
                else
                {
                    m_directMoveDistance -= curMoveDistance;
                    if (m_directMoveDistance < 0.0f)
                        m_directMoveDistance = 0.0f;
                }

                ApplyMove(m_directMoveDir * curMoveDistance);

                if ((m_directMoveDistance <= 0.01f) && m_directMoveCallback != null)
                {
                    m_directMoveDistance = 0.0f;
                    m_directMoveCallback(true);
                    m_directMoveCallback = null;
                }
            }
        }
        public enum MagicType { Mecanim, Skill }

        public void UpdateWeapon()
        {
            if (m_primaryWeapon != null)
            {
                m_primaryWeapon.Update();
            }
            if (m_secondaryWeapon != null)
            {
                m_secondaryWeapon.Update();
            }
        }

#if !RELEASE

        protected Mesh debugMeshInfo = new Mesh();
        protected Material debugMaterial = null;
        
        protected void UpdateDebugInfo()
        {
            if(debugMaterial == null)
            {
                var shader = ResourceHelper.LoadShaderSync("shaders/", "Alpha-Diffuse") as Shader;//Shader.Find("X2M/Transparent/Diffuse");
                //TriangleMaterial = new Material(shader);
                //TriangleMaterial.SetColor("_Color", new Color(0, 0.75f, 1, 0.5f));
                debugMaterial = new Material(shader);
                debugMaterial.SetColor("_Color", new Color(0, 0, 1, 0.7f));
            }
            var dest = DestPos;
            if (VoxelWorldID != 0)
                dest = MobileBlockMgr.Instance.LocalPos2WorldPos(dest, VoxelWorldID);

            //debugMeshInfo.SetVertices(new List<Vector3>() { Vector3.zero, dest.WorldToUnityVec() - LocalPosition, Vector3.zero, LastDestPos.WorldToUnityVec() - LocalPosition });
            //debugMeshInfo.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            //debugMeshInfo.SetIndices(new int[] { 0,1, 2, 3 }, MeshTopology.Lines, 0);

            debugMeshInfo.SetVertices(new List<Vector3>() { Vector3.zero, dest.WorldToUnityVec() - LocalPosition});
            debugMeshInfo.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            debugMeshInfo.SetIndices(new int[] { 0, 1}, MeshTopology.Lines, 0);

            //Graphics.DrawMesh(debugMeshInfo, LocalPosition + new Vector3(0, 1, 0), Quaternion.identity, debugMaterial, 0);
            Graphics.DrawMesh(debugMeshInfo, LocalPosition, Quaternion.identity, debugMaterial, 0);

            GameScene.SetTempCubePos((int)ThisID, (int)TempCubeColor.cyan, LogicPostition, Color.cyan);
            //GameScene.SetTempCubePos((int)ThisID, (int)TempCubeColor.yellow, Position, Color.yellow);
            //GameScene.SetTempCubePos((int)ThisID, (int)TempCubeColor.green, DestPos, Color.green);

            //GameScene.GetTempCube((int)ThisID, LogicPostition, Color.cyan);
        }
#endif
        public virtual void ApplyMove(Vector3 d)
		{
			Position += d;
		}
		protected virtual void OnMoveStart()
		{

		}
		protected virtual void OnMoveStop(bool arrive, bool sendstopmsg = true)
		{
			if (onMoveStop != null)
			{
				var tCallback = onMoveStop;
				onMoveStop = null;
				tCallback(arrive);
			}

            if (OnMoveStopEvent != null)
            {
                OnMoveStopEvent.Invoke();
            }
        }
        protected virtual void OnQingKungStart()
        {
            if (OnQingKungEnter != null)
                OnQingKungEnter.Invoke();
        }
        protected virtual void OnQingKungStop()
        {
            if (OnQingKungLeave != null)
                OnQingKungLeave.Invoke();
        }
        protected override void OnTimeLineChanged() {
            if(TimeLineing )
            {
                resetMotion();
                Syncer.PauseOutSync = true;
            }else
            {
                Syncer.PauseOutSync = false;
            }
        }
        protected override void OnIsInAttackChange()
		{
			base.OnIsInAttackChange();
			if(StateMachine !=null && (StateMachine.CurStateID != SM.Entity.States.IDLE && StateMachine.CurStateID != SM.Entity.States.ATTACK_IDLE && StateMachine.CurStateID != SM.Entity.States.ATTACK))
				RefreshPrimaryWeaponPos();
		}

		public void RefreshPrimaryWeaponPos()
		{
			if (PrimaryWeapon != null )
			{
                if (IsInAttack)
                    IntoHandWeaponState();
                else
                    OutHandWeaponState();

                
				//PrimaryWeapon.Attachment = GetPrimaryWeaponPos(IsInAttack);
				if(m_godWeapon !=null && m_godWeapon.IsShow)
				{
					m_godWeapon.Attachment = PrimaryWeapon.Attachment;
				}
			}
		}

		public  AvatarAttachment GetPrimaryWeaponPos( Weapon weapon)
		{
			if (IsInAttack || StateMachine.CurStateID == SM.Entity.States.ATTACK)
			{
               return weapon.SrcAttachment;
            }
			else 
			{
				return AvatarAttachment.Back;
			}
		}

        public bool IsQingKung()
        {
            if(m_sm != null)
                return IsQingKung(m_sm.CurStateID);
            return false;
        }
        public virtual bool IsNeedMove()
        {
            return IsNeedMoveByPos(m_destPos);
        }

        public virtual bool IsNeedMoveByPos(UnityEngine.Vector3 p)
        {
            if (IsDingShen)
                return false;
            var dx = Mathf.Abs(p.x - Position.x);
            var dy = Mathf.Abs(p.y - Position.y);
            var dz = Mathf.Abs(p.z - Position.z);

            float checkydis = FallCheckDistance;

            // 
            if (UseGravity)
            {
                checkydis = FallCheckDistanceByGround;
            }

            return speed > 0.0f && (dx > Utility.MoveMinDistance || dz > Utility.MoveMinDistance || dy > checkydis);
        }

		public float RotateToDestDir()
		{
			float angle;
			return RotateToOtherDestDir(DestPos, out angle, m_rotateSpeed);
		}
        public float RotateToOtherDestDir(Vector3 destpos)
        {
            float angle;
            return RotateToOtherDestDir(destpos, out angle, m_rotateSpeed);
        }
        public float RotateToDestDir( out float diffangle, float rotatespeed, bool useAccSpeed = true)
        {
            return RotateToOtherDestDir(DestPos, out diffangle, rotatespeed, useAccSpeed);
        }
        public float RotateToOtherDestDir(Vector3 destpos, out float diffangle, float rotatespeed, bool useAccSpeed=true)
		{
			var destdir = destpos - Position;
            if(VoxelWorldID!=0 && !IsMainCharacter())
                destdir = MobileBlockMgr.Instance.LocalDir2WorldDir(destdir, VoxelWorldID);
			destdir.y = 0;
			float destlen = destdir.magnitude;
			if (destlen < Utility.MoveMinDistance)
			{
				diffangle = 0.0f;
				return destlen;
			}
			destdir.Normalize();
			var destangle = Utilities.Vector2Angle(destdir.z, destdir.x);

			var curangle = DirAngle;
			diffangle = Utilities.AngleDiff(curangle, destangle);
			if(Mathf.Abs(diffangle)<1)
			{
				Direction = destdir;

			}
			else if(rotatespeed>0.0f)
			{
                float f;
                if(useAccSpeed)
                {
                    f = diffangle;
                }
                else
                {
                    f = diffangle > 0 ? 1.0f : -1.0f;
                }

                var d = f * Time.deltaTime * rotatespeed;

                if (diffangle > 0 && d > diffangle)
					d = diffangle;
				else if (diffangle < 0 && d < diffangle)
					d = diffangle;
				curangle -= d;
				curangle = Utilities.NormalizeAngle(curangle);
				DirAngle = curangle;
			
				//DirAngle = destangle;
			}
			return destlen;
		}
		public void ShowGodWeapon(bool bShow)
		{
			if(bShow)
			{
				if (m_godWeapon == null)
				{
					m_godWeapon = new Weapon();
					var config = SkillManager.Instance.GetGoldWeaponConfig(CareerType, 1);
					m_godWeapon.init(this, config.Value.model, !SyncLoad);
				}
				if (PrimaryWeapon != null)
				{
					PrimaryWeapon.Show(false);

					m_godWeapon.Attachment = PrimaryWeapon.Attachment;
				}
				m_godWeapon.Show(true);

			}
			else
			{
				if(m_godWeapon!=null)
				{
					m_godWeapon.Show(false);

				}
				if(PrimaryWeapon!=null)
				{
					PrimaryWeapon.Show(true);
				}
			}
		}

        //角色动作表情相关
        private bool m_bEmoteStunTrigger = false;
        public bool EmoteStunTrigger
        {
            get
            {
                return m_bEmoteStunTrigger;
            }
        }
        private string m_sEmoteActionName = "";
        public string EmoteActionName
        {
            get
            {
                return m_sEmoteActionName;
            }
        }
        private int m_iEmoteInterruptType= 0;
        public int EmoteInterruptType
        {
            get
            {
                return m_iEmoteInterruptType;
            }
        }
        private bool b_IsPlayEa = false;
        public bool IsPlayEa
        {
            set
            {
                b_IsPlayEa = value;
            }
            get
            {
                return b_IsPlayEa;
            }
        }

        public void EmoteStun(string actionname,int interrupttype)
        {
            m_bEmoteStunTrigger = true;
            m_sEmoteActionName = actionname;
            m_iEmoteInterruptType = interrupttype;
            b_IsPlayEa = false;
        }
        public void SetopEmoteStun()
        {
            m_bEmoteStunTrigger = false;
            m_sEmoteActionName = "";
            m_iEmoteInterruptType = 0;
        }
        public bool m_bIsEmoteMove = false;
        public bool IsEmoteMove
        {
            set
            {
                m_bIsEmoteMove = value;
            }
            get
            {
                return m_bIsEmoteMove;
            }
        }
        //角色动作表情相关 end

        private int m_Jump2Trigger;
        public int Jump2Trigger
        {
            get
            {
                return m_Jump2Trigger;
            }
            set
            {
                m_Jump2Trigger = value;
            }
        }
        //角色传送标志
        private bool m_DeliveryTrigger=false;
        public bool DeliveryTrigger
        {
            get
            {
                return m_DeliveryTrigger;
            }
            set
            {
                m_DeliveryTrigger = value;
            }
        }
        private bool m_StopDeliveryTrigger = false;
        public bool StopDeliveryTrigger
        {
            get
            {
                return m_StopDeliveryTrigger;
            }
            set
            {
                m_StopDeliveryTrigger = value;
            }
        }

        private bool m_isEnterFly = false;
        public bool isEnterFly
        {
            get
            {
                return m_isEnterFly;
            }
            set
            {
                m_isEnterFly = value;
                m_isEnterClientFly = value;
                SetAnimatorParamBool(Bokura.AnimatorParam.IsFlying, m_isEnterFly);
            }
        }

        private bool m_isEnterClientFly = false;
        public bool isEnterClientFly
        {
            get
            {
                return m_isEnterClientFly;
            }
            set
            {
                m_isEnterClientFly = value;
            }
        }

        public bool isCurrCloudEnterFly()
        {
            return (m_isEnterClientFly || m_isEnterFly);
        }

        public const float CLOUD_CHECK_ENTER_FLY_DISTANCE = 100;
        public void CheckClientEnterFly()
        {
            isEnterClientFly = (GetGroundDistance() >= CLOUD_CHECK_ENTER_FLY_DISTANCE);
        }

        public void SetCCRadius(float radius)
        {
            if (m_cc == null)
                return;

            m_cc.radius = radius;
        }

        /// <summary>
        /// 获取移动时间
        /// </summary>
        /// <param name="srcpos"></param>
        /// <param name="despos"></param>
        /// <returns></returns>
        public float GetMoveTime(Vector3 srcpos, Vector3 despos)
        {
            if (speed < 0.001f)
                return 0.0f;

            return Vector3.Distance(srcpos, despos) / speed;
        }
        public void Modify2TargetPos(Vector3 targetpos)
        {
            //float step;
            //Vector3 curmovedir;
            //Utility.LerpMove(Position, targetpos, 100.0f, out step, out curmovedir, false);

            //var detla = curmovedir * step;
            //setMotion(detla.x, detla.z);
            //setMotionY(detla.y);

            Position = targetpos;
        }

        public override void RemoveAllEffects()
        {
            base.RemoveAllEffects();
        }
        #region -------------------------技能吟唱相关--------------------------
        ulong m_chantStartTime;
        public SkillTableBase? CurSkillConfig
        {
            get
            {
                return m_curSkillConfig;
            }
        }
        private SkillTableBase? m_curSkillConfig = null;
        /// <summary>
        /// 吟唱技能状态改变事件
        /// </summary>
        public GameEvent<bool> onSkillChantStateChanged { get { return m_onSkillChantStateChanged; } }
        private GameEvent<bool> m_onSkillChantStateChanged = new GameEvent<bool>();
        public ulong ChantRemainTime//技能吟唱剩余时间
        {
            get
            {
                if (CurSkillConfig == null || CurSkillConfig.Value.id != CurCastingSkillID)
                {
                    m_curSkillConfig = SkillTableManager.GetData(CurCastingSkillID);
                }
                if (CurSkillConfig != null)
                {
                    return (ulong)CurSkillConfig.Value.sing_time - (GameScene.Instance.GetServerTime() - m_chantStartTime);
                }
                return 0;
            }
        }
        public int ChantTotalTime//技能吟唱总时间
        {
            get
            {
                if (CurSkillConfig == null || CurSkillConfig.Value.id != CurCastingSkillID)
                {
                    m_curSkillConfig = SkillTableManager.GetData(CurCastingSkillID);
                }
                if (CurSkillConfig != null)
                {
                    return CurSkillConfig.Value.sing_time;
                }
                return 0;
            }
        }
        public string ChantSkillName
        {
            get
            {
                if (CurSkillConfig == null || CurSkillConfig.Value.id != CurCastingSkillID)
                {
                    m_curSkillConfig = SkillTableManager.GetData(CurCastingSkillID);
                }
                if (CurSkillConfig != null)
                {
                    return CurSkillConfig.Value.name;
                }
                return "";
            }
        }
        /// <summary>
        /// 开始技能吟唱，记录开始的时间戳
        /// </summary>
        public void SetChantStartTime()
        {
            m_chantStartTime = GameScene.Instance.GetServerTime();
            m_onSkillChantStateChanged.Invoke(true);
        }
        #endregion -----------------------------------------------------------
    }
}
