#define MOVE_WORLD
using System;
using Bokura;
using Bokura.Common;
using UnityEngine;
using System.Collections.Generic;
using Magic;

namespace Bokura
{
    public class Npc : MovableEntity
    {

        #region 常量



        #endregion

        [XLua.BlackList]
        public class SpeakAiInfo
        {
            public bool isintriggerarea = false;    // 是否在触发区域

            public bool isspeaking = false;     // 是否正在说话

            public int nextspeakid = -1;         // 说话id

            public float speakstart = 0.0f;  // 当前说话开始时间

            public float speaktime = 2.0f;     // 说话时间

            public float speakiterval = 2.0f;    // 说话cd时间

            public void ResetSpeak()
            {
                isspeaking = false;
                nextspeakid = -1;
                speakstart = 0.0f;
            }
        }

        public enum FadeType
        {
            FadeIn,
            FadeOut
        }

        public class FadeInfo
        {
            public FadeType fadetype;
            public bool fadeing = false;
            public float starttime = 0.0f;
            public float life = 1.0f;

            public void Start(FadeType _fadetype, float _life)
            {
                fadeing = true;
                fadetype = _fadetype;
                starttime = Time.realtimeSinceStartup;
                life = _life;
            }

            public float GetAlpha()
            {
                float curtime = Time.realtimeSinceStartup;

                if (fadetype == FadeType.FadeIn)
                {
                    if (curtime < starttime)
                        return 0.0f;

                    return (curtime - starttime) / life;
                }
                else if (fadetype == FadeType.FadeOut)
                {
                    if (curtime < starttime)
                        return 1.0f;

                    return Mathf.Clamp01(1.0f - (curtime - starttime) / life);
                }

                return 0.0f;
            }
        }

        /// <summary>
        /// 淡入淡出信息
        /// </summary>
        private FadeInfo m_fadeInfo = new FadeInfo();

        /// <summary>
        /// 当前的动画id
        /// </summary>
        private int m_curAnimId = 0;
        const int NewSpawnCheck = 1000;
        const float SpawnDelay = 1.0f;
        private NpcTableBase? m_npcConfig;
        private WeaponTableBase? m_npcWeapon;
        private MonsterAttrTableBase? m_npcAttr;

        public MonsterAttrTableBase? NpcAttr
        {
            get
            {
                return m_npcAttr;
            }
        }
        public NpcTableBase? NpcConfig
        {
            get
            {
                return m_npcConfig;
            }
        }

        public override bool UseGravity
        {
            get
            {
                return base.UseGravity && !(NpcConfig != null && NpcConfig.Value.IsFly > 0);
            }
        }

        public override float speed
        {
            get
            {
                return base.speed;
            }
            set
            {
                base.speed = value;

            }
        }
        public float ModelScale { get { return m_npcConfig.HasValue ? (m_npcConfig.Value.npcScale * 0.01f) : 1.0f; } }

        public override bool Selectable
        {
            get
            {
                return m_npcConfig != null ?
                    (m_npcConfig.Value.type != (int)swm.NpcType.NPCTYPE_TIGGER &&
                    m_npcConfig.Value.type != (int)swm.NpcType.NPCTYPE_GATHER) : false;
            }
        }

        public override bool GatherwhileDie {
            get {
                return m_npcConfig != null && m_npcConfig.Value.gather_res > 0;
            }
        }

        public override float HitEffectScale {
            get {
                return m_npcConfig != null ? m_npcConfig.Value.hurt_effect_scale * 0.001f : 1f;
            }
        }
        public bool HasUmbrella { get { return m_data.ai_data != null ? m_data.ai_data.has_umbrella : false; } }
		swm.MapNpcT m_npcData = new swm.MapNpcT();
		public swm.MapNpcT NpcData
		{
			get { return m_npcData; }
		}
        /// <summary>
        /// 是否说话在触发区域
        /// </summary>
        /// <returns></returns>
        [XLua.BlackList]
        public bool IsSpeakInTriggerArea
        {
            get { return m_speakAiInfo.isintriggerarea; }
            set { m_speakAiInfo.isintriggerarea = value; }
        }
        /// <summary>
        /// 发送聊天消息
        /// </summary>
        private swm.ChatMsgT m_sendChatMsg = new swm.ChatMsgT();

        /// <summary>
        /// 说话ai信息
        /// </summary>
        private SpeakAiInfo m_speakAiInfo = new SpeakAiInfo();

        /// <summary>
        /// 是否第一次绑定模型
        /// </summary>
        private bool m_firstBindModel = false;
        public override void SetData(swm.MapEntityDataT data)
        {
            m_npcData = data?.npc_data;
            base.SetData(data);
        }
        public override Entity Clone(ulong _id = 0, CloneUsage _Usage = CloneUsage.NpcVisit)
        {
            Npc _entity = new Npc(_id);
            _entity.SyncLoad = true;
            var tData = m_data.Clone();
            if (_Usage == CloneUsage.Drama)
                tData = HandleDataForDrama(tData);

            _entity.init();
            _entity.SetData(tData);
            _entity.SetNpcConfigById((int)BaseID);
            
            if (IsInTransform )
            {
                _entity.TransformAddtoScene(GetCurrentTransformationModel());
            }
            else
            {
                _entity.OnAddToScene();
            }
            _entity.Position = Position;
            _entity.Direction = Direction;
            return _entity;
        }

        public override uint BaseID
		{
			get
			{
				return m_npcData.baseid;
			}
		}
		public override swm.CareerSex Sex
		{
			get
			{
				return m_npcData.career_sex;
			}
		}

        //是不是新出生的
        public bool m_isNewBorn
        {
            get
            {
                return GetAge() < NewSpawnCheck;
            }
        }

        public bool IsChangeModelActionPlayed = true;

        public Npc(ulong id):base(id)
        {
            m_layer = (Int32)(UserLayer.Layer_NPC);
            m_avatar.shadowType = AvatarShadowType.Decal;
			//m_avatar.LoadModel(IResourceLoader.strNpcPath, "npc_hero", false);
            //Actived = true;
            //Entity_Type = x2m.EntityType.ENTITY_NPC;

        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public Npc() : base()
        {
        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public override void InitEntity(ulong id)
        {
            base.InitEntity(id);
            m_layer = (Int32)(UserLayer.Layer_NPC);
            m_avatar.shadowType = AvatarShadowType.Decal;
        }

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public override void ResetEntity()
        {
            base.ResetEntity();
            OnAIValueChanged.RemoveAllListeners();
            m_npcConfig = null;
            m_npcWeapon = null;
            m_npcAttr = null;
//             AnimatorNormalizedSpeed = 4.0f;

            m_npcData = new swm.MapNpcT();
            AiValues.Clear();
            for (int i = 0; i < EffectIsLoading.Length; i++)
            {
                EffectIsLoading[i] = false;
            }
            EffectObjects.Clear();
            IsOpenAIRange = false;
            MoveType = swm.AiStatusType.Idle;
        }

        ~Npc()
        {
        }

        public override void RefreshCanAttack()
        {
            CanAttack = m_npcConfig.HasValue?m_npcConfig.Value.under_attack!=0:false;

        }
        protected override void OnDataUpdate()
        {

            base.OnDataUpdate();
            DoLoadModel();
        }

        protected override void DoLoadModel(string _path = "")
        {
            string modulepath = string.Empty;
            if (string.IsNullOrEmpty(_path))
            {
                modulepath = GetCurrentTransformationModel();
            }
            else
            {
                modulepath = _path;
            }
//             if (string.IsNullOrEmpty(modulepath))
//             {
//                 if (m_npcData != null)
//                 {
//                     m_npcConfig = NpcTableManager.GetData((int)BaseID);
//                     if (m_npcConfig.HasValue)
//                         m_npcAttr = MonsterAttrTableManager.GetData(m_npcConfig.Value.ability_id, Level);
//                     //modulepath = m_npcData.model;
//                 }
//             }

            LoadModel(modulepath);
        }

        public ulong GetAge()
        {
            //var st = GameScene.Instance.GetServerTime();
            //if (st < m_npcData.borntime)
            //   return 0;
            ulong serverTime = GameScene.Instance.GetServerTime();
            var d = (long)serverTime - (long)m_npcData.borntime;
            if (d < -1000)
                return (ulong)m_npcData.borntime;
            else if (d < 0)
                return 0;
            else
                return (ulong)d;
        }

		public override void SetNetData(swm.MapEntityData _data)
		{
            m_npcData.FromMsg(_data.npc_data.Value);

            base.SetNetData(_data);

            SetNpcConfigById();
            if (m_npcConfig.HasValue)
                m_npcAttr = MonsterAttrTableManager.GetData(m_npcConfig.Value.ability_id, Level);

            RefreshCanAttack();

        }

        public void SetNpcConfigById(int _baseId = 0)
        {
            if(_baseId == 0)
            {
                _baseId = (int)BaseID;
            }
            m_npcConfig = NpcTableManager.GetData(_baseId);
            if (m_npcConfig.HasValue && m_npcConfig.Value.npcWeaponBind > 0)
            {
                m_npcWeapon = WeaponTableManager.GetData(m_npcConfig.Value.npcWeaponBind);
                if (!m_npcWeapon.HasValue)
                    LogHelper.LogWarning("NPC : " + _baseId.ToString() + " has a weapon, but content is null!");
            }
        }

        public override void init()
		{
			base.init();
            //Fix Bug: RefreshCanAttack() is called by SetNetData() before init()，but depend on m_npcConfig loaded In init()

        }

        public override void Release()
        {
            if (NpcConfig.HasValue && NpcConfig.Value.fadeouttime > 0)
            {
                SetInvisibleShader(1.0f);

                float deadtime = NpcConfig.Value.fadeouttime / 1000.0f;

                m_fadeInfo.Start(FadeType.FadeOut, deadtime);

                int ratecnt = (int)(deadtime / Time.deltaTime) + 50;
                GameApplication.Instance.GetTimerManager().AddTimer(() =>
                {
                    if (m_fadeInfo.fadeing)
                    {
                        float alpha = m_fadeInfo.GetAlpha();
                        RefreshMaterialAlpha(alpha);
                    }
                }, 0.0f, ratecnt);

                GameApplication.Instance.GetTimerManager().AddTimer(() =>
                {
                    m_fadeInfo.fadeing = false;
                    
                    base.Release();
                }, deadtime);
            }
            else
                base.Release();
        }

        protected override void OnInvisibleChange()
        {
            if (m_fadeInfo.fadeing)
                return;

            base.OnInvisibleChange();
        }

        public override void LoadModel(string modelpath = null)
		{

			if (string.IsNullOrEmpty(modelpath))
			{
				if (m_npcConfig != null && m_npcConfig.Value.model != CurModelPath)
				{
                    if(string.IsNullOrEmpty(m_npcConfig.Value.model))
                    {
                        LogHelper.LogWarning("NPC Config Model Is Empty!id=", m_npcConfig.Value.id.ToString());
                        return;
                    }
                    AvatarLoadModel(IResourceLoader.strNpcPath, m_npcConfig.Value.model, !SyncLoad);
					Actived = true;
                    CurModelPath = m_npcConfig.Value.model;
				}
			}
			else if(CurModelPath != modelpath)
			{
                //if(modelpath != m_npcConfig.Value.model)
                //{
                //    LogHelper.LogError("NPC Avatar Error!", m_npcConfig.Value.model, modelpath);
                //}
                AvatarLoadModel(IResourceLoader.strNpcPath, modelpath, !SyncLoad);
                CurModelPath = modelpath;
				Actived = true;

			}

            Visible = Visible;
		}

        //[XLua.BlackList]
        //public override void SimulateLogicPosition()
        //{

        //}

        public override void Update()
        {
            base.Update();
            Utilities.ProfilerBegin("Npc.UpdateMaterialAlpha");

            UpdateMaterialAlpha();
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("Npc.UpdateSpeak");
            UpdateSpeak();
            Utilities.ProfilerEnd();

            if (m_b_isBeAttachTo == false)
            {
                Utilities.ProfilerBegin("Npc.UpdateMove");

                if (UseGravity&& CarryTrigger==false) //贴地处理。
                {
                   Position = GetAdjustGroundPosition();       
                }

                ApplyMove(m_motion);

                if(null != Avatar && null != Avatar.unityObject && m_cc && m_cc.enabled)
                {
                    var position = Avatar.unityObject.transform.position;
    #if MOVE_WORLD
                    position += LayeredSceneLoader.WorldOffset;
    #endif
                    Position = position;
                }

                //Utilities.ProfilerBegin("Npc.UpdataAiTest");
                UpdataAiTest();
                Utilities.ProfilerEnd();

            }

        }

        public override void ApplyMove(UnityEngine.Vector3 d)
        {
            if(m_cc != null && m_cc.enabled)
            {
                m_cc.Move(d);
            }
            else
            {
                Position += d;
            }
        }

        public override bool IsNpc()
        {
            return true;
        }

        public override bool haveSkill()
        {
            if (m_npcConfig.HasValue)
                return m_npcConfig.Value.normallistLength > 0 || m_npcConfig.Value.skilllistLength > 0;
            else
                return false;
        }
        protected override void OnAvatarCreateDelegate()
		{
			base.OnAvatarCreateDelegate();
            CC = m_avatar.unityObject.GetComponent<CharacterController>();
            if (CC != null)
            {
                CC.enabled = false; //关闭characterController
            }
            if (!IsInTransform)
            {
                m_avatar.SetScale(ModelScale, ModelScale, ModelScale);
            }

            if (m_headBillboard != null)
				m_headBillboard.Init(this);
            if (m_isNewBorn || IsInTransform)
            {
                Visible = false;

                GameApplication.Instance.GetTimerManager().AddTimer(() =>
                {
                    // 初始化所有的绑定武器
                    InitBindWeapons();
                    CrossFadeAnimPostProcess(m_curAnimId, true);

                    NpcFadeIn();

                    if (m_npcConfig.HasValue && !string.IsNullOrEmpty(m_npcConfig.Value.spawn_effect))
                    {
                        EffectMgr.Instance.Play(m_npcConfig.Value.spawn_effect, this, AvatarAttachment.Root, IResourceLoader.strSkillEffectPath);
                    }

                    Visible = true;

                }, SpawnDelay);
            }
            else
            {
                // 初始化所有的绑定武器
                InitBindWeapons();
                CrossFadeAnimPostProcess(m_curAnimId, true);

                NpcFadeIn();
            }
		}

        private void NpcFadeIn()
        {
            bool isfadein = (NpcConfig.HasValue && NpcConfig.Value.fadeintime > 0);

            if (isfadein)
            {
                if (!IsInvisible)
                {
                    SetInvisibleShader(0.0f);

                    float borntime = NpcConfig.Value.fadeintime / 1000.0f;

                    m_fadeInfo.Start(FadeType.FadeIn, borntime);

                    GameApplication.Instance.GetTimerManager().AddTimer(() =>
                    {
                        m_fadeInfo.fadeing = false;

                        OnInvisibleChange();
                    }, borntime);
                }
            }
        }

        protected override void OnDie()
        {
            base.OnDie();

            if (m_npcConfig.HasValue)
            {
                if (!string.IsNullOrEmpty(m_npcConfig.Value.die_effect))
                {
                    EffectMgr.Instance.Play(m_npcConfig.Value.die_effect, this, AvatarAttachment.Root, IResourceLoader.strSceneEffectPath);
                }
            }
        }

        public override void OnAddToScene()
        {
            base.OnAddToScene();
            DoLoadModel();
            RefreshMissionState(false);

            m_headBillboard = new HeadBillboard();
			m_headBillboard.Init(this);

            if(NeedCheckCanCarry())
            {
                AddListenerCarryEvent();
                CheckAndShowCarryTx();
            }
            
        }

        protected override void CreateStateMachine()
        {
            m_sm = SM.Factory.CreateSM(this);
        }

        protected override void ReleaseStateMachine()
        {
            SM.Factory.ReleaseNpcSM(m_sm);
            m_sm = null;
        }

        public override void OnRemoveFromScene()
        {
            base.OnRemoveFromScene();

            if (m_headBillboard != null)
            {
                m_headBillboard.Dispose();
                m_headBillboard = null;
            }
            RemoveListenerCarryEvent();
        }

		public override int GetSelectPriority()
		{
			if (m_npcConfig.Value.type == (int)swm.NpcType.NPCTYPE_TIGGER)
				return 2;
			else
				return -1;	
		}
        protected override void CrossFadeAnimPostProcess(int animid, bool forceplay)
        {
            m_curAnimId = animid;

            if (!HasAnim(animid))
                return;

            if (!m_firstBindModel)
            {
                m_firstBindModel = true;
            }
            else
            {
                if (!forceplay)
                {
                    if (IsPlayingAnimtion(animid))
                        return;
                }
            }
        }

        /// <summary>
        /// 刷新材质alpha
        /// </summary>
        protected void UpdateMaterialAlpha()
        {
            if (!m_fadeInfo.fadeing)
                return;

            float alpha = m_fadeInfo.GetAlpha();
            RefreshMaterialAlpha(alpha);
        }
        #region AI 相关


        #region AI 参数显示

        protected Dictionary<swm.AiValueType, float> AiValues = new Dictionary<swm.AiValueType, float>();

        public GameEvent<int, float> OnAIValueChanged = new GameEvent<int, float>();
    
        public void SetAIValue(swm.RefreshAiValues values)
        {
            for(int i= 0;i<values.valuesLength;i++)
            {
                SetAIParam((swm.AiValueType)values.value_id(i), values.values(i));
            }
        }

        protected void SetAIParam(swm.AiValueType id ,float v)
        {
            bool isChanged = true;
            if(AiValues.ContainsKey(id))
            {
                isChanged = AiValues[id] != v;
                AiValues[id] = v;
            }else
            {
                AiValues.Add(id, v);
            }
            if (OnAIValueChanged != null && isChanged)
                OnAIValueChanged.Invoke((int)id, v);
        }

        #endregion

        #region AI 视觉听觉范围

        [XLua.BlackList]
        public enum EffectCategory { Exclamation_Yellow, Exclamation_Red, HearRange, VisionConeRange, MaX }

        protected static string[] EffectNames = new string[] { "fx_cj_tanhao_guaiwu_yellow_s", "fx_cj_tanhao_guaiwu_red_s", "fx_hear_range", "fx_vision_range"  };

        protected bool[] EffectIsLoading = new bool[] { false, false, false, false, false, };

        protected Dictionary<EffectCategory, GameObject> EffectObjects = new Dictionary<EffectCategory, GameObject>();

        protected bool IsOpenAIRange = false;

        protected float HearRangeRadius { get { return Data.ai_data!=null ? Data.ai_test_data.hearing : 5.0f; } }

        protected float VisionConeRadius { get { return Data.ai_data != null ? Data.ai_test_data.vision : 5.0f; } }

        protected float VisionConeAngle { get { return Data.ai_data!= null ? Data.ai_test_data.vision_angle : 60.0f; } }

        [XLua.BlackList]
        public swm.AiStatusType MoveType = swm.AiStatusType.Idle;

        protected void UpdataAiTest()
        {
            if (GameScene.Instance.ShowAiTest != IsOpenAIRange && Avatar.unityObject)
            {
                IsOpenAIRange = GameScene.Instance.ShowAiTest;
                if (IsOpenAIRange)
                {
                    ShowHearRangeCircle();
                    ShowVsionConeRange(EffectCategory.VisionConeRange);
                }
                else
                {
                    ClearHearAndVisionEffect();
                }
            }
        }
        protected void LoadEffect(EffectCategory category ,Action<GameObject> callback)
        {
            GameObject e = null;
            EffectObjects.TryGetValue(category, out e);
            if (EffectIsLoading[(int)category] || e != null)
            {
                LogHelper.LogWarningFormat(LogCategory.AI, "LoadEffect effect is loading {0}", category);
                return;
            }

            EffectIsLoading[(int)category] = true;
            var efffct_name = EffectNames[(int)category];
            var path = IResourceLoader.strBuffEffectPath;
                switch (category)
            {
                case EffectCategory.Exclamation_Red:
                case EffectCategory.Exclamation_Yellow:
                    path = IResourceLoader.strBuffEffectPath;
                    break;
                case EffectCategory.HearRange:
                case EffectCategory.VisionConeRange:
                    path = IResourceLoader.strTrapPath;
                    break;
            }

            GameFXPool.LoadFX(path, efffct_name, (UnityEngine.Object o) =>
            {
                EffectIsLoading[(int)category] = false;
                if (o != null)
                {
                    if (!EffectObjects.ContainsKey(category))
                        EffectObjects.Add(category, GameFXPool.CreateFX(o, this));
                    else
                        EffectObjects[category] = GameFXPool.CreateFX(o, this);
                    if (callback != null)
                        callback.Invoke(EffectObjects[category]);
                }
            });
        }

        [XLua.BlackList]
        public void ShowWarnEffect(swm.PlayEffectType level)
        {

            EffectCategory category = EffectCategory.MaX;
            switch (level)
            {
                case swm.PlayEffectType.YellowAlert: category = EffectCategory.Exclamation_Yellow;  break;
                case swm.PlayEffectType.RedAlert: category = EffectCategory.Exclamation_Red;  break;
                default: LogHelper.LogWarningFormat(LogCategory.AI, "ShowEffectWarn effect not found {0}", level); return;
            }

            if (IsOpenAIRange)
            {
                ShowVisionColor(level);
            }

            LoadEffect(category, (GameObject o) => {
                if(o != null)
                {
                    float offset = 2.0f;
                    if (Avatar != null && Avatar.getBoundBox() != null)
                    {
                        offset = Avatar.getBoundBox().bounds.size.y;
                    }
                    o.transform.SetParent(Avatar.unityObject.transform);
                    o.transform.localPosition = new UnityEngine.Vector3(0, offset, 0);
                    o.SetActive(true);
                    //main.Instance.StartCoroutine(FreeWarnEffect(category));
                    Game.GameApplication.Instance.GetTimerManager().AddTimer(() =>
                    {
                        FreeWarnEffect(category);
                    }, 2);

                }
            });
        }

        protected void FreeWarnEffect(EffectCategory category)
        {
            //yield return new WaitForSeconds(2.0f);
            GameObject o = null;
            if (EffectObjects.TryGetValue(category, out o))
            {
                if(o != null)
                {
                    o.transform.SetParent(null);
                    GameFXPool.FreeFX(o);
                    EffectObjects[category] = null;
                }
            }

            //yield break;
        }

        [XLua.BlackList]
        public void ShowHearRangeCircle()
        {
            LoadEffect(EffectCategory.HearRange, (GameObject o) => {
                if (o != null)
                {
                    o.transform.SetParent(Avatar.unityObject.transform);
                    o.transform.localPosition = UnityEngine.Vector3.zero;
                    o.transform.localRotation = Quaternion.identity;
                    o.SetActive(true);
                    var projecter = o.GetComponentInChildren<Projector>();
                    if(projecter)
                    {
                        projecter.orthographicSize = HearRangeRadius;
                    }
                }
            });
        }

        [XLua.BlackList]
        public void SwitchHearAndVisionEffect(bool active)
        {
            GameObject o = null;
            if (EffectObjects.TryGetValue(EffectCategory.HearRange,out o))
                o?.SetActive(active);
            o = null;
            if (EffectObjects.TryGetValue(EffectCategory.VisionConeRange,out o))
                o?.SetActive(active);
        }

        [XLua.BlackList]
        public void ClearHearAndVisionEffect()
        {
            GameObject o = null;
            if (EffectObjects.TryGetValue(EffectCategory.HearRange, out o))
            {
                if (o != null)
                {
                    o.transform.SetParent(null);
                    GameFXPool.FreeFX(o);
                }
                EffectObjects[EffectCategory.HearRange] = null;
                EffectIsLoading[(int)EffectCategory.HearRange] = false;
            }

            o = null;
            if (EffectObjects.TryGetValue(EffectCategory.VisionConeRange, out o))
            {
                if(o != null)
                {
                    o.transform.SetParent(null);
                    GameFXPool.FreeFX(o);
                }
                EffectObjects[EffectCategory.VisionConeRange] = null;
                EffectIsLoading[(int)EffectCategory.VisionConeRange] = false;
            }
        }

        [XLua.BlackList]
        public void ShowVisionColor(swm.PlayEffectType t)
        {
            GameObject o = null;
            if (EffectObjects.TryGetValue(EffectCategory.VisionConeRange, out o))
            {
                if (o != null)
                {
                    var FanShape = o.GetComponent<Bokura.Rapidecal.Dynamical.DynamicDecalFanShape>();
                    if (FanShape)
                    {
                        switch(t)
                        {
                            case swm.PlayEffectType.None: FanShape.color = new Color(1, 1, 1, 0.5f); break;
                            case swm.PlayEffectType.YellowAlert: FanShape.color = new Color(1, 0.7f, 0, 0.5f); break;
                            case swm.PlayEffectType.RedAlert: FanShape.color = new Color(1, 0, 0, 0.5f); break;
                        }                       
                    }
                }
            }
        }

        [XLua.BlackList]
        public void ShowVsionConeRange(EffectCategory category)
        {
            LoadEffect(category, (GameObject o) =>
            {
                if (o != null)
                {
                    o.transform.SetParent(Avatar.unityObject.transform);
                    o.transform.localPosition = UnityEngine.Vector3.zero;
                    o.transform.localRotation = Quaternion.identity;
                    o.SetActive(true);
                    var FanShape = o.GetComponent<Bokura.Rapidecal.Dynamical.DynamicDecalFanShape>();
                    if (FanShape)
                    {
                        FanShape.angle = VisionConeAngle;
                        FanShape.scaling = new UnityEngine.Vector3(VisionConeRadius * 2, VisionConeRadius * 2, VisionConeRadius * 2);
                    }
                }
            });
        }

        #endregion

        #region AI 天气

        /// <summary>
        /// 处理天气类型改变
        /// </summary>
        /// <param name="weathertype"></param>
        public void ProcWeatherTypeChanged(int weathertype)
        {

        }

        #endregion

        protected override void onAnimEvent(MagicContext context, AnimEvent animEvent, List<EventParam> paramlist)
        {
            base.onAnimEvent(context, animEvent, paramlist);

            switch (animEvent)
            {
                case AnimEvent.SwitchItem:
                    //预留一下 以后切换道具的逻辑
                    break;
            }
        }

        #region AI 绑定模型

        #region Weapon
        /// <summary>
        /// 销毁所有的绑定模型
        /// </summary>
        private void ReleaseBindWeapons()
        {
            if (PrimaryWeapon != null)
            {
                PrimaryWeapon.Release();
                PrimaryWeapon = null;
            }
            if (SecondaryWeapon != null)
            {
                SecondaryWeapon.Release();
                SecondaryWeapon = null;
            }
        }

        /// <summary>
        /// 初始化默认的绑定武器
        /// </summary>
        [XLua.BlackList]
        private void InitBindWeapons()
        {
            ReleaseBindWeapons();
            if (m_npcWeapon.HasValue)
            {
                //var weapon_name = m_npcConfig.Value.npcWeapon;
                var weapon_name = m_npcWeapon.Value.primary_weapon;
                if (string.IsNullOrEmpty(weapon_name))
                    return;
                PrimaryWeapon = new Weapon();
                PrimaryWeapon.Attachment = (AvatarAttachment)m_npcWeapon.Value.primary_bind_bone;// AvatarAttachment.Back;
                PrimaryWeapon.init(this, "prefabs/weapons/npc_weapons/", weapon_name);

                weapon_name = m_npcWeapon.Value.second_weapon;
                if (string.IsNullOrEmpty(weapon_name))
                    return;
                SecondaryWeapon = new Weapon();
                SecondaryWeapon.Attachment = (AvatarAttachment)m_npcWeapon.Value.second_bind_bone;// AvatarAttachment.Back;
                SecondaryWeapon.init(this, "prefabs/weapons/npc_weapons/", weapon_name);
            }

            //PrimaryWeapon.Show(false);
        }
        #endregion

        #endregion

        #region AI 行为

        private void Say(string say, uint time, string talk_img_bg, string talk_icon, swm.ChatPosType chatpostype = swm.ChatPosType.NEARBY)
        {
            m_sendChatMsg.target = GameScene.Instance.MainChar.ThisID;
            m_sendChatMsg.sendername = Name;
            m_sendChatMsg.chat_msg = say;
            m_sendChatMsg.sponsor = ThisID;
            m_sendChatMsg.chat_pos = chatpostype;
            m_sendChatMsg.neartalk_cdtime = time;
            ChatModel.Instance.AddChatDataByMsg(m_sendChatMsg, true, true, false, talk_img_bg, talk_icon);
        }

        private void UpdateSpeak()
        {
            if (!m_speakAiInfo.isspeaking)
                return;

            if (Time.realtimeSinceStartup < (m_speakAiInfo.speakstart + m_speakAiInfo.speaktime + m_speakAiInfo.speakiterval))
                return;

            NpcSpeakTableBase? nextspeakcfg = NpcSpeakTableManager.GetData(m_speakAiInfo.nextspeakid);
            if (nextspeakcfg.HasValue)
            {
                SpeakByMainCharCol(nextspeakcfg);
            }
            else
            {
                m_speakAiInfo.ResetSpeak();
            }
        }

        private void SpeakByMainCharCol(NpcSpeakTableBase? speakcfg)
        {
            m_speakAiInfo.isspeaking = true;
            m_speakAiInfo.nextspeakid = speakcfg.Value.nextid;
            m_speakAiInfo.speakstart = Time.realtimeSinceStartup;
            m_speakAiInfo.speaktime = speakcfg.Value.talktime * 0.001f;
            m_speakAiInfo.speakiterval = speakcfg.Value.talk_interval * 0.001f;

            Say(speakcfg.Value.talktext, (uint)speakcfg.Value.talktime, speakcfg.Value.talkframe_pattern, speakcfg.Value.talkicon);
        }
        public void SpeakTalkByTable(int id)
        {
            NpcSpeakTableBase? speak = NpcSpeakTableManager.GetData(id);
            if (speak.HasValue)
            {
                SpeakByMainCharCol(speak);
                StateMachine.OnAnimationEvent(AnimEvent.Talk);
            }
        }
        /// <summary>
        /// 主角碰撞的说话行为
        /// </summary>
        [XLua.BlackList]
        public void SpeakByMainCharCol()
        {
            if (m_speakAiInfo.isspeaking)
                return;

            if (!m_npcConfig.HasValue)
                return;

            int count = m_npcConfig.Value.near_speakidLength;
            if (count <= 0)
                return;

            checkCanSpeakList();

            if (m_canSpeakList.Count <= 0)
            {
                return;
            }

            int index = Random.Global.RandIntRange(0, m_canSpeakList.Count - 1);
            if (index < 0 || index >= m_canSpeakList.Count)
                return;

            int id = m_canSpeakList[index];

            //int index = Random.Global.RandIntRange(0, count - 1);
            //if (index < 0 || index >= count)
            //    return;

            //int id = m_npcConfig.Value.near_speakid(index);

            NpcSpeakTableBase? speakcfg = NpcSpeakTableManager.GetData(id);
            if (!speakcfg.HasValue)
                return;

            SpeakByMainCharCol(speakcfg);
        }

        private List<int> m_canSpeakList = new List<int>(0);
        private void checkCanSpeakList()
        {
            m_canSpeakList.Clear();

            //势力处理;
            int stronghold = m_npcConfig.Value.stronghold;
            int strongholdType = StrongholdsManager.Instance.GetPrestigeTypeByStrongholdId(stronghold);

            int count = m_npcConfig.Value.near_speakidLength;
            int prestigeLength = 0;
            for (int i=0; i< count; ++i)
            {
                int id = m_npcConfig.Value.near_speakid(i);

                NpcSpeakTableBase? speakcfg = NpcSpeakTableManager.GetData(id);
                if (speakcfg.HasValue)
                {
                    prestigeLength = speakcfg.Value.prestigeLength;
                    if (prestigeLength > 0)
                    {
                        for (int k = 0; k < prestigeLength; ++k)
                        {
                            if (speakcfg.Value.prestige(k) == strongholdType)
                            {
                                m_canSpeakList.Add(id);
                                break;
                            }
                        }
                    }
                    else
                    {
                        m_canSpeakList.Add(id);
                    }
                }
            }
        }
        private TimeHelper speakTimeInterval = new TimeHelper(5);

        /// <summary>
        /// 主角碰撞的躲闪行为
        /// </summary>
        [XLua.BlackList]
        public void DodgeByMainCharCol(bool forward)
        {
            if (!m_npcConfig.HasValue)
                return;

            if (m_npcConfig.Value.iscol_dodge <= 0)
                return;

            if (!speakTimeInterval.IsValid())
                return;

            // 说话
            m_speakAiInfo.isspeaking = false;
            m_speakAiInfo.ResetSpeak();

            int talkidlen = m_npcConfig.Value.col_talk_idLength;
            if (talkidlen > 0)
            {
                int index = Random.Global.RandIntRange(0, talkidlen - 1);
                if (index >= 0 && index < talkidlen)
                {
                    int talkid = m_npcConfig.Value.col_talk_id(index);
                    NpcSpeakTableBase? speakcfg = NpcSpeakTableManager.GetData(talkid);
                    if (speakcfg.HasValue)
                    {
                        speakTimeInterval.Refresh((ulong)speakcfg.Value.talktime);

                        Say(speakcfg.Value.talktext, (uint)speakcfg.Value.talktime, speakcfg.Value.talkframe_pattern, speakcfg.Value.talkicon);
                    }
                }
            }
            StateMachine.OnAnimationEvent(AnimEvent.DodgeEnd);
            // 闪避动作
            //UnderAttack(AnimatorStateID.DodgeByMainCharCol_Back);
            //StateMachine?.Resume(SM.Entity.States.UNDER_ATTACK);
        }

        #endregion

        #region AI 状态机

        #endregion

        #endregion

        #region npc搬运相关

        public bool NeedCheckCanCarry()
        {
            return m_npcConfig.Value.carry_id > 0;
        }

        public void AddListenerCarryEvent()
        {
            CarryTypeTableBase? cttb = CarryTypeTableManager.GetData(m_npcConfig.Value.carry_id);
            if (cttb.HasValue != false)
            {
                //注册主角升级事件
                if(cttb.Value.lv_limit>0)
                {
                    m_CarryNeedMainCharLvl = cttb.Value.lv_limit;
                    GameScene.Instance.MainChar.OnLevelChange.AddListener(onMainCharLvlChange);
                }
                //注册任务下发事件
                if(cttb.Value.task_limit>0)
                {
                    m_CarryNeedTaskId = cttb.Value.task_limit;
                    MissionModel.Instance.onAddDoingTask.AddListener(onAddDoingTask);
                    MissionModel.Instance.onInitDoingTask.AddListener(onInitDoingTask);
                    
                    MissionModel.Instance.onRemoveDoingTask.AddListener(onRemoveDoingTask);
                }
            }
        }

        public void RemoveListenerCarryEvent()
        {
            if ( m_CarryNeedMainCharLvl > 0 && GameScene.Instance.MainChar != null)
            {
                GameScene.Instance.MainChar.OnLevelChange.RemoveListener(onMainCharLvlChange);
            }
            //注册任务下发事件
            if (m_CarryNeedTaskId > 0)
            {
               
                MissionModel.Instance.onAddDoingTask.RemoveListener(onAddDoingTask);

                MissionModel.Instance.onRemoveDoingTask.RemoveListener(onRemoveDoingTask);
            }
        }
        int m_CarryNeedTaskId = 0;
        int m_CarryNeedMainCharLvl = 0;
        bool m_showCanCarryTx = false;
        //EffectMgr.EffectInfo m_CanCarryTx;

        public bool CheckOnceCanCarry()
        {
            if (GameScene.Instance.MainChar.Level >= m_CarryNeedMainCharLvl)
            {
                if (m_CarryNeedTaskId > 0)
                {
                    MissionInfoData minfo = MissionModel.Instance.GetDoingMissionInfoDataById((uint)m_CarryNeedTaskId);
                    if (minfo != null)
                    {
                        //显示特效
                        return true;
                    }
                }
                else
                {
                    //显示特效
                    return true;
                }
            }
            return false;
        }

        public void CheckAndShowCarryTx()
        {
            bool showtx = CheckOnceCanCarry();
            ShowCanCarryTx(showtx);
        }

        public void onInitDoingTask()
        {
            CheckAndShowCarryTx();
        }

        public void onAddDoingTask(MissionInfoData minfo)
        {
            if (m_showCanCarryTx == false && minfo.MissionId == m_CarryNeedTaskId)
            {
                if(GameScene.Instance.MainChar.Level >= m_CarryNeedMainCharLvl)
                {
                    //显示特效
                    ShowCanCarryTx(true);
                }
            }
        }

        public void onRemoveDoingTask(MissionInfoData minfo)
        {
            if(m_showCanCarryTx==true&&minfo.MissionId == m_CarryNeedTaskId)
            {
                //退出显示特效
                ShowCanCarryTx(false);
            }
        }

        public void onMainCharLvlChange(int lvl)
        {
            if (m_showCanCarryTx == false && lvl >= m_CarryNeedMainCharLvl)
            {
                if(m_CarryNeedTaskId>0)
                {
                    MissionInfoData minfo = MissionModel.Instance.GetDoingMissionInfoDataById((uint)m_CarryNeedTaskId);
                    if (minfo != null)
                    {
                        //显示特效
                        ShowCanCarryTx(true);
                    }
                }
                else
                {
                    //显示特效
                    ShowCanCarryTx(true);
                }
            }
        }

        public void ShowCanCarryTx(bool v)
        {
            if(m_showCanCarryTx!=v)
            {
                if(v==true)
                {
                    //if(m_CanCarryTx!=null)
                    //{
                    //    m_CanCarryTx.Stop();
                    //}
                    //m_CanCarryTx = EffectMgr.Instance.Play(CarryStageManager.Instance.NpcCanCarryTxName, this, AvatarAttachment.Root, null, false);//播放可搬运特效
                    //EffectMgr.EffectInfoGroup eg= EffectMgr.Instance.PlayByConfig("effect_trap_2010231_01", this);
                    //eg.Visible = true;
                    if (Avatar != null && Avatar.unityObject == null)
                        Avatar.onCreate.AddListener(OnInitShowCanCarryFX);
                    else
                        OnInitShowCanCarryFX();
                            
                }
                else
                {
                    //m_CanCarryTx.Stop();
                    //m_CanCarryTx = null;
                    m_showCanCarryTx = v;
                }                
            }        
        }

        private bool m_HasAddMat = false;
        private void OnInitShowCanCarryFX()
        {
            if(!m_showCanCarryTx && !m_HasAddMat)
            {
                var mat = ResourceHelper.LoadResourceSync(IResourceLoader._strSharedMaterialPath, "fx_common_fnl", ".mat") as Material;

                if (Avatar != null && Avatar.unityObject != null)
                {
                    Avatar.unityObject.gameObject.AddMaterial(mat);
                }

                m_HasAddMat = true;
            }
            m_showCanCarryTx = true;
        }

        /// <summary>
        /// 复位交互点
        /// </summary>
        [XLua.BlackList]
        public void ResetInteractionPoint()
        {
            interaction_id = 0;
            interaction_action = 0;
            CommonActionId = 0;
        }

        #endregion

    }
}
