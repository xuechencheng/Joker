using UnityEngine;
using Bokura;



namespace Bokura
{
    /// <summary>
    /// 表示给定GameObject的用于AvatarShow的实体
    /// </summary>
    public class ShowEntity : AvatarEvent
    {
        private IAvatar m_Avatar;
        public IAvatar Avatar
        {
            get { return m_Avatar; }
        }



        public ShowEntity(GameObject unityObj)
        {
            m_Avatar = IFactory.Instance.CreateAvatar(this);
            m_Avatar.unityObject = unityObj;
        }



        public void Release()
        {
            if(null != m_Avatar)
            {
                m_Avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_Avatar);
                m_Avatar = null;
            }
        }
    }
}