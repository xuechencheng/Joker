using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using Bokura;
using UnityEngine.UI;

namespace Bokura
{
	class TargetSelector
	{

		#region events
		public class ChangeEvent : GameEvent<Entity>
		{

		}


		public GameEvent<bool> onIsLockingChange = new GameEvent<bool>();
		public GameEvent<Entity> onSelectTargetChange = new ChangeEvent();
        public GameEvent<float> onDistanceChange = new GameEvent<float>();

		#endregion

		struct RangeInfo
		{
			public Entity entity;
			//public Vector3 v;
			public float distance;
		}

        class SelectRangeInfoComparser : IComparer<RangeInfo>
        {           
            public int Compare(RangeInfo a, RangeInfo b)
            {
                if(a.entity.GetSelectPriority() < b.entity.GetSelectPriority())
                    return -1;
                else if(a.entity.GetSelectPriority() == b.entity.GetSelectPriority())
                {


                    if (a.distance < b.distance)
                        return -1;
                    else if (a.distance > b.distance)
                    {
                        return 1;
                    }
                    else
                        return 0;
                }
                return 1;
            }
        }

        Entity              m_selected;
		Entity				m_prevSelected;
        List<RangeInfo>     m_selectableList = new List<RangeInfo>(10);
        
		float               m_maxSelectDistance = 25.0f;    //最大的选中距离
		float               m_overViewDelay;
        float               m_overViewDelayOverTime = 0.5f;  //选择目标超过视角时取消选中的时候
		float               m_selectAngle = 45.0f;           //选中目标的范围
        float               m_selectRange = 0.4f;           //摄像机选取范围
        bool                m_isLocking = false;
        SelectRangeInfoComparser m_rangeInfoComparser = new SelectRangeInfoComparser();
        Comparison<RangeInfo> m_rangeInfoComparison;

		static TargetSelector m_instance;
		static public TargetSelector Instance
		{
			get
			{
				if (m_instance == null)
					m_instance = new TargetSelector();

				return m_instance;
			}
		}

        public float SelectViewRange
        {
            get { return m_selectRange; }
            set { m_selectRange = value; }
        }

        public float OverViewDelayOverTime
        {
            get { return m_overViewDelayOverTime; }
            set { m_overViewDelayOverTime = value; }
        }
        public bool IsLocking { get { return m_isLocking && SysSettingModel.Instance.sharedData.bCameraTargetLock; }
            set {
                if (m_isLocking != value ) {
                    m_isLocking = value;
                    onIsLockingChange.Invoke(m_isLocking);
                }
            }
        }
        public float MaxSelectDistance
		{
			get
			{
				return m_maxSelectDistance;
			}
			set
			{
				m_maxSelectDistance = value;
			}
		}

		public Entity Selected
		{
			get
			{
			    return m_selected;
			}
            protected set { m_selected = value; /*IsLocking = m_selected != null ? IsLocking : false;*/  }
		}

        



        TargetSelector()
		{


            m_rangeInfoComparison = m_rangeInfoComparser.Compare;

            SkillShowManager.Instance.OnSkillHit.AddListener((ulong caster, ulong receiver) => 
            {
                //当没有选择目标时，第一个攻击自己的目标自动置为选择目标；
                if (GameScene.Instance.MainChar && receiver == GameScene.Instance.MainChar.ThisID && m_selected == null)
                {
                    SelectTarget(GameScene.Instance.GetEntityByID(caster));
                }
            });
        }

	
        public void Clear()
        {
            m_selected = null;
            m_prevSelected = null;
            m_selectableList.Clear();
        }

		public void SelectNext()
		{

			UpdateSelectorList();
			if (m_selectableList.Count == 0)
				return;

			int next_select = 0;
			//bool cur_locked_found = false;
			for (int i = 0; i < m_selectableList.Count; i++)
			{
				if (m_selectableList[i].entity == m_selected)
				{
					
					for (int j = 1; j < m_selectableList.Count; j ++ )
					{
                        next_select = (i + j) % m_selectableList.Count;

                        var entity = m_selectableList[next_select].entity;
						if (!entity.IsFriendly)
							break;
						//next_select = null;
					}
					break;
				}
			}


		    SelectTarget(m_selectableList[next_select].entity);
	

		}

		void UpdateTargetToServer()
		{
			var curselect = m_selected;
			if (curselect && curselect != m_prevSelected)
			{
				m_prevSelected = curselect;
				var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
				swm.SelectTarget.StartSelectTarget(fbb);
				swm.SelectTarget.AddTargetid(fbb, curselect.ThisID);
				fbb.Finish(swm.SelectTarget.EndSelectTarget(fbb).Value);
				MsgDispatcher.instance.SendFBPackage(swm.SelectTarget.HashID, fbb);
                //LogHelper.Log("Notify Select" + curselect.ToString());
			}
        }

		public void Update()
		{
            if(ICameraHelper.Instance.MainCamera == null)
            {
                return;
            }

            if(m_selected && GameScene.Instance.MainChar )
            {
                var distance = Vector3.Distance(m_selected.GlobalPosition, GameScene.Instance.MainChar.GlobalPosition);
                if (distance > MaxSelectDistance ||  (m_selected.Died && !m_selected.IsFriendly) || m_selected.Deleted  )
                    SelectTarget(null);
            }
            

			//UpdateTrackUITarget();
			//TODO: test code
#if UNITY_EDITOR || UNITY_STANDALONE
			if (ICrossPlatformInputManager.Instance.GetButtonDown("tab"))
			{
                SelectNext();				
			}
#endif
			UpdateTargetToServer();
        }

        bool IsEntityInRange(Entity entity, out RangeInfo v)
		{
            var dir = entity.GlobalPosition - GameScene.Instance.MainChar.GlobalPosition;
            v.distance = dir.magnitude;
            v.entity = entity;
            return v.distance < m_maxSelectDistance;
            //return IsEntityInRangeByCamera(entity);
        }
        bool IsEntityInRange(Entity entity)
        {
            var dir = entity.GlobalPosition - GameScene.Instance.MainChar.GlobalPosition;
            
            return dir.magnitude < m_maxSelectDistance;
            //return IsEntityInRangeByCamera(entity);
        }
        /// <summary>
        /// 根据角色前方一定角度进行判�?
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        bool IsEntityInRangeByChar(Entity entity)
        {
            if (entity.Deleted || entity.Died)
                return false;
            var v = entity.TargetSelNode.position - GameScene.Instance.MainChar.Billboard.transform.position;
            v.y = 0;

            float sqrlen = v.magnitude;
            if (sqrlen > m_maxSelectDistance)
                return false;
            var dir = GameScene.Instance.MainChar.Direction; // - GameScene.Instance.mainCamera.transform.position;
            dir.y = 0;
            dir.Normalize();

            v.Normalize();
            float angle = Vector3.Angle(dir, v);
            return angle < m_selectAngle;
        }

        /// <summary>
        /// 根据相机前方一定范围进行判�?
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        bool IsEntityInRangeByCamera(Entity entity)
        {
            if (entity.Deleted || entity.Died || entity.TargetSelNode==null)
                return false;
            var v = entity.TargetSelNode.position - GameScene.Instance.MainChar.Billboard.transform.position;
            v.y = 0;
            if (v.magnitude > m_maxSelectDistance)
                return false;
            var dir = CameraController.Instance.Direction;
            dir.y = 0;
            dir.Normalize();

            var cam = ICameraHelper.Instance.MainCamera;
            Vector3 viewpoint = cam.WorldToViewportPoint(entity.TargetSelNode.position);
            if (viewpoint.z < 0f || viewpoint.y < 0f || viewpoint.y > 1f)
                return false;
            return viewpoint.x >= (0.5f - m_selectRange) && viewpoint.x <= (0.5f + m_selectRange);
        }

        //边界时调整摄像头�?
        bool IsEntityInRangeAngleByCamera(Entity entity)
        {
            float range = 0.1f;
            if (entity == null || entity.Deleted || entity.Died)
                return false;
            var cam = ICameraHelper.Instance.MainCamera;
            Vector3 viewpoint = cam.WorldToViewportPoint(entity.TargetSelNode.position);
            if (viewpoint.z < 0)
                return false;
            if (viewpoint.y > (0.5f + range) || viewpoint.y < (0.5f - range))
                return false;
            if (viewpoint.x > (0.5f + range) || viewpoint.x < (0.5f - range))
                return false;
            return true;
            //return viewpoint.x >= (0.5f - m_selectRange) && viewpoint.x <= (0.5f + m_selectRange);
        }
        void UpdateSelectorList()
		{
			{
				m_selectableList.Clear();

				foreach (var kv in GameScene.Instance.AllEntitys)
				{
					if (kv.Value.Visible && kv.Value.Selectable && (!kv.Value.Died||kv.Value.IsCharacter()) && !kv.Value.IsMainCharacter())
					{
						RangeInfo v;
						if (IsEntityInRange(kv.Value, out v))
						{
							m_selectableList.Add(v);
						}
					}

				}
                if (m_selectableList.Count > 0)
                {
                    m_selectableList.Sort(m_rangeInfoComparison);
                    //SelectTarget(m_selectableList[0].entity);
                }

            }
		}

        //const float maxNearstDis = 20.0f;
		Entity GetNearstTarget(SkillBase skill=null)
		{
            UpdateSelectorList();
            if (m_selectableList.Count > 0)
            {
//                 var mainchar = GameScene.Instance.MainChar;
                if(skill!=null)
                {
                    for (int i = 0; i < m_selectableList.Count; i++)
                    {
                        if (skill.CheckCanCastTo(m_selectableList[i].entity))
                            return m_selectableList[i].entity;
                    }
                    return null;

                }
                return m_selectableList[0].entity;
            }
            return null;
		}


        public void SelectTarget(Entity ety)
        {
//             if (ety && ety.IsMainCharacter())//现在 能选中自己了
//                 return;

            if (ety && !ety.CanSelect)
                return;

            if (Selected != ety)
            {
                Selected = ety;
                if (onSelectTargetChange != null)
                    onSelectTargetChange.Invoke(ety);

                //UpdateSelectedTraceUI();


            }
        }
        public Entity SelectNearest(SkillBase skill=null)
        {
            var nearest = GetNearstTarget(skill);
            //if (nearest != null)
            SelectTarget(nearest);
            return m_selected;
        }
        bool CheckEntityCanSelect(Entity ety)
		{
			if (ety == null || ety.Deleted || ety.Died)
				return false;
			if (!ety.Visible)
			{
				return false;
			}
			//Vector3 distance = ety.Position - GameScene.Instance.MainChar.Position;
			//if (distance.magnitude > m_maxSelectDistance)
			//{
			//	SelectTargetChange(null);
			//	return false;
			//}

			if (!IsEntityInRange(ety))
			{
				m_overViewDelay += Time.deltaTime;
				if (m_overViewDelay > m_overViewDelayOverTime)
				{
					m_overViewDelay = 0.0f;
					//SelectTargetChange(null);
					return false;
				}
			}
			else
			{
				m_overViewDelay = 0.0f;
			}


			return true;
		}
	}
}