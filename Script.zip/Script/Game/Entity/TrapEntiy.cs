
//场景陷阱类, 陷阱特有的属性和方法在此处理

using System;

using UnityEngine;
using Bokura;

namespace Bokura
{

    public enum Trap_Type
    {
        Trap_Type_None = 0, //无效
        Trap_Type_Rect,     //矩形
        Trap_Type_Angle,    //三角形
        Trap_Type_Circle,   //圆形
        Trap_Type_FanShaped //扇形
    }

    public class TrapEntiy : MovableEntity
    {
        
        public TrapEntiy(ulong id):base(id)
        {			
            Actived = true;
            //Entity_Type = x2m.EntityType.ENTITY_NPC;
        }

        /// <summary>
        /// default ctor, for ObjectPool call
        /// </summary>
        [XLua.BlackList]
        public TrapEntiy() : base()
        {
        }

        /// <summary>
        /// init Entity after Get it from ObjectPool
        /// </summary>
        /// <param name="id"></param>
        [XLua.BlackList]
        public override void InitEntity(ulong id)
        {
            base.InitEntity(id);
            Actived = true;
        }

        ~TrapEntiy()
        {
        }

        UnityEngine.Projector m_projector;
		TrapBase? m_trapConfig;
		UnityEngine.Vector3 m_offset;
		float m_curparam1, m_curparam2;

		swm.MapTrapT m_trapData = new swm.MapTrapT();
        //ulong m_disappearTime;
        EffectMgr.EffectInfoGroup m_effectGroup;
		public float DisappearTimeRemain
		{
			get
			{
				return (float)(m_trapData.overtime - GameScene.Instance.GetServerTime())/1000.0f;
			}
		}

		public TrapBase TrapConfig
		{
			get
			{
				return m_trapConfig.Value;
			}
		}

		public override bool Selectable
		{
			get
			{
				return false;
			}
		}

		public override uint BaseID
		{
			get
			{
				return m_trapData.baseid;
			}
		}

		public override Entity GetOwner()
		{
			if (m_trapData == null || m_trapData.owner_id == 0 || m_trapData.owner_id == ThisID)
				return null;
			else
				return GameScene.Instance.GetEntityByID( m_trapData.owner_id);
		}

		public override void SetNetData(swm.MapEntityData _data)
		{
			base.SetNetData(_data);
			if(_data.trap_data!=null)
			{
				m_trapData.baseid = _data.trap_data.Value.baseid;
				//m_trapData.owner_type = Game.GameScene.GetEntityTypeById(_data.trap_data.Value.owner_id);
				m_trapData.owner_id = _data.trap_data.Value.owner_id;
				m_trapData.overtime = _data.trap_data.Value.overtime;
			}
		}
		void RefreshSize(float param1, float param2)
		{
            if(null != m_projector)
            {
                switch ((Trap_Type)m_trapConfig.Value.area_type)
                {
                    case Trap_Type.Trap_Type_None: //无效
                        {
                            // 长
                            m_projector.orthographicSize = param1 * 0.5f;//z  长
                                                                         // 长比例param2 / param1 = 1
                            m_projector.aspectRatio = 1;//x 
                            break;
                        }
                    case Trap_Type.Trap_Type_Rect:     //矩形
                        {
                            //长

                            m_projector.orthographicSize = param1 * 0.5f;//z  
                                                                         // 长比例param2 / param1 = 1
                            m_projector.aspectRatio = param2 / param1;//x 
                            m_offset = param1 / 2 * Direction;

                            break;
                        }
                    case Trap_Type.Trap_Type_Angle:    //三角形
                        {
                            //距离，角度
                            m_projector.orthographicSize = param1;
                            m_projector.aspectRatio = 1;
                            m_offset = param1 / 2 * Direction;

                            break;
                        }
                    case Trap_Type.Trap_Type_Circle:   //圆形
                        {
                            //半径
                            m_projector.orthographicSize = param1;
                            m_projector.aspectRatio = 1;
                            m_offset = Vector3.zero;
                            break;
                        }
                    case Trap_Type.Trap_Type_FanShaped: //扇形
                        {
                            //距离，角度
                            m_projector.orthographicSize = param1;
                            m_projector.aspectRatio = 1;
                            m_offset = param1 / 2 * Direction;

                            break;
                        }
                }
            }



			SetAvatarPosition();

		}
        public override void DumpMapEntityData(swm.MapEntityDataT data)
        {
            base.DumpMapEntityData(data);

            data.model_radius = m_curparam1;
            data.model_radius2 = m_curparam2;
        }
        public override void SetAvatarPosition()
		{
			if(m_avatar!=null)
			{

				//var offset =  m_avatar.unityObject.transform.rotation*m_offset;
				m_avatar.SetPosition(m_position.x+ m_offset.x,m_position.y,m_position.z+ m_offset.z);
			}
		}

		public override void OnAddToScene()
        {
            base.OnAddToScene();

			m_trapConfig = TrapManager.GetData(Convert.ToInt32(BaseID));
            //Trap_Type areatype = (Trap_Type)trapConfig.area_type;
            //int[] param = trapConfig.area_param;
            string model = m_trapConfig.Value.model;
            AvatarLoadModel(IResourceLoader.strTrapPath, "fx_common", false);

            m_effectGroup = EffectMgr.Instance.PlayByConfig(model, this);

            if(m_avatar.unityObject == null)
                return;
			m_projector = m_avatar.unityObject.GetComponentInChildren<Projector>();

			m_curparam1 = Data.model_radius;
			m_curparam2 = Data.model_radius2;
			RefreshSize(m_curparam1, m_curparam2);

			if(m_trapConfig.Value.show_count_down)
			{
				m_headBillboard = new HeadBillboard();
				m_headBillboard.Init(this);
			}
			
			//Is_ForwardRect(this, param2, param1);

		}

        public override void OnRemoveFromScene()
        {
            base.OnRemoveFromScene();

            m_headBillboard?.Dispose();
            m_headBillboard = null;



            m_effectGroup?.Stop();
            m_effectGroup = null;

        }

        /// <summary>
        /// reset Entity members before ObjectPool Release it
        /// </summary>
        [XLua.BlackList]
        public override void ResetEntity()
        {
            base.ResetEntity();
            m_projector = null;
            m_trapConfig = null;
            m_offset = Vector3.zero;
            m_curparam1 = 0.0f;
            m_curparam2 = 0.0f;
            m_trapData = new swm.MapTrapT();
        }

        public override void Update()
        {

			if (m_trapConfig!=null && m_trapConfig.Value.grow_speed>0.0f)
			{
				float fmaxparam1 = m_trapConfig.Value.max_area_param(0);
				float fmaxparam2 = m_trapConfig.Value.max_area_paramLength > 1 ? m_trapConfig.Value.max_area_param(1) : 0.0f;


				if ((m_curparam1 < fmaxparam1 || m_curparam2 < fmaxparam2))
				{
					float add = m_trapConfig.Value.grow_speed * Time.deltaTime;
					m_curparam1 += add;
					if (m_curparam1 > fmaxparam1)
						m_curparam1 = fmaxparam1;
					m_curparam2 += add;
					if (m_curparam2 > fmaxparam2)
						m_curparam2 = fmaxparam2;
					RefreshSize(m_curparam1, m_curparam2);
				}

			}
            //DrawLine();
        }

    }
}
