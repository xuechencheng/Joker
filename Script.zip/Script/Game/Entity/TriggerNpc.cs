﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Bokura;

namespace Bokura
{
    class TriggerNpc : Npc
    {
        private TriggerComponent m_triggerComponent;



		public override bool Selectable
		{
			get
			{
				return false;
			}
		}

		public TriggerNpc(ulong id):base(id)
        {
            m_layer = (Int32)(UserLayer.Layer_Trigger);
        }

        public override void OnAddToScene()
        {
            base.OnAddToScene();
            if(Actived)
            {
                m_triggerComponent = TriggerComponent.Get(m_avatar.unityObject);
                m_triggerComponent.onRefreshMapEntityData.AddListener(ProcessTrigger);
            }
        }

        private void ProcessTrigger(Collider other)
        {
            if(other is UnityEngine.CharacterController && other.gameObject == GameScene.Instance.MainChar.Avatar.unityObject)
            {
                //主角踩到触发器了
                GameScene.Instance.DispathMainCharacterEnterTrigger(this);
                //LogHelper.LogError("1111111111");

            }
        }
    }
}
