using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
	public class EntitySelector
	{
		const float entity_height = 2.0f;
		public delegate bool SelectFilter(Entity ety);
		public static bool IsPointIsInFan(Vector3 pos, Quaternion rot, float distance, float angle, float height, Vector3 targetPos)
		{
			Vector3 v = targetPos - pos;
			if (v.sqrMagnitude < distance*distance && (v.y < height&&v.y>=-entity_height))
			{
				Vector3 norVec = rot * Vector3.forward;
				float jiajiao = Mathf.Acos(Vector3.Dot(norVec, v.normalized)) * Mathf.Rad2Deg;
				return jiajiao <= angle * 0.5;

			}
			return false;
		}
		static public bool GetEntityInFan(List<Entity> outlist,  Vector3 pos, Quaternion rot, float _distance, float _angle,  float height, SelectFilter filter = null)
		{
			float distance = _distance;// 5.0f;
			float angle = _angle;// 60.0f;
			//List<Entity> arr = new List<Entity>();

			float readius = 0;
			foreach (var kv in GameScene.Instance.AllEntitys)
			{
				if (kv.Value.Avatar != null && kv.Value.Avatar.unityObject != null && IsPointIsInFan(pos, rot,  readius + distance, angle, height, kv.Value.Position))
				{
					if (filter == null || filter(kv.Value))
						outlist.Add(kv.Value);
				}

				
			}
			return outlist.Count > 0;
		}

		static  public bool GetEntityInCircle(List<Entity> outlist, Vector3 pos, float distance, float height,  bool nearestOne = false, SelectFilter filter = null)
		{

			if (nearestOne)
			{
				float mindis = distance;
				Entity nearst = null;
				foreach (var kv in GameScene.Instance.AllEntitys)
				{
					if (kv.Value == GameScene.Instance.MainChar || !kv.Value.Selectable)
						continue;
					var v = (kv.Value.Position - pos);
					var dis = v.magnitude;
					if (dis< mindis && (v.y < height && v.y >= -entity_height))
					{
						nearst = kv.Value;
						mindis = dis;						
					}
				}
				if (nearst != null &&  (filter == null || filter(nearst)))
					outlist.Add(nearst);
			}
			else
			{
				foreach (var kv in GameScene.Instance.AllEntitys)
				{
					var v = (kv.Value.Position - pos);
					if (kv.Value.Selectable && v.sqrMagnitude < distance * distance && (v.y < height && v.y >= -entity_height) 
						&& (filter == null || filter(kv.Value)))
					{
						outlist.Add(kv.Value);
					}
				}
			}


			return outlist.Count>0;
		}

		//static Vector3[] rectpos = new Vector3[4];

		static Collider[] overlayercollders = new Collider[64];

		public static bool IsInRect(Vector3 center, Quaternion rot, Vector3 halfextend, Entity ety)
		{
			int ncount = Physics.OverlapBoxNonAlloc(center, halfextend, overlayercollders, rot, (int)(UserLayerMask.Character | UserLayerMask.MainCharacter | UserLayerMask.NPC));
			for (int i = 0; i < ncount; i++)
			{
				if (overlayercollders[i].gameObject == ety.Avatar.unityObject)
					return true;
			}

			return false;
			//return Vector3.Dot((rectpos[1] - rectpos[0]), rectpos[1] - pos) <= 0.0f &&
			//	 Vector3.Dot((rectpos[2] - rectpos[1]), rectpos[2] - pos) <= 0.0f &&
			//	  Vector3.Dot((rectpos[3] - rectpos[2]), rectpos[3] - pos) <= 0.0f &&
			//	   Vector3.Dot((rectpos[0] - rectpos[3]), rectpos[0] - pos) <= 0.0f;
		}

		public static bool GetEntityInRect(List<Entity> outlist,  Vector3 pos, Quaternion rot, float l, float r, float height, SelectFilter filter = null)
		{

			//Vector3 rtleft = rot * Vector3.left;
			//Vector3 rtforwart = (rot * Vector3.forward)* _distance;
			//rectpos[0] = pos + rtleft * _ldistance;//��
			//rectpos[1] = pos - rtleft * _ldistance;//��
			//rectpos[2] = rectpos[1] + (rtforwart);//��ǰ
			//rectpos[3] = rectpos[0] + (rtforwart);//��ǰ

			foreach (var kv in GameScene.Instance.AllEntitys)
			{

				//Vector3 kvPos = kv.Value.Avatar.unityObject.transform.position;
				if (IsInRect(pos, rot, new Vector3(l/2.0f,height/2.0f, r/2.0f), kv.Value) &&
					(filter == null || filter(kv.Value)))
				{
					outlist.Add(kv.Value);
				}


			}
			return outlist.Count>0;
		}
	}
}