using System;
using System.Collections.Generic;
using UnityEngine.Events;
using Bokura;
namespace Bokura
{

	public class Event
	{
		public delegate void FunDelegate();

		Dictionary<string,FunDelegate> m_funs;
        bool m_invoking = false;

        List<string> m_removelist;
        List<KeyValuePair<string, FunDelegate>> m_addList;
		public void Invoke()
		{

            if (m_funs == null) return;

            m_invoking = true;
            foreach (var v in m_funs.Values)
            {
                try
                {
                    v.Invoke();
                }
                catch (Exception e)
                {
                    LogHelper.LogError(e.ToString());
                }
            }
            m_invoking = false;
            if (m_removelist != null && m_removelist.Count > 0)
            {
                for (int i = 0; i < m_removelist.Count; i++)
                {
                    RemoveListener(m_removelist[i]);
                }
                m_removelist.Clear();
            }
            if (m_addList != null && m_addList.Count > 0)
            {
                for (int i = 0; i < m_addList.Count; i++)
                {
                    AddListener(m_addList[i].Value, m_addList[i].Key);
                }
                m_addList.Clear();
            }

        }

        public FunDelegate AddListener(FunDelegate fun, string funname=null)
		{
            if (m_invoking)
            {
                if (m_addList == null)
                    m_addList = new List<KeyValuePair<string, FunDelegate>>(1);
                m_addList.Add(new KeyValuePair<string, FunDelegate>(funname,fun));
                return fun;
            }
            if(string.IsNullOrEmpty(funname))
            {
                funname = fun.GetHashCode().ToString();
            }
            if (m_funs == null)
                m_funs = new Dictionary<string, FunDelegate>(1);
            m_funs[funname] = fun;
                            
			return fun;
		}
		public void RemoveListener(FunDelegate fun)
		{
           
            if (m_funs == null) return;
            string key = null;
			foreach(var kv in m_funs)
            {
                if(kv.Value == fun)
                {
                    key = kv.Key;
                    break;
                }
            }
            if (m_invoking)
            {
                if (m_removelist == null)
                    m_removelist = new List<string>(1);
                m_removelist.Add(key);
                return;
            }
            if (key!=null)
            {
                m_funs.Remove(key);
            }
		}
        public void RemoveListener(string funname)
        {
            if (m_funs == null) return;
            if (m_invoking)
            {
                if (m_removelist == null)
                    m_removelist = new List<string>(1);
                m_removelist.Add(funname);
                return;
            }
            if (m_funs.ContainsKey(funname))
            {
                m_funs.Remove(funname);
            }
        }
        public void RemoveAllListeners()
		{
			m_funs = null;
		}

		public static Event operator +(Event a, FunDelegate fun)
		{
			a.AddListener(fun);
			return a;
		}

		public static Event operator -(Event a, FunDelegate fun)
		{
			a.RemoveListener(fun);
			return a;
		}
	}
	public class Event<T>
	{

		public delegate void FunDelegate(T a);
        Dictionary<string, FunDelegate> m_funs;
        bool m_invoking = false;

        List<string> m_removelist;
        List<KeyValuePair<string, FunDelegate>> m_addList;
        public void Invoke(T a)
        {

            if (m_funs == null) return;

            m_invoking = true;
            foreach (var v in m_funs.Values)
            {
                try
                {
                    v.Invoke(a);
                }
                catch (Exception e)
                {
                    LogHelper.LogError(e.ToString());
                }

            }
            m_invoking = false;
            if (m_removelist != null && m_removelist.Count > 0)
            {
                for (int i = 0; i < m_removelist.Count; i++)
                {
                    RemoveListener(m_removelist[i]);
                }
                m_removelist.Clear();
            }
            if (m_addList != null && m_addList.Count > 0)
            {
                for (int i = 0; i < m_addList.Count; i++)
                {
                    AddListener(m_addList[i].Value, m_addList[i].Key);
                }
                m_addList.Clear();
            }

        }

        public FunDelegate AddListener(FunDelegate fun, string funname = null)
        {
            if (m_invoking)
            {
                if (m_addList == null)
                    m_addList = new List<KeyValuePair<string, FunDelegate>>(1);
                m_addList.Add(new KeyValuePair<string, FunDelegate>(funname, fun));
                return fun;
            }
            if (string.IsNullOrEmpty(funname))
            {
                funname = fun.GetHashCode().ToString();
            }
            if (m_funs == null)
                m_funs = new Dictionary<string, FunDelegate>(1);
            m_funs[funname] = fun;

            return fun;
        }
        public void RemoveListener(FunDelegate fun)
        {

            if (m_funs == null) return;
            string key = null;
            foreach (var kv in m_funs)
            {
                if (kv.Value == fun)
                {
                    key = kv.Key;
                    break;
                }
            }
            if (m_invoking)
            {
                if (m_removelist == null)
                    m_removelist = new List<string>(1);
                m_removelist.Add(key);
                return;
            }
            if (key != null)
            {
                m_funs.Remove(key);
            }
        }
        public void RemoveListener(string funname)
        {
            if (m_funs == null) return;
            if (m_invoking)
            {
                if (m_removelist == null)
                    m_removelist = new List<string>(1);
                m_removelist.Add(funname);
                return;
            }
            if (m_funs.ContainsKey(funname))
            {
                m_funs.Remove(funname);
            }
        }
        public void RemoveAllListeners()
		{
			m_funs = null;
		}
		public static Event<T> operator +(Event<T> a, FunDelegate fun)
		{
			a.AddListener(fun);
			return a;
		}

		public static Event<T> operator -(Event<T> a, FunDelegate fun)
		{
			a.RemoveListener(fun);
			return a;
		}

	}

	public class Event<T1,T2>
	{

		public delegate void FunDelegate(T1 a, T2 b);

        Dictionary<string, FunDelegate> m_funs;
        bool m_invoking = false;

        List<string> m_removelist;
        List<KeyValuePair<string, FunDelegate>> m_addList;
        public void Invoke(T1 a, T2 b)
        {

            if (m_funs == null) return;

            m_invoking = true;
            foreach (var v in m_funs.Values)
            {
                try
                {
                    v.Invoke(a, b);
                }
                catch (Exception e)
                {
                    LogHelper.LogError(e.ToString());
                }
            }
            m_invoking = false;
            if (m_removelist != null && m_removelist.Count > 0)
            {
                for (int i = 0; i < m_removelist.Count; i++)
                {
                    RemoveListener(m_removelist[i]);
                }
                m_removelist.Clear();
            }
            if (m_addList != null && m_addList.Count > 0)
            {
                for (int i = 0; i < m_addList.Count; i++)
                {
                    AddListener(m_addList[i].Value, m_addList[i].Key);
                }
                m_addList.Clear();
            }


        }

        public FunDelegate AddListener(FunDelegate fun, string funname = null)
        {
            if (m_invoking)
            {
                if (m_addList == null)
                    m_addList = new List<KeyValuePair<string, FunDelegate>>(1);
                m_addList.Add(new KeyValuePair<string, FunDelegate>(funname, fun));
                return fun;
            }
            if (string.IsNullOrEmpty(funname))
            {
                funname = fun.GetHashCode().ToString();
            }
            if (m_funs == null)
                m_funs = new Dictionary<string, FunDelegate>(1);
            m_funs[funname] = fun;

            return fun;
        }
        public void RemoveListener(FunDelegate fun)
        {

            if (m_funs == null) return;
            string key = null;
            foreach (var kv in m_funs)
            {
                if (kv.Value == fun)
                {
                    key = kv.Key;
                    break;
                }
            }
            if (m_invoking)
            {
                if (m_removelist == null)
                    m_removelist = new List<string>(1);
                m_removelist.Add(key);
                return;
            }
            if (key != null)
            {
                m_funs.Remove(key);
            }
        }
        public void RemoveListener(string funname)
        {
            if (m_funs == null) return;
            if (m_invoking)
            {
                if (m_removelist == null)
                    m_removelist = new List<string>(1);
                m_removelist.Add(funname);
                return;
            }
            if (m_funs.ContainsKey(funname))
            {
                m_funs.Remove(funname);
            }
        }
        public void RemoveAllListeners()
		{
			m_funs = null;
		}
		public static Event<T1,T2> operator +(Event<T1,T2> a, FunDelegate fun)
		{
			a.AddListener(fun);
			return a;
		}

		public static Event<T1,T2> operator -(Event<T1,T2> a, FunDelegate fun)
		{
			a.RemoveListener(fun);
			return a;
		}

	}

    public class UnityEventFloat : GameEvent<float>
    {

    }
}