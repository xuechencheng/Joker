using System;

namespace Bokura
{
    public class FIFOFixedStream
    {
        byte[] m_buff;
        long m_readPtr;
        long m_writePtr;
        long m_freesize;

        public FIFOFixedStream(int buffsize)
        {
            m_buff = new byte[buffsize];
            Reset();
        }

        public void Reset()
        {
            m_readPtr = 0;
            m_writePtr = 0;
            m_freesize = m_buff.Length;
        }

        public byte[] RawBuffer
        {
            get => m_buff;
        }

        public bool Write(byte[] data, int offset, int len)
        {
            if (FreeSize < len)
                return false;
            int tailfreesize = m_buff.Length - ActureWritePos;
            if (tailfreesize >= len)
                Array.Copy(data, offset, m_buff, ActureWritePos, len);
            else
            {
                Array.Copy(data, offset, m_buff, ActureWritePos, tailfreesize);
                Array.Copy(data, offset + tailfreesize, m_buff, 0, len - tailfreesize);
            }
            m_writePtr += len;
            return true;
        }

        public int Read(byte[] data, int offset, int len)
        {
            int readSize = len < DataSize ? len : DataSize;
            if (readSize == 0)
                return 0;
            int taildatasize = m_buff.Length - ActureReadPos;
            if (taildatasize >= len)
                Array.Copy(m_buff, ActureReadPos, data, offset, readSize);
            else
            {
                Array.Copy(m_buff, ActureReadPos, data, offset, taildatasize);
                Array.Copy(m_buff, 0, data, offset + taildatasize, readSize - taildatasize);
            }
            m_readPtr += readSize;
            m_freesize += readSize;
            return readSize;
        }

        public int CanDirectRead(int len)
        {
            if (DataSize < len)
                return -1;
            int taildatasize = m_buff.Length - ActureReadPos;
            if (taildatasize >= len)
            {
                return ActureReadPos;
            }
            else
            {
                return -1;
            }
        }
        public int EmptyRead(int len)
        {
            if(CanDirectRead(len)!=-1)
            {
                m_readPtr += len;
                m_freesize += len;
                return len;
            }

            return 0;
        }


        byte[] m_intData = new byte[4];
        public int ReadInt()
        {
            if (Read(m_intData, 0, 4) == 4)
            {
                return m_intData[0] | m_intData[1] << 8 | m_intData[2] << 16 | m_intData[3] << 24;

            }
            else
                return 0;
        }


        int ActureWritePos
        {
            get
            {
                return (int)(m_writePtr % m_buff.Length);
            }
        }

        int ActureReadPos
        {
            get
            {
                return (int)(m_readPtr % m_buff.Length);
            }
        }

        public int FreeSize
        {
            get
            {
                return (int)(m_freesize - m_writePtr);
            }
        }
        public int DataSize
        {
            get
            {
                return (int)(m_writePtr - m_readPtr);
            }
        }
    }
}