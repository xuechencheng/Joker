using Bokura;
using UnityEngine;
using System;
using System.Collections.Generic;
//using UnityEngine.Events;


namespace Bokura
{
    public class Decoration : AvatarEvent
    {
        protected IAvatar m_avatar;

        AvatarAttachment m_attachment;

        Entity m_owner;

        public IAvatar Avatar
        {
            get
            {
                return m_avatar;
            }
        }

        public AvatarAttachment Attachment
        {
            get
            {
                return m_attachment;
            }
            set
            {
                if (m_attachment != value)
                {
                    m_attachment = value;
                    if (m_avatar != null && m_avatar.unityObject)
                    {
                        m_avatar.AttachTo(m_owner.Avatar, m_attachment, AvatarAttachment.Root);
                    }
                }

            }
        }

        public void init(Entity owner, string decoration_name, bool async = true)
        {
            m_owner = owner;
            m_avatar = IFactory.Instance.CreateAvatar(this);
            m_avatar.onCreate.AddListener(OnAvatarCreateDelegate);

            m_avatar.LoadModel(IResourceLoader.strDecorationPath, decoration_name, async); 
        }

        void OnAvatarCreateDelegate()
        {
            if (m_avatar != null && null != m_owner )
            {
                m_avatar.AttachTo(m_owner.Avatar, m_attachment, AvatarAttachment.Root);
                m_avatar.SetLayer(m_owner.Layer);
                m_owner.OnAvatarChanged(m_avatar.unityObject);
            }
        }

        public void Release()
        {
            if (null != m_avatar)
            {
                m_avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_avatar);
                m_avatar = null;
            }

        }

        public void Show(bool show)
        {
            if (m_avatar != null)
            {
                m_avatar.Visible = show;
            }
        }

    }
}
