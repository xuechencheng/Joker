﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bokura;

namespace Bokura
{
    public class FashionBase
    {
        public FashionTableBase FashionConfig;

        public uint ID;
        public string Name;
        public swm.FashionSlot Slot;
        public bool IsDressed;//是否穿戴
        public bool IsOwnered;
        public int LoveState; // -1 = 不喜欢， 1 = 喜欢， 0 = 无（默认）
        public ulong EndTime;
        public List<int> timeliness;
        public List<int> timeliness_price;

        public void Init(FashionTableBase configData)
        {
            FashionConfig = configData;

            this.ID = (uint)configData.id;
            this.Name = configData.name;
            this.Slot = (swm.FashionSlot)configData.slottype;

            if (configData.timeliness_priceLength > 0)
            {
                timeliness = new List<int>(configData.timeliness_priceLength);
                timeliness_price = new List<int>(configData.timeliness_priceLength);

                for (int i = 0; i < configData.timeliness_priceLength; ++i)
                {
                    var item = configData.timeliness_price(i);
                    timeliness.Add(item.Value.key);
                    timeliness_price.Add((int)item.Value.value);
                }
            }
        }
        public void Init(FashionTableBase configData, swm.FashionData _fashion)
        {
            UnityEngine.Debug.Assert(configData.id == _fashion.fid);

            Init(configData);

            Refresh(_fashion);
        }
        public void Refresh(swm.FashionData _fashion)
        {
            if (_fashion.love)
                this.LoveState = 1;
            else
                this.LoveState = 0;

            this.IsOwnered = _fashion.own;

            this.EndTime = _fashion.endtime;
        }
    }
}
