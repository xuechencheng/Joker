﻿using System;
using System.Collections.Generic;
using Bokura;
using UnityEngine;
using System.Text.RegularExpressions;
using System.Reflection;

namespace Bokura
{
    public class FashionModel : ISingleton<FashionModel>
    {
        [XLua.BlackList]
        public static void Register()
        {
            if (m_instance == null)
                m_instance = ClientSingletonManager.Instance.CreateSingleton<FashionModel>();

            //NetworkConnection.networkMsgTamper = new FashionTest();
        }

        public class RoleFashion
        {
            private List<FashionBase> m_FashionSlot;
            private List<FashionBase> m_SaveFashionSlot;
            public List<FashionBase> FashionSlot
            {
                get
                {
                    return m_FashionSlot;
                }
            }
            public List<FashionBase> SaveFashionSlot
            {
                get
                {
                    return m_SaveFashionSlot;
                }
            }
            public GameEvent onRoleSlotChanged = new GameEvent();
            public bool IsModified { get; private set; }
            public RoleFashion()
            {
                m_FashionSlot = new List<FashionBase>(6);
                m_SaveFashionSlot = new List<FashionBase>(6);
            }
            public RoleFashion Clone()
            {
                RoleFashion newObj = new RoleFashion();
                newObj.m_FashionSlot.AddRange(m_FashionSlot);
                return newObj;
            }
            
            public void Init(swm.FashionSlotData slots)
            {
                m_FashionSlot.Clear();
                for (int i = 0; i < slots.fidsLength; ++i)
                {
                    uint id = slots.fids(i);
                    FashionBase _fashion = null;
                    if (id > 0)
                    {
                        _fashion = FashionModel.Instance.GetFashionByThisID((int)id);
                        if (_fashion != null)
                        {
                            _fashion.IsDressed = true;
                        }
                    }
                    m_FashionSlot.Add(_fashion);
                }
                IsModified = false;
            }
            private bool _isBackupped;
            public bool isBackupped
            {
                get
                {
                    return _isBackupped;
                }
            }
            public void Backup()
            {
                if (_isBackupped)
                    return;
                _isBackupped = true;

                m_SaveFashionSlot.Clear();
                m_SaveFashionSlot.AddRange(m_FashionSlot);
            }
            public void Restore()
            {
                if (!_isBackupped)
                    return;
                
                _isBackupped = false;

                for (int i = 0; i < m_FashionSlot.Count; ++i)
                {
                    var fashion = m_FashionSlot[i];
                    if (fashion != null)
                    {
                        fashion.IsDressed = false;
                    }
                }

                m_FashionSlot.Clear();
                m_FashionSlot.AddRange(m_SaveFashionSlot);

                for (int i = 0; i < m_FashionSlot.Count; ++i)
                {
                    var fashion = m_FashionSlot[i];
                    if (fashion != null)
                    {
                        fashion.IsDressed = true;
                    }
                }

                IsModified = false;
            }
            public void ApplyChanges()
            {
                if (!_isBackupped)
                    return;
                _isBackupped = false;

                m_SaveFashionSlot.Clear();

                IsModified = false;
            }
            public bool PutOn(FashionBase fashion)
            {
                if (fashion == null)
                    return false;
                if (fashion.IsDressed)
                    return false;
                
                FashionBase old_fashion = m_FashionSlot[fashion.FashionConfig.slottype];
                if (old_fashion != null)
                {
                    Debug.Assert(old_fashion.IsDressed);
                    old_fashion.IsDressed = false;
                }
                
                m_FashionSlot[fashion.FashionConfig.slottype] = fashion;
                fashion.IsDressed = true;

                IsModified = true;
                onRoleSlotChanged.Invoke();

                return true;
            }
            public bool TakeOff(FashionBase fashion)
            {
                if (fashion == null)
                    return false;
                if (! fashion.IsDressed)
                    return false;

                FashionBase cur_fashion = m_FashionSlot[fashion.FashionConfig.slottype];
                if (cur_fashion == null)
                    return false;

                Debug.Assert(cur_fashion == fashion);
                cur_fashion.IsDressed = false;

                m_FashionSlot[fashion.FashionConfig.slottype] = null;

                IsModified = true;
                onRoleSlotChanged.Invoke();

                return true;
            }
            public List<uint> GetFashionSlotIDs()
            {
                List<uint> ids = new List<uint>(m_FashionSlot.Count);
                for (int i = 0; i < m_FashionSlot.Count; ++i)
                {
                    var fashion = m_FashionSlot[i];
                    if (fashion != null)
                    {
                        ids.Add(fashion.ID);
                    }
                    else
                    {
                        ids.Add(0);
                    }
                }
                return ids;
            }
        }

        private List<FashionBase> m_fashionList = new List<FashionBase>(16);
        private List<FashionBase> m_queryList = new List<FashionBase>(16);
        private RoleFashion m_roleFashion = new RoleFashion();
        private FashionBase m_EmptyFashion = new FashionBase();
        public class BuyFashionEvent : GameEvent<List<uint>>
        {

        }

        public class LoveFashionEvent : GameEvent<uint>
        {

        }

        public class SaveFashionEvent : GameEvent<List<uint>>
        {

        }

        public enum FilerSourceType
        {
            System = 1 << 1,
            Activity = 1 << 2,
            Copy = 1 << 3,
            Shop = 1 << 4,
        }

        public BuyFashionEvent onBuyFashion = new BuyFashionEvent();

        public LoveFashionEvent onLoveFashion = new LoveFashionEvent();

        public GameEvent onRefreshFashionSlots = new GameEvent();

        public SaveFashionEvent onSaveFashion = new SaveFashionEvent();

        public GameEvent onRoleSlotChanged
        {
            get
            {
                return m_roleFashion.onRoleSlotChanged;
            }
        }


        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshAllFashionDatas>(ProcRefreshFashionDatas);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshFashionSlots>(ProcRefreshFashionSlots);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RetBuyFashion>(ProcRetBuyFashion);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RetSignLoveFashion>(ProcRetSignLoveFashion);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RetSaveFashion>(ProcRetSaveFashion);

            m_EmptyFashion.ID = 0;
            m_EmptyFashion.Name = "无";
        }

        public void Clear()
        {
            m_fashionList?.Clear();
            m_queryList?.Clear();
            m_roleFashion = new RoleFashion();
        }

        public void RestoreRoleFashion()
        {
            if (m_roleFashion.isBackupped)
            {
                var fashionids = new List<int>(m_roleFashion.SaveFashionSlot.Count);
                for (int i = 0; i < m_roleFashion.SaveFashionSlot.Count; ++i)
                {
                    var fashion = m_roleFashion.SaveFashionSlot[i];
                    if (fashion != null)
                        fashionids.Add((int)fashion.ID);
                    else
                        fashionids.Add(0);
                }
                SetCharacterFashions(GameScene.Instance.MainChar, fashionids);
            }
            m_roleFashion.Restore();
        }
        public void BackupRoleFashion()
        {
            m_roleFashion.Backup();
        }
        public void ApplyChangesRoleFashion()
        {
            m_roleFashion.ApplyChanges();
        }
        public bool IsModified
        {
            get
            {
                return m_roleFashion.IsModified;
            }
        }
        public FashionBase GetRoleFashionAtSlot(swm.FashionSlot slot)
        {
            return m_roleFashion.FashionSlot[(int)slot];
        }
        public List<uint> GetRoleFashionSlotIDs()
        {
            return m_roleFashion.GetFashionSlotIDs();
        }
        public List<FashionBase> GetUnownedFashionsAtSlot()
        {
            List<FashionBase> unownedFashions = new List<FashionBase>(m_roleFashion.FashionSlot.Count);
            for (int i = 0; i < m_roleFashion.FashionSlot.Count; ++i)
            {
                var fashion = m_roleFashion.FashionSlot[i];
                if (fashion != null && !fashion.IsOwnered)
                {
                    unownedFashions.Add(fashion);
                }
            }
            return unownedFashions;
        }
        public bool DressFashion(FashionBase fashion)
        {
            return m_roleFashion.PutOn(fashion);
        }
        public bool TakeOffFashion(FashionBase fashion)
        {
            return m_roleFashion.TakeOff(fashion);
        }
        public swm.FashionSlot Int2FashionSlot(int value)
        {
            // lua用
            return (swm.FashionSlot)value;
        }

        public int FilterOption;// 0 - 拥有时装; 1 - 标记喜欢; 2 - 时效时装; 3 - 活动掉落; 4 - 推荐排序

        /// <summary>
        /// 查询时装
        /// </summary>
        /// <param name="slot">部位</param>
        /// <param name="filterSource">过滤条件：来源，组合，默认为全部来源，1=商城，2=活动，4=系统</param>
        /// <param name="filterLove">过滤条件：是否喜欢，默认0=全部，1=只显示喜欢</param>
        /// <returns></returns>
        public List<FashionBase> QueryFashion(swm.FashionSlot slot)
        {
            m_queryList.Clear();
            for (int i = 0; i < m_fashionList.Count; ++i)
            {
                var fashion = m_fashionList[i];
                if (fashion.Slot != slot)
                {
                    continue;
                }

                bool careerValid = false;
                for (int j = 0; j < fashion.FashionConfig.relate_careerLength; ++j)
                {
                    if (fashion.FashionConfig.relate_career(j) == (int)GameScene.Instance.MainChar.CareerType)
                    {
                        careerValid = true;
                        break;
                    }
                }
                if (!careerValid)
                {
                    continue;
                }

                if ((int)GameScene.Instance.MainChar.Sex != fashion.FashionConfig.applicable_sex)
                {
                    continue;
                }

                {
                    bool isValid = true;

                    // 0 - 拥有时装; 1 - 标记喜欢; 2 - 时效时装; 3 - 活动掉落; 4 - 推荐排序

                    switch (FilterOption)
                    {
                        case 0:
                            isValid = (fashion.IsOwnered);
                            break;
                        case 1:
                            isValid = (fashion.LoveState == 1);
                            break;
                        case 2:
                            isValid = (fashion.EndTime > 0);
                            break;
                        case 3:
                            isValid = (fashion.FashionConfig.outpu_way == 2);
                            break;
                        case 4:
                        default:
                            isValid = true;
                            break;
                    }
                    
                    if (!isValid)
                        continue;
                }
                
                m_queryList.Add(fashion);
            }

            Comparison<FashionBase> comparison = new Comparison<FashionBase>(
            (FashionBase a, FashionBase b) =>
            {
                if (a.IsOwnered == b.IsOwnered)
                {
                    if (a.IsOwnered)// 	已获得的服饰排序
                    {
                        // 	已穿戴的服饰—时效性服饰-标注喜欢的服饰—其他服饰
                        //	其他服饰按照获取的先后顺序排列，最近获得的排在最前面
                        if (a.IsDressed == b.IsDressed)
                        {
                            if (a.LoveState == 1 && b.LoveState == 1)
                            {
                                if (a.EndTime == b.EndTime)
                                {
                                    return a.ID.CompareTo(b.ID);
                                }
                                else
                                {
                                    return a.EndTime.CompareTo(b.EndTime);
                                }
                            }
                            else
                            {
                                return a.LoveState == 1 ? -1 : 1;
                            }
                        }   
                        else
                        {
                            return a.IsDressed ? -1 : 1;
                        }
                    }
                    else // 	未获取的服饰排序
                    {
                        if (a.LoveState == 1 && b.LoveState == 1)
                        {
                            // 	商城—活动—系统发放顺序排列
                            // 	商城服饰按照上架时间顺序排列，最新上架的排在最前面
                            if (a.FashionConfig.outpu_way == b.FashionConfig.outpu_way && a.FashionConfig.outpu_way == 0)
                            {
                                return a.ID.CompareTo(b.ID);
                            }
                            else
                            {
                                return a.FashionConfig.outpu_way.CompareTo(b.FashionConfig.outpu_way);
                            }
                        }
                        else
                        {
                            return a.LoveState == 1 ? -1 : 1;
                        }
                    }
                }
                else
                {
                    return a.IsOwnered ? -1 : 1;// 	已拥有的排列在获得的的服饰之前
                }
            });
            m_queryList.Sort(comparison);

            if (slot == swm.FashionSlot.HairAccessory || //发饰
                slot == swm.FashionSlot.Waist || // 腰饰
                slot == swm.FashionSlot.BackDecoration)  // 背饰
            {
                m_queryList.Insert(0, m_EmptyFashion);
            }

            return m_queryList;
        }
        public FashionBase GetFashionByThisID(int id)
        {
            for (int i = 0; i < m_fashionList.Count; ++i)
            {
                var fashion = m_fashionList[i];
                if (fashion.ID == id)
                {
                    return fashion;
                }
            }
            return null;
        }
        public void SendReqSaveFashion(List<uint> fashioIdList)
        {
            // 请求保存时装方案

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            var fids = swm.FashionSlotData.CreateFidsVector(fbb, fashioIdList.ToArray());
            var slots = swm.FashionSlotData.CreateFashionSlotData(fbb, fids);

            swm.ReqSaveFashion.StartReqSaveFashion(fbb);
            swm.ReqSaveFashion.AddSlotdatas(fbb, slots);
            var msg = swm.ReqSaveFashion.EndReqSaveFashion(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSaveFashion.HashID, fbb);
        }
        public void SendReqBuyFashion(List<uint> fashioIdList, List<uint> timeIdList)
        {
            // 请求购买时装
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            FlatBuffers.Offset<swm.PerFashionBuy>[] buyitems = new FlatBuffers.Offset<swm.PerFashionBuy>[fashioIdList.Count];
            for (int i = 0; i < fashioIdList.Count; ++i)
            {
                buyitems[i] = swm.PerFashionBuy.CreatePerFashionBuy(fbb, fashioIdList[i], timeIdList[i]);
            }
                    
            var buydatas = swm.ReqBuyFashion.CreateBuydatasVector(fbb, buyitems);

            swm.ReqBuyFashion.StartReqBuyFashion(fbb);
            swm.ReqBuyFashion.AddBuydatas(fbb, buydatas);
            var msg = swm.ReqBuyFashion.EndReqBuyFashion(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqBuyFashion.HashID, fbb);
            
           // MsgSendQueue.instance.EnqueueFb<swm.ReqBuyFashion>(fbb.DataBuffer);
        }
        public void SendReqSignLoveFashion(uint fashioId)
        {
            // 请求标注喜欢的时装
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSignLoveFashion.StartReqSignLoveFashion(fbb);
            swm.ReqSignLoveFashion.AddFid(fbb, fashioId);
            var msg = swm.ReqSignLoveFashion.EndReqSignLoveFashion(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSignLoveFashion.HashID, fbb);

           // MsgSendQueue.instance.EnqueueFb<swm.ReqSignLoveFashion>(fbb.DataBuffer);
        }
        void ProcRefreshFashionDatas(swm.RefreshAllFashionDatas msg)
        {
            // 刷新所有时装
            m_fashionList.Clear();

            for (int i = 0; i < FashionTableManager.Instance.m_DataList.FashionTableLength; ++i)
            {
                var _config = FashionTableManager.Instance.m_DataList.FashionTable(i);

                FashionBase fashionBase = new FashionBase();
                fashionBase.Init(_config.Value);

                m_fashionList.Add(fashionBase);
            }
            
            for (int i = 0; i <  msg.fdatasLength; ++i)
            {
                var fashion = msg.fdatas(i);

                FashionBase fashionBase = GetFashionByThisID((int)fashion.Value.fid);
                fashionBase.Refresh(fashion.Value);
            }
        }

        void ProcRefreshFashionSlots(swm.RefreshFashionSlots msg)
        {
            // 刷新所有时装数据
            m_roleFashion.Init(msg.slotdatas.Value);

            onRefreshFashionSlots.Invoke();
        }

        List<uint> m_tempfids;
        void ProcRetBuyFashion(swm.RetBuyFashion msg)
        {
            if (!msg.ret)
            {
                return;
            }

            // 返回购买结果
            for (int i = 0; i < msg.fdatasLength; ++i)
            {
                var fashion = msg.fdatas(i);

                FashionBase fashionBase = GetFashionByThisID((int)fashion.Value.fid);
                fashionBase.Refresh(fashion.Value);
            }

            if(m_tempfids==null)
                m_tempfids = new List<uint>(msg.fdatasLength);
            m_tempfids.Clear();
            for (int i = 0; i < msg.fdatasLength; ++i)
           {
                var item = msg.fdatas(i);
                m_tempfids.Add(item.Value.fid);
            }


            onBuyFashion.Invoke(m_tempfids);
        }
        void ProcRetSignLoveFashion(swm.RetSignLoveFashion msg)
        {
            // 返回标注喜欢结果
            if (msg.ret)
            {
                FashionBase fashionBase = GetFashionByThisID((int)msg.fdata.Value.fid);
                fashionBase.Refresh(msg.fdata.Value);

                //var request = MsgSendQueue.instance.DequeueFb<swm.ReqSignLoveFashion>();
                //onLoveFashion.Invoke(request.fid);
                onLoveFashion.Invoke(msg.fdata.Value.fid);
            }
        }
        void ProcRetSaveFashion(swm.RetSaveFashion msg)
        {
            // 返回保存结果
            if (!msg.ret)
            {
                return;
            }

            if (msg.entity_id == GameScene.Instance.MainChar.ThisID)
            {
                // 刷新所有时装数据
                m_roleFashion.Init(msg.slotdatas.Value);

                List<uint> fids = new List<uint>(msg.slotdatas.Value.fidsLength);
                for (int i = 0; i < msg.slotdatas.Value.fidsLength; ++i)
                    fids.Add(msg.slotdatas.Value.fids(i));
                onSaveFashion.Invoke(fids);
            }
            else
            {
                // 刷新九屏消息，通知有玩家时装改变，刷新模型
                List<int> fids = new List<int>(msg.slotdatas.Value.fidsLength);
                for (int i = 0; i < msg.slotdatas.Value.fidsLength; ++i)
                    fids.Add((int)msg.slotdatas.Value.fids(i));
                Entity entity = GameScene.Instance.GetEntityByID(msg.entity_id);
                if (entity != null)
                {
                    Character character = (Character)entity;
                    if (character != null)
                    {
                        SetCharacterFashions(character, fids);
                    }
                }
            }

        }
        public bool SetCharacterFashions(Character character, List<int> fashionids)
        {
            if (fashionids == null || fashionids.Count < 0 || fashionids.Count > 6)
            {
                return false;
            }
            for (int i = 0; i < fashionids.Count; ++i)
            {
                var fid = fashionids[i];
                var config = FashionTableManager.GetData(fid);
                var slot = (swm.FashionSlot)config.Value.slottype;

                switch (slot)
                {
                    case swm.FashionSlot.Dress:
                        {
                            if (config.HasValue)
                            {
                                character.ChangeBodyModel(config.Value.model);
                            }
                            else
                            {
                                LogHelper.LogErrorFormat("unknown fashion id {0}", fid);
                                return false;
                            }
                        }
                        break;
                    case swm.FashionSlot.HairStyle:
                        {
                            if (config.HasValue)
                            { 
                                character.ChangeHairModel(config.Value.model);
                            }
                            else
                            {
                                LogHelper.LogErrorFormat("unknown fashion id {0}", fid);
                                return false;
                            }
                        }
                        break;
                    case swm.FashionSlot.Waist:// 腰饰
                    case swm.FashionSlot.HairAccessory://发饰
                    case swm.FashionSlot.BackDecoration://背饰
                        {
                            if (fid == 0)
                            {
                                character.TakeOffDecoration(slot);
                            }
                            else
                            {
                                character.DressDecoration(fid);
                            }
                        }
                        break;
                }
            }
            return true;
        }
    }

    public class FashionTest : INetworkMsgTamper
    {
        public delegate bool FBPackageEvent(ref FlatBuffers.IFlatbufferObject msg);

        private Dictionary<ulong, MethodInfo> m_FBMessageHandlerMap = new Dictionary<ulong, MethodInfo>(8);

        public FashionTest()
        {
            Type type = this.GetType();
            var methodInfos = type.GetMethods();
            for (int i = 0; i < methodInfos.Length; ++i)
            {
                var method = methodInfos[i];

                Match match = Regex.Match(method.Name, "FB_(\\w+)_(\\w+)");
                if (match.Success)
                {
                    string ns = match.Groups[1].Value;
                    string clsname = match.Groups[2].Value;

                    Type typeMsg = Type.GetType(string.Format("{0}.{1}", ns, clsname));
                    FieldInfo fi = typeMsg.GetField("HashID");
                    ulong hashID = (ulong)fi.GetValue(null);

                    m_FBMessageHandlerMap.Add(hashID, method);
                }
            }
        }
        public bool OnReceiveFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size)
        {
            return true;
        }

        public bool OnReceiveProtobufPackage(ref object msg)
        {
            return true;
        }

        public bool OnSendFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size)
        {
            MethodInfo method;
            if (m_FBMessageHandlerMap.TryGetValue(msgid, out method))
            {
                FlatBuffers.IFlatbufferObject flatObj;
                if (MsgPrintLogger.instance.DecodeFlatBuffer(msgid, bytes, offset, out flatObj))
                {
                    var paramList = new object[] { flatObj };
                    bool ret = (bool)method.Invoke(this, paramList);
                    if (ret)
                    {
                        flatObj = (FlatBuffers.IFlatbufferObject)paramList[0];

                    }
                    return ret;
                }
            }
            return true;
        }

        public bool OnSendProtobufPackage(string protoname, ref byte[] luaPBData)
        {
            return true;
        }

        //public bool OnSendProtobufPackage<T>(ref T msg) where T : IExtensible
        //{
        //    return true;
        //}

        public bool FB_swm_ReqLoginGame(swm.ReqLoginGame msg)
        {
            return true;
        }
    }
}
