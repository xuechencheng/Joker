using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 角色特写&微表情;
    /// </summary>
    public class FeatureArticleManager : ClientSingleton<FeatureArticleManager>
    {
        [XLua.BlackList]
        public void Init()
        {
            CameraController.Instance.OnMainCameraDitanceChanged.AddListener(OnMainCameraDitanceChanged);
            //CameraController.Instance.OnCameraRotated.AddListener(OnCameraRotated);
            GameScene.Instance.onEndLoading.AddListener(OnEndLoading);
        }

        [XLua.BlackList]
        public void Update()
        {
            if (m_featureArticleState != FeatureArticleState.NULL)
            {
                if (!isCanCameraRotated)
                {
                    if (!CameraController.Instance.isAnimRotating)
                    {
                        isCanCameraRotated = true;
                    }
                }

                var mainChar = GameScene.Instance.MainChar;
                if (mainChar != null)
                {
                    if (mainChar.StateMachine.CurStateID != SM.Entity.States.IDLE)
                    {
                        ExitFeatureArticleState();
                    }
                }
            }
        }

        [XLua.BlackList]
        public void LateUpdate()
        {
            if (m_featureArticleState == FeatureArticleState.TWO)
            {
                if (isCanCameraRotated)
                {
                    var mainCamera = GameScene.Instance.MainCamera;

                    if (mainCamera != null)
                    {
                        var pos = mainCamera.transform.position;
                        m_deltaLookAtPosition = Vector3.Lerp(m_deltaLookAtPosition, pos, Time.deltaTime * 4.5f);
                        LookAtTarget(m_deltaLookAtPosition, float.MaxValue);
                    }
                }
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_featureArticleState = FeatureArticleState.NULL;
        }

        public GameEvent<FeatureArticleState> OnFeatureArticleStateChanged = new GameEvent<FeatureArticleState>();

        private FeatureArticleState m_featureArticleState = FeatureArticleState.NULL;

        public FeatureArticleState GetCurrFeatureArticleState() { return m_featureArticleState; }

        public float FeatureArticleState_ONE_Ditance = 1.25f;
        public float FeatureArticleState_TWO_Ditance = 1.22f;

        private bool isCanCameraRotated = false;
        private float m_oldFov = 45;

        private Vector3 m_deltaLookAtPosition = Vector3.zero;

        //private float m_oldCamDis = 0f;
        //private float m_oldCamRoteX = 0f;
        //private float m_oldCamRoteY = 0f;

        void OnMainCameraDitanceChanged(float value)
        {
            if (Game.Instance.IsInGame())
            {
                var mainChar = GameScene.Instance.MainChar;
                if (mainChar != null)
                {
                    if (mainChar.CurAnimState == SM.Entity.States.IDLE)
                    {
                        if (m_featureArticleState == FeatureArticleState.NULL)
                        {
                            if (value <= FeatureArticleState_ONE_Ditance)
                            {
                                if (CameraController.Instance.isSphereCastSamething)
                                {
                                    return;
                                }

                                if (isExitFeatureArticleState) { return; }

                                //m_oldCamDis = CameraController.Instance.GetTargetDistance();
                                //m_oldCamRoteX = CameraController.Instance.GetRoteY();
                                //m_oldCamRoteY = CameraController.Instance.GetRoteX();

                                RoteCameraToMainCharFace(1f);
                                isCanCameraRotated = false;

                                m_featureArticleState = FeatureArticleState.ONE;

                                ICameraHelper.Instance.EnableBlur(true, 0);

                                OnFeatureArticleStateChanged.Invoke(m_featureArticleState);
                            }
                            else
                            {
                                isExitFeatureArticleState = false;
                            }
                        }
                        else if (m_featureArticleState == FeatureArticleState.ONE)
                        {
                            if (value <= FeatureArticleState_TWO_Ditance)
                            {
                                if (isExitFeatureArticleState) { return; }
                                m_featureArticleState = FeatureArticleState.TWO;

                                m_oldFov = ICameraHelper.Instance.GetNowFOV();
                                CameraController.Instance.SetCameraFov(true, 25);
                                SetIsInFeatureArticleState(true);

                                var mainCamera = GameScene.Instance.MainCamera;

                                if (mainCamera != null)
                                {
                                    var pos = mainCamera.transform.position;
                                    m_deltaLookAtPosition = pos;
                                }

                                var tPlayerInfoPanel = UnityEngine.UI.Giant.UIUtility.GetPlayerInfoControl();
                                if (null != tPlayerInfoPanel)
                                {
                                    var tCanvas = tPlayerInfoPanel.GetComponentInParent<Canvas>();
                                    if (null != tCanvas)
                                        tCanvas.enabled = false;
                                }

                                OnFeatureArticleStateChanged.Invoke(m_featureArticleState);
                            }
                            else if (value > FeatureArticleState_ONE_Ditance)
                            {
                                m_featureArticleState = FeatureArticleState.NULL;

                                LookAtTarget(0.5f);
                                resetEyeballAdd();
                                SetIsInFeatureArticleState(false);

                                ICameraHelper.Instance.EnableBlur(false);

                                OnFeatureArticleStateChanged.Invoke(m_featureArticleState);
                            }
                        }
                        else if (m_featureArticleState == FeatureArticleState.TWO)
                        {
                            if (value > FeatureArticleState_TWO_Ditance)
                            {
                                m_featureArticleState = FeatureArticleState.ONE;

                                CameraController.Instance.SetCameraFov(false, m_oldFov);

                                var tPlayerInfoPanel = UnityEngine.UI.Giant.UIUtility.GetPlayerInfoControl();
                                if (null != tPlayerInfoPanel)
                                {
                                    var tCanvas = tPlayerInfoPanel.GetComponentInParent<Canvas>();
                                    if (null != tCanvas)
                                        tCanvas.enabled = true;
                                }

                                LookAtTarget(0.5f);

                                resetEyeballAdd();

                                OnFeatureArticleStateChanged.Invoke(m_featureArticleState);
                            }
                        }
                    }
                }
            }
        }


        //private void OnCameraRotated()
        //{
        //    if (m_featureArticleState == FeatureArticleState.TWO)
        //    {
        //        if (isCanCameraRotated)
        //        {
        //            LookAtTarget(float.MaxValue);
        //        }
        //    }
        //}

        [XLua.BlackList]
        public void OnEndLoading()
        {
            if (GameScene.Instance.currState == GameState.InGame)
            {
                if (m_featureArticleState != FeatureArticleState.NULL)
                {
                    var mainChar = GameScene.Instance.MainChar;
                    if (mainChar != null)
                    {
                        ExitFeatureArticleState();
                    }
                }
            }
        }



        private void LookAtTarget(float duration)
        {
            var mainChar = GameScene.Instance.MainChar;
            if (mainChar != null)
            {
                var mainCamera = GameScene.Instance.MainCamera;

                if (mainCamera != null)
                {
                    var pos = mainCamera.transform.position;

                    var angle = Vector3.Angle(mainChar.Avatar.unityObject.transform.forward, mainChar.headRoot.transform.forward);
                    angle = angle - 90;
                    angle = angle / 70;

                    MakeUpAnimationController ctl = mainChar.GetHeadAnimationController();
                    if (ctl != null)
                    {
                        ctl.SetEyeballAdd(new Vector3(0, angle * 8, 0));
                    }

                    //if (mainChar.IsMale())
                    //{
                    //    if (angle < 0)
                    //    {
                    //        mainChar.SetMaxWeight(2f);
                    //    }
                    //    else
                    //    {
                    //        mainChar.SetMaxWeight(0.4f);
                    //    }
                    //}

                    mainChar.LookAtTarget(pos, duration);
                }
            }
        }

        private void LookAtTarget(Vector3 pos, float duration)
        {
            var mainChar = GameScene.Instance.MainChar;
            if (mainChar != null)
            {
                var angle = Vector3.Angle(mainChar.Avatar.unityObject.transform.forward, mainChar.headRoot.transform.forward);
                angle = angle - 90;
                angle = angle / 70;

                MakeUpAnimationController ctl = mainChar.GetHeadAnimationController();
                if (ctl != null)
                {
                    ctl.SetEyeballAdd(new Vector3(0, angle * 8, 0));
                }

                mainChar.LookAtTarget(pos, duration);
            }
        }

        private void resetEyeballAdd()
        {
            var mainChar = GameScene.Instance.MainChar;
            if (mainChar != null)
            {
                MakeUpAnimationController ctl = mainChar.GetHeadAnimationController();
                if (ctl != null)
                {
                    ctl.SetEyeballAdd(Vector3.zero);
                }
            }
        }

        public void SetIsInFeatureArticleState(bool isInFeatureArticleState)
        {
            var mainChar = GameScene.Instance.MainChar;
            if (mainChar != null)
            {
                mainChar.isInFeatureArticleState = isInFeatureArticleState;
            }
        }

        private bool isExitFeatureArticleState = false;
        public void ExitFeatureArticleState()
        {
            isExitFeatureArticleState = true;

            CameraController.Instance.Reset();
            //CameraController.Instance.AnimRotateTo(m_oldCamRoteX, m_oldCamRoteY, 0.5f, true);
            //CameraController.Instance.ChangeDistanceTo(m_oldCamDis-0.01f, false, true);

            //CameraController.Instance.SetCameraFov(false, 0);

            resetEyeballAdd();
            SetIsInFeatureArticleState(false);

            ICameraHelper.Instance.EnableBlur(false);
        }

        //旋转摄像机到主角面前;
        public void RoteCameraToMainCharFace(float speed)
        {
            float rotex = GameScene.Instance.MainChar.DirAngle;
            CameraController.Instance.AnimRotateTo(180 + rotex, 0, speed, true);
        }

        public enum FeatureArticleState
        {
            ONE = 0,
            TWO = 1,

            NULL
        }
    }
}
