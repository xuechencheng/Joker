﻿using System.Collections.Generic;
namespace Bokura
{
    public class FieldDispatchData
    {
        public uint type ;
        public uint id  ;   
        
        public uint GetTypeValue
        {
            get
            {
                return type;
            }
        }  
    }
    public class FieldEventAward
    {
        public uint baseid;
        public uint num;
    }
    public class FieldAdditionTipsData
    {
        public uint id;
    }
    public class FieldCompleteAwardData
    {
        public uint id;
        public string taskinfo;
        //public List<FieldEventAward> awardList;
        // public List<FieldEventAward> coinaward;
        // public ulong expaward;
    }
    public class FieldEventInfoData
    {
        public uint id       ;
        public ulong time    ;
        public string taskinfo;
    }
}
