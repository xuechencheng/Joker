﻿using Bokura;
using System.Collections.Generic;
using FlatBuffers;
namespace Bokura
{
    public class FieldEventManager: ClientSingleton<FieldEventManager>
	{

        public List<FieldEventInfoData> fieldEventInfoList = new List<FieldEventInfoData>(5);

        public FieldDispatchData npcFieldDispatchData = null;

        public FieldDispatchData itemFieldDispatchData = null;

        public FieldDispatchData areaFieldDispatchData = null;


        //事件
        public class FieldDispatchEvent : GameEvent<FieldDispatchData>
        {

        }
        public class FieldAdditionTipsEvent : GameEvent<FieldAdditionTipsData>
        {

        }
        public class FieldCompleteAwardEvent : GameEvent<FieldCompleteAwardData>
       {
        }
        public class RspFieldEventListEvent : GameEvent
        {

        }
        public FieldDispatchEvent fieldDispatchEvent = new FieldDispatchEvent();

        public FieldAdditionTipsEvent fieldAdditionTipsEvent = new FieldAdditionTipsEvent();

        public FieldCompleteAwardEvent fieldCompleteAwardEvent = new FieldCompleteAwardEvent();

        public RspFieldEventListEvent rspFieldEventListEvent = new RspFieldEventListEvent();

        /// <summary>
        /// 注册通信消息
        /// </summary>
        public void Init()
		{
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.FieldDispatch>(ProcFieldDispatch);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.FieldAdditionTips>(ProcFieldAdditionTips);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.FieldCompleteAward>(ProcFieldCompleteAward);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFieldEventList>(ProcRspFieldEventList);
        }



		/// <summary>
		/// 加载配置数据
		/// </summary>
		public void Load()
		{

		}
		
		
		public void Clear()
		{
            fieldEventInfoList.Clear();

        }

        public void ProcFieldDispatch(swm.FieldDispatch msg)
        {
            FieldDispatchData fieldDispatchData = new FieldDispatchData();
            fieldDispatchData.id = msg.id;
            fieldDispatchData.type = msg.type;
            if (fieldDispatchData.type == 1)
            {
                npcFieldDispatchData = fieldDispatchData;
            } else if (fieldDispatchData.type == 2)
            {
                itemFieldDispatchData = fieldDispatchData;
            } else if (fieldDispatchData.type == 3)
            {
                areaFieldDispatchData = fieldDispatchData;
            }
            fieldDispatchEvent.Invoke(fieldDispatchData);
        }

        public void ProcFieldAdditionTips(swm.FieldAdditionTips msg)
        {
            FieldAdditionTipsData fieldAdditionTipsData = new FieldAdditionTipsData();
            fieldAdditionTipsData.id = msg.id;
            fieldAdditionTipsEvent.Invoke(fieldAdditionTipsData);
        }
        public void ProcFieldCompleteAward(swm.FieldCompleteAward msg)
        {
            FieldCompleteAwardData fieldCompleteAwardData = new FieldCompleteAwardData();
            fieldCompleteAwardData.id        = msg.id;
            fieldCompleteAwardData.taskinfo = msg.taskinfo;

            fieldCompleteAwardEvent.Invoke(fieldCompleteAwardData);
        }

        public void ProcRspFieldEventList(swm.RspFieldEventList msg)
        {
            fieldEventInfoList.Clear();
            for (int index = 0, count =msg.fieldlistLength;index<count;index++)
            {
                FieldEventInfoData fieldEventInfoData = new FieldEventInfoData();
                swm.FieldEventInfo? fieldEventInfo = msg.fieldlist(index);

                fieldEventInfoData.id = fieldEventInfo.Value.id;
                fieldEventInfoData.time = fieldEventInfo.Value.time;
                fieldEventInfoData.taskinfo = fieldEventInfo.Value.taskinfo;

                fieldEventInfoList.Add(fieldEventInfoData);

            }
            rspFieldEventListEvent.Invoke();
        }


        public void SendReqFieldEventList()
        {

            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqFieldEventList.StartReqFieldEventList(tFBB);
            Offset<swm.ReqFieldEventList> tOffset = swm.ReqFieldEventList.EndReqFieldEventList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqFieldEventList.HashID, tFBB);
   

        }

        public void TestFun()
        {

        }

    } 

}
