using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;
using x2m;

namespace Bokura
{
    public class FormulaManager : ClientSingleton<FormulaManager>
    {
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFormulaCompose>(RspFormulaCompose_SC);
        }

        [XLua.BlackList]
        public void Clear()
        {

        }

        public uint GetItemNumberByBaseID(int baseID)
        {
            var bag = BagManager.Instance.GetBagByType(swm.BagType.ItemBag);
            if (bag != null)
            {
                return bag.Item_Manager.GetItemNumberByBaseID(baseID);
            }

            return 0;
        }

        public IdentityFormulaTableBase GetConfigDataByID(uint id)
        {
            IdentityFormulaTableBaseList list = IdentityFormulaTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityFormulaTableLength; i < count; ++i)
            {
                IdentityFormulaTableBase table = list.IdentityFormulaTable(i).Value;

                if (table.id == id)
                {
                    return table;
                }
            }

            return default(IdentityFormulaTableBase);
        }

        private List<IdentityFormulaTableBase> m_tempDatas = new List<IdentityFormulaTableBase>(0);
        public List<IdentityFormulaTableBase> GetIdentityFormulaDatasByTalentId(uint talentId, int iType)
        {
            m_tempDatas.Clear();

            IdentityFormulaTableBaseList list = IdentityFormulaTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityFormulaTableLength; i < count; ++i)
            {
                IdentityFormulaTableBase table = list.IdentityFormulaTable(i).Value;

                if (table.talent_id == talentId)
                {
                    if (table.type == iType)
                    {
                        m_tempDatas.Add(table);
                    }
                }
            }

            return m_tempDatas;
        }

        public List<IdentityFormulaTableBase> GetIdentityFormulaDatasNotStar(uint talentId)
        {
            m_tempDatas.Clear();

            IdentityFormulaTableBaseList list = IdentityFormulaTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityFormulaTableLength; i < count; ++i)
            {
                IdentityFormulaTableBase table = list.IdentityFormulaTable(i).Value;

                if (table.talent_id == talentId)
                {
                    if (table.type != 0)
                    {
                        m_tempDatas.Add(table);
                    }
                }
            }

            return m_tempDatas;
        }

        public List<IdentityFormulaTableBase> GetIdentityFormulaDatasByType(int identityType)
        {
            List<IdentityFormulaTableBase> tempDatas = new List<IdentityFormulaTableBase>(0);

            List<int> ids = IdentityManager.Instance.GetCurrTalentMaxIDsByType(identityType);

            for(int i=0; i<ids.Count; ++i)
            {
                int id = ids[i];

                List<IdentityFormulaTableBase> currList = GetIdentityFormulaDatasNotStar((uint)id);
                while (currList.Count == 0)
                {
                    if (id == 0)
                    {
                        break;
                    }
                    else
                    {
                        IdentityTableBase cfg = IdentityManager.Instance.GetCurrTalentConfigById(id);

                        id = cfg.pre_talent_id;

                        if (id == 0) { break; }
                        else
                        {
                            currList = GetIdentityFormulaDatasNotStar((uint)id);
                        }
                    }
                }

                if (currList.Count > 0)
                {
                    foreach(IdentityFormulaTableBase item in currList)
                    {
                        tempDatas.Add(item);
                    }
                }
            }

            return tempDatas;
        }

        public List<IdentityFormulaTableBase> GetIdentityFormulaStarDatasByType(int identityType)
        {
            List<IdentityFormulaTableBase> tempDatas = new List<IdentityFormulaTableBase>(0);

            List<int> ids = IdentityManager.Instance.GetCurrTalentMaxIDsByType(identityType);

            for (int i = 0; i < ids.Count; ++i)
            {
                int id = ids[i];

                do
                {
                    if (id != 0)
                    {
                        IdentityTableBase cfg = IdentityManager.Instance.GetCurrTalentConfigById(id);
                        List<IdentityFormulaTableBase> currList = GetIdentityFormulaDatasByTalentId((uint)id, 0);

                        if (currList.Count > 0)
                        {
                            foreach (IdentityFormulaTableBase item in currList)
                            {
                                tempDatas.Add(item);
                            }
                        }

                        id = cfg.pre_talent_id;
                    }
                } while (id != 0);
            }

            return tempDatas;
        }

        public void ReqFormulaCompose(uint id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqFormulaCompose.StartReqFormulaCompose(fbb);
            swm.ReqFormulaCompose.AddFormulaId(fbb, id);
            fbb.Finish(swm.ReqFormulaCompose.EndReqFormulaCompose(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqFormulaCompose.HashID, fbb);
        }
        public GameEvent<uint, bool> OnFormulaComposeFinished = new GameEvent<uint, bool>();
        private void RspFormulaCompose_SC(swm.RspFormulaCompose msg)
        {
            OnFormulaComposeFinished.Invoke(msg.formula_id, msg.is_ok);
        }
    }
}
