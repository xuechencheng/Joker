﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bokura
{
    /// <summary>
    /// 社交关系基类
    /// </summary>
    public class SocialDataBase
    {
        private ulong m_ID = 0;
        private string m_Name = string.Empty;
        private swm.SocialBasicDataT m_NetData;

        private ulong m_UnReadMessageNumber = 0;
        protected bool m_bIsInitUnReadMessage = false;
        public ulong UnReadMessageNumber
        {
            get
            {
                return m_UnReadMessageNumber;
            }
            set
            {
                m_UnReadMessageNumber = value;

            }
        }

        public ulong ID
        {
            get
            {
                return m_ID;
            }
            set
            {
                m_ID = value;
            }
        }

        public swm.SocialBasicDataT NetData
        {
            get
            {
                return m_NetData;
            }
        }

        public int Career
        {
            get
            {
                if(null != m_NetData)
                {
                    return (int)m_NetData.career;
                }
                return 0;
            }
        }

        public string Name
        {
            get
            {
                return m_Name;
            }
            set
            {
                m_Name = value;
            }
        }
        public void RefreshSocialStateData(swm.RefreshSocialState _state)
        {
            NetData.state = _state.state;
        }

        public void RefreshSocialBasicData(swm.SocialBasicData? _data)
        {
            if(_data.HasValue)
            {
                ID = _data.Value.entity_id;
                if (m_NetData == null)
                    m_NetData = new swm.SocialBasicDataT();
                m_NetData.FromMsg(_data.Value);
            }
        }

        public virtual void Destory()
        {
            m_NetData = null;
        }

        protected void InitUnReadMessageNum(ulong _num)
        {
            if (!m_bIsInitUnReadMessage)
            {
                m_bIsInitUnReadMessage = true;
                m_UnReadMessageNumber = _num;
            }
        }
    }

    /// <summary>
    /// 好友数据
    /// </summary>
    public class FriendData : SocialDataBase
    {
        private swm.FriendDataT m_FriendNetData;
        public swm.FriendDataT FriendNetData
        {
            get
            {
                return m_FriendNetData;
            }
        }



        public uint friendiness { get { return m_FriendNetData.friendiness; } }



        public ulong charID { get { return m_FriendNetData.base_data.entity_id; } }



        public void RefreshData(swm.FriendData _data)
        {
            RefreshSocialBasicData(_data.base_data);
            if (m_FriendNetData == null)
                m_FriendNetData = new swm.FriendDataT();
            m_FriendNetData.FromMsg( _data);
            InitUnReadMessageNum(_data.unread);
        }

        public override void Destory()
        {
            base.Destory();
            m_FriendNetData = null;
        }
    }

    /// <summary>
    /// 黑名单数据
    /// </summary>
    public class BlackManData : SocialDataBase
    {
        private swm.BlackListDataT m_BlackManNetData;
        public swm.BlackListDataT BlackManNetData
        {
            get
            {
                return m_BlackManNetData;
            }
        }
        public void RefreshData(swm.BlackListData _data)
        {
            base.RefreshSocialBasicData(_data.base_data);
            if (m_BlackManNetData == null)
                m_BlackManNetData = new swm.BlackListDataT();
            m_BlackManNetData.FromMsg(_data);
        }
        public override void Destory()
        {
            base.Destory();
            m_BlackManNetData = null;
        }
    }

    /// <summary>
    /// 最近联系人
    /// </summary>
    public class RecentlyData : SocialDataBase
    {
        private swm.ContactDataT m_RecentlyData;
        public swm.ContactDataT RecentlyNetData
        {
            get
            {
                return m_RecentlyData;
            }
        }
        public void RefreshData(swm.ContactData _data)
        {
            base.RefreshSocialBasicData(_data.base_data);
            if (m_RecentlyData == null)
                m_RecentlyData = new swm.ContactDataT();
            m_RecentlyData.FromMsg(_data);
            InitUnReadMessageNum(_data.unread);
        }
        public override void Destory()
        {
            base.Destory();
            m_RecentlyData = null;
        }

        public bool CheckContactType(swm.ContactType _compareTye)
        {
            return (_compareTye & (swm.ContactType)RecentlyNetData.type) == _compareTye;
        }
    }

    /// <summary>
    /// npc好友
    /// </summary>
    public class NpcFriendData : SocialDataBase
    {
        private swm.FriendDataT m_NpcFriendData;
        public swm.FriendDataT NpcFriendNetData
        {
            get
            {
                return m_NpcFriendData;
            }
        }
        public void RefreshData(swm.FriendData _data)
        {
            base.RefreshSocialBasicData(_data.base_data);
            if (m_NpcFriendData == null)
                m_NpcFriendData = new swm.FriendDataT();
            m_NpcFriendData.FromMsg(_data);
            InitUnReadMessageNum(_data.unread);
        }
        public override void Destory()
        {
            base.Destory();
            m_NpcFriendData = null;
        }

        //public bool CheckContactType(swm.ContactType _compareTye)
        //{
        //    return (_compareTye & (swm.ContactType)RecentlyNetData.type) == _compareTye;
        //}
    }
}
