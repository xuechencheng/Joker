using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public enum Enum_Socil_C
     {
         E_NONE = 0,//默认
         E_RECENTLY = 100,//最近
         E_RECENTLYTEAM = 101,//最近队友
         E_FRIEND = 200,//好友
         E_BLACKMAN = 300,//黑名单
         E_NPCFRIEND = 400,//npc好友
    }
    /// <summary>
    /// 好友数据模块
    /// </summary>
    class FriendModel : ClientSingleton<FriendModel>
    {
        private List<FriendData> m_FriendList = new List<FriendData>();
        private List<BlackManData> m_BlackManList = new List<BlackManData>();
        private List<RecentlyData> m_RecentlyList = new List<RecentlyData>();

        private List<NpcFriendData> m_NpcFriendList = new List<NpcFriendData>(5);//npc好友

        private bool m_bIsInitRecentlyList = false;

        private ulong m_FriendApplyRedPointNum = 0;//申请列表的 红点数量
        private bool m_bHasStartContactRedPoint = false;//初始化 第一次服务器通知的 有没有最近联系人的红点
        public bool ISHasStartContactRedPoint
        {
            get
            {
                return m_bHasStartContactRedPoint;
            }
            set
            {
                m_bHasStartContactRedPoint = value;
            }
        }
        public ulong FriendApplyRedPointNum
        {
            get
            {
                return m_FriendApplyRedPointNum;
            }
            set
            {
                m_FriendApplyRedPointNum = value;
                onFriendApplyRedPointChangeEvent.Invoke(m_FriendApplyRedPointNum);
            }
        }
        /// <summary>
        /// 好友列表
        /// </summary>
        public List<FriendData> FriendList
        {
            get
            {
                return m_FriendList;
            }
        }
        /// <summary>
        /// 黑名单列表
        /// </summary>
        public List<BlackManData> BlackManList
        {
            get
            {
                return m_BlackManList;
            }
        }
        /// <summary>
        /// 最近联系人列表
        /// </summary>
        public List<RecentlyData> RecentlyList
        {
            get
            {
                return m_RecentlyList;
            }
        }
        /// <summary>
        /// npc好友列表
        /// </summary>
        public List<NpcFriendData> NpcFriendList
        {
            get
            {
                return m_NpcFriendList;
            }
        }

        //事件
        public class AddFriendEvent : GameEvent<FriendData>
        {

        }

        public class AddBlackManEvent : GameEvent<BlackManData>
        {

        }

        public class AddRecentlyEvent : GameEvent<RecentlyData>
        {

        }

        public class FriendApplyEvent : GameEvent<swm.FriendApplyDataT>
        {

        }

        public class FriendApplyListEvent : GameEvent<List<swm.FriendApplyDataT>>
        {

        }

        public class DelFriendApplyEvent : GameEvent<ulong>
        {

        }
        public class DelFriendApplysEvent : GameEvent<swm.RspAnswerApplyFriend>
        {

        }

        public class SocialDataListEvent : GameEvent<List<swm.SocialBasicDataT>>
        {

        }

        public class AddNpcFriendEvent : GameEvent<NpcFriendData> { }  //添加npc好友
        public class RemoveNpcFriendEvent : GameEvent<NpcFriendData> { } //删除npc好友
        public class UpdataNpcFriendEvent : GameEvent<NpcFriendData> { } //更新npc好友

        public AddFriendEvent onAddFriendEvent = new AddFriendEvent();
        public AddFriendEvent onRefreshFriendEvent = new AddFriendEvent();
        public AddFriendEvent onRemoveFriendEvent = new AddFriendEvent();
        public AddFriendEvent onRefreshFriendSocialStateEvent = new AddFriendEvent();
        public GameEvent onInitGetFriendListEvent = new GameEvent();
        public FriendApplyListEvent onInitFriendApplyListEvent = new FriendApplyListEvent();
        public FriendApplyEvent onAddFriendApplyEvent = new FriendApplyEvent();
        public DelFriendApplyEvent onDelFriendApplyEvent = new DelFriendApplyEvent();
        public DelFriendApplysEvent onDelFriendAppliesEvent = new DelFriendApplysEvent();
        public SocialDataListEvent onSearchResultListEvent = new SocialDataListEvent();
        public AddBlackManEvent onAddBlackManEvent = new AddBlackManEvent();
        public AddBlackManEvent onRefreshBlackManEvent = new AddBlackManEvent();
        public AddBlackManEvent onRemoveBlackManEvent = new AddBlackManEvent();
        public AddBlackManEvent onRefreshBlackManSocialStateEvent = new AddBlackManEvent();
        public GameEvent onInitGetBlackManListEvent = new GameEvent();
        public AddRecentlyEvent onAddRecentlyEvent = new AddRecentlyEvent();
        public AddRecentlyEvent onRefreshRecentlyEvent = new AddRecentlyEvent();
        public AddRecentlyEvent onRemoveRecentlyEvent = new AddRecentlyEvent();
        public AddRecentlyEvent onRefreshRecentlySocialStateEvent = new AddRecentlyEvent();
        public GameEvent onInitGetRecentlyListEvent = new GameEvent();
        public GameEvent onRefreshSocialStateEvent = new GameEvent();
        public DelFriendApplyEvent onFriendApplyRedPointChangeEvent = new DelFriendApplyEvent();
        public AddFriendEvent onFriendUnReadMessageNumberChangeEvent = new AddFriendEvent();
        public AddRecentlyEvent onRecentlyUnReadMessageNumberChangeEvent = new AddRecentlyEvent();

        public AddNpcFriendEvent onAddNpcFriendEvent = new AddNpcFriendEvent();
        public RemoveNpcFriendEvent onRemoveNpcFriendEvent = new RemoveNpcFriendEvent();
        public UpdataNpcFriendEvent onUpdataNpcFriendEvent = new UpdataNpcFriendEvent();

        [XLua.BlackList]
        public void Init()
        {
            //注册系统逻辑事件
            RedDotModel.Instance.onRedDotEvent.AddListener(PorcRedPoint);
            ChatModel.Instance.onUnReadMessageNumberChangeEvent.AddListener(PorcChatUnReadMessage);

            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFriendList>(ProcRspFriendList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFriendApplyList>(ProcRspFriendApplyList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAddFriendApply>(ProcRspAddFriendApply);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspDelFriendApply>(ProcRspDelFriendApply);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAnswerApplyFriend>(ProcRspDelFriendApplies);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAddFriend>(ProcRspAddFriend);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspDelFriend>(ProcRspDelFriend);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshSocialState>(ProcRefreshSocialState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspSearchResult>(ProcRspSearchResult);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspBlackList>(ProcRspBlackList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAddBlackList>(PorcRspAddBlackList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspDelBlackList>(ProcRspDelBlackList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspContactList>(ProcRspContactList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRefeshContact>(ProcRspRefeshContact);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspDelContact>(ProcRspDelContact);

           // MsgDispatcher.instance.RegisterMsgProc<x2m.RspAddNpcFriendApply>(ProcRspAddNpcFriendApply);
            //MsgDispatcher.instance.RegisterMsgProc<x2m.RspDelNpcFriendApply>(ProcRspDelNpcFriendApply);
        }

        /// <summary>
        /// 清除所有数据
        /// </summary>
        public void Clear()
        {
            m_FriendApplyRedPointNum = 0;
            m_bIsInitRecentlyList = false;
            m_bHasStartContactRedPoint = false;
            for (int i=0;i<m_FriendList.Count;i++)
            {
                m_FriendList[i].Destory();
            }
            m_FriendList.Clear();

            for (int i = 0; i < m_BlackManList.Count; i++)
            {
                m_BlackManList[i].Destory();
            }
            m_BlackManList.Clear();

            for (int i = 0; i < m_RecentlyList.Count; i++)
            {
                m_RecentlyList[i].Destory();
            }
            m_RecentlyList.Clear();

            for (int i = 0; i < m_NpcFriendList.Count; i++)
            {
                m_NpcFriendList[i].Destory();
            }
            m_NpcFriendList.Clear();
        }



        /// <summary>
        /// 好友数量
        /// </summary>
        public int friendCount { get { return m_FriendList.Count; } }



        /// <summary>
        /// 按序获取好友数据
        /// </summary>
        public FriendData GetFriendByIndex(int index)
        {
            FriendData tData = null;
            if (index >= 0 && index < friendCount)
                tData = m_FriendList[index];
            return tData;
        }



        //客户端处理
        public ProfessionTableBase  GetProfessionByCareer(swm.CareerType _type)
        {
            return ProfessionTableManager.GetData((int)_type).Value;
        }
        /// <summary>
        /// 关于 好友的红点数据和处理
        /// </summary>
        /// <param name="_msg"></param>
        private void PorcRedPoint(RedDotData _msg)
        {
            if(_msg.RedDotType == swm.RedDotType.FRIENDAPPLY)
            {
                FriendApplyRedPointNum = _msg.Num;
            }
            else if(_msg.RedDotType == swm.RedDotType.CONTACTS && !m_bIsInitRecentlyList)//没有请求过最近联系就接收这个红点
            {
                m_bHasStartContactRedPoint = true;
            }
        }

        /// <summary>
        /// 同步 未读消息
        /// </summary>
        /// <param name="_num"></param>
        /// <param name="_id"></param>
        /// <param name="_channelData"></param>
        private void PorcChatUnReadMessage(ulong _num,ulong _id,ChannelData _channelData)
        {
            if(_id != 0)
            {
                FriendData _fData = GetFriendDataById(_id);
                if(null != _fData)
                {
                    if(_fData.UnReadMessageNumber!=_num)
                    {
                        _fData.UnReadMessageNumber = _num;
                        onFriendUnReadMessageNumberChangeEvent.Invoke(_fData);
                    }
                }
                RecentlyData _rData = GetRecentlyDataById(_id);
                if(null != _rData)
                {
                    if(_rData.UnReadMessageNumber != _num)
                    {
                        if(_rData.UnReadMessageNumber < _num)
                        {
                            _rData.RecentlyNetData.last_time = GameScene.Instance.GetServerTime();
                            SortRecentlyList();
                            onRefreshRecentlyEvent.Invoke(_rData);
                        }

                        _rData.UnReadMessageNumber = _num;
                        onRecentlyUnReadMessageNumberChangeEvent.Invoke(_rData);
                    }
                }
            }
        }

        //好友的相关
        /// <summary>
        /// 通过id 获得一个好友数据
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public FriendData GetFriendDataById(ulong _id)
        {
            FriendData _data = null;
            for(int i=0;i< m_FriendList.Count;i++)
            {
                _data = m_FriendList[i];
                if(_data.ID == _id)
                {
                    return _data;
                }
            }
            return null;
        }
        /// <summary>
        /// 添加好友进列表
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="_bIsSend"></param>
        /// <returns></returns>
        private FriendData AddFriend(swm.FriendData _data,bool _bIsSend = false)
        {
            FriendData _FriendData = GetFriendDataById(_data.base_data.Value.entity_id);
            if(null== _FriendData)
            {
                //没有 增加
                _FriendData = new FriendData();
                _FriendData.RefreshData(_data);
                m_FriendList.Add(_FriendData);
                if (_bIsSend)
                {
                    SortFriendList();
                    onAddFriendEvent.Invoke(_FriendData);
                }
                
            }
            else
            {
                //已有 刷新
                _FriendData.RefreshData(_data);
                if(_bIsSend)
                {
                    onRefreshFriendEvent.Invoke(_FriendData);
                }
            }
            return _FriendData;
        }
        /// <summary>
        /// 通过id删除一个好友
        /// </summary>
        /// <param name="_id"></param>
        private void RemoveFriendById(ulong _id)
        {
            FriendData _FriendData = GetFriendDataById(_id);
            if(null != _FriendData)
            {
                RecentlyData _reData = GetRecentlyDataById(_id);
                if(null == _reData)
                {
                    ChatModel.Instance.RemoveChannelAllChatData(swm.ChatPosType.PRIVATE, _id);//删除客户端本地的聊天记录
                }
                onRemoveFriendEvent.Invoke(_FriendData);
                _FriendData.Destory();
                m_FriendList.Remove(_FriendData);
            }
        }
        /// <summary>
        /// 排序好友列表
        /// </summary>
        public void SortFriendList()
        {
            if (m_FriendList.Count > 0)
            {
                m_FriendList.Sort(ProcessSrotFriendList);
            }
        }

        public int ProcessSrotFriendList(FriendData _a, FriendData _b)
        {
            if (_a.NetData.state < _b.NetData.state)
            {
                return -1;
            }
            else if (_a.NetData.state > _b.NetData.state)
            {
                return 1;
            }
            if (_a.FriendNetData.create_time < _b.FriendNetData.create_time)
            {
                return -1;
            }
            else if (_a.FriendNetData.create_time > _b.FriendNetData.create_time)
            {
                return 1;
            }
            if (_a.ID < _b.ID)
            {
                return -1;
            }
            else if (_a.ID == _b.ID)
            {
                return 0;
            }
            return 1;
        }

        //黑名单的相关
        /// <summary>
        /// 通过id 获得黑名单列表里的数据
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public BlackManData GetBlackManDataById(ulong _id)
        {
            BlackManData _data = null;
            for (int i = 0; i < m_BlackManList.Count; i++)
            {
                _data = m_BlackManList[i];
                if (_data.ID == _id)
                {
                    return _data;
                }
            }
            return null;
        }
        /// <summary>
        /// 添加一个黑名单数据
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="_bIsSend"></param>
        /// <returns></returns>
        private BlackManData AddBlackMan(swm.BlackListData _data, bool _bIsSend = false)
        {
            BlackManData _blackManData = GetBlackManDataById(_data.base_data.Value.entity_id);
            if (null == _blackManData)
            {
                //没有 增加
                _blackManData = new BlackManData();
                _blackManData.RefreshData(_data);
                m_BlackManList.Add(_blackManData);
                if (_bIsSend)
                {
                    SortBlackManList();
                    onAddBlackManEvent.Invoke(_blackManData);
                }
            }
            else
            {
                //已有 刷新
                _blackManData.RefreshData(_data);
                if (_bIsSend)
                {
                    onRefreshBlackManEvent.Invoke(_blackManData);
                }
            }
			ChatModel.Instance.RemoveChannelAllChatData(swm.ChatPosType.PRIVATE, _data.base_data.Value.entity_id);
            return _blackManData;
        }
        /// <summary>
        /// 通过id 删除一个黑名单数据
        /// </summary>
        /// <param name="_id"></param>
        private void RemoveBlackManById(ulong _id)
        {
            BlackManData _BlackManData = GetBlackManDataById(_id);
            if (null != _BlackManData)
            {
                onRemoveBlackManEvent.Invoke(_BlackManData);
                _BlackManData.Destory();
                m_BlackManList.Remove(_BlackManData);
            }
        }
        /// <summary>
        /// 排序黑名单列表
        /// </summary>
        public void SortBlackManList()
        {
            if (m_BlackManList.Count > 0)
            {
                m_BlackManList.Sort(ProcessSrotBlackManList);
            }
        }

        public int ProcessSrotBlackManList(BlackManData _a, BlackManData _b)
        {
            if (_a.NetData.state < _b.NetData.state)
            {
                return -1;
            }
            else if (_a.NetData.state > _b.NetData.state)
            {
                return 1;
            }

            if (_a.ID < _b.ID)
            {
                return -1;
            }
            else if (_a.ID == _b.ID)
            {
                return 0;
            }
            return 1;
        }

        //最近联系人
        /// <summary>
        /// 通过id获得一个最近联系人数据
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public RecentlyData GetRecentlyDataById(ulong _id, swm.ContactType _compareTye = swm.ContactType.UNKNOWN)
        {
            RecentlyData _data = null;
            for (int i = 0; i < m_RecentlyList.Count; i++)
            {
                _data = m_RecentlyList[i];
                if (_data.ID == _id)
                {
                    if(_compareTye == swm.ContactType.UNKNOWN)
                    {
                        return _data;
                    }
                    else
                    {
                        if(_data.CheckContactType(_compareTye))
                        {
                            return _data;
                        }
                    }
                    return null;
                }
            }
            return null;
        }
        /// <summary>
        /// 增加一个最近联系人
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="_bIsSend"></param>
        /// <returns></returns>
        private RecentlyData AddRecently(swm.ContactData _data, bool _bIsSend = false)
        {
            RecentlyData _RecentlyData = GetRecentlyDataById(_data.base_data.Value.entity_id);
            if (null == _RecentlyData)
            {
                //没有 增加
                _RecentlyData = new RecentlyData();
                _RecentlyData.RefreshData(_data);
                m_RecentlyList.Add(_RecentlyData);
                if (_bIsSend)
                {
                    SortRecentlyList();
                    onAddRecentlyEvent.Invoke(_RecentlyData);
                }
            }
            else
            {
                //已有 刷新
                _RecentlyData.RefreshData(_data);
                if (_bIsSend)
                {
                    SortRecentlyList();
                    onRefreshRecentlyEvent.Invoke(_RecentlyData);
                }
            }
            return _RecentlyData;
        }
        /// <summary>
        /// 通过id 删除一个最近联系人
        /// </summary>
        /// <param name="_id"></param>
        private void RemoveRecentlyById(ulong _id)
        {
            RecentlyData _RecentlyData = GetRecentlyDataById(_id);
            if (null != _RecentlyData)
            {
                FriendData _fData = GetFriendDataById(_id);
                if(null == _fData)
                {
                    ChatModel.Instance.RemoveChannelAllChatData(swm.ChatPosType.PRIVATE, _id);
                }

                onRemoveRecentlyEvent.Invoke(_RecentlyData);
                _RecentlyData.Destory();
                m_RecentlyList.Remove(_RecentlyData);
            }
        }
        /// <summary>
        /// 排序最近联系人列表
        /// </summary>
        public void SortRecentlyList()
        {
            if (m_RecentlyList.Count > 0)
            {
                m_RecentlyList.Sort(ProcessSrotRecentlyList);
            }
        }

        public int ProcessSrotRecentlyList(RecentlyData _a, RecentlyData _b)
        {
            if(_a.NetData.state < _b.NetData.state)
            {
                return -1;
            }
            else if(_a.NetData.state > _b.NetData.state)
            {
                return 1;
            }
            if (_a.RecentlyNetData.last_time > _b.RecentlyNetData.last_time)
            {
                return -1;
            }
            else if (_a.RecentlyNetData.last_time < _b.RecentlyNetData.last_time)
            {
                return 1;
            }
            

            if (_a.ID < _b.ID)
            {
                return -1;
            }
            else if (_a.ID == _b.ID)
            {
                return 0;
            }
            return 1;
        }

		public int ProcessSrotRecentlyTeamList(RecentlyData _a, RecentlyData _b)
		{

			if (_a.RecentlyNetData.create_time < _b.RecentlyNetData.create_time)
			{
				return -1;
			}
			else if (_a.RecentlyNetData.create_time > _b.RecentlyNetData.create_time)
			{
				return 1;
			}


			if (_a.ID < _b.ID)
			{
				return -1;
			}
			else if (_a.ID == _b.ID)
			{
				return 0;
			}
			return 1;
		}
		//

		//接收网络消息
		/// <summary>
		/// 接收 好友列表
		/// </summary>
		/// <param name="_msg"></param>
		private void ProcRspFriendList(swm.RspFriendList _msg)
        {
            //if(_msg.data )
            {
                for (int i = 0; i < _msg.dataLength; i++)
                {
                    var _fData = _msg.data(i).Value;
                    if(_fData.unread > 0)
                    {
                        //同步聊天数据的数量
                        ChatModel.Instance.SetUnReadMessageNumber(_fData.unread, _fData.base_data.Value.entity_id, false);
                    }
                    AddFriend(_fData);
                }
                SortFriendList();
                onInitGetFriendListEvent.Invoke();
            }
        }

        /// <summary>
        /// 接收 好友申请列表
        /// </summary>
        /// <param name="_msg"></param>
        swm.RspFriendApplyListT m_recvRspFriendApplyList = new swm.RspFriendApplyListT();
        private void ProcRspFriendApplyList(swm.RspFriendApplyList _msg)
        {
            m_recvRspFriendApplyList.FromMsg(_msg);
            onInitFriendApplyListEvent.Invoke(m_recvRspFriendApplyList.data);
        }

        /// <summary>
        /// 接收 添加申请
        /// </summary>
        /// <param name="_msg"></param>
        swm.FriendApplyDataT m_recvRspAddFriendApply = new swm.FriendApplyDataT();
        private void ProcRspAddFriendApply(swm.RspAddFriendApply _msg)
        {
            
            m_recvRspAddFriendApply.FromMsg(_msg.data.Value);
            onAddFriendApplyEvent.Invoke(m_recvRspAddFriendApply);
        }

        /// <summary>
        /// 接收 删除申请
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspDelFriendApply(swm.RspDelFriendApply _msg)
        {

            onDelFriendApplyEvent.Invoke(_msg.applicant_id);
        }

        private void ProcRspDelFriendApplies(swm.RspAnswerApplyFriend _msg)
        {
            onDelFriendAppliesEvent.Invoke(_msg);
        }

        /// <summary>
        /// 接收 添加好友
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspAddFriend(swm.RspAddFriend _msg)
        {
            AddFriend(_msg.data.Value, true);
        }
        /// <summary>
        /// 接收 删除好友
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspDelFriend(swm.RspDelFriend _msg)
        {
           
            RemoveFriendById(_msg.friend_id);
        }

        /// <summary>
        /// 接收 刷新好友状态
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshSocialState(swm.RefreshSocialState _msg)
        {
            FriendData _fData = GetFriendDataById(_msg.userid);
            if(null != _fData)
            {
                _fData.RefreshSocialStateData(_msg);
                onRefreshFriendSocialStateEvent.Invoke(_fData);
            }
            BlackManData _bData = GetBlackManDataById(_msg.userid);
            if (null != _bData)
            {
                _bData.RefreshSocialStateData(_msg);
                onRefreshBlackManSocialStateEvent.Invoke(_bData);
            }
            RecentlyData _rData = GetRecentlyDataById(_msg.userid);
            if (null != _rData)
            {
                _rData.RefreshSocialStateData(_msg);
                onRefreshRecentlySocialStateEvent.Invoke(_rData);
            }
            if(null != _fData || null != _bData || null != _rData )
            {
                onRefreshSocialStateEvent.Invoke();
            }
        }
        /// <summary>
        /// 接收 搜索列表
        /// </summary>
        /// <param name="_msg"></param>
        swm.RspSearchResultT m_recvRspSearchResult = new swm.RspSearchResultT();
        private void ProcRspSearchResult(swm.RspSearchResult _msg)
        {
            m_recvRspSearchResult.FromMsg(_msg);
            onSearchResultListEvent.Invoke(m_recvRspSearchResult.datas);
        }
        /// <summary>
        /// 接收 黑名单列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspBlackList(swm.RspBlackList _msg)
        {
            if (_msg.dataLength>0)
            {
                for (int i = 0; i < _msg.dataLength; i++)
                {
                    AddBlackMan(_msg.data(i).Value);
                }
                SortBlackManList();
                onInitGetBlackManListEvent.Invoke();
            }   
        }

        /// <summary>
        /// 接收 添加到黑名单
        /// </summary>
        /// <param name="_msg"></param>
        private void PorcRspAddBlackList(swm.RspAddBlackList _msg)
        {
            AddBlackMan(_msg.data.Value, true);
        }
        /// <summary>
        /// 接收 从黑名单删除
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspDelBlackList(swm.RspDelBlackList _msg)
        {
            RemoveBlackManById(_msg.id);
        }

        /// <summary>
        /// 接收 最近联系人列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspContactList(swm.RspContactList _msg)
        {
            if (_msg.dataLength>0)
            {
                for (int i = 0; i < _msg.dataLength; i++)
                {
                    var _fData = _msg.data(i).Value;
                    if (_fData.unread > 0)
                    {
                        //同步聊天数据的数量
                        ChatModel.Instance.SetUnReadMessageNumber(_fData.unread, _fData.base_data.Value.entity_id, false);
                    }
                    AddRecently(_msg.data(i).Value);
                }
                SortRecentlyList();
                onInitGetRecentlyListEvent.Invoke();
            }
        }
        /// <summary>
        /// 接收 通知删除联系人
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspDelContact(swm.RspDelContact _msg)
        {
            RemoveRecentlyById(_msg.userid);
        }
        /// <summary>
        ///接收 通知刷新联系人 如果没有会增加一个
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspRefeshContact(swm.RspRefeshContact _msg)
        {
            AddRecently(_msg.data.Value,true);
        }
        //

        //发送网络消息
        /// <summary>
        /// 发送 通过类型请求列表
        /// </summary>
        /// <param name="_type"></param>
        public void SendReqSocialList(swm.SocialType _type)
        {
            if(_type==swm.SocialType.CONTACT )
            {
                if(m_bIsInitRecentlyList)
                {
                    //最近联系人列表支请求一次
                    onInitGetRecentlyListEvent.Invoke();
                    return;
                }
                m_bHasStartContactRedPoint = false;
                m_bIsInitRecentlyList = true;
                
            }
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSocialList.StartReqSocialList(fbb);
            swm.ReqSocialList.AddType(fbb, _type);
            fbb.Finish(swm.ReqSocialList.EndReqSocialList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSocialList.HashID, fbb);
            //x2m.ReqSocialList msg = new x2m.ReqSocialList();
            //msg.type = _type;
            //MsgDispatcher.instance.SendPackage(msg);
        }


        /// <summary>
        /// 发送 申请好友
        /// </summary>
        /// <param name="_IdLst"></param>
        swm.ReqApplyFriendT m_sendReqApplyFriend = new swm.ReqApplyFriendT();
        public void SendReqApplyFriend(List<ulong> _IdLst)
        {
            if(null != _IdLst && _IdLst.Count > 0)
            {
                m_sendReqApplyFriend.ids = _IdLst;
                //var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                //fbb.Finish(m_sendReqApplyFriend.ToMsg(fbb).Value);
                MsgDispatcher.instance.SendFBPackage(m_sendReqApplyFriend);
                //x2m.ReqApplyFriend msg = new x2m.ReqApplyFriend();
                //for (int i = 0; i < _IdLst.Count; i++)
                //{
                //    msg.ids.Add(_IdLst[i]);
                //}
                //MsgDispatcher.instance.SendPackage(msg);
            }
        }

        /// <summary>
        /// 发送 回复申请
        /// </summary>
        /// <param name="_bIsAgree"></param>
        /// <param name="_IdLst"></param>
        swm.ReqAnswerApplyFriendT m_sendReqAnswerApplyFriend = new swm.ReqAnswerApplyFriendT();
        public void SendReqAnswerApplyFriend( swm.AnswerApply _answer, List<ulong> _IdLst)
        {
            if(null != _IdLst && _IdLst.Count > 0)
            {
                //x2m.ReqAnswerApplyFriend msg = new x2m.ReqAnswerApplyFriend();
                m_sendReqAnswerApplyFriend.ids = _IdLst;
                m_sendReqAnswerApplyFriend.agree = _answer;
                //var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                //fbb.Finish(m_sendReqAnswerApplyFriend.ToMsg(fbb).Value);
                MsgDispatcher.instance.SendFBPackage(m_sendReqAnswerApplyFriend);
                //for (int i = 0; i < _IdLst.Count; i++)
                //{
                //    msg.ids.Add(_IdLst[i]);
                //}
                //MsgDispatcher.instance.SendPackage(msg);
            }
        }

        /// <summary>
        /// 发送 删除好友
        /// </summary>
        /// <param name="_friendId"></param>
        public void SendReqDelFriend(ulong _friendId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqDelFriend.StartReqDelFriend(fbb);
            swm.ReqDelFriend.AddFriendId(fbb, _friendId);
            fbb.Finish(swm.ReqDelFriend.EndReqDelFriend(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqDelFriend.HashID, fbb);
            //x2m.ReqDelFriend msg = new x2m.ReqDelFriend();
            //msg.friend_id = _friendId;
            //MsgDispatcher.instance.SendPackage(msg);
        }

        /// <summary>
        /// 发送 搜索好友
        /// </summary>
        /// <param name="_condition"></param>
        swm.ReqSearchFriendT m_sendReqSearchFriend = new swm.ReqSearchFriendT();
        public void SendReqSearchFriend(swm.FriendSearchConditionT _condition)
        {
            //x2m.ReqSearchFriend msg = new x2m.ReqSearchFriend();
            if(null != _condition)
            {
                m_sendReqSearchFriend.condition = _condition;
                ulong id = 0;
                if(ulong.TryParse(m_sendReqSearchFriend.condition.name,out id))
                {
                    m_sendReqSearchFriend.condition.id = id;
                }
            }

            //var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            //fbb.Finish(m_sendReqSearchFriend.ToMsg(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(m_sendReqSearchFriend);
            //MsgDispatcher.instance.SendPackage(msg);
        }

        /// <summary>
        /// 发送 添加入黑名单
        /// </summary>
        /// <param name="_IdLst"></param>
        swm.ReqAddBlackListT m_sendReqAddBlackList = new swm.ReqAddBlackListT();
        public void SendReqAddBlackList(List<ulong> _IdLst)
        {
            if( null != _IdLst && _IdLst.Count > 0)
            {
                m_sendReqAddBlackList.ids = _IdLst;
                //var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                //fbb.Finish(m_sendReqAddBlackList.ToMsg(fbb).Value);
                MsgDispatcher.instance.SendFBPackage(m_sendReqAddBlackList);
               // x2m.ReqAddBlackList msg = new x2m.ReqAddBlackList();
                //for(int i =0;i< _IdLst.Count;i++)
                //{
                //    msg.ids.Add(_IdLst[i]);
                //}
                //MsgDispatcher.instance.SendPackage(msg);
            }
        }
        /// <summary>
        /// 发送 请求删除黑名单
        /// </summary>
        /// <param name="_IdLst"></param>
        swm.ReqDelBlackListT m_sendReqDelBlackList = new swm.ReqDelBlackListT();
        public void SendReqDelBlackList(List<ulong> _IdLst)
        {
            if(null != _IdLst && _IdLst.Count > 0)
            {
                m_sendReqDelBlackList.ids = _IdLst;
                //var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                //fbb.Finish(m_sendReqDelBlackList.ToMsg(fbb).Value);
                MsgDispatcher.instance.SendFBPackage(m_sendReqDelBlackList);

                //x2m.ReqDelBlackList msg = new x2m.ReqDelBlackList();
                //for (int i = 0; i < _IdLst.Count; i++)
                //{
                //    msg.ids.Add(_IdLst[i]);
                //}
                //MsgDispatcher.instance.SendPackage(msg);
            }
        }
        /// <summary>
        /// 发送 请求删除最近联系人
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_contactType"></param>
        public void SendReqDelContact(ulong _id,swm.ContactType _contactType)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqDelContact.StartReqDelContact(fbb);
            swm.ReqDelContact.AddType(fbb, _contactType);
            swm.ReqDelContact.AddUserid(fbb,_id);
            fbb.Finish(swm.ReqDelContact.EndReqDelContact(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqDelContact.HashID, fbb);
            //x2m.ReqDelContact msg = new x2m.ReqDelContact();
            //msg.userid = _id;
            //msg.type = _contactType;
            //MsgDispatcher.instance.SendPackage(msg);
        }
        /// <summary>
        /// 发送 请求添加联系人
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_contactType"></param>
        public void SendReqAddContact(ulong _id,swm.ContactType _contactType)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqAddContact.StartReqAddContact(fbb);
            swm.ReqAddContact.AddType(fbb, _contactType);
            swm.ReqAddContact.AddUserid(fbb,_id);
            fbb.Finish(swm.ReqAddContact.EndReqAddContact(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAddContact.HashID, fbb);


            //x2m.ReqAddContact msg = new x2m.ReqAddContact();
            //msg.userid = _id;
            //msg.type = _contactType;
            //MsgDispatcher.instance.SendPackage(msg);
        }
        //

        //NPC好友的相关


        /// <summary>
        /// 通过id 获得一个好友数据
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public NpcFriendData GetNpcFriendDataById(ulong _id)
        {
            NpcFriendData _data = null;
            for (int i = 0; i < m_NpcFriendList.Count; i++)
            {
                _data = m_NpcFriendList[i];
                if (_data.ID == _id)
                {
                    return _data;
                }
            }
            return null;
        }
        /// <summary>
        /// 添加NPC好友进列表
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="_bIsSend"></param>
        /// <returns></returns>
        private NpcFriendData AddNpcFriend(swm.FriendData _data, bool _bIsSend = false)
        {
            NpcFriendData _NpcFriendData = GetNpcFriendDataById(_data.base_data.Value.entity_id);
            if (null == _NpcFriendData)
            {
                //没有 增加
                _NpcFriendData = new NpcFriendData();
                _NpcFriendData.RefreshData(_data);
                m_NpcFriendList.Add(_NpcFriendData);
                if (_bIsSend)
                {
                   // SortFriendList();
                    onAddNpcFriendEvent.Invoke(_NpcFriendData);
                }

            }
            else
            {
                //已有 刷新
                _NpcFriendData.RefreshData(_data);
                if (_bIsSend)
                {
                    onUpdataNpcFriendEvent.Invoke(_NpcFriendData);
                }
            }
            return _NpcFriendData;
        }
        /// <summary>
        /// 通过id删除一个好友
        /// </summary>
        /// <param name="_id"></param>
        private void RemoveNpcFriendById(ulong _id)
        {
            NpcFriendData _FriendData = GetNpcFriendDataById(_id);
            if (null != _FriendData)
            {
                RecentlyData _reData = GetRecentlyDataById(_id);
                if (null == _reData)
                {
                    ChatModel.Instance.RemoveChannelAllChatData(swm.ChatPosType.PRIVATE, _id);//删除客户端本地的聊天记录
                }
                onRemoveNpcFriendEvent.Invoke(_FriendData);
                _FriendData.Destory();
                m_NpcFriendList.Remove(_FriendData);
            }
        }

        /// <summary>
        /// 接收 添加Npc好友
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspAddNpcFriend(swm.RspAddFriend _msg)
        {
            AddNpcFriend(_msg.data.Value, true);
        }
        /// <summary>
        /// 接收 删除Npc好友
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspDelNpcFriend(swm.RspDelFriend _msg)
        {

            RemoveNpcFriendById(_msg.friend_id);
        }
        public int ProcessSrotNpcFriendList(NpcFriendData _a, NpcFriendData _b)
        {
            if (_a.NetData.state < _b.NetData.state)
            {
                return -1;
            }
            else if (_a.NetData.state > _b.NetData.state)
            {
                return 1;
            }

            if (_a.ID < _b.ID)
            {
                return -1;
            }
            else if (_a.ID == _b.ID)
            {
                return 0;
            }
            return 1;
        }

    }
}
