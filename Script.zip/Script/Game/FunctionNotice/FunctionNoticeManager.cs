﻿using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    //功能预告
	public class FunctionNoticeManager: ClientSingleton<FunctionNoticeManager>
	{
        public GameEvent<int> onUnLockFunctionEvent = new GameEvent<int>();   //当前功能预告解锁事件 开始提示
        public GameEvent onShowLockFunctionEvent = new GameEvent();   //当前更新显示要解锁的功能


        private int mNowShowFunctionTipId = -1;         //当前显示的解锁配置ID
        public int NowShowFunctionTipId
        {
            get
            {
                return mNowShowFunctionTipId;
            }
        }
        private bool mHasNextTipId = false;         //是否有下一个显示解锁配置ID
        public bool HasNextTipId
        {
            get
            {
                return mHasNextTipId;
            }
        }

        private List<int> ComingNextTableIds = new List<int>(10);

        public List<int> GetAllTableIds()
        {
            if (ComingNextTableIds.Count <= 0 && ComingNextManager.Instance.m_DataList.ComingNextLength > 0)
            {
                for (int i = 0; i < ComingNextManager.Instance.m_DataList.ComingNextLength; ++i)
                {
                    var data = ComingNextManager.Instance.m_DataList.ComingNext(i);
                    ComingNextTableIds.Add(data.Value.id);

                }
            }
            return ComingNextTableIds;
        }


        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
		public void Init()
		{
            //ComingNextTableIds.Clear();
            mHasNextTipId = false;
            mNowShowFunctionTipId = -1;
            //UnityEngine.GameObject obj=null;
           // obj.transform.localPosition =  UnityEngine.Vector3.one
        }



		/// <summary>
		/// 加载配置数据
		/// </summary>
        [XLua.BlackList]
		public void Load()
		{

		}
       
		public void InitData()
        {
            //GetAllEaIds();
            mNowShowFunctionTipId = FindNowTipId();

        }


        /// <summary>
        /// （大退/小退）清理缓存
        /// </summary>
        public void Clear()
		{
            //ComingNextTableIds.Clear();
            mHasNextTipId = true;
            mNowShowFunctionTipId = -1;
           // if (null != GameScene.Instance.MainChar)
           // {
           //     GameScene.Instance.MainChar.OnLevelChange -= OnPlayLvlChange;
           // }
        }

        //当玩家等级改变时 检查功能开放预告
        public void OnPlayLvlChange()
        {
            // 
            if(mHasNextTipId == true)
            {
                if (mNowShowFunctionTipId > 0)
                {
                    ComingNextBase? data = ComingNextManager.GetData(mNowShowFunctionTipId);
                    if (data.HasValue && GameScene.Instance.MainChar.Level >= data.Value.unlockLevel) //当前的可以开放提示了
                    {
                        //提示当前 
                        onUnLockFunctionEvent.Invoke(mNowShowFunctionTipId);
                        //查找下一个提示
                        mNowShowFunctionTipId = FindNowTipId();
                        //if(mHasNextTipId==false)
                        //{
                        //更新显示
                        onShowLockFunctionEvent.Invoke();
                        //}
                    }
                    else //没到开放
                    {
                        //更新显示
                        onShowLockFunctionEvent.Invoke();
                    }
                }
                else
                {
                   //认为错了

                }
            }
            else
            {
                //认为没有要提示的了
                onShowLockFunctionEvent.Invoke();
            }

        }


        //找到大于玩家最近的一个配置id  如果找不到 返回-1
        public int FindNowTipId()
        {
            for (int i = 0; i < ComingNextManager.Instance.m_DataList.ComingNextLength; ++i)
            {
                var data = ComingNextManager.Instance.m_DataList.ComingNext(i);
                if(data.Value.unlockLevel> GameScene.Instance.MainChar.Level)
                {
                    mHasNextTipId = true;
                    return data.Value.id;
                }
            }
            mHasNextTipId = false;
            return -1;
        }
	}
}
