using System;
using System.Collections.Generic;
using System.Text;
using LitJson;
using Bokura;
using UnityEngine;

#if !RELEASE
namespace Bokura
{
    public partial class GMCommandManager : ClientSingleton<GMCommandManager>
    { 
        public GMCommandManager()
        {
            RegisterProcess("ConnectQAServer", ConnectQAServer);

            RegisterProcess("showvox", OpenVoxelDebugger); 
            RegisterProcess("openairange", OpenNpcAiRange); 
            RegisterProcess("openvoxnavmesh", OpenVoxNavmesh);
            RegisterProcess("crash", Crash);
            RegisterProcess("ExportRenderInfo", ExportRenderInfo);
            RegisterProcess("ScreenCapture", ScreenCapture);
            RegisterProcess("showskilldebug", ShowSkillDebug);
            RegisterProcess("shownavdest", ShowNavDest);
            RegisterProcess("navtest", NavTest);
            RegisterProcess("debuginfo", DebugInfo);
            RegisterProcess("clearcacheobj", ClearCacheObj);
        }
        protected void RegisterProcess(string cmd,Action<string[]> act)
        {
            if (!Gm_Process.ContainsKey(cmd))
                Gm_Process.Add(cmd, act);
        }
        Vector3 startpos = Vector3.zero;

        bool follow = false;
        TimeHelper followtimer = new TimeHelper(1,true);
        [XLua.BlackList]
        public void Update()
        {
            //TODO: test code
            if (UnityEngine.EventSystems.EventSystem.current != null)
            {
                if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
                {
                    if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.GetComponent<UnityEngine.UI.InputField>())
                        return;
                    if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.GetComponent<UnityEngine.UI.Giant.EnhancedInputField>())
                        return;
                }
            }

            if(follow && followtimer.IsValid() )
            {
                var target = TargetSelector.Instance.Selected;
                if(target)
                {
                    GameScene.Instance.MainChar.MoveTo(target.Position);
                    //var curpos = GameScene.Instance.MainChar.Position;
                    //GameScene.Instance.MainChar.Syncer.PushMoveData(0, curpos, target.Position, GameScene.Instance.MainChar.DirAngle, GameScene.Instance.GetServerTime());
                }
               

            }
            if (IUnityInput.Instance.GetKey(KeyCode.F) )
            {
                follow = !follow;
                //if (follow && TargetSelector.Instance.Selected != null)
                //    CameraController.Instance.SetTarget(TargetSelector.Instance.Selected.Avatar.unityObject.transform);
                //else
                //    CameraController.Instance.SetTarget(GameScene.Instance.MainChar.Avatar.unityObject.transform);
            }
            if (IUnityInput.Instance.GetKey(KeyCode.P) && IUnityInput.Instance.GetKey(KeyCode.RightShift))
            {
                NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_SystemNotify, "关闭景深");
                //ICameraHelper.Instance.SwitchCameraDepth(false);
            }
            if (IUnityInput.Instance.GetKey(KeyCode.O) && IUnityInput.Instance.GetKey(KeyCode.RightShift))
            {
                NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_SystemNotify, "打开景深");
                //ICameraHelper.Instance.SwitchCameraDepth(true);
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.H) && (IUnityInput.Instance.GetKey(KeyCode.RightShift) || IUnityInput.Instance.GetKey(KeyCode.LeftShift)))
            {
                UIManager.Instance.ToggleSwitchUI();
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.D) && (IUnityInput.Instance.GetKey(KeyCode.RightShift) || IUnityInput.Instance.GetKey(KeyCode.LeftShift)))
            {
                if(CameraController.Instance.GetTargetTransform() != TargetSelector.Instance.Selected.Avatar.unityObject.transform)
                    CameraController.Instance.SetTarget(TargetSelector.Instance.Selected.Avatar.unityObject.transform);
                else
                    CameraController.Instance.SetTarget(GameScene.Instance.MainChar.Avatar.unityObject.transform);
            }
            if (IUnityInput.Instance.GetKeyDown(KeyCode.I) && (IUnityInput.Instance.GetKey(KeyCode.RightShift) || IUnityInput.Instance.GetKey(KeyCode.LeftShift))
                && (IUnityInput.Instance.GetKey(KeyCode.RightControl) || IUnityInput.Instance.GetKey(KeyCode.LeftControl)))
            {
                UIManager.Instance.SaveAllGameObjectImageReference();
            }

            if (IUnityInput.Instance.GetKeyUp(KeyCode.T))
            {
                LuaFunctor.DoString("require(\"ui/ui_mission/ui_missionmain\") ui_missionmain.show()");

            }
            if (IUnityInput.Instance.GetKey(KeyCode.T))
            {
                //SkillManager.Instance.autoAttack.TaskStart(TargetSelector.Instance.Selected, null);

            }

            if (IUnityInput.Instance.GetKeyDown(KeyCode.L))
            {
                GameApplication.ShowTestCube = !GameApplication.ShowTestCube;
                NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_SystemNotify, GameApplication.ShowTestCube ? "显示辅助坐标" : "隐藏辅助坐标");
                if (!GameApplication.ShowTestCube)
                {
                    GameScene.ClearTestCube();
                }
            }

            if(IUnityInput.Instance.GetKey(KeyCode.RightAlt) && IUnityInput.Instance.GetKeyDown(KeyCode.P))
            {
                Ray ray = Bokura.ICameraHelper.Instance.MainCamera.ScreenPointToRay(IUnityInput.Instance.mousePosition);
                //Ray ray = HandleUtility.GUIPointToWorldRay(UnityEngine.Event.current.mousePosition);
                RaycastHit hit;
                if(Utilities.RayCast(ray,out hit,(int)UserLayerMask.AllBlock))
                {
                    if (startpos != Vector3.zero)
                    {
                        var endpos = hit.point + LayeredSceneLoader.WorldOffset;
                        var luastr = string.Format("gmCommand.sendGmCommand('showpath {0} {1} {2} {3} {4} {5}')", startpos.x, startpos.y, startpos.z, endpos.x, endpos.y, endpos.z);
                        LuaFastCall.DoString(luastr); 
                        startpos = Vector3.zero;
                        GameScene.GetTempCube(123234, endpos, Color.red);
                    }
                    else
                    {
                        startpos = hit.point + LayeredSceneLoader.WorldOffset;
                        GameScene.GetTempCube(123233, startpos, Color.gray);
                    }
                    
                }
            }

            if ((IUnityInput.Instance.GetKey(KeyCode.RightShift) || IUnityInput.Instance.GetKey(KeyCode.LeftShift)))
            {
                if (IUnityInput.Instance.GetKeyDown(KeyCode.F))
                {
                    ScreenRecordMode.Enable = !ScreenRecordMode.Enable;
                }
            }

            if ((IUnityInput.Instance.GetKey(KeyCode.RightShift) || IUnityInput.Instance.GetKey(KeyCode.LeftShift)))
            {
                if (IUnityInput.Instance.GetKeyDown(KeyCode.Z))
                {
                    GameScene.Instance.OpenServerIdBox = !GameScene.Instance.OpenServerIdBox;
                }
            }

            UpdateNavDest();
        }
        #region 客户端的Gm指令
        protected static void ConnectQAServer(params string[] argvs)
        {
            if (argvs.Length < 2) return;
            AutoTaskServer.Instance.StartConnection(argvs[1], int.Parse(argvs[2]));
        }
        //showvox 
        //参数r: 表示打开和关闭自动更新,如: showvox r
        //参数f: 表示强制更新以下, 如: showvox f
        protected static void OpenVoxelDebugger(params string[] argvs)
        {
            if (!Bokura.Voxelization.VoxelDebugger.IsOpen)
            {
                var map_name = GameScene.Instance.IsInWorldMap ? "World_JZ_01" : UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
                if(map_name.EndsWith("_baked"))
                    map_name = map_name.Replace("_baked", "");
                var filePath = Bokura.Voxelization.VoxelDebugger.DownloadVoxelFile(map_name);
                if(!string.IsNullOrEmpty(filePath))
                    Bokura.Voxelization.VoxelDebugger.Open(filePath);
            }
            else
            {
                if(argvs.Length > 1)
                {
                    if(argvs[1].ToLower() == "a")
                        Bokura.Voxelization.VoxelDebugger.singleton.autoUpdate = !Bokura.Voxelization.VoxelDebugger.singleton.autoUpdate;
                    else if(argvs[1].ToLower() == "f")
                        Bokura.Voxelization.VoxelDebugger.singleton.ForceBuild();
                    else
                        Bokura.LogHelper.LogWarning($"Unknown Voxel Debugger {argvs[1]} Argument!!");
                }
                else
                    Bokura.Voxelization.VoxelDebugger.Close();
            }
                
        }
        protected static void OpenNpcAiRange(params string[] argvs)
        {
            GameScene.Instance.ShowAiTest =!GameScene.Instance.ShowAiTest;
        }
        protected static void OpenVoxNavmesh(params string[] argvs)
        {
            var nav = UnityEngine.GameObject.Find("__VoxNavMesh__");
            if(nav == null)
            {
                nav =  new UnityEngine.GameObject("__VoxNavMesh__");
                var nanmesh = nav.AddComponent<VoxNavMesh>();
                string map_name = GameScene.Instance.IsInWorldMap ? "World_JZ_01" : UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
                using (VString s = VString.Concat("Assets\\StreamingAssets\\vox\\", map_name, ".gvworld.nav"))
                {
                    int iTileIndex = -1;
                    int iPolyOffset = -1;
                    int iTriangleOffset = -1;
                    if (argvs.Length > 1)
                        int.TryParse(argvs[1], out iTileIndex);
                    if (argvs.Length > 2)
                        int.TryParse(argvs[2], out iPolyOffset);
                    if (argvs.Length > 3)
                        int.TryParse(argvs[3], out iTriangleOffset);
                    nanmesh.AysncOpenFile(s.ToString(), iTileIndex, iPolyOffset, iTriangleOffset);
                    //nanmesh.OpenFile(s.ToString());
                }
            }
            else
            {
                var navmesh = nav.GetComponent<VoxNavMesh>();
                if(navmesh) navmesh.Visual = !navmesh.Visual;
            }
        }
        protected static void ScreenCapture(params string[] argvs)
        {
            if (argvs.Length < 3) return;
            float size;
            if (float.TryParse(argvs[1], out size))
            {
                Bokura.Common.ScreenCapture.Do_Capture = true;
                var folderPath = PathUtility.SimplifiedPath(System.IO.Path.Combine(Bokura.IResourceLoader.persistentDataPath, "ScreenShots/"));
                Bokura.Common.ScreenCapture.CaptureToImageFile(size, argvs[2], folderPath);
                folderPath = PathUtility.SimplifiedPath(System.IO.Path.Combine(Bokura.IResourceLoader.persistentDataPath, "ScreenShots/FullSize/"));
                Bokura.Common.ScreenCapture.CaptureToImageFile(1, argvs[2], folderPath);
            }
        }
        protected static void Crash(params string[] argvs)
        {
            XLua.LuaDLL.Lua.lua_pop(IntPtr.Zero, 10);
        }

        protected static void ExportRenderInfo(params string[] argvs)
        {
            Bokura.Common.ExportRenderInfo.ExportToFile();
        }
    
        void ShowSkillDebug(params string[] argvs)
        {
            bool enable = true;
            int b;
            if(argvs.Length>1 && int.TryParse(argvs[1],out b))
            {
                enable = b != 0;
            }
            SkillDebug.Enable = enable;

        }
        protected PrintDebudInfo DebugInfoManager = null;
        protected bool isShowDebugInfo = false;
        void DebugInfo(params string[] argvs)
        {
            isShowDebugInfo = !isShowDebugInfo;
            if(!isShowDebugInfo)
            {
                GameObject.DestroyImmediate(DebugInfoManager.gameObject);
            }
            else
            {
                var go = new GameObject("__PrintDebudInfo__");
                DebugInfoManager = go.AddComponent<PrintDebudInfo>();
            }
        }
        [XLua.BlackList]
        public void ProcPrintDebugInfo(swm.PrintDebugInfo msg)
        {
            if (!isShowDebugInfo) return;
            DebugInfoManager = GameObject.FindObjectOfType<PrintDebudInfo>();
            if (DebugInfoManager == null)
            {
                var go = new GameObject("__PrintDebudInfo__");
                DebugInfoManager = go.AddComponent<PrintDebudInfo>();
            }
            if (DebugInfoManager != null)
            {
                DebugInfoManager.AddString((PrintDebudInfo.InfoCategory)msg.slot, msg.info);
            }
        }
        void NavTest(params string[] argvs)
        {
            if (argvs.Length != 4)
                return;
            float x, y, z;
            float.TryParse(argvs[1], out x);
            float.TryParse(argvs[2], out y);
            float.TryParse(argvs[3], out z);

            GameScene.Instance.MainChar.MoveByWorldPoint(new Vector3(x, y, z));
        }

        bool m_showNavDestPos = false;
        GameObject m_goNavDest;
        void ShowNavDest(params string[] argvs)
        {
            bool enable = true;
            int b;
            if (argvs.Length > 1 && int.TryParse(argvs[1], out b))
            {
                enable = b != 0;
            }

            m_showNavDestPos = enable;
        }

        void ClearCacheObj(params string[] argvs) {
            Bokura.ResourcesFolderResource.Instance.DoDestroy();
            Bokura.VFXManagement.VFXManager.singleton.ClearCacheObj();
        }

        void UpdateNavDest()
        {
            if(m_showNavDestPos )
            {
                var agent = GameScene.Instance.MainChar?.PathAgent;
                if (agent == null)
                    return;
                if (!m_goNavDest)
                {
                    m_goNavDest = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    m_goNavDest.name = "NavDest";
                    var collider = m_goNavDest.GetComponent<Collider>();
                    if(collider)
                    {
                        UnityEngine.Object.Destroy(collider);
                    }
                }
                m_goNavDest.transform.position = agent.DestPos() - LayeredSceneLoader.WorldOffset;
#if UNITY_EDITOR
                IPathAgent.Instance.RenderPath(true);
#endif
            }
            else
            {
                if (m_goNavDest)
                    GameObject.Destroy(m_goNavDest);
            }
        }

        #endregion
    }

}
#endif