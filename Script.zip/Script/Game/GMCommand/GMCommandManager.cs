using System;
using System.Collections.Generic;
using System.Text;
using LitJson;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public partial class GMCommandManager : ClientSingleton<GMCommandManager>
    {

        private GMCommandBase[] m_allGMCommands;
        private Dictionary<string, Dictionary<string, string>> m_referenceMapping = new Dictionary<string, Dictionary<string, string>>(Bokura.ConstValue.kCap16);
        private LinkedList<string> m_recents = new LinkedList<string>();
        private string m_separator = "|||";
        private string[] m_separatorArray = new string[] { "|||" };
        private StringBuilder m_sb = new StringBuilder();
        private List<FavoriteJsonUtility.JsonInfoLine> m_favoriteList = null;

        public class HierarchyInfo
        {
            public int hashCode;
            public GameObject obj;
            public string name;
            public int level;
            public int childCount;
            public bool isExpand;
            public bool isShow;

            public int parentIndex;
        }

        public List<HierarchyInfo> HierarchyInfoList = new List<HierarchyInfo>(0);

        public void FillHierarchy()
        {
            HierarchyInfoList.Clear();

            List<GameObject> rootGameObjects = new List<GameObject>(0);
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects(rootGameObjects);

            for(int i=0; i< rootGameObjects.Count; ++i)
            {
                foreachTrans(rootGameObjects[i], 0, 0);
            }
        }

        private void foreachTrans(GameObject go, int level, int parentIndex)
        {
            HierarchyInfo info = new HierarchyInfo();
            info.hashCode = go.GetHashCode();
            info.obj = go;
            info.name = go.name;
            info.level = level;
            info.childCount = go.transform.childCount;
            info.isExpand = false;
            info.isShow = (level == 0);

            info.parentIndex = parentIndex;

            HierarchyInfoList.Add(info);

            foreach (Transform child in go.transform)
            {
                foreachTrans(child.gameObject, level + 1, go.GetHashCode());
            }
        }

        public void ExpandGameObjectChilds(int index)
        {
            HierarchyInfo info = HierarchyInfoList[index];
            info.isExpand = true;

            for (int i=0; i< HierarchyInfoList.Count; ++i)
            {
                var childInfo = HierarchyInfoList[i];

                if (childInfo.parentIndex == info.hashCode)
                {
                    HierarchyInfoList[i].isShow = true;
                }
            }
        }

        public void ShrinkGameObjectChilds(int index)
        {
            HierarchyInfo info = HierarchyInfoList[index];
            info.isExpand = false;

            for (int i = 0; i < HierarchyInfoList.Count; ++i)
            {
                var childInfo = HierarchyInfoList[i];

                if (childInfo.parentIndex == info.hashCode)
                {
                    HierarchyInfoList[i].isShow = false;

                    ShrinkGameObjectChilds(i);
                }
            }
        }

        public bool isNotNull(HierarchyInfo info)
        {
            if (info.obj != null)
            {
                return true;
            }
            else
            {
                info.isShow = false;
            }

            return false;
        }

        public void OperateByKeyword(string keyword, bool isActive)
        {
            string key = keyword.ToLower();
            for (int i = 0; i < HierarchyInfoList.Count; ++i)
            {
                var childInfo = HierarchyInfoList[i];

                if (childInfo.obj != null)
                {
                    if (childInfo.obj.name.ToLower().Contains(key))
                    {
                        MonoBehaviour[] monoBehaviours = childInfo.obj.GetComponents<MonoBehaviour>();

                        if (monoBehaviours != null)
                        {
                            for (int k = 0; k < monoBehaviours.Length; ++k)
                            {
                                monoBehaviours[k].enabled = isActive;
                            }
                        }

                        childInfo.obj.SetActive(isActive);
                    }
                }
            }
        }


        public GameObject CreateReporter()
        {
            GameObject go = GameObject.Find("Reporter");

            if (go == null)
            {
                UnityEngine.Object res = Resources.Load("proc_reporter");

                if (res != null)
                {
                    go = GameObject.Instantiate(res) as GameObject;
                    go.name = "Reporter";
                }
            }

            return go;
        }

        public void ShowReporter()
        {
#if !RELEASE
            GameObject go = CreateReporter();
            if (go != null)
            {
                Reporter rp = go.GetComponent<Reporter>();
                if (rp != null)
                {
                    rp.ShowMe();
                }
            }
#endif
        }


        /// <summary>
        /// 所有的GM指令配置
        /// </summary>
        public GMCommandBase[] GMCommands
        {
            get { return m_allGMCommands; }
        }
        public bool ShowChinese
        {
            get { return UnityEngine.PlayerPrefs.GetInt("GM_SHOWCHINESE", 1) == 1; }
            set { UnityEngine.PlayerPrefs.SetInt("GM_SHOWCHINESE", value ? 1 : 0); }
        }

        public void SendCMD(string cmd)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var cmdoffset = fbb.CreateString(cmd);
            swm.GmCommand.StartGmCommand(fbb);
            swm.GmCommand.AddCommand(fbb, cmdoffset);
            fbb.Finish(swm.GmCommand.EndGmCommand(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.GmCommand.HashID, fbb);
        }

        protected Dictionary<string, Action<string[]>> Gm_Process = new Dictionary<string, Action<string[]>>(32);
        public bool ExecuteGameCommand(string cmd, string argvs)
        {
            if (Gm_Process.ContainsKey(cmd))
            {
                Gm_Process[cmd](argvs.Split(' '));
                return true;
            }
            return false;
        }

#region GM UI界面
        [XLua.BlackList]
        static public void Load(string strJson)
        {
            try
            {
                Instance.m_allGMCommands = JsonMapper.ToObject<GMCommandBase[]>(strJson);
                Instance.LoadSpecial();
            }
            catch (Exception e)
            {
                Bokura.LogHelper.LogError("Exception caught when loading gmcommands: " + e.ToString());
            }
            Instance.ShowGUI();
        }
        
        public Dictionary<string, string> GetReference(string reference)
        {
            if (string.IsNullOrWhiteSpace(reference))
            {
                return null;
            }
            if (m_referenceMapping.ContainsKey(reference))
            {
                return m_referenceMapping[reference];
            }
            else
            {
                var dict = LoadReference(reference);
                if(dict != null)
                {
                    m_referenceMapping.Add(reference, dict);
                }
                return dict;
            }
        }

        public Dictionary<string, string> GetReferenceByFilter(Dictionary<string, string> dict, string filter)
        {
            var ret = new Dictionary<string, string>(Bokura.ConstValue.kCap32);
            if (dict == null)
            {
                return ret;
            }
            foreach(var kv in dict)
            {
                if(kv.Key.Contains(filter) || kv.Value.Contains(filter))
                {
                    ret.Add(kv.Key, kv.Value);
                }
            }
            return ret;
        }

        public void ShowGUI()
        {
#if REMOTE_DEBUG
            GameScene.Instance.onGameStateChange.AddListener((prev, next) =>
            {
                if(prev == GameState.Login)
                {
                    LuaFunctor.DoString("ShowDebugWnd()");
                }
                if(next == GameState.Login && prev != GameState.Start)
                {
                    LuaFunctor.DoString("CloseDebugWnd()");
                }
            });
#endif
        }

        private Dictionary<string, string> LoadReference(string reference)
        {
            var referenceList = LoadReferenceFromFBTable(reference);
            if(referenceList == null)
                referenceList = LoadReferenceFromJson(reference);

            return referenceList;
        }

        private Dictionary<string, string> LoadReferenceFromFBTable(string reference)
        {
            var dict = new Dictionary<string, string>(Bokura.ConstValue.kCap32);

            string value = Bokura.Utilities.BuildString("Game.", reference, "Manager");

            var managerType = Type.GetType(value);
            if(managerType == null)
            {
                return null;
            }
            
            var prop = managerType.GetProperty("Instance");
            if(prop==null)
                prop = managerType.BaseType.GetProperty("Instance");
            if (prop == null)
                return null;


            var instance = prop.GetValue(null);
            var list = managerType.GetField("m_DataList")?.GetValue(instance);
            if(null == list)
            {
                list = managerType.GetProperty("m_DataList")?.GetValue(instance);
            }

            value = Bokura.Utilities.BuildString(reference, "Length");

            var length = list?.GetType()?.GetProperty(value)?.GetValue(list) ?? -1;
            for (int i = 0; i < (int)length; i++)
            {
                var table = list?.GetType()?.GetMethod(reference)?.Invoke(list, new object[] { i });
                var id = table?.GetType()?.GetProperty("id")?.GetValue(table);
                var name = table?.GetType()?.GetProperty("name")?.GetValue(table);
                if (id != null && name != null)
                {
                    if (!dict.ContainsKey(id.ToString()))
                        dict.Add(id.ToString(), name.ToString());
                    else
                        LogHelper.LogWarningFormat("table {0},id {1} is exist.", reference,id);
                }
            }
            return dict;
        }

        private Dictionary<string, string> LoadReferenceFromJson(string reference)
        {
            // load file

            string value = Bokura.Utilities.BuildString(reference, ".json");

            string strData = TableManager.LoadFileTable(value, "/Datas/");
            if (string.IsNullOrEmpty(strData))
            {
                return null;
            }
            // parse json
            JsonData jsonData;
            try
            {
                jsonData = JsonMapper.ToObject(strData);
            }
            catch(Exception e)
            {
                Bokura.LogHelper.LogError("Error occurred when parsing json table " + reference + ": " + e.ToString());
                return null;
            }
            if(jsonData == null)
            {
                return null;
            }
            // get data
            var dict = new Dictionary<string, string>(Bokura.ConstValue.kCap32);
            if (jsonData.IsArray)
            {
                foreach(JsonData item in jsonData)
                {
                    if (item.IsObject)
                    {
                        var keys = item.Keys;
                        string id = null;
                        string name = null;
                        if (keys.Contains("id"))
                        {
                            id = item["id"].ToString();
                        }
                        if (keys.Contains("name"))
                        {
                            name = item["name"].ToString();
                        }
                        if(id != null && name != null)
                        {
                            dict.Add(id, name);
                        }
                    }
                }
            }

            return dict;
        }

        public Bokura.GameEvent onFavoriteChanged = new Bokura.GameEvent();

        public void AddRecent(string recent, int maxnum)
        {
            if (string.IsNullOrWhiteSpace(recent))
                return;
            if (maxnum <= 0)
                return;
            m_recents.Remove(recent);
            while (m_recents.Count + 1 > maxnum)
            {
                m_recents.RemoveLast();
            }
            m_recents.AddFirst(recent);
            SaveRecents();
        }
        
        public void ForeachRecent(Action<string> callback)
        {
            foreach(var r in m_recents)
            {
                callback?.Invoke(r);
            }
        }
        
        //public void AddFavorite(string favorite)
        //{
        //    if (string.IsNullOrWhiteSpace(favorite))
        //        return;
        //    if (m_favorites.Contains(favorite))
        //        return;
        //    m_favorites.AddLast(favorite);
        //    onFavoriteChanged.Invoke();
        //    SaveFavorites();
        //}

        //public void CancelFavorite(string favorite)
        //{
        //    if (string.IsNullOrWhiteSpace(favorite))
        //        return;
        //    m_favorites.Remove(favorite);
        //    onFavoriteChanged.Invoke();
        //    SaveFavorites();
        //}

        //public bool IsFavorite(GMCommandBase gm)
        //{
        //    if(gm == null || string.IsNullOrEmpty(gm._text))
        //    {
        //        return false;
        //    }
        //    return m_favorites.Contains(gm._text);
        //}
        
        //public void ForeachFavorite(Action<string> callback)
        //{
        //    foreach (var f in m_favorites)
        //    {
        //        callback?.Invoke(f);
        //    }
        //}

        /// <summary>
        /// 获取收藏夹名列表;
        /// </summary>
        /// <param name="callback"></param>
        public void GetFavoriteNames(Action<string> callback)
        {
            if (m_favoriteList == null)
            {
                FavoriteJsonUtility.LoadFromPlayerPrefs(out m_favoriteList);
            }

            if (m_favoriteList != null)
            {
                for (int i=0, count = m_favoriteList.Count; i<count; ++i)
                {
                    callback?.Invoke(m_favoriteList[i].name);
                }
            }
        }

        /// <summary>
        /// 通过收藏夹编号获取对应名�?;
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public string GetFavoriteNameByIndex(int index)
        {
            if (m_favoriteList != null)
            {
                if (m_favoriteList.Count > index)
                {
                    return m_favoriteList[index].name;
                }
            }

            return "";
        }

        /// <summary>
        /// 创建一个收藏夹;
        /// </summary>
        /// <param name="inputName"></param>
        public void CreateFavoriteName(string inputName)
        {
            if (!string.IsNullOrWhiteSpace(inputName))
            {
                if (m_favoriteList != null)
                {
                    FavoriteJsonUtility.JsonInfoLine one = new FavoriteJsonUtility.JsonInfoLine();
                    one.name = inputName;

                    m_favoriteList.Add(one);

                    FavoriteJsonUtility.SaveToPlayerPrefs(m_favoriteList);
                }
            }
        }

        /// <summary>
        /// 删除一个收藏夹;
        /// </summary>
        /// <param name="index"></param>
        public void RemoveFavoriteByIndex(int index)
        {
            if (m_favoriteList != null)
            {
                if (m_favoriteList.Count > index)
                {
                    if (index != 0)
                    {
                        m_favoriteList.RemoveAt(index);
                    }
                }

                FavoriteJsonUtility.SaveToPlayerPrefs(m_favoriteList);
            }
        }

        /// <summary>
        /// 当前收藏夹的所以指�?;
        /// </summary>
        /// <param name="index"></param>
        /// <param name="callback"></param>
        public void GetAllFavoriteByIndex(int index, Action<string> callback)
        {
            if (m_favoriteList != null)
            {
                if (m_favoriteList.Count > index)
                {
                    FavoriteJsonUtility.JsonInfoLine line = m_favoriteList[index];

                    if (line.favoriteList != null)
                    {
                        for (int i = 0, count = line.favoriteList.Count; i < count; ++i)
                        {
                            callback?.Invoke(line.favoriteList[i]);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 往一个收藏夹添加一个指�?;
        /// </summary>
        /// <param name="index"></param>
        /// <param name="favorite"></param>
        public void AddOneFavorite(int index, string favorite)
        {
            if (!string.IsNullOrWhiteSpace(favorite))
            {
                if (m_favoriteList != null)
                {
                    if (m_favoriteList.Count > index)
                    {
                        FavoriteJsonUtility.JsonInfoLine line = m_favoriteList[index];

                        if (line.favoriteList != null)
                        {
                            if (!line.favoriteList.Contains(favorite))
                            {
                                line.favoriteList.Add(favorite);

                                onFavoriteChanged.Invoke();

                                FavoriteJsonUtility.SaveToPlayerPrefs(m_favoriteList);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 从收藏夹删除一个指�?;
        /// </summary>
        /// <param name="index"></param>
        /// <param name="favorite"></param>
        public void RemoveOneFavorite(int index, string favorite)
        {
            if (!string.IsNullOrWhiteSpace(favorite))
            {
                if (m_favoriteList != null)
                {
                    if (m_favoriteList.Count > index)
                    {
                        FavoriteJsonUtility.JsonInfoLine line = m_favoriteList[index];

                        if (line.favoriteList != null)
                        {
                            if (line.favoriteList.Contains(favorite))
                            {
                                line.favoriteList.Remove(favorite);

                                onFavoriteChanged.Invoke();

                                FavoriteJsonUtility.SaveToPlayerPrefs(m_favoriteList);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 指定收藏夹是否有指令;
        /// </summary>
        /// <param name="index"></param>
        /// <param name="favorite"></param>
        /// <returns></returns>
        public bool IsHaveFavorite(int index, string favorite)
        {
            if (!string.IsNullOrWhiteSpace(favorite))
            {
                if (m_favoriteList != null)
                {
                    if (m_favoriteList.Count > index)
                    {
                        FavoriteJsonUtility.JsonInfoLine line = m_favoriteList[index];

                        if (line.favoriteList != null)
                        {
                            return line.favoriteList.Contains(favorite);
                        }
                    }
                }
            }

            return false;
        }


        private void SaveRecents()
        {
            UnityEngine.PlayerPrefs.SetString("GM_RECENT", ToString(m_recents));
        }
        //private void SaveFavorites()
        //{
        //    UnityEngine.PlayerPrefs.SetString("GM_FAVORITE", ToString(m_favorites));
        //}
        
        private void LoadSpecial()
        {
            m_recents = new LinkedList<string>(UnityEngine.PlayerPrefs.GetString("GM_RECENT", string.Empty).Split(m_separatorArray, StringSplitOptions.RemoveEmptyEntries));
            //m_favorites = new LinkedList<string>(UnityEngine.PlayerPrefs.GetString("GM_FAVORITE", string.Empty).Split(m_separatorArray, StringSplitOptions.RemoveEmptyEntries));
        }

        private string ToString(LinkedList<string> list)
        {
            m_sb.Clear();
            foreach(var item in list)
            {
                m_sb.Append(item);
                m_sb.Append(m_separator);
            }
            return m_sb.ToString();
        }


        public string GetPoolInfos()
        {
#if RELEASE
            return " ";
#else
            return VStringPool.Instance.GetSizeInfo()
                + UnityEngine.UI.VertexInfoPool.GetSizeInfo()
                + CharMemoryPool.Instance.GetSizeInfo()
                + UnityEngine.UI.ObjectPoolMgr.GetSizeInfo();
#endif
        }

#endregion

    }

    [Serializable]
    public class GMCommandBase
    {
        public string _text;
        public string _name;
        public string _index;
        public string _desc;
        public GMCommandParamBase[] _params;
        public string[] _commands;
    }

    [Serializable]
    public class GMCommandParamBase
    {
        public string _desc;
        [XLua.BlackList]
        public JsonData _default;
        public string _defaultStr
        {
            get { return _default?.ToString(); }
        }
        public bool _optional = false;
        public string _reference;
        public bool _repeat = false;
    }

    public static class FavoriteJsonUtility
    {
        private const string NewGmFavoritesKey = "GM_NEW_FAVORITES";//新的收藏逻辑本地key;

        public static void SaveToPlayerPrefs(List<JsonInfoLine> infos)
        {
            string value = ToJson(infos);

            UnityEngine.PlayerPrefs.SetString(NewGmFavoritesKey, value);
        }

        public static void LoadFromPlayerPrefs(out List<JsonInfoLine> outList)
        {
            //UnityEngine.PlayerPrefs.DeleteKey(NewGmFavoritesKey);
            string value = UnityEngine.PlayerPrefs.GetString(NewGmFavoritesKey, string.Empty);

            Parse(value, out outList);

            if (outList == null)
            {
                outList = new List<JsonInfoLine>(Bokura.ConstValue.kCap8);

                JsonInfoLine one = new JsonInfoLine();
                one.name = "默认收藏";

                outList.Add(one);

                SaveToPlayerPrefs(outList);
            }
        }

        public static void Parse(string json, out List<JsonInfoLine> outList)
        {

            outList = null;

            if (string.IsNullOrEmpty(json))
            {
                return;
            }

            try
            {
                JsonData jd = JsonMapper.ToObject(json);

                if (jd.IsArray)
                {
                    outList = new List<JsonInfoLine>(jd.Count);

                    JsonData temp = null;
                    for (int i = 0, count = jd.Count; i < count; ++i)
                    {
                        temp = jd[i];

                        JsonInfoLine line = new JsonInfoLine();
                        line.name = temp["name"].ToString();

                        JsonData fvJd = temp["favorites"];
                        if (fvJd != null)
                        {

                            if (fvJd.IsArray)
                            {
                                line.favoriteList = new List<string>(fvJd.Count);

                                for (int k = 0, len = fvJd.Count; k < len; ++k)
                                {
                                    line.favoriteList.Add(fvJd[k].ToString());
                                }
                            }

                        }

                        outList.Add(line);
                    }
                }
            }
            catch(Exception e)
            {
                LogHelper.Log(json + "  " + e);
            }
        }

        public static string ToJson(List<JsonInfoLine> infos)
        {
            if (infos != null)
            {
                JsonData jd = new JsonData();

                JsonInfoLine line = null;

                for (int i=0, len = infos.Count; i< len; ++i)
                {
                    line = infos[i];
                    JsonData temp = new JsonData();
                    temp["name"] = line.name;

                    JsonData tempFavorites = new JsonData();

                    if (line.favoriteList == null)
                    {
                        line.favoriteList = new List<string>(Bokura.ConstValue.kCap8);
                        line.favoriteList.Add("_Empty_");
                    }

                    for (int k = 0, count = line.favoriteList.Count; k < count; ++k)
                    {
                        tempFavorites.Add(line.favoriteList[k]);
                    }

                    temp["favorites"] = tempFavorites;

                    jd.Add(temp);
                }

                return jd.ToJson();
            }

            return "";
        }

        public sealed class JsonInfoLine
        {
            public string name;
            public List<string> favoriteList;
        }

    }
}
