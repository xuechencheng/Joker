﻿using UnityEngine;
using System;
using System.IO;
using Bokura;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Bokura
{
    public class PrintDebudInfo: MonoBehaviour
    {
        public enum InfoCategory{ First,Second,Third }
        protected Dictionary<InfoCategory, string> infos = new Dictionary<InfoCategory,string>();

        public void Start()
        {
            //infos.Add(InfoCategory.First, "aaaaaaaaaaa");
            //infos.Add(InfoCategory.Second, "aaaaadfasdfasdfaeaaaaaa");
            //infos.Add(InfoCategory.Third, "faefeafefaefaee");
        }
        public void AddString(InfoCategory category,string info)
        {
            if(infos.ContainsKey(category))
            {
                infos[category] = info;
            }
            else
            {
                infos.Add(category,info);
            }
            
        }
        private void OnGUI()
        {

            GUI.color = Color.green;
            using(new GUILayout.VerticalScope("Box"))
            {
                foreach(var info in infos)
                {
                    GUILayout.Label(string.Format("{0}: {1}", (int)info.Key, info.Value));
                }
            }
            GUI.matrix = Matrix4x4.identity;
        }
    }

}//ns Bokura.Voxelization

