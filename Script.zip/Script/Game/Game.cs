using Bokura;

namespace X2Game
{
    class Game : IGame
    {
        public override IAvatar GetMainChar()
        {
            if (GameScene.Instance != null)
            {
                if (GameScene.Instance.MainChar != null)
                {
                    return GameScene.Instance.MainChar.Avatar;
                }
            }
            return null;
        }
        public override MainCharacter GetMainCharacter()
        {
            if (GameScene.Instance != null)
            {
                if (GameScene.Instance.MainChar != null)
                {
                    return GameScene.Instance.MainChar;
                }
            }
            return null;
        }

        public override bool IsInGame()
        {
            return (GameScene.Instance != null) ? (GameScene.Instance.currState == GameState.InGame) : false;
        }

        public override bool IsOutGame()
        {
            if (GameScene.Instance != null)
            {
                if (GameScene.Instance.currState == GameState.Start
                    || GameScene.Instance.currState == GameState.Login
                    || GameScene.Instance.currState == GameState.RoleCreate
                    || GameScene.Instance.currState == GameState.RoleSelect)
                {
                    return true;
                }
            }

            return false;
        }

        public override bool MainCharIsInAir()
        {
            return GameScene.Instance != null ?  GameScene.Instance.MainChar.IsInAir : false;
        }

        public override bool IsInLoading()
        {
            return GameScene.Instance != null ? GameScene.Instance.IsInLoading : false;
        }

        public override void RefreshMechanismOperateStr()
        {
            if (GameScene.Instance != null)
            {
                if (GameScene.Instance.MainChar != null)
                {
                    GameScene.Instance.MainChar.RefreshMechanismOperateStr();
                }
            }
        }

        public override bool IsMainCharCurrInCloud()
        {
            return GameScene.Instance != null ?  GameScene.Instance.MainChar.isCurrInCloud() : false;
        }

        public override UnityEngine.Vector3 MainCharLocalPosition()
        {
            return GameScene.Instance != null ?  GameScene.Instance.MainChar.LocalPosition : UnityEngine.Vector3.zero;
        }

        public override UnityEngine.Canvas GetUICanvas()
        {
            return  X2Game.UIManager.Instance?.GetCanvas();
        }

        public override uint GetCurrentIntomapId()
        {
            if (GameScene.Instance != null)
            {
                return GameScene.Instance.CurrentMapId;
            }

            return 0;
        }

        public override int GetBuildVersion()
        {
            if (GameApplication.Instance != null)
            {
                return GameApplication.Instance.BuildVersion;
            }

            return 0;
        }

        public override void MiddleNotifyModelDisplayString(string content)
        {
            if (NotifyModel.Instance != null)
            {
                NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_Middle, content);
            }
        }

#if WE_TEST && DEBUG && UNITY_ANDROID && !UNITY_EDITOR && !SCENE_EDITOR && !OUTERNET
        public override string GotoPosition(string posStr)
        {
            try
            {
                x2m.GmCommand cmd = new x2m.GmCommand();
                cmd.command = string.Format("goto {0}", posStr);
                X2Game.MsgDispatcher.instance.SendPackage(cmd);
                return "";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        private string GotoMap(string mapId)
        {
            try
            {
                x2m.GmCommand cmd = new x2m.GmCommand();
                cmd.command = string.Format("gomap {0}", mapId);
                X2Game.MsgDispatcher.instance.SendPackage(cmd);
                return "";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
#endif
    }
}
