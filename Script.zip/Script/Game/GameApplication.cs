﻿#if !UNITY_EDITOR
#define LUA_NO_PRINT
#endif

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine.EventSystems;
using System;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using Bokura;

namespace Bokura
{
	public class GameApplication
	{
        [XLua.BlackListAttribute()]
        public static bool ShowTestCube = false;
		GameScene m_gameScene;
		public void InitTable()
		{
			TableManager.Instance.LoadTable(); 
		}

		public delegate void VOIDDelegateBool(bool b);
        public delegate void VOIDDelegate();
        public VOIDDelegateBool onPause;
        public VOIDDelegate onPostUpdate;

		public IResourceLoader m_ResourceLoader;

		public Application.LogCallback logcallback;
		XLua.LuaEnv m_LuaScriptMgr;

		public TimerManager m_TimerManager = new TimerManager();

		NetworkConnection m_Network = new NetworkConnection();
        //是否开启单人浏览场景模式
        public bool IsSingleView = false;

        private GameEvent<int> m_OnBuildVersionChanged = new GameEvent<int>();
        public GameEvent<int> onBuildVersionChanged
        {
            get { return m_OnBuildVersionChanged; }
        }

        private int m_buildVersion = 0;
        public int BuildVersion
        {
            get { return m_buildVersion; }
            set
            {
                m_buildVersion = value;

                onBuildVersionChanged?.Invoke(m_buildVersion);
            }
        }

        public bool IsRelease
        {
            get
            {
#if RELEASE
                return true;
#else
                return false;
#endif
            }
        }

		static GameApplication m_Instance;
		static public GameApplication Instance
		{
			get
			{
				if (m_Instance == null)
					m_Instance = new GameApplication();
				return m_Instance;
			}

		}

		static public bool IsEditorMode
		{
			get
			{
#if UNITY_EDITOR
				return true;
#else
				return false;
#endif
			}

		}

		//是否是内网包。后面通过宏来处理
		static public bool IsLANPackage
		{
			get
			{
				return true;
			}
		}

		public XLua.LuaEnv LuaInstance
		{
			get
			{
				return m_LuaScriptMgr;
			}
		}

		public void DebugOutput(string s)
		{
            LogHelper.Log(s);
        }

		public void Init(main m)
		{
			ClientSingletonManager.Instance.RegisterSingleton();
            m_gameScene = GameScene.Instance;

			m_ResourceLoader = IResourceLoader.Instance;

			IUnityInput.Instance.multiTouchEnabled = true;

			m_LuaScriptMgr = new XLua.LuaEnv();
			m_LuaScriptMgr.AddLoader(LuaScriptLoader);
			UIManager.Instance.Init();

			MainThreadTask.getSingleton().Init();
			if (string.IsNullOrEmpty(m.m_sMainLuaPath))
				LuaFunctor.LoadLuaFile("updater.lua");
			else
				LuaFunctor.LoadLuaFile(m.m_sMainLuaPath);


#if !RELEASE
            GMCommandManager.Instance.CreateReporter();
#endif
        }



        public void InitResource()
		{
			Bokura.AssetBundleResource.Instance.DoStart();
            IEngineMain.Instance.InitRenderPileline();
			InitTable();
			UserDataManager.Instance.LoadConfig();
            //AudioCtrl.Init();
            GameScene.Instance.Init();

            Bokura.IEngineMain.Instance.GameInited = true;

            ILevelSystemManager.Instance.SetLevelSystemInt((int)Bokura.SystemLevelInfo.GetLevel());
        }



        [XLua.BlackList]
		public void Shutdown()
		{
            if (null != m_LuaScriptMgr)
            {
                try
                {
                    LuaFunctor.DoString("if OnGameExit then OnGameExit() end");
                }
                catch(Exception e)
                {
                    LogHelper.LogError(e.ToString());
                }
                


                m_LuaScriptMgr.Dispose();
                m_LuaScriptMgr = null;
            }
			m_TimerManager.DeInit();
			m_Network.Disconnect();
			MainThreadTask.getSingleton().Shutdown();
#if (UNITY_IPHONE || UNITY_IOS || UNITY_ANDROID) && !UNITY_EDITOR
            BuglyAgent.UnregisterLogCallback(LogHandler);
            //Application.logMessageReceived -= LogHandler;
#else
            Application.logMessageReceived -= LogHandler;
#endif
            m_Instance = null;
            UserDataManager.Instance.SaveConfig();
        }

		public TimerManager GetTimerManager()
		{
			return m_TimerManager;
		}

		public NetworkConnection GetNetwork()
		{
			return m_Network;
		}

		static public string GetPlatformName()
		{
#if UNITY_IOS
            return "ios";
#elif UNITY_ANDROID
            return "android";
#else

			return "win";

#endif
		}
        public GameApplication()
		{
#if (UNITY_IPHONE || UNITY_IOS || UNITY_ANDROID) && !UNITY_EDITOR
            BuglyAgent.RegisterLogCallback(LogHandler);
            //Application.logMessageReceived += LogHandler;
#else
            Application.logMessageReceived += LogHandler;
#endif
        }
		void LogHandler(string msg, string stack, LogType lt)
		{
			if (lt == LogType.Error || lt == LogType.Exception || lt == LogType.Warning)
			{
				if (logcallback != null)
				{
					logcallback(msg, stack, lt);
				}
			}
		}

        private byte[] ReadFileBytes(string name)
        {
            string sPath = name;
            try
            {
                var bt = IFile.LoadResourceFiles(sPath);
                if(bt != null)
                    bt = UTF8Process(bt);

                return bt;
            }
            catch(Exception e)
            {
                LogHelper.LogError(e.ToString());
            }

            return null;
        }


#if LUA_NO_PRINT
        static byte[] printsig = new byte[]{ (byte)'p', (byte)'r', (byte)'i', (byte)'n', (byte)'t', (byte)'(' };
#endif
        byte[] LuaScriptLoader(ref string name)
		{
			string lowerName = name.ToLower();
			if (!Utilities.StringEndsWith(lowerName, ".lua"))
			{
				name = name.Replace('.', '/');
				name += ".lua";
			}

			var bytes = ReadFileBytes(Utilities.BuildString("LuaScript/", name));
#if LUA_NO_PRINT
            if (bytes!=null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    if (bytes[i] == '\n')
                    {
                        i++;
                        while (i < bytes.Length && (bytes[i] == '\t' || bytes[i] == ' ')) i++;
                        if (i < bytes.Length - 6)
                        {
                            bool printfound = true;
                            int start = i;
                            for (int j = 0; j < printsig.Length; j++, i++)
                            {
                                if (bytes[i] != printsig[j])
                                {
                                    printfound = false;
                                    break;
                                }
                            }
                            if (printfound)
                            {
                                bytes[start] = (byte)'-';
                                bytes[start + 1] = (byte)'-';
                            }
                            //i += 6;
                        }
                    }
                }
            }
#endif
            //string s = System.Text.UTF8Encoding.UTF8.GetString(bytes);

            return bytes;
		}

// 		IEnumerable<WWW> ILoadFromWWW(string sPath)
// 		{
// 			WWW www = new WWW(sPath);
// 			yield return www;
// 
// 		}
// 		public byte[] LoadFromWWW(string sPath)
// 		{
//             using(WWW www = new WWW(sPath))
//             {
//                 while (!www.isDone)
//                 {
// 
//                 }
//                 if (www.error != null && www.error.Length > 0)
//                 {
//                     return null;
//                 }
//                 if (www != null)
//                     return www.bytes;
//                 else
//                     return null;
//             }
//         }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
		public static byte[] UTF8Process(byte[] bt)
		{		
			return Utilities.UTF8Process(bt);
		}

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static byte[] ReadBytes(string name)
        {
            return Instance.ReadFileBytes(name);
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static float GetBatteryLevel()
        {
            return IFile.GetBatteryLevel();
        } 

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
		public static bool WriteBytes(string fname, byte[] buf)
		{			
            return IFile.WriteBytes(fname, buf);
		}



        public void Start()
        {
            Utilities.ProfilerBegin("UIControlMgr.DoStart");
            {
                UIControlMgr.DoStart();
            }
            Utilities.ProfilerEnd();
        }



        public void Update()
		{
			Utilities.ProfilerBegin("MainThreadTask.DoTask");
			{
				MainThreadTask.getSingleton().do_task();
			}
			Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("MsgDispatcher.Dispatch");
            {
                MsgDispatcher.instance.Dispatch();
            }
            Utilities.ProfilerEnd();

            if (m_LuaScriptMgr!=null)
			{
				Utilities.ProfilerBegin("LuaScriptTick");
				{
					m_LuaScriptMgr.Tick();
				}
				Utilities.ProfilerEnd();
			}

			Utilities.ProfilerBegin("TimeManagerUpdate");
			{
				m_TimerManager.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("GameScene.Update");
			{
				m_gameScene.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("UIControlMgr.Update");
			{
				UIControlMgr.DoUpdate();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("SceneSpawnManager.Update");
			{
				SceneSpawnManager.Instance.DoUpdate();
			}
			Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("MonoUpdateManager.DoUpdate");
            {
                IGameMonoUpdateManager.Instance.MonoUpdate();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("NpcShowManager.DoUpdate");
            {
                NpcShowManager.Instance.MonoUpdate();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("ObjectPoolManager.Update");
            {
                ObjectPoolManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("UIManager.Update");
            {
                UIManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

#if !RELEASE
            Utilities.ProfilerBegin("NpcShowManager.DoUpdate");
            {
                GMCommandManager.Instance.Update();
            }
            Utilities.ProfilerEnd();
#endif
        }

		public void FixedUpdate()
		{
            Utilities.ProfilerBegin("GameScene.FixedUpdate");
            {
                if(m_gameScene != null)
                    m_gameScene.FixedUpdate();
            }
            Utilities.ProfilerEnd();
        }

        public void LateUpdate()
        {
            if (m_gameScene != null)
                m_gameScene.LateUpdate();

            Utilities.ProfilerBegin("UIControlMgr.LateUpdate");
            {
                UIControlMgr.DoLateUpdate();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("AvatarShowManager.LateUpdate");
            {
                AvatarShowManager.Instance.DoLateUpdate();
            }
            Utilities.ProfilerEnd();

            onPostUpdate?.Invoke();
        }


        static string keybuf = "!@#ER)UI*&iaoS(oxkp+=-129kajf";
		public static byte[] XORBUF(byte[] buf, int nStart)
		{

			do
			{
				int nRemain = buf.Length - nStart;
				int writesize = Math.Min(nRemain, keybuf.Length);
				if (writesize == 0)
					break;
				for (int i = 0; i < writesize; i++)
				{
					buf[i + nStart] ^= (byte)keybuf[i];
				}
				nStart += writesize;

			} while (true);

			return buf;
		}
		public static void EncryptSproto(string filename)
		{
			byte[] data = File.ReadAllBytes(filename);
			if (data[0] == 255 && data[1] == 'E' && data[2] == 'C' && data[3] == '!')
				return;

			List<byte> buf = new List<byte>(Bokura.ConstValue.kCap16);
			buf.Add(255); buf.Add((byte)'E'); buf.Add((byte)'C'); buf.Add((byte)'!');
			bool bSkiping = false;
			for (int i = 0; i < data.Length; i++)
			{

				if (data[i] == '#')
				{
					bSkiping = true;
				}

				if (!bSkiping)
					buf.Add(data[i]);

				if (data[i] == '\r' && (i + 1 < data.Length && data[i + 1] == '\n'))
				{
					if (bSkiping)
						buf.Add(data[i]);
					i++;
					if (bSkiping)
						buf.Add(data[i]);
					bSkiping = false;

				}
				else if (data[i] == '\n' || data[i] == '\r')
				{
					if (bSkiping)
						buf.Add(data[i]);
					bSkiping = false;
	
				}

			}

			var xbuf = XORBUF(buf.ToArray(), 4);

			File.WriteAllBytes(filename, xbuf);
		}

		public static byte[] ReadSproto(string filename)
		{
            byte[] dataToFill = GameApplication.ReadBytes(filename);
            if(dataToFill == null)
                return null;
			if (dataToFill[0] == 255 && dataToFill[1] == 'E' && dataToFill[2] == 'C' && dataToFill[3] == '!' && dataToFill.Length>4)
			{
				var buf = new byte[dataToFill.Length - 4];
				Array.Copy(dataToFill, 4, buf, 0, buf.Length);
				XORBUF(buf, 0);
				return buf;
			}
			else
			{
				return dataToFill;
			}
			
		}


        public static void StartKSync()
        {
#if UNITY_STANDALONE_WIN
            GameObject ksyncgo = new GameObject("ksync");
            GameObject.DontDestroyOnLoad(ksyncgo);
            ksyncgo.AddComponent<KSync.KSyncViewer>();
#endif
        }
	}
}
