﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public class AreaTriggerDraw : MonoBehaviour
    {
        BoxCollider box = null;
        private void Start()
        {
            if (box == null)
            {
                box = gameObject.AddComponent<BoxCollider>();
                box.isTrigger = true;
            }
            if (debugMaterial == null)
            {
                var shader = Bokura.ResourceHelper.LoadShaderSync("shaders/", "Alpha-Diffuse") as Shader;
                debugMaterial = new Material(shader);
                debugMaterial.SetColor("_Color", new Color(0, 1, 1, 0.6f));
            }
            if (m_cubeIndices == null)
            {
                m_cubeIndices = new int[36] {
                    0,1,2,3,2,1,
                    2,3,4,5,4,3,
                    4,5,6,7,6,5,
                    2,4,6,0,2,6,
                    1,7,3,7,5,3,
                    0,6,1,1,6,7
                };
            }
        }
        
        public List<swm.MapZoneChunkT> chunks = new List<swm.MapZoneChunkT>(64);

        //private Mesh debugMeshInfo = null;
        private Material debugMaterial = null;

        //Cube
        List<Vector3> m_cubeVertices = new List<Vector3>(8);
        int[] m_cubeIndices;
        
        void Update()
        {

            for (int i = 0; i < chunks.Count; i++)
            {
                if (chunks[i].chunktype == 1)
                {
                    //Cube
                    if (m_cubeVertices == null)
                    {
                        m_cubeVertices = new List<Vector3>(8);
                    }
                    //if (debugMeshInfo == null)
                    //{
                    //    debugMeshInfo = new Mesh();
                    //}
                    var debugMeshInfo = new Mesh();
                    m_cubeVertices.Clear();
                    Vector3 p000 = chunks[i].p000.Vec3();

                    m_cubeVertices.Add(Vector3.zero);
                    m_cubeVertices.Add(chunks[i].p010.Vec3() - p000);
                    m_cubeVertices.Add(chunks[i].p100.Vec3() - p000);
                    m_cubeVertices.Add(chunks[i].p110.Vec3() - p000);
                    m_cubeVertices.Add(chunks[i].p101.Vec3() - p000);
                    m_cubeVertices.Add(chunks[i].p111.Vec3() - p000);
                    m_cubeVertices.Add(chunks[i].p001.Vec3() - p000);
                    m_cubeVertices.Add(chunks[i].p011.Vec3() - p000);

                    debugMeshInfo.SetVertices(m_cubeVertices);
                    debugMeshInfo.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                    debugMeshInfo.SetIndices(m_cubeIndices, MeshTopology.Triangles, 0);

                    Graphics.DrawMesh(debugMeshInfo, p000,
                        Quaternion.identity, debugMaterial, 0);
                }
            }
            
            //圆
        }
    }
}
