﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bokura
{
    /// <summary>
    /// 协议辅助
    /// </summary>
    ///

    ///准备信息
    public class TeamPrepareInfo
    {
        public ulong userid = 0;
        public swm.CopyPrepare prepare_info = swm.CopyPrepare.Wait;
        public uint group_id = 0;
    }
    /// <summary>
    /// 准备结果
    /// </summary>
    public class TeamPrepareResult
    {
        public ulong time = 0;
        public uint copy_baseid = 0;
        public swm.TeamType teamtype = swm.TeamType.Five;
        public List<TeamPrepareInfo> TeamPrepareInfoList = new List<TeamPrepareInfo>();
        private bool m_bIsFirstInit = false;

        public bool IsFirstInit
        {
            set
            {
                m_bIsFirstInit = value;
            }
            get
            {

                return m_bIsFirstInit;
            }
        }

        public void Clear()
        {
            m_bIsFirstInit = false;
            time = 0;
            copy_baseid = 0;
            teamtype = swm.TeamType.Five;
            TeamPrepareInfoList.Clear();
        }

        public void RefresData(swm.RspPrepareResult _msg)
        {
            time = _msg.time;
            copy_baseid = _msg.copy_baseid;
            teamtype = _msg.teamtype;
            if(_msg.prepare_infosLength > 0)
            {
                for(int i =0;i< _msg.prepare_infosLength;i++)
                {
                    swm.PrepareResult? _preData = _msg.prepare_infos(i);
                    AddPrepareInfo(_preData.Value);
                }

                if (!m_bIsFirstInit && TeamPrepareInfoList.Count > 0)
                {
                    TeamPrepareInfoList.Sort(ProcessSrotList);
                }
            }
        }

        public TeamPrepareInfo GetPrepareInfoByIndex(int _index)
        {
            TeamPrepareInfo _InfoData = null;
            if (_index < TeamPrepareInfoList.Count)
            {
                _InfoData = TeamPrepareInfoList[_index];
            }
            return _InfoData;
        }

        public int GetPrepareInfoListLength()
        {
            return TeamPrepareInfoList.Count;
        }
        private void AddPrepareInfo(swm.PrepareResult _data)
        {
            TeamPrepareInfo _InfoData = null;
            for(int i =0;i< TeamPrepareInfoList.Count;i++)
            {
                if(TeamPrepareInfoList[i].userid == _data.uid)
                {
                    _InfoData = TeamPrepareInfoList[i];
                    _InfoData.prepare_info = _data.prepare_info;
                    break;
                }
            }
            if(null == _InfoData)
            {
                _InfoData = new TeamPrepareInfo();
                _InfoData.userid = _data.uid;
                _InfoData.prepare_info = _data.prepare_info;
                _InfoData.group_id = _data.group_id;
                TeamPrepareInfoList.Add(_InfoData);
            }
        }

        int ProcessSrotList(TeamPrepareInfo _a, TeamPrepareInfo _b)
        {
            int master_a = (TeamModel.Instance.TeamData.LeaderId == _a.userid ? 1 : 0);
            int master_b = (TeamModel.Instance.TeamData.LeaderId == _b.userid ? 1 : 0);
            if (master_a < master_b)
            {
                return 1;
            }
            else if (master_a > master_b)
            {
                return -1;
            }

            if (_a.userid < _b.userid)
            {
                return -1;
            }
            else if (_a.userid == _b.userid)
            {
                return 0;
            }
            return 1;
        }

    }
    /// <summary>
    /// 条件信息
    /// </summary>
    public class TeamCopyCondition
    {
        public ulong userid = 0;
        public swm.VerifyResult error_info = swm.VerifyResult.None;
    }
    /// <summary>
    /// 副本条件检查结果
    /// </summary>
    public class TeamCopyConditionResult
    {
        public uint copy_baseid = 0;
        public swm.TeamType teamtype = swm.TeamType.Five;
        public List<TeamCopyCondition> TeamCopyConditionList = new List<TeamCopyCondition>();

        public void setData(swm.RspCopyCondition _msg)
        {
            copy_baseid = _msg.copy_baseid;
            teamtype = _msg.teamtype;
            TeamCopyConditionList.Clear();
            if(_msg.error_infosLength>0)
            {
                for(int i =0;i < _msg.error_infosLength;i++)
                {
                    swm.CopyCondition? _copyData = _msg.error_infos(i);
                    TeamCopyCondition _data = new TeamCopyCondition();
                    _data.userid = _copyData.Value.uid;
                    _data.error_info = _copyData.Value.error_info;
                    TeamCopyConditionList.Add(_data);
                }
            }
        }

    }

    public class GameCopyBossReward
    {
        public uint m_boss_id = 0;
        public uint m_reward_num = 0;
        public uint m_reward_num_max = 0;
    }

    /// <summary>
    /// 协议辅助
    /// 副本信息数据类
    /// </summary>
    public class GameCopyInfo
    {
        private bool m_bInfoIsDirty = false;//数据是否需要更新

        private uint m_copy_baseid;//副本配置唯一id
        private ulong m_create_time;// 副本创建时间
        private ulong m_expire_time;//副本过期时间
        private uint m_reward_num;//副本当前奖励次数
        private uint m_day_compleate_num;//副本今天完成次数
        private uint m_copy_step;//副本当前进度
        private uint m_copy_step_max;//副本最大进度

        private List<GameCopyBossReward> m_BossRewardList = new List<GameCopyBossReward>();

        private CopyInfoTableBase? m_CopyInfoTableConfig = null;

        public bool InfoIsDirty
        {
            get
            {
                return m_bInfoIsDirty;
            }
            set
            {
                m_bInfoIsDirty = value;
            }
        }

        public uint CopyBaseId
        {
            get
            {
                return m_copy_baseid;
            }
        }

        public ulong CreateTime
        {
            get
            {
                return m_create_time;
            }
        }

        public ulong ExpireTime
        {
            get
            {
                return m_expire_time;
            }
        }

        public ulong RewardNum
        {
            get
            {
                return m_reward_num;
            }
        }

        public uint day_compleate_num
        {
            get
            {
                return m_day_compleate_num;
            }
        }

        public ulong CopyStep
        {
            get
            {
                return m_copy_step;
            }
        }

        public uint copy_step_max
        {
            get
            {
                return m_copy_step_max;
            }
        }

        public CopyInfoTableBase?  CopyInfoTableConfig
        {
            get
            {
                return m_CopyInfoTableConfig;
            }
        }


        public GameCopyInfo()
        {
            Clear();
        }

        public void Clear()
        {
           m_copy_baseid = 0;
           m_create_time = 0;
           m_expire_time = 0;
           m_reward_num = 0;
           m_copy_step = 0;
           m_copy_step_max = 0;
           m_day_compleate_num = 0;
           m_BossRewardList.Clear();
        }

        public GameCopyBossReward GetBossRewardById( uint _id)
        {
            GameCopyBossReward _data = null;
            for(int i =0;i<m_BossRewardList.Count;i++)
            {
                _data = m_BossRewardList[i];
                if(_data.m_boss_id == _id)
                {
                    return _data;
                }
            }
            return null;
        }

        public void RefeshData(swm.CopyInfo? _data)
        {
            InfoIsDirty = false;
           if (m_copy_baseid != _data.Value.copy_baseid)
           {
                m_CopyInfoTableConfig = CopyInfoTableManager.GetData((int)_data.Value.copy_baseid);
           }
           m_copy_baseid = _data.Value.copy_baseid;
           m_create_time = _data.Value.create_time;
           m_expire_time = _data.Value.expire_time;
           m_reward_num = _data.Value.reward_num;
           m_day_compleate_num = _data.Value.day_compleate_num;
           m_copy_step = _data.Value.copy_step;
           m_copy_step_max = _data.Value.copy_step_max;

            for (int i = 0; i < _data.Value.boss_reward_numLength; i++)
            {
                AddOrRefreshBossReward( _data.Value.boss_reward_num(i) );

            }
        }

        private void AddOrRefreshBossReward(swm.BossReward? _re)
        {
            GameCopyBossReward _data = null;
            uint _bossId = _re.Value.boss_id;
            uint _rewardNum = _re.Value.reward_num;
            uint _reward_num_max = _re.Value.reward_num_max;
            for (int i = 0; i < m_BossRewardList.Count; i++)
            {
                _data = m_BossRewardList[i];
                if (_data.m_boss_id == _bossId)
                {
                    _data.m_reward_num = _rewardNum;
                    _data.m_reward_num_max = _reward_num_max;
                    return;
                }
            }
            _data = new GameCopyBossReward();
            _data.m_boss_id = _bossId;
            _data.m_reward_num = _rewardNum;
            _data.m_reward_num_max = _reward_num_max;
            m_BossRewardList.Add(_data);
        }
    }


    public class EnterCopyZoneData
    {
        private uint m_TaskId = 0;
        private string m_TaskName = string.Empty;

        public uint TaskId
        {
            get
            {
                return m_TaskId;
            }
            set
            {
                m_TaskId = value;
            }
        }

        public string TaskName
        {
            get
            {
                return m_TaskName;
            }
            set
            {
                m_TaskName = value;
            }
        }

        public void Clear()
        {
            m_TaskId = 0;
        }

        public void decode(swm.EnterCopyZone? _data)
        {
            m_TaskId = _data.Value.taskid;
            m_TaskName = _data.Value.taskname;
        }
    }

    ///配置协助类
    ///
    public class GameCopyTypeConfigData
    {
        private int m_GroupId = 0;
        private List<CopyInfoTableBase?> m_DifficultList = new List<CopyInfoTableBase?>();

        public int GroupId
        {
            get
            {
                return m_GroupId;
            }
            set
            {
                m_GroupId = value;
            }
        }

        public List<CopyInfoTableBase?> DifficultList
        {
            get
            {
                return m_DifficultList;
            }
        }

        public int DifficultListLength
        {
            get
            {
                return m_DifficultList.Count;
            }
        }

        public CopyInfoTableBase? GetCopyInfoTableBaseByIndex(int _index)
        {
            CopyInfoTableBase? _base = null;
            if(_index < DifficultListLength)
            {
                _base = m_DifficultList[_index];
            }
            return _base;
        }

        public CopyInfoTableBase? GetCopyInfoTableBaseByDifficult(int _difficult)
        {
            CopyInfoTableBase? _base = null;
            for(int i =0;i<m_DifficultList.Count;i++)
            {
                CopyInfoTableBase? _data = m_DifficultList[i];
                if(_difficult == _data.Value.difficulty)
                {
                    _base = _data;
                    break;
                }
            }
            return _base;
        }

        public void AddCopyInfoTableBase(CopyInfoTableBase? _data)
        {
            DifficultList.Add(_data);
        }

    }

}
