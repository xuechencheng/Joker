﻿using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    class GameCopyModel : ClientSingleton<GameCopyModel>
    {
        /// <summary>
        /// 配置 协助
        /// </summary>
        private Dictionary<int, List<GameCopyTypeConfigData>> m_CopyTypeDic = new Dictionary<int, List<GameCopyTypeConfigData>>();
        ///
        private GameCopyInfo m_CurrentGameCopyInfo = null;//当前正在进行的副本信息 如果null 就说明没有在副本
        private Dictionary<uint, GameCopyInfo> m_GameCopyInfoPool = new Dictionary<uint, GameCopyInfo>();

        private TeamCopyConditionResult m_CopyConditionResult = new TeamCopyConditionResult();
        private TeamPrepareResult m_PrepareResult = new TeamPrepareResult();


        private List<EnterCopyZoneData> m_EnterCopyZonePool = new List<EnterCopyZoneData>(Bokura.ConstValue.kCap32);
        private List<EnterCopyZoneData> m_EnterCopyTempList = new List<EnterCopyZoneData>(Bokura.ConstValue.kCap32);

        public TeamCopyConditionResult CopyConditionResult
        {
            get
            {
                return m_CopyConditionResult;
            }
        }

        public TeamPrepareResult PrepareResult
        {
            get
            {
                return m_PrepareResult;
            }
        }
        public GameCopyInfo CurrentGameCopyInfo
        {
            get
            {
                return m_CurrentGameCopyInfo;
            }
        }
        public bool CheckIsShowCD(float _time = -1)
        {
            bool b = false;
            if(null != m_CurrentGameCopyInfo && m_CurrentGameCopyInfo.CopyInfoTableConfig.Value.map_id == GameScene.Instance.CurrentIntomapInfo.Value.map_id)
            {
                if(_time <0)
                {
                    _time = (int)((m_CurrentGameCopyInfo.ExpireTime - GameScene.Instance.GetServerTime()) / 1000);
                }
                if(_time < 60)//GetCopyConstantsShutDownCD() )
                {
                    b = true;
                }
            }
            return b;
        }

        public class RefreshCopyInfoEvent : GameEvent<GameCopyInfo>
        {

        }
        public RefreshCopyInfoEvent onCurrentCopyInfoChangeEvent = new RefreshCopyInfoEvent();
        public RefreshCopyInfoEvent onEnterCopyEvent = new RefreshCopyInfoEvent();
        public GameEvent<uint> onExitCopyEvent = new GameEvent<uint>();
        public RefreshCopyInfoEvent onRefreshCopyInfoEvent = new RefreshCopyInfoEvent();

        public GameEvent<TeamCopyConditionResult> onTeamCopyConditionResultEvent = new GameEvent<TeamCopyConditionResult>();
        public GameEvent<bool> onEnterTeamCopyResultEvent = new GameEvent<bool>();
        public GameEvent<TeamPrepareResult> onTeamPrepareResult = new GameEvent<TeamPrepareResult>();

        public GameEvent onNtfBossShow = new GameEvent();
        public GameEvent<List<ItemTableBase?>, List<uint>> onNtfShowCopyReward = new GameEvent<List<ItemTableBase?>, List<uint>>();

        public GameEvent<bool, List<EnterCopyZoneData>> onProcNotifyEnterCopyZoneListEvent = new GameEvent<bool, List<EnterCopyZoneData>>();

        public GameEvent<string> onGameCopyMessage = new GameEvent<string>();

        public GameEvent onTeamStartCopyActivity = new GameEvent();
        public GameEvent onRspOpenGameCopyActivity = new GameEvent();

        public GameEvent onNotifyRoundInfo = new GameEvent();
        public GameEvent<bool> onNotifyTeamChallengeResult = new GameEvent<bool>();
        public GameEvent onNotifyGameCopyExpResult = new GameEvent();
        public GameEvent onNotifyRoundNpcInfo = new GameEvent();
        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspEnterCopy>(ProcRspEnterCopy);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspExitCopy>(ProcRspExitCopy);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRefreshCopyInfo>(ProcRspRefreshCopyInfo);
            //组队本的消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCopyCondition>(ProcRspCopyCondition);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspPrepareResult>(ProcRspPrepareResult);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspEnterTeamCopyResult>(ProcRspEnterTeamCopyResult);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NtfBossShow>(ProcNtfBossShow);
            //区域相位本
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyEnterCopyZoneList>(ProcNotifyEnterCopyZoneList);
            
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NtfShowCopyReward>(ProcNtfShowCopyReward);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.CopyMessage>(ProcCopyMessage);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyTeamCopyActivity>(ProcTeamCopyActivity);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspOpenGameCopyActivity>(ProcRspOpenGameCopyActivity);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyRoundInfo>(ProcNotifyRoundInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyTeamChallengeResult>(ProcNotifyTeamChallengeResult); 
			
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyGameCopyExpResult>(ProcNotifyGameCopyExpResult);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyRoundNpcInfo>(ProcNotifyRoundNpcInfo); 
        }

        public void Clear()
        {
            m_GameCopyInfoPool.Clear();
            m_CurrentGameCopyInfo = null;
            m_PrepareResult.Clear();
            m_roundInfo = null;
            m_gameCopyExpResultT = null;
        }

        /// <summary>
        /// 获取 gamecopyinfo
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="_bIfNotIsCreate">没有的话是不是创建一个</param>
        /// <returns></returns>
        public GameCopyInfo GetGameCopyInfoByBaseId(uint _baseId,bool _bIfNotIsCreate = true)
        {
            GameCopyInfo _info = null;
            if(!m_GameCopyInfoPool.TryGetValue(_baseId,out _info))
            {
                if(_bIfNotIsCreate)
                {
                    _info = new GameCopyInfo();
                    m_GameCopyInfoPool[_baseId] = _info;
                }
             
            }

            return _info;
        }

        /// <summary>
        /// 当前进行的副本信息有改变
        /// </summary>
        private void InvokeCurrentGameCopyInfoChange()
        {
            onCurrentCopyInfoChangeEvent.Invoke(m_CurrentGameCopyInfo);
        }
        
        /// <summary>
        /// 接收 进入副本
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspEnterCopy(swm.RspEnterCopy _msg)
        {
            m_CurrentGameCopyInfo = GetGameCopyInfoByBaseId(_msg.copy_info.Value.copy_baseid);
            m_CurrentGameCopyInfo.RefeshData(_msg.copy_info);
            InvokeCurrentGameCopyInfoChange();
            onEnterCopyEvent.Invoke(m_CurrentGameCopyInfo);
        }

        /// <summary>
        /// 接收 离开副本
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspExitCopy(swm.RspExitCopy _msg)
        {
            if(null != m_CurrentGameCopyInfo && _msg.copy_baseid == m_CurrentGameCopyInfo.CopyBaseId)
            {
                GameCopyInfo _info = null;
                if (m_GameCopyInfoPool.TryGetValue(_msg.copy_baseid, out _info))
                {
                    _info.InfoIsDirty = true;
                }
                m_CurrentGameCopyInfo = null;
                InvokeCurrentGameCopyInfoChange();
            }
            onExitCopyEvent.Invoke(_msg.copy_baseid);
        }

        /// <summary>
        /// 接收 刷新副本信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspRefreshCopyInfo(swm.RspRefreshCopyInfo _msg)
        {
            GameCopyInfo _info= GetGameCopyInfoByBaseId(_msg.copy_info.Value.copy_baseid);
            _info.RefeshData(_msg.copy_info);
            if(null != m_CurrentGameCopyInfo && _info.CopyBaseId == m_CurrentGameCopyInfo.CopyBaseId)
            {
                InvokeCurrentGameCopyInfoChange();
            }
            onRefreshCopyInfoEvent.Invoke(_info);
        }

        /// <summary>
        /// 接收 副本条件检查结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspCopyCondition(swm.RspCopyCondition _msg)
        {
            m_CopyConditionResult.setData(_msg);
            onTeamCopyConditionResultEvent.Invoke(m_CopyConditionResult);
        }

        /// <summary>
        /// 接收 返回 准备结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspPrepareResult(swm.RspPrepareResult _msg)
        {
            m_PrepareResult.RefresData(_msg);
            onTeamPrepareResult.Invoke(m_PrepareResult);
            m_PrepareResult.IsFirstInit = true;
        }

        /// <summary>
        /// 返回 副本投票结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspEnterTeamCopyResult(swm.RspEnterTeamCopyResult _msg)
        {
            m_PrepareResult.Clear();
            onEnterTeamCopyResultEvent.Invoke(_msg.enter_result);
        }

        public void ProcNtfBossShow(swm.NtfBossShow _msg)
        {
            onNtfBossShow.Invoke();
        }

        /// <summary>
        /// 通知进入区域相位本
        /// </summary>
        private void ProcNotifyEnterCopyZoneList(swm.NotifyEnterCopyZoneList _msg)
        {
            BackEnterCopyZoneDataToList();
            if(_msg.zonelistLength > 0 )
            {
                for (int i = 0; i < _msg.zonelistLength; i++)
                {
                    swm.EnterCopyZone? _data = _msg.zonelist(i);
                    EnterCopyZoneData _copyData = GetEnterCopyZoneFromPool();
                    _copyData.decode(_data);
                    m_EnterCopyTempList.Add(_copyData);
                }
                onProcNotifyEnterCopyZoneListEvent.Invoke(_msg.isshow, m_EnterCopyTempList);
            }
        }

        /// <summary>
        /// 通知副本奖励
        /// </summary>
        List<uint> m_showItemNums;
        List<uint> ShowItemNums
        {
            get
            {
                if (m_showItemNums == null)
                    m_showItemNums = new List<uint>(32);
                return m_showItemNums;
            }
        }
        List<ItemTableBase?> m_showItems;
        List<ItemTableBase?> ShowItems
        {
            get
            {
                if (m_showItems == null)
                    m_showItems = new List<ItemTableBase?>(32);
                return m_showItems;
            }
        }
        private void ProcNtfShowCopyReward(swm.NtfShowCopyReward _msg)
        {
            ShowItems.Clear();
            ShowItemNums.Clear();
            for (int i = 0; i < _msg.copy_rewardLength; i++)
            {
                swm.FinishReward? itemNum = _msg.copy_reward(i);
                if (itemNum != null && itemNum.HasValue)
                {
                    ItemTableBase? tConfig = ItemTableManager.GetData((int)itemNum.Value.item_id);
                    ShowItems.Add(tConfig);
                    ShowItemNums.Add(itemNum.Value.item_num);
                }
            }
            onNtfShowCopyReward.Invoke(ShowItems, ShowItemNums);
        }

        /// <summary>
        /// boss预警提示
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcCopyMessage(swm.CopyMessage _msg)
        {
            onGameCopyMessage.Invoke(_msg.tips_msg);
        }

        /// <summary>
        /// 清空临时列表
        /// </summary>
        private void BackEnterCopyZoneDataToList()
        {
            EnterCopyZoneData _data = null;
            for (int i =0;i< m_EnterCopyTempList.Count;i++)
            {
                _data = m_EnterCopyTempList[i];
                _data.Clear();
                m_EnterCopyZonePool.Add(_data);
            }
            m_EnterCopyTempList.Clear();
        }
        /// <summary>
        /// 从池中取一个值 ，没有就创建一个
        /// </summary>
        /// <returns></returns>
        private EnterCopyZoneData GetEnterCopyZoneFromPool()
        {
            EnterCopyZoneData _data = null;
            if (m_EnterCopyZonePool.Count>0)
            {
                _data = m_EnterCopyZonePool[0];
                m_EnterCopyZonePool.RemoveAt(0);
            }
            else
            {
                _data = new EnterCopyZoneData();
            }
            return _data;
        }

        /// <summary>
        /// 请求进入任务副本 通过任务id
        /// </summary>
        /// <param name="_taskId"></param>
        public void SendReqEnterTaskCopy(uint _taskId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqEnterTaskCopy.StartReqEnterTaskCopy(fbb);
            swm.ReqEnterTaskCopy.AddTaskid(fbb, _taskId);
            var msg = swm.ReqEnterTaskCopy.EndReqEnterTaskCopy(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEnterTaskCopy.HashID, fbb);
        }

        /// <summary>
        /// 请求任务副本弹窗
        /// </summary>
        /// <param name="_taskId"></param>
        public void SendReqCopyWindowByTask(uint _taskId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqCopyWindowByTask.StartReqCopyWindowByTask(fbb);
            swm.ReqCopyWindowByTask.AddTaskid(fbb, _taskId);
            var msg = swm.ReqCopyWindowByTask.EndReqCopyWindowByTask(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCopyWindowByTask.HashID, fbb);
        }

        /// <summary>
        /// 发送开始过场
        /// </summary>
        /// <param name="_drama_id"></param>
        public void SendNetBeginPlayDrama( uint _drama_id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.BeginPlayDrama.StartBeginPlayDrama(fbb);
            swm.BeginPlayDrama.AddDramaId(fbb, _drama_id);
            fbb.Finish(swm.BeginPlayDrama.EndBeginPlayDrama(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.BeginPlayDrama.HashID, fbb);
            //x2m.BeginPlayDrama msg = new x2m.BeginPlayDrama();
            //msg.drama_id = _drama_id;
            //MsgDispatcher.instance.SendPackage(msg);
        }
        /// <summary>
        /// 发送结束过场
        /// </summary>
        /// <param name="_drama_id"></param>
        public void SendNetEndPlayDrama( uint _drama_id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.EndPlayDrama.StartEndPlayDrama(fbb);
            swm.EndPlayDrama.AddDramaId(fbb,_drama_id);
            fbb.Finish(swm.EndPlayDrama.EndEndPlayDrama(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.EndPlayDrama.HashID, fbb);

            //x2m.EndPlayDrama msg = new x2m.EndPlayDrama();
            //msg.drama_id = _drama_id;
            //MsgDispatcher.instance.SendPackage(msg);
        }
        /// <summary>
        /// 发送进入副本
        /// </summary>
        /// <param name="_baseId"></param>
        public void SendNetEnterCopy(uint _baseId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqEnterCopy.StartReqEnterCopy(fbb);
            swm.ReqEnterCopy.AddCopyBaseid(fbb, _baseId);
            var msg = swm.ReqEnterCopy.EndReqEnterCopy(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEnterCopy.HashID, fbb);
        }

        /// <summary>
        /// 发送离开副本
        /// </summary>
        /// <param name="_baseId"></param>
        public void SendNetExitCopy( uint _baseId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqExitCopy.StartReqExitCopy(fbb);
            swm.ReqExitCopy.AddCopyBaseid(fbb, _baseId);
            var msg = swm.ReqExitCopy.EndReqExitCopy(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqExitCopy.HashID, fbb);
        }

        /// <summary>
        /// 发送 请求副本基础信息
        /// </summary>
        /// <param name="_baseId"></param>
        public void SendNetReqCopyInfo(uint _baseId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqCopyInfo.StartReqCopyInfo(fbb);
            swm.ReqCopyInfo.AddCopyBaseid(fbb, _baseId);
            var msg = swm.ReqCopyInfo.EndReqCopyInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCopyInfo.HashID, fbb);
        }

        /// <summary>
        /// 发送 准备或拒绝
        /// </summary>
        /// <param name="_userId"></param>
        /// <param name="_prepare"></param>
        /// <param name="_copy_baseid"></param>
        public void SendReqPrepare( swm.CopyPrepare _prepare,uint _copy_baseid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqPrepare.StartReqPrepare(fbb);
            swm.ReqPrepare.AddPrepareInfo(fbb, _prepare);
            swm.ReqPrepare.AddCopyBaseid(fbb, _copy_baseid);
            var msg = swm.ReqPrepare.EndReqPrepare(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqPrepare.HashID, fbb);
        }

        //获得配置数据的协助函数
        public List<GameCopyTypeConfigData> GetCopyListByType(int _type)
        {
            List<GameCopyTypeConfigData> _lst = null;
            if(!m_CopyTypeDic.TryGetValue(_type, out _lst))
            {
                _lst = new List<GameCopyTypeConfigData>();
                CopyInfoTableBase? data;
                for (int i = 0; i < CopyInfoTableManager.Instance.m_DataList.CopyInfoTableLength; ++i)
                {
                    data = CopyInfoTableManager.Instance.m_DataList.CopyInfoTable(i);
                    if (_type == data.Value.type )
                    {
                        GameCopyTypeConfigData _CopyTypeConfigData = null;
                        for(int j =0;j<_lst.Count;j++)
                        {
                            if(_lst[j].GroupId == data.Value.group_id)
                            {
                                _CopyTypeConfigData = _lst[j];
                                break;
                            }
                        }
                        if(null == _CopyTypeConfigData)
                        {
                            _CopyTypeConfigData = new GameCopyTypeConfigData();
                            _CopyTypeConfigData.GroupId = data.Value.group_id;
                            _lst.Add(_CopyTypeConfigData);
                        }
                        _CopyTypeConfigData.AddCopyInfoTableBase(data);
                    }
                }
                m_CopyTypeDic[_type] = _lst;
            }
            return _lst;
        }

        #region 阵法副本
        /// <summary>
        /// 接收 新一轮阵法队长扔铜钱
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcTeamCopyActivity(swm.NotifyTeamCopyActivity _msg)
        {
            onTeamStartCopyActivity.Invoke();
        }

        /// <summary>
        /// 发送 扔铜钱完毕
        /// </summary>
        public void SendOpenActivity(uint _baseId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqOpenGameCopyActivity.StartReqOpenGameCopyActivity(fbb);
            var msg = swm.ReqOpenGameCopyActivity.EndReqOpenGameCopyActivity(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqOpenGameCopyActivity.HashID, fbb);
        }

        /// <summary>
        /// 接收 阵法随机的结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspOpenGameCopyActivity(swm.RspOpenGameCopyActivity _msg)
        {
            string effectName = "fx_cj_ExpActivity_zhen";//先播随机过程特效
            PlayEffect(effectName);

            //再延迟播放随机结果特效
            //测试*
            NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_Middle, "播放"+_msg.type.ToString()+"号特效");
            //*
            switch (_msg.type)
            {
                case 1:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 2:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 3:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 4:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 5:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 6:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 7:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 8:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 9:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 10:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 11:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 12:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 13:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 14:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 15:
                    effectName = "fx_bianshen_dl_s";
                    break;
                case 16:
                    effectName = "fx_bianshen_dl_s";
                    break;
                default:
                    break;
            }
            main.Instance.StartCoroutine(delayPlayEffect(effectName));
        }
        /// <summary>
        /// 在阵眼npc处播放阵法特效
        /// </summary>
        /// <param name="effectName">特效名</param>
        private void PlayEffect(string effectName, float height = 0)
        {
            Entity keyNPC = GameScene.Instance.GetEntityByBaseId(140000, true);
            if (keyNPC != null)
            {
                UnityEngine.Vector3 pos = keyNPC.Position;
                EffectMgr.Instance.Play(effectName, pos + new UnityEngine.Vector3(0, height, 0), IResourceLoader.strSceneEffectPath, true, 2);
            }
        }
        private  System.Collections.IEnumerator delayPlayEffect(string effectName)
        {
            yield return CoroutineConst.GetWaitForSeconds(10f);
            PlayEffect(effectName,5);
        }

        public swm.NotifyRoundInfoT RoundInfo
        {
            get
            {
                return m_roundInfo;
            }
        }
        swm.NotifyRoundInfoT m_roundInfo = new swm.NotifyRoundInfoT();
        /// <summary>
        /// 接收 阵法轮次
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyRoundInfo(swm.NotifyRoundInfo _msg)
        {
            if (m_roundInfo == null) m_roundInfo = new swm.NotifyRoundInfoT();
            m_roundInfo.FromMsg(_msg);
            onNotifyRoundInfo.Invoke();
        }
        /// <summary>
        /// 接收 副本挑战结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyTeamChallengeResult(swm.NotifyTeamChallengeResult _msg)
        {
            onNotifyTeamChallengeResult.Invoke(_msg.iswin);
        }

        swm.NotifyGameCopyExpResultT m_gameCopyExpResultT;
        public swm.NotifyGameCopyExpResultT GameCopyExpResultT
        {
            get
            {
                return m_gameCopyExpResultT;
            }
        }
        /// <summary>
        /// 接收 经验副本经验结算界面
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyGameCopyExpResult(swm.NotifyGameCopyExpResult _msg)
        {
            if (m_gameCopyExpResultT == null) m_gameCopyExpResultT = new swm.NotifyGameCopyExpResultT();
            m_gameCopyExpResultT.FromMsg(_msg);
            onNotifyGameCopyExpResult.Invoke();
        }

        swm.NotifyRoundNpcInfoT m_notifyRoundNpcInfo;
        public swm.NotifyRoundNpcInfoT NotifyRoundNpcInfoTData
        {
            get
            {
                return m_notifyRoundNpcInfo;
            }
        }
        private void ProcNotifyRoundNpcInfo(swm.NotifyRoundNpcInfo _msg)
        {
            if (m_notifyRoundNpcInfo == null) m_notifyRoundNpcInfo = new swm.NotifyRoundNpcInfoT();
            m_notifyRoundNpcInfo.FromMsg(_msg);
            onNotifyRoundNpcInfo.Invoke();
        }
        #endregion
    }
}
