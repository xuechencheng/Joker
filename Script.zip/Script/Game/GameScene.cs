using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using Bokura;
using FlatBuffers;
using System.Linq;

namespace Bokura
{
    /// <summary>
    /// 游戏状态
    /// </summary>
    public enum GameState
	{
		Start           = 0,
		Login           = 1,
		RoleCreate      = 3,
		RoleSelect      = 4,
		InGame          = 5,
		InBattleField   = 6,
        InArena         = 7,
        InSept          = 8,
        InHome          = 9,
        Finish,
	}

	public struct EntityFullID
	{

		public EntityFullID(swm.EntityType _type, ulong _id)
		{
			type = _type;
			id = _id;
		}
		public swm.EntityType type;
		public ulong id;
	}

	class EntityIDEqual : IEqualityComparer<EntityFullID>
	{
		public bool Equals(EntityFullID x, EntityFullID y)
		{
			return x.id == y.id && x.type == y.type;
		}

		public int GetHashCode(EntityFullID obj)
		{
			return (int)(obj.id & 0xfffffful);
		}
	}
    public class ClientGatherData
    {
        public ulong m_src_uid;
        public ulong m_start_time;
        public ulong m_end_time;

        public ChantTableBase? m_chantBase;
    }

    public class ClientToRelive
    {
        public swm.EntityType entity_type;
        public ulong entity_id;
    }

    public class ClientListReliveType
    {
        public List<swm.ReliveType> relive_type = new List<swm.ReliveType>(Bokura.ConstValue.kCap32);
        public ulong relive_time;
        public uint cur_times;
        public uint max_times;
        public ulong auto_time;
		public ulong battle_time;
        public ulong murder_id;
        public swm.EntityType murder_type;
     }
    
    public class MapEntityAttrsDiff
    {
        public int prop_str;        // 力量 strength
        public int prop_int;        // 智力 intelligence
        public int prop_sta;        // 耐力 stamina
        public int prop_dex;        // 敏捷 dexterity

        public int pdef;            // 物防（护甲）
        public int mdef;            // 魔防（抗性）

        public int min_pdam;        // 物攻
        public int max_pdam;
        public int min_mdam;        // 魔攻
        public int max_mdam;

        public float crit_pct;       // 暴击率   
        public float crit_effect;    // 暴击效果

        public int prof_armforce;      // 生活属性 - 臂力
        public int prof_technique;     // 生活属性 - 技术
        public int prof_inspiration;   // 生活属性 - 灵感

        public void Init(swm.MapEntityAttrs x, swm.MapEntityAttrsT y)
        {
            prop_str = (int)(x.prop_str - y.prop_str);
            prop_int = (int)(x.prop_int - y.prop_int);
            prop_sta = (int)(x.prop_sta - y.prop_sta);
            prop_dex = (int)(x.prop_dex - y.prop_dex);
            pdef = (int)(x.pdef - y.pdef);
            mdef = (int)(x.mdef - y.mdef);

            min_pdam = (int)(x.min_pdam - y.min_pdam);
            max_pdam = (int)(x.max_pdam - y.max_pdam);
            min_mdam = (int)(x.min_mdam - y.min_mdam);
            max_mdam = (int)(x.max_mdam - y.max_mdam);

            crit_pct = x.crit_pct - y.crit_pct;
            crit_effect = x.crit_effect - y.crit_effect;

            prof_armforce = (int)(x.prof_armforce - y.prof_armforce);
            prof_technique = (int)(x.prof_technique - y.prof_technique);
            prof_inspiration = (int)(x.prof_inspiration - y.prof_inspiration);
        }
    }

    public enum ECheckCloseCharacterType
    {
        Unknow,
        CheckBuff,
    }

    /// <summary>
    /// 检测靠近的npc
    /// </summary>
    [XLua.BlackList]
    public class CheckCloseCharacter
    {
        /// <summary>
        /// 是否开启检测
        /// </summary>
        public bool isstartcheck;

        /// <summary>
        /// 检测距离
        /// </summary>
        public double checkdis;

        /// <summary>
        /// 检测类型
        /// </summary>
        public int checktype;

        /// <summary>
        /// 检测buff列表
        /// </summary>
        public List<uint> checkbufflist = new List<uint>(Const.kCap8);

        public bool IsCheckBuff()
        {
            return checktype == (int)ECheckCloseCharacterType.CheckBuff;
        }

        /// <summary>
        /// 是否包含buff
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool ContainBuff(Entity entity)
        {
            if (entity == null)
                return false;

            if (entity.BuffProxy == null)
                return false;

            for (int i = 0; i < checkbufflist.Count; i++)
            {
                bool container = entity.BuffProxy.ContainBuff(checkbufflist[i]);
                if (container)
                {
                    return true;
                }   
            }

            return false;
        }
    }
    public partial class GameScene : ClientSingleton<GameScene>
    {
		Dictionary<ulong, Entity>      m_entitys = new Dictionary<ulong, Entity>(100);
		HashSet<Entity>[] m_typeEntitys = new HashSet<Entity>[(int)swm.EntityType.Max];
        List<Entity>      m_deletedEntitys = new List<Entity>(Const.kCap4);
        MainCharacter     m_mainCharacter;
        Entity            m_mouseOverAvatar;
        private swm.IntoMap? m_preIntomapInfo = null;
        private swm.IntoMap? m_currentIntomapInfo;
		bool m_sceneLoaded = false;
        ulong m_serverRecordTime;
        float m_currentGameTime;
        bool m_bIsInLoading = false;
        bool m_bIsNotShowLoading = false;
        bool m_bIsBlink = false;
        //private WaitForSeconds m_WaitForHalfSecondOperation = new WaitForSeconds(0.5f);//没有用的变量 m_WaitForHalfSecondOperation  会报警告 注销 赋值的地方也注销 shiliang
        private WaitForSeconds tWaitForOneSecondOperation = new WaitForSeconds(1.0f);

		Camera m_mainCamera;

        #region 调用Entity的异步方法可能导致对象池回收对象运行时出错，暂时先不使用对象池缓存
        //private ObjectPool<Character> m_CharacterPool = new ObjectPool<Character>();
        //private ObjectPool<Npc> m_NpcPool = new ObjectPool<Npc>();
        //private ObjectPool<TrapEntiy> m_TrapPool = new ObjectPool<TrapEntiy>();
        //private ObjectPool<GatherResourceEntity> m_GatherResPool = new ObjectPool<GatherResourceEntity>();
        //private ObjectPool<ClientNpc> m_ClientNpcPool = new ObjectPool<ClientNpc>();
        //private ObjectPool<Mount> m_MountPool = new ObjectPool<Mount>();
        #endregion

        public bool ShowAiTest = false;

        public ulong ServerRecordTime
        {
            get
            {
                return m_serverRecordTime;
            }
        }

        public float CurrentGameTime
        {
            get
            {
                return m_currentGameTime;
            }
            set
            {
                m_currentGameTime = value;
            }
        }

        /// <summary>
        /// 检测紧密的character
        /// </summary>
        private CheckCloseCharacter m_CheckCloseChar = new CheckCloseCharacter();

        #region EventType
        public class IntoMapEvent : GameEvent<swm.IntoMap>
        {

        }
        public class NotifyDeadMenuEvent : GameEvent<ClientListReliveType>
        {

        }

        public class NotifyToReliveEvent : GameEvent<ClientToRelive>
        {

        }

        public class AttrsChangeEvent : GameEvent<MapEntityAttrsDiff>
        {

        }

        public class LoadProgressEvent : GameEvent<float>
		{

		}
		public class EntityAddRemoveEvent : GameEvent<Entity>
		{

		}

        public class EntityRefreshEvent : GameEvent<Entity>
        {

        }

        public class ChantEvent : GameEvent<ClientGatherData>
        {

        }

        public class RedDotEvent : GameEvent<swm.RefreshRedDot>
        {
        }

        #endregion

        #region property

        private GameState m_CurrState = GameState.Start;
		/// <summary>
		/// 当前游戏状态
		/// </summary>
		public GameState currState { get { return m_CurrState; } }
        private string m_sceneName;

        public string SceneName
        {
            get
            {
                return m_sceneName;
            }
        }
                 
        public Event<GameState, GameState> onGameStateChange = new Event<GameState, GameState>();

        /// <summary>
        /// 死亡事件
        /// </summary>
        public Event<ulong> onToDieEvent = new Event<ulong>();

        /// <summary>
        /// 切换游戏状态
        /// </summary>
        public void ChangeGameState(GameState newState)
		{
            if(m_CurrState!=newState)
            {
                var oldstate = m_CurrState;
                m_CurrState = newState;
                if(newState == GameState.Login)
                {
                    //返回登入界面
                    if(null != m_preIntomapInfo)
                    m_preIntomapInfo = null;
                }
                if(CheckIsInGame( oldstate, newState))//newState < GameState.InGame && oldstate >= GameState.InGame)
                {
                    m_preIntomapInfo = null;
                    UIManager.Instance.CloseAll(new List<string>(2) { "ui_panel_systeminfo", "ui_panel_debug" });
                    //头顶信息在切换场景时是不会自动销毁的
                    UIUtility.DestroyPlayerInfoControlExist();
                    RemoveAllEntityAndMainChar();
                    ClearManagerData();
                }
                onGameStateChange.Invoke(oldstate, newState);
            }
            
		}

        public bool CheckIsInGame( GameState oldState, GameState newState)
        {
            return newState < GameState.InGame && oldState >= GameState.InGame;
        }
        /// <summary>
        /// 是否正在Loading过程中
        /// </summary>
        public bool IsInLoading
        {
            get { return m_bIsInLoading; }
        }

        public bool IsNotShowLoading
        {
            get { return m_bIsNotShowLoading; }
        }
        public swm.IntoMap? CurrentIntomapInfo
        {
            get { return m_currentIntomapInfo; }
        }
        /// <summary>
        /// 当前地图id
        /// </summary>
        public uint CurrentMapId
        {
            get
            {
                if (m_currentIntomapInfo.HasValue)
                    return m_currentIntomapInfo.Value.map_baseid;
                else
                    return 0;
            }
        }

        /// <summary>
        /// 当前是否仙门地图
        /// </summary>
        /// <returns></returns>
        public bool IsCurSeptMap()
        {
            bool isinsept = false;
            var mapcfg = MapInfoTableManager.GetData((int)CurrentMapId);
            if (mapcfg != null)
            {
                isinsept = mapcfg.maptype == (int)swm.MapType.Sept;
            }

            return isinsept;
        }

        /// <summary>
        /// 是否在大世界中
        /// </summary>
        public bool IsInWorldMap
        {
            get
            {
                bool isinbigworld = CurrentMapId == 3;
                bool isinsept = IsCurSeptMap();

                return isinbigworld || isinsept;
            }
        }
        public MainCharacter MainChar
        {
            get { return m_mainCharacter; }
            set { m_mainCharacter = value; }
        }
		public Camera MainCamera
		{
            get { return m_mainCamera; }
		}
        public Entity MouseOverAvatar
        {
            get
            {
                return m_mouseOverAvatar;
            }
        }

        public Dictionary<ulong, Entity> AllEntitys
        {
            get
            {
                return m_entitys;
            }
        }

        public int GetNpcEntityCount()
        {
            int count = 0;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsNpc() || _data.IsClientNpc())
                {
                    count += 1;
                }
            }
            return count;
        }

        public int GetCharacterEntityCount()
        {
            int count = 0;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsCharacter())
                {
                    count += 1;
                }
            }
            return count;
        }

        public int GetGatherResourceEntityCount()
        {
            int count = 0;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsGatherResource())
                {
                    count += 1;
                }
            }
            return count;
        }

        float m_gravity = -19.8f;
		public float Gravity
		{
			get
			{
				return m_gravity;
			}
		}
        #endregion

        #region events
        GameEvent m_onMainCharEnter = new GameEvent();
		public GameEvent onMainCharEnter
		{
			get
			{
				return m_onMainCharEnter;
			}

		}

		public GameEvent onBeginLoading = new GameEvent();
		public GameEvent<float> onLoadingProgress = new LoadProgressEvent();
        public GameEvent onPreEndLoading = new GameEvent();
        public GameEvent onEndLoading = new GameEvent();
        public GameEvent onJumpMapFinish = new GameEvent();
        public GameEvent<Entity> onAddEntity = new EntityAddRemoveEvent();
		public GameEvent<Entity> onRemoveEntity = new EntityAddRemoveEvent();
        public GameEvent onMainCharAdd = new GameEvent();
        public GameEvent onMainCharInitNetData = new GameEvent();
        public GameEvent<Entity> onMainCharEnterTrigger = new EntityRefreshEvent();
        public GameEvent onMainCharSnakePosChangeEvent = new GameEvent();
        public GameEvent onMainCharCreated = new GameEvent();

        public GameEvent<Entity> onRefreshMapEntityAttr = new EntityRefreshEvent();
        public GameEvent<Entity> onRefreshMapEntityData = new EntityRefreshEvent();
        public GameEvent<Entity> onRefreshEntityHpMp = new EntityRefreshEvent();
        public GameEvent<Entity> onRefreshEntityFlags = new EntityRefreshEvent();
        public GameEvent<Entity> onRefreshEntityFightPower = new EntityRefreshEvent();

        public GameEvent onRemoveAllEntity = new GameEvent();
        public GameEvent onPreIntoMap = new GameEvent();
        public IntoMapEvent onIntoMap = new IntoMapEvent();
        public GameEvent onBlinkToMap = new GameEvent();
		public GameEvent onLeaveGame = new GameEvent();
        public ChantEvent onChantEvent = new ChantEvent();
        public GameEvent<bool> onChantEndEvent = new GameEvent<bool>();
        public GameEvent<swm.NotifyEnterChant> onChantEvent2 = new GameEvent<swm.NotifyEnterChant>();
        public GameEvent<swm.NotifyExitChant> onChantEndEvent2 = new GameEvent<swm.NotifyExitChant>();
		public GameEvent<Entity> onAttacked = new GameEvent<Entity>();

        public GameEvent onDisconnect = new GameEvent();
        public GameEvent onReconnect = new GameEvent();

        public GameEvent<Entity> onRefreshLevelAndExp = new GameEvent<Entity>();

        public NotifyDeadMenuEvent onNotifyDeadMenu = new NotifyDeadMenuEvent();
        public NotifyToReliveEvent onNotifyToRelive = new NotifyToReliveEvent();

        public AttrsChangeEvent onAttrChange = new AttrsChangeEvent();
        public GameEvent<int,int> onFightPowerChange = new GameEvent<int,int>();

        public GameEvent<swm.NotifyType,ulong> onNotifyParamChange = new GameEvent<swm.NotifyType, ulong>();

        public GameEvent onRefreshCarefulStateUI = new GameEvent();
        public GameEvent onRefreshHurtBadlyStateUI = new GameEvent();

        public GameEvent<int, float> OnAiEnvParamChanged = new GameEvent<int,float>();
        private GameEvent<uint, uint, uint> m_onNtfInteractionActionEvent = new GameEvent<uint, uint, uint>();
        /// <summary>
        /// 通知交互行为事件
        /// </summary>
        public GameEvent<uint, uint, uint> onNtfInteractionActionEvent
        {
            get { return m_onNtfInteractionActionEvent; }
        }
        private GameEvent m_onInteractionActionStartEvent = new GameEvent();
        /// <summary>
        /// 交互行为开始事件
        /// </summary>
        public GameEvent onInteractionActionStartEvent
        {
            get { return m_onInteractionActionStartEvent; }
        }
        #endregion

        public GameScene()
        {
			for (int i = 0; i < (int)swm.EntityType.Max; i++)
			{
				m_typeEntitys[i] = new HashSet<Entity>();
			}
		}
		~GameScene()
        {
        }

        public void Init()
        {
            RegisterNetWorkMessage();

            WorldMapNpcInfoTable.Instance.Init();
            WorldMapResourceTable.Instance.Init();
            //夏军雁
            UICurveMgr.Instance.Init();
			AnnouncementManager.Instance.Init();
			ServersManager.Instance.Init();
			RoleCreationManager.Instance.Init();
			RoleSelectionManager.Instance.Init();
			AutoPathFinder.Instance.Init();
			AutoAttackManager.Instance.Init();
			SociatyManager.Instance.Init();
			BattleFieldManager.Instance.Init();
			RandomNameManager.Instance.Init();
			SceneSpawnManager.Instance.Init();
            RankListManager.Instance.Init();
            ThreeDPreviewManager.Instance.Init();
            InlineSpriteManager.Instance.Init();
            AvatarShowManager.Instance.Init();
            ArenaManager.Instance.Init();
            DailyActivityManager.Instance.Init();
            MapManager.Instance.Init();
            MiniMapManager.Instance.Init();
            UI_AreaTigger.Instance.Init();
            ScreenNarratorManager.Instance.Init();

            AirWallManager.Instance.Init();

            SysSettingModel.Instance.Init();

            WaterMoveManager.Instance.Init();
            WeatherManager.Instance.Init();
            AltarManager.Instance.Init();
            WeatherCloudManager.Instance.Init();
            StrongholdsManager.Instance.Init();
            MakeupOutGameManager.Instance.Init();
            IdentityManager.Instance.Init();
            FeatureArticleManager.Instance.Init();
            YuhengManager.Instance.Init();
            FormulaManager.Instance.Init();
            InvestCrusadeManager.Instance.Init();

            ClientNpcEntityManager.Instance.Init();

            //SkillModel.Instance.Init();
            BuffModel.Instance.Init();
            GameCopyModel.Instance.Init();
            TriggerManager.Instance.Init();
            ChatModel.Instance.Init();
            NotifyModel.Instance.Init();
            MissionModel.Instance.Init();
            DramaManager.Instance.Init();

            RedDotModel.Instance.Init();
            MiniGameModel.Instance.Init();
            BagManager.Instance.Init();
            MailModel.Instance.Init(); 
            TeamModel.Instance.Init();
            TitleModel.Instance.Init();
            TeamDropModel.Instance.Init();
            GeneralMessageModel.Instance.Init();
            FriendModel.Instance.Init();
            PlayerInfoModel.Instance.Init();
            ShopModel.Instance.Init();
            LifeSkillModel.Instance.Init();
            UserScriptModel.Instance.Init();

            //ManorModel.Instance.Init();

            FieldEventManager.Instance.Init();

            FashionModel.Instance.Init();

            AchievementModel.Instance.Init();

            ActionEmojiManager.Instance.Init();
            DeliveryManager.Instance.Init();
            FunctionNoticeManager.Instance.Init();
            PhotoManager.Instance.Init();
            CarryStageManager.Instance.Init();

            CollectionManager.Instance.Init();
            //ActionEffectManager.Instance.EnableSpawnGameObject = false;

            UserDataMgr.Instance.onUserDataSync.AddListener(CreateMainCharacter);
            ServersManager.Instance.onReconnectResultArrived.AddListener(ProcReconnectResult);

            //qi peng
            CDManager.Instance.Init();
            ExamMgr.Instance.Init();

            AuctionManager.Instance.Init();

            //SendTestNetDelay();//这个先注销  消息根本发不出去 socket都没链接
            NpcShowManager.Instance.Init();

            QingKungTouchPointManager.Instance.Init();
            InteractionPointManager.Instance.Init();

            NpcModelBindCommonDataManager.Instance.Init();

            //这里其实是为了构造，存到CameraHelper里面。
            CameraController.Instance.ResetConfig();
            SimpleCameraController.Instance.ResetConfig();
            FreeCameraController.Instance.ResetConfig();
            VisitNpcCameraController.Instance.ResetConfig();
            ManorBuildingCameraController.Instance.ResetConfig();
            XYFreeCameraController.Instance.ResetConfig();
            TierTrainCameraController.Instance.ResetConfig();
            HomeBuildCameraController.Instance.ResetConfig();
            HomeBuildDetailCameraController.Instance.ResetConfig();
            HomeFieldCameraController.Instance.ResetConfig();
            SeptBuildCameraController.Instance.ResetConfig();
            ICameraHelper.Instance.Init();

            BuildCityManager.Instance.Init();

            CRNPCMgr.Instance.Init();
            TreasureMapMgr.Instance.Init();
            XiandaoExpModel.Instance.Init();

            HomeModel.Instance.Init();
            EquipManager.Instance.Init();
            AITaskMgr.Instance.Init();

            ClientInteractionPointMgr.Instance.Init();
        }
        // reset managers' data when quiting gameplay
        public void ClearManagerData()
        {
            WorldMapNpcInfoTable.Instance.Clear();
            WorldMapResourceTable.Instance.Clear();

            UICurveMgr.Instance.Clear();
            AnnouncementManager.Instance.Clear();
            ServersManager.Instance.Clear();
            RoleCreationManager.Instance.Clear();
            RoleSelectionManager.Instance.Clear();
            AutoPathFinder.Instance.Clear();
            AutoAttackManager.Instance.Clear();
            SociatyManager.Instance.Clear();
            BattleFieldManager.Instance.Clear();
            RandomNameManager.Instance.Clear();
            SceneSpawnManager.Instance.Clear();
            RankListManager.Instance.Clear();
            InlineSpriteManager.Instance.Clear();
            AvatarShowManager.Instance.Clear();
            ArenaManager.Instance.Clear();
            DailyActivityManager.Instance.Clear();
            MapManager.Instance.Clear();
            MiniMapManager.Instance.Clear();
            UI_AreaTigger.Instance.Clear();
            ScreenNarratorManager.Instance.Clear();
            InteractionPointManager.Instance.Clear();

            NpcModelBindCommonDataManager.Instance.Clear();

            AirWallManager.Instance.Clear();

            SysSettingModel.Instance.Clear();

            WaterMoveManager.Instance.Clear();
            WeatherManager.Instance.Clear();
            AltarManager.Instance.Clear();
            WeatherCloudManager.Instance.Clear();
            StrongholdsManager.Instance.Clear();
            IdentityManager.Instance.Clear();
            FeatureArticleManager.Instance.Clear();
            YuhengManager.Instance.Clear();
            FormulaManager.Instance.Clear();
            InvestCrusadeManager.Instance.Clear();

            BuffModel.Instance.Clear();
            GameCopyModel.Instance.Clear();
            TriggerManager.Instance.Clear();
            ChatModel.Instance.Clear();
            NotifyModel.Instance.Clear();
            MissionModel.Instance.Clear();
            DramaManager.Instance.Clear();
            RedDotModel.Instance.Clear();
            MiniGameModel.Instance.Clear();

            BagManager.Instance.Clear();
            MailModel.Instance.Clear();
            TeamModel.Instance.Clear();
            TitleModel.Instance.Clear();
            TeamDropModel.Instance.Clear();
            GeneralMessageModel.Instance.Clear();
            FriendModel.Instance.Clear();
            PlayerInfoModel.Instance.Clear();
            ShopModel.Instance.Clear();
            LifeSkillModel.Instance.Clear();
            UserScriptModel.Instance.Clear();
            MountMgr.Instance.Clear();

            ClientNpcEntityManager.Instance.Clear();

            //ManorModel.Instance.Clear();

            FieldEventManager.Instance.Clear();

            FashionModel.Instance.Clear();

            AchievementModel.Instance.Clear();

            ActionEmojiManager.Instance.Clear();
            DeliveryManager.Instance.Clear();
            FunctionNoticeManager.Instance.Clear();
            CarryStageManager.Instance.Clear();

            CollectionManager.Instance.Clear();

            TargetSelector.Instance.Clear();

            //qi peng
            ExamMgr.Instance.Clear();

            AuctionManager.Instance.Clear();
            BuildCityManager.Instance.Clear();

            //Chen Jize
            CRNPCMgr.Instance.Clear();
            TreasureMapMgr.Instance.Clear();
            XiandaoExpModel.Instance.Clear();

            HomeModel.Instance.Clear();
            EquipManager.Instance.Clear();
            AITaskMgr.Instance.Clear();

            ClientInteractionPointMgr.Instance.Clear();
        }
        
        private void BeginLoading()
        {
            m_bIsInLoading = true;
            onBeginLoading.Invoke();
            IEventDispatchManager.Instance.Invoke(GlobalEventID.BEGIN_LOADING, 0);

            //玩家发生传送、进副本、进相位等切换地图行为时，取消原选择目标
            TargetSelector.Instance.SelectTarget(null);
            m_startLoadingTime = Time.realtimeSinceStartup;
            LogHelper.Log("start loading@", m_startLoadingTime);
        }

        float m_startLoadingTime;

        private void EndLoading()
        {
            var usedtime = Time.realtimeSinceStartup - m_startLoadingTime;
            LogHelper.Log("end loading used", usedtime);
            //LayeredSceneLoader.NotifySceneLoaded();
            IPathAgent.Instance.NotifySceneLoaded(m_sceneName);
            m_sceneLoaded = true;
            m_bIsInLoading = false;
            onEndLoading?.Invoke();
            onJumpMapFinishEvent();

            //这个uniqueshadow在场景加载完需要reset
            MainChar?.Avatar?.unityObject?.GetComponent<UniqueShadow>()?.ResetMaterial();

            if(MainChar != null)
            {
                if (bIsSameMap)
                {
                    //MainChar.forbidMove = false;
                    MainChar.CanControl = true;
                }
                if (!MainChar.isCurrCloudState()&& !bIsSameMap)
                {
                    CameraController.Instance.RotateTo(MainChar.DirAngle, 15);
                }
            }

            m_bIsNotShowLoading = false;
        }

        private void onJumpMapFinishEvent()
        {
            onJumpMapFinish.Invoke();
            IEventDispatchManager.Instance.Invoke(GlobalEventID.END_LOADING, 0);
        }

        /// Load a big world scene. 
		public void Load (string scenename, Action<bool> onLoadDone)
		{
            DoLoadScene (scenename, onLoadDone, true);
		}

        public void LoadSameScene(Action<bool> onLoadDone)
        {
            m_bIsInLoading = true;
            main.Instance.StartCoroutine(OnSubSceneLoadDone(onLoadDone));
        }

		public void SendLoadSceneOK()
		{
			var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.LoadSceneOk.StartLoadSceneOk(fbb);
			fbb.Finish(swm.LoadSceneOk.EndLoadSceneOk(fbb).Value);
			MsgDispatcher.instance.SendFBPackage(swm.LoadSceneOk.HashID, fbb);
		}
		private List<UnityAction> m_TodoLoadingTasks = new List<UnityAction>(Const.kCap8);
		/// <summary>
		/// 添加一个在Loading过程中执行的任务
		/// </summary>
		public void AddTaskToLoadingPhase(UnityAction task)
		{
			if (task != null)
				m_TodoLoadingTasks.Add(task);
		}
		/// <summary>
		/// 只加载场景
		/// </summary>
		public void LoadSimpleScene(string sceneName, Action<bool> onLoadDone)
		{
            BeginLoading();
            IEngineMain.Instance.DoPreLoadScene(sceneName, onLoadDone);
            m_sceneLoaded = false;
            ICameraHelper.Instance.DeInit();
			IWorldManager.Instance.LoadSceneAsync(sceneName, (UnityEngine.Object o) =>
			{
                main.Instance.StartCoroutine(WaitForSceneCompleteLoaded(onLoadDone));               
            });
		}
		/// <summary>
		/// 执行附加的任务
		/// </summary>
        IEnumerator WaitForSceneCompleteLoaded(Action<bool> onLoadDone)
        {
			//等待Scene加载完全
			yield return null;
			//每帧执行一个附加任务
			for (int tIdx = 0, tCount = m_TodoLoadingTasks.Count; tIdx < tCount; tIdx++)
			{
				UnityAction tTask = m_TodoLoadingTasks[tIdx];
				if (tTask != null)
					tTask.Invoke();
				onLoadingProgress.Invoke(0.8f + 0.2f * tIdx / tCount);
				yield return null;
			}
			//等待1秒钟，确保异步任务基本完成
			yield return tWaitForOneSecondOperation;
			onLoadingProgress.Invoke(1.0f);
			m_TodoLoadingTasks.Clear();
			onPreEndLoading.Invoke();
			m_bIsInLoading = false;
			onLoadDone.Invoke(true);
            EndLoading();
            ILevelSystemManager.Instance.Apply();
#if REMOTE_DEBUG
            X2DebugUtilities.Instance.postProcessLayer?.RequestUpdateSetting();
#endif
        }
        void StartUpdateLoadProgress(float start = 0, float finish = 1)
        {
            main.Instance.StartCoroutine(UpdateLoadProgress(start, finish));
        }
        IEnumerator UpdateLoadProgress(float start, float finish)
        {
            while (!m_sceneLoaded)
            {
                onLoadingProgress.Invoke(start + (finish - start) * LayeredSceneLoader.GetLoadingProgress());
                yield return null;
            }
            IWorldManager.Instance.SubSceneLoadingFinishedCallback = null;
        }
        public void LoadScene(string sceneName, Action<bool> onLoadDone)
        {
            DoLoadScene(sceneName, onLoadDone, Utilities.StringEndsWith(sceneName, "_baked")); // TODO better way to determine, or true if all scenes are baked
        }
        /// <summary>
        /// 判定 是否几乎在同一个位置? 因为服务端有体素 和客户端存在0.5左右的偏差， 这样的话 以客户端坐标为准
        /// </summary>
        /// <param name="_curPos"></param>
        /// <param name="_targetPos"></param>
        /// <returns></returns>
        private Vector3 IsSameNearPos(Vector3 _curPos,Vector3 _targetPos)
        {
            Vector3 ps = Vector3.zero;
            Vector3 _del = _targetPos - _curPos;
            if(_del.x > -1 && _del.x < 1 && _del.y > -1 && _del.y < 1 && _del.z > -1 && _del.z < 1)
            {
                ps = new Vector3(_curPos.x, _curPos.y, _curPos.z);
            }

            return ps;
        }

        uint maincharFightPower = 0;

        private void CreateMainCharacter()
        {
            var localpos = UserDataMgr.Instance.MainUserData.Value.cur_pos.FBVec3Vec3() - LayeredSceneLoader.WorldOffset;
            CameraController.Instance.SetCameraPosition(localpos);
            if(null == m_mainCharacter)
            {
                m_mainCharacter = new MainCharacter(UserDataMgr.Instance.MainUserData.Value.entity_id);
                m_mainCharacter.init();
                m_mainCharacter.Actived = false;
                if (maincharFightPower != 0)
                    m_mainCharacter.SetFightPower(maincharFightPower);
                onMainCharCreated.Invoke();
            }

            if (null != m_mainCharacter)
            {
                Vector3 pos = IsSameNearPos(m_mainCharacter.Position, UserDataMgr.Instance.MainUserData.Value.cur_pos.FBVec3Vec3());
                m_mainCharacter.SetNetData(UserDataMgr.Instance.MainUserData.Value);

                if (!bIsSameMap)//相位跳转防止闪回现象
                {
                    if (pos != Vector3.zero)
                    {
                        m_mainCharacter.Position = pos;
                    }
                }
                m_mainCharacter.Attrs.FromMsg(UserDataMgr.Instance.MainUserData.Value.attrs.Value);
            }

            SysSettingModel.Instance.LoadLocalSysSetting();

            IEventDispatchManager.Instance.Invoke(GlobalEventID.CREATE_MAIN_CHARACTER, 0);
        }

        private void InitMaiCharUserData()
        {
            m_mainCharacter.Position = m_currentIntomapInfo.Value.pos.FBVec3Vec3();//UserDataMgr.Instance.mainUserData.cur_pos);
            m_mainCharacter.Direction = m_currentIntomapInfo.Value.dir.FBVec3Vec3();
           // UserDataMgr.Instance.MainUserData.data.cur_pos = m_currentIntomapInfo.pos;
            //UserDataMgr.Instance.MainUserData.data.cur_dir = m_currentIntomapInfo.dir;
            //m_mainCharacter.Attrs.FromMsg(UserDataMgr.Instance.MainUserData.Value.attrs.Value);
            // m_mainCharacter.SetItems(UserDataMgr.Instance.MainUserData.items);
        }
        /// Load a scene. 
		/// <param name="sceneName"> Name of the scene to load.</param>
		/// <param name="onLoadDone">Callback when scene has finish loading.</param>  
        /// <param name="isBaked">Is scene baked.</param>
        void DoLoadScene (string sceneName, Action<bool> onLoadDone, bool isBaked)
		{
            BeginLoading();
            IEngineMain.Instance.DoPreLoadScene(sceneName, onLoadDone);
            ICameraHelper.Instance.DeInit();
            LayeredSceneLoader.SetIsInitialLoading(true);
			m_sceneLoaded = false;

            LoadCallback callback;
            // init the main character
            // load the chunk that the main character stays in
            if (isBaked)
            {
                const float StartSceneLoadedProgress = 0.2f;
                callback = (UnityEngine.Object o) =>
                {
                    //LogHelper.Log("LoadScene>>>>>>>>>>>>>>>>");
                    onLoadingProgress.Invoke(StartSceneLoadedProgress);
                    ICameraHelper.Instance.Init();
                    InitMaiCharUserData();
                };
                IWorldManager.Instance.SubSceneLoadingFinishedCallback = // callback triggered by LayeredSceneLoader from baked scenes
                    (float fMinX, float fMinY, float fMinZ, float fMaxX, float fMaxY, float fMaxZ) =>
                {
                    var pos = m_mainCharacter.GlobalPosition;
                    //LogHelper.Log("IWorldManager.Instance.SubSceneLoadingFinishedCallback>>>>>>>>>>>>>>>>");
                    if (CameraController.Instance.GetTargetTransform() == null)
                    {
                        LogHelper.LogWarning("Main camera have no target!");
                    }
                    if (pos.x >= fMinX && pos.x <= fMaxX && pos.z >= fMinZ && pos.z <= fMaxZ)
                    {
                        if (m_sceneLoaded)
                            return;
                        m_sceneLoaded = true;
                        //LogHelper.Log("LoadChunk>>>>>>>>>>>>>>>>");
                        m_mainCamera = ICameraHelper.Instance.MainCamera;
                        CameraController.Instance.SetCameraPosition(MainChar.LocalPosition);
                        ILevelSystemManager.Instance.Apply();
                        main.Instance.StartCoroutine(OnSubSceneLoadDone(onLoadDone));
                    }
                };

                StartUpdateLoadProgress(StartSceneLoadedProgress);
            }
            else
            {
                callback = (UnityEngine.Object o) =>
                {
                    onLoadingProgress.Invoke(1);
                    m_sceneLoaded = true;
                    main.Instance.StartCoroutine(LoadCamera(onLoadDone));
                };
            }

            m_sceneName = sceneName;
            // load the world scene with callback
            IWorldManager.Instance.LoadWorld (sceneName, callback);
        }

        void LoadingGotoScene()
        {
            LayeredSceneLoader.SetIsInitialLoading(true);
            m_sceneLoaded = false;
            // load the chunk that the main character stays in
            IWorldManager.Instance.SubSceneLoadingFinishedCallback = (float fMinX, float fMinY, float fMinZ, float fMaxX, float fMaxY, float fMaxZ) =>
            {
                var pos = m_mainCharacter.Position;
                if (pos.x >= fMinX && pos.x <= fMaxX && pos.z >= fMinZ && pos.z <= fMaxZ)
                {
                    if (m_sceneLoaded)
                        return;
                    m_sceneLoaded = true;

                    main.Instance.StartCoroutine(OnSubSceneLoadDone(null));
                    m_mainCamera = ICameraHelper.Instance.MainCamera;
                }
            };

            StartUpdateLoadProgress();
        }
        IEnumerator LoadCamera(Action<bool> onLoadDone)
        {
            //LogHelper.Log("LoadCamera>>>>>>>>>>>>>>>>");
            yield return null; // wait for camera ready
            ICameraHelper.Instance.Init();
            m_mainCamera = ICameraHelper.Instance.MainCamera;
            
            InitMaiCharUserData();
            CameraController.Instance.SetCameraPosition(MainChar.LocalPosition);
            ILevelSystemManager.Instance.Apply();
            //main.Instance.StartCoroutine(OnSubSceneLoadDone(onLoadDone));
            var it = OnSubSceneLoadDone(onLoadDone);
            while (it.MoveNext()) yield return it.Current;
        }
        /// Called when a chunk has been loaded.
		IEnumerator OnSubSceneLoadDone (Action<bool> onLoadDone)
        {
            //如果是第一次进入游戏，则等待大世界加载完再继续
            while (!m_sceneLoaded)
            {
                yield return null;
            }
            LayeredSceneLoader.SetIsInitialLoading(false);
            yield return tWaitForOneSecondOperation;

            m_mainCharacter.Actived = true;
            if (!m_bIsBlink)
            {
                onPreEndLoading.Invoke();
                AddEntity(MainChar);
            }
            else onLoadDone = null; // prevent multi-calls
            m_bIsBlink = false;
            m_bIsInLoading = false;
			m_sceneLoaded = true;

            if (!MainChar.IsInited || !MainChar.MainCharNetDataSetted)
                InitMainEntityByEntityData(MainChar, UserDataMgr.Instance.MainUserData.Value);
			else
				MainChar.Actived = true;

            onLoadDone?.Invoke(true);

            EndLoading();
#if REMOTE_DEBUG
            X2DebugUtilities.Instance.postProcessLayer?.RequestUpdateSetting();
#endif
            yield break;
		}
        /// <summary>
        /// 断线处理
        /// </summary>
        public void ProcDisconnect()
        {
            RemoveAllEntity();
            onDisconnect.Invoke();
        }
        /// <summary>
        /// 处理断线重连
        /// </summary>
        private void ProcReconnectResult(bool isSuccess)
        {
            if(isSuccess)
            {
                RequestRecoverState_CS();
                AddEntity(MainChar);
                MainChar.Actived = true;
                onReconnect.Invoke();
            }
        }
        public void RemoveAllEntityAndMainChar()
        {
            RemoveAllEntity();
            if (null != MainChar)
            {
                maincharFightPower = 0;
                MainChar.OnRemoveFromScene();
                MainChar.ReleaseMainCharacter();
                MainChar = null;
            }
        }
        public void RemoveAllEntity()
        {
            onRemoveAllEntity.Invoke();
            if (m_entitys != null)
            {
                foreach (var ent in m_entitys.ToList())
                {
                   RemoveEntity(ent.Value);
                }
                //m_entitys.Clear();//在RemoveEntity的时候逐一删除（存在保留主角的情况）
            }
            for (int i = 0; i < (int)swm.EntityType.Max; i++)
			{
				m_typeEntitys[i].Clear();
			}

        }

        public void RemoveEntityById(ulong _id, bool removeFromList = true)
        {
            Entity entity = GetEntityByID(_id);
            if (entity != null)
            {
                RemoveEntity(entity, removeFromList);
            }
        }

		public void RemoveEntity(Entity entity,bool removeFromList = true)
        {
            if(null != entity )
            {
                ulong _thisId = entity.ThisID;

                onRemoveEntity.Invoke(entity);

                bool isMainChar = entity.IsMainCharacter();
                var mount = entity as Mount;
                bool isMainMount = mount != null && mount.Owner.IsMainCharacter();
                if (!isMainChar && !isMainMount)//主角以及主角的马所有数据是不会被清除的
                {

                    if (entity is Npc)
                    {
                        if (AltarManager.Instance != null)
                        {
                            AltarManager.Instance.RemoveEffect(_thisId, entity.BaseID);
                        }
                    }

                    entity.OnRemoveFromScene();
                    if (removeFromList)
                    {
                        if (m_entityInUpdate)
                        {
                            LogHelper.LogError("cant remove entity in update loop!");
                            return;
                        }
                        var entitys = GetTypeEntityList(entity.EntityType);
                        entitys.Remove(entity);

                        m_entitys.Remove(_thisId);
                    }
                }
                if (MainChar != null && MainChar.CurrentCloseEntityId == _thisId)
                {
                    //删除的是采集资源 就再检查一
                    MainChar.CheckIsCloseEntity(true);
                }

                entity.Release();//所有实体都调用release 主角、马 重载过这个函数
                #region 调用Entity的异步方法可能导致对象池回收对象运行时出错，暂时先不使用对象池缓存
                //if (entity.EntityType == swm.EntityType.Player && !isMainChar)
                //{
                //    entity.ResetEntity();
                //    m_CharacterPool.Release((Character)entity);
                //}
                //else if (entity.EntityType == swm.EntityType.Npc)
                //{
                //    entity.ResetEntity();
                //    m_NpcPool.Release((Npc)entity);
                //}
                //else if (entity.EntityType == swm.EntityType.Trap)
                //{
                //    entity.ResetEntity();
                //    m_TrapPool.Release((TrapEntiy)entity);
                //}
                //else if (entity.EntityType == swm.EntityType.Resource)
                //{
                //    entity.ResetEntity();
                //    m_GatherResPool.Release((GatherResourceEntity)entity);
                //}
                //else if (entity.EntityType == swm.EntityType.ClientNpc)
                //{
                //    entity.ResetEntity();
                //    m_ClientNpcPool.Release((ClientNpc)entity);
                //}
                //else if (entity.EntityType == swm.EntityType.Mount && !isMainMount)
                //{
                //    entity.ResetEntity();
                //    m_MountPool.Release((Mount)entity);
                //}
                #endregion
            }

        }
        private IEnumerator WaitAddEntity()
        {
            while (m_entityInUpdate)
            {
                yield return null;
            }
            for (int i = 0; i < m_addEntities.Count; i++)
            {
                TryAddEntity(m_addEntities[i]);
            }
            m_addEntities.Clear();
            m_IsAddEntityCorStart = false;
        }
        List<Entity> m_addEntities = new List<Entity>(32);
        private void TryAddEntity(Entity entity)
        {
            try
            {
                if (!m_entitys.ContainsKey(entity.ThisID))
                {
                    m_entitys.Add(entity.ThisID, entity);
                    var entitys = GetTypeEntityList(entity.EntityType);
                    entitys.Add(entity);

                    entity.OnAddToScene();
                }

                onAddEntity.Invoke(entity);

            }
            catch (Exception e)
            {
                LogHelper.LogError(e.ToString());
            }
        }
        bool m_IsAddEntityCorStart;
		public void AddEntity(Entity entity)
		{
            if(m_entityInUpdate)
            {
                //LogHelper.LogError("cant add entity in update loop!");
                m_addEntities.Add(entity);
                if (!m_IsAddEntityCorStart)
                {
                    main.Instance.StartCoroutine(WaitAddEntity());
                    m_IsAddEntityCorStart = true;
                }
                return;
            }

            TryAddEntity(entity);

        }

        /// <summary>
        /// 获得目标id 范围内的所有实体(包括 角色，npc)
        /// </summary>
        /// <param name="id"></param>
        /// <param name="distance"></param>
        /// <returns></returns>
        public void GetAllEntityInDistance(ulong _id,Action<float, Entity> _fuc, float _distance = 1.0f)
        {
            Entity _targetEntity = GetEntityByID(_id);
            if(null != _targetEntity)
            {
                float sqrDistance = _distance * _distance;
                foreach (var kv in AllEntitys)
                {
                     if (kv.Value.ThisID == MainChar.ThisID)//|| kv.Value == _targetEntity
                        continue;

                    if (kv.Value.IsCharacter() || (kv.Value.Visible && !kv.Value.Died && kv.Value.IsNpc()))
                    {
                        var dis = (kv.Value.Position - _targetEntity.Position).sqrMagnitude;
                        if (dis < sqrDistance)
                        {
                            _fuc(dis, kv.Value);
                        }
                    }

                }
            }

        }

        public void SwtichAllNpcAction(string actionname)
        {
            int animid = Animator.StringToHash(actionname);

            foreach (var kv in AllEntitys)
            {
                Entity entity = kv.Value;
                if (entity == null)
                    continue;

                if (MainChar != null)
                {
                    if (entity.ThisID == MainChar.ThisID)
                        continue;
                }

                if (!entity.Visible)
                    continue;

                if (!entity.IsNpc())
                    continue;

                Npc npc = entity as Npc;
                if (npc == null)
                    continue;

                if (actionname == "dead")
                {
                    entity.Died = true;
                }
                else
                {
                    entity.Died = false;
                }

                npc.CrossFadeAll(animid);
            }
        }

        /// <summary>
        /// 检测紧密的npc
        /// </summary>
        /// <param name="dodgerange">碰撞范围检测</param>
        /// <returns></returns>
        [XLua.BlackList]
        public void CheckMainCharacterCloseNpc(float dodgerange)
        {
            if (null == MainChar)
                return;

            foreach (var kv in AllEntitys)
            {
                Entity entity = kv.Value;
                if (entity == null)
                    continue;
                if (!entity.IsNpc())
                    continue;
                if (entity.Died)
                    continue;
                if (!entity.Visible)
                    continue;
                if (entity.ThisID == MainChar.ThisID)
                    continue;

                Npc npc = entity as Npc;
                if (npc == null)
                    continue;

                if (!npc.NpcConfig.HasValue)
                    continue;

                int speak_dis = npc.NpcConfig.Value.speak_dis;

                float speakrealdis = speak_dis * 0.001f;

                float sqrDis = (entity.Position - MainChar.Position).sqrMagnitude;
                float sqrspeakrange = speakrealdis * speakrealdis;
                float sqrdodgerange = dodgerange * dodgerange;

                // npc说话触发器

                // speak_dis大于0的话才会处理
                if (speak_dis > 0)
                {
                    if (sqrDis < sqrspeakrange)
                    {
                        if (!npc.IsSpeakInTriggerArea)
                        {
                            npc.SpeakByMainCharCol();
                        }

                        npc.IsSpeakInTriggerArea = true;
                    }
                    else
                    {
                        npc.IsSpeakInTriggerArea = false;
                    }
                }

                // npc躲闪触发器
                if (sqrDis < sqrdodgerange)
                {
                    npc.DodgeByMainCharCol(true);
                }

                //距离
                if(sqrDis < 25)
                {
                    npc.LookAtTarget(MainChar.HeadPostition.WorldToUnityVec(),2,sqrDis < 1);
                }
            }
        }

        public Entity CheckMainCharacterCloseEntity()
        {
            if (null == MainChar)
                return null;

            double mixdistance = double.MaxValue;
            Entity checkentity = null;

            foreach (var kv in AllEntitys)
            {
                Entity entity = kv.Value;
                if (entity == null)
                    continue;

                if (entity.ThisID == MainChar.ThisID)
                    continue;

                if (entity.Died && !entity.GatherwhileDie)
                    continue;

                // 是否可选择
                if (!entity.CanSelect)
                    continue;

                if (!entity.ActuallyVisible)
                    continue;

                float sqrDis = (entity.Position - MainChar.Position).sqrMagnitude;
                bool cancheck = false;

                if (entity.IsGatherResource())
                {
                    GatherResourceEntity _gaEty = entity as GatherResourceEntity;
                    if (_gaEty != null && _gaEty.GatherResourceConfig.HasValue)
                    {
                        double sqrClose = _gaEty.GatherResourceConfig.Value.close_dis;
                        sqrClose = sqrClose * sqrClose;
                        if (sqrDis < sqrClose)
                        {
                            cancheck = true;
                        }
                    }
                }
                else if (entity.IsMachine())
                {
                    MechanismEntity mE = entity as MechanismEntity;

                    if (mE.IsMachineTriggerTypeOperate())
                    {
                        if (sqrDis < mE.CheckRangeSqr())
                        {
                            cancheck = true;
                        }
                    }

                }
                else if (entity.IsNpc())
                {
                    //npc
                    Npc _npcEty = entity as Npc;
                    if (_npcEty != null)
                    {
                        if (_npcEty.NpcConfig.HasValue)
                        {
                            //int _npcType = _npcEty.NpcConfig.Value.type;
//                             if (_npcType == (int)swm.NpcType.NPCTYPE_MISSION ||
//                                 _npcType == (int)swm.NpcType.NPCTYPE_BASE_NPC ||
//                                 _npcType == (int)swm.NpcType.NPCTYPE_DAILYACTIVITY_NPC||
//                                 _npcType == (int)swm.NpcType.NPCTYPE_GATHER)
                            if(_npcEty.NpcConfig.Value.inter_act_optionsLength > 0 || (_npcEty.Died && _npcEty.NpcConfig.Value.gather_res > 0))// 能否交互由交互选项字段决定 策划：钱龙君
                            {
                                double sqrClose = _npcEty.NpcConfig.Value.visit_distance;
                                sqrClose = sqrClose * sqrClose;
                                if (sqrDis < sqrClose)
                                {
                                    cancheck = true;
                                }
                            }
                        }
                    }
                }
                else if(entity.IsClientNpc())
                {
                    ClientNpc _npcEty = entity as ClientNpc;
                    if (_npcEty != null)
                    {
                        if (_npcEty.NpcConfig.HasValue)
                        {
                            if (_npcEty.NpcConfig.Value.inter_act_optionsLength > 0 || (_npcEty.Died && _npcEty.NpcConfig.Value.gather_res > 0))// 能否交互由交互选项字段决定 策划：钱龙君
                            {
                                double sqrClose = _npcEty.NpcConfig.Value.visit_distance;
                                sqrClose = sqrClose * sqrClose;
                                if (sqrDis < sqrClose)
                                {
                                    cancheck = true;
                                }
                            }
                        }
                    }
                }
                else if (entity.IsCharacter())
                {
                    if (m_CheckCloseChar.isstartcheck)
                    {
                        double sqrClose = m_CheckCloseChar.checkdis * m_CheckCloseChar.checkdis;
                        if (sqrDis < sqrClose)
                        {
                            if (m_CheckCloseChar.IsCheckBuff())
                            {
                                bool containbuff = m_CheckCloseChar.ContainBuff(entity);
                                if (containbuff)
                                {
                                    cancheck = true;
                                }
                            }
                        }
                    }
                }

                if (cancheck)
                {
                    if (entity == null || sqrDis < mixdistance)
                    {
                        mixdistance = sqrDis;
                        checkentity = entity;
                    }
                }
            }

            return checkentity;
        }

        public Entity GetEntityByID(swm.EntityType type, ulong id)
		{
			Entity entity;
			if (m_entitys.TryGetValue( id, out entity))
				return entity;
			return null;
		}
        /// <summary>
        /// 通过id 获得 实体类型  服务器定：右边56位就是类型?
        /// </summary>
        /// <returns></returns>
        public static swm.EntityType GetEntityTypeById(ulong _id)
        {
            swm.EntityType result = (swm.EntityType)(_id >> 56);
            if (result == swm.EntityType.Unknown)    //认为是非服务器角色 客户端纯粹模拟的角色 比如 马和 npc好友召唤出来的
            {
                Entity entity = GameScene.Instance.GetEntityByID(swm.EntityType.Unknown,_id);
                if (entity!=null&& entity.IsClientEntity==true)
                {
                    return swm.EntityType.ClientNpc;
                }
            }
            return result;
        }

        public Entity GetEntityByID<T>(ulong id) where T : Entity
        {
            Entity entity;
            if (m_entitys.TryGetValue(id, out entity))
                return entity as T;
            return null;
        }
        public Entity GetEntityByID( ulong id)
		{
			Entity entity;
            if (MainChar != null && MainChar.ThisID == id)
            {
                entity = MainChar;
                return entity;
            }
            if (m_entitys.TryGetValue( id, out entity))
				return entity;
			return null;
		}
		/// <summary>
		/// 判断实体与主角的距离是否不超过给定距离?
		/// </summary>
		public bool IsEntityInDistance(ulong id, float distance)
		{
			if (MainChar == null) return false;
			Entity tEty = GetEntityByID(id);
			if (tEty == null) return false;
			return (MainChar.Position - tEty.Position).sqrMagnitude <= distance * distance;
		}

        /// <summary>
        /// 通过数据创建一个简单的 npc 实体
        /// </summary>
        /// <param name="_baseID"></param>
        /// <param name="_pos"></param>
        /// <param name="_dir"></param>
        /// <returns></returns>
        public Npc CreateSimpleNpcByData(uint _baseID, Vector3 _pos, Vector3 _dir)
        {
            var tData = new swm.MapEntityDataT();
            //tData.entity_type = swm.EntityType.Npc;
            tData.cur_pos  =_pos.Vec3();
            tData.cur_dir = _dir.Vec3();
            var tNpcData = new swm.MapNpcT();
            tData.npc_data = tNpcData;
            tNpcData.baseid = _baseID;
            tNpcData.career_sex = swm.CareerSex.Unknown;
            tNpcData.career_type = swm.CareerType.Unknown;
            Npc tNpc = new Npc(0);
            tNpc.Avatar.EnableLOD = false;
            tNpc.Layer = (int)UserLayer.Layer_Invisible;
            tNpc.SyncLoad = true;
            tNpc.Visible = true;
            tNpc.init();
            tNpc.SetData(tData);
            tNpc.SetNpcConfigById((int)_baseID);
            tNpc.OnAddToScene();
            return tNpc;
        }

        public ClientNpc CreateClientNpcSync(ulong uid, uint _baseID, Vector3 _pos, Quaternion _rot, string tName = null)
        {
            ClientNpc tNpc = new ClientNpc(uid);
            tNpc.init();

            tNpc.IsClientEntity = true;
            tNpc.SyncLoad = true;

            var tNpcData = new swm.MapNpcT();
            tNpcData.baseid = _baseID;
            tNpcData.career_sex = swm.CareerSex.Unknown;
            tNpcData.career_type = swm.CareerType.Unknown;

            var tData = new swm.MapEntityDataT();
            tData.cur_pos = Vector3.zero.Vec3();
            tData.cur_dir = Vector3.zero.Vec3();
            tData.npc_data = tNpcData;
            tData.entity_id = uid;
            tData.move_speed = 2500;
            if (tName != null) tData.name = tName;
            tNpc.SetData(tData);

            tNpc.Avatar.EnableLOD = false;
            tNpc.Layer = (int)UserLayer.Layer_Character;
            tNpc.Visible = true;
            tNpc.Actived = true;
            //tNpc.m_UpdateMove = true;

            tNpc.Avatar.unityObject.transform.position = _pos;
            tNpc.Avatar.unityObject.transform.rotation = _rot;

            
            //tNpc.OnAddToScene();

            GameScene.Instance.AddEntity(tNpc);
            return tNpc;
        } 

        public bool GetEntityAvatarShowConfig(AvatarShowType _type, string _ModelName, int _panelId,out AvatarShowConfig _out)
        {
            AvatarShowConfigs tAsset = UIUtility.GetAvatarShowConfig(_type, _ModelName);
            if(null == tAsset)
            {
                _out = null;
                return false;
            }
            _out = tAsset.GetConfigByPanelId(_panelId);
            return true;
        }

        public Entity GetNpcEntityNearestByBaseId(ulong _baseId, Vector3 pos)
        {
            Entity entity = null;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsNpc())
                {
                    Npc _npcData = _data as Npc;
                    if (_npcData.NpcConfig.Value.id == (int)_baseId)
                    {
                        if(entity == null)
                            entity = _npcData;
                        else if((entity.Position - pos).sqrMagnitude > (_npcData.Position - pos).sqrMagnitude)
                            entity = _npcData;
                    }
                }
            }
            return entity;
        }
        /// <summary>
        /// 获取一个最近的npc
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="onlyAlive"></param>
        /// <returns></returns>
        public Entity GetNearNpcEntityByBaseId(ulong _baseId, bool onlyAlive = false)
        {
            Entity entity = null;
            float _dis = 0;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsNpc())
                {
                    if (onlyAlive && _data.Died) continue;
                    Npc _npcData = _data as Npc;
                    if (_npcData.Visible  && _npcData.NpcConfig.Value.id == (int)_baseId)
                    {
                        Vector3 mainPs = MainChar.Position;
                        Vector3 targetPos = _npcData.Position;
                        float _len = (mainPs-targetPos).sqrMagnitude;
                        if (entity == null || _len < _dis)
                        {
                            entity = _npcData;
                            _dis = _len;
                        }
                    }
                }
                else if(_data.IsClientNpc())
                {
                    if (onlyAlive && _data.Died) continue;
                    ClientNpc _npcData = _data as ClientNpc;
                    if (_npcData.Visible && _npcData.NpcConfig.Value.id == (int)_baseId)
                    {
                        Vector3 mainPs = MainChar.Position;
                        Vector3 targetPos = _npcData.Position;
                        float _len = (mainPs - targetPos).sqrMagnitude;
                        if (entity == null || _len < _dis)
                        {
                            entity = _npcData;
                            _dis = _len;
                        }
                    }
                }
            }
            return entity;
        }
        /// <summary>
        /// 获取一个npc
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="onlyAlive"></param>
        /// <returns></returns>
        public Entity GetNpcEntityByBaseId(ulong _baseId, bool onlyAlive = false, bool onlyVis = true)
        {
            Entity entity = null;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsNpc())
                {
                    if (onlyAlive && _data.Died) continue;
                    if (onlyVis && !_data.Visible) continue;

                    Npc _npcData = _data as Npc;
                    if (_npcData == null)
                        continue;

                    if(_npcData.NpcConfig.Value.id == (int)_baseId)
                    {
                        entity = _npcData;
                        break;
                    }
                }
                else if(_data.IsClientNpc())
                {
                    if (onlyAlive && _data.Died) continue;
                    if (onlyVis && !_data.Visible) continue;

                    ClientNpc _npcData = _data as ClientNpc;
                    if (_npcData == null)
                        continue;

                    if (_npcData.NpcConfig.Value.id == (int)_baseId)
                    {
                        entity = _npcData;
                        break;
                    }
                }
            }
            return entity;
        }

        private List<Entity> m_tmpEntityList = new List<Entity>(Const.kCap32);
        public void ClearAllTempEntityEntity()
        {
            m_tmpEntityList.Clear();
        }
        /// <summary>
        /// 获取 这个baseid的npc列表
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="onlyAlive"></param>
        /// <param name="onlyVis"></param>
        /// <returns></returns>
        public List<Entity> GetNpcEntityListByBaseId(ulong _baseId, bool onlyAlive = false, bool onlyVis = true)
        {
            ClearAllTempEntityEntity();
            foreach (var kv in m_entitys)
            {
                var _npcData = kv.Value as Npc;
                if (_npcData == null)
                    continue;
                if (onlyAlive && _npcData.Died) continue;
                if (onlyVis && !_npcData.Visible) continue;
                if (_npcData.NpcConfig.Value.id == (int)_baseId)
                {
                    m_tmpEntityList.Add( _npcData);
                }
            }
            return m_tmpEntityList;
        }

        /// <summary>
        /// 获得最近的一个资源entity
        /// </summary>
        /// <param name="_baseId"></param>
        /// <returns></returns>
        public Entity GetNearGatherResourceEntityByBaseId(ulong _baseId, List<ulong> hasgatheridlist)
        {
            Entity entity = null;
            float _dis = 0;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data == null)
                    continue;

                ulong entityid = _data.ThisID;
                if (_data.Died)
                    continue;

                if (!_data.Visible)
                    continue;

                if (!_data.IsGatherResource())
                    continue;

                GatherResourceEntity _gaData = _data as GatherResourceEntity;
                if (_gaData.GatherResourceConfig.Value.id != (int)_baseId)
                    continue;

                if (hasgatheridlist != null)
                {
                    if (hasgatheridlist.Contains(entityid))
                        continue;
                }

                Vector3 mainPs = MainChar.Position;
                Vector3 targetPos = _gaData.Position;
                float _len = (mainPs - targetPos).sqrMagnitude;
                if (entity == null || _len < _dis)
                {
                    entity = _gaData;
                    _dis = _len;
                }
            }

            return entity;
        }

        /// <summary>
        /// 获取一个资源entity
        /// </summary>
        /// <param name="_baseId"></param>
        /// <returns></returns>
        public Entity GetGatherResourceEntityByBaseId(ulong _baseId)
        {
            Entity entity = null;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsGatherResource())
                {
                    if (_data.Died)
                        continue;
                    if (!_data.Visible)
                        continue;

                    GatherResourceEntity _gaData = _data as GatherResourceEntity;
                    if (_gaData.GatherResourceConfig.Value.id == (int)_baseId)
                    {
                        entity = _gaData;
                        break;
                    }
                }
            }

            return entity;
        }

        /// <summary>
        /// 获取能够攻击的范围内的最近实体
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="attrange"></param>
        /// <param name="hascheckbaseid">是否需要检测基本id</param>
        /// <param name="onlyAlive"></param>
        /// <returns></returns>
        public Entity GetCanAttNearNpcEntity(ulong _baseId, float attrange, bool hascheckbaseid, bool isappointpos, Vector3 appointpos, bool onlyAlive = false)
        {
            if (MainChar == null)
                return null;

            Vector3 mainPs = MainChar.Position;
            if (isappointpos)
            {
                mainPs = appointpos;
            }

            Entity entity = null;
            float sqrattrange = attrange * attrange;
            float _dis = 0;

            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data == null)
                    continue;

                if (!_data.IsNpc())
                    continue;

                if (onlyAlive && _data.Died)
                    continue;

                Npc _npcData = _data as Npc;
                if (_npcData == null)
                    continue;

                NpcTableBase? npccfg = _npcData.NpcConfig;
                if (npccfg == null)
                    continue;

                if (!npccfg.HasValue)
                    continue;

                // 是否检测baseid
                if (hascheckbaseid)
                {
                    // 不是指定id
                    if (npccfg.Value.id != (int)_baseId)
                        continue;
                }

                // 不能被攻击
                if (npccfg.Value.under_attack <= 0)
                    continue;
                
                Vector3 targetPos = _npcData.Position;
                float _len = (mainPs - targetPos).sqrMagnitude;
                if (_len > sqrattrange)
                    continue;

                if (entity == null || _len < _dis)
                {
                    entity = _npcData;
                    _dis = _len;
                }
            }

            return entity;
        }

        public Entity GetEntityByBaseId(ulong _baseId, bool onlyAlive = false)
        {
            Entity entity = null;
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (onlyAlive && _data.Died) continue;
                if (!_data.Visible)
                        continue;
                uint _id = _data.BaseID;
                if (_id != 0 && _id == _baseId)
                {
                    entity = _data;
                    break;
                }
            }
            return entity; 
        }
        public Entity GetEntityByGameObject(GameObject go)
        {
            foreach (var kv in m_entitys)
            {
                if (kv.Value.Avatar.unityObject == go)
                    return kv.Value;
            }
            return null;
        }
        public HashSet<Entity> GetTypeEntityList(swm.EntityType et)
		{
			return m_typeEntitys[(int)et];
		}

		/// <summary>
		/// 检查当前地图是否可以骑马?
		/// </summary>
		/// <returns></returns>
		public bool CheckCurrentMapRidable()
		{
            var map = MapInfoTableManager.GetData((int)CurrentMapId);
            return map.canridemount;
		}

        public void RefreshAllNpcMissionState()
        {
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsNpc())
                {
                    Npc _npcData = _data as Npc;
                    _npcData.RefreshMissionState();
                }
                else if(_data.IsClientNpc())
                {
                    ClientNpc _npcData = _data as ClientNpc;
                    _npcData.RefreshMissionState();
                }
            }
        }

        public void RefreshAllGatherResourceMissionState(uint _baseId,byte _state)
        {
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                if (_data.IsGatherResource())
                {
                    GatherResourceEntity _gatherResource = _data as GatherResourceEntity;
                    if(_baseId == _gatherResource.BaseID)
                    {
                        _gatherResource.RefreshResourceMissionStateChange(_state);
                    }
                }
            }
        }

        void UpdateMouseOverAvatar()
        {
            Entity lastMouseOverAvatar = m_mouseOverAvatar;
            m_mouseOverAvatar = IAvatarPicker.Instance.GetNearestAvatar(IUnityInput.Instance.mousePosition) as Entity;
            if (m_mouseOverAvatar != lastMouseOverAvatar)
            {
                if (lastMouseOverAvatar != null)
                    lastMouseOverAvatar.OnMouseLeave();
                if (m_mouseOverAvatar != null)
                    m_mouseOverAvatar.OnMouseIn();
            }
        }

        public void SetAllEntityIsVisible(bool _bIsVisible)
        {
            Entity entity;
            foreach (var kv in m_entitys)
            {
                entity = kv.Value;
                if(null != entity)
                {
                    entity.Visible = _bIsVisible;
                }
            }
        }

        public void FixedUpdate()
        {
            if (!IEngineMain.Instance.GameInited)
                return;

        }
        public void Update()
        {

            if (!IEngineMain.Instance.GameInited)
				return;

            if (Bokura.UnityInput.Instance.GetKeyUp(KeyCode.P))
            {
                //LuaFastCall.DoString("test_open_newmanor_createbuilding()");
                //HomeModel.Instance.GM_Test_Event();
            }
            

            //Utilities.ProfilerBegin("IAvatarPicker.Clear");
            //{
            //    IAvatarPicker.Instance.Clear();
            //}
            //Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("MobileBlockMgr.Update");
            {
                MobileBlockMgr.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("Entities.Update 1");
            {
                UpdateEntitys();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("Entities.Update 2");
            {
                UpdateDelEntity();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("TargetSelector.Update");
			{
				TargetSelector.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("ITimelineManager.Update");
			{
				ITimelineManager.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("UpdateMouseOverAvatar");
			{
				UpdateMouseOverAvatar();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("ICrossPlatformInputManager.Update");
			{
				Bokura.ICrossPlatformInputManager.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("TriggerManager.Update");
			{
				TriggerManager.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("ActionEffectManager.Update");
			{
				ActionEffectManager.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("EffectMgr.Update");
			{
				EffectMgr.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("SkillManager.Update");
			{
				SkillManager.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("TeamModel.Update");
			{
				TeamModel.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("UISkillAttacker.Update");
			{
				UISkillAttacker.Instance.Update();
			}
			Utilities.ProfilerEnd();

			Utilities.ProfilerBegin("EntityEffectTextManager.Update");
			{
				EntityEffectTextManager.Instance.Update();
			}
			Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("QingKungTouchPointManager.Update");
            {
                QingKungTouchPointManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("WaterMoveManager.Update");
            {
                WaterMoveManager.Instance.Update();
            }
            Utilities.ProfilerEnd();
            Utilities.ProfilerBegin("WeatherCloudManager.Update");
            {
                WeatherCloudManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("WeatherManager.Update");
            {
                WeatherManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("FeatureArticleManager.Update");
            {
                FeatureArticleManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("ICameraController.Update");
            {
                ICameraHelper.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("BagManager.Update");
            {
                BagManager.Instance.Update();
            }
            Utilities.ProfilerEnd();
            Utilities.ProfilerBegin("ClientNpcEntityManager.Update");
            {
                ClientNpcEntityManager.Instance.Update();
            }
            Utilities.ProfilerEnd();
            Utilities.ProfilerBegin("CRNPCMgr.Update");
            {
                CRNPCMgr.Instance.Update();
            }
            Utilities.ProfilerEnd();
            Utilities.ProfilerBegin("TreasureMapMgr.Update");
            {
                TreasureMapMgr.Instance.Update();
            }
            Utilities.ProfilerEnd();
            Utilities.ProfilerBegin("BuildCitySandTable.Update");
            {
                SandTableManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("InteractionPointManager.Update");
            {
                InteractionPointManager.Instance.Update();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("AITask.Update");
            {
                AITaskMgr.Instance.Update();
            }
            Utilities.ProfilerEnd();

            if (IDynamicBoneManager.Instance != null && IDynamicBoneManager.Instance.m_ReferenceObject == null && m_mainCharacter != null && m_mainCharacter.Avatar != null && m_mainCharacter.Avatar.unityObject != null)
                IDynamicBoneManager.Instance.m_ReferenceObject = m_mainCharacter.Avatar.unityObject.transform;
            if (ShrubManager.Instance != null && ShrubManager.Instance.targetTr == null && m_mainCharacter != null && m_mainCharacter.Avatar != null && m_mainCharacter.Avatar.unityObject != null)
                ShrubManager.Instance.targetTr = m_mainCharacter.Avatar.unityObject.transform;
        }

        public List<Entity> m_showCharacterByLevelSystemList = new List<Entity>(0);
        public List<Entity> m_showNpcByLevelSystemList = new List<Entity>(0);
        
        Collider[] m_overlapColliders = new Collider[10];
        HashSet<Entity> m_cameraCullListA = new HashSet<Entity>();
        HashSet<Entity> m_cameraCullListB = new HashSet<Entity>();
        bool m_entityInUpdate = false;
        void UpdateEntitys()
        {
            if (!m_sceneLoaded)
                return;
            if(m_showCharacterByLevelSystemList.Count>0)
                m_showCharacterByLevelSystemList.Clear();
            if (m_showNpcByLevelSystemList.Count > 0)
                m_showNpcByLevelSystemList.Clear();

            Entity entity;
            Vector3 iCamNearClipPos = CameraController.Instance.GetCameraPosition() + CameraController.Instance.Direction * 0.5f;//放在for循环外以供重复使用

#if REMOTE_DEBUG
            bool enablelevelsystemvisible = true;
#else
            bool enablelevelsystemvisible = ((m_entitys.Count > LevelSystemManager.s_characterShowNumber) || (m_entitys.Count > LevelSystemManager.s_npcShowNumber));
#endif
            m_entityInUpdate = true;
            foreach (var kv in m_entitys)
            {
                entity = kv.Value;

                if (entity.IsNeedDel())
                {
                    AddDeleteEntity(entity);
                }
                else if (kv.Value.Actived)
                {
                    kv.Value.Update();
                }
                else
                {
                    kv.Value.Actived = IsTerrainLoaded(kv.Value.Position);
                }
                Utilities.ProfilerBegin("Entities.CullLogic");

                //------------角色,npc显示距离 数量 逻辑;
                if(enablelevelsystemvisible)
                {
                    if (MainChar != null)
                    {
                        if (entity.IsNpc() && entity.b_isBeAttachTo)
                        {
                            var carryEntity = GetEntityByID(entity.ul_BeAttachToRoleId);
                            if (carryEntity != null)
                                entity.ToMainCharacterSqrMagnitude = (carryEntity.Position - MainChar.Position).sqrMagnitude;
                            else
                                entity.ToMainCharacterSqrMagnitude = (entity.Position - MainChar.Position).sqrMagnitude;
                        }
                        else
                            entity.ToMainCharacterSqrMagnitude = (entity.Position - MainChar.Position).sqrMagnitude;
                    }

                    if (entity.IsCharacter())
                    {
                        if (!entity.IsMainCharacter())
                        {
                            bool isShow = (entity.ToMainCharacterSqrMagnitude <= Bokura.LevelSystemManager.s_characterShowSqrMagnitude);
                            if (isShow)
                            {
                                m_showCharacterByLevelSystemList.Add(entity);
                            }
                            else
                            {
                                entity.VisibleByLevelSystem = false;
                            }
                        }
                    }
                    else if (entity.IsNpc())
                    {
                        bool isShow = (entity.ToMainCharacterSqrMagnitude <= Bokura.LevelSystemManager.s_npcShowSqrMagnitude) ||
                            ((MainChar != null) && (entity.ThisID == MainChar.ul_AttachRoleId));
                        if (isShow)
                        {
                            m_showNpcByLevelSystemList.Add(entity);
                        }
                        else
                        {
                            entity.VisibleByLevelSystem = false;
                        }
                    }
                }
               

                //------------角色,npc显示距离 数量 逻辑;

                //------------检测是否需要隐藏npc模型;
                //if (!entity.IsNeedDel() && !(entity.IsMainCharacter()) && CameraController.Instance != null && entity.Avatar.getBoundBox() != null)
                //{
                //    Bounds iEtyBound = entity.Avatar.getBoundBox().bounds;
                //    if (iEtyBound.Contains(iCamNearClipPos))
                //        entity.VisibleByCamera = false;
                //    else
                //        entity.VisibleByCamera = true;
                //}
                Utilities.ProfilerEnd();

            }
            m_entityInUpdate = false;
            Utilities.ProfilerBegin("Entities.Camera Cull");

            int overlapcount = 0;
            do
            {
                overlapcount = Physics.OverlapSphereNonAlloc(iCamNearClipPos, 0.01f, m_overlapColliders, (int)UserLayerMask.Character | (int)UserLayerMask.NPC);
                if (overlapcount > m_overlapColliders.Length)
                    m_overlapColliders = new Collider[overlapcount];
                else
                    break;

            } while (true);
            if(overlapcount > 0)
            {

                for (int i = 0; i < overlapcount; i++)
                {
                    var aef = m_overlapColliders[i].GetComponent<Bokura.AvatarEventFinder>();
                    entity = aef.m_AvatarEvent as Entity;
                    if (!(entity is MainCharacter))
                    {
                        if (entity && !m_cameraCullListA.Contains(entity))
                        {
                            entity.VisibleByCamera = false;
                            m_cameraCullListA.Add(entity);
                            //m_camerCulledEntitys.Add(entity);
                        }
                    }
                }

                //m_camerCulledEntitys.Remove
            }
            if(m_cameraCullListB.Count>0)
            {
                foreach (var e in m_cameraCullListB)
                {
                    if (!m_cameraCullListA.Contains(e))
                    {
                        e.VisibleByCamera = true;
                    }
                }
                m_cameraCullListB.Clear();
              
            }
            var temp = m_cameraCullListB;
            m_cameraCullListB = m_cameraCullListA;
            m_cameraCullListA = temp;

            Utilities.ProfilerEnd();

            //------------角色,npc显示距离 数量 逻辑;
            if (enablelevelsystemvisible)
            {
                Utilities.ProfilerBegin("Entities.enablelevelsystemvisible");
                if (m_showCharacterByLevelSystemList.Count > Bokura.LevelSystemManager.s_characterShowNumber)
                {
                    m_showCharacterByLevelSystemList.Sort((A, B) => A.ToMainCharacterSqrMagnitude.CompareTo(B.ToMainCharacterSqrMagnitude));
                    int index = 0;
                    foreach (var item in m_showCharacterByLevelSystemList)
                    {
                        item.VisibleByLevelSystem = (index < Bokura.LevelSystemManager.s_characterShowNumber);

                        index = index + 1;
                    }
                }
                else
                {
                    foreach (var item in m_showCharacterByLevelSystemList)
                    {
                        item.VisibleByLevelSystem = true;
                    }
                }

                if (m_showNpcByLevelSystemList.Count > Bokura.LevelSystemManager.s_npcShowNumber)
                {
                    m_showNpcByLevelSystemList.Sort((A, B) => A.ToMainCharacterSqrMagnitude.CompareTo(B.ToMainCharacterSqrMagnitude));
                    int index = 0;
                    foreach (var item in m_showNpcByLevelSystemList)
                    {
                        item.VisibleByLevelSystem = (index < Bokura.LevelSystemManager.s_npcShowNumber);

                        index = index + 1;
                    }
                }
                else
                {
                    foreach (var item in m_showNpcByLevelSystemList)
                    {
                        item.VisibleByLevelSystem = true;
                    }
                }
                Utilities.ProfilerEnd();
            }
            //------------角色,npc显示距离 数量 逻辑;

        }

        //public int sortEntity(Entity A, Entity B)
        //{
        //    return A.ToMainCharacterSqrMagnitude - B.ToMainCharacterSqrMagnitude;
        //}

        public void LateUpdate()
        {
            ITimelineManager.Instance.LateUpdate();
            Utilities.ProfilerBegin("ICameraController.LateUpdate");
            {
                ICameraHelper.Instance.LateUpdate();
            }
            Utilities.ProfilerEnd();

            Utilities.ProfilerBegin("FeatureArticleManager.LateUpdate");
            {
                FeatureArticleManager.Instance.LateUpdate();
            }
            Utilities.ProfilerEnd();

        }
        void UpdateDelEntity()
        {
            for (int i = 0; i < m_deletedEntitys.Count; ++i)
            {
				var ety = m_deletedEntitys[i];
				var entitys = GetTypeEntityList(ety.EntityType);
				entitys.Remove(ety);
               m_entitys.Remove(ety.ThisID);
            }

            m_deletedEntitys.Clear();
        }
        public void AddDeleteEntityById(ulong _id)
        {
            Entity _ety = GetEntityByID(_id);
            AddDeleteEntity(_ety);
        }

        void AddDeleteEntity(Entity entity)
        {
            entity.Deleted = true;
            if(!m_deletedEntitys.Contains(entity))
                m_deletedEntitys.Add(entity);
        }
        public void DispathMainCharacterEnterTrigger(Entity _entity)
        {
            onMainCharEnterTrigger.Invoke(_entity);
        }

        public ulong GetServerTime()
        {
            //记录时间 + 流逝时间 + RTT时间
            ulong time = m_serverRecordTime + (ulong)((Time.realtimeSinceStartup - m_currentGameTime) * 1000.0f) + (ulong)(ServersManager.Instance.RTT * 0.5f);
            return time;
        }
        public void SetServerTime(ulong ser)
        {
            m_serverRecordTime = ser;
            m_currentGameTime = Time.realtimeSinceStartup;
        }
        public ulong GetAdjuestServerTime()
        {
            return GetServerTime() + (ulong)(ServersManager.Instance.RTT * 0.5f );
        }

        public static DateTime startDateTime = new DateTime(1970, 1, 1);
        public DateTime GetServerDateTimeNow()
        {
            DateTime tInit = TimeZone.CurrentTimeZone.ToLocalTime(startDateTime);
            TimeSpan toNow = new TimeSpan((long)GameScene.Instance.GetServerTime() * 10000);
            DateTime tNow = tInit.Add(toNow);

            return tNow;
        }
        /// <summary>
        /// 启用/禁用输入
        /// </summary>
        public void EnableInput(bool enable)
		{
			ICrossPlatformInputManager.Instance.enable = enable;
		}

        public void SetControlCameraMode(bool isSet)
        {
            Bokura.ICrossPlatformInputManager.Instance.ControlCameraMode(isSet);
        }

        public void SetControlCameraHorizontalDeltaX(float x)
        {
            Bokura.ICrossPlatformInputManager.Instance.ControlCameraHorizontalDeltaX(x);
        }

        public void SetControlCameraVerticalDeltaY(float y)
        {
            Bokura.ICrossPlatformInputManager.Instance.ControlCameraVerticalDeltaY(y);
        }

        public void SetControlCameraAxisXY(float x, float y)
        {
            SetControlCameraHorizontalDeltaX(x);
            SetControlCameraVerticalDeltaY(y);
        }

        public void DispatchMainCharSnakePosChange()
        {
            onMainCharSnakePosChangeEvent.Invoke();
        }
        //拍照时 屏蔽显示相关
        public void SetPhotoshow(bool npcvb, bool friendvb, bool teamvb, bool sociatyvb, bool othervb)
        {
            Entity entity;
            foreach (var kv in m_entitys)
            {
                entity = kv.Value;
                if (null != entity)
                {
                    if (entity.EntityType == swm.EntityType.Npc)
                    {
                        entity.Visible = npcvb;
                    }
                    else if (entity.EntityType == swm.EntityType.Player && entity.ThisID != GameScene.Instance.MainChar.ThisID)
                    {
                        //设置所有好友 是否可见 有可能跟设置队伍可见 帮派可见冲突  如果一个角色既是队伍又是好友 又是帮派里的  设置某一个可见时 会有冲突
                        //好友列表中有该角色数据
                        bool b_friend = entity.IsFriendly;
                        bool b_Team = entity.IsTeamMember;
                        bool b_Sociaty = entity.IsSociatyMember;
                        bool b_other = !b_friend && !b_Team && !b_Sociaty;
                        if (b_other == true)
                        {
                            entity.Visible = othervb;
                        }
                        else
                        {
                            bool hasshow = false;
                            if (b_friend == true && friendvb == true)
                            {
                                hasshow = true;
                            }
                            if (hasshow == false && b_Team == true && teamvb == true)
                            {
                                hasshow = true;
                            }
                            if (hasshow == false && b_Sociaty == true && sociatyvb == true)
                            {
                                hasshow = true;
                            }
                            entity.Visible = hasshow;
                        }

                    }

                }
            }
        }
        //设置所有npc 是否可见
        public void PhotoShowNpc(bool Visible)
        {
            Entity entity;
            foreach (var kv in m_entitys)
            {
                entity = kv.Value;
                if (null != entity && entity.EntityType == swm.EntityType.Npc)
                {
                    entity.Visible = Visible;
                }
            }
        }

        //设置所有好友 是否可见 有可能跟设置队伍可见 帮派可见冲突  如果一个角色既是队伍又是好友 又是帮派里的  设置某一个可见时 会有冲突
        public void PhotoShowFriend(bool Visible)
        {
            Entity entity;
            foreach (var kv in m_entitys)
            {
                entity = kv.Value;
                if (null != entity && entity.EntityType == swm.EntityType.Player && entity.ThisID != GameScene.Instance.MainChar.ThisID)
                {
                    //好友列表中有该角色数据
                    if (entity.IsFriendly)
                    {
                        entity.Visible = Visible;
                    }

                }
            }
        }

        //设置所有队伍成员 是否可见
        public void PhotoShowTeam(bool Visible)
        {
            if (TeamModel.Instance.IsHasTeam())
            {
                //List<TeamMemberData>[] myteaminfo = TeamModel.Instance.TeamData.TeamMemberList;// GetTeamMemberListByMemberId
                Entity entity;
                foreach (var kv in m_entitys)
                {
                    entity = kv.Value;
                    if (null != entity && entity.EntityType == swm.EntityType.Player && entity.ThisID != GameScene.Instance.MainChar.ThisID)
                    {
                        //队伍列表中有该角色数据
                        if (entity.IsTeamMember)
                        {
                            entity.Visible = Visible;
                        }

                    }
                }
            }
        }

        //是否显示仙门角色
        public void PhotoShowSociaty(bool Visible)
        {
            bool hassociaty = MainChar && MainChar.IsInSociaty();

            if (hassociaty)
            {
                Entity entity;
                foreach (var kv in m_entitys)
                {
                    entity = kv.Value;
                    if (null != entity && entity.EntityType == swm.EntityType.Player && entity.ThisID != GameScene.Instance.MainChar.ThisID)
                    {
                        if (entity.IsSociatyMember)
                        {
                            entity.Visible = Visible;
                        }
                    }
                }
            }
        }

        public void PhotoShowOther(bool Visible)
        {
            bool hassociaty = MainChar && MainChar.IsInSociaty();

            if (hassociaty)
            {
                Entity entity;
                foreach (var kv in m_entitys)
                {
                    entity = kv.Value;
                    if (null != entity && entity.EntityType == swm.EntityType.Player && entity.ThisID != GameScene.Instance.MainChar.ThisID)
                    {
                        //非好友  非仙门 非队伍
                        if (entity.IsFriendly == false && entity.IsTeamMember == false && entity.IsSociatyMember == false)
                        {
                            entity.Visible = Visible;
                        }

                    }
                }
            }
        }

        //end

        /// <summary>
        /// Get a Mount from ObjectPool
        /// </summary>
        /// <returns></returns>
        public Mount GetNewMount()
        {
            //return m_MountPool.Get();
            return new Mount();
        }

#region 副本流程事件
    
        //相机锁定
        void LockCamera(float[] config)
        {
            if (CameraController.Instance.BlockInput) return;
            if (config.Length != 3) return;
            float rotateX = config[0];
            float rotateY = config[1];
            float dis = config[2];
            
            //curRotateX = ICameraController.Instance.RotateX;
            //curRotateY = ICameraController.Instance.RotateY;
            CameraController.Instance.AnimRotateTo(rotateY, rotateX, 1);
            //curDis = ICameraController.Instance.CurDistance;
            CameraController.Instance.ChangeDistanceTo(dis);

            CameraController.Instance.BlockInput = true;
        }
        void ResumeCamera()
        {
            //ICameraController.Instance.AnimRotateTo(
            //    curRotateX, curRotateY, QiTest.Instance.speed);

            //ICameraController.Instance.ChangeDistanceTo(curDis);

            CameraController.Instance.Reset();

            CameraController.Instance.BlockInput = false;
        }
        
        //float curDis;
        //float curRotateX;
        //float curRotateY;
        float[] ParseCameraConfig(string str)
        {
            float[] m_gameCopyCameraConfig = new float[3];
            if (!string.IsNullOrEmpty(str))
            {
                string[] subStrs = str.Split('|');
                for (int i = 0; i < subStrs.Length; i++)
                {
                    float a = 0;
                    if (float.TryParse(subStrs[i], out a))
                    {
                        if (m_gameCopyCameraConfig.Length > i)
                        {
                            m_gameCopyCameraConfig[i] = a;
                        }
                        else
                        {
                            LogHelper.LogError("GameCopy Camera Config parse error! str:" + str);
                        }
                    }
                    else
                    {
                        LogHelper.LogError("GameCopy Camera Config parse error! str:" + str);
                    }

                }
            }
            return m_gameCopyCameraConfig;
        }
        
        //重伤
        /// <summary>
        /// 进入/退出重伤
        /// </summary>
        void SetHurtBadly(bool value)
        {
            MainChar.IsHurtBadly = value;
            onRefreshHurtBadlyStateUI.Invoke();
        }

        //寻路特效
        List<Vector3> m_gameCopyFindPathPoints;
        List<Vector3> GameCopyFindPathPoints
        {
            get
            {
                if (m_gameCopyFindPathPoints == null)
                {
                    m_gameCopyFindPathPoints = new List<Vector3>(128);
                }
                return m_gameCopyFindPathPoints;
            }
        }
        List<EffectMgr.EffectInfo> m_gameCopyFindPathEffects;
        List<EffectMgr.EffectInfo> GameCopyFindPathEffects {
            get
            {
                if (m_gameCopyFindPathEffects == null)
                {
                    m_gameCopyFindPathEffects = new List<EffectMgr.EffectInfo>(128);
                }
                return m_gameCopyFindPathEffects;
            }
        } 
        void SetFindPathEffect()
        {
            Vector3 targetPos = new Vector3(
                    GameCopyFindPathConfig[0],
                    GameCopyFindPathConfig[1],
                    GameCopyFindPathConfig[2]
                );
            float spacing = GameCopyFindPathConfig[3];
            string fxName = m_gameCopyFindPathConfig2;
            
            if (!MainChar.PathAgent.PathUpdate(MainChar.Position, targetPos))
            {
                LogHelper.LogError("gamecopy findpath error!");
                return;
            }
            Vector3[] tPath = MainChar.PathAgent.onStop(MainChar.Position);
            for (int i = 0; i < tPath.Length; i++)
            {
                tPath[i] -= LayeredSceneLoader.WorldOffset;
            }

            GameCopyFindPathPoints.Clear();
            GameCopyFindPathEffects.Clear();

            //均匀填充一些点
            FillPathPoint(tPath, spacing, GameCopyFindPathPoints);

            //所有的点防止悬空，射线检测向下落地
            Vector3 upOffset = Vector3.up * 0.32f;
            for (int i = 0; i < GameCopyFindPathPoints.Count; i++)
            {
                RaycastHit hit;
                if(Utilities.RayCast(GameCopyFindPathPoints[i],Vector3.down,out hit, 10))
                {
                    GameCopyFindPathPoints[i] = hit.point;
                }
                GameCopyFindPathPoints[i] += upOffset;//适当抬高一点点
            }

            for (int i = 0; i < GameCopyFindPathPoints.Count; i++)
            {
                Vector3 point = GameCopyFindPathPoints[i];
                if (!string.IsNullOrEmpty(fxName))
                {
                    GameCopyFindPathEffects.Add(EffectMgr.Instance.Play(fxName, point, IResourceLoader.strBuffEffectPath, false));
                }
            }
        }
        void RemoveFindPathEffect()
        {
            for (int i = 0; i < GameCopyFindPathEffects.Count; i++)
            {
                if (GameCopyFindPathEffects[i] != null)
                {
                    GameCopyFindPathEffects[i].Stop();
                    GameCopyFindPathEffects[i] = null;
                }
            }
            GameCopyFindPathEffects.Clear();
        }
        //在一组点之间额外均匀填充一些点
        void FillPathPoint(Vector3[] tPath, float spacing, List<Vector3> points)
        {
            for (int i = 0; i < tPath.Length; i++)
            {
                points.Add(tPath[i]);

                if (i + 1 < tPath.Length)
                {
                    FillPointBetweenTwoPoint(tPath[i], tPath[i + 1], spacing, ref points);
                }
            }
        }

        //两点之间均匀填充一些点
        void FillPointBetweenTwoPoint(Vector3 a, Vector3 b, float spacing, ref List<Vector3> points)
        {
            float dis = Vector3.Distance(a, b);
            int fillNum = Mathf.FloorToInt(dis / spacing);
            
            for (int i = 1; i < fillNum + 1; i++)
            {
                points.Add(a + (b - a).normalized * spacing * i);
            }
        }

        //x|y|z|密度间距|特效名
        float[] GameCopyFindPathConfig
        {
            get
            {
                if (m_gameCopyFindPathConfig == null)
                {
                    m_gameCopyFindPathConfig = new float[4];
                }
                return m_gameCopyFindPathConfig;
            }
        }
        float[] m_gameCopyFindPathConfig = null;
        string m_gameCopyFindPathConfig2;
        void ParseGameCopyFindPathConfig(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                string[] subStrs = str.Split('|');
                for (int i = 0; i < subStrs.Length - 1; i++)
                {
					float a = 0;
                    if (float.TryParse(subStrs[i], out a))
                    {
                        if (GameCopyFindPathConfig.Length > i)
                        {
                            GameCopyFindPathConfig[i] = a;
                        }
                        else
                        {
                            LogHelper.LogError("GameCopy FindPath Config parse error! str:" + str);
                        }
                    }
                    else
                    {
                        LogHelper.LogError("GameCopy FindPath Config parse error! str:" + str);
                    }
                }
                m_gameCopyFindPathConfig2 = subStrs[subStrs.Length - 1];
            }
        }

        //背景音乐
        string[] GameCopyBGMusicConfig
        {
            get
            {
                if (m_gameCopyBGMusicConfig == null)
                {
                    m_gameCopyBGMusicConfig = new string[2];
                }
                return m_gameCopyBGMusicConfig;
            }
            set
            {
                m_gameCopyBGMusicConfig = value;
            }
        }
        string[] m_gameCopyBGMusicConfig = null;
        void ParseBGMusicConfig(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                GameCopyBGMusicConfig = str.Split('|');
            }
            else
            {
                LogHelper.LogError("ParseBGMusicConfig str empty!");
            }
        }
        //风力
        int[] GameCopyWindConfig
        {
            get
            {
                if (m_gameCopyWindConfig == null)
                {
                    m_gameCopyWindConfig = new int[2];
                }
                return m_gameCopyWindConfig;
            }
            set
            {
                m_gameCopyWindConfig = value;
            }
        }
        int[] m_gameCopyWindConfig = null;
        void ParseWindConfig(string str)
        {
            string[] subStrs = str.Split('|');
            for (int i = 0; i < subStrs.Length; i++)
            {
                int a = 0;
                if (int.TryParse(subStrs[i], out a))
                {
                    if (GameCopyWindConfig.Length > i)
                    {
                        GameCopyWindConfig[i] = a;
                    }
                    else
                    {
                        LogHelper.LogError("GameCopy Wind Config parse error! str:" + str);
                    }
                }
                else
                {
                    LogHelper.LogError("GameCopy Wind Config parse error! str:" + str);
                }

            }
        }

        //场景特效
        void ParseSceneEffectConfig(string str , out Vector3 pos,out string effectName)
        {
            pos = new Vector3();
            effectName = "";
            if (!string.IsNullOrEmpty(str))
            {
                string[] subStrs = str.Split('|');
                for (int i = 0; i < subStrs.Length - 1; i++)
                {
                    float a = 0;
                    if (float.TryParse(subStrs[i], out a))
                    {
                        if (i == 0)
                        {
                            pos.x = a;
                        }
                        else if (i == 1)
                        {
                            pos.y = a;
                        }
                        else if (i == 2)
                        {
                            pos.z = a;
                        }
                    }
                    else
                    {
                        LogHelper.LogError("GameCopy FindPath Config parse error! str:" + str);
                    }
                }
                effectName = subStrs[subStrs.Length - 1];
            }
        }
#endregion



        /// <summary>
        /// 开始检测紧密的角色
        /// </summary>
        /// <param name="checkdis">检测距离</param>
        /// <param name="checkbufflist">检测的bufflist</param>
        public void StartCheckCloseCharacter(double checkdis, int checktype, uint[] checkbufflist)
        {
            m_CheckCloseChar.isstartcheck = true;
            m_CheckCloseChar.checkdis = checkdis;
            m_CheckCloseChar.checktype = checktype;

            m_CheckCloseChar.checkbufflist.Clear();
            for (int i = 0; i < checkbufflist.Length; i++)
            {
                m_CheckCloseChar.checkbufflist.Add(checkbufflist[i]);
            }
        }

        /// <summary>
        /// 结束检测紧密的角色
        /// </summary>
        public void EndCheckCloseCharacter()
        {
            m_CheckCloseChar.isstartcheck = false;
            m_CheckCloseChar.checkdis = 0.0f;
            m_CheckCloseChar.checktype = (int)ECheckCloseCharacterType.Unknow;
            m_CheckCloseChar.checkbufflist.Clear();
        }

        public void SetTimeScale(float timeScale)
        {
            Time.timeScale = timeScale;
        }

#region 玩家交互点

        // 处理角色的交互行为
        private void ProcCharacterInteraction(MovableEntity entity, uint realinteraction_id)
        {
            if (!entity.IsCharacter())
                return;

            if (m_mainCharacter == null)
                return;

            // 主角没有占领交互点
            if (!m_mainCharacter.IsInInteractionPoint)
            {
                // 同时主角进入交互区域
                if (m_mainCharacter.enterInteractionGroupId > 0)
                {
                    // 检测玩家的交互点是否在主角的交互区域, 在的话检测
                    bool iscontain = InteractionPointManager.Instance.ContainPointByGroupId(m_mainCharacter.enterInteractionGroupId, realinteraction_id);
                    if (iscontain)
                    {
                        m_onNtfInteractionActionEvent.Invoke((uint)MovableEntity.InteractionState.None, realinteraction_id, 0);
                    }
                }
            }
        }

        /// <summary>
        /// 得到没有使用的交互点
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        public uint GetUnUsedInteractionPoint(uint groupid)
        {
            HashSet<uint> usedpointlist = new HashSet<uint>();

            foreach (var kv in AllEntitys)
            {
                var entity = kv.Value as MovableEntity;
                if (entity == null)
                    continue;

                if (entity.Died)
                    continue;

                //if (!entity.IsCharacter())
                //    continue;

                if (!entity.IsInInteractionPoint)
                    continue;

                bool iscontain = InteractionPointManager.Instance.ContainPointByGroupId(groupid, entity.interaction_id);
                if (!iscontain)
                    continue;

                usedpointlist.Add(entity.interaction_id);
            }

            return InteractionPointManager.Instance.GetUnUsedPointByGroupId(groupid, ref usedpointlist);
        }

        public void ReqEnterInteraction_CS(uint interaction_id, uint action_id)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqEnterInteraction> tOffset = swm.ReqEnterInteraction.CreateReqEnterInteraction(tFBB, interaction_id, action_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEnterInteraction.HashID, tFBB);
        }

        public void ReqExitInteraction_CS(uint interaction_id)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqExitInteraction> tOffset = swm.ReqExitInteraction.CreateReqExitInteraction(tFBB, interaction_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqExitInteraction.HashID, tFBB);
        }      
        
        public void RepSwitchInteactionAction_CS(uint interaction_id, uint action_id)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqSwitchInteactionAction> tOffset = swm.ReqSwitchInteactionAction.CreateReqSwitchInteactionAction(tFBB, interaction_id, action_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSwitchInteactionAction.HashID, tFBB);
        }

#endregion
        
        AreaTriggerDraw drawer = null;
        private void ProcDrawArenaTrigger(swm.GmShowTriggerZone msg)
        {
            if (drawer == null)
            {
                GameObject obj = new GameObject();
                drawer = obj.AddComponent<AreaTriggerDraw>();
            }

            drawer.chunks.Clear();
            for (int i = 0; i < msg.zonesLength; i++)
            {
                swm.MapZone? zone = msg.zones(i);
                for (int j = 0; j < zone.Value.chunksLength; j++)
                {
                    swm.MapZoneChunkT chunk = new swm.MapZoneChunkT(zone.Value.chunks(j).Value);
                    drawer.chunks.Add(chunk);
                }
            }
        }
        /// <summary>
        /// 是否资源可采集
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool IsResourceCanGather(Entity entity)
        {
            if (entity == null)
                return false;

            if (!entity.IsGatherResource())
                return false;

            GatherResourceEntity gatherety = entity as GatherResourceEntity;
            if (gatherety == null)
                return false;

            if (gatherety.CanGather())
                return true;

            return false;
        }

        public static bool GetPosScreenPos(UnityEngine.Vector3 _pos, out int x, out int y)
        {
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            if (mainCamera == null)
            {
                x = y = 0;
                return false;
            }

            var spos = mainCamera.WorldToScreenPoint(_pos);
            x = (int)spos.x;
            y = (int)spos.y;

            if (spos.z < 0.0f)
            {
                return false;
            }

            return true;
        }
    }
}
