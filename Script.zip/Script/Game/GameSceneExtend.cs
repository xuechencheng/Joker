using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using Bokura;
using FlatBuffers;
using System.Linq;

namespace Bokura
{
    [XLua.BlackList]
    public enum TempCubeColor
    {
        black,
        blue,
        clear,
        cyan,
        gray,
        green,
        grey,
        magenta,
        red,
        white,
        yellow,
    }

    public partial class GameScene : ClientSingleton<GameScene>
    {

        /// <summary>
        /// 判断仙门内地图切换的时候是否同一张地图的最大距离
        /// </summary>
        private const float IsSeptSameMap_CheckVal = 64.0f;




        //消息的辅助数据
        private ClientGatherData m_NetClientGatherData = null;
        private ClientToRelive m_MainCharRelive = null;
        private ClientListReliveType m_MainCharReliveType = null;
        private MapEntityAttrsDiff m_MapEntityAttrsDiff = null;

        public void RegisterNetWorkMessage()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.IntoMap>(ProcIntoMap);//切换场景
			MsgDispatcher.instance.RegisterFBMsgProc<swm.RspLeaveGame>(ResponseLeaveGame_SC);//离开游戏

			MsgDispatcher.instance.RegisterFBMsgProc<swm.EnterMap>(ProcEnterMap);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.BatchEnterMap>(ProcBatchEnterMap);      
			MsgDispatcher.instance.RegisterFBMsgProc<swm.LeaveMap>(ProcLeaveMap);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.BatchLeaveMap>(ProcBatchLeaveMap);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.BlinkTo>(ProcBlinkTo);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshMainUserAttrs>(ProcRefreshMainUserAttrs);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshMapEntityData>(ProcRefreshMapEntityData);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshEntityHpMp>(ProcRefreshEntityHpMp);
            //MsgDispatcher.instance.RegisterMsgProc<x2m.RefreshEntityFlags>(ProcRefreshEntityFlags);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshPowerValue>(ProcRefreshPowerValue);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.SyncServerTime>(ProcServerTime);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyChangeModel>(ProcNotifyChangeModel);


            MsgDispatcher.instance.RegisterFBMsgProc<swm.ListReliveType>(ProcNotifyDeadMenu);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ToDie>(ProcToDie);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ToRelive>(ProcToRelive);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.StartQuickDodge>(ProcStartQuickDodge);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshEntityEnergy>(ProcRefreshEntityEnergy);


            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshLevelAndExp>(ProcRefreshLevelAndExp);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyEnterChant>(ProcRefreshChantInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyExitChant>(ProcRefreshEndChantInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspGatherResource>(ProcRspGatherResource);



            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyFightState>(ProcNotifyFightState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshEntityAnger>(ProcAngerChange);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.ShowTestPos>(ProcShowTestPos);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ClearShowTestPos>(ProcClearShowTestPos);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ShowEntityTestPos>(ProcShowEntityTestPos);


            MsgDispatcher.instance.RegisterFBMsgProc<swm.TestNetDelay>(ProcTestNetDelay);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.MoveStop>(ProcMoveStop);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.MoveToPos>(ProcMoveToPos);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.MoveToDown>(ProcMoveToDown);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.FallStart>(ProcFallStart);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.FallMove>(ProcFallMove);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyEnterFly>(ProcNotifyEnterFly);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyExitFly>(ProcNotifyExitFly);


			MsgDispatcher.instance.RegisterFBMsgProc<swm.MoveSyncServerPos>(ProcMoveSyncServerPos);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SyncEntityAction>(ProcSyncAction);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshEntityMoveSpeed>(ProcRefreshEntityMoveSpeed);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspQingKung>(ProcRspQingKung);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyQingKungUp>(ProNotifyQingKungUp);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyQingKungTurnDown>(ProNotifyQingKungTurnDown);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyQingKungBlockLand>(ProNotifyQingKungBlockLand);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyQingKungPeak>(ProNotifyQingKungPeak);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshQingKungPep>(ProRefreshQingKungPep);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyQingKungFastLand>(ProNotifyQingKungFastLand);
            //MsgDispatcher.instance.RegisterFBMsgProc<swm.QingKungEnd>(ProcQingKungEnd);

            MsgDispatcher.instance.RegisterFBMsgProc <swm.NotifyGliding>(ProNotifyGliding);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.LookAt>(ProcLookAt);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyPlayAction>(ProcNotifyPlayAction);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshEntityAttackSpeed>(ProcRefreshEntityAttackSpeed);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyPlayEffect>(ProcNotifyPlayEffect);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.UserCatFootNotifyNine>(ProcCareful);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.UserSneak>(ProcSneak);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyParamChange>(ProcNotifyParamChange);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyInteractionAction>(ProcNotifyInteractionAction);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyPlayInteractionOperAction>(ProcNotifyPlayInteractionOperAction);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AiSpeak>(ProAiSpeak);

#if !RELEASE
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshAiNavMeshPath>(ProcRefreshAiNavMeshPath);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshAiValues>(ProcRefreshAiValues);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshNavMeshTile>(ProcRefreshNavMeshTile);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshEnvValues>(ProcRefreshEnvValues);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ShowMeshBegin>(ProcShowMeshBegin);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ShowMesh>(ProcShowMesh);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ShowMeshData>(ProcShowMeshData);

#endif
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshMachineState>(ProcRefreshMachineState);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.CopyEvt>(ProcGameCopyEvent);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyOpenGuide>(ProcOpenGuideEvent);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyOnVehicle>(ProcOnVehicleEvent);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyOffVehicle>(ProcOffVehicleEvent);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyPlayEffects>(ProcNotifyPlayEffects);
            
            MsgDispatcher.instance.RegisterFBMsgProc<swm.GmShowTriggerZone>(ProcDrawArenaTrigger);


            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshResourceState>(ProcRefreshResourceState);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.PrintDebugInfo>(ProcPrintDebugInfo);
            //WeatherManager.Instance.m_OnWeatherTypeChanged.AddListener(ProcWeatherTypeChanged);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyChangeModelId>(ProcNotifyChangeModelId);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyUserOnline>(ProcNotifyUserOnline);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyUserReady>(ProcNotifyUserReady);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCurrLineList>(ProcRspCurrLineList);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyReverseThreat>(ProNotifyReverseThreat);


            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspLeaveStuck>(ProRspLeaveStuck);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyPutOnWeapon>(ProNotifyPutOnWeapon);
            
            

        }


        /// <summary>
        /// 请求返回登录界面
        /// </summary>
        public void RequestLeaveGame_CS()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqLeaveGame.StartReqLeaveGame(fbb);
            fbb.Finish(swm.ReqLeaveGame.EndReqLeaveGame(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqLeaveGame.HashID, fbb);
        }


        /// <summary>
        /// 服务器允许返回登录界面
        /// </summary>
        private void ResponseLeaveGame_SC(swm.RspLeaveGame msg)
        {
            //LogHelper.Log("ResponseLeaveGame_SC(swm.RspLeaveGame msg)");
            onLeaveGame.Invoke();
        }



        /// <summary>
        /// 请求返回角色选择界面
        /// </summary>
        public void RequestBackToRoleList_CS()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqBackToRoleList.StartReqBackToRoleList(fbb);
            fbb.Finish(swm.ReqBackToRoleList.EndReqBackToRoleList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqBackToRoleList.HashID, fbb);
        }

        public void ReqOperateMachine_CS(ulong id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqOperateMachine.StartReqOperateMachine(fbb);
            swm.ReqOperateMachine.AddTarId(fbb, id);
            fbb.Finish(swm.ReqOperateMachine.EndReqOperateMachine(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqOperateMachine.HashID, fbb);
        }


        #region network message

        public bool bIsSameMap = false;


        public bool IsSeptSameMap()
        {
            if (m_mainCharacter == null)
                return false;

            if (!m_currentIntomapInfo.HasValue)
                return false;

            var curpos = m_currentIntomapInfo.Value.pos;
            if (!curpos.HasValue)
                return false;

            Vector3 curposval = new Vector3(curpos.Value.x, curpos.Value.y, curpos.Value.z);
            Vector3 preposval = m_mainCharacter.OldPosition;
            return Vector3.Distance(curposval, preposval) < IsSeptSameMap_CheckVal;
        }

        public uint curLineID = 0;

        void ProcIntoMap(swm.IntoMap msg)
        {
            //LogHelper.Log("swm intomap!", msg.pos.Value.FBVec3Vec3());
            onPreIntoMap.Invoke();
            m_currentIntomapInfo = Utility.CopyFBMsgNotRoot(msg, msg.__p.bb_pos);

            RemoveAllEntity();
            if (MainChar.IsInited)
            {
                bIsSameMap = msg.load_type != swm.LoadType.Normal;
                curLineID = msg.line_id;      

                if (bIsSameMap)
                {
                    AddEntity(MainChar);

                    //MainChar.Actived = false;
                    //相位时玩家可以显示，但禁止移动
                    //MainChar.forbidMove = true;
                    MainChar.CanControl = false;

                    MainChar.ResetInIntoMap();
                    StopDodgeWhenChangeMap();
                }
                else
                {
                    LayeredSceneLoader.ResetInstance();
                    AddEntity(MainChar);
                    //msg.pos.y = 300;
                    //MainChar.IsInited = false;
                    MainChar.Position = Vector3.zero;

                    MainChar.Position = msg.pos.Value.FBVec3Vec3();
                    MainChar.Direction = msg.dir.FBVec3Vec3();
                    //ICameraController.Instance.SetTargetDetlaPos(MainChar.Position);
                    CameraController.Instance.SetCameraPosition(MainChar.LocalPosition);
                    MainChar.Actived = false;
                    MainChar.ResetInIntoMap();
                    StopDodgeWhenChangeMap();
                    MainChar.CanControl = true;
                }

                MainChar.Stop();
                if (MainChar.LastSkillShow != null) {
                    MainChar.LastSkillShow.Stop();
                }

            }

            m_preIntomapInfo = m_currentIntomapInfo;

            onIntoMap.Invoke(m_currentIntomapInfo.Value);

            StrongholdsManager.Instance.ReqStrongHoldPrestige_CS();
            SendReqCurrLineList(false);
        }
        public bool CheckIsMainEntity(ulong _id/*, swm.EntityType _entityType*/)
        {
            if (null != UserDataMgr.Instance.MainUserData)
            {
                if (/*swm.EntityType.Player == _entityType &&*/ UserDataMgr.Instance.MainUserData.Value.entity_id == _id)
                {
                    return true;
                }
            }
            return false;
        }



        /// <summary>
        /// 在跳地图时（大地图传送点间跳转、以及进出副本、竞技场、战场等地图）停止闪避动作，避免闪避目标点离当前位置太远，导致长时间位于闪避状态无法操�?
        /// </summary>
        private void StopDodgeWhenChangeMap()
        {
            if (null == MainChar) return;
            if (MainChar.StateMachine.CurStateID == SM.Entity.States.DODGE)
                MainChar.DodageDestPos = MainChar.Position;
        }



        void ProcBatchEnterMap(swm.BatchEnterMap msg)
		{
			for(int i = 0; i < msg.dataLength; i ++)
			{
				EntityEnterMap(msg.data(i).Value);
			}
		}

        private bool m_bIsOpenServerIdBox = false;
        public bool OpenServerIdBox
        {
            get
            {
                return m_bIsOpenServerIdBox;
            }
            set
            {
                m_bIsOpenServerIdBox = value;
                if(value)
                {
                    NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_SystemNotify, "显示无缝图标" );
                }
                else
                {
                    NotifyModel.Instance.DisplayString(EnumNotifyType.Notify_SystemNotify, "隐藏无缝图标");
                }
                RefreshServeIdWithMainChar();
            }
        }
        private void RefreshServeIdWithMainChar()
        {
            foreach (var kv in m_entitys)
            {
                Entity _data = kv.Value;
                _data.SetIsSameServeIdWithMainChar();
            }
        }

        protected void ProNotifyPutOnWeapon(swm.NotifyPutOnWeapon msg)
        {
            var entity = GetEntityByID(msg.uid) as MovableEntity;
            if (entity != null)
                entity.WeaponId = msg.baseid;
        }

        public Entity ClientEntityEnterMap(swm.MapEntityData data)
        {
            return EntityEnterMap(data);
        }

        Entity EntityEnterMap(swm.MapEntityData data)
		{
            if(MainChar == null)
            {
                //如果连主角都没有 就不处理其他实体进入地图的消息 
                //LogHelper.LogError("MainChar is null,server send EntityEnterMap:");
                return null;
            }

            var entity_type = GameScene.GetEntityTypeById(data.entity_id);
            Entity entity = GetEntityByID( data.entity_id);
			if (entity != null)
			{
                entity.SetNetData(data);
                Vector3 vc = data.cur_pos.Value.FBVec3Vec3();
                Vector3 oldPos = entity.Position;
                float len = (vc - oldPos).sqrMagnitude;

                if (len > 1)//刷新数据  如果范围在1以内 纠正服务端的误差 要不然模型会抖动一下  以客户端的坐标为准
                {
                    entity.Position = vc;
                }
                if (entity.IsMainCharacter() && !MainChar.Actived)
				{
					MainChar.LoadModel();
					MainChar.Actived = true;
				}
                if (entity.IsMainCharacter())
                {
                    RefreshServeIdWithMainChar();
                }

                CarryStageManager.Instance.OnEntityEnterRegion(entity, data);

                return entity;
			}

			if (entity_type == swm.EntityType.Npc)
			{
				var npcConfig = NpcTableManager.GetData((int)(data.npc_data.Value.baseid));
				if (npcConfig != null)
				{

                    entity = new Npc(data.entity_id);
                        
                    if (AltarManager.Instance != null)
                    {
                        AltarManager.Instance.CheckEffectInAltar(data.entity_id, data.npc_data.Value.baseid, data.cur_pos.Value.FBVec3Vec3());
                    }
                }
				else
				{
                    LogHelper.LogError("npc baseid not exist:", data.npc_data.Value.baseid.ToString());
                    return null;
				}


			}
            else if(entity_type == swm.EntityType.ClientNpc)
            {
                entity = new ClientNpc(data.entity_id);
                //entity = m_ClientNpcPool.Get();
                //entity.InitEntity(data.entity_id);
            }
			else if (entity_type == swm.EntityType.Player)
			{
                if (CheckIsMainEntity(data.entity_id))
                    entity = MainChar;
                else
                {
                    entity = new Character(data.entity_id);
                    //entity = m_CharacterPool.Get();
                    //entity.InitEntity(data.entity_id);
                }
            }
			else if (entity_type == swm.EntityType.Trap)
			{
                //陷阱
                entity = new TrapEntiy(data.entity_id);
                //entity = m_TrapPool.Get();
                //entity.InitEntity(data.entity_id);

                //LogHelper.Log(LogCategory.GameLogic, Utilities.BuildString("-------------pos", msg.data.cur_pos.ToString()));
               // LogHelper.Log("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "---" + msg.data.cur_pos.x + "---" + msg.data.cur_pos.y + "---" + msg.data.cur_pos.z);

			}
            else if(entity_type == swm.EntityType.Resource)
            {
                entity = new GatherResourceEntity(data.entity_id);
                //entity = m_GatherResPool.Get();
                //entity.InitEntity(data.entity_id);
            }
            else if(entity_type == swm.EntityType.Machine)
            {
                entity = new MechanismEntity(data.entity_id);

                IMechanismMgr.Instance.RefreshState(data.machine_data.Value.baseid, data.machine_data.Value.state, false);
            }
			else
			{
                LogHelper.LogError("!!!unknown type!", entity_type.ToString());
                return null;
			}

            CarryStageManager.Instance.TestIsAboutCarry(entity, data);

			InitEntityByEntityData(entity, data);

            if (entity_type == swm.EntityType.Npc || entity_type == swm.EntityType.Player)
                CarryStageManager.Instance.OnEntityEnterRegion(entity, data);

            if (MainChar && MainChar.Actived && MainChar.CurrentCloseEntityId ==0 && (entity_type == swm.EntityType.Resource || entity_type == swm.EntityType.Npc))
            {
                MainChar.CheckIsCloseEntity(true);
            }

            return entity;
		}

        void ProcEnterMap(swm.EnterMap msg)
		{
			EntityEnterMap(msg.data.Value);
        }

        private void InitMainEntityByEntityData(MainCharacter _entity, swm.SyncMainUserData _data)
        {
            if (null != _entity)
            {
                //                 if (_entity == MainChar && !MainChar.IsInited)
                //                 {
                //                     MainChar.Position = Vector3.zero;
                //                 }
                _entity.init();
                _entity.SetNetData(_data);

                bool bIsMainCharFirstAdd = false;
                if (_entity == MainChar && (!MainChar.IsInited || !MainChar.MainCharNetDataSetted))
                {
                    bIsMainCharFirstAdd = true;
                }

                MainChar.MainCharNetDataSetted = true;

                if (_entity == MainChar)
                {
                    if (!m_entitys.ContainsKey(_entity.ThisID))
                    {
                        AddEntity(_entity);
                    }
                }
                else
                {
                    AddEntity(_entity);
                }

                _entity.Actived = IsTerrainLoaded(_entity.Position);

                if (bIsMainCharFirstAdd)
                {
                    //LogHelper.LogError("onMainCharAdd");
                    onMainCharAdd.Invoke();
                    onMainCharInitNetData.Invoke();
                }
            }
        }
        private void InitEntityByEntityData(Entity _entity, swm.MapEntityData _data)
        {
            if (null != _entity )
            {
                //                 if (_entity == MainChar && !MainChar.IsInited)
                //                 {
                //                     MainChar.Position = Vector3.zero;
                //                 }
                _entity.init();
                _entity.SetNetData(_data);

                bool bIsMainCharFirstAdd = false;
                if(_entity == MainChar && !MainChar.IsInited)
                {
                    bIsMainCharFirstAdd = true;
                }
                

                if (_entity == MainChar)
                {
                    if (!m_entitys.ContainsKey(_entity.ThisID))
                    {
                        AddEntity(_entity);
                    }
                }
                else
                {
                    AddEntity(_entity);
                }
                
                _entity.Actived = IsTerrainLoaded(_entity.Position);
               
                if (bIsMainCharFirstAdd)
                {
                    //LogHelper.LogError("onMainCharAdd");
                    onMainCharAdd.Invoke();
                    onMainCharInitNetData.Invoke();
                }
            }
        }

        void ProcLeaveMap(swm.LeaveMap msg)
		{
			Entity entity = GetEntityByID(msg.entity_id);

			if(entity!=null)
			{
				RemoveEntity(entity);
			}
			else
			{
                LogHelper.LogWarning("remove entity error, cant find entity id:", msg.entity_id.ToString());
            }
		}

		void ProcBatchLeaveMap(swm.BatchLeaveMap msg)
		{
            for(int i = 0; i < msg.dataLength; i ++ )
            {
                ProcLeaveMap(msg.data(i).Value);
            }
		}

        //npc 移动
        void ProcMoveToPos(swm.MoveToPos _msg)
        {
            var ety = GetEntityByID(_msg.entity_id) as Npc;

            //如果npc 被搬运中 不更新位置
            if (ety == null || ety.StateMachine == null|| ety.CarryBackTrigger == true || ety.b_isBeAttachTo)
                return;

            //LogHelper.Log("1111111111111111111111111111111111111111111111111111111111111111111111   ",
            //    _msg.cur_pos.FBVec3Vec3(), "   ", _msg.to_pos.FBVec3Vec3());

            //LogHelper.Log("msg......" + _msg.to_pos.ToString());

            ety.DestPos = _msg.to_pos.FBVec3Vec3();

            ety.Syncer.PushMoveData(0,_msg.cur_pos.FBVec3Vec3(),_msg.to_pos.FBVec3Vec3(),Utilities.Vector2Angle(_msg.dir.Value.z, _msg.dir.Value.x), GetServerTime());

            //if (!(ety.CarryTrigger && ety.m_isbeCarry == true))
            //{
            //    ety.Direction = _msg.dir.Value.FBVec3Vec3();
            //}

            // 没有交互行为
            ety.ResetInteractionPoint();

            ety.MoveType = (swm.AiStatusType)_msg.ai_status;
            if(ShowAiTest &&( ety.MoveType == swm.AiStatusType.Idle || ety.MoveType == swm.AiStatusType.Back))
            {
                ety.ShowVisionColor(swm.PlayEffectType.None);
            }

            //LogHelper.LogFormat(LogCategory.AI, "ProcMoveToPos npcid={0} topos ={1} frompos={2} nowpos={3}",  _msg.entity_id, _msg.to_pos.FBVec3Vec3(), _msg.cur_pos.FBVec3Vec3(), ety.Position);
        }


        //npc 停止移动
        void ProcMoveStop(swm.MoveStop _msg)
        {
            var ety = GetEntityByID(_msg.entity_id) as MovableEntity;
            if (ety == null)
            {
                LogHelper.LogWarning("cant found entity", _msg.entity_id.ToString());
                return;
            }
            if (ety.IsMainCharacter())
            {
                return;
            }
            //var pos = _msg.cur_pos.Value.FBVec3Vec3();
            //ety.SyncNetMove(pos, pos);
            ety.Direction = _msg.dir.Value.FBVec3Vec3();
            ety.LogicPostition = _msg.cur_pos.FBVec3Vec3();
            //ety.Syncer.PushMoveData(ety.Position, pos, Utilities.Vector2Angle(_msg.dir.Value.z, _msg.dir.Value.x));
            ety.Syncer.StopSyncMove();
            ety.Stop();
            
        }

        //角色移动
        void ProcMoveToDown(swm.MoveToDown msg)
        {
            
            var ety = GetEntityByID(  msg.entity_id) as MovableEntity;
            if (ety == null || ety.StateMachine == null)
                return;
            if (ety.IsMainCharacter() )
            {
                //if (!MainChar.IsQingKung())
                //     MainChar.Joystick.ServerMoveTo(msg);
                return;
            }

            if (msg.vox_world_id != ety.VoxelWorldID)
                return;
            if (msg.to_pos.Value.x == 0.0f || msg.to_pos.Value.y == 0.0f)
                return;
            if (ety.StateMachine.CurStateID == SM.Entity.States.STUN)
                return;
            if (msg.action == (sbyte)swm.MoveActionType.Jump && ety.IsCharacter())
            {
                var character = ety as Character;
                if(character.Mount )
                {
                    if(character.Mount.IsLandMount || character.Mount.IsLandMode)
                    {
                        character.Mount.StateMachine.ChangeState(SM.Entity.States.JUMP);
                    }
                }
                else
                {
                    if(character.JumpStatus == Character.JumpState.Jumping1)
                        character.StateMachine.ChangeState(SM.Entity.States.JUMP2);
                    else
                        character.StateMachine.ChangeState(SM.Entity.States.JUMP);
                }
            }
            LogHelper.Log("msg....." + msg.to_pos.ToString());
            ety.Syncer.PushMoveData(0, msg.client_pos.FBVec3Vec3(), msg.to_pos.FBVec3Vec3(), Utilities.Vector2Angle(msg.dir.Value.z, msg.dir.Value.x), msg.client_time );
        }

        void ProcFallMove(swm.FallMove msg)
        {
            var ety = GameScene.Instance.GetEntityByID(msg.entity_id) as MovableEntity;
            if (ety != null && ety.IsMainCharacter())
            {
                //LogHelper.Log("swm.FallMove!", msg.end_pos.Value.FBVec3Vec3().ToString());
                //MainChar.Joystick.ServerFallMove(msg);
            }
        }
        void ProcFallStart(swm.FallStart msg) 
        {
            var ety = GameScene.Instance.GetEntityByID(msg.entity_id) as MovableEntity;
            if (ety != null && ety.IsMainCharacter())
            {
                //LogHelper.Log("swm.FallStart!", msg.end_pos.Value.FBVec3Vec3().ToString());

                //MainChar.Joystick.ServerFallStart(msg);
            }
        }

        void ProcNotifyEnterFly(swm.NotifyEnterFly msg)
        {
            var ety = GameScene.Instance.GetEntityByID(msg.entity_id) as MovableEntity;
            if (ety != null)
            {
                ety.isEnterFly = true;
            }
        }

        void ProcNotifyExitFly(swm.NotifyExitFly msg)
        {
            var ety = GameScene.Instance.GetEntityByID(msg.entity_id) as MovableEntity;
            if (ety != null)
            {
                ety.isEnterFly = false;
            }
        }

#if UNITY_EDITOR
        public delegate int ExtraTerrainLoadTester(Vector3 position); //< 1=true, 0=false, -1=unknown
        public static ExtraTerrainLoadTester extraTerrainLoadTester;
#endif
        /// Test if terrain under a point has been loaded into scene
        /// <param name="position">The point to test</param>
        bool IsTerrainLoaded(Vector3 position)
        {
            if (LayeredSceneLoader.IsActive)
                return LayeredSceneLoader.IsTerrainLoaded(position);
#if UNITY_EDITOR
            foreach (ExtraTerrainLoadTester t in extraTerrainLoadTester.GetInvocationList())
            {
                switch(t.Invoke(position))
                {
                    case 0: return false;
                    case 1: return true;
                }
            }
#endif
            return true;
        }

#if !RELEASE   //调试用的
        void ProcRefreshAiValues(swm.RefreshAiValues msg)
        {
            var ety = GetEntityByID(msg.entity_id) as Npc;
            if (ety == null)
                return;

            ety.SetAIValue(msg);
        }

        void ProcRefreshEnvValues(swm.RefreshEnvValues msg)
        {
            //var ety = GetEntityByID(msg.entity_id) as Character;
            //if (!ety.IsMainCharacter())
            //   return;
            if (msg.valuesLength == msg.value_idLength && OnAiEnvParamChanged != null)
            {
                for(int i = 0;i <msg.value_idLength;i++)
                    OnAiEnvParamChanged.Invoke(msg.value_id(i), msg.values(i));
            }
        }

        void ProcRefreshAiNavMeshPath(swm.RefreshAiNavMeshPath msg)
        {
            var nav = GameObject.FindObjectOfType<VoxPathNavMesh>();
            if (nav == null) nav = new GameObject("__VoxPathNavMesh__").AddComponent<VoxPathNavMesh>();
            if (nav != null)
            {
                var list = new List<Vector3>(msg.pathLength);
                for(int i=0;i<msg.pathLength;i++)
                {
                    list.Add(msg.path(i).Value.FBVec3Vec3());
                }
                nav.PushPath(msg.entity_id, list);
            }
        }


        void ProcRefreshNavMeshTile(swm.RefreshNavMeshTile msg)
        {
            var navmesh = GameObject.FindObjectOfType<VoxNavMesh>();
            if (navmesh != null)
            {
                DetourNav.DetourMeshTile tile = new DetourNav.DetourMeshTile();

                //header
                tile.header = new DetourNav.DetourMeshHeader();
                tile.header.x = msg.header.Value.x;
                tile.header.y = msg.header.Value.y;
                tile.header.polyCount = msg.header.Value.polyCount;
                
                //poly
                tile.polys = new DetourNav.DetourPoly[msg.header.Value.polyCount];
                for(int i = 0;i<tile.polys.Length;i++)
                {
                    var poly = new DetourNav.DetourPoly();
                    tile.polys[i] = poly;
                    poly.vertCount = (byte)msg.polys(i).Value.vertCount;
                    poly.verts = new ushort[msg.polys(i).Value.vertsLength];
                    for (int j = 0; j < poly.verts.Length; j++)
                    {
                        poly.verts[j] = msg.polys(i).Value.verts(j);
                    }
                }

                //verts
                tile.verts = new float[msg.vertsLength];
                for (int i = 0; i < tile.verts.Length; i++)
                {
                    tile.verts[i] = msg.verts(i);
                }
                //detailMeshes
                tile.detailMeshes = new DetourNav.DetourPolyDetail[msg.detailMeshesLength];
                for (int i = 0; i < tile.detailMeshes.Length; i++)
                {
                    var Poly = new DetourNav.DetourPolyDetail();
                    tile.detailMeshes[i] = Poly;
                    Poly.triBase = (byte)msg.detailMeshes(i).Value.triBase;
                    Poly.triCount = (byte)msg.detailMeshes(i).Value.triCount;
                    Poly.vertBase = (byte)msg.detailMeshes(i).Value.vertBase;
                }
                //detailVerts
                tile.detailVerts = new float[msg.detailVertsLength];
                for (int i = 0; i < tile.detailVerts.Length; i++)
                {
                    tile.detailVerts[i] = msg.detailVerts(i);
                }
                //detailTris
                tile.detailTris = new byte[msg.detailTrisLength];
                for (int i = 0; i < tile.detailTris.Length; i++)
                {
                    tile.detailTris[i] = (byte)msg.detailTris(i);
                }

                navmesh.RefreshTile(tile);
            }
        }
#endif
        [XLua.BlackList]
        public GameEvent OnBlinkFinishEvent = new GameEvent();

        void ProcBlinkTo(swm.BlinkTo msg)
        {
            var ety = GetEntityByID( msg.entity_id) as MovableEntity;
            if (ety == null)
                return;

            if (ety.IsMainCharacter())
            {
                onBlinkToMap.Invoke();
                curLineID = msg.selectline;
                SendReqCurrLineList(false);
            }

            if (msg.to_pos.Value.x == 0.0f && msg.to_pos.Value.z == 0.0f && msg.to_pos.Value.y == 0.0f)
                return;

            ety.VoxelWorldID = msg.vox_world_id;

            if (msg.type == swm.BlinkType.UNKNOWN)
            {
                m_bIsNotShowLoading = true;
                //直接瞬移;

                if (ety.IsMainCharacter() && ety.StateMachine.CurStateID == SM.Entity.States.StateExitClouding)
                {
                    ety.Position = msg.to_pos.FBVec3Vec3() + new Vector3(0, 20f, 0);
                }
                else
                {
                    ety.Position = msg.to_pos.FBVec3Vec3() + new Vector3(0, 0.5f, 0);
                }
                ety.Direction = msg.to_dir.FBVec3Vec3();
                ety.Stop();
                //ety.FlyStun();
                if (ety.IsMainCharacter())
                {
                    var mainchar = ety as MainCharacter;

                    if (mainchar != null)
                    {
                        mainchar.ResetInIntoMap();
                    }

                    //StopDodgeWhenChangeMap();
                    if (mainchar.Mount != null && mainchar.Mount.Avatar.unityObject != null)
                        CameraController.Instance.SetTarget(mainchar.Mount.Avatar.unityObject.transform);
                    else if (ety.Avatar != null && ety.Avatar.unityObject)
                        CameraController.Instance.SetTarget(ety.Avatar.unityObject.transform);
                    if (!IsTerrainLoaded(ety.Position))
                    {
                        //ety.Actived = false;
                        m_sceneLoaded = false;
                        m_bIsBlink = true;
                        LayeredSceneLoader.ResetCallback(ety.Position);
                        LayeredSceneLoader.SetIsInitialLoading(true);
                        BeginLoading();
                        LoadingGotoScene();
                    }
                    else
                    {
                        onJumpMapFinishEvent();
                    }
                }
            }
            else if (msg.type == swm.BlinkType.GOTO)
            {
                //直接瞬移
                ety.Position = msg.to_pos.FBVec3Vec3() + new Vector3(0,0.5f,0);
                ety.Direction = msg.to_dir.FBVec3Vec3();
                ety.Stop();
                ety.FlyStun();
                
                OnBlinkFinishEvent.Invoke();

                //LogHelper.LogError("ety.Position-------------------------------->:"+ ety.Position);
                if (ety.IsMainCharacter())
                {
                    var mainchar = ety as MainCharacter;

                    if (mainchar != null)
                    {
                        mainchar.ResetInIntoMap();
                    }

                    StopDodgeWhenChangeMap();
                    if (mainchar.Mount != null && mainchar.Mount.Avatar.unityObject != null)
                        CameraController.Instance.SetTarget(mainchar.Mount.Avatar.unityObject.transform);
                    else if (ety.Avatar != null && ety.Avatar.unityObject)
                        CameraController.Instance.SetTarget(ety.Avatar.unityObject.transform);
                    ety.Avatar.ReleaseMagicTrackBuilder();

                    if (!IsTerrainLoaded(ety.Position))
                    {
                        //LogHelper.Log("ProcBlinkTo(swm.BlinkTo msg)>>>>>>>>>>>>>");
                        ety.Actived = false;
                        m_sceneLoaded = false;
                        m_bIsBlink = true;
                        LayeredSceneLoader.ResetCallback(ety.Position);
                        LayeredSceneLoader.SetIsInitialLoading(true);
                        BeginLoading();
                        LoadingGotoScene();
                    }
                    else //这里不加的话 近距离直接传送 会卡住界面 loading不开始 也不结束 黑屏等待
                    {
                        onJumpMapFinishEvent();
                    }

                }
                else if (ety.Syncer != null)
                {
                    ety.Syncer.PushMoveData(0, ety.Position, ety.Position, ety.DirAngle, GetServerTime());
                }
            }
            else if (msg.type == swm.BlinkType.ONRUSH)
            {
                LogHelper.LogWarning( "blink to have been obsolete.");
            }
            else if (msg.type == swm.BlinkType.BEATFLOWN || msg.type == swm.BlinkType.BEATBACK)
            {
                if (ety.IsNpc())
                {
                    //var npc = ety as Npc;
                    GameApplication.Instance.GetTimerManager().AddTimer(() =>
                    {
                        ety.Syncer.PushMoveData(0, ety.Position, msg.to_pos.FBVec3Vec3(), ety.DirAngle, GetServerTime());

                    }, 1.0f);
                }
            }
        }

        void ProcNotifyInteractionAction(swm.NotifyInteractionAction msg)
        {
            var entity = GetEntityByID(msg.entity_id) as MovableEntity;
            if (!entity)
                return;

            // 当前退出交互点, 角色不在交互点状态, 不处理
            if (msg.interaction_id == 0)
            {
                if (entity.StateMachine.CurStateID != SM.Entity.States.ACTION)
                    return;
            }

            // 播放动作
            bool enter = (msg.interaction_id != 0);
            uint oldid = entity.interaction_id;
            uint oldactionid = entity.interaction_action;
            
            entity.interaction_id = msg.interaction_id;
            entity.interaction_action = msg.action_id;
            entity.CommonType = MovableEntity.ActionType.Interaction;
            entity.CommonTrunPos = Vector3.zero;
            entity.interaction_pos = msg.pos.FBVec3Vec3();
            entity.interaction_dir = msg.dir.FBVec3Vec3();

            //LogHelper.LogWarning($"ProcNotifyInteractionAction {entity.IsNpc()} {entity.ThisID} {msg.interaction_id} {msg.action_id} {entity.interaction_pos} {entity.interaction_dir}");
            if (enter)
            {
                entity.CommonActionId = msg.action_id;

                entity.interactionInfo.interaction_id = msg.interaction_id;
                entity.interactionInfo.action_id = msg.action_id;

                if (entity.interactionState == MovableEntity.InteractionState.Exit || 
                    entity.interactionState == MovableEntity.InteractionState.None)
                {
                    entity.interactionState = MovableEntity.InteractionState.EnterIdle;
                }
                else if (entity.interactionState == MovableEntity.InteractionState.EnterIdle)
                {
                    entity.interactionState = MovableEntity.InteractionState.Idle;
                }
            }
            else
            {
                entity.CommonActionId = oldactionid;

                entity.interactionInfo.interaction_id = oldid;
                entity.interactionInfo.action_id = msg.action_id;
                entity.interactionState = MovableEntity.InteractionState.Exit;
            }

            if (!entity.isCloudTransmitting())
            {
                entity.StateMachine?.Resume(SM.Entity.States.ACTION);
            }

            // 处理其他角色的交互行为对主角的影响
            if (!entity.IsMainCharacter() && entity.IsCharacter())
            {
                ProcCharacterInteraction(entity, entity.interactionInfo.interaction_id);
            }
        }

        void ProcNotifyPlayAction(swm.NotifyPlayAction msg)
        {
            var entity = GetEntityByID(msg.entity_id) as MovableEntity;
            if (!entity)
                return;

            entity.CommonType = MovableEntity.ActionType.Common;           
            entity.CommonActionId = msg.actionid;
            entity.CommonTrunPos = msg.pos.HasValue ? msg.pos.Value.FBVec3Vec3() : Vector3.zero;
            entity.CommonTrunDir = msg.dir.HasValue ? msg.dir.Value.FBVec3Vec3() : Vector3.zero;

            if (!entity.isCloudTransmitting() )
            {
                entity.StateMachine.Resume(SM.Entity.States.ACTION);
            } 
        }
        void ProcNotifyPlayInteractionOperAction(swm.NotifyPlayInteractionOperAction msg)
        {
            var entity = GetEntityByID(msg.entity_id) as MovableEntity;
            if (entity == null) 
                return;

            entity.interaction_id = msg.interaction_id;
            entity.interaction_action = msg.action_id;
            entity.interaction_serve_target_id = msg.be_entity_id;
            entity.CommonType = MovableEntity.ActionType.Interaction;
            entity.interaction_pos = msg.pos.HasValue ? msg.pos.Value.FBVec3Vec3() : Vector3.zero;
            entity.interaction_dir = msg.dir.HasValue ? msg.dir.Value.FBVec3Vec3() : Vector3.zero;

            entity.interactionState = MovableEntity.InteractionState.EnterIdle;
            entity.StateMachine.Resume(SM.Entity.States.ACTION);

            //var interactionpoint =  InteractionPointManager.Instance.GetInterationActionTypeFromID((int)msg.interaction_id);
        }

        void ProAiSpeak(swm.AiSpeak msg)
        {
            var entity = GetEntityByID(msg.entity_id) as Npc;
            if (entity == null)
                return;
            entity.SpeakTalkByTable((int)msg.speak_id);
        }
        void ProcRefreshMainUserAttrs(swm.RefreshMainUserAttrs msg)
        {
            if (m_mainCharacter != null)
            {
                if (msg.is_show_attrs_diff)
                {
                    if (null == m_MapEntityAttrsDiff)
                    {
                        m_MapEntityAttrsDiff = new MapEntityAttrsDiff();
                    }
                    m_MapEntityAttrsDiff.Init(msg.attrs.Value, m_mainCharacter.Attrs);

                    onAttrChange.Invoke(m_MapEntityAttrsDiff);
                }
                m_mainCharacter.Attrs.FromMsg(msg.attrs.Value);
                onRefreshMapEntityAttr.Invoke(m_mainCharacter);
            }
        }
        
        void ProcRefreshMapEntityData(swm.RefreshMapEntityData msg)
        {
            var ety = GetEntityByID(msg.data.Value.entity_id) as MovableEntity;
            if (ety == null)
                return;
            //if (ety == m_mainCharacter)
            //    return;

            ety.SetNetData( msg.data.Value);
            onRefreshMapEntityData.Invoke(ety);

        }
        void ProcRefreshEntityHpMp(swm.RefreshEntityHpMp msg)
        {
            var ety = GetEntityByID(msg.entity_id) as MovableEntity;
            if (ety == null)
                return;
			//if (ety == m_mainCharacter)
			//    return;
			//ety.CurHP = msg.cur_hp;  //当前生命
			//ety.MaxHP = msg.max_hp;  //生命上限
			//ety.CurMP = msg.cur_mp;  //当前法力
			//ety.MaxMP = msg.max_mp;  //法力上限
			ety.SetHpMp(msg.cur_hp, msg.max_hp, msg.cur_mp, msg.max_mp);
			onRefreshEntityHpMp.Invoke(ety);

            if (ety.IsCharacter())
            {
                AutoEatMedicine();
            }
        }

        void AutoEatMedicine()
        {
            //自动吃药
            if (MainChar != null &&
                MainChar.Data != null)
            {
                if (MainChar.IsInAttack)
                {
                    if (SysSettingModel.Instance.sharedData.iAutoMedicine)
                    {
                        float percent = MainChar.Data.cur_hp * 100f / MainChar.Data.max_hp;
                        if (percent <= SysSettingModel.Instance.sharedData.AutoMedicineTriggerPercent)
                        {
                            ItemBase item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoMedicineItem1);
                            if (item == null) item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoMedicineItem2);
                            if (item == null) item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoMedicineItem3);
                            if (item == null) item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoMedicineItem4);

                            if (item != null && item.ItemNum > 0)
                            {
                                BagManager.Instance.ReqUseItem_CS(item.ID, Vector3.zero, Vector3.zero, 0);
                            }
                        }
                    }
                }
                else
                {
                    if (SysSettingModel.Instance.sharedData.iAutoFood)
                    {
                        float percent = MainChar.Data.cur_hp * 100f / MainChar.Data.max_hp;
                        if (percent <= SysSettingModel.Instance.sharedData.AutoFoodTriggerPercent)
                        {
                            ItemBase item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoFoodItem1);
                            if (item == null) item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoFoodItem2);
                            if (item == null) item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoFoodItem3);
                            if (item == null) item = BagManager.Instance.GetItemByBaseID(swm.BagType.ItemBag, SysSettingModel.Instance.sharedData.AutoFoodItem4);

                            if (item != null && item.ItemNum > 0)
                            {
                                BagManager.Instance.ReqUseItem_CS(item.ID, Vector3.zero, Vector3.zero, 0);
                            }
                        }
                    }
                }
            }
        }
        //void ProcRefreshEntityFlags(swm.RefreshEntityFlags msg)
        //{
        //    var ety = GetEntityByID(msg.entity_id) as MovableEntity;
        //    if (ety == null)
        //        return;
        //    //if (ety == m_mainCharacter)
        //    //{
        //    //    LogHelper.Log("m_mainCharacter-----------");               
        //    //}            
        //    // ety.FlagsState = msg.flags;
        //    onRefreshEntityFlags.Invoke(ety);
        //}

        

        void ProcRefreshPowerValue(swm.RefreshPowerValue _msg)
        {
            if(null != m_mainCharacter)
            {
                maincharFightPower = 0;
                int diff = (int)(_msg.value - m_mainCharacter.FightPower);
                if (m_mainCharacter.FightPower != 0 && diff != 0)
                    onFightPowerChange.Invoke((int)_msg.value, diff);
                m_mainCharacter.SetFightPower(_msg.value);
                onRefreshEntityFightPower.Invoke(m_mainCharacter);
            }
            else
            {
                maincharFightPower = _msg.value;
            }
        }

		void ProcSyncAction(swm.SyncEntityAction msg)
		{
			var ety = GetEntityByID(msg.entity_id);
			if (ety == null)
				return;
			if (ety.IsMainCharacter())
				return;
			if (ety.Syncer != null)
				ety.Syncer.PushState((SM.Entity.States)msg.state,(int)msg.action);
            //LogHelper.LogWarningFormat("sync state {0} to {1} {2}", msg.entity_type, (SM.Entity.States)msg.state, msg.action);

        }
        void ProcMoveSyncServerPos(swm.MoveSyncServerPos msg)
        {
            var ety = GetEntityByID(msg.entity_id);
            if (ety == null)
                return;

            ety.Position = msg.pos.FBVec3Vec3();
            //ety.DirAngle = msg.move_data 
        }


        void ProcServerTime(swm.SyncServerTime msg)
        {
            m_serverRecordTime = msg.time;
            m_currentGameTime = Time.realtimeSinceStartup;
        }
        
		void ProcNotifyChangeModel(swm.NotifyChangeModel msg)
		{
			var ety = GetEntityByID(msg.entity_id);
			if (ety == null)
				return;
			ety.LoadModel(msg.model_name);
		}

        /// <summary>
        /// 接收 复活
        /// </summary>
        /// <param name="msg"></param>
        void ProcToRelive(swm.ToRelive msg)
        {
            //LogHelper.LogError(">>>>>>>>>>>>>>>>void ProcToRelive(swm.ToRelive msg)<<<<<<<<<<<<<<<<<<<<");
            var ety = GetEntityByID(msg.entity_id);
            if (ety == null)
                return;
            ety.Died = false;
            if (ety.IsMainCharacter())
            {
                if(null == m_MainCharRelive)
                {
                    m_MainCharRelive = new ClientToRelive();
                }
                m_MainCharRelive.entity_id = msg.entity_id;
                //m_MainCharRelive.entity_type = msg.entity_type;
                onNotifyToRelive.Invoke(m_MainCharRelive);
            }
                
        }

        void ProcRefreshEntityEnergy(swm.RefreshEntityEnergy _msg)
        {
            var ety = GetEntityByID(_msg.entity_id) as Character;
            if (ety == null)
                return;
            ety.SetDodgeEnegy(_msg.cur_energy, _msg.max_energy);

        }
        /// <summary>
        /// 闪避动作
        /// </summary>
        /// <param name="_msg"></param>
        void ProcStartQuickDodge(swm.StartQuickDodge _msg)
        {
            var ety = GetEntityByID(  _msg.entity_id) as Character;
            if (ety == null || ety.StateMachine == null)
                return;
            ety.DodgeTrigger = true;
            ety.DodgeDestPosVoxWorldID = _msg.vox_world_id;
            ety.DodageDestPos = _msg.end_pos.FBVec3Vec3();
            ety.StateMachine.ChangeState(SM.Entity.States.DODGE);
            if (ety.IsMainCharacter())   ety.Syncer.StopSyncMove();
            if (GameApplication.ShowTestCube)
                GetTempCube(112311, ety.DodageDestPos, Color.yellow);
        }
        /// <summary>
        /// 接收 自己死亡处理
        /// </summary>
        /// <param name="msg"></param>
        void ProcNotifyDeadMenu(swm.ListReliveType msg)
        {
            if (null == m_MainCharReliveType)
            {
                m_MainCharReliveType = new ClientListReliveType();
            }
            // m_MainCharReliveType.relive_type = msg.relive_type;
            m_MainCharReliveType.relive_type.Clear();
           for(int i=0;i< msg.relive_typeLength; i++)
            {
                m_MainCharReliveType.relive_type.Add(msg.relive_type(i));
            }

            m_MainCharReliveType.relive_time = msg.relive_time;
            m_MainCharReliveType.cur_times = msg.cur_times;
            m_MainCharReliveType.max_times = msg.max_times;
            m_MainCharReliveType.auto_time = msg.auto_time;
			m_MainCharReliveType.battle_time = msg.battle_time;
            m_MainCharReliveType.murder_id = msg.murder_id;
            m_MainCharReliveType.murder_type = GetEntityTypeById(msg.murder_id);
            onNotifyDeadMenu.Invoke(m_MainCharReliveType);
        }
        /// <summary>
        /// 接收 死亡（所有entity的死亡）
        /// </summary>
        void ProcToDie(swm.ToDie msg)
        {
            var ety = GetEntityByID( msg.entity_id);
            if (ety == null)
                return;

            if (!ety.HideDiedAnim)
            {
                ety.Died = true;
            }

            onToDieEvent.Invoke(msg.entity_id);
        }

        public bool CheckReliveType( swm.ReliveType _compareTye)
        {
            for(int i = 0;i< m_MainCharReliveType.relive_type.Count;i++)
            {
                if (_compareTye == m_MainCharReliveType.relive_type[i])
                {
                    return true;
                }
            }

            return false;
            //return (_compareTye & (swm.ReliveType)_sourceReliveType) == _compareTye;
        }

        void ProcRefreshLevelAndExp(swm.RefreshLevelAndExp msg)
		{
            Character ety;
            if (CheckIsMainEntity(msg.entity_id))
            {
                ety = MainChar;
            }
            else
            {
                ety = GetEntityByID(msg.entity_id) as Character;
            }
            if (ety == null)
				return;

			ety.Level = (int)msg.cur_level;
			ety.Exp = (long)msg.cur_exp;
            onRefreshLevelAndExp.Invoke(ety);

        }

        [XLua.BlackList]
        public GameEvent<ulong> OnSendReqGatherResource = new GameEvent<ulong>();
        /// <summary>
        /// 发送请求采集资源
        /// </summary>
        /// <param name="_id"></param>
        public void SendReqGatherResource(ulong _id)
        {
            Entity ety = GetEntityByID(_id);
            if(null != ety)
            {
//                 Entity targetEntity = GetEntityByID(tData.tar_uid);//暂时先不处理转向  服务端说先等等
//                 if (null != targetEntity)
//                 {
//                     ety.DirectTo(targetEntity.Position);
//                 }

                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqGatherResource.StartReqGatherResource(fbb);
                swm.ReqGatherResource.AddTarUid(fbb, _id);
                swm.ReqGatherResource.AddTarPos(fbb, swm.Vector3.CreateVector3(fbb, ety.Position.x, ety.Position.y, ety.Position.z));
                var msg = swm.ReqGatherResource.EndReqGatherResource(fbb);
                fbb.Finish(msg.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqGatherResource.HashID, fbb);

                OnSendReqGatherResource.Invoke(_id);
            }
        }

        /// <summary>
        /// 开始吟唱、处理读条消息
        /// </summary>
        void ProcRefreshChantInfo(swm.NotifyEnterChant msg)
        {
            //LogHelper.LogError("ProcRefreshChantInfo");
            Character ety = GetEntityByID(msg.entity_id) as Character;
            if(null != ety)
            {
                uint tChantID = msg.chant_id;
                if (ety.IsMainCharacter())
                {
                    ChantTableBase? tConfig = ChantTableManager.GetData((int)tChantID);

                    if (null == m_NetClientGatherData)
                    {
                        m_NetClientGatherData = new ClientGatherData();
                    }

                    m_NetClientGatherData.m_src_uid = msg.entity_id;
                    m_NetClientGatherData.m_start_time = msg.start_time;
                    m_NetClientGatherData.m_end_time = msg.end_time;

                    if (tConfig.HasValue)
                    {
                        m_NetClientGatherData.m_chantBase = tConfig;
                    }
                    else
                    {
                        m_NetClientGatherData.m_chantBase = null;
                    }


                    onChantEvent.Invoke(m_NetClientGatherData);
                }
				//else
				ety.SetChantData(tChantID, msg.start_time, msg.end_time);

                ety.Direction = (msg.dir.FBVec3Vec3());

                onChantEvent2.Invoke(msg);
            }
        }

        /// <summary>
        /// 结束吟唱
        /// </summary>
        /// <param name="_msg"></param>
        void ProcRefreshEndChantInfo(swm.NotifyExitChant _msg)
        {
            Character ety = GetEntityByID(_msg.entity_id) as Character;
            if(null != ety)
            {
                if (ety.IsMainCharacter())
                {
                    onChantEndEvent.Invoke(_msg.is_ok);
                    if(!_msg.is_ok)
                    {
                        //中断 再强行检查一下是否靠近采集点
                        (ety as MainCharacter).CheckIsCloseEntity(true);
                    }
                }
                else
					ety.SetChantData(0, 0, 0);

				ety.setIsChant(false, null);

                onChantEndEvent2.Invoke(_msg);
            }
        }


        /// <summary>
        /// 请求采集结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspGatherResource(swm.RspGatherResource _msg)
        {
            if (!_msg.is_ok)
            {
                if(MainChar != null)
                {
                    //失败后 主角 再强行检查一下是否靠近采集点
                    MainChar.CheckIsCloseEntity(true);
                }
            }
        }

        
        void ProcLookAt(swm.LookAt msg)
        {
            var entity = GetEntityByID(msg.entity_id);
            if(entity)
            {
                entity.DirectTo(msg.pos.FBVec3Vec3());
            }
        }


        void ProcNotifyFightState(swm.NotifyFightState msg)
		{
			var ety = GetEntityByID(msg.entity_id);
			if (ety == null)
				return;
			ety.IsInAttack = msg.is_fighting;
			
		}


		void ProcAngerChange(swm.RefreshEntityAnger msg)
		{
			var ety = GetEntityByID(msg.entity_id);
			if (ety == null)
				return;
			ety.SetAnger(msg.cur_anger, msg.max_anger);
			//ety.Anger = msg.cur_anger;
		}

		//void ProcBeAttacked(swm.BeAttacked msg)
		//{
		//	var ety = GetEntityByID(msg.attacker.entity_type, msg.attacker.entity_id);
		//	if (ety == null)
		//		return;
		//	onAttacked.Invoke(ety);
		//}

        void ProcRefreshEntityAttackSpeed(swm.RefreshEntityAttackSpeed msg)
        {
            var ety = GetEntityByID( msg.entity_id);
            if(ety!=null)
                ety.Data.attack_speed = msg.attack_speed;

        }
        void ProcNotifyPlayEffect(swm.NotifyPlayEffect msg)
        {
            var ety = GetEntityByID(  msg.entity_id) as Npc;
            if (ety == null)
                return;
            ety.ShowWarnEffect((swm.PlayEffectType)msg.effect_type);
        }
        public void SendReqRelive(swm.ReliveType _reliveType)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqRelive.StartReqRelive(fbb);
            swm.ReqRelive.AddReliveType(fbb, _reliveType);
            var msg = swm.ReqRelive.EndReqRelive(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRelive.HashID, fbb);

            //             x2m.ReqRelive msg = new x2m.ReqRelive();
            //             msg.relive_type = _reliveType;
            //             MsgDispacther.instance.SendPackage(msg);
        }

        void ProcRefreshEntityMoveSpeed(swm.RefreshEntityMoveSpeed msg)
        {
            var entity = GetEntityByID(msg.entity_id) as MovableEntity;
            if (!entity)
                return;

            entity.speed = msg.move_speed / 1000.0f;
        }

        void ProcRspQingKung(swm.RspQingKung _msg)
        {
            //var entity = GetEntityByID(_msg.entity_id) as Character;
            //if (!entity)
            //    return;
            if (_msg.cli_pos.HasValue) MainChar.Position = _msg.cli_pos.FBVec3Vec3();
            MainChar.StateMachine?.Resume(MainChar.StateMachine.PrevStateID);
            //LogHelper.Log("不能轻功。");
        }
        //轻功快速落地
        void ProNotifyQingKungFastLand(swm.NotifyQingKungFastLand _msg)
        {
            var entity = GetEntityByID(_msg.entity_id) as Character;
            if (!entity)
                return;
            if (_msg.pos.HasValue)
            {
                entity.QingKungLandPosVoxelWorldID = _msg.vox_world_id;
                entity.QingKungLandPos = _msg.pos.FBVec3Vec3();
            }
            entity.StateMachine?.Resume( SM.Entity.States.QingKungStun);
            entity.RemoveAllEffects();
            //entity.FlyStun();
        }

        //轻功转向通知掉落点
        void ProNotifyQingKungTurnDown(swm.NotifyQingKungTurnDown _msg)
        {
            var entity = GetEntityByID(_msg.entity_id) as Character;
            if (entity == null || entity.IsMainCharacter() || !_msg.tpos.HasValue)
                return;
            entity.QingKungLandPos = _msg.tpos.FBVec3Vec3();
            entity.IsQingKungNormalFall = true;
            entity.StateMachine?.ChangeState(SM.Entity.States.QingKungFall);
            if (GameApplication.ShowTestCube)
            {
                GameScene.GetTempCube(124, entity.QingKungLandPos, Color.grey);
            }
        }

        //轻功碰到障碍物掉落
        void ProNotifyQingKungBlockLand(swm.NotifyQingKungBlockLand _msg)
        {
            var entity = GetEntityByID(_msg.entity_id) as Character;
            if (entity == null || entity.IsMainCharacter())
                return;
            entity.QingKungLandPos = _msg.pos.FBVec3Vec3();
            entity.IsQingKungNormalFall = false; //没有体力值
            entity.StateMachine?.ChangeState(SM.Entity.States.QingKungFall);
            if (GameApplication.ShowTestCube)
            {
                GameScene.GetTempCube(124, entity.QingKungLandPos, Color.grey);
            }
        }
        void ProNotifyQingKungUp(swm.NotifyQingKungUp _msg)
        {
            var entity = GetEntityByID(_msg.entity_id) as Character;
            if (entity == null || entity.IsMainCharacter())
                return;
            entity.QingKungStartPos = _msg.cli_pos.FBVec3Vec3();
            entity.Position = _msg.cli_pos.FBVec3Vec3();
            entity.Direction = _msg.land_pos.FBVec3Vec3() - _msg.cli_pos.FBVec3Vec3();
            entity.QingKungTopPos = _msg.to_pos.FBVec3Vec3();
            entity.QingKungLandPos = _msg.land_pos.FBVec3Vec3();
            entity.QingKungDurationTime = _msg.normalizedtime / 10000.0f; //(_msg.to_dst_time - GetServerTime() + ServersManager.Instance.RTT + 100) / 1000.0f;/*临时的延时网络*/;
            var step = (QingKungStep)_msg.id;
            if (entity.QingKungStep != step)
            {
                Debug.Assert(_msg.id != 0, Utilities.BuildFormatString("server ro client id = 0 ,client is {0}", entity.QingKungStep));
                entity.QingKungStep = step;
            }
            else if (step == QingKungStep.QingKungUp) //持续播上升动作时，用7来标记
            {
                entity.QingKungStep = QingKungStep.QingKungUp2;
            }
            if (entity.StateMachine == null)
                return;
            entity.StateMachine?.Resume(SM.Entity.States.QingKungEnter);

            if (GameApplication.ShowTestCube)
            {
                GameScene.GetTempCube(125, entity.QingKungTopPos, Color.yellow);
                GameScene.GetTempCube(124, entity.QingKungLandPos, Color.grey);
            }
            //LogHelper.Log("ProQingKungMoveToDown", entity.QingKungTopPos.ToString());
        }
        void ProNotifyQingKungPeak(swm.NotifyQingKungPeak msg)
        {
            var entity = GetEntityByID(msg.entity_id) as Character;
            if (!entity)
                return;
            var pos = msg.tpos.FBVec3Vec3();
            Vector3? tpos = QingKungTouchPointManager.Instance.GetNearTouchPoint();
            if (tpos.HasValue)
            {
                if ((tpos.Value - pos).sqrMagnitude < 1f)//sqrMagnitude 是平方的 后面那个数字需要平方  1的平方是1
                    entity.QingKungTopPos = tpos.Value;
                else
                    entity.QingKungTopPos = pos;
            }
            else
                entity.QingKungTopPos = pos;
            entity.StateMachine?.ChangeState(SM.Entity.States.QingKungPeakEnter);
        }


        void ProRefreshQingKungPep(swm.RefreshQingKungPep msg)
        {
            if (MainChar != null)
                MainChar.SetQingKungEnergy((int)msg.cur, (int)msg.max);
        }

        void ProcRefreshMachineState(swm.RefreshMachineState msg)
        {
            IMechanismMgr.Instance.RefreshState(msg.baseid, msg.state, true);
        }

        /// <summary>
        /// //下降滑翔;
        /// </summary>
        /// <param name="msg"></param>
        void ProNotifyGliding(swm.NotifyGliding msg)
        {
            var entity = GetEntityByID(msg.entity_id) as Character;
            if (!entity)
                return;

            entity.CommonGlidingCurrPos = msg.cur_pos.FBVec3Vec3();
            entity.CommonGlidingCurrDir = msg.cur_dir.FBVec3Vec3();
            entity.CommonGlidingTargetPos = msg.tpos.FBVec3Vec3();
            entity.CommonGlidingTime = msg.ttime;

            if (entity.StateMachine.CurStateID == SM.Entity.States.StateExitClouding)
            {
                //entity.Position = entity.CommonGlidingTargetPos + new Vector3(0, 20, 0);
            }
            else
            {
                entity.StateMachine.ChangeState(SM.Entity.States.CommonGliding);
            }
        }

        #region EntityTest

        //这里只是用于测试的代码！
        [XLua.BlackListAttribute()]
        public static List<KeyValuePair<ulong, GameObject>> TestCube = new List<KeyValuePair<ulong, GameObject>>(Bokura.ConstValue.kCap16);

        [XLua.BlackListAttribute()]
        public static Dictionary<int, GameObject> TempCube = new Dictionary<int, GameObject>(Bokura.ConstValue.kCap16);

        [XLua.BlackListAttribute()]
        public static Dictionary<int, Dictionary<int, GameObject>> m_TempCubeDict = new Dictionary<int, Dictionary<int, GameObject>>(Bokura.ConstValue.kCap32);

        //[XLua.BlackListAttribute()]
        //public enum PosColor { ClientMainPos,ServerMainPos, ClientMainDestPos,ServerMainDestPos,FallLandPos,QingKungTopPos}

        //[XLua.BlackListAttribute()]
        //public static Dictionary<PosColor, Color> clrs = new Dictionary<PosColor, Color>();

        [XLua.BlackListAttribute()]
        public static GameObject CreateCube(Vector3 pos,Color clr)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.GetComponent<BoxCollider>().enabled = false;
            go.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
            go.transform.position = new Vector3(pos.x, pos.y + go.transform.localScale.y /2, pos.z) - LayeredSceneLoader.WorldOffset;
            var render = go.GetComponent<Renderer>();
            if( render)
            {

                var material = ResourceHelper.LoadResourceSync("art_resource/environment/Common/Materials/", "env_test_d", ".mat");
                //var material = IResourceLoader.Instance.Load("asset/art_resource/environment/buildings/Materials/env_test_d", typeof(Material));
                render.material = material as Material;
                MaterialPropertyBlock block = new MaterialPropertyBlock();
                block.SetColor("_Color", clr);
                render.SetPropertyBlock(block);
            }
            return go;
        }

        [XLua.BlackListAttribute()]
        public static GameObject SetTempCubePos(int id, int colorid, Vector3? pos = null, Color? clr = null)
        {
            GameObject go = null;

            if (!m_TempCubeDict.ContainsKey(id))
            {
                Dictionary<int, GameObject> objdict = new Dictionary<int, GameObject>(Bokura.ConstValue.kCap8);
                go = CreateCube(pos.Value, clr.Value);
                objdict.Add(colorid, go);
                m_TempCubeDict.Add(id, objdict);
            }
            else
            {
                var objdict = m_TempCubeDict[id];
                if (objdict.ContainsKey(colorid))
                {
                    go = objdict[colorid];
                }
                else
                {
                    go = CreateCube(pos.Value, clr.Value);
                    objdict.Add(colorid, go);
                }
            }

            if (go != null)
            {
                RefreshCubePossition(go, pos.Value);
            }

            return go;
        }

        [XLua.BlackListAttribute()]
        public static GameObject GetTempCube(int id,Vector3? pos = null,Color? clr = null)
        {
            GameObject go = null;

            if(!TempCube.TryGetValue(id,out go))
            {
                go = CreateCube(pos.Value, clr.Value);
                TempCube.Add(id, go);
            }

            if (pos.HasValue)
                RefreshCubePossition(go , pos.Value);

            return go;
        }

        [XLua.BlackListAttribute()]
        public static void RefreshCubePossition(GameObject go, Vector3 pos)
        {
            if(go)
                go.transform.position = new Vector3(pos.x, pos.y + go.transform.localScale.y / 2, pos.z) - LayeredSceneLoader.WorldOffset;
        }

        static void ProcShowTestPos(swm.ShowTestPos msg)
        {
            if (!GameApplication.ShowTestCube) return;
            for (int i=0;i< msg.posLength; i++)
            {
                var go = CreateCube(msg.pos(i).FBVec3Vec3(), Color.red);
                var pair = new KeyValuePair<ulong, GameObject>(0, go);
                TestCube.Add(pair);
            }
        }

        [XLua.BlackListAttribute()]
        public static void ClearTestCube()
        {
            for (int i = 0; i < TestCube.Count;i++)
            {
                GameObject.DestroyImmediate(TestCube[i].Value);
            }
            TestCube.Clear();
            var iter = TempCube.GetEnumerator();
            while(iter.MoveNext())
            {
                GameObject.DestroyImmediate(iter.Current.Value);
            }
            TempCube.Clear();

            foreach(var iter1 in m_TempCubeDict)
            {
                if (iter1.Value == null)
                    continue;

                foreach(var iter2 in iter1.Value)
                {
                    GameObject go = iter2.Value;
                    if (go != null)
                    {
                        GameObject.DestroyImmediate(go);
                    }
                }
            }
            m_TempCubeDict.Clear();
        }

        static void ProcClearShowTestPos(swm.ClearShowTestPos msg)
        {
            for(int i = 0; i< TestCube.Count;)
            {
                if (TestCube[i].Key == 0)
                {
                    GameObject.DestroyImmediate(TestCube[i].Value);
                    TestCube.RemoveAt(i);
                }
                else
                    i++;
            }
            //TestCube.Clear();
        }
        static void ProcShowEntityTestPos(swm.ShowEntityTestPos msg)
        {
            if (!GameApplication.ShowTestCube) return;
            KeyValuePair<ulong, GameObject> entity ;
            foreach (var e in TestCube) if (e.Key == msg.entity_id){ entity = e; break; }

            if (entity.Value == null)
            {
                var go = CreateCube(msg.pos.Value.FBVec3Vec3(), Color.white);
                if (entity.Key != 0)
                    TestCube.Remove(entity);

                TestCube.Add(new KeyValuePair<ulong, GameObject>(msg.entity_id, go));
            }
            else
            {
                entity.Value.transform.position = new Vector3(msg.pos.Value.x, msg.pos.Value.y + entity.Value.transform.localScale.y / 2, msg.pos.Value.z) - LayeredSceneLoader.WorldOffset; ;
            }
        }
#endregion


        #region 网络延迟测试
        public void SendTestNetDelay()
        {
            if(!waiting_receive || Time.time - m_lastFrameSendTestMsgTime > 5)
            {
                m_lastFrameSendTestMsgTime = Time.time;
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.TestNetDelay.StartTestNetDelay(fbb);
                swm.TestNetDelay.AddTime(fbb, m_lastFrameSendTestMsgTime);
                fbb.Finish(swm.TestNetDelay.EndTestNetDelay(fbb).Value);                
                MsgDispatcher.instance.SendFBPackage(swm.TestNetDelay.HashID, fbb);
                waiting_receive = true;
            }
        }
        private bool waiting_receive = false;
        private float m_lastFrameSendTestMsgTime = 0;
        void ProcTestNetDelay(swm.TestNetDelay msg)
        {
            //if(msg.time == m_lastFrameSendTestMsgTime)
            {
                //var delta = (Time.time - m_lastFrameSendTestMsgTime) * 1000;
                //IDebugSystem.Instance.NetDelay = delta;
                waiting_receive = false;
                //LogHelper.Log(string.Format("network delay:{0}", delta));
                //SendTestNetDelay();
                GameApplication.Instance.m_TimerManager.AddTimer(SendTestNetDelay, 0.5f);

            }
        }
#endregion
  //      void ProcNotifyShowWeapon(swm.NotifyShowWeapon msg)
		//{
		//	var ety = GetEntityByID(msg.entity.entity_type, msg.entity.entity_id) as Character;
		//	if (ety == null)
		//		return;
		//	ety.IsShowGoldWeapon = msg.is_show_weapon;
		//}

        /// <summary>
        /// 重连成功后请求恢复状态
        /// </summary>
        private void RequestRecoverState_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqRecoverState.StartReqRecoverState(tFBB);
            swm.ReqRecoverState.AddMapid(tFBB, m_currentIntomapInfo.HasValue ? m_currentIntomapInfo.Value.map_baseid : 3);
            Vector3 tPos = Vector3.zero;
            bool tIsDead = false;
            bool tIsRide = false;
            if (null != MainChar)
            {
                tPos = MainChar.Position;
                tIsDead = MainChar.Died;
                tIsRide = (null != MainChar.Mount);
            }
            swm.ReqRecoverState.AddPos(tFBB, swm.Vector3.CreateVector3(tFBB, tPos.x, tPos.y, tPos.z));
            swm.ReqRecoverState.AddIsDead(tFBB, tIsDead);
            swm.ReqRecoverState.AddIsRide(tFBB, tIsRide);
            Offset<swm.ReqRecoverState> tOffset = swm.ReqRecoverState.EndReqRecoverState(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRecoverState.HashID, tFBB);
        }
        #endregion

        /// <summary>
        /// 请求 进入谨慎/退出谨慎
        /// </summary>
        public void ReqCareful_CS(bool iInto)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqCatFoot> tOffset = swm.ReqCatFoot.CreateReqCatFoot(tFBB, iInto);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCatFoot.HashID, tFBB);
        }
        /// <summary>
        /// 接收 谨慎状态 所有entity
        /// </summary>
        /// <param name="msg"></param>
        void ProcCareful(swm.UserCatFootNotifyNine msg)
        {
            //LogHelper.LogError("msg.catfoot:" + msg.catfoot);
            var ety = GetEntityByID(msg.charid) as Character;
            if (ety == null)
                return;
            
            ety.IsCareful = msg.catfoot;
        }

        /// <summary>
        /// 接收 隐身或退出隐身 所有entity
        /// </summary>
        /// <param name="msg"></param>
        void ProcSneak(swm.UserSneak msg)
        {
            //LogHelper.LogError("msg.sneak:" + msg.sneak);
            var ety = GetEntityByID(msg.charid);
            if (ety == null)
                return;
            ety.IsInvisible = msg.sneak;
        }
        
        /// <summary>
        /// 通知的参数改变消息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyParamChange(swm.NotifyParamChange _msg)
        {

            onNotifyParamChange.Invoke(_msg.type,_msg.value);
        }

        #region 副本流程事件
        private void ProcGameCopyEvent(swm.CopyEvt msg)
        {
            //LogHelper.Log("ProcGameCopyEvent! msg.evt_type:", msg.evt_type, " msg.is_enable:", msg.is_enable,
            //    " msg.param1:", msg.param1, " msg.param2:", msg.param2 == null ? "null" : msg.param2);
            switch (msg.evt_type)
            {
                case 1:
                    //相机锁定
                    if (msg.is_enable)
                    {
                        float[] config = ParseCameraConfig(msg.param2);
                        LockCamera(config);
                    }
                    else
                    {
                        ResumeCamera();
                    }
                    break;
                case 2:
                    //地表
                    if (msg.is_enable)
                    {
                        Bokura.IFoliageControler.Instance.SetFoliagePhysic(
                            (CritiasFoliage.EFoliagePhysicType)msg.param1);
                    }
                    else
                    {
                        Bokura.IFoliageControler.Instance.SetFoliagePhysic(
                            CritiasFoliage.EFoliagePhysicType.NORMAL);
                    }
                    break;
                case 3:
                    //角色状态
                    if (msg.param1 == 1)
                    {
                        //重伤
                        SetHurtBadly(msg.is_enable);
                    }
                    break;
                case 4:
                    //NPC脚印
                    if (msg.is_enable)
                    {
                        ActionEffectManager.Instance.StartForcePlayActionEvent((int)msg.param1);
                    }
                    else
                    {
                        ActionEffectManager.Instance.StopForcePlayActionEvent((int)msg.param1);
                    }
                    break;
                case 5:
                    //寻路特效
                    if (msg.is_enable)
                    {
                        ParseGameCopyFindPathConfig(msg.param2);
                        RemoveFindPathEffect();
                        SetFindPathEffect();
                    }
                    else
                    {
                        RemoveFindPathEffect();
                    }
                    break;
                case 6:
                    //天气
                    WeatherManager.Instance.ChangeGameCopyWeather((int)msg.param1);
                    break;
                case 7:
                    //背景音乐
                    ParseBGMusicConfig(msg.param2);
                    if (GameCopyBGMusicConfig.Length != 2)
                    {
                        LogHelper.LogError("GameCopyBGMusicConfig need 2 params");
                        return;
                    }
                    AudioStudio.AudioManager.Instance.SetState(GameCopyBGMusicConfig[0], GameCopyBGMusicConfig[1]);
                    break;
                case 8:
                    //风力
                    if (msg.is_enable)
                    {
                        ParseWindConfig(msg.param2);
                        int min = GameCopyWindConfig[0];
                        int max = GameCopyWindConfig[1];
                        CritiasFoliage.FoliageTileManager.Instance.GetWind().SetIntensityRange(min, max);
                    }
                    else
                    {
                        CritiasFoliage.FoliageTileManager.Instance.GetWind().SetDefaultIntensity();
                    }
                    break;
                case 9:
                    //场景特效
                    if (msg.is_enable)
                    {
                        Vector3 pos;
                        string effectName;
                        ParseSceneEffectConfig(msg.param2, out pos, out effectName);
                        //
                    }
                    else
                    {

                    }
                    break;
                default:
                    break;
            }
        }

        #endregion

        private void ProcOpenGuideEvent(swm.NotifyOpenGuide msg)
        {
            int id = (int)msg.guideid;
            GuideMgr.Instance.GuideTriggerEvent.Invoke(id);
        }
        /// <summary>
        /// 接收 进入载具变身
        /// </summary>
        /// <param name="msg"></param>
        private void ProcOnVehicleEvent(swm.NotifyOnVehicle msg)
        {
            var ety = GetEntityByID(msg.entity_id) as Character;
            if (ety == null)
                return;
            
            ety.VehicleId = msg.vehicle_id;
            if (ety.IsMainCharacter())
            {
                MainChar.OnRefreshVehicleEvent.Invoke();

                if (MainChar.Mount != null)
                    MountMgr.Instance.RequestDismount();
            }

        }
        /// 请求 退出载具变身
        /// </summary>
        public void ReqOffVehicle_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqOffVehicle.StartReqOffVehicle(tFBB);
            Offset<swm.ReqOffVehicle> tOffset = swm.ReqOffVehicle.EndReqOffVehicle(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqOffVehicle.HashID, tFBB);
        }
        /// <summary>
        /// 接收 退出载具变身
        /// </summary>
        /// <param name="msg"></param>
        private void ProcOffVehicleEvent(swm.NotifyOffVehicle msg)
        {
            var ety = GetEntityByID(msg.entity_id) as Character;
            if (ety == null)
                return;

            ety.VehicleId = 0;
            if (ety.IsMainCharacter())
                MainChar.OnRefreshVehicleEvent.Invoke();
        }

        private void ProcNotifyPlayEffects(swm.NotifyPlayEffects msg)
        {
            EffectMgr.Instance.Play(msg.name, msg.pos.FBVec3Vec3() - LayeredSceneLoader.WorldOffset);
        }

        /// <summary>
        /// 刷新资源状态(可采集/不可采集)
        /// </summary>
        /// <param name = "msg" ></ param >
        private void ProcRefreshResourceState(swm.RefreshResourceState msg)
        {
            GatherResourceEntity entity = GetEntityByID(msg.entity_id) as GatherResourceEntity;
            if (entity == null)
                return;

            entity.RefreshCollectionState(msg.state);

            if (m_mainCharacter != null)
            {
                if (entity.IsEntityClose(m_mainCharacter))
                {
                    m_mainCharacter.CheckIsCloseEntity(true);
                }
            }
        }
#if !RELEASE
        void ProcShowMeshBegin(swm.ShowMeshBegin msg)
        {
            var servermesh = GameObject.Find("ServerMesh");
            if(servermesh)
            {
                GameObject.DestroyImmediate(servermesh);
            }
        }


        List<Vector3> m_serverMeshVertrx;// = new List<Vector3>(1024*64);
        List<int> m_serverMeshIndices;// = new List<int>(1024 * 64 * 3);
        void ProcShowMeshData(swm.ShowMeshData msg)
        {
            if(m_serverMeshVertrx==null)
            {
                m_serverMeshVertrx = new List<Vector3>(1024 * 32);
                m_serverMeshIndices = new List<int>(1024 * 32 * 3);
            }
            for (int i = 0; i < msg.verticesLength; i++)
            {
                m_serverMeshVertrx.Add(msg.vertices(i).FBVec3Vec3());
            }
            for (int i = 0; i < msg.indicesLength; i++)
            {
                m_serverMeshIndices.Add(msg.indices(i));
            }
        }

        void ProcShowMesh(swm.ShowMesh msg)
        {
            var servermesh = GameObject.Find("ServerMesh");
            if (!servermesh)
            {
                servermesh = new GameObject("ServerMesh");
            }
            int prevVertexLen = 0;// msg.verticesLength;
            
            if(m_serverMeshVertrx!=null)
            {
                prevVertexLen = m_serverMeshVertrx.Count;
            }
            var vertices = new Vector3[prevVertexLen+ msg.verticesLength];

            if(prevVertexLen>0)
                Array.Copy(m_serverMeshVertrx.ToArray(), vertices, prevVertexLen);

            for(int i = 0; i < msg.verticesLength; i ++)
            {
                vertices[i+ prevVertexLen] = msg.vertices(i).FBVec3Vec3();
            }
            int prevIndexLen = 0;
            if(m_serverMeshIndices!=null)
            {
                prevIndexLen = m_serverMeshIndices.Count;
            }

            var indices = new int[msg.indicesLength+prevIndexLen];
            if(prevIndexLen>0)
                Array.Copy(m_serverMeshIndices.ToArray(), indices, prevIndexLen);

            if(m_serverMeshVertrx!=null)
            {
                m_serverMeshVertrx.Clear();
                m_serverMeshIndices.Clear();
            }

            for (int i = 0; i < msg.indicesLength; i +=3)
            {
                indices[i+ prevIndexLen] = msg.indices(i);
                indices[i+1+ prevIndexLen] = msg.indices(i+2);
                indices[i+2+ prevIndexLen] = msg.indices(i+1);
            }

            //var 

            var mesh = new Mesh();
            mesh.SetVertices(vertices, vertices.Length);
            mesh.SetIndices(indices, MeshTopology.Triangles, 0);

            mesh.RecalculateBounds();
            
            //mesh.SetVertices()


            var meshobj = new GameObject(Utilities.BuildString("mesh", servermesh.transform.childCount.ToString()));
            var meshfilter = meshobj.AddComponent<MeshFilter>();
            meshfilter.sharedMesh = mesh;
            //meshfilter.sharedMesh

            var meshrender = meshobj.AddComponent<MeshRenderer>();
            var shader = ResourceHelper.LoadShaderSync("shaders/", "Alpha-Diffuse") as Shader;
            var material = new Material(shader);
            float r = ((msg.color) & 0xff)/255.0f;
            float g = ((msg.color >> 8) & 0xff) / 255.0f;
            float b = ((msg.color >> 16) & 0xff) / 255.0f;
            float a = ((msg.color >> 24) & 0xff) / 255.0f;

            material.color = new Color(r, g, b, a);
            meshrender.sharedMaterial = material;
            
            meshobj.transform.SetParent(servermesh.transform, true);

            meshobj.transform.position = msg.pos.FBVec3Vec3() - LayeredSceneLoader.WorldOffset;
            meshobj.transform.rotation = Quaternion.Euler(0.0f, msg.radian_y/Mathf.PI*180.0f, 0.0f);
            meshobj.transform.localScale = new Vector3(msg.scale, msg.scale, msg.scale);
        }
#endif
        ///// <summary>
        ///// 天气改变
        ///// </summary>
        //private void ProcWeatherTypeChanged()
        //{
        //    int weatherType = WeatherManager.Instance.GetCurrWeatherType();

        //    if (null == MainChar)
        //        return;

        //    foreach (var kv in AllEntitys)
        //    {
        //        Entity entity = kv.Value;
        //        if (entity == null)
        //            continue;

        //        if (entity.ThisID == MainChar.ThisID)
        //            continue;

        //        if (entity.Died)
        //            continue;

        //        if (!entity.Visible)
        //            continue;

        //        if (!entity.IsNpc())
        //            continue;

        //        Npc npc = entity as Npc;
        //        if (npc == null)
        //            continue;

        //        npc.ProcWeatherTypeChanged(weatherType);
        //    }
        //}

        protected void ProcPrintDebugInfo(swm.PrintDebugInfo msg)
        {
#if !RELEASE
            GMCommandManager.Instance.ProcPrintDebugInfo(msg);
#endif
        }
        /// <summary>
        /// 九屏改变身 变模型通知
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyChangeModelId(swm.NotifyChangeModelId _msg)
        {
            Entity entity = GetEntityByID(_msg.entityid);
            if(entity)
            {
                entity.currentTransformId = _msg.changeid;
            }
        }

        public GameEvent<List<swm.RedDotType>> onRedPointState = new GameEvent<List<swm.RedDotType>>();

        void ProcNotifyUserOnline(swm.NotifyUserOnline msg)
        {
            if(msg.main_data.HasValue)
                UserDataMgr.Instance.ProcSyncMainUserData(msg.main_data.Value);
            if(msg.map_data.HasValue)
                ProcIntoMap(msg.map_data.Value);
            if(msg.mount_data.HasValue)
                MountMgr.Instance.ProcNotifyMountList(msg.mount_data.Value);
            if(msg.chat_data.HasValue)
                ProcNotifyParamChange(msg.chat_data.Value);
            int len = msg.red_dot_dataLength;
            LogHelper.Log("redpoint" + len.ToString());
            if (len > 0)
            {
                List<swm.RedDotType> lst = new List<swm.RedDotType>();
                for (int i = 0; i < len; ++i)
                {
                    lst.Add(msg.red_dot_data(i).Value.type);
                }

                onRedPointState.Invoke(lst);
            }

            //ProcSyncMainUserData()
        }


        void ProcNotifyUserReady(swm.NotifyUserReady msg)
        {
            if(msg.buff_data.HasValue)
                BuffModel.Instance.ProcNotifyAddBuff(msg.buff_data.Value);
            if(msg.plane_data.HasValue)
                MobileBlockMgr.Instance.ProcNotifyTerrace(msg.plane_data.Value);
        }

        /// <summary>
        /// 请求退出变身状态 用这个 别用载具那个
        /// </summary>
        /// <param name="_buffid"></param>
        public void SendReqExitChangeModel()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqExitChangeModel.StartReqExitChangeModel(fbb);
            var msg = swm.ReqExitChangeModel.EndReqExitChangeModel(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqExitChangeModel.HashID, fbb);
        }


        bool bShowLinePanel = false;

        /// <summary>
        /// 线路列表请求
        /// </summary>
        /// <param></param>
        public void SendReqCurrLineList(bool bShow)
        {
            bShowLinePanel = bShow;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqCurrLineList.StartReqCurrLineList(fbb);
            var msg = swm.ReqCurrLineList.EndReqCurrLineList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCurrLineList.HashID, fbb);
        }

        /// <summary>
        /// 换线请求
        /// </summary>
        /// <param></param>
        public void SendReqChangeLine(uint id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqChangeLine.StartReqChangeLine(fbb);
            swm.ReqChangeLine.AddLineid(fbb, id);
            var msg = swm.ReqChangeLine.EndReqChangeLine(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqChangeLine.HashID, fbb);
        }

        /// <summary>
        /// 线路列表返回
        /// </summary>
        /// <param name="_msg"></param>
        public GameEvent<List<swm.LineData>, uint, bool> OnCurLineInfo = new GameEvent<List<swm.LineData>,uint, bool>();

        private void ProcRspCurrLineList(swm.RspCurrLineList _msg)
        {
            List<swm.LineData> lst = new List<swm.LineData>(_msg.linelistLength);

            for (int i = 0; i < _msg.linelistLength; ++i)
            {
                lst.Add(_msg.linelist(i).Value);
            }

            OnCurLineInfo.Invoke(lst, curLineID, bShowLinePanel);
            bShowLinePanel = false;
        }

        public List<Entity> treatlist = new List<Entity>();
        private void ResetTreatlist() {
            for (int i = 0; i < treatlist.Count; i++) {
                if (treatlist[i] != null) {
                    treatlist[i].IsTreatMainchar = false;
                }
                
            }
            treatlist.Clear();
        }
        //仇恨列表
        private void ProNotifyReverseThreat(swm.NotifyReverseThreat msg)
        {
            ResetTreatlist();
            for (int i = 0; i < msg.uidsLength; i++) {
                ulong id = msg.uids(i);
                Entity entity = GetEntityByID(id);
                if (entity != null) {
                    entity.IsTreatMainchar = true;
                    treatlist.Add(entity);
                }
                
            }
        }

        #region 脱离卡死
        public void ReqLeaveStuck()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqLeaveStuck.StartReqLeaveStuck(fbb);
            var leave = swm.ReqLeaveStuck.EndReqLeaveStuck(fbb);
            fbb.Finish(leave.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqLeaveStuck.HashID, fbb);

        }

        public ulong LeaveStuckUnlockTime { get { return PrevLeaveStruckBeginTime + LeaveStuckDuration; } }
        protected ulong LeaveStuckDuration = 0;        //秒
        protected ulong PrevLeaveStruckBeginTime = 0;  //
        protected void ProRspLeaveStuck(swm.RspLeaveStuck msg)
        {
            PrevLeaveStruckBeginTime = msg.stamp;
            LeaveStuckDuration = msg.msec;
        }

        #endregion

        #region gm

        public void GM_Test_NpcActionModelBind(uint npcbaseid, uint actionid)
        {
            var entity = GetEntityByBaseId(npcbaseid) as MovableEntity;
            if (!entity)
                return;

            entity.CommonType = MovableEntity.ActionType.Common;
            entity.CommonTrunPos = Vector3.zero;
            entity.CommonActionId = actionid;

            if (!entity.isCloudTransmitting())
            {
                entity.StateMachine.Resume(SM.Entity.States.ACTION);
            }
        }

        public void GM_Test_RefreshResourceState(bool cangather)
        {
            foreach (var iter in m_entitys)
            {
                Entity entity = iter.Value;
                if (entity == null)
                    continue;

                if (!entity.IsGatherResource())
                    continue;

                GatherResourceEntity gatherentity = entity as GatherResourceEntity;
                if (gatherentity == null)
                    continue;

                if (cangather)
                {
                    gatherentity.RefreshCollectionState((int)swm.ResourceCollectionState.Collection);
                }
                else
                {
                    gatherentity.RefreshCollectionState((int)swm.ResourceCollectionState.NoCollection);
                }
            }
        }


#endregion
    }
}


