﻿using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public class NotifyMessageBoxInfo
    {
        private swm.NotifyMessageBox? m_netMessage;
        private string m_content = string.Empty;
        private bool m_isRead = false;
        public bool IsRead
        {
            get
            {
                return m_isRead;
            }
            set
            {
                m_isRead = value;
            }
        }
        public swm.NotifyMessageBox? NetMessage
        {
            get
            {
                return m_netMessage;
            }
            set
            {
                m_netMessage = value;
            }
        }

        public string GetParamsValueByKey(string _key)
        {
            string str = string.Empty;
            if (null != m_netMessage)
            {
                if (m_netMessage.Value.ts_paramsLength > 0)
                {
                    for (int i = 0; i < m_netMessage.Value.ts_paramsLength; i++)
                    {
                        swm.TsParams? _swTs = m_netMessage.Value.ts_params(i);
                        if (_key.Equals(_swTs.Value.key))
                        {
                            str = _swTs.Value.value;
                            break;
                        }
                    }
                }
            }
            return str;
        }

        public string Content
        {
            get
            {
                if( null != m_netMessage && string.IsNullOrEmpty(m_content) )
                {
                    //TODO:FB
                    // m_content= NotifyModel.Instance.GetInfoByData((int)m_netMessage.Value.ts_id, m_netMessage.Value.ts_params);
                    List<swm.TsParamsT> _list = null;
                    if(m_netMessage.Value.ts_paramsLength > 0)
                    {
                        _list = new List<swm.TsParamsT>();
                        for(int i =0;i< m_netMessage.Value.ts_paramsLength;i++)
                        {
                            swm.TsParamsT _xmTs = new swm.TsParamsT();
                            swm.TsParams? _swTs = m_netMessage.Value.ts_params(i);
                            _xmTs.key = _swTs.Value.key;
                            _xmTs.value = _swTs.Value.value;
                            _list.Add(_xmTs);
                        }
                    }

                    m_content = NotifyModel.Instance.GetInfoByData((int)m_netMessage.Value.ts_id, _list);
				}
                return m_content;
            }
        }
    }


    class GeneralMessageModel : ClientSingleton<GeneralMessageModel>
    {
        public class NotifyMessageBoxEvent : GameEvent<NotifyMessageBoxInfo>
        {

        }
        public NotifyMessageBoxEvent onNotifyMessage = new NotifyMessageBoxEvent();

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyMessageBox>(ProcNotifyMessageBox);
        }
        public void Clear()
        {

        }
        /// <summary>
        /// 接收到通用“确认”“取消”消息
        /// </summary>
        public void ProcNotifyMessageBox(swm.NotifyMessageBox _msg)
        {
            NotifyMessageBoxInfo _info = new NotifyMessageBoxInfo();
            _info.NetMessage = Utility.CopyFBMsg(_msg);
            onNotifyMessage.Invoke(_info);
        }

        /// <summary>
        /// 发送选择结果
        /// </summary>
        /// <param name="_result"></param>
        /// <param name="_version"></param>
        public void SendReturnMessageBox(swm.MsgBoxRespondType _result,uint _version, swm.MessageBoxType _type)
        {
			var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            //x2m.ReturnMessageBox msg = new x2m.ReturnMessageBox();
            swm.ReturnMessageBox.StartReturnMessageBox(fbb);

            swm.ReturnMessageBox.AddResult(fbb, _result);
			swm.ReturnMessageBox.AddVersion(fbb, _version);
			swm.ReturnMessageBox.AddType(fbb, _type);
			fbb.Finish(swm.ReturnMessageBox.EndReturnMessageBox(fbb).Value);
	
            MsgDispatcher.instance.SendFBPackage(swm.ReturnMessageBox.HashID, fbb);
        }
    }
}
