using System.Collections.Generic;
using System;
using System.IO;
using Bokura;

using UnityEngine;

namespace Bokura
{
    [XLua.LuaCallCSharp]
    public class GuideMgr : ClientSingleton<GuideMgr>
    {
        private GameEvent<int> m_GuideTriggerEvent;
        public GameEvent<int> GuideTriggerEvent
        {
            get { return m_GuideTriggerEvent; }
        }

        private GameEvent m_OnRecvUserData;
        public GameEvent OnRecvUserData
        {
            get { return m_OnRecvUserData; }
        }

        public float ScreenWidth
        {
            get { return Screen.width; }
        }

#if !RELEASE
        //Guide-Runtime-Tool active ?
        private bool m_GuideTool = false;
        [XLua.BlackList]
        public bool isGuideTool
        {
            get { return m_GuideTool; }
            set { m_GuideTool = value; }
        }

        private GuideBtn m_Btn;
        [XLua.BlackList]
        public GuideBtn GuideBtn
        {
            get { return m_Btn; }
            set
            {
                m_Btn = value;
                isGuideTool = true;
            }
        }
#endif

        Dictionary<ushort, byte> m_guideSteps = new Dictionary<ushort, byte>(Bokura.ConstValue.kCap16);

        MemoryStream m_writeStream = new MemoryStream(3*1024);
        BinaryWriter m_binaryWrite;

        public GuideTableBaseList m_DataList;
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/GuideTable.bin");
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
            bb.EnableStringCache = true;
            Instance.m_DataList = GuideTableBaseList.GetRootAsGuideTableBaseList(bb);
            CreateKeyToIdList();
        }
        public static GuideTableBase? GetData(int id)
        {
            if (Instance.m_HasIniKeyToIdList == false)
                CreateKeyToIdList();

            Int64 m_LongId = 0;

            m_LongId = m_LongId | (uint)id; int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId, out listid) == true)
            {
                var data = Instance.m_DataList.GuideTable(listid);
                return data;
            }
            return null;
        }
        private static void CreateKeyToIdList()
        {
            int len = Instance.m_DataList.GuideTableLength;

            Instance.KeyToIdList = new Dictionary<long, int>(len);
            Int64 m_LongID = 0;
            for (int i = 0; i < len; i++)
            {
                var data = Instance.m_DataList.GuideTable(i);
                m_LongID = 0;
                m_LongID = m_LongID | (uint)data.Value.id;
                Instance.KeyToIdList.Add(m_LongID, i);
            }
            Instance.m_HasIniKeyToIdList = true;
        }
        public static int GetLen()
        {
            return Instance.KeyToIdList.Count;
        }

        public GuideMgr()
        {
            ClientSyncDataMgr.Instance.OnRecvServerData.AddListener(OnRecvServerData);
            m_binaryWrite = new BinaryWriter(m_writeStream);

            m_GuideTriggerEvent = new GameEvent<int>();
            m_OnRecvUserData = new GameEvent();
        }

        public void Clear()
        {
            m_guideSteps.Clear();

            m_writeStream.Dispose();
            m_binaryWrite.Dispose();
        }

        void OnRecvServerData(ClientSyncDataType dt, byte[] data)
        {
            if (dt != ClientSyncDataType.GuideData)
                return;
            if(data.Length%3!=0)
            {
                LogHelper.LogError("recv invalid guide data!", data.Length.ToString());
                return;
            }
            MemoryStream ms = new MemoryStream(data);
            BinaryReader br = new BinaryReader(ms);
            while(ms.Length-ms.Position>=3)
            {
                var id = br.ReadUInt16();
                var step = br.ReadByte();
               
                m_guideSteps[id] = step;
               
            }

            ms.Dispose();
            br.Dispose();

            m_OnRecvUserData.Invoke();
        }

        void SaveGuide()
        {
            m_writeStream.SetLength(0);
            m_writeStream.Position = 0;
            foreach(var kv in m_guideSteps)
            {
                m_binaryWrite.Write(kv.Key);
                m_binaryWrite.Write(kv.Value);
            }
            ClientSyncDataMgr.Instance.SetData(ClientSyncDataType.GuideData, m_writeStream.GetBuffer(),0,(int)m_writeStream.Position);
            ClientSyncDataMgr.Instance.SaveData();
        }

        public void SetGuideStep(int id, int step)
        {
            if (id < 0 || id > 0xffff || step<0|| step>255)
                return;
            m_guideSteps[(ushort)id] = (byte)step;
            SaveGuide();
        }

        public int GetGuideStep(int id)
        {
            if (id < 0 || id > 0xffff)
                return 0;
            byte step;
            if(m_guideSteps.TryGetValue((ushort)id,out step))
                return step;
            return 0;
        }



    }
}