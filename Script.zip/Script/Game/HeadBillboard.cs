﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Bokura
{

    public class HeadBillboard 
    {


		static List<HeadBillboard> m_Billboards = new List<HeadBillboard>();
        // Use this for initialization
		Transform m_hpbarTransform;
		Vector3 m_oldPos;
		Vector3 m_cameraPos;
		Quaternion m_oldRotate;
        protected bool m_bVisible = true;

        public Transform transform
		{
			get
			{
				return m_hpbarTransform;
			}
		}

        public bool Visible
        {
            get
            {
                return m_bVisible;
            }

            set
            {
                if(m_bVisible != value)
                {
                    m_bVisible = value;
                    if (null != m_hpbarTransform)
                    {
                        m_hpbarTransform.gameObject.SetActive(m_bVisible);
                    }
                }
            }
        }

        public void Init(Entity e)
		{

			if(e!=null && e.Avatar != null && e.Avatar.unityObject != null)
			{
				m_hpbarTransform = e.Avatar.unityObject.transform.Find("ui/hpbar");
			}
			m_Billboards.Add(this);
		}

		public void Dispose()
		{
			m_Billboards.Remove(this);
		}

		public static void UpdateAll()
		{
			for(int i = 0; i < m_Billboards.Count; i ++ )
			{
				m_Billboards[i].Update();
			}
		}

		// Update is called once per frame
		void Update()
        {
            if (m_hpbarTransform != null  )
			{
				var camera = GameScene.Instance.MainCamera;
                if(null == camera)
                    return;

				if (m_oldPos!= m_hpbarTransform.position ||
					m_cameraPos != camera.transform.position ||
					m_oldRotate != m_hpbarTransform.rotation)
				{
					var v = camera.transform.localToWorldMatrix.MultiplyPoint(Vector3.forward);

					v -= camera.transform.position;


					var lookat = m_hpbarTransform.position - v;


					m_hpbarTransform.LookAt(lookat);
					m_oldPos = m_hpbarTransform.position;//new Vector3(m_HpBarTransform.position.x, m_HpBarTransform.position.y,m_HpBarTransform.position.z);
					m_oldRotate = m_hpbarTransform.rotation;
					m_cameraPos = camera.transform.position;
				}


			}
     
        }
    }
}


