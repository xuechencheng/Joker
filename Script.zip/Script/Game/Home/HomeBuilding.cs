using Bokura;
using UnityEngine;

namespace Bokura
{
    [XLua.LuaCallCSharp]
    public class HomeBuilding: AvatarEvent
    {

        public const string ModelDir = "art_resource/environment/GameTesting/prefabs/";

        IAvatar m_model;
        public IAvatar Model { get { return m_model; } }

        HomeBuildingInfo m_homeBuildingInfo;

        Vector3 m_showPos;
        bool m_titleVisible=false;
        GameObject m_tile;
        Renderer m_tileRenderer;
        Color m_tileColor;
        Material m_tileMat;
        public Vector3 Position
        {
            get => m_showPos;
            set
            {
                m_showPos = value;
                if (m_model!=null)
                    m_model.SetPosition(m_showPos);
            }
        }

        [XLua.BlackList]
        public Transform GetTrans()
        {
            if (m_model == null)
                return null;

            if (m_model.unityObject == null)
                return null;

            return m_model.unityObject.transform;
        }

        public bool TileVisible
        {
            get => m_titleVisible;
            set
            {
                m_titleVisible = value;
                if (m_tile)
                    m_tileRenderer.enabled = m_titleVisible;

                //    m_tile.SetActive(m_titleVisible);
            }
        }

        public Color TileColor
        {
            get
            {
                return m_tileColor;
            }
            set
            {
                m_tileColor = value;
                if (m_tileMat)
                    m_tileMat.color = m_tileColor;
            }
        }

        //bool m_isTempBuilding;
  
 

        public HomeBuildingInfo Info { get => m_homeBuildingInfo; }

        public HomeBuilding()
        {
            m_model = IFactory.Instance.CreateAvatar(this);
            m_model.onCreate.AddListener(OnAvatarCreateDelegate);

        }

        string m_loadmodel;
        public void SetInfo(HomeBuildingInfo buildingInfo)
        {
            m_homeBuildingInfo = buildingInfo;
            UpdateShowPosFromInfo();
            //SetPosition(buildingInfo)
            string model;
            if(buildingInfo.IsInBuilding || buildingInfo.IsInUpgrade)
                model = buildingInfo.Config.biuldingmodel;
            else
                model =  buildingInfo.Config.model;
            if (string.IsNullOrEmpty(model))
                model = buildingInfo.Config.model;

            if (m_loadmodel != model)
            {

                m_loadmodel = model;
                m_model.LoadModel(ModelDir, model, true);
            }

        }

        public void Release()
        {
            if (null != m_model)
            {
                m_model.Release();
                IFactory.Instance.ReleaseAvatar(m_model);
                m_model = null;
            }
        }

        public override bool IsHomeBuilding()
        {
            return true;
        }
        void OnAvatarCreateDelegate()
        {
            m_model.SetLayer((int)UserLayer.Layer_Default);

            m_model.SetPosition(m_showPos);
            m_model.SetDirectionAngle(Info.Dir * 90.0f);

            CreateTile();

            if (Info != null)
            {
                HomeBuildingViewer.Instance.modelLoadEvent.Invoke(Info.id);
            }
        }

        void CreateTile()
        {
            if(!m_tile)
            {
                m_tile = GameObject.CreatePrimitive(PrimitiveType.Cube);

                //UnityEngine.Object.Destroy(m_tile.GetComponent<BoxCollider>());
                m_tile.transform.localPosition = Vector3.zero;
                m_tile.layer = (int)UserLayer.Layer_NPC;
                var render = m_tile.GetComponent<Renderer>();
                m_tileRenderer = render;
                if (render)
                {
                    var shader = ResourceHelper.LoadShaderSync("shaders/", "Alpha-DiffuseNoZ") as Shader;
                    m_tileMat = new Material(shader);
                    render.material = m_tileMat;//

                    m_tileMat.color = m_tileColor;

                }
            }
            m_tileRenderer.enabled = m_titleVisible;

            m_tile.transform.localScale = new Vector3(Info.ConfigWidth * HomeBuildingViewer.GridSize, 0.1f, Info.ConfigHeight * HomeBuildingViewer.GridSize);

            m_tile.transform.SetParent(m_model.unityObject.transform, false);
        }

        public void UpdateShowPosFromInfo()
        {
            if (m_model == null) return;
            var offset = HomeBuildingViewer.Instance.Offset;
            var pos =  m_homeBuildingInfo.Rect.center * HomeBuildingViewer.GridSize;
            m_showPos =new Vector3( pos.x,0.0f, pos.y) + offset;
            if (m_model != null)
            {
                m_model.SetPosition(m_showPos);
                m_model.SetDirectionAngle(Info.Dir * 90.0f);
            }

        }

        public bool IsShowPosSameInfoPos()
        {
           // var offset = HomeBuildingViewer.Instance.Offset;
            var showpos = m_showPos - HomeBuildingViewer.Instance.Offset;
            var x = (int)((showpos.x / HomeBuildingViewer.GridSize) - Info.Rect.width / 2.0f);
            var y = (int)((showpos.z / HomeBuildingViewer.GridSize) - Info.Rect.height / 2.0f);
            return m_homeBuildingInfo.Pos.x == x && m_homeBuildingInfo.Pos.y == y;
        }
        public bool UpdatePosFromShowPos()
        {
            var showpos = m_showPos - HomeBuildingViewer.Instance.Offset;
            var x = (int)((showpos.x / HomeBuildingViewer.GridSize) - Info.Rect.width / 2.0f);
            var y = (int)((showpos.z / HomeBuildingViewer.GridSize) - Info.Rect.height / 2.0f);


            m_homeBuildingInfo.Pos = new Vector2Int(x, y);
            HomeBuildingMgr.Instance.MakeBuildingInRange(m_homeBuildingInfo);
            //if (HomeBuildingMgr.Instance.CheckBuildingPosValid(m_homeBuildingInfo, x, y, 0))
            //{
            //    m_homeBuildingInfo.Pos = new Vector2(x, y);
            //    return true;
            //}
            return false;
        }

        /// <summary>
        /// 播放升级特效
        /// </summary>
        [XLua.BlackList]
        public void PlayLevelupEff()
        {
            //// 是否升级,建造消息的回应
            if (Info == null)
                return;


            if (Info.Config.type == (int)swm.BuildingType.hexin)
            {
                // 需要升级的回复 (核心建造是秒升的, 需要特殊判断)
                if (!Info.IsRspLevelupState())
                    return;
            }
            else
            {
                // 之前是在升级或者创建
                if ((Info.IspreInBuilding || Info.IspreInUpgrade) == false)
                    return;

                // 现在不在升级或者创建, 已经创建完成
                if (Info.IsInBuilding || Info.IsInUpgrade)
                    return;
            }

            EffectMgr.Instance.Play(Info.Config.levelup_eff, Position, null, true, (float)Info.Config.levelup_eff_scale);
        }
    }
}


