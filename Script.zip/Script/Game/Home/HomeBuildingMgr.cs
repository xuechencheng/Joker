using System.Collections.Generic;
using System;
using System.IO;
using Bokura;
using FlatBuffers;

using UnityEngine;

namespace Bokura
{

    [XLua.LuaCallCSharp]
    public class HomeBuildingInfo
    {
        
        public int id;
     

        public int ConfigWidth
        {
            get => Config.area(0);
        }
        public int ConfigHeight
        {
            get => Config.area(1);
        }


        int m_dir;
        public int Dir//0:0 1:90 2:180 3:270
        {
            get => m_dir;
            set {
                m_dir = value;
                if (m_dir == 0 || m_dir == 2)
                {
                    m_rect.width = ConfigWidth;
                    m_rect.height = ConfigHeight;
                }
                else
                {
                    m_rect.width = ConfigHeight;
                    m_rect.height = ConfigWidth;
                }
            }
        }

        public Vector2Int Pos
        {
            get
            {
                return m_rect.position;
            }
            set
            {
                m_rect.position = value;
            }
        }

        RectInt m_rect;
        public RectInt Rect
        {
            get=> m_rect;
        }

        int m_configid;
        public int ConfigID
        {
            get => m_configid;
            set
            {
                m_configid = value;
                m_config = null;
            }
        }

        HomeBuildingTableBase? m_config;
        public HomeBuildingTableBase Config
        {
            get
            {
                if (m_config.HasValue)
                    return m_config.Value;
                m_config = HomeBuildingTableManager.GetData(m_configid);
                return m_config.Value;
            }
        }

        private int m_preState;
        public int preState
        {
            get { return m_preState; }
            set { m_preState = value; }
        }


        int m_state;
        public int State
        {
            set => m_state = value;
            get => m_state;
        }

        private int m_rsptype;
        public int rsptype
        {
            get { return m_rsptype; }
            set { m_rsptype = value; }
        }

        /// <summary>
        /// 是否升级状态的回应
        /// </summary>
        /// <returns></returns>
        public bool IsRspLevelupState()
        {
            return m_rsptype == (int)swm.RspBuildInfoType.levelup;
        }

        /// <summary>
        /// 是否建造状态的回应
        /// </summary>
        /// <returns></returns>
        public bool IsRspBuildState()
        {
            return m_rsptype == (int)swm.RspBuildInfoType.build;
        }

        public bool IsInProduct
        {
            get =>(m_state & (int)swm.BuildingState.product)!=0;
        }

        public bool IsInBuilding
        {
            get=> (m_state & (int)swm.BuildingState.building) != 0;
        }

        public bool IsInUpgrade
        {
            get => (m_state & (int)swm.BuildingState.levelup) != 0;
        }

        [XLua.BlackList]
        public bool IspreInBuilding
        {
            get => (m_preState & (int)swm.BuildingState.building) != 0;
        }

        [XLua.BlackList]
        public bool IspreInUpgrade
        {
            get => (m_preState & (int)swm.BuildingState.levelup) != 0;
        }

        /// <summary>
        /// 是否可升级
        /// </summary>
        /// <returns></returns>
        public bool CanUpgrade(bool notify = false)
        {
            if (!CanUpgrade_Cond(notify))
                return false;

            var nextcfg = HomeBuildingMgr.Instance.GetNextConfig(Config);
            if (!nextcfg.HasValue)
                return false;

            if (!HomeBuildingMgr.Instance.CanBuild(Config, nextcfg, notify))
                return false;

            return true;
        }

        [XLua.BlackList]
        public bool CanUpgrade_Cond(bool notify)
        {
            int condnum = Config.conditionLength;
            if (condnum > 0)
            {
                for (int i = 0; i < condnum; i++)
                {
                    int cond = Config.condition(i);
                    var cond_buildingcfg = HomeBuildingTableManager.GetData(cond);
                    if (!cond_buildingcfg.HasValue)
                        continue;

                    int cond_type = cond_buildingcfg.Value.type;
                    int cond_level = cond_buildingcfg.Value.level;


                    bool can_cond = false;

                    var buildingdata = HomeBuildingMgr.Instance.GetBuildingByCfgType(cond_type);
                    if (buildingdata != null)
                    {
                        if (!buildingdata.IsInBuilding)
                        {
                            if (buildingdata.Config.level >= cond_level)
                            {
                                can_cond = true;
                            }
                        }
                    }

                    if (!can_cond)
                    {
                        if (notify)
                        {
                            NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_HOME_LEVELUP_NOTENOUGH);
                        }

                        return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// 是否可以提示信息
        /// </summary>
        /// <returns></returns>
        public bool CanTipInfo()
        {
            if (Config.type == (int)swm.BuildingType.jiuguan)
            {
                return HomeWorkerModel.Instance.IsTavernRefresh();
            }
            else if (Config.type == (int)swm.BuildingType.lingtian)
            {
                var buildingInfoMgr = HomeFieldModel.Instance.buildingInfoMgr;
                if (buildingInfoMgr != null)
                {
                    var homePlantInfoMgr = buildingInfoMgr.GetPlantInfoMgr((uint)id);
                    if (homePlantInfoMgr != null)
                    {
                        int gainnum = homePlantInfoMgr.GetGainNum();
                        if (gainnum > 0)
                            return true;
                    }
                }
            }
            else if (Config.type == (int)swm.BuildingType.hexin)
            {
                return CanReceiveIncome();
            }

            return false;
        }

        /// <summary>
        /// 是否能领取收益
        /// </summary>
        /// <returns></returns>
        public bool CanReceiveIncome()
        {
            if (!IsInProduct)
                return false;

            // 没有产出时间的, 是没有产出的
            if (Config.period <= 0)
                return false;

            ulong servertime = GameScene.Instance.GetServerTime() / 1000;
            ulong starttime = (ulong)productTime;
            if (servertime < starttime)
                return false;

            return (servertime - starttime) > (uint)Config.period;
        }

        public bool IsTemp
        {
            get => id == HomeBuildingMgr.TEMP_BUILD_ID;
        }

        uint m_startTime;
        public uint StartTime
        {
            set => m_startTime = value;
            get => m_startTime;
        }

        private uint m_productTime;
        /// <summary>
        /// 生产时间
        /// </summary>
        public uint productTime
        {
            get { return m_productTime; }
            set { m_productTime = value; }
        }

        private uint m_levelupTime;
        /// <summary>
        /// 升级时间
        /// </summary>
        public uint levelupTime
        {
            get { return m_levelupTime; }
            set { m_levelupTime = value; }
        }


        private uint m_buildTime;
        /// <summary>
        /// 建造时间
        /// </summary>
        public uint buildTime
        {
            get { return m_buildTime; }
            set { m_buildTime = value; }
        }

        int m_laborID = 0;
        public int LaborID
        {
            get => m_laborID;
            set => m_laborID = value;
        }

        public bool IsBlocked
        {
            get => !HomeBuildingMgr.Instance.CheckBuildingPosValid(this);            
        }

        public int LeftTime
        {
            get
            {
                uint time = 0;
                if (IsInBuilding)
                {
                    time = buildTime;
                }
                else if (IsInUpgrade)
                {
                    time = levelupTime;
                }

                if(IsInBuilding || IsInUpgrade)
                {
                    return Config.duration - (int)(GameScene.Instance.GetServerTime() / 1000 - time);
                }
                else
                {
                    return 0;
                }
            }
        }

        public bool Overlaped(HomeBuildingInfo other)
        {
            if (m_rect.xMin >= other.Rect.xMax ||
                m_rect.xMax <= other.Rect.xMin ||
                m_rect.yMin >= other.Rect.yMax ||
                m_rect.yMax <= other.Rect.yMin)
                return false;
            return true;
        }
    }

    [XLua.LuaCallCSharp]
    public class HomeBuildingMgr : ClientSingleton<HomeBuildingMgr>
    {

        public const int MAX_BUILDING_COUNT = 200;

        public const int TEMP_BUILD_ID = 999999999;


        Dictionary<int, HomeBuildingInfo> m_HomeBuildingMap = new Dictionary<int, HomeBuildingInfo>(20);


        public Dictionary<int, HomeBuildingInfo> HomeBuildingMap
        {
            get { return m_HomeBuildingMap; }
        }

        public Event<int> OnBuildingInfoUpdate = new Event<int>();


        Dictionary<int, HomeBuildingInfo> m_needUpdateBuilding = new Dictionary<int, HomeBuildingInfo>(20);
        // List<HomeBuildingInfo> m_HomeBuildingList = new List<HomeBuildingInfo>(20);

        HomeBuildingInfo m_tempBuildInfo;
        public HomeBuildingInfo TempBuildInfo
        {
            get => m_tempBuildInfo;
        }

        RectInt m_buildRange;
        public RectInt BuildRange
        {
            get => m_buildRange;
        }


        int m_coreBuildingLevel;
        public int CoreBuildingLevel
        {
            get => m_coreBuildingLevel;
        }

        /// <summary>
        /// 当前紧密的建筑id
        /// </summary>
        private int m_currentCloseBuildingId = -1;

        #region 事件

        private GameEvent<int> m_onCloseBuildingEvent = new GameEvent<int>();
        public GameEvent<int> onCloseBuildingEvent
        {
            get { return m_onCloseBuildingEvent; }
        }


        private GameEvent<int> m_onRefreshBuildingInfoEvent = new GameEvent<int>();   
        public GameEvent<int> onRefreshBuildingInfoEvent
        {
            get { return m_onRefreshBuildingInfoEvent; }
        }

        #endregion

        public HomeBuildingMgr()
        {
        }

        

        public void Init()
        {

            m_buildRange = new RectInt(0, 0, 50, 50);

            //MsgDispatcher.instance.RegisterFBMsgProc<swm.RspHomeBuildingPos>(ProcRspHomeBuildingPos);  // 家园建筑数据
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspHomeBuildingInfo>(ProcRspHomeBuildingInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRecycleBuilding>(ProcRspRecycleBuilding);
            //MsgDispatcher.instance.RegisterFBMsgProc<swm.RspBuildLevelUp>(ProcRspBuildLevelUp);  // 
            //MsgDispatcher.instance.RegisterFBMsgProc<swm.RspBuildBuilding>(ProcRspBuildBuilding);    // 建造成功后返回 失败不返回
        }

        List<int> m_tempBuildIds;
        public void Clear()
        {
            if (m_tempBuildIds == null)
                m_tempBuildIds = new List<int>(10);
            m_tempBuildIds.AddRange(m_HomeBuildingMap.Keys);
            m_HomeBuildingMap.Clear();
            for (int i = 0; i < m_tempBuildIds.Count; i++)
                OnBuildingInfoUpdate.Invoke(m_tempBuildIds[i]);
            m_tempBuildIds.Clear();

            m_needUpdateBuilding.Clear();
        }

        public int BuildingCount { get => m_HomeBuildingMap.Count; }

        //List<int> m_needRemoveList = new List<int>(10);

        //[XLua.BlackList]
        //public void UpdateBuildingState()
        //{
        //    //if (m_needUpdateBuilding.Count == 0)
        //    //    return;

        //    //foreach(var v in m_needUpdateBuilding.Values)
        //    //{  
        //    //    if((v.IsInBuilding || v.IsInUpgrade)  &&v.LeftTime<=0)
        //    //    {
        //    //        RequestHomeBuildingInfo(v.id);
        //    //    }
        //    //}
        //}

        [XLua.BlackList]
        public void UpdateAutoReceiveIncome()
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return;

            // 家园外就不检测了
            if (mapinfo.maptype != (int)swm.MapType.Manor)
                return;

            foreach(var iter in m_HomeBuildingMap)
            {
                var buildingdata = iter.Value;
                if (buildingdata == null)
                    continue;

                // 是否手动领取
                var buildingcfg = buildingdata.Config;
                if (buildingcfg.ismanual > 0)
                    continue;

                bool canreceive = buildingdata.CanReceiveIncome();
                if (!canreceive)
                    continue;

                ReqBuildingGain_CS((uint)buildingdata.id);
            }
        }

        public HomeBuildingInfo GetBuildingByID(int id)
        {
            HomeBuildingInfo info;
            if (id == TEMP_BUILD_ID && m_tempBuildInfo != null)
                return m_tempBuildInfo;
            if(m_HomeBuildingMap.TryGetValue(id, out info ))
            {
                return info;
            }
            return null;
        }

        public HomeBuildingInfo GetBuildingByCfgId(int cfgid)
        {
            foreach (var iter in m_HomeBuildingMap)
            {
                var buildingdata = iter.Value;
                if (buildingdata == null)
                    continue;

                if (buildingdata.ConfigID == cfgid)
                {
                    return buildingdata;
                }
            }

            return null;
        }

        public HomeBuildingInfo GetBuildingByCfgType(int cfgid)
        {
            foreach (var iter in m_HomeBuildingMap)
            {
                var buildingdata = iter.Value;
                if (buildingdata == null)
                    continue;

                var buildingcfg = HomeBuildingTableManager.GetData(buildingdata.ConfigID);
                if (!buildingcfg.HasValue)
                    continue;

                if (buildingcfg.Value.type == cfgid)
                {
                    return buildingdata;
                }
            }

            return null;
        }

        public ICollection<HomeBuildingInfo> AllBuildings
        {
            get => m_HomeBuildingMap.Values;

        }

        #region 消息

        public void RequestHomeBuildingInfo(int id)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqHomeBuildingInfo.CreateReqHomeBuildingInfo(tFBB, (uint)id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeBuildingInfo.HashID, tFBB);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="uid">唯一id</param>
        /// <param name="baseid">建筑配置id</param>
        /// <param name="laborid">劳工id</param>
        public void ReqBuildLevelUp_CS(uint uid, uint baseid, uint laborid)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqBuildLevelUp.CreateReqBuildLevelUp(tFBB, uid, baseid, laborid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqBuildLevelUp.HashID, tFBB);
        }

        public void ReqBuildingGain_CS(uint uid)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqBuildingGain.CreateReqBuildingGain(tFBB, uid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqBuildingGain.HashID, tFBB);
        }

        #endregion

        HomeBuildingInfo m_buildinfoFormTemp;
        public bool RequestBuild(int configid, int laborid)
        {
            if (m_tempBuildInfo != null)
                return false;
            if (m_buildinfoFormTemp == null)
            {
                m_buildinfoFormTemp = new HomeBuildingInfo();
                m_buildinfoFormTemp.id = TEMP_BUILD_ID;
                
            }
            m_tempBuildInfo = m_buildinfoFormTemp;
            m_buildinfoFormTemp.ConfigID = configid;
            m_buildinfoFormTemp.State = 0;
            m_buildinfoFormTemp.Dir = 0;
            m_buildinfoFormTemp.LaborID = laborid;
            m_buildinfoFormTemp.Pos = new Vector2Int((int)m_buildRange.center.x, (int)m_buildRange.center.y);

            OnBuildingInfoUpdate.Invoke(m_tempBuildInfo.id);
            return true;
        }


        swm.ReqBuildBuildingT m_reqBuildBuilding;
        public bool ConfirmBuild()
        {
            if (!CheckBuildingPosValid(m_tempBuildInfo))
                return false;

            if (m_reqBuildBuilding == null)
            {
                m_reqBuildBuilding = new swm.ReqBuildBuildingT();
                m_reqBuildBuilding.pos = new swm.BuildingPosT();
            }

            m_reqBuildBuilding.baseid = (uint)m_tempBuildInfo.ConfigID;
            m_reqBuildBuilding.pos.left = (byte)m_tempBuildInfo.Pos.x;
            m_reqBuildBuilding.pos.top = (byte)m_tempBuildInfo.Pos.y;
            m_reqBuildBuilding.pos.dir = (byte)m_tempBuildInfo.Dir;
            m_reqBuildBuilding.laborid = (uint)m_tempBuildInfo.LaborID;

            MsgDispatcher.instance.SendFBPackage(m_reqBuildBuilding);
            m_tempBuildInfo = null;
            OnBuildingInfoUpdate.Invoke(TEMP_BUILD_ID);
            return true;
        }

        public void CancelBuild()
        {
            if(m_tempBuildInfo!=null)
            {
                m_tempBuildInfo = null;
                OnBuildingInfoUpdate.Invoke(TEMP_BUILD_ID);

            }

        }


        swm.ReqEditBuildingPosT m_ReqEditBuildingPos;
        public void RequestRestBuildingPos(HomeBuildingInfo info)
        {
            if (m_ReqEditBuildingPos == null)
            {
                m_ReqEditBuildingPos = new swm.ReqEditBuildingPosT();
            }
            m_ReqEditBuildingPos.pos.left = (byte)info.Pos.x;
            m_ReqEditBuildingPos.pos.top = (byte)info.Pos.y;
            m_ReqEditBuildingPos.pos.dir = (byte)info.Dir;
            m_ReqEditBuildingPos.uid = (uint)info.id;
            MsgDispatcher.instance.SendFBPackage(m_ReqEditBuildingPos);
        }

        public void RequestRecycleBuilding(int id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqRecycleBuilding.StartReqRecycleBuilding(fbb);
            swm.ReqRecycleBuilding.AddUid(fbb, (uint)id);
            fbb.Finish(swm.ReqRecycleBuilding.EndReqRecycleBuilding(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRecycleBuilding.HashID, fbb);
        }
        public void MakeBuildingInRange(HomeBuildingInfo info)
        {
            var newpos = info.Pos;

            var overleft =  m_buildRange.xMin - info.Rect.xMin;
            if (overleft > 0)
                newpos.x += overleft;

            var overright = info.Rect.xMax - m_buildRange.xMax;    
            if (overright > 0)
                newpos.x -= overright;

            var overtop = m_buildRange.yMin - info.Rect.yMin;
            if (overtop > 0)
                newpos.y += overtop;

            var overbottom = info.Rect.yMax - m_buildRange.yMax;
            if (overbottom > 0)
                newpos.y -= overbottom;
            info.Pos = newpos;
        }

        public bool CheckBuildingPosValid(HomeBuildingInfo info)
        {
            if (info == null)
                return false;

            foreach (var cinfo in m_HomeBuildingMap.Values)
            {
              
                if (cinfo == info)
                    continue;

                if (info.Overlaped(cinfo))
                    return false;

            }

            return true;

        }



        //void ProcRspHomeBuildingPos(swm.RspHomeBuildingPos msg)
        //{
        //    m_HomeBuildingMap.Clear();
        //    for(int i= 0;  i < msg.infoLength; i ++)
        //    {
        //        var minfo = msg.info(i).Value;

        //        RefreshHomeBuildingInfo(minfo);
        //    }
        //}

        [XLua.BlackList]
        public void RefreshHomeBuildingInfo(swm.RspHomeBuildingInfo msg)
        {
            HomeBuildingInfo info;
            var minfo = msg;

            if (!m_HomeBuildingMap.TryGetValue((int)minfo.uid, out info))
            {
                info = new HomeBuildingInfo();
                info.id = (int)minfo.uid;
                m_HomeBuildingMap.Add((int)minfo.uid, info);
            }

            info.ConfigID = (int)minfo.baseid;

            if (minfo.pos.HasValue)
            {
                info.Pos = new Vector2Int(minfo.pos.Value.left, minfo.pos.Value.top);
                info.Dir = minfo.pos.Value.dir;
            }

            info.rsptype = (int)minfo.rsptype;
            info.preState = info.State;
            info.State = (int)minfo.state;
            info.StartTime = (uint)minfo.stime;
            info.productTime = minfo.producttime;
            info.levelupTime = minfo.leveluptime;
            info.buildTime = minfo.buildtime;

            NotifyBuildingInfoUpdate(info);
        }

        [XLua.BlackList]
        public void ProcRspHomeBuildingInfo(swm.RspHomeBuildingInfo msg)
        {
            RefreshHomeBuildingInfo(msg);
        }

        void ProcRspRecycleBuilding(swm.RspRecycleBuilding msg)
        {
            if(msg.result==0)
            {
                if(m_HomeBuildingMap.ContainsKey((int)msg.uid ))
                {
                    m_HomeBuildingMap.Remove((int)msg.uid);

                    OnBuildingInfoUpdate.Invoke((int)msg.uid);
                }
            }
        }

        //void ProcRspBuildLevelUp(swm.RspBuildLevelUp msg)
        //{
        //    HomeBuildingInfo info;
        //    if (!m_HomeBuildingMap.TryGetValue((int)msg.uid, out info))
        //    {
        //        LogHelper.LogWarning("building not found!", msg.uid);
        //        return;
        //    }
        //    info.ConfigID = (int)msg.baseid;
        //    info.State = (int)msg.state;
        //    info.StartTime = (uint)msg.stime;
        //    NotifyBuildingInfoUpdate(info);
        //}

        //void ProcRspBuildBuilding(swm.RspBuildBuilding msg)
        //{
        //    HomeBuildingInfo info;
        //    if (!m_HomeBuildingMap.TryGetValue((int)msg.uid, out info))
        //    {
        //        info = new HomeBuildingInfo();
        //        info.id = (int)msg.uid;
        //        m_HomeBuildingMap.Add((int)msg.uid, info);
        //    }

        //    info.ConfigID = (int)msg.baseid;
        //    info.Pos = new Vector2Int(msg.pos.Value.left, msg.pos.Value.top);
        //    info.Dir = msg.pos.Value.dir;
        //    info.State = (int)msg.state;
        //    info.StartTime = (uint)msg.stime;
        //    NotifyBuildingInfoUpdate(info);
        //}

        //void ProcRspBuildingCurState(swm.RspBuildingCurState msg)
        //{
        //    HomeBuildingInfo info;
        //    if (!m_HomeBuildingMap.TryGetValue((int)msg.uid, out info))
        //    {
        //        LogHelper.LogWarning("RspBuildingCurState building not found!", msg.uid);
        //        return;
        //    }
        //    info.ConfigID = (int)msg.baseid;
        //    info.State = (int)msg.state;
        //    info.StartTime = msg.stime;

        //    NotifyBuildingInfoUpdate(info);
        //}

        void NotifyBuildingInfoUpdate(HomeBuildingInfo info)
        {
            if(info.IsInBuilding || info.IsInUpgrade)
            {
                if (!m_needUpdateBuilding.ContainsKey(info.id))
                    m_needUpdateBuilding.Add(info.id, info);
            }
            else
            {
                if(m_needUpdateBuilding.ContainsKey(info.id))
                {
                    m_needUpdateBuilding.Remove(info.id);
                }
            }

            if(info.Config.type == (int)swm.BuildingType.hexin)
            {
                m_coreBuildingLevel = info.Config.level;
                RefreshBuildRange(m_coreBuildingLevel);
            }

            OnBuildingInfoUpdate.Invoke(info.id);
        }

        void RefreshBuildRange(int level)
        {
            var info = HomeLevelTableManager.GetData(level);
            if (!info.HasValue)
                return;

            m_buildRange = new RectInt(info.Value.startpos(0), info.Value.startpos(1), info.Value.area(0), info.Value.area(1));
        }

        public void CheckIsCloseBuilding(bool forceexec = false)
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return;

            // 家园外面就不检测了
            if (mapinfo.maptype != (int)swm.MapType.Manor)
                return;

            var homemodel = HomeModel.Instance;
            if (homemodel == null)
                return;

            // 在编辑模式不触发
            if (!forceexec)
            {
                if (homemodel.editMode)
                    return;
            }

            var viewer = HomeBuildingViewer.Instance;
            if (viewer == null)
                return;

            int selbuildingid = viewer.GetCloseBuilding();

            if (forceexec || m_currentCloseBuildingId != selbuildingid)
            {
                m_currentCloseBuildingId = selbuildingid;
                m_onCloseBuildingEvent.Invoke(selbuildingid);
            }
        }

        /// <summary>
        /// 检测是否可以升级
        /// </summary>
        [XLua.BlackList]
        public void CheckCanUpgrade()
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return;

            // 家园外就不检测了
            if (mapinfo.maptype != (int)swm.MapType.Manor)
                return;

            foreach (var iter in m_HomeBuildingMap)
            {
                var uid = iter.Key;
                var buildingdata = iter.Value;
                if (buildingdata == null)
                    continue;

                if (buildingdata.IsInUpgrade || buildingdata.IsInBuilding)
                    continue;

                if (buildingdata.CanUpgrade())
                {
                    m_onRefreshBuildingInfoEvent.Invoke(uid);
                }
            }
        }

        /// <summary>
        /// 检测是否可以有提示信息
        /// </summary>
        [XLua.BlackList]
        public void CheckCanTip()
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return;

            // 家园外就不检测了
            if (mapinfo.maptype != (int)swm.MapType.Manor)
                return;

            foreach (var iter in m_HomeBuildingMap)
            {
                var uid = iter.Key;
                var buildingdata = iter.Value;
                if (buildingdata == null)
                    continue;

                if (buildingdata.IsInUpgrade || buildingdata.IsInBuilding)
                    continue;

                if (buildingdata.CanTipInfo())
                {
                    m_onRefreshBuildingInfoEvent.Invoke(uid);
                }
            }
        }

        public HomeBuildingTableBase? GetBuildingByTypeAndLvl(int type, int level)
        {
            int num = HomeBuildingTableManager.Instance.m_DataList.HomeBuildingTableLength;
            if (num > 0)
            {
                for (int i = 0; i < num; i++)
                {
                    var cfg = HomeBuildingTableManager.Instance.m_DataList.HomeBuildingTable(i);
                    if (!cfg.HasValue)
                        continue;

                    if (cfg.Value.type == type && cfg.Value.level == level)
                    {
                        return cfg;
                    }
                }
            }

            return null;
        }

        public HomeBuildingTableBase? GetNextConfig(HomeBuildingTableBase? curcfg)
        {
            int type = curcfg.Value.type;
            int level = curcfg.Value.level;
            int nextlevel = level + 1;

            return GetBuildingByTypeAndLvl(type, nextlevel);
        }
        
        public bool IsCoreBuildingUnlock(HomeBuildingTableBase? cfg)
        {
            var core_building_data = GetBuildingByCfgType((int)swm.BuildingType.hexin);
            if (core_building_data == null)
                return false;

            var core_building_cfg = HomeBuildingTableManager.GetData(core_building_data.ConfigID);
            if (!core_building_cfg.HasValue)
                return false;

            int core_building_lvl = core_building_cfg.Value.level;

            if (cfg.Value.reqcorelevel <= 0)
                return true;

            if (cfg.Value.reqcorelevel > 0)
            {
                if (core_building_lvl >= cfg.Value.reqcorelevel)
                    return true;
            }

            return false;
        }

        public bool CanBuild(HomeBuildingTableBase? curcfg, HomeBuildingTableBase? cfg, bool notify)
        {
            if (!cfg.HasValue)
                return false;

            var homebag = BagManager.Instance.GetBagByType((int)swm.BagType.HomeBag);
            if (homebag == null)
                return false;

            ulong ticket = BagManager.Instance.GetTicket();
            ulong food = BagManager.Instance.GetFood();

            if (!IsCoreBuildingUnlock(curcfg))
            {
                if (notify)
                {
                    NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_HOME_CORELEVEL_NOTENOUGH);
                }

                return false;
            }

            int num = cfg.Value.itemcostLength;
            if (num > 0)
            {
                for (int i = 0; i < num; i++)
                {
                    var stuff = cfg.Value.itemcost(i);
                    if (stuff.Value.listLength >= 2)
                    {
                        int stuff_itemid = stuff.Value.list(0);
                        int stuff_itemcnt = stuff.Value.list(1);

                        if (stuff_itemcnt > 0)
                        {
                            if (stuff_itemid == (int)swm.CoinType.TICKET)
                            {
                                if ((ulong)stuff_itemcnt > ticket)
                                {
                                    if (notify)
                                    {
                                        NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_HOME_MATERIAL_NOTENOUGH);
                                    }

                                    return false;
                                }
                            }
                            else if (stuff_itemid == (int)swm.CoinType.FOOD)
                            {
                                if ((ulong)stuff_itemcnt > food)
                                {
                                    if (notify)
                                    {
                                        NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_HOME_MATERIAL_NOTENOUGH);
                                    }

                                    return false;
                                }
                            }
                            else
                            {
                                var item = homebag.Item_Manager.GetItemByBaseID(stuff_itemid);
                                if (item == null)
                                {
                                    if (notify)
                                    {
                                        NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_HOME_MATERIAL_NOTENOUGH);
                                    }

                                    return false;
                                }

                                if (item.ItemNum < stuff_itemcnt)
                                {
                                    if (notify)
                                    {
                                        NotifyModel.Instance.GetInfoAndDispathTypeEvent(Game.TsInfoID.TS_HOME_MATERIAL_NOTENOUGH);
                                    }

                                    return false;
                                }
                            }
                        }
                    }
                }
            }

            return true;
        }
    }
}