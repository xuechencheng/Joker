using System.Collections.Generic;
using System;
using System.IO;

using Bokura;

using UnityEngine;

namespace Bokura
{

    [XLua.LuaCallCSharp]
    class HomeBuildingViewer : ClientSingleton<HomeBuildingViewer>
    {

        public const int GridSize = 2;

        public Color TileNormalColor = new Color(0.8f,0.8f,0.8f,0.6f);
        public Color TileSelectColor = new Color(0.1f, 0.8f, 0.1f, 0.6f);
        public Color TileBlockedColor = new Color(0.8f, 0.1f, 0.1f, 0.6f);

        Vector3 m_offset = new Vector3(-45,0.0f,-26.0f);
        public Vector3 Offset
        {
            get
            {
                return m_offset;
            }
            set
            {
                m_offset = value;
            }
        }

        bool m_isInEditMode = false;
        public bool IsInEditMode { get => m_isInEditMode; }


        Vector2Int m_originalSelectPos;
        int m_originalSelectDir;
        HomeBuilding m_curSelect;
        public HomeBuilding CurSelect
        {
            get => m_curSelect;
        }

        Dictionary<int, HomeBuilding> m_buildingList = new Dictionary<int, HomeBuilding>(20);
        public Dictionary<int, HomeBuilding> BuildingList { get { return m_buildingList; } }

        public Event OnSelectChange = new Event();
        public Event OnEditModeChange = new Event();
        public Event<int> OnAddBuildingFinish = new Event<int>();


        GameObject m_wallObject;
        GameObject m_editPlaneObject;

        private GameEvent<int> m_modelLoadEvent = new GameEvent<int>();
        public GameEvent<int> modelLoadEvent
        {
            get { return m_modelLoadEvent; }
        }

        public void Init()
        {
            GameScene.Instance.onEndLoading.AddListener(OnEndLoading);
        }

        void OnEndLoading()
        {

            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo==null)
                return;
            if(mapinfo.maptype == (int)swm.MapType.Manor)
            {
                Hide();
                Show();
                //GameApplication.Instance.GetTimerManager().AddTimer(Show,0.1f);
            }
            else
            {
                Hide();
            }
        }


        public void Show()
        {
            HomeBuildingMgr.Instance.OnBuildingInfoUpdate.AddListener(OnBuildInfoRefresh);

            foreach (var info in HomeBuildingMgr.Instance.AllBuildings)
            {
                var building = new HomeBuilding();
                building.SetInfo(info);

                m_buildingList.Add(info.id, building);
            }

            RefreshWall(HomeBuildingMgr.Instance.CoreBuildingLevel);

            HomePlantBuildingMgr.Instance.InitInfo();
        }

        public void Hide()
        {
            HomeBuildingMgr.Instance.OnBuildingInfoUpdate.RemoveListener(OnBuildInfoRefresh);

            HomePlantBuildingMgr.Instance.Release();

            foreach (var kv in m_buildingList)
            {
                kv.Value.Release();
            }
            m_buildingList.Clear();

            if(m_wallObject)
            {
                GameObject.Destroy(m_wallObject);
                m_wallObject = null;
            }
            if(m_editPlaneObject)
            {
                GameObject.Destroy(m_editPlaneObject);
                m_editPlaneObject = null;
            }
        }

        CameraControlMode m_prevCameraMode;
        public void EnterEditMode(float rotspeed = 1.0f)
        {
            if (m_isInEditMode)
                return;
            Select(null);
            m_isInEditMode = true;
            m_prevCameraMode = ICameraHelper.Instance.GetNowMode();
            ICameraHelper.Instance.SwitchController(CameraControlMode.HomeBuildCamera);

            var curcam = CameraHelper.Instance.CurrentController as HomeBuildCameraController;
            if (curcam != null)
            {
                curcam.rotStepSpeed = rotspeed;
            }

            foreach (var building in m_buildingList.Values)
            {
                building.TileVisible = true;
                building.TileColor = TileNormalColor;
                //building.TileColor = 
            }
            if(m_editPlaneObject)
            {
                m_editPlaneObject.SetActive(true);
            }
            OnEditModeChange.Invoke();
        }

        public void LeaveEditMode(float rotspeed = 1.0f)
        {
            if (!m_isInEditMode)
                return;
            Select(null);
            m_isInEditMode = false;
            ICameraHelper.Instance.SwitchController(m_prevCameraMode);

            var hcamera = ICameraHelper.Instance.CurrentController as CameraController;
            if (hcamera != null)
            {
                hcamera.StartTween();
                hcamera.tweenRotStepSpeed = rotspeed;
            }

            foreach (var building in m_buildingList.Values)
            {
                building.TileVisible = false;
            }
            if (m_editPlaneObject)
            {
                m_editPlaneObject.SetActive(false);
            }

            OnEditModeChange.Invoke();
        }

        public void Select(HomeBuilding building)
        {
            var prevSelect = m_curSelect;
            m_curSelect = building;// GetBuildingByMousePos();
            if (m_curSelect != prevSelect)
            {
                if(prevSelect!=null)
                {
                    prevSelect.TileColor = prevSelect.Info.IsBlocked ? TileBlockedColor : TileNormalColor;
                }
                
                if(m_curSelect!=null)
                {
                    m_originalSelectPos = m_curSelect.Info.Pos;
                    m_originalSelectDir = m_curSelect.Info.Dir;
                    m_curSelect.TileColor = m_curSelect.Info.IsBlocked ? TileBlockedColor : TileSelectColor;
                }

                OnSelectChange?.Invoke();
            }
        }

        public void MoveCamera(float dx, float dz)
        {
            var hcamera = ICameraHelper.Instance.CurrentController as HomeBuildCameraController;
            if(hcamera!=null)
                hcamera.MoveXZ(dx, dz);
        }

        public void LookAtBuilding(HomeBuilding building)
        {
            if (building == null)
                return;
            var hcamera = ICameraHelper.Instance.CurrentController as HomeBuildCameraController;
            hcamera.FlushAnimMove();

            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            var ray = mainCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0.0f));
            var plane = new Plane(Vector3.up, 0.0f);
            float dis;
            
            if (!plane.Raycast(ray, out dis))
                return;
            Vector3 curlookat = ray.GetPoint(dis);
            Vector3 delta = building.Position - curlookat;
            MoveCamera(delta.x, delta.z);
        }

        public HomeBuilding GetTempBuilding()
        {
            return GetBuildingById(HomeBuildingMgr.TEMP_BUILD_ID);
        }
        public HomeBuilding GetBuildingByMousePos()
        {
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            var pos = IUnityInput.Instance.mousePosition;
            Ray ray = mainCamera.ScreenPointToRay(pos);
            var mask = UserLayerMask.NPC;
            RaycastHit hitinfo;
            if (!Physics.Raycast(ray, out hitinfo, 1000.0f, (int)mask))
                return null;
            
            var aef = hitinfo.collider.GetComponentInParent<AvatarEventFinder>();
            if (!aef)
                return null;
            var building = aef.m_AvatarEvent as HomeBuilding;

            return building;

        }

        public HomeBuilding GetBuildingById(int id)
        {
            HomeBuilding building;
            if (m_buildingList.TryGetValue(id, out building))
                return building;
            return null;
        }

        public bool GetBuildingScreenPos(HomeBuilding building, out int x, out int y)
        {
            if (building == null)
            {
                x = 0;
                y = 0;
                return false;
            }
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            var spos = mainCamera.WorldToScreenPoint(building.Position);
            x = (int)spos.x;
            y = (int)spos.y;

            if (spos.z < 0.0f)
            {
                return false;
            }

            return true;
        }

        public void GetbuildingViewPos(HomeBuilding building, out float x, out float y)
        {
            if (building == null)
            {
                x = 0.0f;
                y = 0.0f;
                return;
            }
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            var vpos = mainCamera.WorldToViewportPoint(building.Position);
            x = vpos.x;
            y = vpos.y;
        }
        public bool SetSelectBuildingScreenPos(int x, int y)
        {
            var building = m_curSelect;
            if (building == null)
                return false;
            var oldpos = building.Position;
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            var pos = new Vector2(x, y);
            Ray ray = mainCamera.ScreenPointToRay(pos);
            var mask = (int)UserLayerMask.TerrainObject | (int)UserLayerMask.Terrain;
            RaycastHit hitinfo;

            if (!Physics.Raycast(ray, out hitinfo, 100.0f, (int)mask))
                return false;
            var newpos = hitinfo.point;
            var dx = newpos - oldpos;
            dx /= GridSize;
            dx.y = 0.0f;
            dx.x = ((int)dx.x)*GridSize;
            dx.z = ((int)dx.z) * GridSize; ;
            building.Position += dx;
            building.UpdatePosFromShowPos();

            if(!building.IsShowPosSameInfoPos())
                building.UpdateShowPosFromInfo();
            bool blocked = building.Info.IsBlocked;
            building.TileColor = blocked ? TileBlockedColor : TileSelectColor;

            return blocked;

        }



        public bool SetSelectBuildingDir(int dir)
        {
            var building = m_curSelect;
            if (building == null)
                return false;
            building.Info.Dir = dir;
            building.UpdatePosFromShowPos();
            building.UpdateShowPosFromInfo();
            bool blocked = building.Info.IsBlocked;
            building.TileColor = blocked ? TileBlockedColor : TileSelectColor;

            return blocked;

        }

        public bool CancelSelectModify()
        {
            var building = m_curSelect;
            if (building == null)
                return false;

            if (m_curSelect.Info.IsTemp)
            {
                HomeBuildingMgr.Instance.CancelBuild();
            }
            else
            {
                building.Info.Pos = m_originalSelectPos;
                building.Info.Dir = m_originalSelectDir;
                building.UpdateShowPosFromInfo();
            }

            return true;
        }

        public bool ApplySelectModify()
        {
            var building = m_curSelect;
            if (building == null)
                return false;
            if (building.Info.IsBlocked)
                return false;
            if(building.Info.IsTemp)
            {
                HomeBuildingMgr.Instance.ConfirmBuild();
            }
            else
            {
                HomeBuildingMgr.Instance.RequestRestBuildingPos(building.Info);
            }
            return true;
        }



        Collider[] m_overlappedColliders = new Collider[10];
        Vector3[] m_posCheck = new Vector3[4];
        void CheckMainCharCollide()
        {
            if (!GameScene.Instance.MainChar)
                return;
            var cc = GameScene.Instance.MainChar.CC;
            if (!cc)
                return;
            var charpos = GameScene.Instance.MainChar.Position;
            var d = new Vector3(0.0f, cc.height , 0.0f);
            int n = Physics.OverlapCapsuleNonAlloc(charpos, charpos + d, cc.radius, m_overlappedColliders, (int)UserLayerMask.Default);
            int sz = Math.Min(n, m_overlappedColliders.Length);
            for(int i = 0; i < sz; i ++)
            {
                var aef = m_overlappedColliders[i].GetComponentInParent<AvatarEventFinder>();
                if (!aef)
                    continue;
                var building = aef.m_AvatarEvent as HomeBuilding;
                if (building == null) 
                    continue;

                
                var halfWidth = new Vector3(building.Info.Rect.width, 0.0f, 0.0f);
                var halfHeight = new Vector3(0.0f, 0.0f, building.Info.Rect.height);

                m_posCheck[0] = building.Position - halfWidth;
                m_posCheck[1] = building.Position + halfWidth;
                m_posCheck[2] = building.Position - halfHeight;
                m_posCheck[3] = building.Position + halfHeight;
                Vector3 closep = charpos;
                var dis = float.MaxValue;
                for(int c = 0; c <m_posCheck.Length; c ++ )
                {
                    var newdis = (charpos - m_posCheck[c]).sqrMagnitude;
                    if (newdis < dis)
                    {
                        closep = m_posCheck[c];
                        dis = newdis;
                    }
                }

                GameScene.Instance.MainChar.Position = closep + Vector3.up;
                   

                break;
            }
        }

        void OnBuildInfoRefresh(int id)
        {
            HomeBuilding building = null;
            var info = HomeBuildingMgr.Instance.GetBuildingByID(id);

            if (!m_buildingList.TryGetValue(id, out building) && info != null)
            {
                building = new HomeBuilding();
                m_buildingList.Add(id, building);
            }

            if (info != null)
            {
                building.SetInfo(info);
                building.TileVisible = m_isInEditMode;
                building.TileColor = building.Info.IsBlocked ? TileBlockedColor : (building == m_curSelect ? TileSelectColor : TileNormalColor);

                if (info.Config.type == (int)swm.BuildingType.hexin)
                {
                    RefreshWall(info.Config.level);
                }

                CheckMainCharCollide();
            }
            else if (building != null)
            {
                if (building == m_curSelect)
                {
                    Select(null);
                }

                building.Release();
                m_buildingList.Remove(id);
            }

            if (building != null)
            {
                building.PlayLevelupEff();
            }

            // 灵田始终是增加的, 不删除
            HomePlantBuildingMgr.Instance.Add(info);

            OnAddBuildingFinish.Invoke(id);
        }

        int m_curWallLevel = 0;
        void RefreshWall(int level)
        {
            var config = HomeLevelTableManager.GetData(level);
            if (!config.HasValue)
                return;
            if (m_wallObject && m_curWallLevel == level)
                return;
            m_curWallLevel = level;
            if (m_wallObject)
                GameObject.Destroy(m_wallObject);
            if (m_editPlaneObject)
                GameObject.Destroy(m_editPlaneObject);

            m_wallObject = null;
            ResourceHelper.LoadPrefabAsync(HomeBuilding.ModelDir, config.Value.wallmodel, (UnityEngine.Object res) =>
            {
                var wallres = res as GameObject;
                if (wallres)
                {
                    m_wallObject = GameObject.Instantiate(wallres);
                    m_wallObject.transform.position = Offset;

                }
                else
                {
                    LogHelper.LogWarning("[HC]cant load wall res", config.Value.wallmodel);
                }
            });
          
            ResourceHelper.LoadPrefabAsync(HomeBuilding.ModelDir, config.Value.editmodel, (UnityEngine.Object res)=>
            {
                var planeres = res as GameObject;
                if (planeres)
                {
                    m_editPlaneObject = GameObject.Instantiate(planeres);
                    m_editPlaneObject.transform.position = Offset;
                    m_editPlaneObject.SetActive(IsInEditMode);
                }
                else
                {
                    LogHelper.LogWarning("[HC]cant load edit plane res", config.Value.wallmodel);
                }
            });
            
        }




        [XLua.BlackList]
        public int GetCloseBuilding()
        {
            int selbuildingid = -1;

            var MainChar = GameScene.Instance.MainChar;
            if (null == MainChar)
                return selbuildingid;

            foreach (var iter in m_buildingList)
            {
                HomeBuilding building = iter.Value;
                if (building == null)
                    continue;

                HomeBuildingInfo buildinginfo = building.Info;
                if (buildinginfo == null)
                    continue;

                int width = buildinginfo.Rect.width;
                int height = buildinginfo.Rect.height;

                float sqrDis = (building.Position - MainChar.Position).sqrMagnitude;
                int closedis = width > height ? width : height;
                float sqrclose = (float)(closedis * closedis) + 2.0f;
                if (sqrDis < sqrclose)
                {
                    selbuildingid = buildinginfo.id;
                    break;
                }
            }

            return selbuildingid;
        }
    }
}