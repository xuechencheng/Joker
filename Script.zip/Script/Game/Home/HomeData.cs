using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FlatBuffers;
using swm;
using LitJson;

namespace Bokura
{

    public class HomeCfgInfo
    {
        /// <summary>
        /// 田的最大数目
        /// </summary>
        public int Field_Max_Num;

        /// <summary>
        /// 田的行数
        /// </summary>
        public int Field_Row_Num;

        /// <summary>
        /// 田的列数
        /// </summary>
        public int Field_Column_Num;

        /// <summary>
        /// 灵田格子尺寸
        /// </summary>
        public float Field_Grid_Size;

        [XLua.BlackList]
        public void Load()
        {
            var cfg = GameCfgTableManager.GetData((int)GameCfgID.Home_Field_Max_Num);
            if (cfg != null)
            {
                try
                {

                    Field_Max_Num = (int)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Home_Field_Row_Num);
            if (cfg != null)
            {
                try
                {
                    Field_Row_Num = (int)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Home_Field_Column_Num);
            if (cfg != null)
            {
                try
                {
                    Field_Column_Num = (int)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Home_Field_Grid_Size);
            if (cfg != null)
            {
                try
                {
                    Field_Grid_Size = float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }
        }
    }

    public class HomeMainInfoTest
    {
        /// <summary>
        /// 粮食 谷物 上限
        /// </summary>
        public uint max_cereals;

        /// <summary>
        /// 当前工人数量
        /// </summary>
        public ushort cur_workers_num = 0;

        /// <summary>
        /// 最大工人数量
        /// </summary>
        public ushort max_workers_num = 0;

        /// <summary>
        /// 处于休息中的工人
        /// </summary>
        public ushort sleep_workers_num;

        [XLua.BlackList]
        public void Refresh(RspHomeMainInfo msg)
        {
            max_cereals = msg.max_cereals;
            cur_workers_num = msg.cur_workers_num;
            max_workers_num = msg.max_workers_num;
        }

    }


    public class HomeEventInfo
    {
        /// <summary>
        /// 事件类型
        /// </summary>
        public uint etype;

        /// <summary>
        /// 建筑配置id
        /// </summary>
        public uint baseid;

        /// <summary>
        /// 事件发生时间
        /// </summary>
        public uint deadline;

        /// <summary>
        /// 是否已经提示过红点
        /// </summary>
        public bool hasnotify = false;

        /// <summary>
        /// 是否显示红点
        /// </summary>
        /// <returns></returns>
        public bool CanShowRedpoint()
        {
            if (hasnotify)
                return false;

            if (deadline <= 0)
                return false;

            ulong curtime = (ulong)deadline * 1000;
            ulong servertime = GameScene.Instance.GetServerTime();
            bool isendtime = (servertime > curtime);

            if (isendtime)
            {
                hasnotify = true;
            }

            return isendtime;
        }

        [XLua.BlackList]
        public void Refresh(ManorForecastInfo msg)
        {
            etype = msg.etype;
            baseid = msg.baseid;
            deadline = msg.deadline;
        }
    }

    public class HomeEventInfoMgr
    {
        private List<HomeEventInfo> m_eventlist = new List<HomeEventInfo>(Const.kCap8);
        public List<HomeEventInfo> eventlist
        {
            get { return m_eventlist; }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_eventlist.Clear();
        }

        [XLua.BlackList]
        public void Refresh(RspManorForecast msg)
        {
            m_eventlist.Clear();

            int num = msg.forecastsLength;
            for (int i = 0; i < num; i++)
            {
                ManorForecastInfo? swminfo = msg.forecasts(i);
                if (!swminfo.HasValue)
                    continue;

                HomeEventInfo eventinfo = new HomeEventInfo();
                eventinfo.Refresh(swminfo.Value);
                m_eventlist.Add(eventinfo);
            }
        }

        [XLua.BlackList]
        public bool CheckRedpointState()
        {
            bool haseventupdate = false;

            foreach (var eventdata in m_eventlist)
            {
                if (eventdata == null)
                    continue;

                bool showredpoint = eventdata.CanShowRedpoint();
                if (showredpoint)
                {
                    haseventupdate = true;
                    break;
                }
            }

            return haseventupdate;
        }
    }

    public class HomeFaZhenInfo
    {
        /// <summary>
        /// 法阵的唯一id
        /// </summary>
        public uint uid;

        /// <summary>
        /// 法阵id(对应配置中的id)
        /// </summary>
        public uint fazhen_id;

        /// <summary>
        /// 法阵的到期时间
        /// </summary>
        public uint deadline;

        /// <summary>
        /// 法阵的匹配程度
        /// </summary>
        public int suitable;

        [XLua.BlackList]
        public void Refresh(swm.FaZhenInfo info)
        {
            uid = info.id;
            fazhen_id = info.fazhen_id;
            deadline = info.deadline;
            suitable = (int)info.suitable;
        }
    }

    public class HomeFaZhenBuildingInfo
    {
        /// <summary>
        /// 炼妖法阵的id
        /// </summary>
        public uint building_uid;

        /// <summary>
        /// 法阵列表
        /// </summary>    
        private Dictionary<uint, HomeFaZhenInfo> m_fazhendict = new Dictionary<uint, HomeFaZhenInfo>(Const.kCap8);

        [XLua.BlackList]
        public void Refresh(swm.FaZhenBuildingInfo building_info)
        {
            building_uid = building_info.building_uid;

            m_fazhendict.Clear();

            for(int i = 0; i < building_info.fazhenLength; i++)
            {
                swm.FaZhenInfo? swminfo = building_info.fazhen(i);
                if (!swminfo.HasValue)
                    continue;

                HomeFaZhenInfo info = new HomeFaZhenInfo();
                info.Refresh(swminfo.Value);
                m_fazhendict.Add(swminfo.Value.id, info);
            }
        }

        [XLua.BlackList]
        public void Refresh(swm.FaZhenInfo info)
        {
            HomeFaZhenInfo fazheninfo = null;
            m_fazhendict.TryGetValue(info.id, out fazheninfo);

            if (fazheninfo == null)
                return;

            fazheninfo.Refresh(info);
        }
    }


    public class HomeFaZhenBuildingInfoMgr
    {
        private Dictionary<uint, HomeFaZhenBuildingInfo> m_buildingDict = new Dictionary<uint, HomeFaZhenBuildingInfo>(Const.kCap8);

        [XLua.BlackList]
        public void Refresh(swm.RspHomeFaZhenInfo info)
        {
            m_buildingDict.Clear();

            for (int i = 0; i < info.fazhen_buildingLength; i++)
            {
                swm.FaZhenBuildingInfo? swminfo = info.fazhen_building(i);
                if (!swminfo.HasValue)
                    continue;

                HomeFaZhenBuildingInfo buildinginfo = new HomeFaZhenBuildingInfo();
                buildinginfo.Refresh(swminfo.Value);
                m_buildingDict.Add(swminfo.Value.building_uid, buildinginfo);
            }
        }

        [XLua.BlackList]
        public void Refresh(swm.RspOpenHomeFaZhen msg)
        {
            if (!msg.fazhen.HasValue)
                return;

            HomeFaZhenBuildingInfo info = null;
            m_buildingDict.TryGetValue(msg.building_uid, out info);

            if (info == null)
                return;

            info.Refresh(msg.fazhen.Value);
        }
    }
}


