

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FlatBuffers;
using swm;
using LitJson;
using Bokura;
using Vector3 = UnityEngine.Vector3;

namespace Bokura
{
    public class HomePlantInfo
    {
        /// <summary>
        /// 格子id
        /// </summary>
        public uint slot_id;

        /// <summary>
        /// 种子id
        /// </summary>
        public uint seed_id;

        /// <summary>
        /// 到期时间
        /// </summary>
        public ulong deadline;


        private HomeSeedTableBase? m_config;
        public HomeSeedTableBase Config
        {
            get
            {
                if (m_config.HasValue)
                    return m_config.Value;

                m_config = HomeSeedTableManager.GetData((int)seed_id);
                return m_config.Value;
            }
        }


        /// <summary>
        /// 是否可收获
        /// </summary>
        /// <returns></returns>
        public bool CanGain()
        {
            ulong curtime = deadline * 1000;
            ulong servertime = GameScene.Instance.GetServerTime();
            return (servertime > curtime);
        }
    }

    public class HomePlantInfoMgr
    {
        [XLua.BlackList]
        public void Clear()
        {
            m_fieldInfoDict.Clear();
        }

        private Dictionary<uint, HomePlantInfo> m_fieldInfoDict = new Dictionary<uint, HomePlantInfo>(Const.kCap16);
        public Dictionary<uint, HomePlantInfo> fieldInfoDict
        {
            get { return m_fieldInfoDict; }
        }


        private uint m_field_uid;
        /// <summary>
        /// 建筑id
        /// </summary>
        public uint field_uid
        {
            get { return m_field_uid; }
        }

        /// <summary>
        /// 获取空闲的孔位
        /// </summary>
        /// <returns></returns>
        public int GetEmptySlotId()
        {
            int Field_Max_Num = HomeModel.Instance.cfgInfo.Field_Max_Num;
            for (int i = 1; i <= Field_Max_Num; i++)
            {
                if (!m_fieldInfoDict.ContainsKey((uint)i))
                {
                    return i;
                }
            }

            return 0;
        }

        /// <summary>
        /// 获取收获数目
        /// </summary>
        /// <returns></returns>
        public int GetGainNum()
        {
            int num = 0;
            foreach (var iter in m_fieldInfoDict)
            {
                HomePlantInfo info = iter.Value;
                if (info == null)
                    continue;

                if (info.CanGain())
                {
                    num++;
                }
            }

            return num;
        }

        [XLua.BlackList]
        public void RefreshGainInfo(RspHomeGain msg)
        {
            for (int i = 0; i < msg.gain_slotsLength; i++)
            {
                uint gain_slot = msg.gain_slots(i);
                m_fieldInfoDict.Remove(gain_slot);
            }
        }

        [XLua.BlackList]
        public void RefreshAllFieldInfo(HomeFieldInfo msg)
        {
            m_field_uid = msg.field_uid;

            m_fieldInfoDict.Clear();

            for (int i = 0; i < msg.field_slotLength; i++)
            {
                swm.HomeFieldSlotInfo? swmfieldinfo = msg.field_slot(i);
                if (!swmfieldinfo.HasValue)
                    continue;

                HomePlantInfo fieldinfo = new HomePlantInfo();
                fieldinfo.slot_id = swmfieldinfo.Value.slot_id;
                fieldinfo.seed_id = swmfieldinfo.Value.seed_id;
                fieldinfo.deadline = swmfieldinfo.Value.deadline;

                if (!m_fieldInfoDict.ContainsKey(fieldinfo.slot_id))
                {
                    m_fieldInfoDict.Add(fieldinfo.slot_id, fieldinfo);
                }
            }
        }

        [XLua.BlackList]
        public void RefreshPlantInfo(RspHomePlanting msg)
        {
            int field_slot_num = msg.field_slotLength;
            for (int i = 0; i < field_slot_num; i++)
            {
                swm.HomeFieldSlotInfo? swmfieldinfo = msg.field_slot(i);
                if (!swmfieldinfo.HasValue)
                    continue;

                uint slot_id = swmfieldinfo.Value.slot_id;
                uint seed_id = swmfieldinfo.Value.seed_id;
                ulong deadline = swmfieldinfo.Value.deadline;
                if (m_fieldInfoDict.ContainsKey(slot_id))
                {
                    HomePlantInfo plantinfo = m_fieldInfoDict[slot_id];
                    plantinfo.seed_id = seed_id;
                    plantinfo.deadline = deadline;
                }
                else
                {
                    HomePlantInfo plantinfo = new HomePlantInfo();
                    plantinfo.slot_id = slot_id;
                    plantinfo.seed_id = seed_id;
                    plantinfo.deadline = deadline;

                    m_fieldInfoDict.Add(slot_id, plantinfo);
                }
            }
        }
    }

    /// <summary>
    /// 种植信息管理(多灵田)
    /// </summary>
    public class HomePlantBuildingInfoMgr
    {
        private Dictionary<uint, HomePlantInfoMgr> m_buildingDict = new Dictionary<uint, HomePlantInfoMgr>(Const.kCap16);

        public Dictionary<uint, HomePlantInfoMgr> buildingDict
        {
            get { return m_buildingDict; }
        }

        public HomePlantInfoMgr GetPlantInfoMgr(uint field_uid)
        {
            HomePlantInfoMgr plantinfomgr = null;
            m_buildingDict.TryGetValue(field_uid, out plantinfomgr);

            return plantinfomgr;
        }


        private List<ItemBase> m_seedList = new List<ItemBase>();
        /// <summary>
        /// 背包里的种子列表
        /// </summary>
        public List<ItemBase> seedList
        {
            get { return m_seedList; }
        }


        [XLua.BlackList]
        public void Clear()
        {
            foreach (var iter in m_buildingDict)
            {
                HomePlantInfoMgr plantinfomgr = iter.Value;
                if (plantinfomgr == null)
                    continue;

                plantinfomgr.Clear();
            }

            m_buildingDict.Clear();
        }

        [XLua.BlackList]
        public void RefreshAllFieldInfo(RspHomeFieldInfo msg)
        {
            Clear();

            int buildingnum = msg.field_infoLength;
            for (int i = 0; i < buildingnum; i++)
            {
                swm.HomeFieldInfo? swmfieldinfo = msg.field_info(i);
                if (!swmfieldinfo.HasValue)
                    continue;

                uint field_uid = swmfieldinfo.Value.field_uid;
                if (m_buildingDict.ContainsKey(field_uid))
                    continue;

                HomePlantInfoMgr plantmgr = new HomePlantInfoMgr();
                plantmgr.RefreshAllFieldInfo(swmfieldinfo.Value);

                m_buildingDict.Add(field_uid, plantmgr);
            }
        }

        [XLua.BlackList]
        public void RefreshPlantInfo(RspHomePlanting msg)
        {
            HomePlantInfoMgr plantinfomgr = null;
            m_buildingDict.TryGetValue(msg.field_uid, out plantinfomgr);

            if (plantinfomgr == null)
            {
                plantinfomgr = new HomePlantInfoMgr();
                m_buildingDict.Add(msg.field_uid, plantinfomgr);
            }

            if (plantinfomgr != null)
            {
                plantinfomgr.RefreshPlantInfo(msg);
            }
        }

        [XLua.BlackList]
        public void RefreshGainInfo(RspHomeGain msg)
        {
            HomePlantInfoMgr plantinfomgr = null;
            m_buildingDict.TryGetValue(msg.field_uid, out plantinfomgr);

            if (plantinfomgr == null)
            {
                plantinfomgr = new HomePlantInfoMgr();
                m_buildingDict.Add(msg.field_uid, plantinfomgr);
            }

            if (plantinfomgr != null)
            {
                plantinfomgr.RefreshGainInfo(msg);
            }
        }

        /// <summary>
        /// 计算背包里的种子列表
        /// </summary>
        public void CalcSeedListInBag()
        {
            m_seedList.Clear();

            var bag = BagManager.Instance.GetBagByType(swm.BagType.ItemBag);
            if (bag == null)
                return;

            var itemlist = bag.Item_Manager.GetItemList();
            if (itemlist == null)
                return;

            for (int i = 0; i < itemlist.Count; i++)
            {
                ItemBase item = itemlist[i];
                if (item == null)
                    continue;

                var seedcfg = HomeSeedTableManager.GetData(item.BaseID);
                if (seedcfg == null)
                    continue;

                m_seedList.Add(item);
            }
        }
    }

    public class HomePlant : AvatarEvent
    {
        //public const string ModelDir = "art_resource/environment/LV/Common/prefabs/Foliage/";
        public const string ModelDir = "";

        /// <summary>
        /// 种植中的颜色
        /// </summary>
        private Color Tile_Planting_Color = new Color(0.1f, 0.8f, 0.1f, 0.6f);

        /// <summary>
        /// 被种植的颜色
        /// </summary>
        private Color Tile_Planted_Color = new Color(1.0f, 0.52f, 0.28f, 0.6f);

        private int m_building_uid;
        public int building_uid
        {
            get { return m_building_uid; }
        }

        public Vector3 Position
        {
            get
            {
                var building = HomeBuildingViewer.Instance.GetBuildingById(building_uid);
                if (building == null)
                    return Vector3.zero;

                var trans = building.GetTrans();
                if (trans == null)
                    return Vector3.zero;

                //Vector3 pos = building.Position;
                var relative_pos = trans.TransformPoint(m_relative_pos);
                //pos += relative_pos;
                return relative_pos;
            }
        }

        private Vector3 m_relative_pos;
        public Vector3 relative_pos
        {
            get { return m_relative_pos; }
        }

        private bool m_tileVis = false;
        public bool tileVis
        {
            get { return m_tileVis; }
            set
            {
                m_tileVis = value;
                if (m_tile)
                    m_tileRenderer.enabled = m_tileVis;
            }
        }


        private Color m_tileColor = Color.white;
        public Color tileColor
        {
            get { return m_tileColor; }
            set
            {
                m_tileColor = value;

                if (m_tileMat)
                    m_tileMat.color = m_tileColor;
            }
        }


        private HomePlantInfo m_plantInfo = null;
        public HomePlantInfo plantInfo
        {
            get { return m_plantInfo; }
        }


        private GameObject m_tile;

        private Renderer m_tileRenderer;

        private Material m_tileMat;

        private IAvatar m_model = null;

        private string m_loadmodel;

        /// <summary>
        /// 是否在种植中
        /// </summary>
        private bool m_inPlanting = false;

        public HomePlant()
        {
            m_model = IFactory.Instance.CreateAvatar(this);
            m_model.onCreate.AddListener(OnAvatarCreateDelegate);
        }

        public void SetInfo(int uid, HomePlantInfo info)
        {
            if (info == null)
                return;

            m_building_uid = uid;
            m_plantInfo = info;

            m_relative_pos = HomePlantBuildingMgr.CalcRelativePos((int)m_plantInfo.slot_id);

            string modelpath = info.Config.modelpath;
            string model = info.Config.model;

            if (m_loadmodel != model)
            {
                m_loadmodel = model;
                m_model.LoadModel(modelpath, model, true);
            }
        }     

        public void RefreshTile()
        {
            if (m_inPlanting)
            {
                tileVis = true;
                tileColor = Tile_Planted_Color;
            }
            else
            {
                tileVis = false;
                tileColor = Tile_Planting_Color;
            }
        }

        public void Refresh(int building_uid, HomePlantInfo info)
        {
            if (info == null)
                return;

            if (m_plantInfo == null)
                return;

            if (info.slot_id == m_plantInfo.slot_id)
            {
                SetVisible(true);
                RefreshTile();
            }
            else
            {
                Release();
                SetInfo(building_uid, info);
            }
        }

        public void Release()
        {
            if (null != m_model)
            {
                m_model.Release();
                IFactory.Instance.ReleaseAvatar(m_model);
                m_model = null;
            }
        }

        private void OnAvatarCreateDelegate()
        {
            m_model.SetLayer((int)UserLayer.Layer_Default);

            HomeBuilding building = HomeBuildingViewer.Instance.GetBuildingById(m_building_uid);
            if (building != null)
            {
                m_model.unityObject.transform.SetParent(building.GetTrans());
                m_model.unityObject.transform.localScale = Vector3.one;
                m_model.unityObject.transform.localRotation = Quaternion.identity;

                m_model.SetPosition(m_relative_pos);

                float modelscale = (float)m_plantInfo.Config.modelscale;
                m_model.SetScale(modelscale, modelscale, modelscale);

                CreateTile();
                RefreshTile();
            }
        }

        private void CreateTile()
        {
            if (!m_tile)
            {
                m_tile = GameObject.CreatePrimitive(PrimitiveType.Cube);

                m_tile.transform.localPosition = Vector3.zero;
                m_tile.layer = (int)UserLayer.Layer_NPC;
                var render = m_tile.GetComponent<Renderer>();
                m_tileRenderer = render;
                if (render)
                {
                    var shader = ResourceHelper.LoadShaderSync("shaders/", "Alpha-DiffuseNoZ") as Shader;
                    m_tileMat = new Material(shader);
                    render.material = m_tileMat;

                    m_tileMat.color = m_tileColor;
                }
            }

            m_tileRenderer.enabled = m_tileVis;

            float Field_Grid_Size = HomeModel.Instance.cfgInfo.Field_Grid_Size;
            float tilesize = Field_Grid_Size * 1.0f;
            tilesize *= (1.0f / (float)m_plantInfo.Config.modelscale);
            m_tile.transform.localScale = new Vector3(tilesize, 0.1f, tilesize);

            m_tile.transform.SetParent(m_model.unityObject.transform, false);
        }

        [XLua.BlackList]
        public void RefreshPos(Vector3 pos)
        {
            if (m_model != null)
            {
                m_model.SetPosition(pos);
            }
        }

        public void SetVisible(bool vis)
        {
            if (m_model == null)
                return;

            m_model.Visible = vis;
        }

        public void SetPlantState(bool plant)
        {
            m_inPlanting = plant;
        }

        public void SetTileVis(bool vis)
        {
            if (m_tile == null)
                return;

            tileVis = vis;
        }
    }

    public class HomePlantBuilding
    {
        private int m_field_uid;
        public int field_uid
        {
            get { return m_field_uid; }
            set { m_field_uid = value; }
        }

        /// <summary>
        /// 是否在种植中
        /// </summary>
        private bool m_inPlanting = false;

        private Dictionary<uint, HomePlant> m_plantDict = new Dictionary<uint, HomePlant>(Const.kCap16);


        private HomePlantInfoMgr m_plantinfomgr;

        [XLua.BlackList]
        public void Release()
        {
            m_plantinfomgr = null;

            foreach (var iter in m_plantDict)
            {
                HomePlant plant = iter.Value;
                if (plant == null)
                    continue;

                plant.Release();
            }
        }

        [XLua.BlackList]
        public void SetInfo()
        {
            var plantinfomgr = m_plantinfomgr;
            if (plantinfomgr == null)
                return;

            var fieldInfoDict = plantinfomgr.fieldInfoDict;
            if (fieldInfoDict == null)
                return;

            foreach (var iter in fieldInfoDict)
            {
                uint slotid = iter.Key;
                HomePlantInfo plantinfo = iter.Value;
                if (plantinfo == null)
                    continue;

                HomePlant plant = null;
                m_plantDict.TryGetValue(slotid, out plant);

                if (plant == null)
                {
                    plant = new HomePlant();
                    plant.SetPlantState(m_inPlanting);
                    plant.SetInfo(m_field_uid, plantinfo);

                    m_plantDict.Add(slotid, plant);
                }
                else
                {
                    plant.SetPlantState(m_inPlanting);
                    plant.Refresh(m_field_uid, plantinfo);
                }
            }
        }

        [XLua.BlackList]
        public void Refresh()
        {
            SetVisible(false);
            SetInfo();
        }

        [XLua.BlackList]
        public void SetPlantInfoMgr(HomePlantInfoMgr plantinfomgr)
        {
            m_plantinfomgr = plantinfomgr;
        }

        public void SetPlantState(bool isplant)
        {
            if (m_plantDict == null)
                return;

            m_inPlanting = isplant;
            foreach (var iter in m_plantDict)
            {
                HomePlant plant = iter.Value;
                if (plant == null)
                    continue;

                plant.SetPlantState(isplant);
            }
        }

        public void SetVisible(bool vis)
        {
            if (m_plantDict == null)
                return;

            foreach (var iter in m_plantDict)
            {
                HomePlant plant = iter.Value;
                if (plant == null)
                    continue;

                plant.SetVisible(vis);

                if (!vis)
                {
                    plant.SetTileVis(false);
                }
            }
        }

        public HomePlant GetPlant(int slot_id)
        {
            HomePlant plant = null;
            m_plantDict.TryGetValue((uint)slot_id, out plant);
            return plant;
        }
    }

    public class HomePlantBuildingMgr : ClientSingleton<HomePlantBuildingMgr>
    {
        private Dictionary<int, HomePlantBuilding> m_buildingDict = new Dictionary<int, HomePlantBuilding>(Const.kCap16);

        [XLua.BlackList]
        public void Release()
        {
            foreach (var iter in m_buildingDict)
            {
                var building = iter.Value;
                if (building == null)
                    continue;

                building.Release();
            }

            m_buildingDict.Clear();
        }

        [XLua.BlackList]
        public void InitInfo()
        {
            Release();

            foreach (var info in HomeBuildingMgr.Instance.AllBuildings)
            {
                int buildingtype = info.Config.type;

                // 不是灵田
                if (buildingtype != (int)swm.BuildingType.lingtian)
                    continue;

                HomePlantBuilding building = new HomePlantBuilding();

                m_buildingDict.Add(info.id, building);
            }
        }

        [XLua.BlackList]
        public void Add(HomeBuildingInfo info)
        {
            if (info == null)
                return;

            int uid = info.id;
            int type = info.Config.type;
            if (type != (int)swm.BuildingType.lingtian)
                return;

            if (m_buildingDict.ContainsKey(uid))
                return;

            HomePlantBuilding building = new HomePlantBuilding();
            m_buildingDict.Add(info.id, building);
        }

        [XLua.BlackList]
        public void RefreshAll()
        {
            var buildingInfoMgr = HomeFieldModel.Instance.buildingInfoMgr;
            if (buildingInfoMgr == null)
                return;

            var buildingInfoDict = buildingInfoMgr.buildingDict;
            if (buildingInfoDict == null)
                return;

            foreach (var iter in buildingInfoDict)
            {
                int uid = (int)iter.Key;
                var plantinfomgr = iter.Value;
                if (plantinfomgr == null)
                    continue;

                HomePlantBuilding building = null;
                m_buildingDict.TryGetValue(uid, out building);

                if (building == null)
                    continue;

                building.field_uid = uid;
                building.SetPlantInfoMgr(plantinfomgr);
                building.Refresh();
            }
        }

        public HomePlantBuilding GetBuilding(int uid)
        {
            HomePlantBuilding building = null;
            m_buildingDict.TryGetValue(uid, out building);
            return building;
        }

        public void RefreshBuilding(int uid)
        {
            HomePlantBuilding building = null;
            m_buildingDict.TryGetValue(uid, out building);

            if (building == null)
                return;

            var buildingInfoMgr = HomeFieldModel.Instance.buildingInfoMgr;
            if (buildingInfoMgr == null)
                return;

            var plantinfomgr = buildingInfoMgr.GetPlantInfoMgr((uint)uid);
            if (plantinfomgr == null)
                return;

            building.field_uid = uid;
            building.SetPlantInfoMgr(plantinfomgr);
            building.Refresh();
        }

        public void SetBuildingVis(int uid, bool vis)
        {
            HomePlantBuilding building = null;
            m_buildingDict.TryGetValue(uid, out building);

            if (building == null)
                return;

            building.SetVisible(vis);
        }

        public void SetBuildingPlantState(int uid, bool plant)
        {
            HomePlantBuilding building = null;
            m_buildingDict.TryGetValue(uid, out building);

            if (building == null)
                return;

            building.SetPlantState(plant);
        }

        public void LookAtField(HomeBuilding building)
        {
            if (building == null)
                return;

            var info = building.Info;
            if (info == null)
                return;

            if (info.Config.type != (int)swm.BuildingType.lingtian)
                return;

            var hcamera = ICameraHelper.Instance.CurrentController as HomeFieldCameraController;
            if (hcamera == null)
                return;

            hcamera.SetDestPos(building.Position);
        }

        public HomePlant GetPlant(int uid, int slot_id)
        {
            HomePlantBuilding building = null;
            m_buildingDict.TryGetValue(uid, out building);

            if (building == null)
                return null;

            return building.GetPlant(slot_id);
        }

        public static Vector3 GetPlantPos(int uid, int slot_id)
        {
            var building = HomeBuildingViewer.Instance.GetBuildingById(uid);
            if (building == null)
                return Vector3.zero;

            var pos = CalcRelativePos(slot_id);

            var trans = building.GetTrans();
            if (trans != null)
            {
                pos = trans.TransformPoint(pos);
            }

            //pos += building.Position;
            return pos;
        }

        public static bool GetBuildingScreenPos(Vector3 position, out int x, out int y)
        {
            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            if (mainCamera == null)
            {
                x = 0; y = 0;
                return false;
            }

            var spos = mainCamera.WorldToScreenPoint(position);
            x = (int)spos.x;
            y = (int)spos.y;

            if (spos.z < 0.0f)
            {
                return false;
            }

            return true;
        }

        [XLua.BlackList]
        public static Vector3 CalcRelativePos(int slot_id)
        {
            int Field_Row_Num = HomeModel.Instance.cfgInfo.Field_Row_Num;
            int Field_Column_Num = HomeModel.Instance.cfgInfo.Field_Column_Num;

            int index = (int)slot_id - 1;
            int x = index % Field_Row_Num;
            int y = index / Field_Column_Num;
            float real_x = x - (Field_Row_Num - 1) * 0.5f;
            float real_y = y - (Field_Column_Num - 1) * 0.5f;

            float Field_Grid_Size = HomeModel.Instance.cfgInfo.Field_Grid_Size;
            float gridsize = Field_Grid_Size * 0.95f;
            Vector3 relative_pos;
            relative_pos.x = real_x * gridsize;
            relative_pos.z = -real_y * gridsize;
            relative_pos.y = 0.0f;
            return relative_pos;
        }
    }

}


