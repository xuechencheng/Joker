
using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;
using LitJson;
//
namespace Bokura
{
    public class HomeFieldModel : ClientSingleton<HomeFieldModel>
    {
        #region 内置

        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<RspHomeFieldInfo>(RspHomeFieldInfo_SC);    // 通知灵田信息
            MsgDispatcher.instance.RegisterFBMsgProc<RspHomePlanting>(RspHomePlanting_SC);  // 灵天种植
            MsgDispatcher.instance.RegisterFBMsgProc<RspHomeGain>(RspHomeGain_SC);  // 灵田收获

            HomeBuildingViewer.Instance.modelLoadEvent.AddListener(onModelLoadEvent);
        }

        public void Clear()
        {
            m_buildingInfoMgr.Clear();
        }

        #endregion

        #region 数据


        private HomePlantBuildingInfoMgr m_buildingInfoMgr = new HomePlantBuildingInfoMgr();
        /// <summary>
        /// 种植建筑物管理
        /// </summary>
        public HomePlantBuildingInfoMgr buildingInfoMgr
        {
            get { return m_buildingInfoMgr; }
        }

        /// <summary>
        /// 临时的孔位列表
        /// </summary>
        private List<uint> m_tempSlotidList = new List<uint>(Const.kCap16);

        #endregion

        #region 事件

        private GameEvent m_onHomeFieldInfoEvent = new GameEvent();
        public GameEvent onHomeFieldInfoEvent
        {
            get { return m_onHomeFieldInfoEvent; }
        }

        private GameEvent<uint> m_onHomePlantingEvent = new GameEvent<uint>();
        public GameEvent<uint> onHomePlantingEvent
        {
            get { return m_onHomePlantingEvent; }
        }

        private GameEvent<uint> m_onHomeGainEvent = new GameEvent<uint>();
        public GameEvent<uint> onHomeGainEvent
        {
            get { return m_onHomeGainEvent; }
        }

        #endregion

        #region 消息

        public void ReqHomeFieldInfo_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqHomeFieldInfo.StartReqHomeFieldInfo(tFBB);
            var tOffset = swm.ReqHomeFieldInfo.EndReqHomeFieldInfo(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeFieldInfo.HashID, tFBB);
        }

        private void RspHomeFieldInfo_SC(RspHomeFieldInfo msg)
        {
            m_buildingInfoMgr.RefreshAllFieldInfo(msg);
            HomePlantBuildingMgr.Instance.RefreshAll();

            m_onHomeFieldInfoEvent.Invoke();
        }

        public void ReqHomePlanting_CS(uint field_uid, List<uint> slot_id_list, uint seed_id)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            var slot_id_vecoff = swm.ReqHomePlanting.CreateSlotIdVector(tFBB, slot_id_list.ToArray());

            var tOffset = swm.ReqHomePlanting.CreateReqHomePlanting(tFBB, field_uid, slot_id_vecoff, seed_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomePlanting.HashID, tFBB);
        }

        private void RspHomePlanting_SC(RspHomePlanting msg)
        {
            m_buildingInfoMgr.RefreshPlantInfo(msg);

            uint field_uid = msg.field_uid;
            var buildinginfomgr = m_buildingInfoMgr.GetPlantInfoMgr(field_uid);
            if (buildinginfomgr != null)
            {
                var building = HomePlantBuildingMgr.Instance.GetBuilding((int)field_uid);
                if (building != null)
                {
                    building.field_uid = (int)field_uid;
                    building.SetPlantInfoMgr(buildinginfomgr);
                }
            }

            HomePlantBuildingMgr.Instance.RefreshBuilding((int)msg.field_uid);

            m_onHomePlantingEvent.Invoke(msg.field_uid);
        }

        /// <summary>
        /// 灵田收获
        /// </summary>
        public void ReqHomeGain_CS(uint field_uid)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqHomeGain.CreateReqHomeGain(tFBB, field_uid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeGain.HashID, tFBB);
        }

        private void RspHomeGain_SC(RspHomeGain msg)
        {
            m_buildingInfoMgr.RefreshGainInfo(msg);
            HomePlantBuildingMgr.Instance.RefreshBuilding((int)msg.field_uid);

            m_onHomeGainEvent.Invoke(msg.field_uid);
        }

        #endregion

        #region 事件

        private void onModelLoadEvent(int uid)
        {
            var buildinginfo = HomeBuildingMgr.Instance.GetBuildingByID(uid);
            if (buildinginfo == null)
                return;

            if (buildinginfo.Config.type != (int)BuildingType.lingtian)
                return;

            HomePlantBuildingMgr.Instance.RefreshBuilding(uid);
        }

        #endregion

        #region 函数

        /// <summary>
        /// 种植所有的种子
        /// </summary>
        /// <param name="selSeedId"></param>
        public void PlantAllSeed(uint field_uid, int selSeedId)
        {
            var bag = BagManager.Instance.GetBagByType(swm.BagType.ItemBag);
            if (bag == null)
                return;

            uint num = bag.Item_Manager.GetItemNumberByBaseID(selSeedId);
            if (num <= 0)
                return;

            var homePlantInfoMgr = m_buildingInfoMgr.GetPlantInfoMgr(field_uid);

            m_tempSlotidList.Clear();

            int index = 0;

            int Field_Max_Num = HomeModel.Instance.cfgInfo.Field_Max_Num;
            for (uint i = 1; i <= Field_Max_Num; i++)
            {
                if (homePlantInfoMgr != null)
                {
                    bool iscontain = homePlantInfoMgr.fieldInfoDict.ContainsKey(i);
                    if (iscontain)
                        continue;
                }


                if (index >= num)
                    continue;

                m_tempSlotidList.Add(i);

                index++;
            }

            ReqHomePlanting_CS(field_uid, m_tempSlotidList, (uint)selSeedId);
        }

        #endregion
    }
}
