
using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;
using LitJson;


namespace Bokura
{
    public class HomeModel : ClientSingleton<HomeModel>
    {
        #region 内置

        [XLua.BlackList]
        public void Init()
        {
            // 一些全局事件
            MsgDispatcher.instance.RegisterFBMsgProc<RspHomeMainInfo>(RspHomeMainInfo_SC);  // 进入家园推送到前端
            MsgDispatcher.instance.RegisterFBMsgProc<RspManorCap>(RspManorCapo_SC);//家园上限
            MsgDispatcher.instance.RegisterFBMsgProc<RspManorForecast>(RspManorForecast_SC);    // 家园事件

            // 法阵
            MsgDispatcher.instance.RegisterFBMsgProc<RspHomeFaZhenInfo>(RspHomeFaZhenInfo_SC);      // 回应家园法阵信息
            MsgDispatcher.instance.RegisterFBMsgProc<RspOpenHomeFaZhen>(RspOpenHomeFaZhen_SC);      // 回应打开家园法阵

            HomeWorkerModel.Instance.Init();
            HomeBuildingMgr.Instance.Init();
            HomeBuildingViewer.Instance.Init();
            HomeFieldModel.Instance.Init();

            GameApplication.Instance.GetTimerManager().AddTimer(OnTimer, 1, -1);
        }

        [XLua.BlackList]
        public void Clear()
        {
            HomeWorkerModel.Instance.Clear();
            HomeBuildingMgr.Instance.Clear();
            HomeFieldModel.Instance.Clear();

            m_eventmgr.Clear();
        }

        [XLua.BlackList]
        public void Load()
        {
            HomeLevelTableManager.Load();
            HomeBuildingVisitBtnTableManager.Load();
            HomeBuildingTableManager.Load();
            LaborBaseTableManager.Load();
            FollowerBaseTableManager.Load();
            ManorTaskTableManager.Load();
            HomeSeedTableManager.Load();
            HomeEventTableManager.Load();
            HomeTradingTableManager.Load();
            HomeFazhenTableManager.Load();

            m_cfgInfo.Load();
        }

        #endregion

        #region 数据


        private HomeCfgInfo m_cfgInfo = new HomeCfgInfo();
        public HomeCfgInfo cfgInfo
        {
            get { return m_cfgInfo; }
        }

        private HomeMainInfoTest m_homeMainInfoTest = new HomeMainInfoTest();
        public HomeMainInfoTest homeMainInfoTest
        {
            get { return m_homeMainInfoTest; }
        }


        private HomeEventInfoMgr m_eventmgr = new HomeEventInfoMgr();
        public HomeEventInfoMgr eventmgr
        {
            get { return m_eventmgr; }
        }

        private HomeFaZhenBuildingInfoMgr m_fazhenBuildingMgr = new HomeFaZhenBuildingInfoMgr();
        public HomeFaZhenBuildingInfoMgr fazhenBuildingMgr
        {
            get { return m_fazhenBuildingMgr; }
        }


        private bool m_editMode = false;
        public bool editMode
        {
            get { return m_editMode; }
            set { m_editMode = value; }
        }

        #endregion

        #region 事件变量

        private GameEvent m_onHomeMainInfoEvent = new GameEvent();
        public GameEvent onHomeMainInfoEvent
        {
            get { return m_onHomeMainInfoEvent; }
        }

        private GameEvent m_onHomeRefreshMainInfoEvent = new GameEvent();
        public GameEvent onHomeRefreshMainInfoEvent
        {
            get { return m_onHomeRefreshMainInfoEvent; }
        }

        private GameEvent m_onHomeEventNtf = new GameEvent();
        public GameEvent onHomeEventNtf
        {
            get { return m_onHomeEventNtf; }
        }

        private GameEvent m_onRedpointEvent = new GameEvent();
        public GameEvent onRedpointEvent
        {
            get { return m_onRedpointEvent; }
        }

        private GameEvent m_onFaZhenInfoEvent = new GameEvent();
        public GameEvent onFaZhenInfoEvent
        {
            get { return m_onFaZhenInfoEvent; }
        }

        private GameEvent<uint> m_onOpenFaZhenEvent = new GameEvent<uint>();
        public GameEvent<uint> onOpenFaZhenEvent
        {
            get { return m_onOpenFaZhenEvent; }
        }

        #endregion

        #region 消息函数

        /// <summary>
        /// 玩家请求进入家园
        /// </summary>
        public void ReqEnterHome_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqEnterHome.StartReqEnterHome(tFBB);
            var tOffset = swm.ReqEnterHome.EndReqEnterHome(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEnterHome.HashID, tFBB);
        }

        public void ReqExisHome_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqExitManor.StartReqExitManor(tFBB);
            var tOffset = swm.ReqExitManor.EndReqExitManor(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqExitManor.HashID, tFBB);
        }

        /// <summary>
        /// 进入家园推送到前端
        /// </summary>
        private void RspHomeMainInfo_SC(RspHomeMainInfo msg)
        {
            m_editMode = false;

            HomeBuildingMgr.Instance.Clear();
            for (int i = 0; i < msg.buildingsLength; i++)
                HomeBuildingMgr.Instance.RefreshHomeBuildingInfo(msg.buildings(i).Value);

            m_homeMainInfoTest.Refresh(msg);
            HomeFieldModel.Instance.ReqHomeFieldInfo_CS();

            m_onHomeMainInfoEvent.Invoke();
        }

        /// <summary>
        /// 刷新 家园上限 
        /// 劳工上限
        /// 粮食上限
        /// </summary>
        private void RspManorCapo_SC(RspManorCap msg)
        {
            m_homeMainInfoTest.max_workers_num = (ushort)msg.worker_cap;
            m_homeMainInfoTest.max_cereals = (ushort)msg.cereals_cap;
            m_onHomeRefreshMainInfoEvent.Invoke();
        }

        private void RspManorForecast_SC(RspManorForecast msg)
        {
            m_eventmgr.Refresh(msg);
            m_onHomeEventNtf.Invoke();
        }

        public void ReqHomeFazhenInfo_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqHomeFaZhenInfo.StartReqHomeFaZhenInfo(tFBB);
            var tOffset = swm.ReqHomeFaZhenInfo.EndReqHomeFaZhenInfo(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeFaZhenInfo.HashID, tFBB);
        }

        private void RspHomeFaZhenInfo_SC(RspHomeFaZhenInfo msg)
        {
            m_fazhenBuildingMgr.Refresh(msg);
            m_onFaZhenInfoEvent.Invoke();
        }

        [XLua.BlackList]
        public void ReqOpenHomeFaZhen_CS()
        {
            
        }

        private void RspOpenHomeFaZhen_SC(RspOpenHomeFaZhen msg)
        {
            m_fazhenBuildingMgr.Refresh(msg);

            m_onOpenFaZhenEvent.Invoke(msg.building_uid);
        }

        #endregion

        #region 函数

        /// <summary>
        /// 家园定时器
        /// </summary>
        private void OnTimer()
        {
            // 刷新事件
            UpdateEventRedpointState();

            // 自动刷新建筑状态

            if (HomeBuildingMgr.Instance != null)
            {
                // (现在改成点击完成劳工, 手动完成建造,升级状态, 不需要自动检测了)
                // 自动刷新建筑状态
                //HomeBuildingMgr.Instance.UpdateBuildingState();

                // 刷新自动领取收益
                HomeBuildingMgr.Instance.UpdateAutoReceiveIncome();

                // 检测是否可以升级
                HomeBuildingMgr.Instance.CheckCanUpgrade();

                // 检测是否可以有提示信息
                HomeBuildingMgr.Instance.CheckCanTip();
            }
        }

        public bool HasRedpoint()
        {
            bool hasredpoint = m_eventmgr.CheckRedpointState();
            return hasredpoint;
        }

        private void UpdateEventRedpointState()
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return;

            // 家园内就不检测了
            if (mapinfo.maptype == (int)swm.MapType.Manor)
                return;

            if (m_eventmgr == null)
                return;

            bool hasredpoint = m_eventmgr.CheckRedpointState();

            if (hasredpoint)
            {
                m_onRedpointEvent.Invoke();
            }
        }

        [XLua.BlackList]
        public bool IsEditMode()
        {
            var mapinfo = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentMapId);
            if (mapinfo == null)
                return false;

            // 家园内就不检测了
            if (mapinfo.maptype != (int)swm.MapType.Manor)
                return false;

            return m_editMode;
        }

        #endregion

        #region 测试

        [XLua.BlackList]
        public void GM_Test_Event()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            var servertime = (uint)(GameScene.Instance.GetServerTime() / 1000);
            var event1 = ManorForecastInfo.CreateManorForecastInfo(tFBB, 1, 0, servertime + 10);
            var event2 = ManorForecastInfo.CreateManorForecastInfo(tFBB, 2, 102, servertime + 20);
            var event3 = ManorForecastInfo.CreateManorForecastInfo(tFBB, 3, 601, servertime + 30);
            var event4 = ManorForecastInfo.CreateManorForecastInfo(tFBB, 4, 4, servertime + 40);
            var event5 = ManorForecastInfo.CreateManorForecastInfo(tFBB, 5, 903, servertime + 50);

            var offlist = new Offset<ManorForecastInfo>[] { event1, event2, event3, event4, event5 };
            var off = RspManorForecast.CreateForecastsVector(tFBB, offlist);

            var tOffset = RspManorForecast.CreateRspManorForecast(tFBB, off);
            tFBB.Finish(tOffset.Value);

            OfflineViewMsgTamper.ProcFBMsg(RspManorForecast.HashID, tFBB);
        }

        #endregion
    }
}
