using System;

namespace Bokura
{
    public class LaborInTavernInfo
    {
        private uint m_labor_id = 0;
        public uint LaborId
        {
            get
            {
                return m_labor_id;
            }
            set
            {
                m_labor_id = value;
            }
        }

        private bool m_be_hired = false;
        public bool Be_hired
        {
            get
            {
                return m_be_hired;
            }
            set
            {
                m_be_hired = value;
            }
        }

        public void Clear()
        {
            m_be_hired = false;
            m_labor_id = 0;
        }

        public void Refresh(swm.LaborInTavern _data)
        {
            m_be_hired = _data.be_hired;
            m_labor_id = _data.labor_id;
        }

    }


    /// <summary>
    /// 劳工和随从 工作信息
    /// </summary>
    public class HomeWorkerInfo
    {

        /// <summary>
        /// 工作目标
        /// </summary>
        private uint m_target_Id = 0;
        public uint Target_id
        {
            get
            {
                return m_target_Id;
            }
            set
            {
                m_target_Id = value;
            }
        }

        /// <summary>
        /// 工作结束时间
        /// </summary>
        private ulong m_end_time = 0;
        public ulong End_time
        {
            get
            {
                return m_end_time;
            }
            set
            {
                m_end_time = value;
            }
        }

        /// <summary>
        /// 工作增益比例
        /// </summary>
        private uint m_output_addition = 0;
        public uint Output_addition
        {
            get
            {
                return m_output_addition;
            }
            set
            {
                m_output_addition = value;
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_target_Id         = 0;
            m_end_time          = 0;
            m_output_addition   = 0;
        }

        [XLua.BlackList]
        public void Refresh(swm.WorkInfo? _workInfo)
        {
            if(null != _workInfo)
            {
                m_target_Id = _workInfo.Value.target_id;
                m_end_time = _workInfo.Value.end_time * 1000;
                m_output_addition = _workInfo.Value.output_addition;
            }
            else
            {
                Clear();
            }

        }
    }

    /// <summary>
    /// 劳工和随从信息
    /// </summary>
    public class HomeWorker
    {
        private HomeWorkerInfo m_workerinfo = new HomeWorkerInfo();
        public HomeWorkerInfo WorkerInfo
        {
            get
            {
                return m_workerinfo;
            }
        }

        /// <summary>
        /// 唯一id
        /// </summary>
        private uint m_id = 0;
        public uint Id
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
        }
        /// <summary>
        /// 等级
        /// </summary>
        private uint m_level = 0;
        public uint Level
        {
            get
            {
                return m_level;
            }
            set
            {
                m_level = value;
            }
        }

        /// <summary>
        /// 当前经验
        /// </summary>
        private uint m_cur_exp = 0;
        public uint Cur_Exp
        {
            get
            {
                return m_cur_exp;
            }
            set
            {
                m_cur_exp = value;
            }
        }

        /// <summary>
        /// 工人状态
        /// </summary>
        private swm.WorkerState m_worker_state = swm.WorkerState.Idle;
        public swm.WorkerState Worker_State
        {
            get
            {
                return m_worker_state;
            }
            set
            {
                m_worker_state = value;
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_id = 0;
            m_level = 0;
            m_cur_exp = 0;
            m_worker_state = swm.WorkerState.Idle;
            m_workerinfo.Clear();
        }

        [XLua.BlackList]
        public void Refresh(swm.Worker _data)
        {
            m_id = _data.worker_id;
            m_level = _data.level;
            m_cur_exp = _data.cur_exp;
            //m_worker_state = _data.worker_state;
        }

        [XLua.BlackList]
        public void RefreshWorkInfo(swm.WorkInfo? _workInfo)
        {
            if(null == _workInfo)
            {
                m_worker_state = swm.WorkerState.Idle;
            }
            else
            {
                m_worker_state = swm.WorkerState.Working;
            }
            m_workerinfo.Refresh(_workInfo);
        }
    }

    /// <summary>
    /// 随从数据
    /// </summary>
    public class HomeFollower
    {
        private HomeWorker m_worker = new HomeWorker();
        public HomeWorker Worker
        {
            get
            {
                return m_worker;
            }
        }

        /// <summary>
        /// 随从配置
        /// </summary>
        private FollowerBaseTableBase? m_FollowerBaseTableBaseConfig = null;
        public FollowerBaseTableBase? FollowerBaseTableBaseConfig
        {
            get
            {
                return m_FollowerBaseTableBaseConfig;
            }
        }

        /// <summary>
        /// 随从npc配置
        /// </summary>
        private NpcTableBase? m_NpcTableBaseConfig = null;
        public NpcTableBase? NpcTableBaseConfig
        {
            get
            {
                return m_NpcTableBaseConfig;
            }
        }

        /// <summary>
        /// 好感度
        /// </summary>
        private uint m_favor_level = 0;
        public uint Favor_level
        {
            get
            {
                return m_favor_level;
            }
            set
            {
                m_favor_level = value;
            }
        }

        /// <summary>
        /// 好感度值
        /// </summary>
        private uint m_favor = 0;
        public uint Favor
        {
            get
            {
                return m_favor;
            }
            set
            {
                m_favor = value;
            }
        }
        [XLua.BlackList]
        public void Clear()
        {
            m_favor         = 0;
            m_favor_level   = 0;
            m_FollowerBaseTableBaseConfig = null;
            m_worker.Clear();
        }

        [XLua.BlackList]
        public void Refresh(swm.Follower _data)
        {
            m_favor = _data.favor;
            m_favor_level = _data.favor_level;
            m_worker.Refresh(_data.worker.Value);
            m_FollowerBaseTableBaseConfig = FollowerBaseTableManager.GetData((int)m_worker.Id);
            if(m_FollowerBaseTableBaseConfig.HasValue)
            {
                m_NpcTableBaseConfig = NpcTableManager.GetData(m_FollowerBaseTableBaseConfig.Value.npc_id);
            }
            else
            {
                m_NpcTableBaseConfig = null;
            }
        }

        [XLua.BlackList]
        public void RefreshWorkInfo(swm.WorkInfo? _workInfo)
        {
            m_worker.RefreshWorkInfo(_workInfo);
        }
    }

    /// <summary>
    /// 劳工数据
    /// </summary>
    public class HomeLabor
    {
        private HomeWorker m_worker = new HomeWorker();
        public HomeWorker Worker
        {
            get
            {
                return m_worker;
            }
        }

        /// <summary>
        /// 劳工配置
        /// </summary>
        private LaborBaseTableBase? m_LaborBaseTableBaseConfig = null;
        public LaborBaseTableBase? LaborBaseTableBaseConfig
        {
            get
            {
                return m_LaborBaseTableBaseConfig;
            }
        }

        /// <summary>
        /// 劳工npc配置
        /// </summary>
        private NpcTableBase? m_NpcTableBaseConfig = null;
        public NpcTableBase? NpcTableBaseConfig
        {
            get
            {
                return m_NpcTableBaseConfig;
            }
        }
        /// <summary>
        /// 忠诚度
        /// </summary>
        private uint m_loyalty = 0;
        public uint Loyalty
        {
            get
            {
                return m_loyalty;
            }
            set
            {
                m_loyalty = value;
            }
        }

        /// <summary>
        /// 心情
        /// </summary>
        private swm.MoodType m_mood = swm.MoodType.Normal;
        public swm.MoodType Mood
        {
            get
            {
                return m_mood;
            }
            set
            {
                m_mood = value;
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_mood = swm.MoodType.Normal;
            m_loyalty = 0;
            m_LaborBaseTableBaseConfig = null;
            m_worker.Clear();
        }

        [XLua.BlackList]
        public void Refresh(swm.Labor _data)
        {
            m_loyalty = _data.loyalty;
            m_mood = _data.mood;
            m_worker.Refresh(_data.worker.Value);
            m_LaborBaseTableBaseConfig = LaborBaseTableManager.GetData((int)m_worker.Id);
            if (m_LaborBaseTableBaseConfig.HasValue)
            {
                m_NpcTableBaseConfig = NpcTableManager.GetData(m_LaborBaseTableBaseConfig.Value.npc_id);
            }
            else
            {
                m_NpcTableBaseConfig = null;
            }
        }

        [XLua.BlackList]
        public void RefreshWorkInfo(swm.WorkInfo? _workInfo)
        {
            m_worker.RefreshWorkInfo(_workInfo);
        }
    }

}
