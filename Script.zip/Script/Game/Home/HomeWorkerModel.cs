using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    class HomeWorkerModel : ClientSingleton<HomeWorkerModel>
    {
        //工人列表
        private Dictionary<uint, HomeLabor> m_HomeLaborList = new Dictionary<uint, HomeLabor>(Const.kCap32);
        private List<HomeLabor> m_HomeLaborListPool = new List<HomeLabor>(Const.kCap32);
        private List<HomeLabor> m_TempStoreHomeLabor = new List<HomeLabor>(Const.kCap32);//临时存放劳工的列表 派发用
        public Dictionary<uint, HomeLabor> HomeLaborList
        {
            get
            {
                return m_HomeLaborList;
            }
        }

        //随从列表
        private Dictionary<uint, HomeFollower> m_HomeFollowerList = new Dictionary<uint, HomeFollower>(Const.kCap32);
        private List<HomeFollower> m_HomeFollowerListPool = new List<HomeFollower>(Const.kCap32);
        private List<HomeFollower> m_TempStoreHomeFollower = new List<HomeFollower>(Const.kCap32);

        public Dictionary<uint, HomeFollower> HomeFollowerList
        {
            get
            {
                return m_HomeFollowerList;
            }
        }

        private List<LaborInTavernInfo> m_LaborInTavernInfoList = new List<LaborInTavernInfo>(Const.kCap32);
        private List<LaborInTavernInfo> m_LaborInTavernInfoListPool = new List<LaborInTavernInfo>(Const.kCap32);

        public List<LaborInTavernInfo>  LaborInTavernInfoList
        {
            get
            {
                return m_LaborInTavernInfoList;
            }
        }
        /// <summary>
        /// 随从已解锁的任务列表
        /// </summary>
        private List<uint> m_HomeTaskList = new List<uint>(Const.kCap32);
        public List<uint> HomeTaskList
        {
            get
            {
                return m_HomeTaskList;
            }
        }

        /// <summary>
        /// 是否请求酒馆信息
        /// </summary>
        private bool m_reqTavernInfo = false;

        /// <summary>
        /// 酒馆刷新时间
        /// </summary>
        private ulong m_tavernRefreshTime = 0;

        /// <summary>
        /// 酒馆刷新花费
        /// </summary>
        private uint m_refresh_energy = 0;
        public uint Refresh_Energy
        {
            get
            {
                return m_refresh_energy;
            }
        }

        private Dictionary<int, List<ManorTaskTableBase>> m_StoreManorTaskTableBaseList = new Dictionary<int, List<ManorTaskTableBase>>(Const.kCap16);

        private List<uint> m_tempStoreIdList = new List<uint>(Const.kCap32);

        public GameEvent onInitHomeLaborListEvent = new GameEvent();//获取劳工列表
        public GameEvent<HomeLabor> onAddHomeLaborEvent = new GameEvent<HomeLabor>();//增加劳工
        public GameEvent<HomeLabor> onRefreshHomeLaborEvent = new GameEvent<HomeLabor>();//刷新劳工数据
        public GameEvent<HomeLabor> onDeleteHomeLaborEvent = new GameEvent<HomeLabor>();//删除劳工
        public GameEvent<HomeLabor> onRefreshHomeLaborWorkInfoEvent = new GameEvent<HomeLabor>();//刷新劳工工作信息

        public GameEvent onInitHomeFollowerListEvent = new GameEvent();//获取随从列表
        public GameEvent<HomeFollower> onAddHomeFollowerEvent = new GameEvent<HomeFollower>();//增加随从
        public GameEvent<HomeFollower> onRefreshHomeFollowerEvent = new GameEvent<HomeFollower>();//刷新随从数据
        public GameEvent<HomeFollower> onDeleteHomeFollowerEvent = new GameEvent<HomeFollower>();//删除随从
        public GameEvent<HomeFollower> onRefreshHomeFollowerWorkInfoEvent = new GameEvent<HomeFollower>();//刷新随从工作信息

        public GameEvent<uint> onTaskListChange = new GameEvent<uint>();//随从任务列表改变了

        public GameEvent<ulong> onInitTavernInfoEvent = new GameEvent<ulong>();//获得酒馆消息
        public GameEvent<LaborInTavernInfo> onHireLaborEvent = new GameEvent<LaborInTavernInfo>();//获得一个招募劳工消息

        public GameEvent<uint, uint> onMakeItemEvent = new GameEvent<uint, uint>();         // 制作贸易战事件

        public GameEvent onWorkerInfoChangedEvent = new GameEvent();                        // 家园工作信息改变

        [XLua.BlackList]
        public GameEvent onWorkerFinishWorkEvent = new GameEvent();                         // 返回完成任务

        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspWorkerList>(RspWorkerList_SC);  // 返回劳工列表信息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFollowerList>(RspFollowerList_SC);  // 返回追随者列表信息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyNewFollower>(NotifyNewFollower_SC);  // 获得新的追随者
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyNewLabor>(NotifyNewLabor_SC);  // 获得新的劳工
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyLaborInfo>(NotifyLaborInfo_SC);  // 通知信息变化的劳工列表
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyFollowerInfo>(NotifyFollowerInfo_SC);  // 通知信息变化的劳工列表
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspTavernInfo>(RspTavernInfo_SC);  // 返回酒馆信息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspHireLabor>(RspHireLabor_SC);    // 返回招募信息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFireLabor>(RspFireLabor_SC);    // 返回劳工遣散
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFollowerToWork>(RspFollowerToWork_SC);  // 返回追随者任务派遣信息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspFollowerFinishWork>(RspFollowerFinishWork_SC);  // 追随者完成任务
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspLaborFinishWork>(RspLaborFinishWork_SC);  // 追随者完成任务
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspHomeTaskList>(RspHomeTaskList_SC);  // 返回已解锁任务信息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyNewHomeTask>(NotifyNewHomeTask_SC);  // 通知新的解锁任务
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyLaborToWork>(NotifyLaborToWork_SC);  // 通知劳工工作信息

            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspHomeMakeItem>(RspHomeMakeItem_SC);      // 回复贸易战制作
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyHomeWorkerInfoChanged>(NotifyHomeWorkerInfoChanged_SC);      // 通知家园工作信息改变
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspHomeWorkerFinishWork>(RspHomeWorkerFinishWork_SC);          // 返回完成任务
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_HomeTaskList.Clear();
            m_TempStoreHomeLabor.Clear();
            m_TempStoreHomeFollower.Clear();
            BackToAllHomeLaborToPool();
            BackToAllHomeFollowerToPool();
        }
        ///客户端处理
        ///

        ///

        /// <summary>
        /// 通过类型和品质获取随从派遣任务配置列表
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_quality"></param>
        /// <returns></returns>
        public List<ManorTaskTableBase> GetManorTaskTableBaseByTypeAndQuality(int _type,int _quality)
        {
            int key = _type * 1000 + _quality;
            List<ManorTaskTableBase> _list = null;
            if(!m_StoreManorTaskTableBaseList.TryGetValue(key,out _list))
            {
                _list = new List<ManorTaskTableBase>(Const.kCap32);
                ManorTaskTableBaseList _configList = ManorTaskTableManager.Instance.m_DataList;
                ManorTaskTableBase _value;
                for (int i=0;i<_configList.ManorTaskTableLength;i++)
                {
                    _value = _configList.ManorTaskTable(i).Value;
                    if(_value.specialty_type == _type && _value.qualify == _quality)
                    {
                        _list.Add(_value);
                    }
                }
                m_StoreManorTaskTableBaseList.Add(key, _list);
            }
            return _list;
        }
         
        /// <summary>
        /// 检查任务id是否在解锁列表内
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public bool CheckTaskIdIsUnLock(uint _id)
        {
            for(int i=0;i<m_HomeTaskList.Count;i++)
            {
                if(_id == m_HomeTaskList[i])
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 通过id获得劳工
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public HomeLabor GetHomeLaborById(uint _id)
        {
            HomeLabor _data = null;
            m_HomeLaborList.TryGetValue(_id, out _data);
            return _data;
        }

        /// <summary>
        /// 获取当前劳工数量
        /// </summary>
        /// <returns></returns>
        public int GetLaborNumber()
        {
            return m_HomeLaborList.Count;
        }

        /// <summary>
        /// 获取当前 闲置的劳工数量
        /// </summary>
        /// <returns></returns>
        public int GetCurrentNoJobLaborNumber()
        {
            List<HomeLabor> _list = GetCurrentNoJobLaborList();
            return _list.Count;
        }

        /// <summary>
        /// 获取当前 闲置的劳工列表
        /// </summary>
        /// <returns></returns>
        public List<HomeLabor> GetCurrentNoJobLaborList()
        {
            m_TempStoreHomeLabor.Clear();
            foreach (var v in m_HomeLaborList)
            {
                if (v.Value.Worker.WorkerInfo.Target_id == 0)
                {
                    m_TempStoreHomeLabor.Add(v.Value);
                }
            }
            return m_TempStoreHomeLabor;
        }


        /// <summary>
        /// 清除所有劳工数据 入内存池
        /// </summary>
        private void BackToAllHomeLaborToPool()
        {
            HomeLabor _data;
            foreach (var _v in m_HomeLaborList)
            {
                _data = _v.Value;
                _data.Clear();
                m_HomeLaborListPool.Add(_data);
            }
            m_HomeLaborList.Clear();
        }

        /// <summary>
        /// 从内存池里取一个劳工
        /// </summary>
        /// <returns></returns>
        private HomeLabor GetHomeLaborFromPool()
        {
            HomeLabor _data = null;
            if (m_HomeLaborListPool.Count > 0)
            {
                _data = m_HomeLaborListPool[0];
                m_HomeLaborListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new HomeLabor();
            }
            return _data;
        }

        /// <summary>
        /// 是否酒馆已经刷新
        /// </summary>
        /// <returns></returns>
        [XLua.BlackList]
        public bool IsTavernRefresh()
        {
            if (!m_reqTavernInfo)
                return false;

            ulong servertime = GameScene.Instance.GetServerTime() / 1000;
            ulong deadline = m_tavernRefreshTime;

            return servertime > deadline;
        }

        /// <summary>
        /// 增加或者刷新劳工
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="_bIsSendEvent"></param>
        /// <returns></returns>
        private HomeLabor AddHomeLabor(swm.Labor _data,bool _bIsSendEvent = true,bool _bIsAdd = true)
        {
            uint _id = _data.worker.Value.worker_id;
            HomeLabor _homeLabor = GetHomeLaborById(_id);
            if(_homeLabor != null)
            {
                //刷新
                _homeLabor.Refresh(_data);
                if (_bIsSendEvent)
                {
                    onRefreshHomeLaborEvent.Invoke(_homeLabor);
                }
            }
            else
            {
                if(_bIsAdd)
                {
                    //增加
                    _homeLabor = GetHomeLaborFromPool();
                    _homeLabor.Refresh(_data);
                    m_HomeLaborList.Add(_id, _homeLabor);
                    if (_bIsSendEvent)
                    {
                        onAddHomeLaborEvent.Invoke(_homeLabor);
                    }
                }

            }

            return _homeLabor;
        }

        /// <summary>
        /// 删除劳工
        /// </summary>
        /// <param name="_id"></param>
        private void DeleteHomeLabor(uint _id)
        {
            HomeLabor _homeLabor = null;
            if (m_HomeLaborList.TryGetValue(_id, out _homeLabor))
            {
                m_HomeLaborList.Remove(_id);
                onDeleteHomeLaborEvent.Invoke(_homeLabor);
            }
        }

        /// <summary>
        /// 刷新劳工工作信息
        /// </summary>
        /// <param name="_workInfo"></param>
        /// <param name="_bIsSendEvent"></param>
        private HomeLabor RefreshLaborWorkInfo(uint _id,swm.WorkInfo? _workInfo, bool _bIsSendEvent = true)
        {
            HomeLabor _homeLabor = GetHomeLaborById(_id);
            if(null != _homeLabor)
            {
                _homeLabor.RefreshWorkInfo(_workInfo);
                if(_bIsSendEvent)
                {
                    onRefreshHomeLaborWorkInfoEvent.Invoke(_homeLabor);
                }
            }
            else
            {
                LogHelper.Log("no labor so cannot RefreshLaborWorkInfo", _id.ToString());
            }
            return _homeLabor;
        }

        /// <summary>
        /// 通过id获得随从
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public HomeFollower GetHomeFollowerById(uint _id)
        {
            HomeFollower _data = null;
            m_HomeFollowerList.TryGetValue(_id, out _data);
            return _data;
        }

        /// <summary>
        /// 随从数量
        /// </summary>
        /// <returns></returns>
        public int GetFollowerNumber()
        {
            return m_HomeFollowerList.Count;
        }

        /// <summary>
        /// 随从闲置的数量
        /// </summary>
        /// <returns></returns>
        public int GetFollowerNoJobNumber()
        {
            List<HomeFollower> _list = GetCurrentNoJobFollowerList();
            return _list.Count;
        }

        /// <summary>
        /// 获取闲置随从列表
        /// </summary>
        /// <returns></returns>
        public List<HomeFollower> GetCurrentNoJobFollowerList()
        {
            m_TempStoreHomeFollower.Clear();
            foreach (var v in m_HomeFollowerList)
            {
                if (v.Value.Worker.WorkerInfo.Target_id == 0)
                {
                    m_TempStoreHomeFollower.Add(v.Value);
                }
            }
            return m_TempStoreHomeFollower;
        }

        /// <summary>
        /// 获取正在干这探索任务的一个随从
        /// </summary>
        /// <param name="_taskId"></param>
        /// <returns></returns>
        public HomeFollower GetOneHomeFollowerByExploreTaskId(uint _taskId)
        {
            HomeFollower _data = null;
            List<HomeFollower>  _list = GetHomeListByExploreTaskId(_taskId);
            if(_list.Count>0)
            {
                _data = _list[0];
            }
            return _data;
        }
        /// <summary>
        ///通过探索任务id 获取正在探索的随从列表
        /// </summary>
        /// <param name="_taskId"></param>
        /// <returns></returns>
        public List<HomeFollower> GetHomeListByExploreTaskId(uint _taskId)
        {
            m_TempStoreHomeFollower.Clear();
            foreach (var v in m_HomeFollowerList)
            {
                uint _targetId = v.Value.Worker.WorkerInfo.Target_id;
                if (_targetId != 0 && _targetId == _taskId)
                {
                    m_TempStoreHomeFollower.Add(v.Value);
                }
            }
            return m_TempStoreHomeFollower;
        }

        /// <summary>
        /// 清除所有随从数据 入内存池
        /// </summary>
        private void BackToAllHomeFollowerToPool()
        {
            HomeFollower _data;
            foreach (var _v in m_HomeFollowerList)
            {
                _data = _v.Value;
                _data.Clear();
                m_HomeFollowerListPool.Add(_data);
            }
            m_HomeFollowerList.Clear();
        }

        /// <summary>
        /// 从内存池里取一个随从
        /// </summary>
        /// <returns></returns>
        private HomeFollower GetHomeFollowerFromPool()
        {
            HomeFollower _data = null;
            if (m_HomeFollowerListPool.Count > 0)
            {
                _data = m_HomeFollowerListPool[0];
                m_HomeFollowerListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new HomeFollower();
            }
            return _data;
        }

        /// <summary>
        /// 增加或者刷新随从信息
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="_bIsSendEvent"></param>
        /// <returns></returns>
        private HomeFollower AddHomeFollower(swm.Follower _data, bool _bIsSendEvent = true,bool _bIsAdd = true)
        {
            uint _id = _data.worker.Value.worker_id;
            HomeFollower _homeFollower = GetHomeFollowerById(_id);
            if(null != _homeFollower)
            {
                _homeFollower.Refresh(_data);
                if (_bIsSendEvent)
                {
                    onRefreshHomeFollowerEvent.Invoke(_homeFollower);
                }
            }
            else
            {
                if(_bIsAdd)
                {
                    _homeFollower = GetHomeFollowerFromPool();
                    _homeFollower.Refresh(_data);
                    m_HomeFollowerList.Add(_id, _homeFollower);
                    if (_bIsSendEvent)
                    {
                        onAddHomeFollowerEvent.Invoke(_homeFollower);
                    }
                }

            }
            return _homeFollower;
        }

        /// <summary>
        /// 删除随从
        /// </summary>
        /// <param name="_id"></param>
        private void DeleteHomeFollower(uint _id)
        {
            HomeFollower _homeFollower = null;
            if (m_HomeFollowerList.TryGetValue(_id, out _homeFollower))
            {
                m_HomeFollowerList.Remove(_id);
                onDeleteHomeFollowerEvent.Invoke(_homeFollower);
            }
        }

        /// <summary>
        /// 刷新随从工作信息
        /// </summary>
        /// <param name="_workInfo"></param>
        /// <param name="_bIsSendEvent"></param>
        private HomeFollower RefreshFollowerWorkInfo(uint _id,swm.WorkInfo? _workInfo, bool _bIsSendEvent = true)
        {
            HomeFollower _homeFollower = GetHomeFollowerById(_id);
            if (null != _homeFollower)
            {
                _homeFollower.RefreshWorkInfo(_workInfo);
                if (_bIsSendEvent)
                {
                    onRefreshHomeFollowerWorkInfoEvent.Invoke(_homeFollower);
                }
            }
            else
            {
                LogHelper.Log("no Follower so cannot RefreshFollowerWorkInfo", _id.ToString());
            }
            return _homeFollower;
        }


        /// <summary>
        /// 清除所有酒馆招募数据 入内存池
        /// </summary>
        private void BackToAllLaborTavernInfoToPool()
        {
            LaborInTavernInfo _data;
            for(int i=0;i<m_LaborInTavernInfoList.Count;i++)
            {
                _data = m_LaborInTavernInfoList[i];
                _data.Clear();
                m_LaborInTavernInfoListPool.Add(_data);
            }
            m_LaborInTavernInfoList.Clear();
        }

        /// <summary>
        /// 从内存池里取一个酒馆招募数据
        /// </summary>
        /// <returns></returns>
        private LaborInTavernInfo GetLaborTavernInfoFromPool()
        {
            LaborInTavernInfo _data = null;
            if (m_LaborInTavernInfoListPool.Count > 0)
            {
                _data = m_LaborInTavernInfoListPool[0];
                m_LaborInTavernInfoListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new LaborInTavernInfo();
            }
            return _data;
        }

        /// <summary>
        /// 通过id 获得酒馆列表的成员信息
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public LaborInTavernInfo GetLaborInTavernInfoById(uint _id)
        {
            LaborInTavernInfo _data = null;
            for(int i =0;i< m_LaborInTavernInfoList.Count;i++)
            {
                if(m_LaborInTavernInfoList[i].LaborId == _id)
                {
                    _data = m_LaborInTavernInfoList[i];
                    break;
                }
            }
            return _data;
        }

        ///结束客户端处理


        ///开始接收协议

        /// <summary>
        /// 返回劳工列表信息
        /// </summary>
        /// <param name="msg"></param>
        private void RspWorkerList_SC(swm.RspWorkerList msg)
        {
            BackToAllHomeLaborToPool();
            for (int i =0;i<msg.labor_listLength;i++)
            {
                swm.Labor _data = msg.labor_list(i).Value;
                AddHomeLabor(_data,false);
            }

            for(int j=0;j<msg.work_infoLength;j++)
            {
                swm.WorkInfo? _workInfo = msg.work_info(j);
                RefreshLaborWorkInfo(_workInfo.Value.worker_id,_workInfo, false);
            }

            onInitHomeLaborListEvent.Invoke();
        }

        /// <summary>
        /// 返回追随者列表信息
        /// </summary>
        private void RspFollowerList_SC(swm.RspFollowerList msg)
        {
            BackToAllHomeFollowerToPool();
            for (int i=0;i<msg.follower_listLength;i++)
            {
                swm.Follower _data = msg.follower_list(i).Value;
                AddHomeFollower(_data, false);
            }
            for (int j = 0; j < msg.work_infoLength; j++)
            {
                swm.WorkInfo? _workInfo = msg.work_info(j);
                RefreshFollowerWorkInfo(_workInfo.Value.worker_id,_workInfo, false);
            }

            onInitHomeFollowerListEvent.Invoke();
        }

        /// <summary>
        /// 获得新的追随者
        /// </summary>
        /// <param name="msg"></param>
        private void NotifyNewFollower_SC(swm.NotifyNewFollower msg)
        {
            swm.Follower _data = msg.follower.Value;
            AddHomeFollower(_data);
        }

        /// <summary>
        /// 返回已解锁任务信息
        /// </summary>
        /// <param name="msg"></param>
        private void RspHomeTaskList_SC(swm.RspHomeTaskList msg)
        {
            m_HomeTaskList.Clear();
            for(int i=0;i<msg.task_listLength;i++)
            {
                uint _id = msg.task_list(i);
                m_HomeTaskList.Add(_id);
            }
        }

        /// <summary>
        /// 通知新的解锁任务
        /// </summary>
        /// <param name="msg"></param>
        private void NotifyNewHomeTask_SC(swm.NotifyNewHomeTask msg)
        {
            bool _b = CheckTaskIdIsUnLock(msg.task_id);
            if(!_b)
            {
                m_HomeTaskList.Add(msg.task_id);
                onTaskListChange.Invoke(msg.task_id);
            }
        }

        /// <summary>
        /// 返回酒馆信息
        /// </summary>
        /// <param name="msg"></param>
        private void RspTavernInfo_SC(swm.RspTavernInfo msg)
        {
            m_reqTavernInfo = true;
            m_tavernRefreshTime = msg.deadline;

            m_refresh_energy = msg.refresh_energy;

            BackToAllLaborTavernInfoToPool();
            for(int i=0;i<msg.laborsLength;i++)
            {
                LaborInTavernInfo _data = GetLaborTavernInfoFromPool();
                _data.Refresh(msg.labors(i).Value);
                m_LaborInTavernInfoList.Add(_data);
            }
            onInitTavernInfoEvent.Invoke(msg.deadline);
        }

        /// <summary>
        /// 返回招募信息
        /// </summary>
        /// <param name="msg">雇佣的劳工id</param>
        private void RspHireLabor_SC(swm.RspHireLabor msg)
        {
            LaborInTavernInfo _data = GetLaborInTavernInfoById(msg.labor_id);
            if(null != _data)
            {
                _data.Be_hired = true;
                onHireLaborEvent.Invoke(_data);
            }
            
        }

        /// <summary>
        /// 通知劳工工作
        /// </summary>
        /// <param name="msg"></param>
        private void NotifyLaborToWork_SC(swm.NotifyLaborToWork msg)
        {
            RefreshLaborWorkInfo(msg.work_info.Value.worker_id, msg.work_info, true);
        }

        /// <summary>
        /// 通知增加一个劳工
        /// </summary>
        /// <param name="msg"></param>
        private void NotifyNewLabor_SC(swm.NotifyNewLabor msg)
        {
            swm.Labor _data = msg.labor.Value;
            AddHomeLabor(_data);
        }

        /// <summary>
        /// 通知信息变化的劳工列表
        /// </summary>
        /// <param name="msg"></param>
        private void NotifyLaborInfo_SC(swm.NotifyLaborInfo msg)
        {
            int len = msg.labor_listLength;
            for(int i=0;i<len;i++)
            {
                AddHomeLabor(msg.labor_list(i).Value,true,false);
            }
        }

        /// <summary>
        /// 通知信息变化的追随者列表
        /// </summary>
        /// <param name="msg"></param>
        private void NotifyFollowerInfo_SC(swm.NotifyFollowerInfo msg)
        {
            int len = msg.follower_listLength;
            for (int i = 0; i < len; i++)
            {
                AddHomeFollower(msg.follower_list(i).Value, true, false);
            }
        }

        /// <summary>
        /// 返回劳工遣散
        /// </summary>
        /// <param name="msg"></param>
        private void RspFireLabor_SC(swm.RspFireLabor msg)
        {
            DeleteHomeLabor(msg.labor_id);
        }

        /// <summary>
        /// 返回追随者任务派遣信息
        /// </summary>
        /// <param name="msg"></param>
        private void RspFollowerToWork_SC(swm.RspFollowerToWork msg)
        {
            RefreshFollowerWorkInfo(msg.work_info.Value.worker_id, msg.work_info, true);
        }

        /// <summary>
        /// 追随者完成任务
        /// </summary>
        /// <param name="msg"></param>
        private void RspFollowerFinishWork_SC(swm.RspFollowerFinishWork msg)
        {
            //收到这条消息认为 追随者 工作完成 进入idle 清空工作信息
            for(int i =0;i<msg.follower_listLength;i++)
            {
                RefreshFollowerWorkInfo(msg.follower_list(i), null, true);
            }
        }

        /// <summary>
        /// 劳工完成任务
        /// </summary>
        /// <param name="msg"></param>
        private void RspLaborFinishWork_SC(swm.RspLaborFinishWork msg)
        {
            //收到这条消息认为 追随者 工作完成 进入idle 清空工作信息
            for (int i = 0; i < msg.labor_listLength; i++)
            {
                RefreshLaborWorkInfo(msg.labor_list(i), null, true);
            }
        }
        ///结束接收协议


        ///开始发送协议

        /// <summary>
        /// 请求劳工列表信息
        /// </summary>
        public void ReqWorkerList_CS()
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqWorkerList.StartReqWorkerList(tFBB);
            var tOffset = swm.ReqWorkerList.EndReqWorkerList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqWorkerList.HashID, tFBB);
        }



        /// <summary>
        /// 请求追随者列表信息
        /// </summary>
        public void ReqFollowerList_CS()
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqFollowerList.StartReqFollowerList(tFBB);
            var tOffset = swm.ReqFollowerList.EndReqFollowerList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqFollowerList.HashID, tFBB);
        }

        /// <summary>
        /// 是否手动刷新
        /// </summary>
        /// <param name="refresh"></param>
        public void ReqTavernInfo_CS(bool refresh)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqTavernInfo.CreateReqTavernInfo(tFBB, refresh);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqTavernInfo.HashID, tFBB);
        }

        /// <summary>
        /// 招募劳工
        /// </summary>
        /// <param name="labor_id">雇佣的劳工id</param>
        public void ReqHireLabor_CS(uint labor_id)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqHireLabor.CreateReqHireLabor(tFBB, labor_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHireLabor.HashID, tFBB);
        }



        /// <summary>
        /// 劳工遣散
        /// </summary>
        /// <param name="labor_id"></param>
        public void ReqFireLabor_CS(uint labor_id)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqFireLabor.CreateReqFireLabor(tFBB, labor_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqFireLabor.HashID, tFBB);
        }

        /// <summary>
        /// 劳工完成任务 (劳工状态需要玩家手动点击)
        /// </summary>
        /// <param name="labor_id"></param>
        public void ReqLaborFinishWork_CS(List<uint> labor_id)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.ReqLaborFinishWork.CreateLaborListVector(tFBB, labor_id.ToArray());
            swm.ReqLaborFinishWork.StartReqLaborFinishWork(tFBB);
            swm.ReqLaborFinishWork.AddLaborList(tFBB, vec);
            tFBB.Finish(swm.ReqLaborFinishWork.EndReqLaborFinishWork(tFBB).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqLaborFinishWork.HashID, tFBB);
        }

        
        /// <summary>
        /// 完成全部劳工 完工的状态
        /// </summary>
        public void SendFinishAllLaborWork()
        {
            m_tempStoreIdList.Clear();
            ulong _t = GameScene.Instance.GetServerTime();
            foreach (var _v in m_HomeLaborList)
            {
                HomeWorkerInfo _info = _v.Value.Worker.WorkerInfo;
                if(_info.End_time>0&&_info.End_time < _t)
                {
                    m_tempStoreIdList.Add(_v.Key);
                }
            }
            if (m_tempStoreIdList.Count>0)
            {
                ReqLaborFinishWork_CS(m_tempStoreIdList);
            }
        }

        /// <summary>
        /// 检查是否有可以完成的劳工
        /// </summary>
        /// <returns></returns>
        public bool CheckIsHasCanCompleteLabor()
        {
            ulong _t = GameScene.Instance.GetServerTime();
            foreach (var _v in m_HomeLaborList)
            {
                HomeWorkerInfo _info = _v.Value.Worker.WorkerInfo;
                if (_info.End_time > 0 &&_info.End_time < _t)
                {
                    return true;
                }
            }
            return false;
        }



        /// <summary>
        /// 追随者任务派遣
        /// </summary>
        /// <param name="labor_id"></param>
        /// <param name="target_id"></param>
        public void ReqFollowerToWork_CS(uint labor_id, uint target_id)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var tOffset = swm.ReqFollowerToWork.CreateReqFollowerToWork(tFBB, labor_id, target_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqFollowerToWork.HashID, tFBB);
        }

        /// <summary>
        /// 追随者完成任务 (追随者状态需要玩家手动点击)
        /// </summary>
        /// <param name="labor_id"></param>
        public void ReqFollowerFinishWork_CS(List<uint> _follower_id)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            var vec = swm.ReqFollowerFinishWork.CreateFollowerListVector(tFBB, _follower_id.ToArray());

            swm.ReqFollowerFinishWork.StartReqFollowerFinishWork(tFBB);
            swm.ReqFollowerFinishWork.AddFollowerList(tFBB, vec);
            tFBB.Finish(swm.ReqFollowerFinishWork.EndReqFollowerFinishWork(tFBB).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqFollowerFinishWork.HashID, tFBB);
        }

        /// <summary>
        /// 完成全部随从 完工的状态
        /// </summary>
        public void SendFinishAllFollowerWork()
        {
            m_tempStoreIdList.Clear();
            ulong _t = GameScene.Instance.GetServerTime();
            foreach (var _v in m_HomeFollowerList)
            {
                HomeWorkerInfo _info = _v.Value.Worker.WorkerInfo;
                if (_info.End_time>0&&_info.End_time < _t)
                {
                    m_tempStoreIdList.Add(_v.Key);
                }
            }
            if (m_tempStoreIdList.Count > 0)
            {
                ReqFollowerFinishWork_CS(m_tempStoreIdList);
            }
        }

        /// <summary>
        /// 检查是否有可以完成的随从
        /// </summary>
        /// <returns></returns>
        public bool CheckIsHasCanCompleteFollower()
        {
            ulong _t = GameScene.Instance.GetServerTime();
            foreach (var _v in m_HomeFollowerList)
            {
                HomeWorkerInfo _info = _v.Value.Worker.WorkerInfo;
                if (_info.End_time >0 && _info.End_time < _t)
                {
                    return true;
                }
            }
            return false;
        }


        /// <summary>
        /// 请求已解锁任务信息
        /// </summary>
        public void ReqHomeTaskList_CS()
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqHomeTaskList.StartReqHomeTaskList(tFBB);
            var tOffset = swm.ReqHomeTaskList.EndReqHomeTaskList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeTaskList.HashID, tFBB);
        }
        ///结束发送协议
        ///

        
        public void ReqHomeMakeItem_CS(uint building_uid, uint trading_id, List<uint> worker_list, uint repeated_num)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.ReqHomeMakeItem.CreateWorkerListVector(tFBB, worker_list.ToArray());

            var tOffset = swm.ReqHomeMakeItem.CreateReqHomeMakeItem(tFBB, building_uid, trading_id, vec, repeated_num);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeMakeItem.HashID, tFBB);
        }

        private void RspHomeMakeItem_SC(swm.RspHomeMakeItem msg)
        {
            onMakeItemEvent.Invoke(msg.building_uid, msg.trading_id);
        }

        private void NotifyHomeWorkerInfoChanged_SC(swm.NotifyHomeWorkerInfoChanged msg)
        {


            onWorkerInfoChangedEvent.Invoke();
        }

        public void ReqHomeWorkerFinishWork_CS(List<uint> worker_list)
        {
            var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.ReqHomeWorkerFinishWork.CreateWorkerListVector(tFBB, worker_list.ToArray());
            var tOffset = swm.ReqHomeWorkerFinishWork.CreateReqHomeWorkerFinishWork(tFBB, vec);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqHomeWorkerFinishWork.HashID, tFBB);
        }

        private void RspHomeWorkerFinishWork_SC(swm.RspHomeWorkerFinishWork msg)
        {


            onWorkerFinishWorkEvent.Invoke();
        }
    }
}
