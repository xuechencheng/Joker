﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using Bokura;

namespace Bokura
{

    //下载资源文件，支持断点续传
    public class HttpDownloadFile : MonoBehaviour
    {

        private static HttpDownloadFile instance;
        public static HttpDownloadFile _Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new GameObject("Download").AddComponent<HttpDownloadFile>();
                }
                return instance;
            }
        }

        private Dictionary<string, UnityWebRequest> listRequest = new Dictionary<string, UnityWebRequest>();    //下载请求的列表

        /// <summary>
        /// 开始下载资源
        /// </summary>
        /// <param name="url">资源的url</param>
        /// <param name="savePath">下载后保存文件的绝对路径，包含文件名称和扩展名</param>
        public HttpDownloadHandler StartDownload(string url, string savePath, string md5)
        {
            if (listRequest.ContainsKey(url))
            {
                LogHelper.Log("下载列表已经存在路径=>", url);
                //return listRequest[url].downloadHandler as _DownloadHandler;
                return null;    //如果已经存在，则返回null
            }
            var loadHandler = new HttpDownloadHandler(savePath, md5);
            UnityWebRequest request = UnityWebRequest.Get(url);
            request.timeout = 50;
            request.chunkedTransfer = true;
            request.disposeDownloadHandlerOnDispose = true;
            request.SetRequestHeader("Range", Bokura.Utilities.BuildString("bytes = ", loadHandler.DownedLength.ToString(), "-")); //断点续传设置读取文件数据流开始索引，成功会返回206
            request.downloadHandler = loadHandler;
            request.SendWebRequest(); //协程操作
            listRequest.Add(url, request);   //保存下载的请求
            return loadHandler;
        }

        //停止下载操作
        public void StopDownload(string url)
        {
            UnityWebRequest request = null;
            if (!listRequest.TryGetValue(url, out request))
            {
                LogHelper.Log("不存在下载的请求=>", url);
                return;
            }
            listRequest.Remove(url);
            (request.downloadHandler as HttpDownloadHandler).OnDispose();  //释放文件操作的资源
            request.Abort();    //中止下载
            request.Dispose();  //释放

        }

        //private void Update()
        //{
        //    //释放下载完成的操作
        //    List<string> removeList = new List<string>();
        //    foreach (string url in listRequest.Keys)
        //    {
        //        UnityWebRequest request = listRequest[url];
        //        if (request.isDone)
        //        {
        //            request.Dispose();
        //            removeList.Add(url);
        //        }
        //    }

        //    for (int i = 0; i < removeList.Count; i++)
        //    {
        //        listRequest.Remove(removeList[i]);
        //    }
        //    removeList.Clear();
        //}

        public enum DownStatus
        {
            None,
            Downloading,
            Completed,
            Error,
        }

        public DownStatus CheckStatus(string url, ref ulong downBytes)
        {

            UnityWebRequest request = null;
            if (!listRequest.TryGetValue(url, out request))
            {
                LogHelper.Log("不存在下载的请求=>", url);
                return DownStatus.None;
            }

            downBytes = request.downloadedBytes;
            bool noError = string.IsNullOrEmpty(request.error);
            if (request.isDone && noError)
            {
                request.Dispose();
                listRequest.Remove(url);
                return DownStatus.Completed;
            }

            if (noError == false)
            {
                LogHelper.LogWarning(request.error);
                return DownStatus.Error;
            }
            return DownStatus.Downloading;
        }

        private void OnDestroy()
        {
            //释放下载完成的操作
            foreach (string url in listRequest.Keys)
            {
                (listRequest[url].downloadHandler as HttpDownloadHandler).OnDispose();  //释放资源
                listRequest[url].Dispose();
            }
            listRequest.Clear();
        }

    }

}