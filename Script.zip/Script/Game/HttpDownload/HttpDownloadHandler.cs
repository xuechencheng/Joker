﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using Bokura;

namespace Bokura
{
    //下载句柄，自定义部分操作和数据
    public class HttpDownloadHandler : DownloadHandlerScript
    {
        //文件流，用来写入文件数据
        private FileStream fs;

        //要下载的文件总长度
        private int _contentLength = 0;
        public int ContentLength
        {
            get { return _contentLength; }
        }

        //已经下载的数据长度
        private int _downedLength = 0;
        public int DownedLength
        {
            get { return _downedLength; }
        }

        //要保存的文件名称，带扩展名
        private string _fileName;
        public string FileName
        {
            get { return _fileName; }
        }

        //要保存的文件路径
        private string savePath = null;

        //下载中的临时文件名，可自定义：fileName+.temp
        public string FileNameTemp
        {
            get { return Bokura.Utilities.BuildString(_fileName, ".temp"); }
        }

        //保存的文件目录名称
        public string DirectoryPath
        {
            get { return savePath.Substring(0, savePath.LastIndexOf('/')); }
        }

        #region 消息通知事件

        private event Action<int> _eventTotalLength = null; //接收到数据总长度的事件回调，传递的参数是文件总大小，单位：字节

        private event Action<float> _eventProgress = null;    //进度通知事件，传递的是进度浮点数

        private event Action<string> _eventComplete = null;  //完成后的事件回调，传递的参数是文件路径

        #endregion

        #region 注册消息事件

        //注册收到文件总长度的事件，传递的参数是文件总大小，单位：字节
        public void RegisteReceiveTotalLengthBack(Action<int> back)
        {
            if (back != null)
                _eventTotalLength += back;
        }

        //注册进度事件，传递的是进度浮点数
        public void RegisteProgressBack(Action<float> back)
        {
            if (back != null)
                _eventProgress += back;
        }

        //注册下载完成后的事件，传递的参数是文件路径
        public void RegisteCompleteBack(Action<string> back)
        {
            if (back != null)
                _eventComplete += back;
        }

        #endregion

        /// <summary>
        /// 初始化下载句柄，定义每次下载的数据上限为200kb
        /// </summary>
        /// <param name="filePath">文件路径，下载的数据直接写入文件路径</param>
        /// <param name="md5">文件MD5码，下载的文件的MD5</param>
        public HttpDownloadHandler(string filePath, string md5) : base(new byte[1024 * 200])
        {
            savePath = filePath.Replace('\\', '/');
            _fileName = savePath.Substring(savePath.LastIndexOf('/') + 1);  //获取文件名
            //创建文件目录
            string localdir = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(localdir))
            {
                Directory.CreateDirectory(localdir);
            }

            try
            {
                bool bAppend = false;
                if (string.IsNullOrEmpty(md5))
                {
                    //直接下载
                    bAppend = false;
                }
                else
                {
                    //读取上次下载未完成的文件md5码，分析是否可以断点续传
                    var stream = new FileStream(Bokura.Utilities.BuildString(savePath, ".md5"), FileMode.OpenOrCreate);
                    if (stream.Length > 0)
                    {
                        byte[] data = new byte[stream.Length];
                        stream.Read(data, 0, (int)stream.Length);
                        string strData = System.Text.Encoding.Default.GetString(data);
                        if (string.Equals(md5, strData))
                        {
                            bAppend = true;
                        }
                        else
                        {
                            bAppend = false;
                            byte[] md5Data = System.Text.Encoding.UTF8.GetBytes(md5);
                            stream.Write(md5Data, 0, md5Data.Length);
                        }
                    }

                    stream.Flush();
                    stream.Close();
                }

                if (bAppend)
                {
                    this.fs = new FileStream(Bokura.Utilities.BuildString(savePath, ".temp"), FileMode.OpenOrCreate);    //文件流操作的是临时文件，结尾添加.temp扩展名
                    _downedLength = (int)fs.Length;  //设置已经下载的数据长度
                    fs.Position = _downedLength; //设置继续写入数据的起始位置
                }
                else
                {
                    this.fs = new FileStream(Bokura.Utilities.BuildString(savePath, ".temp"), FileMode.OpenOrCreate);    //重新下载
                    _downedLength = 0;
                }
            }
            catch
            {

            }
        }

        /// <summary>
        /// 当从网络接收数据时的回调，每帧调用一次
        /// </summary>
        /// <param name="data">接收到的数据字节流，总长度为构造函数定义的200kb，并非所有的数据都是新的</param>
        /// <param name="dataLength">接收到的数据长度，表示data字节流数组中有多少数据是新接收到的，即0-dataLength之间的数据是刚接收到的</param>
        /// <returns>返回true表示当下载正在进行，返回false表示下载中止</returns>
        protected override bool ReceiveData(byte[] data, int dataLength)
        {
            //LogHelper.Log("接收到的数据长度:" + ((float)(dataLength / 1024)).ToString("0.0") + "KB/" + ((float)(data.Length / 1024)).ToString("0.0") + "KB");
            if (data == null || data.Length == 0)
            {
                LogHelper.Log("没有获取到数据缓存！");
                return false;
            }
            fs.Write(data, 0, dataLength);
            _downedLength += dataLength;
            //LogHelper.Log("数据进度=>" + ((float)(_downedLength / 1024)).ToString("0.0") + "KB/" + ((float)(_contentLength / 1024)).ToString("0.0") + "KB");

            if (_eventProgress != null)
                _eventProgress.Invoke((float)_downedLength / _contentLength);   //通知进度消息

            return true;
        }

        /// <summary>
        /// 所有数据接收完成的回调，将临时文件保存为制定的文件名
        /// </summary>
        protected override void CompleteContent()
        {
            OnDispose();

            //LogHelper.Log("下载完成！");
            string CompleteFilePath = Bokura.Utilities.BuildString(DirectoryPath, "/", FileName);   //完整路径
            string TempFilePath = fs.Name;   //临时文件路径
            string Md5FilePath = Bokura.Utilities.BuildString(savePath, ".md5");

            if (File.Exists(Md5FilePath))
            {
                File.Delete(Md5FilePath);
            }

            if (File.Exists(TempFilePath))
            {
                if (File.Exists(CompleteFilePath))
                {
                    File.Delete(CompleteFilePath);
                }
                File.Move(TempFilePath, CompleteFilePath);
                //LogHelper.Log("重命名文件！");
            }
            else
            {
                LogHelper.Log("生成文件失败=>下载的文件不存在！");
            }
            if (_eventComplete != null)
                _eventComplete.Invoke(CompleteFilePath);
        }

        public void OnDispose()
        {
            //LogHelper.Log("下载总量=>" + _downedLength);
            fs.Close();
            fs.Dispose();
        }

        /// <summary>
        /// 请求下载时，会先接收到文件的数据总量
        /// </summary>
        /// <param name="contentLength">文件的数据总长度</param>
        [Obsolete]
        protected override void ReceiveContentLength(int contentLength)
        {
            _contentLength = contentLength + _downedLength;
            if (_eventTotalLength != null)
                _eventTotalLength.Invoke(_contentLength);
            //LogHelper.Log(string.Format("收到头部信息==>>数据总长度{0}", contentLength));
        }
    }
}
