﻿//using UnityEngine;
using System.Collections;
using System.Threading;
using System.Net;
using System.IO;
using System;
using System.Security.Cryptography;
using Bokura;

namespace Bokura
{

    public class HttpDownloader : IDisposable
    {
        bool m_bIsDone;
        string m_sError="";
		long m_nDownloadBytes;
        long m_nTotalBytes;
        Thread m_DownloadThread;
        string m_sFileMD5="";
        long m_nSpeedLimite = 0;//10*1024*1024;
		const int m_nHttpTimeout = 10 * 1000;
        int m_nDownloadSpeed = 0;
        bool m_bDowloadCancel = false;
        ~HttpDownloader()
        {
            Dispose();
        }

        public void Dispose()
        {
            if (m_DownloadThread != null)
            {
                Cancel();
                m_DownloadThread.Join();
                m_DownloadThread = null;
            }
        }

        public void Cancel()
        {
            m_bDowloadCancel = true;
        }
        public bool Download(string url, string localpath, bool redownload = false )
        {
            if (m_DownloadThread != null)
                return false;
            m_bIsDone = false;
            m_bDowloadCancel = false;
            m_sFileMD5 = "";
            m_sError = "";
            m_nTotalBytes = 0;
            m_nDownloadBytes = 0;

            m_DownloadThread = new Thread(()=> { downloadThread(url, localpath, redownload); });
            m_DownloadThread.Start();
            return true;
        }
		void downloadThread(string url, string localpath, bool redownload)
        {



            LogHelper.Log("download:",url," -> ",localpath);
            FileStream fs = null;
			//string downloadingpath = localpath + ".tmp";
            long downloadoffest = 0;
			WebResponse wr = null;
            var md5 = new MD5CryptoServiceProvider();

            try
            {

				md5.Initialize();
				//var md5outbuf = new byte[1024*64];
				//var md5srcbuff = new byte[1024*64];
				byte[] cache = new byte[1024 * 64];

                HttpWebRequest httpreq = (HttpWebRequest)WebRequest.Create(url);
                httpreq.Timeout = m_nHttpTimeout;
                httpreq.ReadWriteTimeout = m_nHttpTimeout;

                wr = httpreq.GetResponse();
                m_nTotalBytes = wr.ContentLength;

                if (File.Exists(localpath) &&!redownload)
                {
                    fs = new FileStream(localpath, FileMode.Open, FileAccess.Read);
                    downloadoffest = fs.Length;
					
					fs.Seek(0, SeekOrigin.Begin);
					int readlen = 0;
					while((readlen = fs.Read(cache, 0, cache.Length) )>0)
					{
						md5.TransformBlock(cache, 0, readlen, cache, 0);
						m_nDownloadBytes += readlen;
					}
					fs.Close();

					fs = new FileStream(localpath, FileMode.Append);


				}
				else
                {
                    string localdir = Path.GetDirectoryName(localpath);
                    if(!Directory.Exists(localdir))
                    {
                        Directory.CreateDirectory(localdir);
                    }

                    fs = new FileStream(localpath, FileMode.Create);
                }





				if (wr.ContentLength> downloadoffest)
                {
					m_nTotalBytes = wr.ContentLength;
					m_nDownloadBytes = downloadoffest;
					wr.Close();
					httpreq = (HttpWebRequest)WebRequest.Create(url);
					httpreq.Timeout = m_nHttpTimeout;
                    httpreq.ReadWriteTimeout = m_nHttpTimeout;
					httpreq.AddRange(downloadoffest);

					wr = httpreq.GetResponse();

					var httpstream = wr.GetResponseStream();
                    var prevchecktime = System.Environment.TickCount;
                    long curdownloadbytes = 0;
                    if (httpstream != null)
                    {
                        
                        int nReadBytes = 0;
                        while ((nReadBytes = httpstream.Read(cache, 0, cache.Length)) > 0 && !m_bDowloadCancel)
                        {
                            fs.Write(cache, 0, nReadBytes);
							md5.TransformBlock(cache, 0, nReadBytes, cache, 0);
							m_nDownloadBytes += nReadBytes;
                            if (m_nSpeedLimite>0)
                            {
                                curdownloadbytes += nReadBytes;

                                if (curdownloadbytes > m_nSpeedLimite)
                                {
                                    while (System.Environment.TickCount - prevchecktime < 1000)
                                    {
                                        Thread.Sleep(1);
                                    }
                                    prevchecktime = System.Environment.TickCount;
                                    curdownloadbytes = 0;
                                }
                               
                            }
                        }

                        //fs = null;
                       
                    
                    }
                    else
                    {
                        m_sError = "http response stream error!";
                    }
			
                }
                if(m_bDowloadCancel)
                {
                    m_sError = "User Cancel Download!";
                }
                else if(m_nDownloadBytes< m_nTotalBytes)
                {
                    m_sError = "connection closed!";
                }

				wr.Close();
				wr = null;

				fs.Flush();
                fs.Close();
				fs = null;

				var md5byte = md5.TransformFinalBlock(cache, 0, 0);
				md5byte = md5.Hash;
				//fs = new FileStream(localpath, FileMode.Open);
				//var md5byte = md5.ComputeHash(fs);

				m_sFileMD5 = "";
				for (int i = 0; i < md5byte.Length; i++)
				{
					m_sFileMD5 += md5byte[i].ToString("X2");
				}
				//fs.Close();
				//fs = null;
			}
            catch(Exception e)
            {
                m_sError = e.ToString();
				if (wr!=null)
				{
					wr.Close();
					wr = null;
				}
 
            }
            md5.Dispose();
            if (fs != null)
            {
                fs.Flush();
                fs.Close();
            }
            m_DownloadThread = null;
            m_bIsDone = true;

            LogHelper.Log("download thread exit!", localpath, m_nDownloadBytes);

        }

        public bool IsDone()
        {
            return m_bIsDone;
        }

        public long GetDownloadedBytesNum()
        {
            return m_nDownloadBytes;
        }

        public long GetTotalBytesNum()
        {
            return m_nTotalBytes;
        }
        public string GetError()
        {
            return m_sError;
        }
        public string GetMD5()
        {
            return m_sFileMD5;
        }
        public void SetSpeedLimite(int nSpeed)
        {
            m_nSpeedLimite = nSpeed;
        }

        public int GetSpeed()
        {
            return m_nDownloadSpeed;
        }
    }
}

