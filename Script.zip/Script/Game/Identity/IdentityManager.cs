using UnityEngine;
using System.Collections.Generic;

using Bokura;

namespace Bokura
{
    public class IdentityManager : ClientSingleton<IdentityManager>
    {
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshTalent>(OnRefreshTalent);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspIdentityInfo>(OnRspIdentityInfo);
        }

        [XLua.BlackList]
        public void Clear()
        {

        }


        private List<SingleTalentInfo> m_talentInfos = new List<SingleTalentInfo>(0);

        public GameEvent OnIdentityInfoChanged = new GameEvent();

        public string GetNameByIdentityType(swm.IdentityType iType)
        {

            IdentityTableBaseList list = IdentityTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityTableLength; i < count; ++i)
            {
                IdentityTableBase table = list.IdentityTable(i).Value;

                if (table.indentity_type == (int)iType)
                {
                    return table.indentity_name;
                }
            }

            return "";
        }

        void OnRefreshTalent(swm.RefreshTalent msg)
        {
            swm.TalentInfo data = msg.data.Value;

            bool isHave = false;

            for (int i=0, count = m_talentInfos.Count; i<count; ++i)
            {
                if (m_talentInfos[i].id == data.id)
                {
                    m_talentInfos[i].num = data.num;
                    m_talentInfos[i].red_dots = data.red_dots;

                    isHave = true;

                    break;
                }
            }

            if (!isHave)
            {
                addToTalentInfos(data);
            }

            OnIdentityInfoChanged.Invoke();
        }

        void addToTalentInfos(swm.TalentInfo data)
        {
            SingleTalentInfo info = new SingleTalentInfo();
            info.id = data.id;
            info.num = data.num;
            info.red_dots = data.red_dots;

            m_talentInfos.Add(info);
        }

        public void ReqIdentityInfo()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqIdentityInfo.StartReqIdentityInfo(fbb);
            var msg = swm.ReqIdentityInfo.EndReqIdentityInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqIdentityInfo.HashID, fbb);
        }

        void OnRspIdentityInfo(swm.RspIdentityInfo msg)
        {
            m_talentInfos.Clear();

            swm.TalentInfo data; 

            for (int i=0, len = msg.datasLength; i<len; ++i)
            {
                data = msg.datas(i).Value;

                addToTalentInfos(data);
            }

            OnIdentityInfoChanged.Invoke();
        }


        private List<IdentityTableBase> m_tempDatas = new List<IdentityTableBase>(0);
        public List<IdentityTableBase> GetAllCurrTalentTypeDatas(int iType)
        {
            m_tempDatas.Clear();

            IdentityTableBaseList list = IdentityTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityTableLength; i < count; ++i)
            {
                IdentityTableBase table = list.IdentityTable(i).Value;

                if (table.talent_type == (int)iType)
                {
                    m_tempDatas.Add(table);
                }
            }

            return m_tempDatas;
        }

        public List<IdentityTableBase> GetCurrIdentityDatas(swm.IdentityType iType)
        {
            m_tempDatas.Clear();

            IdentityTableBaseList list = IdentityTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityTableLength; i < count; ++i)
            {
                IdentityTableBase table = list.IdentityTable(i).Value;

                if (table.indentity_type == (int)iType)
                {
                    if (table.talent_num <= (int)GetCurrTalentNumById(table.id))
                    {
                        if (!isHaveNextId(table.talent_type, table.id))
                        {
                            if (!isHaveThisTalentType(table.talent_type))
                            {
                                m_tempDatas.Add(table);
                            }
                        }
                    }
                    else
                    {
                        if (!isHaveThisTalentType(table.talent_type))
                        {
                            m_tempDatas.Add(table);
                        }
                    }
                }
            }

            return m_tempDatas;
        }

        private bool isHaveThisTalentType(int talentType)
        {
            for (int i = 0, count = m_tempDatas.Count; i < count; ++i)
            {
                IdentityTableBase table = m_tempDatas[i];

                if (table.talent_type == talentType)
                {
                    return true;
                }
            }

            return false;
        }

        public bool isHaveNextId(int talentType, int id)
        {
            IdentityTableBaseList list = IdentityTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityTableLength; i < count; ++i)
            {
                IdentityTableBase table = list.IdentityTable(i).Value;

                if (table.talent_type == talentType)
                {
                    if (table.pre_talent_id == id)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public ulong GetCurrTalentNumById(int id)
        {
            for (int i = 0, count = m_talentInfos.Count; i < count; ++i)
            {
                if (m_talentInfos[i].id == id)
                {
                    return m_talentInfos[i].num;
                }
            }

            return 0;
        }

        public IdentityTableBase GetCurrTalentConfigById(int id)
        {
            IdentityTableBaseList list = IdentityTableManager.Instance.m_DataList;
            for (int i = 0, count = list.IdentityTableLength; i < count; ++i)
            {
                IdentityTableBase table = list.IdentityTable(i).Value;

                if (table.id == id)
                {
                    return table;
                }
            }

            return default(IdentityTableBase);
        }

        public List<int> GetCurrTalentMaxIDsByType(int identityType)
        {
            List<int> ids = new List<int>(0);

            List<IdentityTableBase> all = GetCurrIdentityDatas((swm.IdentityType)identityType);

            for (int i=0; i<all.Count; ++i)
            {
                int id = all[i].id;
                IdentityTableBase cfg = GetCurrTalentConfigById(id);

                if (cfg.talent_num <= (int)GetCurrTalentNumById(id))
                {
                    ids.Add(id);
                }
                else
                {
                    ids.Add(cfg.pre_talent_id);
                }
            }


            return ids;
        }



        public class SingleTalentInfo
        {
            public uint id;
            public ulong num;
            public bool red_dots;
        }
    }
}
