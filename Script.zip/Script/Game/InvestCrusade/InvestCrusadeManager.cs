using UnityEngine;
using System.Collections.Generic;

using Bokura;

namespace Bokura
{
    public class InvestCrusadeManager : ClientSingleton<InvestCrusadeManager>
    {
        [XLua.BlackList]
        public void Init()
        {

        }

        [XLua.BlackList]
        public void Clear()
        {

        }

        public PlacerewardTableBase GetPlacerewardTableById(int id)
        {
            PlacerewardTableBaseList list = PlacerewardTableManager.Instance.m_DataList;
            for (int i = 0, count = list.PlacerewardTableLength; i < count; ++i)
            {
                PlacerewardTableBase table = list.PlacerewardTable(i).Value;

                if (table.id == id)
                {
                    return table;
                }
            }

            return default(PlacerewardTableBase);
        }

        public enum InvestCrusadeState
        {

        }
    }
}