using System.Collections.Generic;
using Bokura;
using UnityEngine;

namespace Bokura
{

    public enum AttributeEnum_
    {
        prop_str = 4,
        prop_int = 6,
        prop_sta = 8,
        prop_dex = 10,
        str_pct = 12,
        int_pct = 14,
        sta_pct = 16,
        dex_pct = 18,
        str_dpct = 20,
        int_dpct = 22,
        sta_dpct = 24,
        dex_dpct = 26,
        hp = 28,
        pdam = 30,//最小最大物理攻击
        max_pdam = 32,//最大物理攻击
        mdam = 34,//最小最大魔法攻击
        max_mdam = 36,//最大魔法攻击
        pdef = 38,
        mdef = 40,
        hp_pct = 42,
        pdam_pct = 44,
        max_pdam_pct = 46, 
        mdam_pct = 48,
        max_mdam_pct = 50,
        pdef_pct = 52,
        mdef_pct = 54,
        hp_dpct = 56,
        pdam_dpct = 58,
        max_pdam_dpct = 60,
        mdam_dpct = 62,
        max_mdam_dpct = 64,
        pdef_dpct = 66,
        mdef_dpct = 68,
        ppen = 70,
        mpen = 72,
        ppen_pct = 74,
        mpen_pct = 76,
        pdam_add_pct = 78,
        mdam_add_pct = 80,
        psuf_pct = 82,
        psuf_com_pct = 84,
        msuf_pct = 86,
        msuf_com_pct = 88,
        attack_speed = 90,
        attack_speed_pct = 92,
        attack_speed_dpct = 94,
        crit_level = 96,
        crit_pct = 98,
        crit_effect = 100,
        cooldown_dec = 102,
        move_speed = 104,
        move_speed_pct = 106,
        move_speed_dpct = 108,
        attack_renew = 110,
        renew = 112,
        attack_renew_pct = 114,
        attack_renew_dpct = 116,
        renew_pct = 118,
        renew_dpct = 120,
        melee_pct = 122,
        ranged_pct = 124,
        suf_melee_dpct = 126,
        suf_ranged_dpct = 128,
        heal_pct = 130,
        suf_heal_pct = 132,
        suf_heal_dpct = 134,
        suf_crit_effect_dec = 136,
        mp = 138,
        anger = 140,
        prof_armforce = 142,
        prof_technique = 144,
        prof_inspiration = 146,
        fire_atk            = 148,
        water_atk           = 150,
        thunder_atk         = 152,
        wind_atk            = 154,
        poison_atk          = 156,
        all_element_atk     = 158,
        fire_def            = 160,
        water_def           = 162,
        thunder_def         = 164,
        wind_def            = 166,
        poison_def          = 168,
        all_element_def     = 170,
        fire_pen            = 172,
        water_pen           = 174,
        thunder_pen         = 176,
        wind_pen            = 178,
        poison_pen          = 180,
        all_element_pen = 182,

    }
    /// <summary>
    /// 道具属性描述
    /// </summary>
    public class ItemAttributeDesc
    {
        private int m_ID            = 0;
        /// <summary>
        /// 属性编号
        /// </summary>
        public int Id
        {
            get { return m_ID; }
        }

        private long m_NetCurrentValue = 0;

        /// <summary>
        /// 当前值 服务器的原始值
        /// </summary>
        public long NetCurrentValue
        {
            get
            {
                return m_NetCurrentValue;
            }
        }

        public string colorDex = "";

        private float m_CurrentValue = 0;
        /// <summary>
        /// 当前值 通过coef修改过 ，如果coef = 1的话 和NetCurrentValue 一致的
        /// </summary>
        public float CurrentValue
        {
            get
            {
                if (Config.HasValue)
                {
                    int _coef = Config.Value.coef;
                    if (_coef > 1)
                    {
                        m_CurrentValue = 100.0f * m_NetCurrentValue / _coef;
                    }
                    else
                    {
                        m_CurrentValue = m_NetCurrentValue;
                    }

                }
                else
                {
                    m_CurrentValue = m_NetCurrentValue;
                }
                return m_CurrentValue;
            }
        }

        private long m_NetMaxValue = 0;

        /// <summary>
        /// 最大值 服务器的原始值
        /// </summary>
        public long NetMaxValue
        {
            get
            {
                return m_NetMaxValue;
            }
        }

        private float m_MaxValue     = 0;
        /// <summary>
        /// 通过coef修改过，如果coef = 1的话 和NetCurrentValue 一致的 有这个值就说明是区间（此时m_currentValue表示左区间）
        /// </summary>
        public float MaxValue
        {
            get
            {
                if (Config.HasValue)
                {
                    int _coef = Config.Value.coef;
                    if (_coef > 1)
                    {
                        m_MaxValue = 100.0f * m_NetMaxValue / _coef;
                    }
                    else
                    {
                        m_MaxValue = m_NetMaxValue;
                    }

                }
                else
                {
                    m_MaxValue = m_NetMaxValue;
                }
                return m_MaxValue;
            }
        }
        private string m_Des        = string.Empty;
        /// <summary>
        /// 完整格式化文本：名称+值
        /// </summary>
        public string Des
        {
            get
            {
                if (string.IsNullOrEmpty(m_Des))
                    m_Des = Utilities.BuildString(false, Des_Name, ":", Des_Value);
                return m_Des;
            }
        }
        private string m_Des_SuperName = string.Empty;
        /// <summary>
        /// 完整格式化文本：属性署名+名称+值
        /// </summary>
        public string Des_Supername
        {
            get
            {
                if (string.IsNullOrEmpty(m_Des_SuperName))
                    m_Des_SuperName = Utilities.BuildString(false, SuperName, Des_Name, ":", Des_Value);
                return m_Des_SuperName;
            }
        }

       
        private string m_SuperName = string.Empty;
        /// <summary>
        /// 属性署名
        /// </summary>
        public string SuperName
        {
            get
            {
                if (string.IsNullOrEmpty(m_SuperName))
                {
                    if (Config.HasValue)
                        m_SuperName = Config.Value.prop_supername;
                    //if(string.IsNullOrEmpty(m_SuperName))
                    //{
                    //    m_SuperName = "<color=#F767FEFF>测试文字</color>";
                    //}
                }
                return m_SuperName;
            }
        }

        private string m_DesName    = string.Empty;
        /// <summary>
        /// 名称文本
        /// </summary>
        public string Des_Name
        {
            get
            {
                if (string.IsNullOrEmpty(m_DesName))
                {
                    if (Config.HasValue)
                        m_DesName = string.Format(colorDex, Config.Value.color_desc);
                }
                return m_DesName;
            }
        }
        private string m_DesValue  = string.Empty;
        /// <summary>
        /// 值文本
        /// </summary>
        public string Des_Value
        {
            get
            {
                if (string.IsNullOrEmpty(m_DesValue))
                {
                    if (Config.HasValue)
                    {
                        int _coef = Config.Value.coef;
                        if (_coef > 1)
                        {
                            if (NetMaxValue == 0)
                            {
                                m_DesValue = Utilities.BuildFormatString("{0:N1}%", CurrentValue.ToString());
                            }
                            else
                            {
//                                 float _maxValue = MaxValue;
                                m_DesValue = Utilities.BuildFormatString("{0:N1}%~{1:N1}%", CurrentValue.ToString(), MaxValue.ToString());
                            }
                        }
                        else
                        {
                            if (NetMaxValue == 0)
                            {
                                m_DesValue = Utilities.BuildFormatString("{0:N0}", CurrentValue.ToString());
                            }
                            else
                            {
                                m_DesValue = Utilities.BuildFormatString("{0:N0}~{1:N0}", CurrentValue.ToString(), MaxValue.ToString());
                            } 
                        }
                    }
                }
                return m_DesValue;
            }
        }
        private PropTableBase? m_Config = null;
        /// <summary>
        /// 属性配置信息
        /// </summary>
        public PropTableBase? Config
        {
            get
            {
                if (!m_Config.HasValue)
                    m_Config = PropTableManager.GetData(m_ID);
                return m_Config;
            }
        }
        /// <summary>
        /// 设置属性值
        /// </summary>
        public void SetValue(int id , long currentValue, long maxValue = 0)
        {
            if (m_ID != id)
            {
                m_Config        = null;
                m_DesName       = string.Empty;
            }
            m_Des               = string.Empty;
            m_DesValue          = string.Empty;
            m_ID                = id;
            m_NetCurrentValue   = currentValue;
            m_NetMaxValue       = maxValue;

        }
        /// <summary>
        /// 获取属性id对应的属性名称
        /// </summary>
        public static string PropNameByID(int id)
        {
            for (int tIdx = 0, tCount = PropTableManager.Instance.m_DataList.PropTableLength; tIdx < tCount; ++tIdx)
            {
                PropTableBase? tConfig = PropTableManager.Instance.m_DataList.PropTable(tIdx);
                if (id == tConfig.Value.id)
                    return tConfig.Value.variable_name;
            }
            return null;
        }
        /// <summary>
        /// 获取属性名称对应的属性id
        /// </summary>
        public static int PropIDByName(string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                for (int tIdx = 0, tCount = PropTableManager.Instance.m_DataList.PropTableLength; tIdx < tCount; ++tIdx)
                {
                    PropTableBase? tConfig = PropTableManager.Instance.m_DataList.PropTable(tIdx);
                    if (name.Equals(tConfig.Value.variable_name))
                        return tConfig.Value.id;
                }
            }
            return 0;
        }
    }
    /// <summary>
    /// 物品基类
    /// </summary>
    public class ItemBase
    {
        /// <summary>
        /// 物品基id
        /// </summary>
        public int BaseID;
        /// <summary>
        /// 物品唯一id
        /// </summary>
        public ulong ID;
        /// <summary>
        /// 物品名称
        /// </summary>
        public string Name;
        /// <summary>
        /// 物品类型
        /// </summary>
        public swm.ItemType Type;
        /// <summary>
        /// 物品子类型
        /// </summary>
        public int SubType;
        /// <summary>
        /// 物品品质
        /// </summary>
        public swm.QualityType Quality;
 
        private swm.ItemDataT m_ItemData;
        /// <summary>
        /// 物品数据
        /// </summary>
        public swm.ItemDataT ItemData
        {
            get { return m_ItemData; }
            set
            {
                m_ItemData = value;
                m_ItemAttributeDescList = null;
            }
        }
        /// <summary>
        /// 获取道具数量
        /// </summary>
        public uint ItemNum
        {
            get { return ItemData != null ? ItemData.num : 0; }
        }

        private uint m_itemLastNum = 0;
        public uint ItemLastNum
        {
            get
            {
                return m_itemLastNum;
            }
            set
            {
                m_itemLastNum = value;
            }
        }
        private ulong m_currentDurable = 0;
        /// <summary>
        /// 当前耐久
        /// </summary>
        public ulong CurrentDurable
        {
            get { return m_currentDurable; }
        }
        private ulong m_maxDurable = 0;
        /// <summary>
        /// 最大耐久
        /// </summary>
        public ulong MaxDurable
        {
            get { return m_maxDurable; }
        }
        /// <summary>
        /// 物品配置
        /// </summary>
        public ItemTableBase? ItemConfig;
        private EquipTableBase? m_EquipTableConfig = null;
        /// <summary>
        /// 装备配置
        /// </summary>
        public EquipTableBase EquipTableConfig
        {
            get
            {
                if (ItemConfig.Value.type == (int)(swm.ItemType.EQUIP) && null == m_EquipTableConfig)
                    m_EquipTableConfig = EquipTableManager.GetData(ItemConfig.Value.id);
                return m_EquipTableConfig.Value;
            }
        }

        private List<ItemAttributeDesc> m_ItemAttributeDescList = null;

       
        public enum AttType
        {
            Base,
            Random,
            Craft,
        }

        /// <summary>
        /// 存储物品的属性描述信息
        /// </summary>
        public List<ItemAttributeDesc> ItemAttributeDescList
        {
            get
            {
                if (null == m_ItemAttributeDescList && null != m_ItemData && m_ItemData.base_props != null)
                {
                    //装备
                    AddEqquipAttributeCom(ref m_ItemAttributeDescList,m_ItemData.base_props, AttType.Base);
                }
                return m_ItemAttributeDescList;
            }
        }
        //随机属性
        private List<ItemAttributeDesc> m_ItemRandAttributeDescList = null;
        public List<ItemAttributeDesc> ItemRandAttributeDescList
        {
            get
            {
                if (null == m_ItemRandAttributeDescList && null != m_ItemData && m_ItemData.rand_props != null)
                {
                    //装备
                    AddEqquipAttributeCom(ref m_ItemRandAttributeDescList, m_ItemData.rand_props, AttType.Random); 
                }
                return m_ItemRandAttributeDescList;
            }
     
        }
        //打造等额外属性
        private List<ItemAttributeDesc> m_ItemMakeCraftAttributeDescList = null;
        public List<ItemAttributeDesc> ItemMakeCraftAttributeDescList
        {
            get
            {
                if (null == m_ItemMakeCraftAttributeDescList && null != m_ItemData && m_ItemData.makecraft_props != null)
                {
                    //装备
                    AddEqquipAttributeCom(ref m_ItemMakeCraftAttributeDescList, m_ItemData.makecraft_props, AttType.Craft);
                  
                }
                return m_ItemMakeCraftAttributeDescList;
            }

        }

        int SortAtt(ItemAttributeDesc att1, ItemAttributeDesc att2)
        {
            if (att1.Id < att2.Id)
                return -1;
            else
                return 1;
        }

        //System.Type tType = System.Type.GetType("swm.EntityAttrsT");
        public void AddEqquipAttributeCom(ref List<ItemAttributeDesc> attlist, List<swm.ItemAttrT> props, AttType type)
        {
            //Dictionary<uint, uint> temp = new Dictionary<uint, uint>(12);
            for (int i = 0; i < props.Count; ++i)
            {
                 swm.ItemAttrT data = props[i];
//                 if (data.type == (uint)AttributeEnum_.pdam || data.type == (uint)AttributeEnum_.max_pdam
//                     || data.type == (uint)AttributeEnum_.mdam || data.type == (uint)AttributeEnum_.max_mdam
//                     || data.type == (uint)AttributeEnum_.pdam_pct || data.type == (uint)AttributeEnum_.max_pdam_pct
//                     || data.type == (uint)AttributeEnum_.mdam_pct || data.type == (uint)AttributeEnum_.max_mdam_pct
//                     || data.type == (uint)AttributeEnum_.pdam_dpct || data.type == (uint)AttributeEnum_.max_pdam_dpct
//                     || data.type == (uint)AttributeEnum_.mdam_dpct || data.type == (uint)AttributeEnum_.max_mdam_dpct)
//                 {
//                     temp.Add(data.type, data.value);
//                 }
//                 else
                    AddEqquipAttribute(ref attlist, type, (int)data.type, data.value);
            }
            attlist.Sort(SortAtt);
//             List<uint> exist = new List<uint>(6);
// 
//             foreach(var item in temp)
//             {
//                 switch(item.Key)
//                 {
//                     case (uint)AttributeEnum_.pdam:
//                         if (!exist.Contains((uint)AttributeEnum_.pdam))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.max_pdam))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam, item.Value, temp[(uint)AttributeEnum_.max_pdam]);
//                                 exist.Add((uint)AttributeEnum_.max_pdam);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam, item.Value, 0);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.max_pdam:
//                         if (!exist.Contains((uint)AttributeEnum_.max_pdam))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.pdam))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam, temp[(uint)AttributeEnum_.pdam], item.Value);
//                                 exist.Add((uint)AttributeEnum_.pdam);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam, 0, item.Value);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.mdam:
//                         if (!exist.Contains((uint)AttributeEnum_.mdam))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.max_mdam))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam, item.Value, temp[(uint)AttributeEnum_.max_mdam]);
//                                 exist.Add((uint)AttributeEnum_.max_mdam);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam, item.Value, 0);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.max_mdam:
//                         if (!exist.Contains((uint)AttributeEnum_.max_mdam))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.mdam))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam, temp[(uint)AttributeEnum_.mdam], item.Value);
//                                 exist.Add((uint)AttributeEnum_.mdam);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam, 0, item.Value);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.pdam_pct:
//                         if (!exist.Contains((uint)AttributeEnum_.pdam_pct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.max_pdam_pct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_pct, item.Value, temp[(uint)AttributeEnum_.max_pdam_pct]);
//                                 exist.Add((uint)AttributeEnum_.max_pdam_pct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_pct, item.Value, 0);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.max_pdam_pct:
//                         if (!exist.Contains((uint)AttributeEnum_.max_pdam_pct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.pdam_pct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_pct, temp[(uint)AttributeEnum_.pdam_pct], item.Value);
//                                 exist.Add((uint)AttributeEnum_.pdam_pct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_pct, 0, item.Value);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.mdam_pct:
//                         if (!exist.Contains((uint)AttributeEnum_.mdam_pct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.max_mdam_pct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_pct, item.Value, temp[(uint)AttributeEnum_.max_mdam_pct]);
//                                 exist.Add((uint)AttributeEnum_.max_mdam_pct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_pct, item.Value, 0);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.max_mdam_pct:
//                         if (!exist.Contains((uint)AttributeEnum_.max_mdam_pct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.mdam_pct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_pct, temp[(uint)AttributeEnum_.mdam_pct], item.Value);
//                                 exist.Add((uint)AttributeEnum_.mdam_pct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_pct, 0, item.Value);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.pdam_dpct:
//                         if (!exist.Contains((uint)AttributeEnum_.pdam_dpct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.max_pdam_dpct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_dpct, item.Value, temp[(uint)AttributeEnum_.max_pdam_dpct]);
//                                 exist.Add((uint)AttributeEnum_.max_pdam_dpct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_dpct, item.Value, 0);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.max_pdam_dpct:
//                         if (!exist.Contains((uint)AttributeEnum_.max_pdam_dpct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.pdam_dpct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_dpct, temp[(uint)AttributeEnum_.pdam_dpct], item.Value);
//                                 exist.Add((uint)AttributeEnum_.pdam_dpct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.pdam_dpct, 0, item.Value);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.mdam_dpct:
//                         if (!exist.Contains((uint)AttributeEnum_.mdam_dpct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.max_mdam_dpct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_dpct, item.Value, temp[(uint)AttributeEnum_.max_mdam_dpct]);
//                                 exist.Add((uint)AttributeEnum_.max_mdam_dpct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_dpct, item.Value, 0);
//                         }
//                         break;
//                     case (uint)AttributeEnum_.max_mdam_dpct:
//                         if (!exist.Contains((uint)AttributeEnum_.max_mdam_dpct))
//                         {
//                             if (temp.ContainsKey((uint)AttributeEnum_.mdam_dpct))
//                             {
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_dpct, temp[(uint)AttributeEnum_.mdam_dpct], item.Value);
//                                 exist.Add((uint)AttributeEnum_.mdam_dpct);
//                             }
//                             else
//                                 AddEqquipAttribute(ref attlist, (int)AttributeEnum_.mdam_dpct, 0, item.Value);
//                         }
//                         break;
//                 }
//            }
        }

        /// <summary>
        /// 物品图标
        /// </summary>
        public string iconPath
		{
			get
			{
				if (ItemConfig != null && ItemConfig.HasValue)
					return ItemConfig.Value.icon;
				return string.Empty;
			}
		}

        float m_cd;
        public float CD
        {
            get
            {
                return m_cd;
            }
        }
        
        public Event<float> OnCDResest = new Event<float>();

        /// <summary>
        /// 更新装备属性信息
        /// </summary>
        public void UpdateEquipAttributes(swm.ItemData data)
        {
            if (m_ItemData != null && m_ItemData.base_props != null)
            {
                m_ItemData.base_props = new List<swm.ItemAttrT>(data.base_propsLength);
                for (int i =0; i < data.base_propsLength; ++i)
                {
                    swm.ItemAttrT item = new swm.ItemAttrT();
                    item.FromMsg(data.base_props(i).Value);
                    m_ItemData.base_props.Add(item);
                }
                if(m_ItemAttributeDescList!=null)
                {
                    m_ItemAttributeDescList.Clear();
                    m_ItemAttributeDescList = null;
                }
               
            }
        }
        public void UpdateEquipAttributesRand_props(swm.ItemData data)
        {
            if (m_ItemData != null && m_ItemData.rand_props != null)
            {
                m_ItemData.rand_props = new List<swm.ItemAttrT>(data.rand_propsLength);
                for (int i = 0; i < data.rand_propsLength; ++i)
                {
                    swm.ItemAttrT item = new swm.ItemAttrT();
                    item.FromMsg(data.rand_props(i).Value);
                    m_ItemData.rand_props.Add(item);
                }
                if (m_ItemRandAttributeDescList != null)
                {
                    m_ItemRandAttributeDescList.Clear();
                    m_ItemRandAttributeDescList = null;
                }
            }
        }

        /// <summary>
        /// 向属性列表添加属性
        /// </summary>
        private void AddEqquipAttribute(ref List<ItemAttributeDesc> attlist, AttType type, int id, long currentValue, long maxValue = 0)
        {
            if (attlist == null)
                attlist = new List<ItemAttributeDesc>(16);
            if (currentValue != 0 || maxValue != 0)
            {
                ItemAttributeDesc tData = new ItemAttributeDesc();
                if (type == AttType.Base)
                    tData.colorDex = "<color=#61B47AFF>{0}</color>";
                else
                    tData.colorDex = "<color=#A668DAFF>{0}</color>";
                tData.SetValue(id, currentValue, maxValue);
                attlist.Add(tData);
            }
        }
        public ItemBase()
        {
            //表示这是一个空的物品类
            this.ID = 0;
        }
        /// <summary>
        /// 初始化物品
        /// </summary>
        public virtual void Init(ItemTableBase configData, swm.ItemData itemData)
        {
            ItemConfig      = configData;          
            this.BaseID     = configData.id;
            this.Name       = configData.name;
            this.Type       = (swm.ItemType)configData.type;
            this.SubType    = configData.subtype;
            this.Quality    = (swm.QualityType)configData.quality;
            RefreshItem(itemData);
        }
        /// <summary>
        /// 更新物品属性和耐久
        /// </summary>
        public virtual void RefreshItem(swm.ItemData itemData)
        {
            ItemLastNum = ItemNum;
            if (m_ItemData == null)
                m_ItemData = new swm.ItemDataT();
            //ItemData = itemData;
            m_ItemData.FromMsg(itemData);
            m_ItemAttributeDescList = null;
            this.ID = itemData.id;
            SetDurableData(itemData.cur_dur, itemData.max_dur);
        }
        /// <summary>
        /// 更新物品耐久
        /// </summary>
        public void SetDurableData(ulong currentDur, ulong maxDur)
        {
            //耐久百分值（放大了100倍）
            m_currentDurable = (currentDur + 99) / 100;
            m_maxDurable = (maxDur + 99) / 100;
        }
        public virtual void ResetCD(float cd)
        {
            if (m_cd == cd)
                return;
            m_cd = cd;
            if (OnCDResest != null)
                OnCDResest.Invoke(CD);
        }
        public virtual void Update()
        {
            if (m_cd > 0.0f)
            {
                m_cd -= Time.deltaTime;
                if (m_cd <= 0.0f)
                {
                    //cd ok
                    m_cd = 0.0f;
                }
            }
        }

        /// <summary>
        /// 销毁物品
        /// </summary>
        public virtual void Destory()
        {
            ItemConfig          = null;
            m_EquipTableConfig  = null;
            ItemData            = null;
            if (null != m_ItemAttributeDescList)
            {
                m_ItemAttributeDescList.Clear();
                m_ItemAttributeDescList = null;
            }
        }
    }
}