﻿namespace Bokura
{
    /// <summary>
    /// 物品实例工厂
    /// </summary>
    public class ItemFactory : ClientSingleton<ItemFactory>
    {
        /// <summary>
        /// 创建一个物品实例
        /// </summary>
        public ItemBase CreateItem(ItemTableBase config, swm.ItemData item)
        {
            ItemBase tBase = null;
            if (null == tBase)
                tBase = new ItemBase();
            tBase.Init(config, item);
            return tBase;
        }
    }
}
