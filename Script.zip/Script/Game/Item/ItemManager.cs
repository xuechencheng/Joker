﻿using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 物品管理器，管理单个背包中的物品数据
    /// </summary>
    public class ItemManager : ISingleton<ItemManager>
    {
        /// <summary>
        /// 保存物品数据
        /// </summary>
        private List<ItemBase> m_itemList = new List<ItemBase>(Const.kCap32);



        /// <summary>
        /// 物品新增事件
        /// </summary>
        public GameEvent<ItemBase> onAddItem = new GameEvent<ItemBase>();

        /// <summary>
        /// 物品增量事件
        /// </summary>
        public GameEvent<ItemBase,uint> onAddItemNum = new GameEvent<ItemBase,uint>();
        

        /// <summary>
        /// 物品刷新事件（数量变化等）
        /// </summary>
        public GameEvent<ItemBase> onRefreshItem = new GameEvent<ItemBase>();



        /// <summary>
        /// 物品移除事件
        /// </summary>
        public GameEvent<ulong> onRemoveItem = new GameEvent<ulong>();



        /// <summary>
        /// 添加一个物品，如果checkExist为true，则先检查相同类型的物品是否已经存在
        /// </summary>
        public ItemBase AddItem(swm.ItemData item, bool checkExist = true, swm.ItemSrcType srcType = swm.ItemSrcType.UNKNOWN)
        {
            ItemTableBase? tConfig = ItemTableManager.GetData((int)item.baseid);
            ItemBase tItem = null;
            bool iShowAnim = srcType == swm.ItemSrcType.DROP ||
                             srcType == swm.ItemSrcType.GM;//物品飞入背包动画事件
            if (tConfig.HasValue)
            {

                //判断是否需要检查相同类型的物品已经存在
                if (checkExist && m_itemList.Count > 0)
                {
                    for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
                    {
                        tItem = m_itemList[tIdx];
                        if (item.id == tItem.ID)
                        {
                            if (item.num > tItem.ItemNum && iShowAnim)
                            {
                                onAddItemNum.Invoke(tItem, item.num - tItem.ItemNum);
                            }
                            //已经存在，那就刷新
                            tItem.RefreshItem(item);
                            onRefreshItem.Invoke(tItem);
                            return tItem;
                        }
                    }
                }

                tItem = ItemFactory.Instance.CreateItem(tConfig.Value, item);
                m_itemList.Add(tItem);
                onAddItem.Invoke(tItem);

                if (iShowAnim)
                {
                    onAddItemNum.Invoke(tItem, tItem.ItemNum);
                }
            }
            return tItem;
        }



        /// <summary>
        /// 获取物品列表
        /// </summary>
        public List<ItemBase> GetItemList()
        {
            return m_itemList;
        }



        /// <summary>
        /// 获取物品数量
        /// </summary>
        public int GetItemCount()
        {
            return m_itemList.Count;
        }



        /// <summary>
        /// 移除指定物品
        /// </summary>
        public void RemoveItem(ulong thisID)
        {
            if (m_itemList.Count > 0)
            {
                for (int tIdx = m_itemList.Count - 1; tIdx >= 0; --tIdx)
                {
                    ItemBase tItem = m_itemList[tIdx];
                    if (tItem != null && thisID == tItem.ID)
                    {
                        tItem.Destory();
                        m_itemList.RemoveAt(tIdx);
                        onRemoveItem.Invoke(thisID);
                    }
                }
            }
        }



        /// <summary>
        /// 移除所有道具
        /// </summary>
        public void DeleteAllItem()
        {
            for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
                m_itemList[tIdx].Destory();
            m_itemList.Clear();
        }



        /// <summary>
        /// 获得指定道具
        /// </summary>
        public ItemBase GetItemByThisID(ulong thisID)
        {
            if (m_itemList.Count > 0)
            {
                for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
                {
                    ItemBase tItem = m_itemList[tIdx];
                    if (tItem != null && thisID == tItem.ID)
                        return tItem;
                }
            }
            return null;
        }



        /// <summary>
        /// 获取指定类型的物品数量
        /// </summary>
        public uint GetItemNumberByBaseID(int baseID)
        {
            uint tNum = 0;
            for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
            {
                ItemBase tItem = m_itemList[tIdx];
                if (tItem != null && tItem.BaseID == baseID)
                    tNum += tItem.ItemNum;
            }
            return tNum;
        }



        /// <summary>
        /// 获取指定类型的物品
        /// </summary>
        public ItemBase GetItemByBaseID(int baseID)
        {
            for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
            {
                ItemBase tItem = m_itemList[tIdx];
                if (tItem != null && tItem.BaseID == baseID)
                    return tItem;
            }
            return null;
        }



        /// <summary>
        /// 获取指定索引顺序的物品
        /// </summary>
        public ItemBase GetItemByIndex(int index)
        {
            if (index < 0 || index >= m_itemList.Count)
                return null;
            return m_itemList[index];         
        }

        /// <summary>
        /// 获取指定类型和子类型的物品列表
        /// </summary>
        /// <param name="type"></param>
        /// <param name="subType"></param>
        /// <returns></returns>
        public List<ItemBase> GetItemListByTypeAndSubType(swm.ItemType type, int subType , bool iIgnoreCantUse = false)
        {
            List<ItemBase> res = new List<ItemBase>();
            for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
            {
                ItemBase tItem = m_itemList[tIdx];
                if (tItem != null && tItem.Type == type && tItem.SubType == subType)
                {
                    if (iIgnoreCantUse && tItem.ItemConfig.Value.needlevel > GameScene.Instance.MainChar.Level)
                        continue;
                    res.Add(tItem);
                }
            }
            return res;
        }
        
        public List<ItemBase> GetItemListByCDGroupId(int CDGroupId)
        {
            List<ItemBase> res = new List<ItemBase>();
            for (int tIdx = 0, tCount = m_itemList.Count; tIdx < tCount; tIdx++)
            {
                ItemBase tItem = m_itemList[tIdx];
                if (tItem != null && tItem.ItemConfig.Value.cd_group == CDGroupId)
                {
                    res.Add(tItem);
                }
            }
            return res;
        }
    }
}