﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bokura
{
    ///辅助类
    public class MaterialHelpItemBase
    {
        public uint m_BagNum = 0;//在背包的数量
        public MaterialHelpManualTableBase? m_ManualTableBaseConfig;
        public ItemTableBase? m_ItemConfig;
    }

    public class LifeSkill_UnlockCraftSlotInfo
    {
        /// <summary>
        /// 已完成次数
        /// </summary>
        public uint finish_count;

        /// <summary>
        /// 目标次数
        /// </summary>
        public uint target_count;

        /// <summary>
        /// 刷新
        /// </summary>
        public void Refresh(swm.UnlockCraftSlotInfo? _slotinfo)
        {
            if (!_slotinfo.HasValue)
                return;

            finish_count = _slotinfo.Value.finish_count;
            target_count = _slotinfo.Value.target_count;
        }
    }

    public class LifeSkillCraftData
    {
        /// <summary>
        /// 指定的制造手法
        /// </summary>
        public uint craft_id;

        /// <summary>
        /// 当前已解锁格子数量
        /// </summary>
        public uint slot_count;

        /// <summary>
        /// 当前解锁中格子信息
        /// </summary>
        public List<LifeSkill_UnlockCraftSlotInfo> slot_unlockinfo = new List<LifeSkill_UnlockCraftSlotInfo>(Const.kCap16);

        public void Refresh(swm.CraftInfo? _craftinfo)
        {
            if (!_craftinfo.HasValue)
                return;

            craft_id = _craftinfo.Value.craft_id;
            slot_count = _craftinfo.Value.slot_count;

            slot_unlockinfo.Clear();

            int num = _craftinfo.Value.slot_unlockinfoLength;
            for (int i = 0; i < num; i++)
            {
                swm.UnlockCraftSlotInfo? slotinfo = _craftinfo.Value.slot_unlockinfo(i);
                if (!slotinfo.HasValue)
                    continue;

                var slotdata = new LifeSkill_UnlockCraftSlotInfo();
                slotdata.Refresh(slotinfo);
                slot_unlockinfo.Add(slotdata);
            }
        }

        /// <summary>
        /// 是否孔解锁
        /// </summary>
        /// <param name="slotid">开孔id</param>
        /// <returns></returns>
        public bool IsSlotUnlock(uint slotid)
        {
            return slotid <= slot_count;
        }
    }

    public class LifeSkillAllCraftData
    {

        private Dictionary<uint, LifeSkillCraftData> m_craftDict = new Dictionary<uint, LifeSkillCraftData>(Const.kCap16);
        /// <summary>
        /// 
        /// </summary>
        public Dictionary<uint, LifeSkillCraftData> craftDict
        {
            get { return m_craftDict; }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_craftDict.Clear();
        }

        public LifeSkillCraftData GetCraftData(uint craft_id)
        {
            LifeSkillCraftData craftdata = null;
            m_craftDict.TryGetValue(craft_id, out craftdata);

            return craftdata;
        }

        /// <summary>
        /// 填充数据
        /// </summary>
        /// <param name="_craftinfo"></param>
        public void FillData(swm.CraftInfo? _craftinfo)
        {
            if (!_craftinfo.HasValue)
                return;

            uint craftid = _craftinfo.Value.craft_id;

            if (m_craftDict.ContainsKey(craftid))
            {
                var craftdata = m_craftDict[craftid];
                if (craftdata != null)
                {
                    craftdata.Refresh(_craftinfo);
                }
            }
            else
            {
                var craftdata = new LifeSkillCraftData();
                craftdata.Refresh(_craftinfo);
                m_craftDict.Add(craftid, craftdata);
            }
        }

        public uint GetSlotUnlockNum(uint craft_id)
        {
            LifeSkillCraftData craftdata = null;
            m_craftDict.TryGetValue(craft_id, out craftdata);

            if (craftdata == null)
                return 0;

            return craftdata.slot_count;
        }

        /// <summary>
        /// 是否孔解锁
        /// </summary>
        /// <param name="craft_id"></param>
        /// <param name="slotid"></param>
        /// <returns></returns>
        public bool IsSlotUnlock(uint craft_id, uint slotid)
        {
            LifeSkillCraftData craftdata = null;
            m_craftDict.TryGetValue(craft_id, out craftdata);

            if (craftdata == null)
                return false;

            return craftdata.IsSlotUnlock(slotid);
        }
    }
}
