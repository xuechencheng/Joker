﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bokura
{
    public class LifeSkillGatheringData
    {
        private swm.GatheringProfessionType m_gatherType = swm.GatheringProfessionType.None;

        private List<uint> m_LearnSkills = new List<uint>();
        public swm.GatheringProfessionType GatherType
        {
            get
            {
                return m_gatherType;
            }
            set
            {
                m_gatherType = value;
            }
        }

        public List<uint> LearnSkills
        {
            get
            {
                return m_LearnSkills;
            }
        }

        /// <summary>
        /// 清除数据
        /// </summary>
        public void Clear()
        {
            m_LearnSkills.Clear();
            m_gatherType = swm.GatheringProfessionType.None;
        }
        /// <summary>
        /// 重新初始化数据
        /// </summary>
        /// <param name="_data"></param>
        /// <returns></returns>
        public bool Init(swm.GatheringProfessionData _data)
        {
            Clear();
            m_gatherType = _data.type;
            uint _id = 0;
            for (int i=0;i<_data.learned_skillsLength;i++)
            {
                _id = _data.learned_skills(i);
                AddLearnSkillId(_id);
            }
            return true;
        }

        /// <summary>
        /// 增加一个已经学习的技能id
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_bIsCheckIsHas">是否检查重复</param>
        /// <returns></returns>
        public bool AddLearnSkillId(uint _id,bool _bIsCheckIsHas = false)
        {
            if(_bIsCheckIsHas)
            {
                if(CheckIshasLearnId(_id))
                {
                    return false;
                }
            }
            m_LearnSkills.Add(_id);
            return true;
        }

        /// <summary>
        /// 检查是否已经在学习列表了
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public bool CheckIshasLearnId( uint _id)
        {
            uint _tmpId = 0;
            for (int i = 0; i < m_LearnSkills.Count; i++)
            {
                _tmpId = m_LearnSkills[i];
                if (_id == _tmpId)
                {
                    return true;
                }
            }
            return false;
        }

    }

    public class LifeSkillAllGatheringDatas
    {
        private List<LifeSkillGatheringData> m_gatherDataList = new List<LifeSkillGatheringData>();

        /// <summary>
        /// 清空现有数据
        /// </summary>
        public void Clear()
        {

            LifeSkillGatheringData _data;
            for (int i =0;i< m_gatherDataList.Count;i++)
            {
                _data = m_gatherDataList[i];
                _data.Clear();
            }
        }

        /// <summary>
        /// 初始化数据
        /// </summary>
        /// <param name="_msg"></param>
        public void InitAllGatherData(swm.AllGatheringProfessions _msg)
        {
            Clear();
            swm.GatheringProfessionData _data;
            for (int i=0;i< _msg.datasLength;i++)
            {
                var _d = _msg.datas(i);
                if(null != _d)
                {
                    _data = _d.Value;
                    AddGatherDataToList(_data);
                }
            }
        }

        /// <summary>
        /// 通过类型获得数据列表
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_bNullIsCreate"> 如果没有是否创建 默认创建</param>
        /// <returns></returns>
        public LifeSkillGatheringData GetLifeSkillGatheringDataByType(swm.GatheringProfessionType _type,bool _bNullIsCreate = true)
        {
            LifeSkillGatheringData _data = null;
            for (int i =0;i< m_gatherDataList.Count;i++)
            {
                _data = m_gatherDataList[i];
                if(_data.GatherType == _type)
                {
                    return _data;
                }
            }
            if(_bNullIsCreate)
            {
                _data = new LifeSkillGatheringData();
                m_gatherDataList.Add(_data);
                return _data;
            }
            return null;
        }

        /// <summary>
        /// 检查是否已经学习采集技能
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_id"></param>
        /// <returns></returns>
        public bool CheckGatherSkillIsLearn(swm.GatheringProfessionType _type, uint _id)
        {
            LifeSkillGatheringData _gatherData = GetLifeSkillGatheringDataByType(_type );
            return _gatherData.CheckIshasLearnId(_id);
        }

        /// <summary>
        /// 增加 一个采集技能数据
        /// </summary>
        /// <param name="_data"></param>
        /// <returns></returns>
        private LifeSkillGatheringData AddGatherDataToList(swm.GatheringProfessionData _data)
        {
           LifeSkillGatheringData _gatherData = GetLifeSkillGatheringDataByType(_data.type);
            if( null != _gatherData)
            {
                _gatherData.Init(_data);
            }
           return _gatherData;
        }

    }
}
