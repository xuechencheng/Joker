using System.Collections.Generic;
using Bokura;
using System;

namespace Bokura
{
    class LifeSkillModel : ClientSingleton<LifeSkillModel>
    {
        #region 变量

        public class ProfessionData {
            public uint id;
            public uint level;
            public uint exp;

            public ProfessionData(uint id, uint level, uint exp) {
                this.id = id;
                this.level = level;
                this.exp = exp;
            }
        }

        private LifeSkillAllGatheringDatas m_LifeSkillGatherDatas = new LifeSkillAllGatheringDatas();//采集技能数据

        //手册辅助列表 存放类型的列表
        private Dictionary<int, List<MaterialHelpItemBase>> m_MaterialHelpItemList = new Dictionary<int, List<MaterialHelpItemBase>>(Const.kCap32);

        public LifeSkillAllGatheringDatas LifeSkillGatherDatas
        {
            get
            {
                return m_LifeSkillGatherDatas;
            }
        }



        private LifeSkillAllCraftData m_lifeSkillAllCraftData = new LifeSkillAllCraftData();
        /// <summary>
        /// 制造数据
        /// </summary>
        public LifeSkillAllCraftData lifeSkillAllCraftData
        {
            get { return m_lifeSkillAllCraftData; }
        }



        public class RefreshGatheringData : GameEvent<swm.GatheringProfessionType, uint>
        {

        }

        public GameEvent onInitGetGatherListEvent = new GameEvent();
        public RefreshGatheringData onStudyGatherSuccessEvent = new RefreshGatheringData();
        public GameEvent onStudyGatherFailEvent = new GameEvent();
        public GameEvent onReceiveData = new GameEvent();
        public GameEvent<List<uint>> onGetReward = new GameEvent<List<uint>>();


        private GameEvent m_onMakeThingInCraftEvent = new GameEvent();
        /// <summary>
        /// 返回制造结果
        /// </summary>
        public GameEvent onMakeThingInCraftEvent
        {
            get { return m_onMakeThingInCraftEvent; }
        }



        private GameEvent<uint> m_onNtfCraftInfoEvent = new GameEvent<uint>();
        /// <summary>
        /// 通知制造信息
        /// </summary>
        public GameEvent<uint> onNtfCraftInfoEvent
        {
            get { return m_onNtfCraftInfoEvent; }
        }

        #endregion

        #region 内置函数

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AllGatheringProfessions>(ProcAllGatheringProfessions);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspStudyGatheringProfessionSkill>(ProcRspStudyGatheringProfessionSkill);

            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCraftInfo>(ProcRspCraftInfo_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyCraftInfo>(ProcNotifyCraftInfo_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspMakeThingInCraft>(ProcRspMakeThingInCraft_SC);


            //新的生活技能消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspAllProfession>(ProcRspAllProfesssion);//生活技能列表
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyAddFormula>(ProcNotifyAddFormula);//通知获得了新的配方
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshProfessionExp>(ProcRefreshProfessionExp);//刷新生活技能经验
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspUseFormula>(ProcRspUseFormula);//
        }

        /// <summary>
        /// 清除所有数据
        /// </summary>
        public void Clear()
        {
            m_LifeSkillGatherDatas.Clear();
            m_lifeSkillAllCraftData.Clear();
            haveData = false;
        }

        public void Load()
        {
            CraftInfoTableManager.Load();
            CraftUnlockSlotTableManager.Load();
            CraftStuffTableManager.Load();
            CraftLingTableManager.Load();
            CraftDropTableManager.Load();
        }

        #endregion

        #region 消息函数

        /// <summary>
        /// 获取指定制造手法信息
        /// </summary>
        /// <param name="craft_id">指定的制造手法</param>
        public void ReqCraftInfo_CS(uint craft_id)
        {
            var fb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var msg = swm.ReqCraftInfo.CreateReqCraftInfo(fb, craft_id);
            fb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCraftInfo.HashID, fb);
        }

        /// <summary>
        /// 制造
        /// </summary>
        /// <param name="craft_id">制造id</param>
        /// <param name="core_item_id">核心材料baseid</param>
        /// <param name="stuff_item_list">辅助材料列表</param>
        public void ReqMakeThingInCraft_CS(uint craft_id, uint core_item_id, List<uint> stuff_item_list)
        {
            if (stuff_item_list == null)
                return;

            var fb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.ReqMakeThingInCraft.CreateStuffItemListVector(fb, stuff_item_list.ToArray());
            var msg = swm.ReqMakeThingInCraft.CreateReqMakeThingInCraft(fb, craft_id, core_item_id, vec);
            fb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqMakeThingInCraft.HashID, fb);
        }

        /// <summary>
        /// 返回指定制造手法信息
        /// </summary>
        /// <param name="msg"></param>
        private void ProcRspCraftInfo_SC(swm.RspCraftInfo msg)
        {
            ProcCraftInfo(msg.craft_info);
        }

        /// <summary>
        /// 通知制造手法信息
        /// </summary>
        /// <param name="msg"></param>
        private void ProcNotifyCraftInfo_SC(swm.NotifyCraftInfo msg)
        {
            ProcCraftInfo(msg.craft_info);
        }

        /// <summary>
        /// 返回制造结果
        /// </summary>
        /// <param name="msg"></param>
        private void ProcRspMakeThingInCraft_SC(swm.RspMakeThingInCraft msg)
        {
            //m_makeThingInCraft.Refresh(msg);

            BagManager.Instance.ProcRspOpenGiftBag(msg);

            m_onMakeThingInCraftEvent.Invoke();
        }

        #endregion

        #region 函数

        public void TestCraft(uint craft_id)
        {
            var craftdata = m_lifeSkillAllCraftData.GetCraftData(craft_id);
            if (craftdata == null)
                return;

            craftdata.slot_count++;

            m_onNtfCraftInfoEvent.Invoke(craft_id);
        }

        //客户端
        /// <summary>
        /// 获得当前类型的 已经学习的id
        /// </summary>
        /// <param name="_type"></param>
        /// <returns></returns>
        public uint GetCurrentGatheringDataIdByType(swm.GatheringProfessionType _type)
        {
            uint _id = 0;
            LifeSkillGatheringData _gatherData = m_LifeSkillGatherDatas.GetLifeSkillGatheringDataByType(_type);
            if (null != _gatherData)
            {
                int len = _gatherData.LearnSkills.Count;
                if (len > 0)
                {
                    _id = _gatherData.LearnSkills[len - 1];
                }
            }
            return _id;
        }

        /// <summary>
        /// 检查id 是否是当前节点的字节点
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_checkId"></param>
        /// <returns></returns>
        public bool CheckIsInCurrentGatheringChildList(swm.GatheringProfessionType _type, uint _checkId)
        {
            uint _currentId = GetCurrentGatheringDataIdByType(_type);
            if (_currentId != 0)
            {
                var _data = CollectTableManager.GetData((int)_type, (int)_currentId);
                if (null != _data && _data.Value.next_id_listLength > 0)
                {
                    int _id = 0;
                    for (int i = 0; i < _data.Value.next_id_listLength; i++)
                    {
                        _id = _data.Value.next_id_list(i);
                        if (_id == _checkId)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 通过类型获得图鉴配置和道具数据的辅助
        /// </summary>
        /// <param name="_type"></param>
        /// <returns></returns>
        public List<MaterialHelpItemBase> GetMaterialHelpListByType(int _type)
        {
            List<MaterialHelpItemBase> _lst = null;
            if (!m_MaterialHelpItemList.TryGetValue(_type, out _lst))
            {
                _lst = new List<MaterialHelpItemBase>();

                for (int i = 0; i < MaterialHelpManualTableManager.Instance.m_DataList.MaterialHelpManualTableLength; ++i)
                {
                    var data = MaterialHelpManualTableManager.Instance.m_DataList.MaterialHelpManualTable(i);
                    if (_type == data.Value.type)
                    {
                        MaterialHelpItemBase _data = new MaterialHelpItemBase();
                        _data.m_ManualTableBaseConfig = data;
                        _data.m_ItemConfig = ItemTableManager.GetData(data.Value.id);
                        _data.m_BagNum = BagManager.Instance.GetItemNumberByBaseID(swm.BagType.ItemBag, data.Value.id);
                        _lst.Add(_data);
                    }
                }
                m_MaterialHelpItemList[_type] = _lst;
            }
            else
            {
                for (int i = 0; i < _lst.Count; i++)
                {
                    _lst[i].m_BagNum = BagManager.Instance.GetItemNumberByBaseID(swm.BagType.ItemBag, _lst[i].m_ManualTableBaseConfig.Value.id);
                }
            }

            return _lst;
        }

        /// <summary>
        /// 获得 采集表数据 （辅助函数）
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_id"></param>
        /// <returns></returns>
        public CollectTableBase? GetCollectTableData(swm.GatheringProfessionType _type, int _id)
        {
            return CollectTableManager.GetData((int)_type, _id);
        }

        /// <summary>
        /// 检查是否已经学习
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_id"></param>
        /// <returns></returns>
        public bool CheckGatherSkillIsLearn(swm.GatheringProfessionType _type, uint _id)
        {
            return m_LifeSkillGatherDatas.CheckGatherSkillIsLearn(_type, _id);
        }

        //接收网络消息
        /// <summary>
        /// 接收 所有采集技能数据
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcAllGatheringProfessions(swm.AllGatheringProfessions _msg)
        {
            m_LifeSkillGatherDatas.InitAllGatherData(_msg);
            onInitGetGatherListEvent.Invoke();
        }

        /// <summary>
        /// 接收 学习技能结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspStudyGatheringProfessionSkill(swm.RspStudyGatheringProfessionSkill _msg)
        {
            if (_msg.result)
            {
                LifeSkillGatheringData _data = m_LifeSkillGatherDatas.GetLifeSkillGatheringDataByType(_msg.type);
                if (null != _data)
                {
                    if (_data.AddLearnSkillId(_msg.skillid))
                    {
                        onStudyGatherSuccessEvent.Invoke(_msg.type, _msg.skillid);
                    }
                }
            }
            else
            {
                onStudyGatherFailEvent.Invoke();
            }
        }

        /// <summary>
        /// 发送 学习采集技能
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_skillid"></param>
        public void SendReqStudyGatheringProfessionSkill(swm.GatheringProfessionType _type, uint _skillid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqStudyGatheringProfessionSkill.StartReqStudyGatheringProfessionSkill(fbb);
            swm.ReqStudyGatheringProfessionSkill.AddType(fbb, _type);
            swm.ReqStudyGatheringProfessionSkill.AddSkillid(fbb, _skillid);
            var msg = swm.ReqStudyGatheringProfessionSkill.EndReqStudyGatheringProfessionSkill(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqStudyGatheringProfessionSkill.HashID, fbb);
        }

        /// <summary>
        /// 通知制造手法信息
        /// </summary>
        /// <param name="_craftinfo"></param>
        private void ProcCraftInfo(swm.CraftInfo? _craftinfo)
        {
            if (!_craftinfo.HasValue)
                return;

            uint craft_id = _craftinfo.Value.craft_id;

            m_lifeSkillAllCraftData.FillData(_craftinfo);
            m_onNtfCraftInfoEvent.Invoke(craft_id);
        }

        #endregion

        #region 新生活技能

        //请求所有生活技能 //界面打开的时候请求
        bool haveData = false;
        public bool HaveData {
            get {
                return haveData;
            }
        }
        public void ReqAllProfession() {
            if (haveData) {
                if (onReceiveData != null)
                    onReceiveData.Invoke();
                return;
            }
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            swm.ReqAllProfession.StartReqAllProfession(fbb);
            fbb.Finish(swm.ReqAllProfession.EndReqAllProfession(fbb).Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqAllProfession.HashID, fbb);
        }

        private List<ProfessionData> m_Professions = new List<ProfessionData>();//生活技能列表
        private Dictionary<int, List<uint>> m_formulas = new Dictionary<int, List<uint>>();//配方列表

        public List<ProfessionData> Professions {
            get {
                return m_Professions;
            }
        }

        public ProfessionData GetProfessionData(int id) {
            for (int i = 0; i < m_Professions.Count; i++) {
                if (m_Professions[i].id == id)
                    return m_Professions[i];
            }
            return null;
        }

        public List<uint> GetFormulasByType(int type)
        {
            if (m_formulas.ContainsKey(type)) {
                return m_formulas[type];
            }
            return null;
        }

        //收到通知后刷新界面
        private void ProcRspAllProfesssion(swm.RspAllProfession msg)
        {
            haveData = true;
            m_Professions.Clear();
            m_formulas.Clear();
            for (int i = 0; i < msg.professionLength; i++) {
                var profess = msg.profession(i).Value;
                m_Professions.Add(new ProfessionData(profess.id, profess.level, profess.exp));
            }
            m_Professions.Sort(sortfun);

            for (int i = 0; i < msg.formulaLength; i++) {
                uint fid = msg.formula(i);
                InsertFormula(fid);
            }

            SortFormula();

            if (onReceiveData != null)
                onReceiveData.Invoke();
        }

        private void InsertFormula(uint fid) {

            var table = ProfessionFormulaTableManager.GetData((int)fid);
            if (table.HasValue)
            {
                int pid = table.Value.profession;
                if (!m_formulas.ContainsKey(pid))
                {
                    m_formulas.Add(pid, new List<uint>());
                }
                m_formulas[pid].Add(fid);
            }
        }

        private void SortFormula() {
            var iter = m_formulas.GetEnumerator();
            while (iter.MoveNext())
            {
                iter.Current.Value.Sort();
            }
        }

        private int sortfun(ProfessionData p1, ProfessionData p2) {
            if (p1.id > p2.id) return 1;
            else if (p1.id < p2.id) return -1;
            else return 0;
        }

        //通知刷新的配方
        private void ProcNotifyAddFormula(swm.NotifyAddFormula msg)
        {
            InsertFormula(msg.formulaid);
            SortFormula();
            //通知界面更改
            //....
        }

        private void ProcRefreshProfessionExp(swm.RefreshProfessionExp msg)
        {
            var profession = GetProfessionData((int)msg.id);
            profession.level = msg.level;
            var expdiff = msg.exp - profession.exp;
            profession.exp = msg.exp;

            List<swm.TsParamsT> _list = new List<swm.TsParamsT>();
            swm.TsParamsT _xmTs = new swm.TsParamsT();
            _xmTs.key = "{num}";
            _xmTs.value = expdiff.ToString();
            _list.Add(_xmTs);
            swm.TsParamsT _namets = new swm.TsParamsT();
            _namets.key = "{name}";
            var pr = ProfessionSkillTableManager.GetData((int)profession.id);
            _namets.value = pr.Value.name;
            _list.Add(_namets);

            NotifyModel.Instance.GetInfoAndDispathTypeEvent(TsInfoID.TS_ADD_PROFESSIONEXP, _list);
            //通知界面更改
            //....
        }

        public void ReqUseFormula(uint formulaid, uint count, uint npcid) {
           // m_rewards.Clear();
           // for (int i = 0; i <count; i++)
           // {
           //     m_rewards.Add(1);
           //  
           // }
           // if (onGetReward != null) onGetReward.Invoke(m_rewards);
            //return;
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            var msg = swm.ReqUseFormula.CreateReqUseFormula(fbb, formulaid, count, npcid);
            fbb.Finish(msg.Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqUseFormula.HashID, fbb);
        }

        List<uint> m_rewards = new List<uint>();
        private void ProcRspUseFormula(swm.RspUseFormula msg) {
            //LogHelper.LogError("获取道具开始");
            //LogHelper.LogError(msg.formulaid);
            var formual = ProfessionFormulaTableManager.GetData((int)msg.formulaid);
            if (formual.Value.profession != 1)
                return;

            m_rewards.Clear();
            for (int i = 0; i < msg.itemLength; i++)
            {
                m_rewards.Add((uint)msg.item(i));
                // LogHelper.LogError(msg.item(i));
            }
            if (onGetReward != null) onGetReward.Invoke(m_rewards);
            //LogHelper.LogError("获取道具结束");
        }

        public void SendGatherNpc(ulong npcid) {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            var msg = swm.ReqGatherNpc.CreateReqGatherNpc(fbb, npcid);
            fbb.Finish(msg.Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqGatherNpc.HashID, fbb);
        }


        #endregion
    }
}
