using UnityEngine;
using Bokura;
using UnityEngine.UI;
using UnityEngine.Video;

namespace Bokura
{
    public class LuaFastCall
    {

        public static void GetEntityGlobalPos(Entity ety, out float x, out float y,out float z)
        {
            var pos = ety.GlobalPosition;
            x = pos.x;
            y = pos.y;
            z = pos.z;
        }
        public static void SetGameObjectPos(UnityEngine.GameObject go, float x, float y, float z)
        {
            go.transform.position = new Vector3(x, y, z);
        }

        public static void SetGameObjectPosWithWorldOffset(UnityEngine.GameObject go, float x, float y, float z)
        {
            Vector3 p = new Vector3(x, y, z);

            p -= LayeredSceneLoader.WorldOffset;
            if(go)
            {
                go.transform.localPosition = p;
            }
        }

        public static void SetGameObjectLocalPos(UnityEngine.Object o, float x, float y, float z)
        {
            Transform trans = o as Transform;
            if (trans != null)
            {
                trans.localPosition = new Vector3(x, y, z);
                return;
            }
            GameObject go = o as GameObject;
            if (go)
            {
                go.transform.localPosition = new Vector3(x, y, z);
            }
        }

        public static Vector2 GetGameObjectAnchoredPos(UnityEngine.GameObject go)
        {
            var rct = go.transform as RectTransform;
            if (rct != null)
                return rct.anchoredPosition;

            return Vector2.zero;
        }

        public static void SetGameObjectAnchoredPos(UnityEngine.GameObject go, float x, float y)
        {
            var rct = go.transform as RectTransform;
            if (rct != null)
                rct.anchoredPosition = new Vector2(x, y);
        }
        public static void SetGameObjectAnchoredPos(UnityEngine.RectTransform go, float x, float y)
        {
            go.anchoredPosition = new Vector2(x, y);
        }

        public static void SetGameObjectRectSize(UnityEngine.GameObject go, float w, float h)
        {
            var rct = go.transform as RectTransform;
            if (rct != null)
                rct.sizeDelta = new Vector2(w, h);
        }
        public static void SetGameObjectRectSize(UnityEngine.GameObject go, float w)
        {
            var rct = go.transform as RectTransform;
            if (rct != null)
                rct.sizeDelta = new Vector2(w, rct.sizeDelta.y);
        }
        public static void SetGameObjectRectSize(UnityEngine.RectTransform go, float w, float h)
        {
            go.sizeDelta = new Vector2(w, h);
        }
        public static void SetPivotPos(UnityEngine.RectTransform go, float x, float y)
        {
            go.pivot = new Vector2(x, y);
        }

        static public float Vector2Angle(float x, float y)
        {
            return Utilities.Vector2Angle(y, x);
        }

        public static void SetGameObjectRot(UnityEngine.GameObject go, float x, float y, float z, float w)
        {
            go.transform.rotation = new Quaternion(x, y, z, w);
        }
        public static void SetGameObjectLocalRot(UnityEngine.GameObject go, float x, float y, float z, float w)
        {
            SetGameObjectLocalRotByQuaternion( go,new Quaternion(x, y, z, w));
        }
        public static void SetGameObjectLocalRotByQuaternion(UnityEngine.GameObject go, Quaternion _qua)
        {
            go.transform.localRotation = _qua;
        }
        public static void SetGameObjectScale(GameObject go, float x, float y, float z)
        {
            go.transform.localScale = new Vector3(x, y, z);
        }
        public static void SetGameObjectParent(GameObject go, Transform parent, bool b)
        {
            go.transform.SetParent(parent, b);
        }

        public static void SetGameObjectLayer(GameObject go, int nLayer, bool recur)
        {
            if(go)
            {
                if (recur)
                    go.SetLayerRecursively(nLayer);
                else
                    go.layer = nLayer;
            }
        }
        public static void SetActive(UnityEngine.Object obj, bool b)
        {
            GameObject tGo = obj as GameObject;
            if (tGo != null)
            {
                if (tGo.activeSelf != b)
                    tGo.SetActive(b);
                return;
            }
            Component tComp = obj as Component;
            if (tComp != null)
            {
                if (tComp.gameObject.activeSelf != b)
                    tComp.gameObject.SetActive(b);
            }
        }

        public static bool IsGoNull(GameObject go)
        {
            return (go == null);
        }

        public static bool IsActive(UnityEngine.Object obj)
        {
            var go = obj as GameObject;
            if (go)
                return go.activeSelf;

            var co = obj as Component;
            if (co != null)
            {
                return co.gameObject.activeSelf;

            }
            return false;
        }

        public static void SetGameObjectActiveByMeshRender(string _objectPath, bool b)
        {
            var go = GameObject.Find(_objectPath);
            if (go)
            {
                MeshRenderer render = go.GetComponent<MeshRenderer>();
                if (render)
                {
                    render.enabled = b;
                }
            }
        }

        public static float GetAnimationLength(UnityEngine.Object obj, string stateName)
        {
            if (null != obj)
            {
                Animation animation = null;
                if (obj is GameObject)
                {
                    animation = (obj as GameObject).GetComponent<Animation>();
                }
                else if (obj is Transform)
                {
                    animation = (obj as Transform).GetComponent<Animation>();
                }
                else if (obj is Component)
                {
                    animation = (obj as Component).GetComponent<Animation>();
                }
                if (null != animation)
                {
                    var clip = animation.GetClip(stateName);
                    if (clip == null)
                    {
                        clip = AnimationClipManager.Instance.GetAnimationClip(stateName);
                    }
                    if(clip != null)
                    {
                        return clip.length;
                    }
                }
                else
                {
                    LogHelper.LogWarning("Get anim length error! ", stateName);
                }
            }
            return 0;
        }

        public static void PlayAnimationByUnityAnimation(UnityEngine.Object obj, string stateName, bool custom = false)
        {
            if (null != obj)
            {
                Animation animation = null;
                if (obj is GameObject)
                {
                    animation = (obj as GameObject).GetComponent<Animation>();
                }
                else if (obj is Transform)
                {
                    animation = (obj as Transform).GetComponent<Animation>();
                }
                else if (obj is Component)
                {
                    animation = (obj as Component).GetComponent<Animation>();
                }
                if (null != animation)
                {
                    if (animation.gameObject.activeSelf)
                    {
                        if (string.IsNullOrEmpty(stateName))
                        {
                            animation.Stop();
                            animation.Play(PlayMode.StopAll);
                            return;
                        }
                        if (custom)
                        {
                            var clip = animation.GetClip(stateName);
                            if (clip == null)
                            {
                                clip = AnimationClipManager.Instance.GetAnimationClip(stateName);
                            }
                        }
                        animation.Stop();
                        animation.Play(stateName, PlayMode.StopAll);
                    }
                }
                else
                {
                    LogHelper.LogWarning("play anim error! ", stateName);
                }
            }
        }
        public static void StopVideo(UnityEngine.Object obj, string videoName)
        {
            if (null != obj)
            {
                VideoPlayer videoPlayer = null;
                if (obj is GameObject)
                {
                    videoPlayer = (obj as GameObject).GetComponentInChildren<VideoPlayer>();
                }
                else if (obj is Transform)
                {
                    videoPlayer = (obj as Transform).GetComponentInChildren<VideoPlayer>();
                }
                if (null != videoPlayer)
                {
                    videoPlayer.Stop();
                }
                else
                {
                    LogHelper.LogWarning("play video error! ", videoName);
                }
            }
        }
        public static void PlayVideo(UnityEngine.Object obj, string videoName,float speed = 1.0f,bool loop = true)
        {
            if (null != obj)
            {
                VideoPlayer videoPlayer = null;
                if (obj is GameObject)
                {
                    videoPlayer = (obj as GameObject).GetComponentInChildren<VideoPlayer>();
                }
                else if (obj is Transform)
                {
                    videoPlayer = (obj as Transform).GetComponentInChildren<VideoPlayer>();
                }
                if (null != videoPlayer)
                {
                    if (videoPlayer.gameObject.activeSelf)
                    {
                        IResourceLoader.Instance.LoadAssetAsync(IResourceLoader.strVideoPath, videoName,IResourceLoader.strVideoSuffix, (Object o) => {

                            videoPlayer.clip = o as VideoClip;
                            videoPlayer.playbackSpeed = speed;
                            videoPlayer.isLooping = loop;
                            videoPlayer.Play();
                        });
                    }
                }
                else
                {
                    LogHelper.LogWarning("play video error! ", videoName);
                }
            }

        }
        public static void PlayParticalSystem(UnityEngine.Object obj,bool withChildren = false)
        {
            if (null != obj)
            {
                UIRenderAdapter ParticleSystem = null;
                if (obj is GameObject)
                {
                    ParticleSystem = (obj as GameObject).GetComponentInChildren<UIRenderAdapter>();
                }
                else if (obj is Transform)
                {
                    ParticleSystem = (obj as Transform).GetComponentInChildren<UIRenderAdapter>();
                }
                if (null != ParticleSystem)
                {
                    if (ParticleSystem.gameObject.activeSelf)
                    {
                        ParticleSystem.Play(withChildren);
                    }
                }
                else
                {
                    LogHelper.LogWarning("play ParticalSystem error! ");
                }
            }
        }
        public static void PlayAnimation(UnityEngine.Object obj, string stateName, int layer, float normalizedTime = float.NegativeInfinity)
        {
            if (null != obj)
            {
                Animator animator = null;
                if (obj is GameObject)
                {
                    animator = (obj as GameObject).GetComponentInChildren<Animator>();
                }
                else if (obj is Transform)
                {
                    animator = (obj as Transform).GetComponentInChildren<Animator>();
                }
                if (null != animator)
                {
                    if (animator.gameObject.activeSelf)
                    {
                        animator.Play(stateName, layer, normalizedTime);
                    }
                }
                else
                {
                    LogHelper.LogWarning("play anim error! ", stateName);
                }
            }
        }

        public static bool HasParent(UnityEngine.Object obj)
        {
            var go = obj as GameObject;
            if (go != null)
            {

                return go.transform.parent != null;
            }
            var t = obj as Transform;
            if (t != null)
            {
                return t.parent != null;
            }
            return false;
        }

        public static void SetSiblingIndex(UnityEngine.Object obj, int idx)
        {
            var transform = obj as Transform;
            if (transform)
            {
                transform.SetSiblingIndex(idx);
                return;
            }
            var go = obj as GameObject;
            if (go)
            {
                go.transform.SetSiblingIndex(idx);
            }
        }

        public static bool GetTerrianHeight(float x, float y, out float z)
        {
            return GetTerrianHeightWithMask(x, y, (int)UserLayerMask.Terrain, out z);

        }

        public static bool GetTerrianHeightWithMask(float x, float y,int layMask, out float z, float startz=1000.0f)
        {
            RaycastHit hitinfo;
            Vector3 pos = new Vector3(x, startz, y);
            pos -= LayeredSceneLoader.WorldOffset;

            if (Utilities.RayCast(pos, Vector3.down, out hitinfo, 100000000, layMask))
            {
                z = hitinfo.point.y;
                return true;
            }
            else
            {
                z = 0;
                return false;
            }
        }

        public static Transform SearchChildTransform(Transform t, string name)
        {
            var c = t.Find(name);
            if (c)
            {
                return c;
            }
            for (int i = 0; i < t.childCount; i++)
            {
                var ct = t.GetChild(i);
                var fd = SearchChildTransform(ct, name);
                if (fd)
                    return fd;
            }
            return null;
        }

        public static Transform SearchChild(UnityEngine.Object o, string name)
        {
            Transform t = o as Transform;
            if (t == null)
            {
                var go = o as GameObject;
                if (go)
                {
                    t = go.transform;
                }
                else
                {
                    var co = o as Component;
                    if (co)
                        t = co.transform;
                }
            }
            if (t == null)
                return null;
            return SearchChildTransform(t, name);
        }

        public static bool IsChildTransform(Object p, Transform child)
        {
            Transform parent;
            GameObject go = p as GameObject;
            if (go != null)
            {
                parent = go.transform;
            }
            else
            {
                parent = p as Transform;
                if (parent == null)
                    return false;
            }

            var _p = child;
            while (_p != null)
            {
                if (_p == parent)
                    return true;
                _p = _p.parent;
            }

            return false;
        }

        // 	public static bool SetImageByPath(UnityEngine.UI.Image image, string path)
        // 	{
        // 		int nLastIdx = path.LastIndexOf(':');
        // 		if ( nLastIdx>0)
        // 		{
        // 			string mainpath = path.Substring(0,  nLastIdx);
        // 			string subname = path.Substring(nLastIdx + 1, path.Length - nLastIdx - 1);
        // 			return SetImageWithSubImage(image, mainpath, subname);
        // 		}
        // 		else
        // 		{
        // 			return SetImageWithSubImage(image, path, null);
        // 		}
        // 	}
        // 	public static bool SetImageWithSubImage(UnityEngine.UI.Image image, string path, string subimagename)
        // 	{
        // 		if (image == null || string.IsNullOrEmpty(path))
        // 		{
        // 			return false;
        // 		}
        // 
        // 		if (string.IsNullOrEmpty(subimagename))
        // 		{
        // 			UnityEngine.Sprite sprite = IUILoader.Instance.Load(path, typeof(UnityEngine.Sprite)) as UnityEngine.Sprite;
        //                 //IResourceLoader.Instance.Load(path, typeof(UnityEngine.Sprite)) as  UnityEngine.Sprite;
        //                 if (sprite != null)
        // 			{
        // 				image.sprite = sprite;
        // 				return true;
        // 			}		
        // 		}
        // 		else
        // 		{
        //             var sprites = IUILoader.Instance.LoadAll(path);//IResourceLoader.Instance.LoadAll(path);
        // 
        //             if (sprites!=null && sprites.Length>0)
        // 			{
        // 				for(int i = 0; i < sprites.Length; i ++ )
        // 				{
        // 					if (sprites[i].name == subimagename)
        // 					{
        // 						UnityEngine.Sprite sprite = sprites[i] as UnityEngine.Sprite;
        // 						if (sprite!=null)
        // 						{
        // 							image.sprite = sprite;
        // 							return true;
        // 						}
        // 					}
        // 				}
        // 			}
        // 
        // 		}
        // 		return false;
        // 	}

        public static void SetLayerRecur(GameObject obj, int nLayer)
        {
            obj.layer = nLayer;
            for (int i = 0; i < obj.transform.childCount; i++)
            {
                SetLayerRecur(obj.transform.GetChild(i).gameObject, nLayer);
            }
        }

        public static void SetGray(UnityEngine.Object obj, bool b, float grayamount = 1, bool withChild = true)
        {
            var gameobj = obj as UnityEngine.GameObject;
            if (null == gameobj)
            {
                Transform trans = obj as UnityEngine.Transform;
                if (null != trans)
                    gameobj = trans.gameObject;
                else
                {
                    Component tComp = obj as UnityEngine.Component;
                    if (null != tComp)
                        gameobj = tComp.gameObject;
                }
            }
            if (gameobj != null)
            {
                var gray = GrayCompent.Get(gameobj);//gameobj.GetComponent<Game.GrayCompent>();
                if (gray != null)
                {
                    gray.setGrayCompent(b, grayamount, withChild);
                }
            }
        }
        public static void SetImageByItemId(Image img, uint itemId)
        {
            if(null != img)
            {
                img.sprite = UIUtility.GetIconByItemId(itemId);
            }
        }

        public static void SetImageByPath(Image img, string spritePath)
        {
            if (img == null) return;
            Sprite tSprite = null;
            if (!string.IsNullOrEmpty(spritePath))
                tSprite = UIUtility.GetSpriteByPath(spritePath, spritePath.LastIndexOf((char)Const.kAscii_Colon) <= 0);
            img.sprite = tSprite;
        }

        public static void SetText(Text t, string text)
        {
            if (t == null) return;
            t.text = text;
        }

        public static void ScreenPointToLocalInRect(RectTransform t, Vector2 pos, out float x, out float y)
        {
            Vector2 vo;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(t, pos, null, out vo);
            x = vo.x + t.pivot.x*t.rect.width;
            y = vo.y + t.pivot.y*t.rect.height;
        }

        public static void ScreenPointToLocalPointInRectangle(RectTransform t, Vector2 pos, out float x, out float y) {
            Vector2 vo;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(t, pos, null, out vo);
            x = vo.x;// + t.pivot.x*t.rect.width;
            y = vo.y;// + t.pivot.y*t.rect.height;
        }

        public static void ScreenPointToWorldInRect(RectTransform t, Vector2 pos, out float x, out float y, out float z)
        {
            Vector3 vo;
            RectTransformUtility.ScreenPointToWorldPointInRectangle(t, pos, null, out vo);
            x = vo.x;
            y = vo.y;
            z = vo.z;
        }

        //玩家面向的三角形顶点
        public static Vector3[] GetObjectForwardAnglePos(UnityEngine.GameObject go, float distance, float angle)
        {
            Vector3[] posArr = new Vector3[2];
            Quaternion r = go.transform.rotation;
            Quaternion r0 = Quaternion.Euler(r.eulerAngles.x, r.eulerAngles.y + angle, r.eulerAngles.z);
            posArr[0] = go.transform.position + (r0 * Vector3.forward) * distance;
            Quaternion r1 = Quaternion.Euler(r.eulerAngles.x, r.eulerAngles.y - angle, r.eulerAngles.z);
            posArr[1] = go.transform.position + (r1 * Vector3.forward) * distance;
            return posArr;
            /* Quaternion r = go.transform.rotation;
             Quaternion r0 = Quaternion.Euler(r.eulerAngles.x, r.eulerAngles.y + angle, r.eulerAngles.z);
             Vector3 posArr = go.transform.position + (r0 * Vector3.forward) * distance;

             return posArr;*/
        }

        //玩家面向的矩形顶点
        public static Vector3[] GetObjectForwardRectPos(UnityEngine.GameObject go, float lDistance, float fDistance)
        {
            Vector3[] posArr = new Vector3[4];
            Quaternion r = go.transform.rotation;
            posArr[0] = go.transform.position + (r * Vector3.left) * lDistance;//左
            posArr[1] = go.transform.position + (r * Vector3.right) * lDistance;//右
            posArr[2] = posArr[1] + (r * Vector3.forward) * fDistance;//右前
            posArr[3] = posArr[0] + (r * Vector3.forward) * fDistance;//左前


            /*Debug.DrawLine(posArr[0], posArr[1], Color.red);
            Debug.DrawLine(posArr[1], posArr[2], Color.red);
            Debug.DrawLine(posArr[2], posArr[3], Color.red);
            Debug.DrawLine(posArr[3], posArr[0], Color.red);*/

            return posArr;
        }

        //判断点是否在扇形范围内
        public static bool GetPointIsInFanShaped(UnityEngine.GameObject go, float distance, float angle, Vector3 targetPos)
        {
            float dlen =(go.transform.position-targetPos).sqrMagnitude;
            if (dlen < distance * distance)
            {
                Vector3 norVec = go.transform.rotation * Vector3.forward;
                Vector3 tmpVec = targetPos - go.transform.position;
                float jiajiao = Mathf.Acos(Vector3.Dot(norVec.normalized, tmpVec.normalized)) * Mathf.Rad2Deg;
                if (jiajiao <= angle * 0.5)
                {
                    //在扇形内
                    return true;
                }
            }
            return false;
        }

        public static Camera FindCameraByName(string _name)
        {
            Camera _cam = null;
            GameObject go = GameObject.Find(_name);
            if (go)
            {
                _cam = go.GetComponent<Camera>();
            }
            return _cam;
        }

        /// <summary>
        /// 检查当前摄像机是否开着这个层级
        /// </summary>
        /// <param name="layer"></param>
        /// <returns></returns>
        public static bool CheckLayerIsOpen(Camera _cam, UserLayer layer)
        {
            if (_cam != null)
            {
                int l = 1 << (int)(layer);
                int h = (_cam.cullingMask & l);
                return h == l;
            }
            return false;
        }
        /// <summary>
        /// 关闭摄像机层
        /// </summary>
        /// <param name="layer"></param>
        public static void CloseUserLayer( Camera _cam,UserLayer layer)
        {
            if (_cam != null)
            {
                _cam.cullingMask &= ~(1 << (int)layer);
            }
        }
        /// <summary>
        /// 打开摄像机层
        /// </summary>
        /// <param name="layer"></param>
        public static void OpenUserLayer(Camera _cam, UserLayer layer)
        {
            if (_cam != null)
            {
                _cam.cullingMask |= (1 << (int)layer);
            }

        }

        public static object[] DoString(string luastr)
        {
            return LuaFunctor.DoString(luastr);
        }
        #region get ui control interface

        public static RectTransform GetChildRectTransform(Transform transform, string strName)
        {
            RectTransform rectTransform = null;
            if (string.IsNullOrEmpty(strName))
            {
                if (null != transform)
                {
                    rectTransform = transform.GetComponent<RectTransform>();
                }
            }
            else
            {
                Transform trans = GetChildTransform(transform, strName);
                if (null != trans)
                {
                    rectTransform = trans.GetComponent<RectTransform>();
                }
            }
            return rectTransform;
        }
        public static Transform GetChildTransform(Transform transform, string strName)
        {
            return GetChildTransformRecursive(transform, strName);
        }
        static Vector3[] m_corner = new Vector3[4];
        public static Vector3[] GetRectWorldCorner(RectTransform transform)
        {
            transform.GetWorldCorners(m_corner);
            return m_corner;
        }

        public static UnityEngine.Object GetChildObject(Object obj, string strName)
        {
            var trans = obj as Transform;
            if (trans)
                return GetChildObjectRecursive(trans, strName);
            var go = obj as GameObject;
            if (go)
                return GetChildObjectRecursive(go.transform, strName);
            return null;
        }

        public static Transform GetChildTransformRecursive(Transform transform, string strName)
        {
            Transform trans = transform.Find(strName);
            if (trans)
                return trans;
            for (int i = 0; i < transform.childCount; ++i)
            {
                trans = transform.GetChild(i);
                trans = GetChildTransformRecursive(trans, strName);
                if (trans)
                    return trans;
            }
            return null;
        }

        public static UnityEngine.Object GetChildObjectRecursive(Transform transform, string strName)
        {
            Transform trans = transform.Find(strName);
            if (trans)
                return trans.gameObject;

            UnityEngine.Object obj;
            for (int i = 0; i < transform.childCount; ++i)
            {
                trans = transform.GetChild(i);
                obj = GetChildObjectRecursive(trans, strName);
                if (obj)
                    return obj;
            }
            return null;
        }

        public static T GetComponent<T>(object obj, string strName) where T : UnityEngine.Component
        {

            Transform transform = obj as Transform;
            if (transform == null)
            {
                var go = obj as GameObject;
                if (go != null)                   
                    transform = go.transform;
                else
                {
                    var comp = obj as Component;
                    if (comp != null)
                        transform = comp.transform;
                    else
                        return null;
                }
            }

            Transform trans = null;
            if (!string.IsNullOrEmpty(strName))
            {
                trans = GetChildTransform(transform, strName);
            }
            else
            {
                trans = transform;
            }
            return trans ? trans.GetComponent<T>() : null;
        }
        public static UnityEngine.UI.Dropdown GetDropDownControl(object transform, string strName)
        {
            return GetComponent<Dropdown>(transform, strName);
        }

        public static Dropdown2 GetDropDown2Control(object transform, string strName)
        {
            return GetComponent<Dropdown2>(transform, strName);
        }

        public static UnityEngine.UI.Text GetTextControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.Text>(transform, strName);
        }
        
        public static UnityEngine.UI.ScrollRect GetScrollRectControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.ScrollRect>(transform, strName);
        }

        public static UnityEngine.UI.Button GetButtonControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.Button>(transform, strName);
        }

        public static UnityEngine.UI.Image GetImageControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.Image>(transform, strName);
        }
        public static UnityEngine.UI.RawImage GetRawImageControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.RawImage>(transform, strName);
        }
        public static UnityEngine.Video.VideoPlayer GetVideoPlayerControl(object transform, string strName)
        {   
            return GetComponent<UnityEngine.Video.VideoPlayer>(transform, strName);
        }

        public static UnityEngine.UI.Slider GetSliderControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.Slider>(transform, strName);
        }

        public static UnityEngine.UI.Toggle GetToggleControl(object transform, string strName)
        {
            return GetComponent<UnityEngine.UI.Toggle>(transform, strName);
        }

        public static UnityEngine.Color String2Color(string colors)
        {
            Color clr;
            uint c = uint.Parse(colors, System.Globalization.NumberStyles.HexNumber);
            clr.a = (c >> 24) / 255.0f;
            clr.r = ((c >> 16) & 0xff) / 255.0f;
            clr.g = ((c >> 8) & 0xff) / 255.0f;
            clr.b = (c & 0xff) / 255.0f;
            return clr;
        }

        #endregion

        /// <summary>
        /// Wheather entity contains collider
        /// </summary>
        /// <param name="ety"></param>
        /// <returns></returns>
        public static bool IsEntityContainCollider(Entity ety)
        {
            if (ety == null)
                return false;
            else if (ety.Avatar == null)
                return false;
            else if (ety.Avatar.getBoundBox() == null)
                return false;
            else
                return true;
        }

        public static string ReplaceMainCharName(string str)
        {
            MainCharacter mainchar = GameScene.Instance.MainChar;
            if(null != mainchar && !string.IsNullOrEmpty(str))
            {
                return str.Replace("{mainname}", mainchar.Name);
            }
            return str;
        }

        /// <summary>
        /// 设置spriteelement原始尺寸
        /// </summary>
        /// <param name="container"></param>
        /// <param name="uiName"></param>
        // public static void FindAndSetSpriteElement_OrigSize(UICtrlContent container, string uiName)
        // {
        //     if (null == container) return;
        //     UITransform tTran = container.FindChild(uiName);
        //     if (tTran == null)
        //         return;
        //     SpriteElement tElement = tTran as SpriteElement;
        //     if (tElement == null)
        //         return;
        //     Sprite sprite = tElement.sprite;
        //     if (sprite == null)
        //         return;
        //     tElement.SetSizeWithCurrentAnchors(Axis.Horizontal, sprite.rect.width);
        // }

        // public static void SetScrollListPadding(ScrollList scrolllist, int left, int right, int top, int bottom) {
        //     Padding pd = new Padding(left, right, top, bottom);
        //     scrolllist.padding = pd;
        // }

        public static void MarkLayoutForRebuild(Transform trans) {
            RectTransform recttrans = trans.GetComponent<RectTransform>();
            LayoutRebuilder.MarkLayoutForRebuild(recttrans);
        }
    }

}