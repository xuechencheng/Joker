namespace Bokura
{
    using System;
    using XLua.LuaDLL;
    public class LuaFunctor
    {
        XLua.LuaFunction m_luaFunction;
        public LuaFunctor(string strTableName, string strFuncName)
        {
            InitFunction(strTableName, strFuncName);
        }
        public LuaFunctor(string strFuncName)
        {
            InitFunction(strFuncName);
        }
        private void InitFunction(string strFuncName)
        {
            if (!string.IsNullOrEmpty(strFuncName))
            {
                int index = strFuncName.IndexOf('.');
                if (index >= 0)
                {
                    string strTableName = strFuncName.Substring(0, index);
                    strFuncName = strFuncName.Substring(index + 1);
                    InitFunction(strTableName, strFuncName);
                }
                else
                {
                    m_luaFunction = GameApplication.Instance.LuaInstance.Global.Get<XLua.LuaFunction>(strFuncName);
                }
            }
        }
        private void InitFunction(string strTableName, string strFuncName)
        {
            if (!string.IsNullOrEmpty(strFuncName))
            {
                XLua.LuaEnv luaEnv = GameApplication.Instance.LuaInstance;
                IntPtr L = luaEnv.L;
                if (string.IsNullOrEmpty(strTableName))
                {
                    m_luaFunction = luaEnv.Global.Get<XLua.LuaFunction>(strFuncName);
                }
                else
                {
                    int oldTop = Lua.lua_gettop(L);
                    Lua.xlua_getglobal(L, strTableName);
                    if (Lua.lua_istable(L, -1))
                    {
                        Lua.lua_pushstring(L, strFuncName);
                        if (0 != Lua.xlua_pgettable(L, -2))
                        {
                            string err = Lua.lua_tostring(L, -1);
                            Lua.lua_settop(L, oldTop);
                            throw new Exception(Bokura.Utilities.BuildString("get field [", strFuncName, "] error:", err));
                        }
                        try
                        {
                            luaEnv.translator.Get(L, -1, out m_luaFunction);
                        }
                        catch (Exception e)
                        {
                            throw e;
                        }
                        finally
                        {
                            Lua.lua_settop(L, oldTop);
                        }
                    }
                }
            }
        }
        public TResult Call<T, TResult>(T a)
        {
            if (m_luaFunction != null)
            {
                return m_luaFunction.Func<T, TResult>(a);
            }

            return default(TResult);
        }

        public TResult Call<T1, T2, TResult>(T1 a, T2 b)
        {
            if(m_luaFunction != null)
            {
                return m_luaFunction.Func<T1, T2, TResult>(a, b);
            }

            return default(TResult);
        }

        public void Call()
        {
            if(m_luaFunction != null)
            {
                m_luaFunction.Action();
            }
        }

        public void Call<T>(T a)
        {
            if(m_luaFunction != null)
            {
                m_luaFunction.Action<T>(a);
            }
        }

        public void Call<T1, T2>(T1 a, T2 b)
        {
            if(m_luaFunction != null)
            {
                m_luaFunction.Action<T1, T2>(a, b);
            }
        }

        public void Call<T1, T2, T3>(T1 a, T2 b, T3 c)
        {
            if(m_luaFunction != null)
            {
                m_luaFunction.Action<T1, T2, T3>(a, b, c);
            }
        }

        public void Call<T1, T2, T3, T4>(T1 a, T2 b, T3 c, T4 d)
        {
            if(m_luaFunction != null)
            {
                m_luaFunction.Action<T1, T2, T3, T4>(a, b, c, d);
            }
        }

        public static object[] LoadLuaFile(string strFileName)
        {
            string str  = Bokura.Utilities.BuildString("require '", strFileName, "'");
            return GameApplication.Instance.LuaInstance.DoString(str);
        }

        public static object[] DoString(string strFunc)
        {
            return GameApplication.Instance.LuaInstance.DoString(strFunc);
        }
        public bool IsNull()
        {
            return m_luaFunction == null;
        }
    }
}
