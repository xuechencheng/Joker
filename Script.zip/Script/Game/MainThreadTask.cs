﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Bokura;
using XLua;

public class MainThreadTask  {

    public delegate void TaskFun();


    Queue<TaskFun> m_TaskFunList = new Queue<TaskFun>(10);
	//int m_DoTaskThreadID = 0;

    public void Init()
    {
    }

	public void Shutdown()
	{
		msInstance = null;
	}

    private MainThreadTask()
    {

    }

    static MainThreadTask msInstance = new MainThreadTask();
    public static MainThreadTask getSingleton()
    {
        return msInstance;
    }
    public void push_task(TaskFun fun)
    {
		
        lock(m_TaskFunList)
        {
			//if (m_DoTaskThreadID == System.Threading.Thread.CurrentThread.ManagedThreadId)
			//	fun();
			//else
				m_TaskFunList.Enqueue(fun);
        }
    }

    public void do_task()
    {
        lock(m_TaskFunList)
        {
			//m_DoTaskThreadID = System.Threading.Thread.CurrentThread.ManagedThreadId;
            var start_time = UnityEngine.Time.realtimeSinceStartup;

            while (m_TaskFunList.Count>0)
            {
                var p = m_TaskFunList.Dequeue();
                {
					try
					{
						p();
					}
					catch(Exception e)
					{
                        LogHelper.LogError(e.ToString());
                    }

                  
                }

                if(UnityEngine.Time.realtimeSinceStartup - start_time>0.05f)
                {
                    break;
                }
            }

			//m_DoTaskThreadID = 0;
		}
	}
}
