﻿using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
#if ENABLE_MANOR
namespace Bokura
{
    public class ManorCanvas : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        public void OnPointerDown(PointerEventData eventData)
        {
            //if (eventData.pointerId == -1)  // -1 表示鼠标左键
            {
                if (ManorModel.Instance.ManorDesigner != null)
                    ManorModel.Instance.ManorDesigner.CurEditMode.OnPointerDown(eventData);
            }
        }

        public void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            //if (eventData.pointerId == -1) // -1 表示鼠标左键
            {
                if (ManorModel.Instance.ManorDesigner != null)
                    ManorModel.Instance.ManorDesigner.CurEditMode.OnPointerUp(eventData);
            }
        }

        public void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            //if (eventData.pointerId == -1) // -1 表示鼠标左键
            {
                if (ManorModel.Instance.ManorDesigner != null)
                    ManorModel.Instance.ManorDesigner.CurEditMode.OnBeginDrag(eventData);
            }
        }

        public void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            //if (eventData.pointerId == -1) // -1 表示鼠标左键
            {
                if (ManorModel.Instance.ManorDesigner != null)
                    ManorModel.Instance.ManorDesigner.CurEditMode.OnDrag(eventData);
            }
        }

        public void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            //if (eventData.pointerId == -1) // -1 表示鼠标左键
            {
                if (ManorModel.Instance.ManorDesigner != null)
                    ManorModel.Instance.ManorDesigner.CurEditMode.OnEndDrag(eventData);
            }
        }
    }
}
#endif