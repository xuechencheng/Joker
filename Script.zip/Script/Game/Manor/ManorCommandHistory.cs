﻿using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;
#if ENABLE_MANOR
namespace Bokura
{
    public class ManorCommandHistory
    {
        ManorDesigner m_ManorDesigner;
        public ManorDesigner ManorDesigner
        {
            get
            {
                return m_ManorDesigner;
            }
        }
        ManorWorld m_ManorWorld;
        public ManorWorld ManorWorld
        {
            get
            {
                return m_ManorWorld;
            }
        }
        public ManorCommandHistory(ManorDesigner designer)
        {
            m_ManorDesigner = designer;
            m_ManorWorld = m_ManorDesigner.ManorWorld;
        }

        Stack<ManorCommandBase> m_CommandList = new Stack<ManorCommandBase>(16);
        Stack<ManorCommandBase> m_UndoList = new Stack<ManorCommandBase>(16);
        
        void ExecuteCommand(ManorCommandBase cmd, ManorCommandBase.CommandArgsBase args)
        {
            cmd.Execute(args);
            m_CommandList.Push(cmd);

            ClearUndoList();
        }
        public void ExecuteCommandPutObject(ManorCommandPutObject.CommandArgsPutObject args)
        {
            ExecuteCommand(new ManorCommandPutObject(this), args);
        }
        public void ExecuteCommandPutMultiObjects(ManorCommandPutMultiObjects.CommandArgsPutMultiObjects args)
        {
            ExecuteCommand(new ManorCommandPutMultiObjects(this), args);
        }
        public void ExecuteCommandPutAutoWall(ManorCommandPutAutoWall.CommandArgsPutAutoWall args)
        {
            ExecuteCommand(new ManorCommandPutAutoWall(this), args);
        }
        public void ExecuteCommandMoving(ManorCommandMoving.CommandArgsMoving args)
        {
            ExecuteCommand(new ManorCommandMoving(this), args);
        }
        public void ExecuteCommandDeleteObjects(ManorCommandDeleteObjects.CommandArgsDeleteObjects args)
        {
            ExecuteCommand(new ManorCommandDeleteObjects(this), args);
        }
        public bool CanUndo()
        {
            return m_CommandList.Count > 0;
        }
        public bool CanRedo()
        {
            return m_UndoList.Count > 0;
        }
        public void Undo()
        {
            if (! CanUndo())
            {
                return;
            }

            var cmd = m_CommandList.Pop();
            cmd.Undo();
            m_UndoList.Push(cmd);
        }
        public void Redo()
        {
            if (! CanRedo())
            {
                return;
            }

            var cmd = m_UndoList.Pop();
            cmd.Redo();
            m_CommandList.Push(cmd);
        }
        void ClearUndoList()
        {
            while (m_UndoList.Count > 0)
            {
                var cmd = m_UndoList.Pop();
                cmd.Destroy();
            }
        }
        public void Uninit()
        {
//             while (m_CommandList.Count > 0)
//             {
//                 var cmd = m_CommandList.Pop();
//                 cmd.Destroy();
//             }
            ClearUndoList();
        }
    }

    public abstract class ManorCommandBase
    {
        public class CommandArgsBase
        {

        }
        protected ManorCommandHistory m_ManorCommandHistory;
        
        public ManorCommandBase(ManorCommandHistory history)
        {
            m_ManorCommandHistory = history;
        }
        public abstract void Execute(CommandArgsBase e);
        public abstract void Redo();
        public abstract void Undo();
        public virtual void Destroy() { }
    }

    public class ManorCommandPutObject : ManorCommandBase
    {
        public class CommandArgsPutObject : ManorCommandBase.CommandArgsBase
        {
            public List<ManorObject> saveSelections;
            public ManorObject obj;
        }

        ManorObject m_object;
        List<ManorObject> m_selection;
        public ManorCommandPutObject(ManorCommandHistory history)
            : base(history)
        {
            
        }
        public override void Execute(CommandArgsBase e)
        {
            CommandArgsPutObject args = (CommandArgsPutObject)e;

            m_object = args.obj;
            m_object.ID = m_ManorCommandHistory.ManorWorld.GenerateObjectID();

            m_selection = new List<ManorObject>(args.saveSelections);

            m_ManorCommandHistory.ManorWorld.AddObject(m_object);

            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            m_ManorCommandHistory.ManorDesigner.SelectObject(m_object);
        }
        public override void Redo()
        {
            m_ManorCommandHistory.ManorWorld.AddObject(m_object);

            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            m_ManorCommandHistory.ManorDesigner.SelectObject(m_object);

            m_object.ReloadModel();
        }
        public override void Undo()
        {
            m_ManorCommandHistory.ManorWorld.RemoveObject(m_object);
            
            m_object.Destroy();

            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_selection.Count; ++i)
            {
                m_ManorCommandHistory.ManorDesigner.SelectObject(m_selection[i]);
            }
        }
        public override void Destroy()
        {
            if (m_object != null)
            {
                m_object.Destroy();
                m_object = null;
            }
        }
    }

    public class ManorCommandPutMultiObjects : ManorCommandBase
    {
        public class CommandArgsPutMultiObjects : ManorCommandBase.CommandArgsBase
        {
            public List<ManorObject> saveSelections;
            public ManorObject obj;
            public List<ManorObject.Cell> cells;
        }

        List<ManorObject> m_objectList;
        List<ManorObject> m_selection;

        public ManorCommandPutMultiObjects(ManorCommandHistory history)
            : base(history)
        {
            
        }
        public override void Execute(CommandArgsBase e)
        {
            CommandArgsPutMultiObjects args = (CommandArgsPutMultiObjects)e;
            m_selection = new List<ManorObject>(args.saveSelections);

            m_objectList = new List<ManorObject>(args.cells.Count);

            for (int i = 0; i < args.cells.Count; ++i)
            {
                ManorObject newObj = args.obj.Copy();
                newObj.ID = m_ManorCommandHistory.ManorWorld.GenerateObjectID();
                newObj.SetCell(args.cells[i]);

                m_objectList.Add(newObj);
            }

            Redo();
        }
        public override void Redo()
        {
            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_objectList.Count; ++i)
            {
                ManorObject obj = m_objectList[i];
                
                m_ManorCommandHistory.ManorWorld.AddObject(obj);

                m_ManorCommandHistory.ManorDesigner.SelectObject(obj);

                obj.ReloadModel();
            }
        }
        public override void Undo()
        {
            for (int i = 0; i < m_objectList.Count; ++i)
            {
                ManorObject obj = m_objectList[i];

                m_ManorCommandHistory.ManorWorld.RemoveObject(obj);

                obj.Destroy();
            }

            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_selection.Count; ++i)
            {
                m_ManorCommandHistory.ManorDesigner.SelectObject(m_selection[i]);
            }
        }
        public override void Destroy()
        {
            if (m_objectList != null)
            {
                for (int i = 0; i < m_objectList.Count; ++i)
                {
                    ManorObject obj = m_objectList[i];

                    obj.Destroy();
                }
                m_objectList.Clear();
                m_objectList = null;
            }
        }
    }

    public class ManorCommandPutAutoWall : ManorCommandBase
    {
        public class CommandArgsPutAutoWall : ManorCommandBase.CommandArgsBase
        {
            public List<ManorObject> saveSelections;
            public ManorObject obj;
            public List<ManorObject.Cell> cells;
        }
        
        List<ManorAutoWallChunk> m_newAutoWallChunks;
        List<ManorAutoWallChunk> m_updateAutoWallChunks;

        List<swm.ManorChunkType> m_oldAutoWallChunkTypes;
        List<swm.ManorChunkType> m_newAutoWallChunkTypes;

        // List<ManorObject> m_selection;//没有用的变量 m_selection 只赋值了，但没使用  会报警告 注销掉 赋值的地方也注销 shiliang

        public ManorCommandPutAutoWall(ManorCommandHistory history)
            : base(history)
        {
                        
        }
        public override void Execute(CommandArgsBase e)
        {
            CommandArgsPutAutoWall args = (CommandArgsPutAutoWall)e;

            m_newAutoWallChunks = new List<ManorAutoWallChunk>(args.cells.Count);
            
            var needUpdateModelChunks = new Dictionary<ManorAutoWallChunk, x2m.ManorChunkType>(args.cells.Count);
            
            for (int i = 0; i < args.cells.Count; ++i)
            {
                var cell = args.cells[i];

                ManorObject obj = args.obj.Copy();
                obj.ID = m_ManorCommandHistory.ManorWorld.GenerateObjectID();

                m_ManorCommandHistory.ManorWorld.AddObject(obj);

                ManorAutoWallChunk autoWallChunk = obj as ManorAutoWallChunk;

                obj.SetCell(cell);

                m_newAutoWallChunks.Add(autoWallChunk);
            }

            for (int i = 0; i < m_newAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_newAutoWallChunks[i];
                
                m_ManorCommandHistory.ManorDesigner.UpdateAutoWallChunk(autoWallChunk, needUpdateModelChunks);
            }

            m_updateAutoWallChunks = new List<ManorAutoWallChunk>(needUpdateModelChunks.Count);
            m_oldAutoWallChunkTypes = new List<x2m.ManorChunkType>(needUpdateModelChunks.Count);
            m_newAutoWallChunkTypes = new List<x2m.ManorChunkType>(needUpdateModelChunks.Count);
            
            var iter = needUpdateModelChunks.GetEnumerator();
            while (iter.MoveNext())
            {
                var autoWallChunk = iter.Current.Key;
                var oldChunkType = iter.Current.Value;

                autoWallChunk.ReloadModel();

                if (m_newAutoWallChunks.IndexOf(autoWallChunk) == -1)
                {
                    m_oldAutoWallChunkTypes.Add(oldChunkType);
                    m_newAutoWallChunkTypes.Add(autoWallChunk.ChunkType);

                    m_updateAutoWallChunks.Add(autoWallChunk);
                }
            }

            //m_selection = new List<ManorObject>(args.saveSelections);//没有用的变量 m_selection 只赋值了，但没使用  会报警告 注销掉 赋值的地方也注销 shiliang
        }
        public override void Redo()
        {
            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            
            for (int i = 0; i < m_newAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_newAutoWallChunks[i];

                m_ManorCommandHistory.ManorWorld.AddObject(autoWallChunk);

                autoWallChunk.ReloadModel();
            }

            for (int i = 0; i < m_updateAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_updateAutoWallChunks[i];

                autoWallChunk.ChunkType = m_newAutoWallChunkTypes[i];

                autoWallChunk.ReloadModel();
            }
        }
        public override void Undo()
        {
            for (int i = 0; i < m_newAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_newAutoWallChunks[i];

                m_ManorCommandHistory.ManorWorld.RemoveObject(autoWallChunk);

                autoWallChunk.Destroy();
            }

            for (int i = 0; i < m_updateAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_updateAutoWallChunks[i];

                autoWallChunk.ChunkType = m_oldAutoWallChunkTypes[i];

                autoWallChunk.ReloadModel();
            }
        }
        public override void Destroy()
        {
            if (m_newAutoWallChunks != null)
            {
                for (int i = 0; i < m_newAutoWallChunks.Count; ++i)
                {
                    ManorAutoWallChunk autoWallChunk = m_newAutoWallChunks[i];

                    autoWallChunk.Destroy();
                }

                m_newAutoWallChunks.Clear();
                m_newAutoWallChunks = null;
            }

        }
    }

    public class ManorCommandMoving : ManorCommandBase
    {
        public class CommandArgsMoving : ManorCommandBase.CommandArgsBase
        {
            public List<ManorObject> objectList;
            public List<ManorObject.Cell> srcCellList;
            public List<swm.ManorDirection> srcDirList;
            public List<ManorObject.Cell> destCellList;
            public List<swm.ManorDirection> destDirList;
        }

        List<ManorObject> m_objectList;
        List<ManorObject.Cell> m_srcCellList;
        List<swm.ManorDirection> m_srcDirList;
        List<ManorObject.Cell> m_destCellList;
        List<swm.ManorDirection> m_destDirList;

        List<ManorAutoWallChunk> m_updateAutoWallChunks;

        List<swm.ManorChunkType> m_oldAutoWallChunkTypes;
        List<swm.ManorChunkType> m_newAutoWallChunkTypes;

        public ManorCommandMoving(ManorCommandHistory history)
            : base(history)
        {
            
        }
        public override void Execute(CommandArgsBase e)
        {
            CommandArgsMoving args = (CommandArgsMoving)e;

            m_objectList = new List<ManorObject>(args.objectList);
            m_srcCellList = new List<ManorObject.Cell>(args.srcCellList);
            m_srcDirList = new List<x2m.ManorDirection>(args.srcDirList);
            m_destCellList = new List<ManorObject.Cell>(args.destCellList);
            m_destDirList = new List<x2m.ManorDirection>(args.destDirList);

            m_updateAutoWallChunks = new List<ManorAutoWallChunk>(2);

            m_oldAutoWallChunkTypes = new List<x2m.ManorChunkType>(2);
            m_newAutoWallChunkTypes = new List<x2m.ManorChunkType>(2);

            Redo();
        }
        public override void Redo()
        {
            var needUpdateModelChunks = new Dictionary<ManorAutoWallChunk, x2m.ManorChunkType>(2);

            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_objectList.Count; ++i)
            {
                ManorObject obj = m_objectList[i];

                m_ManorCommandHistory.ManorDesigner.SelectObject(obj);

                obj.Direction = m_destDirList[i];

                ManorObject.Cell cell = m_destCellList[i];
                obj.SetCell(cell);

                if (obj.ObjectType == x2m.ManorObjectType.AutoWallChunk)
                {
                    ManorObject.Cell oldcell = m_srcCellList[i];

                    ManorAutoWallChunk autoWallChunk = obj as ManorAutoWallChunk;
                    
                    int chunk_sizew = autoWallChunk.ObjectMask.mask_w;
                    int chunk_sizeh = autoWallChunk.ObjectMask.mask_h;

                    int old_chunk_col = oldcell.left / chunk_sizew;
                    int old_chunk_row = oldcell.top / chunk_sizeh;

                    m_ManorCommandHistory.ManorDesigner.UpdateAroundAutoWallChunks(autoWallChunk.BaseID, old_chunk_col, old_chunk_row, needUpdateModelChunks);
                    
                    m_ManorCommandHistory.ManorDesigner.UpdateAutoWallChunk(autoWallChunk, needUpdateModelChunks);
                }
            }

            m_updateAutoWallChunks.Clear();

            m_oldAutoWallChunkTypes.Clear();
            m_newAutoWallChunkTypes.Clear();

            var iter = needUpdateModelChunks.GetEnumerator();
            while (iter.MoveNext())
            {
                var autoWallChunk = iter.Current.Key;
                var oldChunkType = iter.Current.Value;

                m_oldAutoWallChunkTypes.Add(oldChunkType);
                m_newAutoWallChunkTypes.Add(autoWallChunk.ChunkType);

                m_updateAutoWallChunks.Add(autoWallChunk);

                autoWallChunk.ReloadModel();
            }
        }
        public override void Undo()
        {
            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_objectList.Count; ++i)
            {
                ManorObject obj = m_objectList[i];

                m_ManorCommandHistory.ManorDesigner.SelectObject(obj);

                obj.Direction = m_srcDirList[i];

                ManorObject.Cell cell = m_srcCellList[i];
                obj.SetCell(cell);
            }

            for (int i = 0; i < m_updateAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_updateAutoWallChunks[i];

                autoWallChunk.ChunkType = m_oldAutoWallChunkTypes[i];

                autoWallChunk.ReloadModel();
            }
        }
    }

    public class ManorCommandSelection : ManorCommandBase
    {
        public class CommandArgsSelection : ManorCommandBase.CommandArgsBase
        {
            public List<ManorObject> saveSelections;
            public List<ManorObject> selectionList;
        }

        List<ManorObject> m_SelectionList;
        List<ManorObject> m_OldSelectionList;
        public ManorCommandSelection(ManorCommandHistory history)
            : base(history)
        {
            
        }
        public override void Execute(CommandArgsBase e)
        {
            CommandArgsSelection args = (CommandArgsSelection)e;

            m_OldSelectionList = new List<ManorObject>(args.saveSelections);
            m_SelectionList = new List<ManorObject>(args.selectionList);

            Redo();
        }
        public override void Redo()
        {
            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_SelectionList.Count; ++i)
            {
                m_ManorCommandHistory.ManorDesigner.SelectObject(m_SelectionList[i]);
            }
        }
        public override void Undo()
        {
            m_ManorCommandHistory.ManorDesigner.DeselectAll();
            for (int i = 0; i < m_OldSelectionList.Count; ++i)
            {
                m_ManorCommandHistory.ManorDesigner.SelectObject(m_OldSelectionList[i]);
            }
        }
    }

    public class ManorCommandDeleteObjects : ManorCommandBase
    {
        public class CommandArgsDeleteObjects : ManorCommandBase.CommandArgsBase
        {
            public List<ManorObject> objectList;
        }
        
        List<ManorObject> m_ObjectList;
        List<ManorWorld.ObjectData> m_objDataList;

        List<ManorAutoWallChunk> m_deletedAutoWallChunks;
        List<x2m.ManorChunkType> m_deletedAutoWallChunkTypes;

        List<ManorAutoWallChunk> m_updateAutoWallChunks;

        List<x2m.ManorChunkType> m_oldAutoWallChunkTypes;
        List<x2m.ManorChunkType> m_newAutoWallChunkTypes;

        public ManorCommandDeleteObjects(ManorCommandHistory history)
            : base(history)
        {
            
        }
        public override void Execute(CommandArgsBase e)
        {
            CommandArgsDeleteObjects args = (CommandArgsDeleteObjects)e;

            m_ObjectList = new List<ManorObject>(args.objectList);

            m_deletedAutoWallChunks = new List<ManorAutoWallChunk>(2);
            m_deletedAutoWallChunkTypes = new List<x2m.ManorChunkType>(2);

            m_updateAutoWallChunks = new List<ManorAutoWallChunk>(2);

            m_oldAutoWallChunkTypes = new List<x2m.ManorChunkType>(2);
            m_newAutoWallChunkTypes = new List<x2m.ManorChunkType>(2);

            Redo();
        }
        public override void Redo()
        {
            var needUpdateModelChunks = new Dictionary<ManorAutoWallChunk, x2m.ManorChunkType>(2);

            m_ManorCommandHistory.ManorDesigner.DeselectAll();

            for (int i = 0; i < m_ObjectList.Count; ++i)
            {
                ManorObject obj = m_ObjectList[i];
                m_ManorCommandHistory.ManorWorld.RemoveObject(obj);

                obj.Destroy();

                if (obj.ObjectType == x2m.ManorObjectType.AutoWallChunk)
                {
                    ManorAutoWallChunk autoWallChunk = obj as ManorAutoWallChunk;
                    
                    m_ManorCommandHistory.ManorDesigner.UpdateAroundAutoWallChunks(autoWallChunk.BaseID, autoWallChunk.chunk_col, autoWallChunk.chunk_row, needUpdateModelChunks);

                    m_ManorCommandHistory.ManorDesigner.UpdateAutoWallChunk(autoWallChunk, needUpdateModelChunks);

                    m_deletedAutoWallChunks.Add(autoWallChunk);
                    m_deletedAutoWallChunkTypes.Add(autoWallChunk.ChunkType);
                }
            }

            m_updateAutoWallChunks.Clear();

            m_oldAutoWallChunkTypes.Clear();
            m_newAutoWallChunkTypes.Clear();

            var iter = needUpdateModelChunks.GetEnumerator();
            while (iter.MoveNext())
            {
                var autoWallChunk = iter.Current.Key;
                var oldChunkType = iter.Current.Value;

                if (m_deletedAutoWallChunks.IndexOf(autoWallChunk) == -1)
                {
                    m_oldAutoWallChunkTypes.Add(oldChunkType);
                    m_newAutoWallChunkTypes.Add(autoWallChunk.ChunkType);

                    m_updateAutoWallChunks.Add(autoWallChunk);

                    autoWallChunk.ReloadModel();
                }
            }
        }
        public override void Undo()
        {
            m_ManorCommandHistory.ManorDesigner.DeselectAll();

            for (int i = 0; i < m_ObjectList.Count; ++i)
            {
                ManorObject obj = m_ObjectList[i];
                m_ManorCommandHistory.ManorWorld.AddObject(obj);

                m_ManorCommandHistory.ManorDesigner.SelectObject(obj);

                if (obj.ObjectType == x2m.ManorObjectType.AutoWallChunk)
                {
                    ManorAutoWallChunk autoWallChunk = obj as ManorAutoWallChunk;

                    int idx = m_deletedAutoWallChunks.IndexOf(autoWallChunk);
                    autoWallChunk.ChunkType = m_deletedAutoWallChunkTypes[idx];

                    autoWallChunk.ReloadModel();
                }
                else
                {
                    obj.ReloadModel();
                }
            }

            for (int i = 0; i < m_updateAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = m_updateAutoWallChunks[i];

                autoWallChunk.ChunkType = m_oldAutoWallChunkTypes[i];

                autoWallChunk.ReloadModel();
            }
        }
    }
    

}
#endif