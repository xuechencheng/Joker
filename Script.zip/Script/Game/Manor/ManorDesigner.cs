﻿using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;
#if ENABLE_MANOR
namespace Bokura
{
    public class ManorDesigner
    {
        public enum ManorEditMode
        {
            Selection = 0,
            PutBuilding,
            PutFloorObject,
            PutAutoWall,
            PutWater,
            RemoveWater,
        }
        ManorCommandHistory m_ManorCommandHistory;
        public ManorCommandHistory ManorCommandHistory
        {
            get
            {
                return m_ManorCommandHistory;
            }
        }
        ManorWorld m_ManorWorld;
        public ManorWorld ManorWorld
        {
            get
            {
                return m_ManorWorld;
            }
        }
        ManorEditModeMachine<ManorDesigner, ManorDesigner.ManorEditMode> m_SM;
        public bool ShowGrid
        {
            get
            {
                return m_ManorWorld.ShowGrid;
            }
            set
            {
                m_ManorWorld.ShowGrid = value;
            }
        }
        public void Init(ManorWorld manorWorld)
        {
            m_ManorWorld = manorWorld;

            m_SM = ManorEditModeFactory.CreateSM(this);

            m_ManorCommandHistory = new ManorCommandHistory(this);
        }
        public class SelectionChangedEvent : GameEvent
        {

        }
        public SelectionChangedEvent OnSelectionChanged = new SelectionChangedEvent();

        List<ManorObject> m_SelectionList = new List<ManorObject>(8);
        public List<ManorObject> SelectionList
        {
            get
            {
                return m_SelectionList;
            }
        }
        public int SelectionCount
        {
            get
            {
                return m_SelectionList.Count;
            }
        }
        public ManorObject GetSelection(int idx)
        {
            if (idx >= 0 && idx < m_SelectionList.Count)
            {
                return m_SelectionList[idx];
            }
            return null;
        }
        public void Uninit()
        {
            DeselectAll();

            m_ManorCommandHistory.Uninit();

            m_SM.Destroy();
            m_SM = null;
        }

        bool isModified = false;
        public bool Modified
        {
            get
            {
                return isModified;
            }
        }
        ManorEditMode m_EditMode;
        public ManorEditMode EditMode
        {
            get
            {
                return m_EditMode;
            }
            set
            {
                if (m_EditMode != value)
                {
                    m_EditMode = value;

                    m_SM.ChangeState(m_EditMode);
                }
            }
        }
        public int PuttingObjectID { get; private set; }
        public ManorObject PuttingObject;
        public ManorEditModeBase<ManorDesigner, ManorDesigner.ManorEditMode> CurEditMode
        {
            get
            {
                return m_SM.CurState;
            }
        }
        public ManorObject CreateObjectByID(int id)
        {
            var config = ManorObjectTableManager.GetData(id);
            if (!config.HasValue)
            {
                return null;
            }

            ManorObject newobj = null;

            if (config.Value.tag == 1) // 开掘水池
            {

            }
            else if (config.Value.tag == 2) // 填埋水池
            {

            }
            else if (config.Value.tag == 3) // 自动墙
            {
                newobj = new ManorAutoWallChunk(m_ManorWorld);
            }
            else if (config.Value.layer == 1) // 地板层
            {
                newobj = new ManorFloor(m_ManorWorld);
            }
            else if (config.Value.layer == 2) // 物件层
            {
                newobj = new ManorBuilding(m_ManorWorld);
            }
            else
            {
                return null;
            }

            if (!newobj.Init(config))
            {
                return null;
            }

            return newobj;
        }
        public void SetCurrPuttingObjectID(int puttingObjID)
        {
            var config = ManorObjectTableManager.GetData(puttingObjID);
            if (!config.HasValue)
            {
                return;
            }

            ManorEditMode newEidtMode = ManorEditMode.Selection;
            if (config.Value.tag == 1) // 开掘水池
                newEidtMode = ManorEditMode.PutWater;
            else if (config.Value.tag == 2) // 填埋水池
                newEidtMode = ManorEditMode.RemoveWater;
            else if (config.Value.tag == 3) // 自动墙
                newEidtMode = ManorEditMode.PutAutoWall;
            else if (config.Value.layer == 1) // 地板层
                newEidtMode = ManorEditMode.PutFloorObject;
            else if (config.Value.layer == 2) // 物件层
                newEidtMode = ManorEditMode.PutBuilding;
            else
                Debug.Assert(false);

            ManorObject newobj = CreateObjectByID(puttingObjID);

            if (PuttingObject != null)
            {
                PuttingObject.Destroy();
                PuttingObject = null;
            }

            PuttingObjectID = puttingObjID;

            PuttingObject = newobj;

            if (newEidtMode == this.EditMode)
            {
                m_SM.SendMessage(ManorEditModeBase<ManorDesigner, ManorDesigner.ManorEditMode>.MESSAGE_PUTTING_OBJECT_CHANGED, null);
            }
            else
            {
                EditMode = newEidtMode;
            }
        }
        public bool MousePosition2World(Vector3 position, out Vector3 hitpoint)
        {
            int layerMask = LayerMask.GetMask("Terrain");
            Ray ray = ManorBuildingCameraController.Instance.Camera.ScreenPointToRay(position);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 1000.0f, layerMask))
            {
                hitpoint = hit.point;
                return true;
            }
            hitpoint = Vector3.zero;
            return false;
        }
        public void SelectObject(ManorObject obj)
        {
            if (obj == null || obj.Selected)
            {
                return;
            }
            obj.Selected = true;
            m_SelectionList.Add(obj);

            OnSelectionChanged?.Invoke();
        }
        public void DeselectObject(ManorObject obj)
        {
            if (obj == null || ! obj.Selected)
            {
                return;
            }
            obj.Selected = false;
            m_SelectionList.Remove(obj);

            OnSelectionChanged?.Invoke();
        }
        public void DeselectAll()
        {
            for (int i = m_SelectionList.Count - 1; i >= 0; --i)
            {
                DeselectObject(m_SelectionList[i]);
            }

            OnSelectionChanged?.Invoke();
        }

        public ManorAutoWallChunk GetAutoWallChunk(int autoWallBaseID, int chunk_col, int chunk_row)
        {
            return this.ManorWorld.GetAutoWallChunkInCell(autoWallBaseID, chunk_col, chunk_row);
        }
        public void UpdateAroundAutoWallChunks(int autoWallBaseID, int chunk_col, int chunk_row, Dictionary<ManorAutoWallChunk, x2m.ManorChunkType> needUpdateModelChunks)
        {
            ManorAutoWallChunk obj_above = GetAutoWallChunk(autoWallBaseID, chunk_col, chunk_row + 1);
            ManorAutoWallChunk obj_below = GetAutoWallChunk(autoWallBaseID, chunk_col, chunk_row - 1);
            ManorAutoWallChunk obj_left = GetAutoWallChunk(autoWallBaseID, chunk_col - 1, chunk_row);
            ManorAutoWallChunk obj_right = GetAutoWallChunk(autoWallBaseID, chunk_col + 1, chunk_row);

            if (obj_above != null)
            {
                UpdateAutoWallChunk(obj_above, needUpdateModelChunks);
            }
            if (obj_below != null)
            {
                UpdateAutoWallChunk(obj_below, needUpdateModelChunks);
            }
            if (obj_left != null)
            {
                UpdateAutoWallChunk(obj_left, needUpdateModelChunks);
            }
            if (obj_right != null)
            {
                UpdateAutoWallChunk(obj_right, needUpdateModelChunks);
            }
        }
        public void UpdateAutoWallChunk(ManorAutoWallChunk autoWallChunk, Dictionary<ManorAutoWallChunk, x2m.ManorChunkType> needUpdateModelChunks)
        {
            x2m.ManorChunkType newChunkType = autoWallChunk.ChunkType;

            int chunk_col = autoWallChunk.chunk_col;
            int chunk_row = autoWallChunk.chunk_row;

            ManorAutoWallChunk obj_above = GetAutoWallChunk(autoWallChunk.BaseID, chunk_col, chunk_row + 1);
            ManorAutoWallChunk obj_below = GetAutoWallChunk(autoWallChunk.BaseID, chunk_col, chunk_row - 1);
            ManorAutoWallChunk obj_left = GetAutoWallChunk(autoWallChunk.BaseID, chunk_col - 1, chunk_row);
            ManorAutoWallChunk obj_right = GetAutoWallChunk(autoWallChunk.BaseID, chunk_col + 1, chunk_row);

            if (obj_above != null && obj_below != null)
            {
                if (obj_left != null && obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Cross;  // ┼
                }
                else if (obj_left != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_T_Corner_Left;   // ┤
                }
                else if (obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_T_Corner_Right;     // ├
                }
                else
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Line_Vert;       // │
                }
            }
            else if (obj_above != null)
            {
                if (obj_left != null && obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_T_Corner_Up;  // ┴
                }
                else if (obj_left != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Corner_Bottom_Right;   // ┘
                }
                else if (obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Corner_Bottom_Left;     // └
                }
                else
                {
                    newChunkType = x2m.ManorChunkType.Chunk_One_End_Down;       // ↓
                }
            }
            else if (obj_below != null)
            {
                if (obj_left != null && obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_T_Corner_Bottom;  // ┬
                }
                else if (obj_left != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Corner_Top_Right;   // ┐
                }
                else if (obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Corner_Top_Left;     // ┌
                }
                else
                {
                    newChunkType = x2m.ManorChunkType.Chunk_One_End_Up;       // ↑
                }
            }
            else
            {
                if (obj_left != null && obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Line_Horz;  // ─
                }
                else if (obj_left != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_One_End_Right;   // →
                }
                else if (obj_right != null)
                {
                    newChunkType = x2m.ManorChunkType.Chunk_One_End_Left;     // ←
                }
                else
                {
                    newChunkType = x2m.ManorChunkType.Chunk_Both_Ends_Horz;       // ┅
                }

            }

            if (newChunkType != autoWallChunk.ChunkType)
            {
                if (!needUpdateModelChunks.ContainsKey(autoWallChunk))
                {
                    needUpdateModelChunks[autoWallChunk] = autoWallChunk.ChunkType;
                }

                autoWallChunk.ChunkType = newChunkType;

                if (obj_above != null)
                {
                    UpdateAutoWallChunk(obj_above, needUpdateModelChunks);
                }
                if (obj_below != null)
                {
                    UpdateAutoWallChunk(obj_below, needUpdateModelChunks);
                }
                if (obj_left != null)
                {
                    UpdateAutoWallChunk(obj_left, needUpdateModelChunks);
                }
                if (obj_right != null)
                {
                    UpdateAutoWallChunk(obj_right, needUpdateModelChunks);
                }
            }
        }
        
    }
}
#endif