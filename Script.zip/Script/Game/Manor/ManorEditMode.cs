﻿using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;

#if ENABLE_MANOR
namespace Bokura
{
    public class ManorEditModeBase<HOST, StateIDs> : State<HOST, StateIDs> where HOST : ManorDesigner
    {
        public const int MESSAGE_PUTTING_OBJECT_CHANGED = 1000010;
        public const int MEAAAGE_ROTATE_OBJECT = 1000011;

        public ManorEditModeBase(StateIDs _id, HOST host) : base(_id, host)
        {

        }
        public virtual void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {
            
        }
        public virtual void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            
        }
        public virtual void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            
        }
        public virtual void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public virtual void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
    }

    public class ManorEditModeSelection<T> : ManorEditModeBase<T, ManorDesigner.ManorEditMode> where T : ManorDesigner
    {
        enum SelectionState
        {
            InBrowsing,
            InViewRotating,
            InMoving,
        }

        SelectionState m_SelectionState;

        Timer m_PressTimer;
        
        void SaveSelectionsState()
        {
            m_saveObjectCell.Clear();
            m_saveObjectDir.Clear();
            for (int i = 0; i < this.Host.SelectionCount; ++i)
            {
                ManorObject obj = this.Host.GetSelection(i);
                m_saveObjectCell.Add(obj.GetCell());
                m_saveObjectDir.Add(obj.Direction);
            }
        }
        void RestoreSelectionsState()
        {
            for (int i = 0; i < this.Host.SelectionCount; ++i)
            {
                ManorObject obj = this.Host.GetSelection(i);

                var dir = m_saveObjectDir[i];
                obj.Direction = dir;

                ManorObject.Cell cell = m_saveObjectCell[i];
                obj.SetCell(cell);

                obj.ShowMaskHelperLine(Color.white);
            }
        }
        bool IsSelectionsCellValid()
        {
            bool valid = true;
            for (int i = 0; i < this.Host.SelectionCount; ++i)
            {
                var obj = this.Host.GetSelection(i);

                bool isCellValid = obj.IsCellValid();
                if (isCellValid)
                {
                    isCellValid = this.Host.ManorWorld.IsCellValid(obj.Layer, obj.GetCell(), true);
                }
                valid = valid && isCellValid;
            }
            return valid;
        }
        public ManorEditModeSelection(T host) : base(ManorDesigner.ManorEditMode.Selection, host)
		{
        }
        public override void OnEnter(State<T, ManorDesigner.ManorEditMode> prevState)
        {
            m_SelectionState = SelectionState.InBrowsing;
        }
        public override void OnLeave(State<T, ManorDesigner.ManorEditMode> nextState)
        {
            switch (m_SelectionState)
            {
                case SelectionState.InMoving:
                    {
                        
                    }
                    break;
            }
            
        }
        void StartSelection(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Ray ray = ManorBuildingCameraController.Instance.Camera.ScreenPointToRay(eventData.position);
            ManorObject obj = this.Host.ManorWorld.Pick(ray);
            if (obj != null)
            {
                if (!obj.Selected)
                {
                    if (this.Host.SelectionCount > 0)
                    {
                        m_isCellValid = IsSelectionsCellValid();
                        if (!m_isCellValid)
                        {
                            RestoreSelectionsState();
                        }
                    }

                    this.Host.DeselectAll();
                    this.Host.SelectObject(obj);

                    SaveSelectionsState();
                }
            }
            else
            {
                if (this.Host.SelectionCount > 0)
                {
                    m_isCellValid = IsSelectionsCellValid();
                    if (!m_isCellValid)
                    {
                        RestoreSelectionsState();
                    }
                }

                this.Host.DeselectAll();
            }
        }
        public override void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {
            m_isDragged = false;

            ManorBuildingCameraController.Instance.CaptureInput();

            m_PressTimer = GameApplication.Instance.GetTimerManager().AddTimer(() =>
            {
                m_SelectionState = SelectionState.InMoving;

                StartSelection(eventData);

            }, 0.2f, 1);
            
            
        }
        public override void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            switch (m_SelectionState)
            {
                case SelectionState.InBrowsing:
                    {
                        StartSelection(eventData);
                    }
                    break;
                case SelectionState.InMoving:
                    {
                        if (!m_isDragged)
                        {
                            m_SelectionState = SelectionState.InBrowsing;
                        }
                    }
                    break;
            }
            ManorBuildingCameraController.Instance.ReleaseInput();

            if (m_PressTimer.ID > 0)
            {
                m_PressTimer.Remove();
            }
        }
        Vector3 originPosition;
        Vector3 currPosition;

        bool m_isDragged;

        bool m_isCellValid;
        List<Vector3> m_saveObjectPoses = new List<Vector3>(16);
        List<ManorObject.Cell> m_saveObjectCell = new List<ManorObject.Cell>(16);
        List<x2m.ManorDirection> m_saveObjectDir = new List<x2m.ManorDirection>(16);
        public override void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            m_isDragged = true;

            switch (m_SelectionState)
            {
                case SelectionState.InBrowsing:
                    {
                        m_PressTimer.Remove();

                        m_SelectionState = SelectionState.InViewRotating;
                    }
                    break;
                case SelectionState.InMoving:
                    {
                        Vector3 hitpoint;
                        if (this.Host.SelectionCount > 0 && this.Host.MousePosition2World(eventData.position, out hitpoint))
                        {
                            originPosition = hitpoint;
                            currPosition = hitpoint;

                            m_isCellValid = IsSelectionsCellValid();
                            if (m_isCellValid)
                            {
                                SaveSelectionsState();
                            }

                            m_saveObjectPoses.Clear();
                            for (int i = 0; i < this.Host.SelectionCount; ++i)
                            {
                                ManorObject obj = this.Host.GetSelection(i);
                                m_saveObjectPoses.Add(obj.ObjectModel.transform.position);
                            }
                            
                        }
                    }
                    break;
            }
            
        }
        public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            switch (m_SelectionState)
            {
                case SelectionState.InViewRotating:
                    {
                        ManorBuildingCameraController.Instance.Rotate(Mathf.Clamp(eventData.delta.x * 0.1f, -1f, 1f), Mathf.Clamp(eventData.delta.y * 0.1f, -1f, 1f));
                    }
                    break;
                case SelectionState.InMoving:
                    {
                        Vector3 worldpos;
                        if (this.Host.SelectionCount > 0 && this.Host.MousePosition2World(eventData.position, out worldpos))
                        {
                            currPosition = worldpos;

                            m_isCellValid = true;
                            for (int i = 0; i < this.Host.SelectionCount; ++i)
                            {
                                ManorObject obj = this.Host.GetSelection(i);
                                Vector3 offset = currPosition - originPosition;
                                offset.y = 0;
                                Vector3 pos = m_saveObjectPoses[i] + offset;

                                int col, row;
                                if (this.Host.ManorWorld.World2Cell(pos, out col, out row))
                                {
                                    bool isCellValid = obj.SetCell(col, row);
                                    if (isCellValid)
                                    {
                                        isCellValid = this.Host.ManorWorld.IsCellValid(obj.Layer, obj.GetCell(), true);
                                    }
                                    Color maskHelperColor;
                                    if (isCellValid)
                                        maskHelperColor = Color.green;
                                    else
                                        maskHelperColor = Color.red;
                                    obj.ShowMaskHelperLine(maskHelperColor);

                                    m_isCellValid = m_isCellValid && isCellValid;
                                }
                            }
                        }
                    }
                    break;
            }
        
            
        }
        public override void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            switch (m_SelectionState)
            {
                case SelectionState.InViewRotating:
                    {
                        m_SelectionState = SelectionState.InBrowsing;
                    }
                    break;
                case SelectionState.InMoving:
                    {
                        if (m_isCellValid)
                        {
                            if (this.Host.SelectionCount > 0)
                            {
                                ManorCommandMoving.CommandArgsMoving args = new ManorCommandMoving.CommandArgsMoving()
                                {
                                    objectList = new List<ManorObject>(this.Host.SelectionCount),
                                    srcCellList = new List<ManorObject.Cell>(this.Host.SelectionCount),
                                    srcDirList = new List<x2m.ManorDirection>(this.Host.SelectionCount),
                                    destCellList = new List<ManorObject.Cell>(this.Host.SelectionCount),
                                    destDirList = new List<x2m.ManorDirection>(this.Host.SelectionCount),
                                };

                                for (int i = 0; i < this.Host.SelectionCount; ++i)
                                {
                                    ManorObject obj = this.Host.GetSelection(i);

                                    var srcCell = m_saveObjectCell[i];
                                    var destCell = obj.GetCell();

                                    if (srcCell.IsEqual(destCell))
                                    {
                                        continue;
                                    }

                                    args.objectList.Add(obj);

                                    args.srcCellList.Add(srcCell);
                                    args.destCellList.Add(destCell);

                                    args.srcDirList.Add(m_saveObjectDir[i]);
                                    args.destDirList.Add(obj.Direction);

                                    obj.ShowMaskHelperLine(Color.white);
                                }
                                if (args.objectList.Count > 0)
                                {
                                    this.Host.ManorCommandHistory.ExecuteCommandMoving(args);
                                }
                            }

                            SaveSelectionsState();
                        }
                        else
                        {
                            RestoreSelectionsState();
                        }

                        m_SelectionState = SelectionState.InBrowsing;
                    }
                    break;
            }
        }
        public override void SendMessage(int msgid, object param)
        {
            switch (msgid)
            {
                case ManorEditModeBase<T, ManorDesigner.ManorEditMode>.MEAAAGE_ROTATE_OBJECT:
                    {
                        if (this.Host.SelectionCount > 0)
                        {
                            m_isCellValid = true;
                            for (int i = 0; i < this.Host.SelectionCount; ++i)
                            {
                                var obj = this.Host.GetSelection(i);
                                
                                obj.Rotate();

                                bool isCellValid = obj.IsCellValid();
                                if (isCellValid)
                                {
                                    isCellValid = this.Host.ManorWorld.IsCellValid(obj.Layer, obj.GetCell(), true);
                                }
                                Color maskHelperColor;
                                if (isCellValid)
                                    maskHelperColor = Color.green;
                                else
                                    maskHelperColor = Color.red;
                                obj.ShowMaskHelperLine(maskHelperColor);
                                m_isCellValid = m_isCellValid && isCellValid;
                            }

                            if (m_isCellValid)
                            {
                                if (this.Host.SelectionCount > 0)
                                {
                                    ManorCommandMoving.CommandArgsMoving args = new ManorCommandMoving.CommandArgsMoving()
                                    {
                                        objectList = new List<ManorObject>(this.Host.SelectionCount),
                                        srcCellList = new List<ManorObject.Cell>(this.Host.SelectionCount),
                                        srcDirList = new List<x2m.ManorDirection>(this.Host.SelectionCount),
                                        destCellList = new List<ManorObject.Cell>(this.Host.SelectionCount),
                                        destDirList = new List<x2m.ManorDirection>(this.Host.SelectionCount),
                                    };

                                    for (int i = 0; i < this.Host.SelectionCount; ++i)
                                    {
                                        ManorObject obj = this.Host.GetSelection(i);

                                        args.objectList.Add(obj);
                                        var srcCell = m_saveObjectCell[i];
                                        var destCell = obj.GetCell();

                                        if (srcCell.IsEqual(destCell))
                                        {
                                            continue;
                                        }

                                        args.srcCellList.Add(srcCell);
                                        args.destCellList.Add(destCell);

                                        args.srcDirList.Add(m_saveObjectDir[i]);
                                        args.destDirList.Add(obj.Direction);

                                    }
                                    if (args.objectList.Count > 0)
                                    {
                                        this.Host.ManorCommandHistory.ExecuteCommandMoving(args);
                                    }
                                }

                                SaveSelectionsState();
                            }
                        }
                    }
                    break;
            }
        }
    }
    public class ManorEditModePuttingBase<T> : ManorEditModeBase<T, ManorDesigner.ManorEditMode> where T : ManorDesigner
    {
        public ManorEditModePuttingBase(ManorDesigner.ManorEditMode _id, T host) : base(_id, host)
        {
        }
    }
    public class ManorEditModePutBuilding<T> : ManorEditModePuttingBase<T> where T : ManorDesigner
    {
        private bool m_isCellValid;
        List<ManorObject> saveSelectionList;
        public ManorEditModePutBuilding(T host) : base(ManorDesigner.ManorEditMode.PutBuilding, host)
        {
        }
        public override void OnEnter(State<T, ManorDesigner.ManorEditMode> prevState)
        {
            saveSelectionList = new List<ManorObject>(this.Host.SelectionList);

            this.Host.DeselectAll();
            this.Host.PuttingObject.LoadModel(false);
            this.Host.PuttingObject.IgnoreCollisionWithMainChar = true;
        }
        public override void OnLeave(State<T, ManorDesigner.ManorEditMode> nextState)
        {
            if (!m_isCellValid)
            {
                this.Host.PuttingObject.Destroy();

                this.Host.DeselectAll();
                for (int i = 0; i < saveSelectionList.Count; ++i)
                {
                    this.Host.SelectObject(saveSelectionList[i]);
                }
            }
        }
        public override void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Vector3 hitpoint;
            if (this.Host.MousePosition2World(eventData.position, out hitpoint))
            {
                int col;
                int row;
                if (this.Host.ManorWorld.World2Cell(hitpoint, out col, out row))
                {
                    m_isCellValid = this.Host.PuttingObject.SetCell(col, row);
                    if (m_isCellValid)
                    {
                        m_isCellValid = this.Host.ManorWorld.IsCellValid(this.Host.PuttingObject.Layer, this.Host.PuttingObject.GetCell());
                    }
                    Color maskHelperColor;
                    if (m_isCellValid)
                        maskHelperColor = Color.green;
                    else
                        maskHelperColor = Color.red;
                    this.Host.PuttingObject.ShowMaskHelperLine(maskHelperColor);
                }
            }
        }
        public override void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            if (m_isCellValid)
            {
                this.Host.PuttingObject.HideMaskHelperLine();

                var args = new ManorCommandPutObject.CommandArgsPutObject()
                {
                    obj = this.Host.PuttingObject,
                    saveSelections = saveSelectionList,
                };
                this.Host.ManorCommandHistory.ExecuteCommandPutObject(args);

                this.Host.EditMode = ManorDesigner.ManorEditMode.Selection;
                
                this.Host.PuttingObject = null;
            }
            else
            {
                this.Host.EditMode = ManorDesigner.ManorEditMode.Selection;
            }
        }
        public override void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            ManorBuildingCameraController.Instance.LockRotation = false;
        }
        public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Vector3 hitpoint;
            if (this.Host.MousePosition2World(eventData.position, out hitpoint))
            {
                int col;
                int row;
                if (this.Host.ManorWorld.World2Cell(hitpoint, out col, out row))
                {
                    m_isCellValid = this.Host.PuttingObject.SetCell(col, row);
                    if (m_isCellValid)
                    {
                        m_isCellValid = this.Host.ManorWorld.IsCellValid(ManorObject.LayerType.Object, this.Host.PuttingObject.GetCell());
                    }
                    Color maskHelperColor;
                    if (m_isCellValid)
                        maskHelperColor = Color.white;
                    else
                        maskHelperColor = Color.red;
                    this.Host.PuttingObject.ShowMaskHelperLine(maskHelperColor);
                }
            }
        }
        public override void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            ManorBuildingCameraController.Instance.LockRotation = true;
        }
        public override void SendMessage(int msgid, object param)
        {
            switch (msgid)
            {
                case ManorEditModeBase<T, ManorDesigner.ManorEditMode>.MESSAGE_PUTTING_OBJECT_CHANGED:
                    {
                        this.Host.PuttingObject.LoadModel(false);
                    }
                    break;
            }
        }
    }
    public class ManorEditModePutFloorObject<T> : ManorEditModePuttingBase<T> where T : ManorDesigner
    {
        List<ManorObject> saveSelectionList;

        Vector2Int m_TopLeftCell;
        Vector2Int m_BottomRightCell;

        List<ManorObject.Cell> m_ObjectCells;

        List<ManorObject.MaskHelperLine> m_MaskHelperLines;

        public ManorEditModePutFloorObject(T host) : base(ManorDesigner.ManorEditMode.PutFloorObject, host)
        {
        }
        public override void OnEnter(State<T, ManorDesigner.ManorEditMode> prevState)
        {
            saveSelectionList = new List<ManorObject>(this.Host.SelectionList);

            this.Host.DeselectAll();
            this.Host.PuttingObject.LoadModel(false);

            m_ObjectCells = new List<ManorObject.Cell>(16);

            m_MaskHelperLines = new List<ManorObject.MaskHelperLine>(16);
        }
        public override void OnLeave(State<T, ManorDesigner.ManorEditMode> nextState)
        {

        }
        void UpdateMaskCells()
        {
            int x1 = m_TopLeftCell.x;
            int y1 = m_TopLeftCell.y;
            int x2 = m_BottomRightCell.x;
            int y2 = m_BottomRightCell.y;
            if (x2 < x1)
            {
                x1 = m_TopLeftCell.x + this.Host.PuttingObject.ObjectMask.mask_w - 1;
            }
            if (y2 < y1)
            {
                y1 = m_TopLeftCell.y + this.Host.PuttingObject.ObjectMask.mask_h - 1;
            }
            int mincol = Math.Min(x1, x2);
            int minrow = Math.Min(y1, y2);
            int maxcol = Math.Max(x1, x2);
            int maxrow = Math.Max(y1, y2);

            int col_step = m_TopLeftCell.x > m_BottomRightCell.x ? -1 : 1;
            int row_step = m_TopLeftCell.y > m_BottomRightCell.y ? -1 : 1;

            int cols = maxcol - mincol + 1;
            int rows = maxrow - minrow + 1;
            int obj_cols = Math.Max(1, cols / this.Host.PuttingObject.ObjectMask.mask_w);
            int obj_rows = Math.Max(1, rows / this.Host.PuttingObject.ObjectMask.mask_h);
            int obj_count = obj_cols * obj_rows;

            if (m_MaskHelperLines.Count > obj_count)
            {
                for (int i = obj_count; i < m_MaskHelperLines.Count; ++i)
                {
                    m_MaskHelperLines[i].Destroy();
                }
                m_MaskHelperLines.RemoveRange(obj_count, m_MaskHelperLines.Count - obj_count);
            }
            else if (m_MaskHelperLines.Count < obj_count)
            {
                while (m_MaskHelperLines.Count < obj_count)
                {
                    m_MaskHelperLines.Add(new ManorObject.MaskHelperLine(this.Host.ManorWorld));
                }
            }

            m_ObjectCells.Clear();
            for (int i = 0; i < m_MaskHelperLines.Count; ++i)
            {
                m_ObjectCells.Add(new ManorObject.Cell());
            }

            for (int i = 0; i < obj_count; ++i)
            {
                var maskHelperLine = m_MaskHelperLines[i];

                int col = i % obj_cols;
                int row = i / obj_cols;

                int left = m_TopLeftCell.x + col_step * (col * this.Host.PuttingObject.ObjectMask.mask_w);
                int top = m_TopLeftCell.y + row_step * (row * this.Host.PuttingObject.ObjectMask.mask_h);
                ManorObject.Cell cell = new ManorObject.Cell(left, top, this.Host.PuttingObject.ObjectMask.mask_w, this.Host.PuttingObject.ObjectMask.mask_h, false);

                Color color;
                if (this.Host.ManorWorld.IsCellValid(ManorObject.LayerType.Floor, cell))
                    color = Color.green;
                else
                    color = Color.red;
                maskHelperLine.Init(cell, color);

                m_ObjectCells[i] = cell;
            }
        }
        public override void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Vector3 hitpoint;
            if (this.Host.MousePosition2World(eventData.position, out hitpoint))
            {
                int col;
                int row;
                if (this.Host.ManorWorld.World2Cell(hitpoint, out col, out row))
                {
                    m_TopLeftCell = new Vector2Int(col, row);
                    m_BottomRightCell = new Vector2Int(col, row);

                    UpdateMaskCells();
                }
            }
        }
        public override void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            for (int i = m_ObjectCells.Count - 1; i >= 0; --i)
            {
                var cell = m_ObjectCells[i];
                if (this.Host.ManorWorld.IsCellValid(ManorObject.LayerType.Floor, cell))
                {
                    
                }
                else
                {
                    m_ObjectCells.RemoveAt(i);
                }
            }
            if (m_ObjectCells.Count > 0)
            {
                ManorCommandPutMultiObjects.CommandArgsPutMultiObjects args = new ManorCommandPutMultiObjects.CommandArgsPutMultiObjects()
                {
                    obj = this.Host.PuttingObject,
                    cells = m_ObjectCells,
                    saveSelections = saveSelectionList,
                };
                this.Host.ManorCommandHistory.ExecuteCommandPutMultiObjects(args);
            }

            for (int i = 0; i < m_MaskHelperLines.Count; ++i)
            {
                m_MaskHelperLines[i].Destroy();
            }
            m_MaskHelperLines.Clear();
            m_ObjectCells.Clear();
            this.Host.EditMode = ManorDesigner.ManorEditMode.Selection;

            this.Host.PuttingObject.Destroy();
            this.Host.PuttingObject = null;
        }
        public override void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Vector3 hitpoint;
            if (this.Host.MousePosition2World(eventData.position, out hitpoint))
            {
                int col;
                int row;
                if (this.Host.ManorWorld.World2Cell(hitpoint, out col, out row))
                {
                    m_BottomRightCell = new Vector2Int(col, row);

                    UpdateMaskCells();
                }
            }
        }
        public override void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void SendMessage(int msgid, object param)
        {
            switch (msgid)
            {
                case ManorEditModeBase<T, ManorDesigner.ManorEditMode>.MESSAGE_PUTTING_OBJECT_CHANGED:
                    {
                        this.Host.PuttingObject.LoadModel(false);
                    }
                    break;
            }
        }
    }
    public class ManorEditModePutAutoWall<T> : ManorEditModeBase<T, ManorDesigner.ManorEditMode> where T : ManorDesigner
    {
        List<ManorObject> saveSelectionList;
        
        Vector2Int m_TopLeftCell;
        Vector2Int m_BottomRightCell;

        List<ManorObject.Cell> m_ObjectCells;

        List<ManorObject.MaskHelperLine> m_MaskHelperLines;

        public ManorEditModePutAutoWall(T host) : base(ManorDesigner.ManorEditMode.PutAutoWall, host)
        {
        }
        public override void OnEnter(State<T, ManorDesigner.ManorEditMode> prevState)
        {
            saveSelectionList = new List<ManorObject>(this.Host.SelectionList);

            this.Host.DeselectAll();

            m_ObjectCells = new List<ManorObject.Cell>(16);

            m_MaskHelperLines = new List<ManorObject.MaskHelperLine>(16);
        }
        public override void OnLeave(State<T, ManorDesigner.ManorEditMode> nextState)
        {

        }
        void UpdateMaskCells()
        {
            int x1 = m_TopLeftCell.x / this.Host.PuttingObject.ObjectMask.mask_w;
            int y1 = m_TopLeftCell.y / this.Host.PuttingObject.ObjectMask.mask_h;
            int x2 = m_BottomRightCell.x / this.Host.PuttingObject.ObjectMask.mask_w;
            int y2 = m_BottomRightCell.y / this.Host.PuttingObject.ObjectMask.mask_h;

            int mincol = Math.Min(x1, x2);
            int minrow = Math.Min(y1, y2);
            int maxcol = Math.Max(x1, x2);
            int maxrow = Math.Max(y1, y2);
            
            int chunk_sizew = this.Host.PuttingObject.ObjectMask.mask_w;
            int chunk_sizeh = this.Host.PuttingObject.ObjectMask.mask_h;

            int cols = maxcol - mincol + 1;
            int rows = maxrow - minrow + 1;

            int obj_count = cols + rows - 1;

            if (m_MaskHelperLines.Count > obj_count)
            {
                for (int i = obj_count; i < m_MaskHelperLines.Count; ++i)
                {
                    m_MaskHelperLines[i].Destroy();
                }
                m_MaskHelperLines.RemoveRange(obj_count, m_MaskHelperLines.Count - obj_count);
            }
            else if (m_MaskHelperLines.Count < obj_count)
            {
                while (m_MaskHelperLines.Count < obj_count)
                {
                    m_MaskHelperLines.Add(new ManorObject.MaskHelperLine(this.Host.ManorWorld));
                }
            }

            m_ObjectCells.Clear();
            for (int i = 0;i < m_MaskHelperLines.Count; ++i)
            {
                m_ObjectCells.Add(new ManorObject.Cell());
            }

            int col_step = m_TopLeftCell.x > m_BottomRightCell.x ? -1 : 1;
            int row_step = m_TopLeftCell.y > m_BottomRightCell.y ? -1 : 1;
            
            for (int i = 0; i < cols; ++i)
            {
                int chunk_col = x1 + col_step * i;
                int chunk_row = y1;
             
                ManorObject.Cell cell = new ManorObject.Cell(chunk_col * chunk_sizew, chunk_row * chunk_sizeh, chunk_sizew, chunk_sizeh, false);
                
                Color color;
                if (this.Host.ManorWorld.IsCellValid(ManorObject.LayerType.Object, cell))
                    color = Color.green;
                else
                    color = Color.red;

                var maskHelperLine = m_MaskHelperLines[i];
                maskHelperLine.Init(cell, color);

                m_ObjectCells[i] = cell;
            }

            for (int i = 1; i < rows; ++i)
            {
                int chunk_col = x2;
                int chunk_row = y1 + row_step * i;
                
                ManorObject.Cell cell = new ManorObject.Cell(chunk_col * chunk_sizew, chunk_row * chunk_sizeh, chunk_sizew, chunk_sizeh, false);

                Color color;
                if (this.Host.ManorWorld.IsCellValid(ManorObject.LayerType.Object, cell))
                    color = Color.green;
                else
                    color = Color.red;

                var maskHelperLine = m_MaskHelperLines[i - 1 + cols];
                maskHelperLine.Init(cell, color);

                m_ObjectCells[i - 1 + cols] = cell;
            }
        }
        public override void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Vector3 hitpoint;
            if (this.Host.MousePosition2World(eventData.position, out hitpoint))
            {
                int col;
                int row;
                if (this.Host.ManorWorld.World2Cell(hitpoint, out col, out row))
                {
                    m_TopLeftCell = new Vector2Int(col, row);
                    m_BottomRightCell = new Vector2Int(col, row);

                    UpdateMaskCells();
                }
            }
        }
        public override void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            //             int chunk_sizew = this.Host.PuttingObject.ObjectMask.mask_w;
            //             int chunk_sizeh = this.Host.PuttingObject.ObjectMask.mask_h;
            // 
            //             int create_counter = 0;
            // 
            //             var needUpdateModelChunks = new Dictionary<ManorAutoWallChunk, ManorAutoWallChunk.TChunkType>(m_ObjectCells.Count);
            // 
            //             List<ManorAutoWallChunk> newAutoWallChunks = new List<ManorAutoWallChunk>(m_ObjectCells.Count);

            /*
                        for (int i = 0; i < m_ObjectCells.Count; ++i)
                        {
                            var cell = m_ObjectCells[i];
                            if (this.Host.ManorWorld.IsCellValid(this.Host.PuttingObject.Layer, cell))
                            {
                                ++create_counter;
                                if (create_counter > 0)
                                {
                                    this.Host.PuttingObject = this.Host.CreateObjectByID(this.Host.PuttingObjectID);
                                }

                                ManorAutoWallChunk autoWallChunk = this.Host.PuttingObject as ManorAutoWallChunk;

                                this.Host.PuttingObject.SetCell(cell);

                                newAutoWallChunks.Add(autoWallChunk);
                            }
                        }*/
            /*

                        for (int i = 0; i < newAutoWallChunks.Count; ++i)
                        {
                            ManorAutoWallChunk autoWallChunk = newAutoWallChunks[i];

                            var cell = autoWallChunk.GetCell();

                            int chunk_col = cell.left / chunk_sizew;
                            int chunk_row = cell.top / chunk_sizeh;
                            this.Host.UpdateAutoWallChunk(autoWallChunk, chunk_col, chunk_row, needUpdateModelChunks);
                        }

                        List<ManorAutoWallChunk.TChunkType> oldAutoWallChunkTypes = new List<ManorAutoWallChunk.TChunkType>(needUpdateModelChunks.Count);
                        List<ManorAutoWallChunk.TChunkType> newAutoWallChunkTypes = new List<ManorAutoWallChunk.TChunkType>(needUpdateModelChunks.Count);
                        List<ManorAutoWallChunk> updateAutoWallChunks = new List<ManorAutoWallChunk>(needUpdateModelChunks.Count);

                        var iter = needUpdateModelChunks.GetEnumerator();
                        while (iter.MoveNext())
                        {
                            var autoWallChunk = iter.Current.Key;
                            var oldChunkType = iter.Current.Value;

                            autoWallChunk.DestroyModel();
                            autoWallChunk.LoadModel(true);

                            if (newAutoWallChunks.IndexOf(autoWallChunk) == -1)
                            {
                                oldAutoWallChunkTypes.Add(oldChunkType);
                                newAutoWallChunkTypes.Add(autoWallChunk.ChunkType);
                                updateAutoWallChunks.Add(autoWallChunk);
                            }
                        }
            */

            for (int i = m_ObjectCells.Count - 1; i >= 0; --i)
            {
                var cell = m_ObjectCells[i];
                if (this.Host.ManorWorld.IsCellValid(this.Host.PuttingObject.Layer, cell))
                {
                    
                }
                else
                {
                    m_ObjectCells.RemoveAt(i);
                }
            }

            if (m_ObjectCells.Count > 0)
            {
                ManorCommandPutAutoWall.CommandArgsPutAutoWall args = new ManorCommandPutAutoWall.CommandArgsPutAutoWall()
                {
                    obj = this.Host.PuttingObject,
                    saveSelections = saveSelectionList,
                    cells = m_ObjectCells,
                };
                this.Host.ManorCommandHistory.ExecuteCommandPutAutoWall(args);
            }
            /*
            int chunk_sizew = this.Host.PuttingObject.ObjectMask.mask_w;
            int chunk_sizeh = this.Host.PuttingObject.ObjectMask.mask_h;

            int create_counter = 0;

            var needUpdateModelChunks = new Dictionary<ManorAutoWallChunk, ManorAutoWallChunk.TChunkType>(m_ObjectCells.Count);

            List<ManorAutoWallChunk> newAutoWallChunks = new List<ManorAutoWallChunk>(m_ObjectCells.Count);

            for (int i = 0; i < m_ObjectCells.Count; ++i)
            {
                var cell = m_ObjectCells[i];
                if (this.Host.ManorWorld.IsCellValid(this.Host.PuttingObject.Layer, cell))
                {
                    ++create_counter;
                    if (create_counter > 0)
                    {
                        this.Host.PuttingObject = this.Host.CreateObjectByID(this.Host.PuttingObjectID);
                    }

                    this.Host.ManorWorld.AddObject(this.Host.PuttingObject);

                    ManorAutoWallChunk autoWallChunk = this.Host.PuttingObject as ManorAutoWallChunk;

                    this.Host.PuttingObject.SetCell(cell);

                    newAutoWallChunks.Add(autoWallChunk);
                }
            }

            for (int i = 0; i < newAutoWallChunks.Count; ++i)
            {
                ManorAutoWallChunk autoWallChunk = newAutoWallChunks[i];

                var cell = autoWallChunk.GetCell();

                int chunk_col = cell.left / chunk_sizew;
                int chunk_row = cell.top / chunk_sizeh;
                this.Host.UpdateAutoWallChunk(autoWallChunk, chunk_col, chunk_row, needUpdateModelChunks);
            }

            var iter = needUpdateModelChunks.GetEnumerator();
            while (iter.MoveNext())
            {
                var autoWallChunk = iter.Current.Key;
                var oldChunkType = iter.Current.Value;
                
                autoWallChunk.DestroyModel();
                autoWallChunk.LoadModel(true);
            }
            */

            for (int i = 0; i < m_MaskHelperLines.Count; ++i)
            {
                m_MaskHelperLines[i].Destroy();
            }
            m_MaskHelperLines.Clear();
            m_ObjectCells.Clear();

            this.Host.EditMode = ManorDesigner.ManorEditMode.Selection;

            this.Host.PuttingObject.Destroy();
            this.Host.PuttingObject = null;
        }
        public override void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            Vector3 hitpoint;
            if (this.Host.MousePosition2World(eventData.position, out hitpoint))
            {
                int col;
                int row;
                if (this.Host.ManorWorld.World2Cell(hitpoint, out col, out row))
                {
                    m_BottomRightCell = new Vector2Int(col, row);

                    UpdateMaskCells();
                }
            }
        }
        public override void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
    }
    public class ManorEditModePutWater<T> : ManorEditModeBase<T, ManorDesigner.ManorEditMode> where T : ManorDesigner
    {
        public ManorEditModePutWater(T host) : base(ManorDesigner.ManorEditMode.PutWater, host)
        {
        }
        public override void OnEnter(State<T, ManorDesigner.ManorEditMode> prevState)
        {

        }
        public override void OnLeave(State<T, ManorDesigner.ManorEditMode> nextState)
        {

        }
        public override void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
    }
    public class ManorEditModeRemoveWater<T> : ManorEditModeBase<T, ManorDesigner.ManorEditMode> where T : ManorDesigner
    {
        public ManorEditModeRemoveWater(T host) : base(ManorDesigner.ManorEditMode.RemoveWater, host)
        {
        }
        public override void OnEnter(State<T, ManorDesigner.ManorEditMode> prevState)
        {

        }
        public override void OnLeave(State<T, ManorDesigner.ManorEditMode> nextState)
        {

        }
        public override void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
        public override void OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {

        }
    }
    public class ManorEditModeMachine<HOST, StateIDs> : StateMachine<HOST, StateIDs> where HOST : ManorDesigner
    {
        public ManorEditModeMachine(HOST _host, IEqualityComparer<StateIDs> cmp) : base(_host, cmp)
        {
            
        }

        public void AddState(ManorEditModeBase<HOST, StateIDs> state)
        {
            base.AddState(state);
        }

        public new ManorEditModeBase<HOST, StateIDs> GetState(StateIDs id) 
        {
            State<HOST, StateIDs> state = base.GetState(id);
            return state as ManorEditModeBase<HOST, StateIDs>;
        }
        public ManorEditModeBase<HOST, StateIDs> CurState
        {
            get
            {
                return m_curState as ManorEditModeBase<HOST, StateIDs>;
            }
        }
    }
    public class ManorEditModeFactory
    {
        class StateIDEqual : IEqualityComparer<ManorDesigner.ManorEditMode>
        {
            public bool Equals(ManorDesigner.ManorEditMode x, ManorDesigner.ManorEditMode y)
            {
                return x == y;
            }
            public int GetHashCode(ManorDesigner.ManorEditMode obj)
            {
                return (int)obj;
            }
        }
        static StateIDEqual compare = new StateIDEqual();
        public static ManorEditModeMachine<ManorDesigner, ManorDesigner.ManorEditMode> CreateSM(ManorDesigner designer)
        {
            var sm = new ManorEditModeMachine<ManorDesigner, ManorDesigner.ManorEditMode>(designer, compare);
            sm.AddState(new ManorEditModeSelection<ManorDesigner>(designer));
            sm.AddState(new ManorEditModePutBuilding<ManorDesigner>(designer));
            sm.AddState(new ManorEditModePutFloorObject<ManorDesigner>(designer));
            sm.AddState(new ManorEditModePutAutoWall<ManorDesigner>(designer));
            sm.AddState(new ManorEditModePutWater<ManorDesigner>(designer));
            sm.AddState(new ManorEditModeRemoveWater<ManorDesigner>(designer));

            sm.ChangeState(ManorDesigner.ManorEditMode.Selection);

            return sm;
        }
    }
}
#endif