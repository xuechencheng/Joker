﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

#if ENABLE_MANOR
namespace Bokura
{
    public class ManorJoystick : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
    {

        public void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        {
            
        }

        public void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        {
            
        }

        public void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
        {
            
        }
    }
}
#endif