﻿using System.Collections.Generic;
using Bokura;
using UnityEngine;
using System.IO;
#if ENABLE_MANOR
namespace Bokura
{
    public class ManorModel : ClientSingleton<ManorModel>
    {
        const int MAXIMUM_WORLD_COUNT = 3;

        public enum ManorStateEnum
        {
            None = 0,
            Browsing,
            Building,
        }

        public class RefreshManorListEvent : GameEvent<List<ManorListMember>>
        {

        }
        public class CreateManorEvent : GameEvent<int, uint, string>
        {

        }
        public class RefreshManorInfoEvent : GameEvent
        {

        }
        
        public class RequestJoinManorEvent : GameEvent<bool>
        {

        }

        public class EnterManorScene : GameEvent
        {

        }

        public class ExitManorScene : GameEvent
        {

        }

        public class SaveManorFurniture : GameEvent<bool>
        {

        }

        public RefreshManorListEvent OnRefreshManorList = new RefreshManorListEvent();

        public CreateManorEvent OnCreateManor = new CreateManorEvent();
        
        public RefreshManorInfoEvent OnRefreshManorInfo = new RefreshManorInfoEvent();
        
        public RequestJoinManorEvent OnRequestJoinManor = new RequestJoinManorEvent();

        public EnterManorScene OnEnterManorScene = new EnterManorScene();

        public ExitManorScene OnExitManorScene = new ExitManorScene();

        public SaveManorFurniture OnSaveManorFurniture = new SaveManorFurniture();

        List<GameObject> m_goWorldList;
        List<ManorWorld> m_ManorWorldList;

        ManorDesigner m_ManorDesigner;

        bool m_isInManorScene;

        public bool IsInManorScene
        {
            get
            {
                return m_isInManorScene;
            }
        }

        ManorInfo m_ThisManorInfo;
        public ManorInfo ThisManorInfo
        {
            get
            {
                return m_ThisManorInfo;
            }
        }

        public ManorDesigner ManorDesigner
        {
            get
            {
                return m_ManorDesigner;
            }
        }

        ManorStateEnum m_ManorState;

        public ManorStateEnum ManorState
        {
            get
            {
                return m_ManorState;
            }
            set
            {
                if (m_ManorState != value)
                {
                    switch (m_ManorState)
                    {
                        case ManorStateEnum.Browsing:
                            ExitBrowsing();
                            break;
                        case ManorStateEnum.Building:
                            ExitBuilding();
                            break;
                    }
                    m_ManorState = value;
                    switch (m_ManorState)
                    {
                        case ManorStateEnum.Browsing:
                            EnterBrowsing();
                            break;
                        case ManorStateEnum.Building:
                            EnterBuilding();
                            break;
                    }
                }
            }
        }

        MainCharacterCollisionEvent m_collisionEvent;

        void EnterBuilding()
        {
            if (m_ThisManorInfo != null)
            {
                CameraController.Instance.IsUpdate = false;
                ManorBuildingCameraController.Instance.Enabled = true;
                GameScene.Instance.MainChar.CanControl = false;

                var world = m_ManorWorldList[m_ThisManorInfo.mainchar_index];

                m_ManorDesigner = new ManorDesigner();
                m_ManorDesigner.Init(world);

                m_collisionEvent = GameScene.Instance.MainChar.Avatar.unityObject.AddComponent<MainCharacterCollisionEvent>();
                m_collisionEvent.m_ManorWorld = world;

                world.CreateSnapshoot();
            }



        }
        void ExitBuilding()
        {
            if (m_ThisManorInfo != null)
            {
                UnityEngine.Object.Destroy(m_collisionEvent);

                ManorBuildingCameraController.Instance.Enabled = false;
                CameraController.Instance.IsUpdate = true;
                GameScene.Instance.MainChar.CanControl = true;

                m_ManorDesigner.Uninit();

                m_ManorDesigner.ManorWorld.RestoreSnapshoot();

                m_ManorDesigner = null;
            }
        }
        void EnterBrowsing()
        {

        }
        void ExitBrowsing()
        {

        }


        [XLua.BlackList]
        public void Init()
        {
            GameScene.Instance.onEndLoading.AddListener(ProcSceneEndLoading);

            MsgDispatcher.instance.RegisterFBMsgProc <swm.RspManorList> (ProcRspManorList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCreateManor>(ProcRspCreateManor);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCharManorData>(ProcRspCharManorData);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRequestJoinManor>(ProcRspRequestJoinManor);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspSaveManorFurniture>(ProcRspSaveManorFurniture);

            m_ManorState = ManorStateEnum.Browsing;
        }

        public void Clear()
        {
            m_goWorldList?.Clear();
            m_ManorWorldList?.Clear();
            m_isInManorScene = false;
            m_ManorDesigner = null;
            m_ThisManorInfo = null;
            m_ManorState = ManorStateEnum.Browsing;
        }

        public void Undo()
        {
            m_ManorDesigner.ManorCommandHistory.Undo();
        }

        public void Redo()
        {
            m_ManorDesigner.ManorCommandHistory.Redo();
        }
        public void DeleteSelections()
        {
            if (m_ManorDesigner.SelectionCount > 0)
            {
                ManorCommandDeleteObjects.CommandArgsDeleteObjects args = new ManorCommandDeleteObjects.CommandArgsDeleteObjects()
                {
                    objectList = m_ManorDesigner.SelectionList,
                };
                m_ManorDesigner.ManorCommandHistory.ExecuteCommandDeleteObjects(args);
            }
        }
        public void RotateSelections()
        {
            m_ManorDesigner.CurEditMode.SendMessage(ManorEditModeBase<ManorDesigner, ManorDesigner.ManorEditMode>.MEAAAGE_ROTATE_OBJECT, null);
        }

        public void SendReqManorList(uint manor_type)
        {
            // 请求庄园列表

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            
            swm.ReqManorList.StartReqManorList(fbb);
            swm.ReqManorList.AddManorType(fbb, manor_type);
            var msg = swm.ReqManorList.EndReqManorList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqManorList.HashID, fbb);
        }
        public void SendReqCreateManor(uint baseid, string name)
        {
            // 请求创建庄园

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            var offset = fbb.CreateString(name);

            swm.ReqCreateManor.StartReqCreateManor(fbb);
            swm.ReqCreateManor.AddBaseid(fbb, baseid);
            swm.ReqCreateManor.AddName(fbb, offset);
            var msg = swm.ReqCreateManor.EndReqCreateManor(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCreateManor.HashID, fbb);
            
            //MsgSendQueue.instance.EnqueueFb<swm.ReqCreateManor>(fbb.DataBuffer);
        }
        public void SendReqExitManor()
        {
            // 请求退出庄园

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            swm.ReqExitManor.StartReqExitManor(fbb);
            var msg = swm.ReqExitManor.EndReqExitManor(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqExitManor.HashID, fbb);
        }
        public void SendReqCharManorData(ulong charid)
        {
            // 请求庄园数据

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            
            swm.ReqCharManorData.StartReqCharManorData(fbb);
            swm.ReqCharManorData.AddCharid(fbb, charid);
            var msg = swm.ReqCharManorData.EndReqCharManorData(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCharManorData.HashID, fbb);
        }
        public void SendReqEnterManor(ulong charid)
        {
            // 请求进入庄园

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            
            swm.ReqEnterManor.StartReqEnterManor(fbb);
            swm.ReqEnterManor.AddCharid(fbb, charid);
            var msg = swm.ReqEnterManor.EndReqEnterManor(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEnterManor.HashID, fbb);
        }
        public void SendReqRequestJoinManor(uint baseid)
        {
            // 请求加入庄园

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            
            swm.ReqRequestJoinManor.StartReqRequestJoinManor(fbb);
            swm.ReqRequestJoinManor.AddManorid(fbb, baseid);
            var msg = swm.ReqRequestJoinManor.EndReqRequestJoinManor(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRequestJoinManor.HashID, fbb);

            //MsgSendQueue.instance.EnqueueFb<swm.ReqRequestJoinManor>(fbb.DataBuffer);
        }
        public void SendReqSaveManorFurniture(byte[] furniture)
        {
            if (furniture.Length > 10 * 1024)
            {
                LogHelper.LogErrorFormat("can not save manor furniture data, size = {0}", furniture.Length);
                return;
            }

            // 请求保存庄园家具数据

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();

            var offset = swm.ReqSaveManorFurniture.CreateFurnitureDataVector(fbb, furniture);

            swm.ReqSaveManorFurniture.StartReqSaveManorFurniture(fbb);
            swm.ReqSaveManorFurniture.AddFurnitureData(fbb, offset);
            var msg = swm.ReqSaveManorFurniture.EndReqSaveManorFurniture(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSaveManorFurniture.HashID, fbb);
        }
        void ProcSceneEndLoading()
        {
            if (!GameScene.Instance.CurrentIntomapInfo.HasValue)
            {
                return;
            }
            var config = MapInfoTableManager.GetData((int)GameScene.Instance.CurrentIntomapInfo.Value.map_baseid);
            if (config.maptype == 4)// 判断场景是否庄园
            {
                m_goWorldList = new List<GameObject>(MAXIMUM_WORLD_COUNT);
                m_ManorWorldList = new List<ManorWorld>(MAXIMUM_WORLD_COUNT);

                for (int i = 0; i < MAXIMUM_WORLD_COUNT; ++i)
                {
                    var goWorld = new GameObject();

                    var world = goWorld.AddComponent<ManorWorld>();
                    GameObject.DontDestroyOnLoad(goWorld);

                    GameObject cube = GameObject.Find(Utilities.BuildString("dummy_Cube", (i + 1).ToString()));
                    cube.layer = LayerMask.NameToLayer("Terrain");

                    MeshRenderer meshRenderer = cube.GetComponent<MeshRenderer>();
                    meshRenderer.enabled = false;

                    world.boxCollider = cube.GetComponent<BoxCollider>();

                    world.center = cube.transform.position + new Vector3(0, 0.5f, 0);

                    //string fileName = Utilities.BuildString(Application.persistentDataPath, "/manorworld.dat");
                    //if (File.Exists(fileName))
                    if (m_ThisManorInfo != null && m_ThisManorInfo.users[i] != null && m_ThisManorInfo.users[i].furniture_data.Length > 0)
                    {
                        using (MemoryStream stream = new MemoryStream(m_ThisManorInfo.users[i].furniture_data))
                        //using (FileStream fileStream = new FileStream(fileName, FileMode.Open))
                        {
                            if (!world.LoadFromStream(stream))
                            {
                                world.Init();
                            }
                        }
                    }
                    else
                    {
                        world.Init();
                    }

                    m_goWorldList.Add(goWorld);
                    m_ManorWorldList.Add(world);
                }

                m_isInManorScene = true;

                OnEnterManorScene.Invoke();
            }
            else
            {
                if (m_isInManorScene)
                {
                    m_isInManorScene = false;

                    if (m_ManorDesigner != null)
                    {
                        m_ManorDesigner.Uninit();
                        m_ManorDesigner = null;
                    }

                    for (int i = 0; i < MAXIMUM_WORLD_COUNT; ++i)
                    {
                        var goWorld = m_goWorldList[i];
                        var world = m_ManorWorldList[i];

                        if (goWorld != null)
                        {
                            if (world != null)
                            {
                                world.Uninit();
                            }

                            GameObject.Destroy(goWorld);
                        }
                    }
                    m_goWorldList.Clear();
                    m_ManorWorldList.Clear();

                    OnExitManorScene.Invoke();
                }
            }
        }
        public class ManorListUserInfo
        {
            public ulong charid;
            public string name;
            public string manor_name;
            public uint level;
            public swm.CareerType career;
            public swm.CareerSex sex;
            public byte[] furniture_data;
        }
        public class ManorListMember
        {
            public ulong id;
            public uint baseid;
            public string name;
            public List<ManorListUserInfo> users;
        }
        public class ManorInfo
        {
            public ulong id;
            public uint baseid;
            public string name;
            public uint create_time;
            public uint members_num;
            public uint level;
            public uint visit_num;
            public uint collect_num;

            public List<ManorListUserInfo> users;

            public ManorListUserInfo mainchar_user;
            public int mainchar_index;
        }
        void ProcRspManorList(swm.RspManorList msg)
        {
            List<ManorListMember> manorList = new List<ManorListMember>(msg.manorsLength);
            for (int i = 0; i < msg.manorsLength; ++i)
            {
                var simpledata = msg.manors(i);

                ManorListMember member = new ManorListMember();
                member.id = simpledata.Value.id;
                member.baseid = simpledata.Value.baseid;
                member.name = simpledata.Value.name;

                member.users = new List<ManorListUserInfo>(MAXIMUM_WORLD_COUNT);
                for (int j = 0; j < MAXIMUM_WORLD_COUNT; ++j)
                    member.users.Add(null);

                for (int j = 0; j < simpledata.Value.membersLength; ++j)
                {
                    var member_data = simpledata.Value.members(j);

                    var userinfo = new ManorListUserInfo();
                    userinfo.charid = member_data.Value.user_info.Value.charid;
                    userinfo.name = member_data.Value.user_info.Value.name;
                    userinfo.level = member_data.Value.user_info.Value.level;
                    userinfo.career = member_data.Value.user_info.Value.career;
                    userinfo.sex = member_data.Value.user_info.Value.sex;

                    member.users[(int)member_data.Value.index] = userinfo;
                }

                manorList.Add(member);
            }
            OnRefreshManorList.Invoke(manorList);
        }
        void ProcRspCreateManor(swm.RspCreateManor msg)
        {
            //var request = MsgSendQueue.instance.DequeueFb<swm.ReqCreateManor>();

            if (msg.ret_code == swm.ReqCreateManorRetCode.Ok)
            {
                GameScene.Instance.MainChar.ManorBaseID = msg.data.Value.base_data.Value.baseid ;// request.baseid;
            }

            OnCreateManor.Invoke((int)msg.ret_code, msg.data.Value.base_data.Value.baseid, msg.data.Value.base_data.Value.name);

            UpdateCharManorData(msg.data);
        }
        void UpdateCharManorData(swm.ManorAllData? data)
        {
            ManorInfo manorInfo = new ManorInfo();
            manorInfo.id = data.Value.base_data.Value.id;
            manorInfo.baseid = data.Value.base_data.Value.baseid;
            manorInfo.name = data.Value.base_data.Value.name;
            manorInfo.create_time = data.Value.base_data.Value.create_time;
            manorInfo.members_num = data.Value.base_data.Value.members_num;
            manorInfo.level = data.Value.base_data.Value.level;
            manorInfo.visit_num = data.Value.base_data.Value.visit_num;
            manorInfo.collect_num = data.Value.base_data.Value.collect_num;

            manorInfo.users = new List<ManorListUserInfo>(MAXIMUM_WORLD_COUNT);
            for (int i = 0; i < MAXIMUM_WORLD_COUNT; ++i)
                manorInfo.users.Add(null);

            for (int i = 0; i < data.Value.membersLength; ++i)
            {
                var memeber = data.Value.members(i);

                var userinfo = new ManorListUserInfo();
                userinfo.charid = memeber.Value.user_info.Value.charid;
                userinfo.name = memeber.Value.user_info.Value.name;
                userinfo.level = memeber.Value.user_info.Value.level;
                userinfo.career = memeber.Value.user_info.Value.career;
                userinfo.sex = memeber.Value.user_info.Value.sex;

                userinfo.manor_name = memeber.Value.name;

                userinfo.furniture_data = new byte[memeber.Value.furniture_dataLength];
                for (int j = 0; j < memeber.Value.furniture_dataLength; ++j)
                {
                    userinfo.furniture_data[j] = memeber.Value.furniture_data(j);
                }

                manorInfo.users[(int)memeber.Value.index] = userinfo;
                
                if (userinfo.charid == GameScene.Instance.MainChar.ThisID)
                {
                    manorInfo.mainchar_user = userinfo;
                    manorInfo.mainchar_index = (int)memeber.Value.index;
                }
            }

            m_ThisManorInfo = manorInfo;

            OnRefreshManorInfo.Invoke();
        }

        void ProcRspCharManorData(swm.RspCharManorData msg)
        {
            UpdateCharManorData(msg.data);
        }
        void ProcRspRequestJoinManor(swm.RspRequestJoinManor msg)
        {
            if (msg.result)
            {
                GameScene.Instance.MainChar.ManorBaseID = msg.data.Value.base_data.Value.baseid;
            }
            OnRequestJoinManor.Invoke(msg.result);

            UpdateCharManorData(msg.data);
        }
        void ProcRspSaveManorFurniture(swm.RspSaveManorFurniture msg)
        {
            OnSaveManorFurniture.Invoke(msg.result);
        }
        public void Save()
        {
            if (m_ManorDesigner != null)
            {
                using (MemoryStream stream = new MemoryStream())

                //string fileName = Utilities.BuildString(Application.persistentDataPath, "/manorworld.dat");
                //using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
                {
                    m_ManorDesigner.ManorWorld.SaveToStream(stream);
                    
                    SendReqSaveManorFurniture(stream.ToArray());
                }

                m_ManorDesigner.ManorWorld.CreateSnapshoot();
            }

        }
    }
}
#endif