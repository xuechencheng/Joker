﻿using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;
#if ENABLE_MANOR
namespace Bokura
{
    public abstract class ManorObject
    {
        public enum LayerType
        {
            Undefined = 0,
            Floor,
            Object,
        }
        public enum TagType
        {
            Undefined = 0,
            AddWater,   // 开掘水池
            RemoveWater,  // 填埋水池
            AutoWall,   // 自动墙
        }
        
        public struct Cell
        {
            public short left;
            public short top;
            public short right;
            public short bottom;

            bool m_Flip;

            public Cell(int left, int top, int width, int height, bool flip) 
            {
                this.left = (short)left;
                this.top = (short)top;
                this.right = (short)(left + width - 1);
                this.bottom = (short)(top + height - 1);
                this.m_Flip = flip;
            }

            public void Set(int left, int top, int width, int height, bool flip)
            {
                this.left = (short)left;
                this.top = (short)top;
                this.right = (short)(left + width - 1);
                this.bottom = (short)(top + height - 1);
                this.m_Flip = flip;
            }

            public int width
            {
                get
                {
                    return right - left + 1;
                }
                set
                {
                    right = (short)(left + value - 1);
                }
            }

            public int height
            {
                get
                {
                    return bottom - top + 1;
                }
                set
                {
                    bottom = (short)(top + value - 1);
                }
            }

            public void Offset(int ofx, int ofy)
            {
                left += (short)ofx;
                right += (short)ofx;
                top += (short)ofy;
                bottom += (short)ofy;
            }

            public int centerx
            {
                get
                {
                    return left + (right - left) / 2;
                }
                set
                {
                    int w = width;
                    left = (short)(value - w / 2);
                    width = w;
                }
            }

            public int centery
            {
                get
                {
                    return top + (bottom - top) / 2;
                }
                set
                {
                    int h = height;
                    top = (short)(value - h / 2);
                    height = h;
                }
            }
            public bool Flip
            {
                get
                {
                    return m_Flip;
                }
                set
                {
                    if (m_Flip != value)
                    {
                        int w = width;
                        int h = height;
                        right = (short)(left + h - 1);
                        bottom = (short)(top + w - 1);

                        m_Flip = value;
                    }
                }
            }

            public bool IsInRange(int l, int t, int w, int h)
            {
                if (left >= l && top >= t && right < l + w && bottom < t + h)
                {
                    return true;
                }
                return false;
            }

            public bool IsCrossed(Cell rhs)
            {
                if (left > rhs.right || rhs.left > right)
                {
                    return false;
                }
                if (top > rhs.bottom || rhs.top > bottom)
                {
                    return false;
                }
                return true;
            }

            public bool IsEqual(Cell rhs)
            {
                return (left == rhs.left) && (right == rhs.right) && (top == rhs.top) && (bottom == rhs.bottom) && (Flip == rhs.Flip);
            }
        }

        public class MaskHelperLine
        {
            GameObject goMaskHelperLine;
            LineRenderer lineRender;

            ManorWorld m_ManorWorld;
            Cell m_Cell;
            public void SetCell(Cell cell)
            {
                m_Cell = cell;

                Update();
            }
            public void SetColor(Color color)
            {
                if (lineRender != null)
                {
                    lineRender.startColor = color;
                    lineRender.endColor = color;
                }
            }
            public MaskHelperLine(ManorWorld world)
            {
                m_ManorWorld = world;
            }
            public void Init(Cell cell, Color color)
            {
                m_Cell = cell;

                if (goMaskHelperLine == null)
                {
                    goMaskHelperLine = new GameObject();
                    goMaskHelperLine.name = "MaskHelperLine";
                    lineRender = goMaskHelperLine.AddComponent<LineRenderer>();
                    var shader = ResourceHelper.LoadShaderSync("Shaders/Particles/", "Particle-Add") as Shader;
                    if (shader != null)
                    {
                        lineRender.sharedMaterial = new Material(shader);
                    }
                    lineRender.startWidth = 0.1f;
                    lineRender.endWidth = 0.1f;
                    lineRender.useWorldSpace = true;
                    lineRender.loop = true;
                    lineRender.positionCount = 4;
                }

                Update();

                SetColor(color);
            }
            public void Destroy()
            {
                if (goMaskHelperLine != null)
                {
                    GameObject.Destroy(goMaskHelperLine);
                    goMaskHelperLine = null;
                }
            }
            void Update()
            {
                Vector3 pos;
                m_ManorWorld.Cell2World(m_Cell.left, m_Cell.top, out pos);
                pos.y = m_ManorWorld.center.y + 0.1f;

                float sizeW = m_Cell.width * m_ManorWorld.CellWidth;
                float sizeH = m_Cell.height * m_ManorWorld.CellHeight;

                lineRender.SetPosition(0, pos);
                lineRender.SetPosition(1, pos + new Vector3(0, 0, sizeH));
                lineRender.SetPosition(2, pos + new Vector3(sizeW, 0, sizeH));
                lineRender.SetPosition(3, pos + new Vector3(sizeW, 0, 0));
            }
        }

        public LayerType Layer { get; private set; }
        public TagType Tag { get; private set; }
        public int ID;
        public int BaseID;
        public abstract x2m.ManorObjectType ObjectType
        {
            get;
        }
        public ManorObjMaskTableBase ObjectMask;
        public ManorObjectTableBase? ObjectInfo;
        public GameObject ObjectModel;
        protected Transform ObjectModelTransform;

        public virtual bool AllowRotate
        {
            get
            {
                return true;
            }
        }
        protected Cell m_Cell;

        protected bool isDestroyed;

        x2m.ManorDirection m_Direction;

        protected ManorWorld m_ManorWorld;

        List<Collider> m_ColliderList;

        bool m_Visible;

        bool m_Selected;

        MaskHelperLine m_MaskHelperLine;
        protected abstract ManorObject CreateNew();

        protected bool m_IgnoreCollisionWithMainChar;

        public bool IgnoreCollisionWithMainChar
        {
            get
            {
                return m_IgnoreCollisionWithMainChar;
            }
            set
            {
                m_IgnoreCollisionWithMainChar = value;

                if (ObjectModel != null)
                {
                    UpdateCollisionWithMainChar(m_IgnoreCollisionWithMainChar);
                }
            }
        }
        protected void UpdateCollisionWithMainChar(bool ignore)
        {
            for (int i = 0; i < m_ColliderList.Count; ++i)
            {
                Collider collider = m_ColliderList[i];
                Physics.IgnoreCollision(GameScene.Instance.MainChar.CC, collider, m_IgnoreCollisionWithMainChar);
            }
        }
        public ManorObject(ManorWorld world)
        {
            m_ManorWorld = world;
        }

        public bool Init(ManorObjectTableBase? config)
        {
            this.ID = m_ManorWorld.GenerateObjectID();
            this.BaseID = config.Value.id;

            ObjectMask = ManorObjMaskTableManager.GetData(config.Value.id);

            ObjectInfo = config;

            m_Cell.width = ObjectMask.mask_w;
            m_Cell.height = ObjectMask.mask_h;

            Layer = (LayerType)ObjectInfo.Value.layer;

            Tag = (TagType)ObjectInfo.Value.tag;

            m_Visible = true;

            m_ColliderList = new List<Collider>(2);
            
            m_Direction = x2m.ManorDirection.Down;

            return true;
        }
        public virtual void LoadFromObjectData(ManorWorld.ObjectData data)
        {
            this.ID = data.ID;
            this.BaseID = data.BaseID;

            var config = ManorObjectTableManager.GetData(data.BaseID);

            ObjectMask = ManorObjMaskTableManager.GetData(config.Value.id);

            ObjectInfo = config;

            Layer = (LayerType)ObjectInfo.Value.layer;

            Tag = (TagType)ObjectInfo.Value.tag;

            Direction = data.Direction;

            SetCell(data.cell);

            m_ColliderList = new List<Collider>(2);

            m_Visible = true;
        }
        public virtual bool CompareTo(ManorWorld.ObjectData data)
        {
            if (this.ID != data.ID ||
                this.BaseID != data.BaseID)
                return false;

            if (Direction != data.Direction)
                return false;

            if (! this.m_Cell.IsEqual(data.cell))
                return false;

            return true;
        }
        public virtual void SaveToObjectData(ManorWorld.ObjectData data)
        {
            data.ObjType = this.ObjectType;
            data.ID = (ushort)this.ID;
            data.BaseID = (ushort)this.BaseID;
            data.cell = this.m_Cell;
            data.Direction = this.Direction;
        }
        private static ManorWorld.ObjectData m_DataForCopy = new ManorWorld.ObjectData();
        public ManorObject Copy()
        {
            ManorObject obj = CreateNew();

            this.SaveToObjectData(m_DataForCopy);
            obj.LoadFromObjectData(m_DataForCopy);

            return obj;
        }
        protected void RecurveAllColliders(Transform parent)
        {
            try
            {
                Collider collider = parent.GetComponent<Collider>();
                if (collider != null)
                {
                    m_ColliderList.Add(collider);
                }
            }
            catch
            {
                LogHelper.LogErrorFormat("failed to get component collider, object={0}", parent.gameObject.name);
            }

            for (int i = 0; i < parent.childCount; ++i)
            {
                Transform child = parent.GetChild(i);

                RecurveAllColliders(child);
            }
        }
        public virtual void LoadModel(bool updateModel)
        {
            m_ManorWorld.LoadModel(IResourceLoader.strBuildingPath, ObjectInfo.Value.model, true, (UnityEngine.Object o) =>
            {
                if (isDestroyed)
                {
                    return;
                }

                DestroyModel();

                ObjectModel = GameObject.Instantiate(o) as GameObject;
                ObjectModelTransform = ObjectModel.transform;
                ObjectModelTransform.localScale = new Vector3((float)ObjectMask.scalex, (float)ObjectMask.scaley, (float)ObjectMask.scalez);

                RecurveAllColliders(ObjectModelTransform);

                if (m_IgnoreCollisionWithMainChar)
                {
                    UpdateCollisionWithMainChar(m_IgnoreCollisionWithMainChar);
                }

                if (updateModel)
                {
                    UpdateModelPosition();
                    UpdateModelRotation();
                }
            }
            );
        }
        public bool IsCrossed(Cell rhs)
        {
            return m_Cell.IsCrossed(rhs);
        }
        public bool IsCellEqual(Cell rhs)
        {
            return m_Cell.IsEqual(rhs);
        }
        public bool IsCellValid()
        {
            if (m_Cell.IsInRange(0, 0, m_ManorWorld.CellCols, m_ManorWorld.CellRows))
            {
                return true;
            }
            return false;
        }
        public Cell GetCell()
        {
            return m_Cell;
        }
        public bool SetCell(Cell cell, bool forceSetModelPos = true)
        {
            m_Cell.left = cell.left;
            m_Cell.top = cell.top;
            m_Cell.right = cell.right;
            m_Cell.bottom = cell.bottom;

            m_Cell.Flip = cell.Flip;

            bool bValid = IsCellValid();

            if (bValid || forceSetModelPos)
            {
                UpdateModelPosition();
            }

            if (m_MaskHelperLine != null)
            {
                m_MaskHelperLine.SetCell(m_Cell);
            }

            return bValid;
        }
        public bool SetCell(int col, int row, bool forceSetModelPos = true)
        {
            m_Cell.centerx = col;
            m_Cell.centery = row;

            bool bValid = IsCellValid();
            
            if (bValid || forceSetModelPos)
            {
                UpdateModelPosition();
            }

            if (m_MaskHelperLine != null)
            {
                m_MaskHelperLine.SetCell(m_Cell);
            }

            return bValid;
        }
        protected virtual void UpdateModelRotation()
        {
            if (ObjectModel == null)
            {
                return;
            }

            switch (m_Direction)
            {
                case x2m.ManorDirection.Down:
                    {
                        ObjectModelTransform.localRotation = Quaternion.identity;
                    }
                    break;
                case x2m.ManorDirection.Right:
                    {
                        ObjectModelTransform.localRotation = Quaternion.Euler(0, 90, 0);
                    }
                    break;
                case x2m.ManorDirection.Up:
                    {
                        ObjectModelTransform.localRotation = Quaternion.Euler(0, 180, 0);
                    }
                    break;
                case x2m.ManorDirection.Left:
                    {
                        ObjectModelTransform.localRotation = Quaternion.Euler(0, 270, 0);
                    }
                    break;
            }
        }
        protected void UpdateModelPosition()
        {
            if (ObjectModel == null)
            {
                return;
            }

            Vector3 pos;
            m_ManorWorld.Cell2World(m_Cell.left, m_Cell.top, out pos);
            pos.y = m_ManorWorld.center.y + 0.1f;

            float sizeW = m_Cell.width * m_ManorWorld.CellWidth;
            float sizeH = m_Cell.height * m_ManorWorld.CellHeight;

            ObjectModelTransform.position = new Vector3(pos.x + sizeW * 0.5f, pos.y, pos.z + sizeH * 0.5f);
            
        }
        public bool Visible
        {
            get
            {
                return m_Visible;
            }
            set
            {
                if (m_Visible != value)
                {
                    m_Visible = value;

                    ObjectModel.SetActive(m_Visible);
                }
            }
        }
        public void DestroyModel()
        {
            if (ObjectModel != null)
            {
                GameObject.Destroy(ObjectModel);
                ObjectModel = null;

                ObjectModelTransform = null;
            }
        }
        public void ReloadModel()
        {
            DestroyModel();
            isDestroyed = false;
            LoadModel(true);
        }
        public void Destroy()
        {
            isDestroyed = true;

            HideMaskHelperLine();

            DestroyModel();
        }
        public void ShowMaskHelperLine(Color color)
        {
            if (m_MaskHelperLine == null)
            {
                m_MaskHelperLine = new MaskHelperLine(m_ManorWorld);
                m_MaskHelperLine.Init(m_Cell, color);
            }

            m_MaskHelperLine.SetColor(color);
        }
        
        public void HideMaskHelperLine()
        {
            if (m_MaskHelperLine != null)
            {
                m_MaskHelperLine.Destroy();
                m_MaskHelperLine = null;
            }
        }
        public bool Selected
        {
            get
            {
                return m_Selected;
            }
            set
            {
                if (m_Selected != value)
                {
                    m_Selected = value;
                    if (m_Selected)
                        ShowMaskHelperLine(Color.white);
                    else
                        HideMaskHelperLine();
                }
            }
        }
        public bool IsColliderThisOne(Collider collider)
        {
            for (int i = 0; i < m_ColliderList.Count; ++i)
            {
                if (m_ColliderList[i] == collider)
                {
                    return true;
                }
            }
            return false;
        }
        public x2m.ManorDirection Direction
        {
            get
            {
                return m_Direction;
            }
            set
            {
                if (m_Direction != value)
                {
                    m_Direction = value;

                    switch (m_Direction)
                    {
                        case x2m.ManorDirection.Down:
                            {
                                m_Cell.Flip = false;
                            }
                            break;
                        case x2m.ManorDirection.Right:
                            {
                                m_Cell.Flip = true;
                            }
                            break;
                        case x2m.ManorDirection.Up:
                            {
                                m_Cell.Flip = false;
                            }
                            break;
                        case x2m.ManorDirection.Left:
                            {
                                m_Cell.Flip = true;
                            }
                            break;
                    }

                    UpdateModelRotation();
                    UpdateModelPosition();
                }
            }
        }
        public void Rotate()
        {
            switch (m_Direction)
            {
                case x2m.ManorDirection.Down:
                    {
                        Direction = x2m.ManorDirection.Right;
                    }
                    break;
                case x2m.ManorDirection.Right:
                    {
                        Direction = x2m.ManorDirection.Up;
                    }
                    break;
                case x2m.ManorDirection.Up:
                    {
                        Direction = x2m.ManorDirection.Left;
                    }
                    break;
                case x2m.ManorDirection.Left:
                    {
                        Direction = x2m.ManorDirection.Down;
                    }
                    break;
            }
        }
    }

    public class ManorBuilding : ManorObject
    {
        public ManorBuilding(ManorWorld world) : base(world)
        {

        }

        public override x2m.ManorObjectType ObjectType
        {
            get
            {
                return x2m.ManorObjectType.Building;
            }
        }
        protected override ManorObject CreateNew()
        {
            return new ManorBuilding(m_ManorWorld);
        }
    }

    public class ManorFloor : ManorObject
    {
        public ManorFloor(ManorWorld world) : base(world)
        {

        }

        public override x2m.ManorObjectType ObjectType
        {
            get
            {
                return x2m.ManorObjectType.Floor;
            }
        }
        protected override ManorObject CreateNew()
        {
            return new ManorFloor(m_ManorWorld);
        }
    }

    public class ManorAutoWallChunk : ManorObject
    {
        public ManorAutoWallChunk(ManorWorld world) : base(world)
        {

        }
        public override x2m.ManorObjectType ObjectType
        {
            get
            {
                return x2m.ManorObjectType.AutoWallChunk;
            }
        }
        x2m.ManorChunkType m_ChunkType;
        public x2m.ManorChunkType ChunkType
        {
            get
            {
                return m_ChunkType;
            }
            set
            {
                m_ChunkType = value;
            }
        }

        public int chunk_col
        {
            get
            {
                int chunk_sizew = ObjectMask.mask_w;
                return m_Cell.left / chunk_sizew;
            }
        }
        public int chunk_row
        {
            get
            {
                int chunk_sizeh = ObjectMask.mask_h;
                return m_Cell.top / chunk_sizeh;
            }
        }
        public override bool AllowRotate
        {
            get
            {
                return false;
            }
        }
        public override void LoadFromObjectData(ManorWorld.ObjectData data)
        {
            base.LoadFromObjectData(data);

            ChunkType = (x2m.ManorChunkType)data.ChunkType;
        }
        public override bool CompareTo(ManorWorld.ObjectData data)
        {
            if (!base.CompareTo(data))
                return false;

            if (ChunkType != data.ChunkType)
                return false;

            return true;
        }
        public override void SaveToObjectData(ManorWorld.ObjectData data)
        {
            base.SaveToObjectData(data);

            data.ChunkType = this.ChunkType;
        }
        protected override void UpdateModelRotation()
        {
            if (ObjectModel == null)
            {
                return;
            }

            int subid = (int)this.ChunkType;
            var subobj = ObjectMask.ManorSubObjectBySubID(subid);
            ObjectModelTransform.localRotation = Quaternion.Euler((float)subobj.rotatex, (float)subobj.rotatey, (float)subobj.rotatez);
        }
        public override void LoadModel(bool updateModel)
        {
            int subid = (int)this.ChunkType;
            var subobj = ObjectMask.ManorSubObjectBySubID(subid);

            m_ManorWorld.LoadModel(IResourceLoader.strBuildingPath, subobj.model, true, (UnityEngine.Object o) =>
            {
                if (isDestroyed)
                {
                    return;
                }

                DestroyModel();

                ObjectModel = GameObject.Instantiate(o) as GameObject;
                ObjectModelTransform = ObjectModel.transform;
                ObjectModelTransform.localScale = new Vector3((float)ObjectMask.scalex, (float)ObjectMask.scaley, (float)ObjectMask.scalez);

                RecurveAllColliders(ObjectModelTransform);

                if (m_IgnoreCollisionWithMainChar)
                {
                    UpdateCollisionWithMainChar(m_IgnoreCollisionWithMainChar);
                }

                if (updateModel)
                {
                    UpdateModelPosition();
                    UpdateModelRotation();
                }
            }
            );
        }
        protected override ManorObject CreateNew()
        {
            return new ManorAutoWallChunk(m_ManorWorld);
        }
    }

    public class MainCharacterCollisionEvent : MonoBehaviour
    {
        [HideInInspector]
        public ManorWorld m_ManorWorld;

        private void OnControllerColliderHit(ControllerColliderHit hit)
        {
            if (hit.gameObject.layer == LayerMask.NameToLayer("Terrain"))
            {
                // hit object is dummyCube
                return;
            }

            ManorObject manorObj = m_ManorWorld.FindManorObjectByCollider(hit.collider);
            if (manorObj != null)
            {
                switch (manorObj.ObjectType)
                {
                    case x2m.ManorObjectType.Building:
                    case x2m.ManorObjectType.AutoWallChunk:
                        {
                            Bounds bounds = hit.collider.bounds;

                            GameScene.Instance.MainChar.Position = bounds.center + new Vector3(0, bounds.size.y, 0);
                        }
                        break;
                    case x2m.ManorObjectType.Floor:
                        // do nothing...
                        break;
                }
            }
        }
    }
}
#endif