using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Zip;
#if ENABLE_MANOR
namespace Bokura
{
    public class ManorWorld : MonoBehaviour
    {
        const int FILE_FORMAT_VERSION = 1;
        
        public class Header
        {
            public int version;
            public float CellWidth;
            public float CellHeight;
            public float WorldWidth;
            public float WorldHeight;
            public int CellCols;
            public int CellRows;
            public int ObjectIDCounter;
            public int reserved;
        }
        public class ObjectData
        {
            public ushort ID;
            public ushort BaseID;
            public swm.ManorObjectType ObjType;
            public swm.ManorDirection Direction;
            public swm.ManorChunkType ChunkType; 
            public ManorObject.Cell cell;
        }
        public class Content
        {
            public ObjectData[] Objects;
        }

        public float CellWidth;
        public float CellHeight;

        public float WorldWidth;
        public float WorldHeight;

        public int CellCols;
        public int CellRows;

        public Vector3 center;

        public BoxCollider boxCollider;
        
        int m_ObjectIDCounter;

        List<ManorObject> m_FloorLayerObjects;
        List<ManorObject> m_ObjectLayerObjects;
        Dictionary<int, ManorObject> m_IndexOfObjectIDs;

        public int GenerateObjectID()
        {
            return ++m_ObjectIDCounter;
        }

//         private void Awake()
//         {
//             
//         }
// 
//         private void OnDestroy()
//         {
//             
//         }
        public void AddObject(ManorObject obj)
        {
            if (obj.Layer == ManorObject.LayerType.Floor)
                AddObjectToFloorLayer(obj);
            else
                AddObjectToObjectLayer(obj);
        }
        public void RemoveObject(ManorObject obj)
        {
            if (obj.Layer == ManorObject.LayerType.Floor)
                RemoveObjectFromFloorLayer(obj);
            else
                RemoveObjectFromObjectLayer(obj);
        }
        void AddObjectToFloorLayer(ManorObject obj)
        {
            if (obj.Layer == ManorObject.LayerType.Floor)
            {
                m_FloorLayerObjects.Add(obj);
                m_IndexOfObjectIDs.Add(obj.ID, obj);
            }
        }

        bool RemoveObjectFromFloorLayer(ManorObject obj)
        {
            m_IndexOfObjectIDs.Remove(obj.ID);
            return m_FloorLayerObjects.Remove(obj);
        }

        void AddObjectToObjectLayer(ManorObject obj)
        {
            if (obj.Layer == ManorObject.LayerType.Object)
            {
                m_ObjectLayerObjects.Add(obj);
                m_IndexOfObjectIDs.Add(obj.ID, obj);
            }
        }
        bool RemoveObjectFromObjectLayer(ManorObject obj)
        {
            m_IndexOfObjectIDs.Remove(obj.ID);
            return m_ObjectLayerObjects.Remove(obj);
        }
        ManorObject FindObjectByID(int id)
        {
            ManorObject obj;
            if (m_IndexOfObjectIDs.TryGetValue(id, out obj))
            {
                return obj;
            }

            return null;
        }
        public bool IsCellValid(ManorObject.LayerType layer, ManorObject.Cell cell, bool exceptSelectedObjects = false)
        {
            if (layer == ManorObject.LayerType.Floor)
            {
                for (int i = 0; i < m_FloorLayerObjects.Count; ++i)
                {
                    var obj = m_FloorLayerObjects[i];
                    if (exceptSelectedObjects && obj.Selected)
                    {
                        continue;
                    }
                    if (obj.IsCrossed(cell))
                    {
                        return false;
                    }
                }
                return true;
            }
            else if (layer == ManorObject.LayerType.Object)
            {
                for (int i = 0; i < m_ObjectLayerObjects.Count; ++i)
                {
                    var obj = m_ObjectLayerObjects[i];
                    if (exceptSelectedObjects && obj.Selected)
                    {
                        continue;
                    }
                    if (obj.IsCrossed(cell))
                    {
                        return false;
                    }
                }
                return true;
            }

            return false;
        }
        public ManorAutoWallChunk GetAutoWallChunkInCell(int autoWallBaseID, int chunk_col, int chunk_row)
        {
            for (int i = 0; i < m_ObjectLayerObjects.Count; ++i)
            {
                var obj = m_ObjectLayerObjects[i];
                if (obj.ObjectType == x2m.ManorObjectType.AutoWallChunk)
                {
                    ManorAutoWallChunk autoWallChunk = obj as ManorAutoWallChunk;
                    if (autoWallChunk.chunk_col == chunk_col && autoWallChunk.chunk_row == chunk_row)
                    {
                        if (autoWallChunk.BaseID != autoWallBaseID)
                        {
                            return null;
                        }
                        else
                        {
                            return autoWallChunk;
                        }
                    }
                }
            }
            return null;
        }
        public void Init()
        {
            m_ObjectLayerObjects = new List<ManorObject>(16);
            m_FloorLayerObjects = new List<ManorObject>(16);
            m_IndexOfObjectIDs = new Dictionary<int, ManorObject>(16);

            CellWidth = 1f;
            CellHeight = 1f;

            WorldWidth = 128;
            WorldHeight = 128;

            CellCols = (int)(WorldWidth / CellWidth);
            CellRows = (int)(WorldHeight / CellHeight);
        }
        public void RemoveAllObjects()
        {
            for (int i = 0; i < m_ObjectLayerObjects.Count; ++i)
            {
                var obj = m_ObjectLayerObjects[i];
                obj.Destroy();
            }
            m_ObjectLayerObjects.Clear();

            for (int i = 0; i < m_FloorLayerObjects.Count; ++i)
            {
                var obj = m_FloorLayerObjects[i];
                obj.Destroy();
            }
            m_IndexOfObjectIDs.Clear();
        }
        private byte[] m_SnapshootData;
        public void CreateSnapshoot()
        {
            using (MemoryStream ms = new MemoryStream(1024))
            {
                SaveToStream(ms);

                m_SnapshootData = ms.ToArray();
            }
        }
        void LoadHeaderForRestoreSnapshoot(Header header)
        {

        }
        void LoadContentForRestoreSnapshoot(Content content)
        {
            HashSet<int> ids = new HashSet<int>();
            for (int i = 0; i < content.Objects.Length; ++i)
            {
                ObjectData data = content.Objects[i];

                ManorObject obj = FindObjectByID(data.ID);
                if (obj == null)
                {
                    obj = CreateObject(data);

                    obj.LoadModel(true);

                    AddObject(obj);
                }
                else
                {
                    if (! obj.CompareTo(data))
                    {
                        obj.LoadFromObjectData(data);

                        obj.ReloadModel();
                    }
                }

                ids.Add(data.ID);
            }

            for (int i = m_ObjectLayerObjects.Count - 1; i >= 0; --i)
            {
                var obj = m_ObjectLayerObjects[i];
                if (! ids.Contains(obj.ID))
                {
                    RemoveObjectFromObjectLayer(obj);

                    obj.Destroy();
                }
            }

            for (int i = m_FloorLayerObjects.Count - 1; i >= 0; --i)
            {
                var obj = m_FloorLayerObjects[i];
                if (! ids.Contains(obj.ID))
                {
                    RemoveObjectFromFloorLayer(obj);

                    obj.Destroy();
                }
            }
        }
        public bool RestoreSnapshoot()
        {
            if (m_SnapshootData == null)
            {
                return false;
            }
            using (MemoryStream ms = new MemoryStream(m_SnapshootData))
            {
                if (!DoLoadFromStream(ms, LoadHeaderForRestoreSnapshoot, LoadContentForRestoreSnapshoot))
                {
                    return false;
                }
            }
            return true;
        }
        public void Uninit()
        {
            RemoveAllObjects();
        }
        void LoadHeader(Header header)
        {
            m_ObjectLayerObjects = new List<ManorObject>(16);
            m_FloorLayerObjects = new List<ManorObject>(16);
            m_IndexOfObjectIDs = new Dictionary<int, ManorObject>(16);

            this.CellWidth = header.CellWidth;
            this.CellHeight = header.CellHeight;
            this.WorldWidth = header.WorldWidth;
            this.WorldHeight = header.WorldHeight;
            this.CellCols = header.CellCols;
            this.CellRows = header.CellRows;
            this.m_ObjectIDCounter = header.ObjectIDCounter;
        }
        public ManorObject CreateObject(ObjectData data)
        {
            ManorObject obj = null;
            switch ((x2m.ManorObjectType)data.ObjType)
            {
                case x2m.ManorObjectType.Building:
                    obj = new ManorBuilding(this);
                    break;
                case x2m.ManorObjectType.Floor:
                    obj = new ManorFloor(this);
                    break;
                case x2m.ManorObjectType.AutoWallChunk:
                    obj = new ManorAutoWallChunk(this);
                    break;
            }
            obj.LoadFromObjectData(data);

            return obj;
        }
        void LoadContent(Content content)
        {
            for (int i = 0; i < content.Objects.Length; ++i)
            {
                ObjectData data = content.Objects[i];

                ManorObject obj = CreateObject(data);

                obj.LoadModel(true);

                AddObject(obj);
            }
        }
        delegate void LoadHeaderCallback(Header header);

        delegate void LoadContentCallback(Content content);

        bool DoLoadFromStream(Stream stream, LoadHeaderCallback callbackHeader, LoadContentCallback callbackLoadContent)
        {
            //BinaryFormatter bf = new BinaryFormatter();//没有用的变量 bf  报警告 注销掉 使用下面的函数  shiliang
            try
            {
                using (ZipInputStream zipStream = new ZipInputStream(stream))
                {
                    ZipEntry entry = zipStream.GetNextEntry();
                    if (!string.Equals(entry.Name, "world"))
                    {
                        return false;
                    }
                    byte[] bytes = new byte[entry.Size];
                    zipStream.Read(bytes, 0, (int)entry.Size);

                    using (MemoryStream ms = new MemoryStream(bytes))
                    {
                        var manor_content = ProtoBuf.Serializer.Deserialize(typeof(x2m.ManorContent), ms) as x2m.ManorContent;

                        Header header = new Header();

                        Content content = new Content();

                        using (BinaryReader reader = new BinaryReader(ms))
                        {
                            header.version = manor_content.header.version;
                            header.CellWidth = manor_content.header.CellWidth;
                            header.CellHeight = manor_content.header.CellHeight;
                            header.WorldWidth = manor_content.header.WorldWidth;
                            header.WorldHeight = manor_content.header.WorldHeight;
                            header.CellCols = manor_content.header.CellCols;
                            header.CellRows = manor_content.header.CellRows;
                            header.ObjectIDCounter = manor_content.header.ObjectIDCounter;
                            header.reserved = manor_content.header.reserved;

                            if (header.version != ManorWorld.FILE_FORMAT_VERSION)
                            {
                                return false;
                            }
                            if (header.reserved != 0)
                            {
                                return false;
                            }

                            callbackHeader(header);

                            content.Objects = new ObjectData[manor_content.Objects.Count];

                            for (int i = 0; i < manor_content.Objects.Count; ++i)
                            {
                                x2m.ManorObjectData manor = manor_content.Objects[i];

                                ObjectData data = new ObjectData();
                                data.ID = (ushort)manor.ID;
                                data.BaseID = (ushort)manor.BaseID;
                                data.ObjType = manor.ObjType;
                                data.Direction = manor.Direction;
                                data.ChunkType = manor.ChunkType;
                                data.cell = new ManorObject.Cell(manor.cell.left, manor.cell.top, manor.cell.right - manor.cell.left + 1, manor.cell.bottom - manor.cell.top + 1, manor.cell.flip);
                                
                                content.Objects[i] = data;
                            }

                            callbackLoadContent(content);
                        }
                    }
                     
                    return true;
                }
            }
            catch (Exception e)
            {
                File.WriteAllText(Utilities.BuildString(IResourceLoader.persistentDataPath, "/err.txt"), e.ToString());
                LogHelper.LogError("failed to load manor world data");
                return false;
            }
        }
        public bool LoadFromStream(Stream stream)
        {
            return DoLoadFromStream(stream, LoadHeader, LoadContent);
        }
        void BuildHeader(Header header)
        {
            header.version = ManorWorld.FILE_FORMAT_VERSION;
            header.CellWidth = this.CellWidth;
            header.CellHeight = this.CellHeight;
            header.WorldWidth = this.WorldWidth;
            header.WorldHeight = this.WorldHeight;
            header.CellCols = this.CellCols;
            header.CellRows = this.CellRows;
            header.ObjectIDCounter = this.m_ObjectIDCounter;
            header.reserved = 0;
        }
        void BuildContent(Content content)
        {
            content.Objects = new ObjectData[m_ObjectLayerObjects.Count + m_FloorLayerObjects.Count];
            int index = 0;
            for (int i = 0; i < m_FloorLayerObjects.Count; ++i)
            {
                var obj = m_FloorLayerObjects[i];

                var data = new ObjectData();
                obj.SaveToObjectData(data);
                content.Objects[index++] = data;
            }
            for (int i = 0; i < m_ObjectLayerObjects.Count; ++i)
            {
                var obj = m_ObjectLayerObjects[i];

                var data = new ObjectData();
                obj.SaveToObjectData(data);
                content.Objects[index++] = data;
            }
        }
        public void SaveToStream(Stream stream)
        {
            try
            {
                Header header = new Header();
                BuildHeader(header);

                Content content = new Content();
                BuildContent(content);

#if false
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        BinaryWriter writer = new BinaryWriter(ms);
                        writer.Write(header.version);
                        writer.Write(header.CellWidth);
                        writer.Write(header.CellHeight);
                        writer.Write(header.WorldWidth);
                        writer.Write(header.WorldHeight);
                        writer.Write(header.CellCols);
                        writer.Write(header.CellRows);
                        writer.Write(header.ObjectIDCounter);
                        writer.Write(header.reserved);

                        writer.Write(content.Objects.Length);

                        for (int i = 0; i < content.Objects.Length; ++i)
                        {
                            ObjectData data = content.Objects[i];
                            if (data == null) continue;

                            writer.Write(data.ID);
                            writer.Write(data.BaseID);
                            writer.Write(data.ObjType);
                            writer.Write(data.Direction);
                            writer.Write(data.ChunkType);
                            
                            writer.Write(data.cell.left);
                            writer.Write(data.cell.top);
                            writer.Write(data.cell.right);
                            writer.Write(data.cell.bottom);
                            writer.Write(data.cell.Flip);
                        }

                        using (ZipOutputStream zipStream = new ZipOutputStream(stream))
                        {
                            ZipEntry entry = new ZipEntry("world");

                            zipStream.PutNextEntry(entry);

                            var buff = ms.ToArray();
                            zipStream.Write(buff, 0, buff.Length);
                        }
                    }
                }
#endif

                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        x2m.ManorContent manor_content = new x2m.ManorContent();
                        manor_content.header = new x2m.ManorHeader();

                        manor_content.header.version = header.version;
                        manor_content.header.CellWidth = header.CellWidth;
                        manor_content.header.CellHeight = header.CellHeight;
                        manor_content.header.WorldWidth = header.WorldWidth;
                        manor_content.header.WorldHeight = header.WorldHeight;
                        manor_content.header.CellCols = header.CellCols;
                        manor_content.header.CellRows = header.CellRows;
                        manor_content.header.ObjectIDCounter = header.ObjectIDCounter;
                        manor_content.header.reserved = header.reserved;
                        
                        for (int i = 0; i < content.Objects.Length; ++i)
                        {
                            ObjectData data = content.Objects[i];
                            if (data == null) continue;

                            x2m.ManorObjectData manorObj = new x2m.ManorObjectData();

                            manorObj.ID = data.ID;
                            manorObj.BaseID = data.BaseID;
                            manorObj.ObjType = data.ObjType;
                            manorObj.Direction = data.Direction;
                            manorObj.ChunkType = data.ChunkType;

                            manorObj.cell = new x2m.ManorCell();
                            manorObj.cell.left = data.cell.left;
                            manorObj.cell.top = data.cell.top;
                            manorObj.cell.right = data.cell.right;
                            manorObj.cell.bottom = data.cell.bottom;
                            manorObj.cell.flip = data.cell.Flip;

                            manor_content.Objects.Add(manorObj);
                        }
                        ProtoBuf.Serializer.Serialize(ms, manor_content);
                        
                        using (ZipOutputStream zipStream = new ZipOutputStream(stream))
                        {
                            zipStream.SetLevel(9);

                            ZipEntry entry = new ZipEntry("world");
                            zipStream.PutNextEntry(entry);

                            var buff = ms.ToArray();
                            zipStream.Write(buff, 0, buff.Length);
                        }
                    }
                }

            }
            catch (Exception e)
            {
                File.WriteAllText(Utilities.BuildString(IResourceLoader.persistentDataPath, "/err.txt"), e.ToString());
                LogHelper.LogError("failed to save manor world");
            }
        }
        public bool World2Cell(Vector3 pos, out int col, out int row)
        {
            float x = pos.x - (center.x - WorldWidth / 2.0f);
            float z = pos.z - (center.z - WorldHeight / 2.0f);
            if (x >= 0 && z >= 0 && x <= WorldWidth && z <= WorldHeight)
            {
                col = Mathf.FloorToInt(x / CellWidth);
                row = Mathf.FloorToInt(z / CellHeight);
                return true;
            }
            col = -1;
            row = -1;
            return false;
        }

        public bool Cell2World(int col, int row, out Vector3 pos)
        {
            pos = new Vector3(col * CellWidth + (center.x - WorldWidth / 2.0f), 0, row * CellHeight + (center.z - WorldHeight / 2.0f));

            if (col >= 0 && row >= 0 && col < CellCols && row < CellRows)
            {
                return true;
            }
            return false;
        }
        public void LoadModel(string strAssetBundlesPath, string strModelName, bool bAsync, LoadCallback callback)
        {
            if (string.IsNullOrEmpty(strModelName))
            {
                Bokura.LogHelper.LogError(LogCategory.Framework, "Model name is empty : ");
                return;
            }

            if (bAsync)
            {
                ResourceHelper.LoadPrefabAsync(strAssetBundlesPath, strModelName, callback);
            }
            else
            {
                ResourceHelper.LoadPrefabAsync(strAssetBundlesPath, strModelName, callback);
            }
        }
        public ManorObject FindManorObjectByCollider(Collider collider)
        {
            for (int i = 0; i < m_ObjectLayerObjects.Count; ++i)
            {
                ManorObject obj = m_ObjectLayerObjects[i];
                if (obj.IsColliderThisOne(collider))
                {
                    return obj;
                }
            }
            for (int i = 0; i < m_FloorLayerObjects.Count; ++i)
            {
                ManorObject obj = m_FloorLayerObjects[i];
                if (obj.IsColliderThisOne(collider))
                {
                    return obj;
                }
            }
            return null;
        }
        public ManorObject Pick(Ray ray)
        {
            int layermask = LayerMask.GetMask("Default");
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 9999999, layermask))
            {
                return FindManorObjectByCollider(hit.collider);
            }
            
            return null;
        }
        GameObject goGridMesh;

        private bool m_ShowGrid;
        public bool ShowGrid
        {
            get
            {
                return m_ShowGrid;
            }

            set
            {
                if (m_ShowGrid != value)
                {
                    m_ShowGrid = value;

                    if (m_ShowGrid)
                    {
                        int meshsize = 4;

                        int width = (int)WorldWidth / meshsize;
                        int height = (int)WorldHeight / meshsize;

                        goGridMesh = new GameObject();
                        goGridMesh.name = "GridMesh";
                        MeshFilter meshFilter = goGridMesh.AddComponent<MeshFilter>();

                        Mesh mesh = new Mesh();
                        meshFilter.sharedMesh = mesh;
                        MeshRenderer renderer = goGridMesh.AddComponent<MeshRenderer>();

                        GameObject goSettings = GameObject.Find("ManorWorldSettings");
                        
                        renderer.sharedMaterial = goSettings.GetComponent<MeshRenderer>().sharedMaterial;

                        Vector3[] vertices = new Vector3[height * width];
                        Vector2[] uv = new Vector2[height * width];

                        //Vector2 uvScale = new Vector2(1.0f / (width - 1), 1.0f / (height - 1));

                        for (int y = 0; y < height; y++)
                        {
                            for (int x = 0; x < width; x++)
                            {
                                vertices[y * width + x] = new Vector3(x * meshsize, 0, y * meshsize);
                                uv[y * width + x] = new Vector2(x % 2, y % 2); //Vector2.Scale(new Vector2(x * meshsize, y * meshsize), uvScale);
                            }
                        }
                        mesh.vertices = vertices;
                        mesh.uv = uv;

                        int[] triangles = new int[(height - 1) * (width - 1) * 6];
                        int index = 0;
                        for (int y = 0; y < height - 1; y++)
                        {
                            for (int x = 0; x < width - 1; x++)
                            {
                                triangles[index++] = (y * width) + x;
                                triangles[index++] = ((y + 1) * width) + x;
                                triangles[index++] = (y * width) + x + 1;

                                triangles[index++] = ((y + 1) * width) + x;
                                triangles[index++] = ((y + 1) * width) + x + 1;
                                triangles[index++] = (y * width) + x + 1;
                            }
                        }
                        mesh.triangles = triangles;

                        mesh.RecalculateNormals();

                        goGridMesh.transform.position = center + new Vector3(-WorldWidth / 2.0f, 0, -WorldHeight / 2.0f);
                        
                    }
                    else
                    {
                        GameObject.Destroy(goGridMesh);
                        goGridMesh = null;
                    }
                }
            }
        }
    }
}
#endif