﻿using System;
using System.Collections.Generic;
using System.Text;
using Bokura;
using UnityEngine;
#if ENABLE_MANOR
namespace Bokura
{
    public class ManorWorldSettings : MonoBehaviour
    {
        public static ManorWorldSettings Instance;

        private void Awake()
        {
            Instance = this;    
        }

        private void OnDestroy()
        {
            Instance = null;
        }

        public Material GridMeshMaterial;
    }
}
#endif