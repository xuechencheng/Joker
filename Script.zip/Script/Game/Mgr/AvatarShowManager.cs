using System;
using System.Collections.Generic;
using LitJson;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 用于管理AvatarShow的产生、更新、消亡
    /// </summary>
	public class AvatarShowManager: ClientSingleton<AvatarShowManager>
	{
        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
		}
        /// <summary>
        /// 加载配置数据（必须在使用AvatarShow的UI界面数据层加载配置以前调用）
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
            if (m_ConfigLoaded) return;
            m_ConfigLoaded = true;
            m_PanelConfigs.Clear();
            string tPanelConfig = TableManager.LoadFileTable("panel_avatarshow.json", "/Datas/");
            JsonData tJsonData = JsonMapper.ToObject(tPanelConfig);
            int tCount = tJsonData.Count;
            if (tCount > 0)
            {
                for (int tIdx = 0; tIdx < tCount; tIdx++)
                {
                    JsonData tSubData = tJsonData[tIdx];
                    AvatarShowPanelConfig tConfig = JsonMapper.ToObject<AvatarShowPanelConfig>(tSubData.ToJson());
                    m_PanelConfigs.Add(tConfig.panelId, tConfig);
                }
            }
            m_EnvLightConfigs = UIUtility.GetAvatarShowEnvLightConfig();
            //依赖于从角色表、Npc表、神兵表、坐骑表、外观配置表中获取模型的名称，从而加载模型和对应的AvatarShow配置
        }
        [XLua.BlackList]
        public void Clear()
        {
            foreach (var tShow in m_ActiveAvatarShows)
                tShow.Dispose();
            m_ActiveAvatarShows.Clear();
            m_AvatarShowPool.Clear();
            //场景切换会自动销毁对象，因此只需要清空引用即可
            m_EnvPool.Clear();
            AvatarShow.Clear();
            ThreeDPreviewManager.Instance.Clear();
        }
        private bool m_ConfigLoaded = false;
        /// <summary>
        /// 与界面相关的配置
        /// </summary>
        private Dictionary<int, AvatarShowPanelConfig> m_PanelConfigs = new Dictionary<int, AvatarShowPanelConfig>(Const.kCap8);
        /// <summary>
        /// 界面的3D环境缓存
        /// </summary>
        private Dictionary<int, Env3dInfo> m_EnvPool = new Dictionary<int, Env3dInfo>(Const.kCap2); 
        /// <summary>
        /// 当前使用的AvatarShow
        /// </summary>
        private HashSet<AvatarShow> m_ActiveAvatarShows = new HashSet<AvatarShow>();
        /// <summary>
        /// 缓存池
        /// </summary>
        private Stack<AvatarShow> m_AvatarShowPool = new Stack<AvatarShow>(Const.kCap8);
        /// <summary>
        /// 环境光配置
        /// </summary>
        private AvatarShowEnvLightConfig m_EnvLightConfigs = null;
        /// <summary>
        /// 从缓存池中获取对象
        /// </summary>
        private AvatarShow GetAvatarShowFromPool()
        {
            AvatarShow tShow = null;
            if (m_AvatarShowPool.Count > 0)
                tShow = m_AvatarShowPool.Pop();
            if (null == tShow)
                tShow = new AvatarShow();
            m_ActiveAvatarShows.Add(tShow);
            return tShow;
        }
        /// <summary>
        /// 获取显示角色的AvatarShow.
        /// Warning:记得及时调用TimelineUserAvatarData.Dispose释放资源
        /// </summary>
        public AvatarShow GetAvatarShow(UserAvatarData data)
        {
            return GetAvatarShowFromPool().Init(data);
        }
        /// <summary>
        /// 获取显示NPC的AvatarShow
        /// </summary>
        public AvatarShow GetAvatarShow(NpcAvatarData data)
        {
            return GetAvatarShowFromPool().Init(data);
        }
        /// <summary>
        /// 获取坐骑的AvatarShow
        /// </summary>
        public AvatarShow GetAvatarShow(MountAvatarData data)
        {
            return GetAvatarShowFromPool().Init(data);
        }
        /// <summary>
        /// 获取武器的AvatarShow
        /// </summary>
        public AvatarShow GetAvatarShow(WeaponAvatarData data)
        {
            return GetAvatarShowFromPool().Init(data);
        }
        /// <summary>
        /// 获取自建城建筑的AvatarShow
        /// </summary>
        public AvatarShow GetAvatarShow(BuildingAvatarData data)
        {
            return GetAvatarShowFromPool().Init(data);
        }
        /// <summary>
        /// 获取自建城沙盘的AvatarShow
        /// </summary>
        public AvatarShow GetAvatarShow(SandTableAvatarData data)
        {
            return GetAvatarShowFromPool().Init(data);
        }
        [XLua.BlackList, Obsolete("请勿使用，逻辑未通")]
        public AvatarShow GetAvatarShow(GameObject avatarObj, string configPath /*AvatarShow配置文件的资源路径*/, int panelId /*展示的界面id*/)
        {
            if (null == avatarObj) return null;
            return GetAvatarShowFromPool().Init(avatarObj, configPath, panelId);
        }
        /// <summary>
        /// 回收AvatarShow
        /// </summary>
        public void RecycleAvatarShow(AvatarShow _Show)
        {
            if (null != _Show)
            {
                m_ActiveAvatarShows.Remove(_Show);
                _Show.Dispose();
                m_AvatarShowPool.Push(_Show);
            }
        }
        /// <summary>
        /// 获取界面相关的配置
        /// </summary>
        [XLua.BlackList]
        public AvatarShowPanelConfig GetPanelConfig(int _PanelId)
        {
            AvatarShowPanelConfig tResult;
            if (null == m_PanelConfigs || !m_PanelConfigs.TryGetValue(_PanelId, out tResult))
                tResult = null;
            return tResult;
        }
        /// <summary>
        /// 根据UI界面名称获取对应的id （不要频繁调用，缓存结果）
        /// </summary>
        public int GetPanelId(string panelName)
        {
            Load();
            int tPanelId = 0;
            if(!string.IsNullOrEmpty(panelName))
            {
                foreach (var tPair in m_PanelConfigs)
                {
                    AvatarShowPanelConfig tConfig = tPair.Value;
                    if (tConfig.panelName == panelName)
                    {
                        tPanelId = tConfig.panelId;
                        break;
                    }
                }
            }
            return tPanelId;
        }
        /// <summary>
        /// 根据id获取环境光配置
        /// </summary>
        [XLua.BlackList]
        public EnvLightConfig GetEnvLightConfigById(int _Id)
        {
            return null != m_EnvLightConfigs ? m_EnvLightConfigs.GetConfigById(_Id) : null;
        }
        /// <summary>
        /// 获取界面的3D环境
        /// </summary>
        public Transform GetPanelEnv3D(string _Name)
        {
            Transform tEnv = null;
            if(!string.IsNullOrEmpty(_Name))
            {
                var tKey = _Name.GetHashCode();
                Env3dInfo tInfo = null;
                if (!m_EnvPool.TryGetValue(tKey, out tInfo))
                {
                    tEnv = UIUtility.GetPrefabByAssetPath(Const.kAvatarShowEnvPath, _Name)?.transform;
                    if (tEnv)
                        tEnv.gameObject.SetLayerRecursively(Const.kAvatarShowLayer);
                }
                else
                {
                    tEnv = tInfo.env3d;
                    m_EnvPool.Remove(tKey);
                }
            }
            return tEnv;
        }
        /// <summary>
        /// 回收界面的3D环境
        /// </summary>
        public void RecyclePanelEnv3D(string _Name, Transform _Env3D)
        {
            if (null != _Env3D)
            {
                if(!string.IsNullOrEmpty(_Name))
                {
                    var tKey = _Name.GetHashCode();
                    if (!m_EnvPool.ContainsKey(tKey))
                    {
                        _Env3D.gameObject.SetActive(false);
                        m_EnvPool.Add(tKey, new Env3dInfo(_Env3D));
                        return;
                    }
                }
                //如果未知姓名或已经存在，直接销毁
                _Env3D.DestroyGameObject();
            }
        }
        [XLua.BlackList]
        public void DoLateUpdate()
        {
            foreach (var tShow in m_ActiveAvatarShows)
                tShow.DoLateUpdate();
            //延时删除场景
            var tKeyList = Const.s_Int32List;
            tKeyList.Clear();
            foreach (var tPair in m_EnvPool)
            {
                var tInfo = tPair.Value;
                tInfo.standByTime += Time.unscaledDeltaTime;
                if (tInfo.standByTime > 30f)
                {
                    tInfo.Dispose();
                    tKeyList.Add(tPair.Key);
                }
            }
            for (int tIdx = 0, tCount = tKeyList.Count; tIdx < tCount; tIdx++)
                m_EnvPool.Remove(tKeyList[tIdx]);
            ThreeDPreviewManager.Instance.DoLateUpdate();
        }
    }
    /// <summary>
    /// 玩家外观数据
    /// </summary>
    public struct UserAvatarData
    {
        /// <summary>
        /// 角色id
        /// </summary>
        public ulong charID;
        /// <summary>
        /// 职业
        /// </summary>
        public int career;
        /// <summary>
        /// 性别
        /// </summary>
        public int sex;
        /// <summary>
        /// 捏脸数据
        /// </summary>
        public byte[] makeup;
        /// <summary>
        /// 时装数据
        /// </summary>
        public List<uint> fids;
        /// <summary>
        /// 展示的界面id
        /// </summary>
        public int panelID;
        [XLua.BlackList]
        public UserAvatarData(int panelId)
        {
            this.charID = 0;
            this.career = 1;
            this.sex = 1;
            this.makeup = null;
            this.fids = null;
            this.panelID = panelId;
        }
        [XLua.BlackList]
        public UserAvatarData(swm.RspUserAvatarData msg, int panelId)
        {
            this.charID = msg.char_id;
            this.career = (int)(msg.career_type != swm.CareerType.Unknown ? msg.career_type : swm.CareerType.Warrior);
            this.sex = (int)(msg.career_sex != swm.CareerSex.Unknown ? msg.career_sex : swm.CareerSex.Male);
            this.panelID = panelId;
            int tMakeupDataCount = msg.makeup_dataLength;
            if (tMakeupDataCount > 0)
            {
                this.makeup = new byte[tMakeupDataCount];
                for (int tIdx = 0; tIdx < tMakeupDataCount; tIdx++)
                    this.makeup[tIdx] = msg.makeup_data(tIdx);
            }
            else
                this.makeup = null;
            int tFidDataCount = msg.fidsLength;
            if (tFidDataCount > 0)
            {
                this.fids = UIPoolMgr.SpawnList<uint>();
                this.fids.Capacity = tFidDataCount;
                for (int tIdx = 0; tIdx < tFidDataCount; tIdx++)
                    this.fids.Add(msg.fids(tIdx));
            }
            else
                this.fids = null;
        }
        [XLua.BlackList]
        public void Dispose()
        {
            this.makeup = null;
            UIPoolMgr.RecycleList(ref this.fids);
        }
    }
    /// <summary>
    /// Npc外观数据
    /// </summary>
    public struct NpcAvatarData
    {
        /// <summary>
        /// id
        /// </summary>
        public uint baseID;
        /// <summary>
        /// 展示的界面id
        /// </summary>
        public int panelID;
        public NpcAvatarData(uint baseid, int panelid)
        {
            this.baseID = baseid;
            this.panelID = panelid;
        }
        [XLua.BlackList]
        public void Dispose()
        {
        }
    }
    /// <summary>
    /// 坐骑外观数据
    /// </summary>
    public struct MountAvatarData
    {
        /// <summary>
        /// 基本类型
        /// </summary>
        public int baseID;
        /// <summary>
        /// 皮肤类型
        /// </summary>
        public int skinID;
        /// <summary>
        /// 展示的界面id
        /// </summary>
        public int panelID;
        public MountAvatarData(int baseid, int skinid, int panelid)
        {
            this.baseID = baseid;
            this.skinID = skinid;
            this.panelID = panelid;
        }
        [XLua.BlackList]
        public void Dispose()
        {
        }
    }
    /// <summary>
    /// 武器外观数据
    /// </summary>
    public struct WeaponAvatarData
    {
        /// <summary>
        /// 基本类型
        /// </summary>
        public ulong baseID;
        /// <summary>
        /// 展示的界面id
        /// </summary>
        public int panelID;
        public WeaponAvatarData(ulong baseId, int panelId)
        {
            this.baseID = baseId;
            this.panelID = panelId;
        }
        [XLua.BlackList]
        public void Dispose()
        {
        }
    }
    /// <summary>
    /// 自建城外观数据
    /// </summary>
    public struct BuildingAvatarData
    {
        /// <summary>
        /// 基本外观id
        /// </summary>
        public uint baseID;
        /// <summary>
        /// 展示的界面id
        /// </summary>
        public int panelID;
        public BuildingAvatarData(uint baseId, int panelId)
        {
            baseID = baseId;
            panelID = panelId;
        }
        [XLua.BlackList]
        public void Dispose()
        {
        }
    }
    /// <summary>
    /// 自建城沙盘外观数据
    /// </summary>
    public struct SandTableAvatarData
    {
        /// <summary>
        /// 基本外观id
        /// </summary>
        public uint baseID;
        /// <summary>
        /// 展示的界面id
        /// </summary>
        public int panelID;
        public SandTableAvatarData(uint baseId, int panelId)
        {
            baseID = baseId;
            panelID = panelId;
        }
    }
    /// <summary>
    /// 3D环境配置数据
    /// </summary>
    public class Env3dInfo
    {
        /// <summary>
        /// 3D环境
        /// </summary>
        public Transform env3d;
        /// <summary>
        /// 空闲时间
        /// </summary>
        public float standByTime;
        public Env3dInfo(Transform _Env3D)
        {
            this.env3d = _Env3D;
            this.standByTime = 0;
        }
        public void Dispose()
        {
            if(this.env3d)
            {
                this.env3d.DestroyGameObject();
                this.env3d = null;
            }
        }
    }
}
