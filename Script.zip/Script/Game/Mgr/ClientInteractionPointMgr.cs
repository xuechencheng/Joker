using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    #region Client Interaction Point Manager
    public class ClientInteractionPointMgr : ClientSingleton<ClientInteractionPointMgr>
    {
        #region Property
        /// <summary>
        /// ID to allocate
        /// </summary>
        private ulong m_ulMaxID = 0;

        /// <summary>
        /// Stores all client interaction points
        /// ulong : ID
        /// ClientInteractionPointInfo : Interaction point info
        /// </summary>
        private Dictionary<ulong, ClientInteractionPointInfo> m_dicInteractionPoints = new Dictionary<ulong, ClientInteractionPointInfo>(ConstValue.kCap8);

        /// <summary>
        /// Current map id
        /// </summary>
        private uint m_uiCurMapID = 0;
        #endregion

        #region Interface
        /// <summary>
        /// Add an interaction point info
        /// </summary>
        /// <param name="tOccupied"> Is this point occupied </param>
        /// <param name="tType"> What is this interaction point </param>
        /// <param name="tPosition"> World position of this interaction point </param>
        public void AddInteractionPoint(bool tOccupied, ClientInteractionType tType, Vector3 tPosition)
        {
            ClientInteractionPointInfo info = new ClientInteractionPointInfo(tOccupied, tType, tPosition);
            m_dicInteractionPoints.Add(m_ulMaxID++, info);
        }
        #endregion

        #region Interface For Home
        private void AddHomeBuilding(int tBuildingID)
        {
            var building = HomeBuildingViewer.Instance.GetBuildingById(tBuildingID);

            ClientInteractionType type = (ClientInteractionType)building.Info.Config.restPoint;
            if (type == ClientInteractionType.None) return;
            string interactionPointName;

            // Add sit point
            if ((type & ClientInteractionType.Bench) != 0)
                for (int i = 0; i < 10; i++)
                {
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append("SitPoint");
                    X2StringBuilder.Append(i);
                    interactionPointName = UnityEngine.UI.Giant.UIPoolMgr.SpawnString(X2StringBuilder.Length);
                    X2StringBuilder.CopyToString(interactionPointName);
                    Transform restPoint = building.Model.unityObject.transform.Find(interactionPointName);
                    if (restPoint == null) break;
                    AddInteractionPoint(false, ClientInteractionType.Bench, restPoint.position);
                }

            // Add sleep point
            if ((type & ClientInteractionType.Bed) != 0)
                for (int i = 0; i < 10; i++)
                {
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append("SleepPoint");
                    X2StringBuilder.Append(i);
                    interactionPointName = UnityEngine.UI.Giant.UIPoolMgr.SpawnString(X2StringBuilder.Length);
                    X2StringBuilder.CopyToString(interactionPointName);
                    Transform restPoint = building.Model.unityObject.transform.Find(interactionPointName);
                    if (restPoint == null) break;
                    AddInteractionPoint(false, ClientInteractionType.Bed, restPoint.position);
                }

            // Add build point
            if ((type & ClientInteractionType.Construct) != 0)
                for (int i = 0; i < 10; i++)
                {
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append("BuildPoint");
                    X2StringBuilder.Append(i);
                    interactionPointName = UnityEngine.UI.Giant.UIPoolMgr.SpawnString(X2StringBuilder.Length);
                    X2StringBuilder.CopyToString(interactionPointName);
                    Transform restPoint = building.Model.unityObject.transform.Find(interactionPointName);
                    if (restPoint == null) break;
                    AddInteractionPoint(false, ClientInteractionType.Construct, restPoint.position);
                }
        }

        /// <summary>
        /// Get the closets interaction point to given position
        /// </summary>
        /// <param name="tStartPos"> Given position </param>
        /// <param name="tType"> The type of interaction point to find </param>
        /// <returns> Closest interaction point info, return null if not found </returns>
        public ClientInteractionPointInfo GetClosestInteractionPointInfo(Vector3 tStartPos, ClientInteractionType tType)
        {
            ClientInteractionPointInfo pointInfo = null;
            if (m_dicInteractionPoints.Count > 0)
            {
                float distance = -1;
                float magnitude = 0;
                foreach (var info in m_dicInteractionPoints.Values)
                {
                    if (info.Type != tType) continue;
                    if (info.Occupied) continue;

                    magnitude = (info.Position - tStartPos).magnitude;
                    if (distance < 0)
                    {
                        distance = magnitude;
                        pointInfo = info;
                    }
                    else if (magnitude < distance)
                    {
                        distance = magnitude;
                        pointInfo = info;
                    }
                }
            }

            return pointInfo;
        }
        #endregion

        #region Method
        /// <summary>
        /// Collect all interaction point when map load finished
        /// </summary>
        private void OnMapLoadDone()
        {
            // Home map
            if (m_uiCurMapID == 6553601)
                HomeBuildingViewer.Instance.modelLoadEvent.AddListener(AddHomeBuilding);
        }

        /// <summary>
        /// Clear data and update current map id when changing map
        /// </summary>
        /// <param name="_msg"> Map to jump to </param>
        private void OnChangeMap(swm.IntoMap _msg)
        {
            m_dicInteractionPoints.Clear();
            m_uiCurMapID = _msg.map_id;
            m_ulMaxID = 0;

            HomeBuildingViewer.Instance.modelLoadEvent.RemoveListener(AddHomeBuilding);
        }
        #endregion

        #region Life Cycle
        public void Init()
        {
            m_uiCurMapID = 0;
            m_ulMaxID = 0;
            GameScene.Instance.onIntoMap.AddListener(OnChangeMap);
            GameScene.Instance.onEndLoading.AddListener(OnMapLoadDone);
        }

        public void Clear()
        {
            m_dicInteractionPoints.Clear();
            GameScene.Instance.onEndLoading.RemoveListener(OnMapLoadDone);
            GameScene.Instance.onIntoMap.AddListener(OnChangeMap);
        }
        #endregion
    }
    #endregion

    #region Client Interaction Point Info
    public enum ClientInteractionType
    {
        None = 0,
        Bench = 1,           // Sit point
        Bed = 1 << 1,        // Sleep point
        Construct = 1 << 2,  // Construct architecture point
    }

    public class ClientInteractionPointInfo
    {
        #region Property
        /// <summary>
        /// Is this point occupied
        /// </summary>
        private bool m_bIsOccupied = false;
        public bool Occupied { get { return m_bIsOccupied; } }

        /// <summary>
        /// What is this interaction item
        /// </summary>
        private ClientInteractionType m_citType;
        public ClientInteractionType Type { get { return m_citType; } }

        /// <summary>
        /// Position of this interaction point
        /// </summary>
        private Vector3 m_v3Position;
        public Vector3 Position { get { return m_v3Position; } }
        #endregion

        #region Interface
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tOccupied"> Is this point occupied </param>
        /// <param name="tType"> What type is this interaction item </param>
        /// <param name="tPos"> Interaction position </param>
        public ClientInteractionPointInfo(bool tOccupied, ClientInteractionType tType, Vector3 tPos)
        {
            m_bIsOccupied = tOccupied;
            m_citType = tType;
            m_v3Position = tPos;
        }
        #endregion
    }
    #endregion
}