﻿using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 新版内联图标管理器
    /// </summary>
	public class InlineSpriteManager: ClientSingleton<InlineSpriteManager>
	{
        private int m_EmojiCount = 0;
        public int emojiCount
        {
            get { return m_EmojiCount; }
        }
        /// <summary>
        /// 表情名称哈希值与id映射关系
        /// </summary>
        private readonly Dictionary<int, int> m_HashName2IdMap = new Dictionary<int, int>(Const.kCap32);
        /// <summary>
        /// 表情别名哈希值与id映射关系
        /// </summary>
        private readonly Dictionary<int, int> m_HashSpecialCodeMap = new Dictionary<int, int>(Const.kCap32);
        /// <summary>
        /// 路径哈希值与静态精灵数据映射关系
        /// </summary>
        //private readonly Dictionary<int, InlineSpriteData> m_SpriteInfos = new Dictionary<int, InlineSpriteData>(Const.kCap16);
        /// <summary>
        /// 路径哈希值与动态精灵数据映射关系
        /// </summary>
        //private readonly Dictionary<int, InlineAnimData> m_AnimInfos = new Dictionary<int, InlineAnimData>(Const.kCap16);
        /// <summary>
        /// 配置id与表情信息映射关系
        /// </summary>
        private readonly Dictionary<int, EmojiInfo> m_EmojiInfos = new Dictionary<int, EmojiInfo>(Const.kCap16);
        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
		}
        /// <summary>
        /// 重置数据
        /// </summary>
        [XLua.BlackList]
        public void Clear()
        {

        }
        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
            EmojiTableManager.Load();
            m_EmojiCount = EmojiTableManager.Instance.m_DataList.EmojiTableLength;
            for (int tIdx = 0; tIdx < m_EmojiCount; tIdx++)
            {
                EmojiTableBase? tConfig = EmojiTableManager.GetData(tIdx);
                if(tConfig.HasValue)
                {
                    EmojiTableBase tValue = tConfig.Value;
                    int tHashName = UIUtility.GetCustomHashCode(tValue.name);
                    if (!m_HashName2IdMap.ContainsKey(tHashName))
                        m_HashName2IdMap.Add(tHashName, tIdx);
                    else
                        UIUtility.LogError(string.Format("表情的名称哈希值冲突,id：{0}与{1}", tIdx, m_HashName2IdMap[tHashName]));

                    int tSPHashName = UIUtility.GetCustomHashCode(tValue.specialcode);
                    if (!m_HashSpecialCodeMap.ContainsKey(tSPHashName))
                        m_HashSpecialCodeMap.Add(tSPHashName, tIdx);
                    else
                        UIUtility.LogError(string.Format("表情的特殊字符有重复,specialcode：{0}", tValue.specialcode));
                }
            }
		}
        /// <summary>
        /// 根据传入的特殊字符串解析出对应的表情名称
        /// </summary>
        /// <param name="spCode">特殊字符串</param>
        [XLua.BlackList]
        public string GetEmojiNameBySpecialCode(string spCode)
        {
            string tEmojiName = "Unknown";
            if (!string.IsNullOrEmpty(spCode))
            {
                int tSPHashName = UIUtility.GetCustomHashCode(spCode);
                int tIdx = -1;
                if (m_HashSpecialCodeMap.TryGetValue(tSPHashName, out tIdx))
                    tEmojiName = GetEmojiInfoById(tIdx).name;
            }
            return tEmojiName;
        }
        /// <summary>
        /// 根据id获取表情的信息
        /// </summary>
        public EmojiInfo GetEmojiInfoById(int id)
        {
            EmojiInfo tInfo;
            if(!m_EmojiInfos.TryGetValue(id, out tInfo))
            {
                EmojiTableBase? tConfig = EmojiTableManager.GetData(id);
                if (tConfig.HasValue)
                {
                    EmojiTableBase tValue = tConfig.Value;
                    tInfo.name = tValue.name;
                    tInfo.specialcode = tValue.specialcode;
                    //静态表情
                    if (tValue.type == 0)
                        tInfo.iconPath = tValue.prefix_path;
                    //动态表情
                    else
                        tInfo.iconPath = UIUtility.ConcatString(tValue.prefix_path, Const.kZeroStr);
                }
                else
                {
                    tInfo.name = "Unknown";
                    tInfo.iconPath = string.Empty;
                    tInfo.specialcode = string.Empty;
                }
                m_EmojiInfos.Add(id, tInfo);
            }
            return tInfo;
        }

        // /// <summary>
        // /// InlineText和UIInlineText脚本内部使用，通过id获取静态/动态精灵数据
        // /// </summary>
        // [XLua.BlackList]
        // public void GetInlineData(int hashName, out InlineSpriteData spriteInfo, out InlineAnimData animInfo)
        // {
        //     spriteInfo = null;
        //     animInfo = null;
        //     int tConfigId = 0;
        //     if (!m_HashName2IdMap.TryGetValue(hashName, out tConfigId))
        //         return;
        //     EmojiTableBase? tConfig = EmojiTableManager.GetData(tConfigId);
        //     if (tConfig.HasValue)
        //     {
        //         EmojiTableBase tValue = tConfig.Value;
        //         if(tValue.type == 0)//静态表情
        //             spriteInfo = GetInlineSpriteData(tValue.prefix_path);
        //         else //动态表情
        //             animInfo = GetInlineAnimData(tValue.frequency, tValue.num, tValue.prefix_path);
        //     }
        // }

        /// <summary>
        /// InlineText和UIInlineText脚本内部使用，通过id获取静态精灵数据
        /// </summary>
        // [XLua.BlackList]
        // public InlineSpriteData GetInlineSpriteData(string path)
        // {
        //     InlineSpriteData tData = null;
        //     if(!string.IsNullOrEmpty(path))
        //     {
        //         int tHashPath = path.GetHashCode();
        //         if (!m_SpriteInfos.TryGetValue(tHashPath, out tData))
        //         {
        //             tData = new InlineSpriteData(path);
        //             m_SpriteInfos.Add(tHashPath, tData);
        //         }
        //     }
        //     if (null == tData)
        //         tData = InlineSpriteData.Default;
        //     return tData;
        // }

        // private InlineAnimData GetInlineAnimData(int frequency, int num, string path)
        // {
        //     InlineAnimData tData = null;
        //     if (!string.IsNullOrEmpty(path))
        //     {
        //         int tHashPath = path.GetHashCode();
        //         if (!m_AnimInfos.TryGetValue(tHashPath, out tData))
        //         {
        //             tData = new InlineAnimData(frequency, num, path);
        //             m_AnimInfos.Add(tHashPath, tData);
        //         }
        //     }
        //     if (null == tData)
        //         tData = InlineAnimData.Default;
        //     return tData;
        // }
    }

    /// <summary>
    /// 表情信息
    /// </summary>
    public struct EmojiInfo
    {
        /// <summary>
        /// 表情名称
        /// </summary>
        public string name;
        /// <summary>
        /// 表情的图标
        /// </summary>
        public string iconPath;
        /// <summary>
        /// 特殊符号
        /// </summary>
        public string specialcode;
    }
}
