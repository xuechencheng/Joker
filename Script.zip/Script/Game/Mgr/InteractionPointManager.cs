using LitJson;
using System;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    [XLua.BlackList]

    /// <summary>
    /// 交互点管理器
    /// </summary>
	public class InteractionPointManager : ClientSingleton<InteractionPointManager>
    {
        #region 常量

        //private const float VisualRange = 10f;

        #endregion

        #region 变量

        /// <summary>
        /// 交互点配置
        /// </summary>
        private InteractionAssets m_interactionAsset = null;

        ///// <summary>
        ///// 通用配置
        ///// </summary>
        //private InteractionConfigAssets m_config = null;


    
        private InteractionAssets.SeatItem m_nearSeatItem = null;
        /// <summary>
        /// 最近的位置id
        /// </summary>
        /// 
        [XLua.BlackList]
        public InteractionAssets.SeatItem nearSeatItem
        {
            get { return m_nearSeatItem; }
        }


        ///// <summary>
        ///// 是否common配置被加载
        ///// </summary>
        //private bool m_commonCfgLoaded = false;


        /// <summary>
        /// 当前地图id
        /// </summary>
        private uint m_curMapid = 0;


        private List<int> m_findAnimIdList = new List<int>(Const.kCap8);
        /// <summary>
        /// 查找到的动画id列表
        /// </summary>
        public List<int> findAnimIdList
        {
            get { return m_findAnimIdList; }
        }


        /// <summary>
        /// 一组中未使用的交互点id集合
        /// </summary>
        private Dictionary<uint, InteractionAssets.SeatItem> m_UnUsedPointByGroupDict = new Dictionary<uint, InteractionAssets.SeatItem>(Const.kCap8);



        private GameEvent m_interactionPointLoadedEvent = new GameEvent();
        /// <summary>
        /// 交互点加载
        /// </summary>
        [XLua.BlackList]
        public GameEvent interactionPointLoadedEvent
        {
            get { return m_interactionPointLoadedEvent; }
        }

        #endregion

        #region 继承函数

        [XLua.BlackList]
        public void Init()
        {
            GameScene.Instance.onEndLoading.AddListener(ProcessOnEndLoading);
            GameScene.Instance.onAddEntity.AddListener(ProcAddEntity);
        }

        /// <summary>
        /// 重置数据
        /// </summary>
        [XLua.BlackList]
        public void Clear()
        {
            //m_commonCfgLoaded = false;
            m_UnUsedPointByGroupDict.Clear();
        }

        [XLua.BlackList]
        public void Update()
        {
            /*
            if (m_interactionAsset == null) return;
            var nearest = VisualRange;
            InteractionAssets.SeatItem seat = null;
            var pos = GameScene.Instance.MainChar.Position;

            for (int i = 0; i < m_interactionAsset.items.Length; i++)
            {
                var item = m_interactionAsset.items[i];
                for (int j = 0; j < item.seats.Length; j++)
                {
                    var distance = Vector3.Distance(item.seats[j].startPosition, pos);
                    if (distance < nearest)
                    {
                        nearest = distance;
                        seat = item.seats[j];
                    }
                }
            }

            if (seat != null)
            {
                m_nearSeatItem = seat;
            }
            */
            InteractionUpdate();
        }

        #endregion

        #region 事件

        private void ProcessOnEndLoading()
        {
            //LoadCommonAnimCfg();
            LoadInteractionAssets();
        }

        private void ProcAddEntity(Entity entity)
        {
            if (entity == null)
                return;

            // 处理交互点entity
            ProcAddInteractionEntity(entity as MovableEntity);
        }

        private void ProcAddInteractionEntity(MovableEntity entity)
        {
            var mainchar = GameScene.Instance.MainChar;
            if (mainchar == null)
                return;

            // 是玩家才会检测
            if (!entity.IsCharacter())
                return;

            if (!entity.IsInInteractionPoint)
                return;

            uint entitypointid = entity.interaction_id;

            // 主角没有占领交互点
            if (mainchar.IsInInteractionPoint)
                return;

            // 同时主角进入交互区域
            if (mainchar.enterInteractionGroupId <= 0)
                return;

            // 检测玩家的交互点是否在主角的交互区域, 在的话检测
            bool iscontain = InteractionPointManager.Instance.ContainPointByGroupId(mainchar.enterInteractionGroupId, entitypointid);
            if (!iscontain)
                return;

            GameScene.Instance.onNtfInteractionActionEvent.Invoke((uint)MovableEntity.InteractionState.None, entitypointid, 0);
        }

        #endregion

        #region 函数

        //private void LoadCommonAnimCfg()
        //{
        //    if (m_commonCfgLoaded)
        //        return;

        //    m_commonCfgLoaded = true;
        //    m_config = null;

        //    ResourceHelper.LoadResourceAsync(IResourceLoader.strDatasInteractionFolder, "config", IResourceLoader.strAssetSuffix, (UnityEngine.Object o) =>
        //    {
        //        m_config = o as InteractionConfigAssets;
        //    });
        //}

        [XLua.BlackList]
        private void LoadInteractionAssets()
        {
            if (m_curMapid == GameScene.Instance.CurrentMapId)
                return;

            m_curMapid = GameScene.Instance.CurrentMapId;
            m_interactionAsset = null;

            ResourceHelper.LoadResourceAsync(IResourceLoader.strDatasInteractionFolder, m_curMapid.ToString(), IResourceLoader.strAssetSuffix, (UnityEngine.Object o) =>
            {
                m_interactionAsset = o as InteractionAssets;

                CheckMainCharInteraction();

                m_interactionPointLoadedEvent.Invoke();
            });
        }

        private void CheckMainCharInteraction()
        {
            var mainchar = GameScene.Instance.MainChar;
            if (mainchar == null)
                return;

            // 同时主角进入交互区域
            uint groupid = mainchar.enterInteractionGroupId;
            if (groupid <= 0)
                return;

            GameScene.Instance.onNtfInteractionActionEvent.Invoke((uint)MovableEntity.InteractionState.None, groupid, 0);
        }

        /// <summary>
        /// 获取交互点id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public InteractionAssets.SeatItem GetInterationActionTypeFromID(int id)
        {
            for (int i = 0; i < m_interactionAsset.items.Length; i++)
            {
                var item = m_interactionAsset.items[i];
                for (int j = 0; j < item.seats.Length; j++)
                {
                    if (item.seats[j].id == id)
                        return item.seats[j];
                }
            }

            return null;
        }

        /// <summary>
        /// 根据groupid检测交互点是否包含
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        [XLua.BlackList]
        public bool ContainPointByGroupId(uint groupid, uint id)
        {
            for (int i = 0; i < m_interactionAsset.items.Length; i++)
            {
                InteractionAssets.Item item = m_interactionAsset.items[i];
                if (item.id == groupid)
                {
                    for (int j = 0; j < item.seats.Length; j++)
                    {
                        InteractionAssets.SeatItem seatitem = item.seats[j];
                        if (seatitem.id == id)
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        public uint GetGroupIdByPoint(uint id)
        {
            if (m_interactionAsset == null)
                return 0;

            if (m_interactionAsset.items == null)
                return 0;

            for (int i = 0; i < m_interactionAsset.items.Length; i++)
            {
                InteractionAssets.Item item = m_interactionAsset.items[i];

                if (item.id == id)
                {
                    return (uint)item.id;
                }

                for (int j = 0; j < item.seats.Length; j++)
                {
                    InteractionAssets.SeatItem seatitem = item.seats[j];
                    if (seatitem.id == id)
                    {
                        return (uint)item.id;
                    }
                }
            }

            return 0;
        }

        public void CalcAnimIdList(uint pointid)
        {
            m_findAnimIdList.Clear();

            for (int i = 0; i < m_interactionAsset.items.Length; i++)
            {
                InteractionAssets.Item item = m_interactionAsset.items[i];
                for (int j = 0; j < item.seats.Length; j++)
                {
                    InteractionAssets.SeatItem seatitem = item.seats[j];
                    if (seatitem.id == pointid)
                    {
                        m_findAnimIdList.AddRange(seatitem.anims);
                        break;
                    }
                }
            }
        }

        ///// <summary>
        ///// 获取动作id
        ///// </summary>
        ///// <param name="action_id"></param>
        ///// <returns></returns>
        //public InteractionConfigAssets.AnimConfig GetAnimConfig(uint action_id)
        //{
        //    if (m_config == null)
        //        return null;

        //    if (m_config.animConfigs == null)
        //        return null;

        //    for (int i = 0; i < m_config.animConfigs.Length; i++)
        //    {
        //        InteractionConfigAssets.AnimConfig animcfg = m_config.animConfigs[i];
        //        if (animcfg == null)
        //            continue;

        //        if (animcfg.id == action_id)
        //        {
        //            return animcfg;
        //        }
        //    }

        //    return null;
        //}

        /// <summary>
        /// 在groupid中查找没有被使用的id
        /// </summary>
        /// <param name="groupid"></param>
        /// <param name="usedpointlist"></param>
        /// <returns></returns>

        [XLua.BlackList]
        public uint GetUnUsedPointByGroupId(uint groupid, ref HashSet<uint> usedpointlist)
        {
            if (m_interactionAsset == null)
                return 0;

            if (m_interactionAsset.items == null)
                return 0;

            m_UnUsedPointByGroupDict.Clear();

            for (int i = 0; i < m_interactionAsset.items.Length; i++)
            {
                InteractionAssets.Item item = m_interactionAsset.items[i];
                if (item.id == groupid)
                {  
                    for (int j = 0; j < item.seats.Length; j++)
                    {
                        InteractionAssets.SeatItem seatitem = item.seats[j];
                        if (!usedpointlist.Contains((uint)seatitem.id))
                        {
                            if (!m_UnUsedPointByGroupDict.ContainsKey((uint)seatitem.id))
                            {
                                m_UnUsedPointByGroupDict.Add((uint)seatitem.id, seatitem);
                            }
                        }
                    }
                }
            }

            uint nearestid = 0;
            float mindis = 10000.0f;

            MainCharacter mainchar = GameScene.Instance.MainChar;

            if (mainchar != null)
            {
                Vector3 mainpos = mainchar.Position;

                if (m_UnUsedPointByGroupDict.Count > 0)
                {
                    foreach (var iter in m_UnUsedPointByGroupDict)
                    {
                        InteractionAssets.SeatItem seatitem = iter.Value;
                        if (seatitem == null)
                            continue;

                        Vector3 pos = seatitem.startPosition;
                        float dis = (mainpos - pos).sqrMagnitude;
                        if (dis < mindis)
                        {
                            nearestid = (uint)seatitem.id;
                            mindis = dis;
                        }
                    }
                }
            }

            return nearestid;
        }

        #endregion

        #region 交互点 服务逻辑

        protected TimeHelper deltaTime = new TimeHelper(1,true);
        protected List<KeyValuePair< GameObject, float>> GizmesObjects = new List<KeyValuePair<GameObject, float>>(Const.kCap16);

        [XLua.BlackList]
        public void SpawnRealEffect(InteractionAssets.SeatItem seatitem)
        {
            if (string.IsNullOrEmpty(seatitem.effectPath))
                return;

            if (string.IsNullOrEmpty(seatitem.effectName))
                return;

            if (seatitem != null)
            {
                Vector3 pos = seatitem.effectPosition.WorldToUnityVec();
                Quaternion rot = Quaternion.LookRotation(seatitem.effectForward, Vector3.up);
                GameFXPool.LoadFX(seatitem.effectPath, seatitem.effectName, (UnityEngine.Object o) =>
                {
                    if (o != null)
                    {
                        var clone = GameFXPool.CreateFX(o, null);
                        clone.SetActive(true);
                        clone.transform.position = pos;
                        clone.transform.rotation = rot;
                        GizmesObjects.Add(new KeyValuePair<GameObject, float>(clone, Time.realtimeSinceStartup));
                    }
                });
            }
        }

        public void SpawnEffect(InteractionAssets.SeatItem seatitem)
        {
            if (string.IsNullOrEmpty(seatitem.foodPath))
                return;

            if (string.IsNullOrEmpty(seatitem.foodName))
                return;

            if (seatitem!= null)
            {
                Vector3 pos = seatitem.foodPosition.WorldToUnityVec();
                Quaternion rot = Quaternion.LookRotation(seatitem.foodForward, Vector3.up);
                GameFXPool.LoadFX(seatitem.foodPath, seatitem.foodName, (UnityEngine.Object o) =>
                {
                    if (o != null)
                    {
                        var clone = GameFXPool.CreateFX(o, null);
                        clone.SetActive(true);
                        clone.transform.position = pos;
                        clone.transform.rotation = rot;
                        GizmesObjects.Add(new KeyValuePair<GameObject, float>(clone,Time.realtimeSinceStartup));
                    }
                });
            }
        }



        protected void InteractionUpdate()
        {
            if (deltaTime.IsValid()) return;
            for(int i = GizmesObjects.Count - 1; i >= 0; i--)
            {
                var duration = Time.realtimeSinceStartup - GizmesObjects[i].Value;
                if(duration > 10)
                {
                    GameFXPool.FreeFX(GizmesObjects[i].Key);
                    GizmesObjects.RemoveAt(i);
                }
            }
        }
        #endregion
    }
}







