﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using System;
using UnityEngine;
using Bokura;
using System.Reflection;

namespace Bokura
{
    public class NpcModelBindCommonDataBindInfo
    {
        public int actionhashid;
        public string actionname;
        public string modelname;
        public int att_point;
    }

    public class NpcModelBindCommonData
    {
        public string m_model_name;       // 模型名字

        /// <summary>
        /// 动作信息
        /// </summary>
        public Dictionary<int, NpcModelBindCommonDataBindInfo> m_actionInfo_dict = new Dictionary<int, NpcModelBindCommonDataBindInfo>(Const.kCap32);

        /// <summary>
        /// 武器信息
        /// </summary>

        public Dictionary<string, NpcModelBindCommonDataBindInfo> m_weaponInfo_dict = new Dictionary<string, NpcModelBindCommonDataBindInfo>(Const.kCap32);

        /// <summary>
        /// 获取绑定信息
        /// </summary>
        /// <param name="animid"></param>
        /// <returns></returns>
        [XLua.BlackList]
        public NpcModelBindCommonDataBindInfo GetBindInfoByAnimId(int animid)
        {
            if (m_actionInfo_dict.ContainsKey(animid))
                return m_actionInfo_dict[animid];

            return null;
        }
    }

    /// <summary>
    /// 临时先解析表格数据, 最后这个模型绑定数据应该有npc编辑器来生成
    /// </summary>
    public class NpcModelBindCommonDataManager : ClientSingleton<NpcModelBindCommonDataManager>
    {
        #region 常量

        #endregion

        #region 变量

        private Dictionary<string, NpcModelBindCommonData> m_data_dict = new Dictionary<string, NpcModelBindCommonData>(Const.kCap32);

        #endregion

        #region 继承函数

        [XLua.BlackList]
        public void Init()
        {
            
        }

        [XLua.BlackList]
        public void Clear()
        {

        }

        [XLua.BlackList]
        public void Load()
        {
            InitAllData();
        }

        #endregion

        #region 函数

        /// <summary>
        /// 获取模型绑定名字
        /// </summary>
        /// <param name="modelname"></param>
        /// <returns></returns>
        [XLua.BlackList]
        public NpcModelBindCommonData GetModelBindCommonData(string modelname)
        {
            if (m_data_dict.ContainsKey(modelname))
                return m_data_dict[modelname];

            return null;
        }

        private void InitAllData()
        {     
            NpcModelBindCommonTableManager.Load();

            ParseCfgData();
        }

        private void ParseCfgData()
        {
            int length = NpcModelBindCommonTableManager.Instance.m_DataList.NpcModelBindCommonTableLength;
            for (int i = 0; i < length; ++i)
            {
                NpcModelBindCommonTableBase? cfgdata = NpcModelBindCommonTableManager.Instance.m_DataList.NpcModelBindCommonTable(i);
                if (!cfgdata.HasValue)
                    continue;

                NpcModelBindCommonTableBase cfgdataval = cfgdata.Value;

                string modelname = cfgdataval.model_name;
                if (string.IsNullOrEmpty(modelname))
                    continue;

                NpcModelBindCommonData data = null;
                if (m_data_dict.ContainsKey(modelname))
                {
                    data = m_data_dict[modelname];
                }
                else
                {
                    data = new NpcModelBindCommonData();
                    m_data_dict.Add(modelname, data);
                }

                if (data == null)
                    continue;

                AddBindInfo(data, cfgdataval.actionname, cfgdataval.modelname, cfgdataval.att_point);
            }
        }

        private void AddBindInfo(NpcModelBindCommonData data, string straction_name, string strmodel_name, int att_point_id)
        {
            NpcModelBindCommonDataBindInfo bindinfo = new NpcModelBindCommonDataBindInfo();
            bindinfo.actionname = straction_name;
            bindinfo.modelname = strmodel_name;
            bindinfo.att_point = att_point_id;
            bindinfo.actionhashid = Animator.StringToHash(bindinfo.actionname);

            AddActionInfoDict(data, bindinfo);
            AddWeaponInfoDict(data, bindinfo);
        }

        private void AddWeaponInfoDict(NpcModelBindCommonData data, NpcModelBindCommonDataBindInfo bindinfo)
        {
            string strmodel_name = bindinfo.modelname;

            if (string.IsNullOrEmpty(strmodel_name))
                return;

            if (data.m_weaponInfo_dict.ContainsKey(strmodel_name))
                return;

            data.m_weaponInfo_dict.Add(strmodel_name, bindinfo);
        }

        private void AddActionInfoDict(NpcModelBindCommonData data, NpcModelBindCommonDataBindInfo bindinfo)
        {
            if (string.IsNullOrEmpty(bindinfo.actionname))
                return;

            int hashid = bindinfo.actionhashid;

            if (data.m_actionInfo_dict.ContainsKey(hashid))
                return;

            data.m_actionInfo_dict.Add(hashid, bindinfo);
        }

        #endregion
    }
}

