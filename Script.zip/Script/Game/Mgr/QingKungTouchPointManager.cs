﻿using LitJson;
using System;
using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    [XLua.BlackList]
    public enum QingKungStep
    {
        QingKungNone = 0,
        QingKungMove = 1, //移动轻功起飞
        QingKungSitu,//原地轻功起飞
        QingKungTwo,
        QingKungThree,
        QingKungFour,
        QingKungUp = 6,     //上升
        QingKungUp2,
        QingKungGliding = 10,  //滑翔
    }
    /// <summary>
    /// 轻功踩踏点管理器
    /// </summary>
	public class QingKungTouchPointManager : ClientSingleton<QingKungTouchPointManager>
    {

        protected List<bool> enables = new List<bool>();
        protected List<GameObject> effects = new List<GameObject>();
        protected PointAssets Points = null;
        protected uint m_curMapid = 0;


        protected bool Enable = false;
        public float VisualRange = 50f;
        public float PeakRange = 20f;
        public float NearPeakRange = 20f;
        protected string EffectName = "fx_cj_caitadian_s";
        protected bool CanPeakTouchPoint = false;
        protected Vector3 NearPoint = Vector3.zero;
        protected float Tick = 0.1f;
        protected float LastTickTime = 0f;


        public GameEvent<bool> OnCanPeakTouchPoint = new GameEvent<bool>();

        [XLua.BlackList]
        public void Init()
        {
            //GameScene.Instance.onIntoMap.AddListener(ProcessIntoMap);
            GameScene.Instance.onEndLoading.AddListener(ProcessOnEndLoading);

        }


        private void ProcessOnEndLoading()
        {
            if (m_curMapid == GameScene.Instance.CurrentMapId)
                return;

            m_curMapid = GameScene.Instance.CurrentMapId;
            Points = null;
            ResourceHelper.LoadResourceAsync(IResourceLoader.strDatasFlyPointFolder, m_curMapid.ToString(), IResourceLoader.strAssetSuffix, (UnityEngine.Object o) =>
            {
                Points = o as PointAssets;
                if(Points != null)
                {
                    ResetData(Points.Points.Length);
                }
            });
        }
        protected void ResetData(int capacity)
        {
            if (effects.Count < capacity) { effects.Capacity = capacity; effects.AddRange(new GameObject[capacity - effects.Count]); }
            if (enables.Count < capacity) { enables.Capacity = capacity; enables.AddRange(new bool[capacity - enables.Count]); }
            for (int i = 0; i < effects.Count; i++) { if(effects[i] != null) GameFXPool.FreeFX(effects[i]); else effects[i] = null; }
            for (int i = 0; i < enables.Count; i++) enables[i] = false;
        }

        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {

        }



        public  void EnableTuchPoint()
        {
            Enable = true;
        }
        public void DisableTuchPoint()
        {
            Enable = false;
            ResetData(0);

            CanPeakTouchPoint = false;
            OnCanPeakTouchPoint.Invoke(CanPeakTouchPoint);
        }

        public Vector3? GetNearTouchPoint()
        {
            if (NearPoint == Vector3.zero)
                return null;
            return NearPoint;
        }

        [XLua.BlackList]
        public void Update()
        {
            if (!Enable) return;
            if (Points == null || GameScene.Instance == null || GameScene.Instance.MainChar == null) return;
            if (Time.realtimeSinceStartup - LastTickTime < Tick) return;
            LastTickTime = Time.realtimeSinceStartup;

            Vector3 nearpoint = Vector3.zero;
            float nearpointdistance = 99990;
            bool canPeakTouchPoint = false;
            var mainCharPos = GameScene.Instance.MainChar.Position;
            for (int i = 0; i < Points.Points.Length; i++)
            {
                var touch = Points.Points[i];
                var distance = Vector3.Distance(touch, mainCharPos);
                if (distance < VisualRange)
                {
                    if (!enables[i])
                    {
                        var index = i;//闭包传值
                        enables[i] = true;
                        GameFXPool.LoadFX(IResourceLoader.strSceneEffectPath, EffectName, (UnityEngine.Object o) =>
                        {
                            if (o != null && Enable)
                            {
                                var pos = touch - LayeredSceneLoader.WorldOffset;
                                var clone = GameFXPool.CreateFX(o, pos, Quaternion.identity, null);
                                clone.SetActive(true);
                                effects[index] = clone;
                            }
                        });
                    }
                    if (distance < PeakRange)
                    {
                        canPeakTouchPoint = true;
                        var d = Vector3.Distance(touch, mainCharPos);
                        if (d < nearpointdistance)
                        {
                            nearpointdistance = d;
                            nearpoint = touch;
                        }
                    }
                }
                else if (enables[i])
                {
                    enables[i] = false;
                    GameFXPool.FreeFX(effects[i]);
                    effects[i] = null;
                }
            }

            NearPoint = nearpoint;

            bool isPeakStay = GameScene.Instance.MainChar ? GameScene.Instance.MainChar.StateMachine.CurStateID == SM.Entity.States.QingKungPeakStay : false;
            canPeakTouchPoint = canPeakTouchPoint && !isPeakStay;
            if (CanPeakTouchPoint != canPeakTouchPoint)
            {
                CanPeakTouchPoint = canPeakTouchPoint;
                OnCanPeakTouchPoint.Invoke(CanPeakTouchPoint);
            }
        }
    }
}
