﻿
namespace Bokura
{
    public class RandomNameManager: ClientSingleton<RandomNameManager>
	{
		private int m_FirstNameCount = 0;
		private int m_ManTwoCount = 0;
		private int m_FemaleTwoCount = 0;



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
			UnityEngine.Random.InitState((int)GameScene.Instance.GetServerTime());
		}



        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {

        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
			RandomNameTableManager.Load();
			int tCount = RandomNameTableManager.Instance.m_DataList.RandomNameTableLength;
			if(tCount > 0)
			{
				RandomNameTableBase? tBaseData = RandomNameTableManager.GetData(0);
				if(tBaseData.HasValue)
				{
					RandomNameTableBase tValue = tBaseData.Value;
					m_FirstNameCount = tValue.first_name_count;
					m_ManTwoCount = tValue.man_two_count;
					m_FemaleTwoCount = tValue.female_two_count;
				}
			}
		}



		public string GetRandomNameBySex(int sex)
		{
			//未知性别，默认男性
			if (sex < 1 || sex > 2)
				sex = 1;
			return UIUtility.ConcatString(GetFirstRandomName(), (sex == 1) ? GetManTwoRandomName() : GetFemaleTwoRandomName());
		}



		private string GetFirstRandomName()
		{
			int tIdx = UnityEngine.Random.Range(1, m_FirstNameCount + 1);
			RandomNameTableBase? tBaseData = RandomNameTableManager.GetData(tIdx);
			if (tBaseData.HasValue)
			{
				RandomNameTableBase tValue = tBaseData.Value;
				return tValue.first_name;
			}
			return string.Empty;
		}



		private string GetManTwoRandomName()
		{
			int tIdx = UnityEngine.Random.Range(1, m_ManTwoCount + 1);
			RandomNameTableBase? tBaseData = RandomNameTableManager.GetData(tIdx);
			if (tBaseData.HasValue)
			{
				RandomNameTableBase tValue = tBaseData.Value;
				return tValue.man_two;
			}
			return string.Empty;
		}



		private string GetFemaleTwoRandomName()
		{
			int tIdx = UnityEngine.Random.Range(1, m_FemaleTwoCount + 1);
			RandomNameTableBase? tBaseData = RandomNameTableManager.GetData(tIdx);
			if (tBaseData.HasValue)
			{
				RandomNameTableBase tValue = tBaseData.Value;
				return tValue.female_two;
			}
			return string.Empty;
		}
	}
}
