﻿using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 管理场景中表现类实体生成和销毁的类
    /// </summary>
    public class SceneSpawnManager: ClientSingleton<SceneSpawnManager>
	{
		private const int kSpawnType_Effect = 1;



		private struct SpawnedEntity
		{
			/// <summary>
			/// 已存活时间
			/// </summary>
			public float survivalTime;
			/// <summary>
			/// 寿命
			/// </summary>
			public float lifeTime;
			/// <summary>
			/// 引用
			/// </summary>
			public GameObject target;
		}



		/// <summary>
		/// 存放已生成的对象
		/// </summary>
		private Queue<SpawnedEntity> m_SpawnList = new Queue<SpawnedEntity>(Const.kCap8);



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyCreateNewEffect>(ResponseSpawnInScene_SC);
		}



        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {
            m_SpawnList?.Clear();
        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
			SceneSpawnTableManager.Load();
		}



		/// <summary>
		/// 获取指定id对应的配置信息
		/// </summary>
		private SceneSpawnTableBase? GetConfig(int id)
		{
			return SceneSpawnTableManager.GetData(id);
		}



		/// <summary>
		/// 在场景中生成实体
		/// </summary>
		private void ResponseSpawnInScene_SC(swm.NotifyCreateNewEffect msg)
		{
			if (!GameScene.Instance.MainChar) return;
			Vector3 tPos = msg.pos.FBVec3Vec3();
			SceneSpawnTableBase? tConfig = GetConfig((int)msg.effectid);
			if (!tConfig.HasValue) return;
			SceneSpawnTableBase tData = tConfig.Value;

			//超出可视范围不生成
			if (!CheckInShowRange(tPos, tData.show_range)) return;

			string tPath = GetPathByType(tData.type);

			//类型不支持
			if (string.IsNullOrEmpty(tPath)) return;

			//同步加载资源
			UnityEngine.Object o = ResourceHelper.LoadPrefabSync(tPath, tData.name);
            if(o != null)
			{
				if (o == null) return;
				GameObject tSpawnGo = GameObject.Instantiate(o, tPos, Quaternion.identity) as GameObject;
				SpawnedEntity tEntity = new SpawnedEntity();
				tEntity.lifeTime = tData.life_time / 1000.0f;
				tEntity.survivalTime = 0;
				tEntity.target = tSpawnGo;
				m_SpawnList.Enqueue(tEntity);
			}
		}



		/// <summary>
		/// 根据类型获取资源的路径
		/// </summary>
		private string GetPathByType(int type)
		{
			if (type == kSpawnType_Effect)
				return IResourceLoader.strSceneEffectPath;
			return null;
		}



		/// <summary>
		/// 检查主角到目标位置的距离是否超过指定距离
		/// </summary>
		private bool CheckInShowRange(Vector3 targetPos, float showDistance)
		{
			return (GameScene.Instance.MainChar.Position - targetPos).sqrMagnitude <= showDistance * showDistance;
		}



		public void DoUpdate()
		{
			float tDeltaTime = Time.unscaledDeltaTime;
			for (int tIdx = 0, tCount = m_SpawnList.Count; tIdx < tCount; tIdx++)
			{
				SpawnedEntity tEntity = m_SpawnList.Dequeue();
				GameObject tTarget = tEntity.target;
				if (tTarget != null /*未被意外销毁*/)
				{
					float tSurvivalTime = tEntity.survivalTime + tDeltaTime;
					if (tSurvivalTime < tEntity.lifeTime /*未达到寿命*/)
					{
						tEntity.survivalTime = tSurvivalTime;
						m_SpawnList.Enqueue(tEntity);
					}
					else
						GameObject.Destroy(tTarget);
				}
			}
		}
	}
}
