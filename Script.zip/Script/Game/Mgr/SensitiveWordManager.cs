using System.Collections.Generic;

namespace Bokura
{
    /// <summary>
    /// 敏感词管理器
    /// </summary>
	public class SensitiveWordManager: ClientSingleton<SensitiveWordManager>
	{
        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
		}



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
            ForbidwordTableManager.Load();
            ForbidwordTableBaseList tDataList = ForbidwordTableManager.Instance.m_DataList;
            int tDataLength = tDataList.ForbidwordTableLength;
            List<string> tLib = new List<string>(tDataLength);
            for (int tIdx = 0; tIdx < tDataLength; tIdx++)
            {
                ForbidwordTableBase? tData = tDataList.ForbidwordTable(tIdx);
                if (tData.HasValue)
                    tLib.Add(tData.Value.name);
            }
            //避免引擎层依赖逻辑层逻辑
            StringUtility.InitWorldLib(tLib);
        }
    }

}
