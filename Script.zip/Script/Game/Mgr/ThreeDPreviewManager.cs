using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 3D预览管理器
    /// </summary>
	public class ThreeDPreviewManager: ClientSingleton<ThreeDPreviewManager>
	{
        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
		}



        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {
            //场景切换会自动销毁对象，因此只需要清空引用即可
            m_PreviewCaches?.Clear();
            m_PosCaches?.Clear();
            m_NextPos = 0;
            m_ActivePreviews?.Clear();
        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
		}



        /// <summary>
        /// 缓存未使用的预览设施
        /// </summary>
        private Queue<ThreeDPreview> m_PreviewCaches = new Queue<ThreeDPreview>(Const.kCap2);



        /// <summary>
        /// 缓存未使用的位置
        /// </summary>
        private Queue<int> m_PosCaches = new Queue<int>(Const.kCap2);



        /// <summary>
        /// 下一个位置
        /// </summary>
        private int m_NextPos = 0;



        /// <summary>
        /// 目前正在使用的预览设施
        /// </summary>
        private HashSet<ThreeDPreview> m_ActivePreviews = new HashSet<ThreeDPreview>();



        public void DoLateUpdate()
        {
            //手动快照
            if(m_ActivePreviews.Count > 0)
            {
                foreach (var tPreview in m_ActivePreviews)
                    tPreview.DoRender();
            }

            //超时销毁
            float tTimeDelta = Time.unscaledDeltaTime;
            for (int tIdx = 0, tCount = m_PreviewCaches.Count; tIdx < tCount; tIdx++)
            {
                ThreeDPreview tPreview = m_PreviewCaches.Dequeue();
                tPreview.DoTick(tTimeDelta);
                if (tPreview.standByTime > 5)
                    GameObject.Destroy(tPreview.gameObject);
                else
                    m_PreviewCaches.Enqueue(tPreview);
            }
        }



        /// <summary>
        /// 获取预览
        /// </summary>
        public ThreeDPreview GetPreview(int _Width, int _Height, string _BackgroundPath, float _Fov)
        {
            ThreeDPreview tPreview = null;
            if(m_PreviewCaches.Count > 0)
                tPreview = m_PreviewCaches.Dequeue();
            if(null == tPreview)
                tPreview = UIUtility.LoadAndGetThreeDPreview();
            if(tPreview == null)
            {
                UIUtility.LogWarning("Cant Find Prefab [ui_item_previewcam]");
                return null;
            }

            int tPos = m_NextPos;
            if (m_PosCaches.Count > 0)
                tPos = m_PosCaches.Dequeue();
            else
                m_NextPos++;

            RenderTexture tRT = RenderTexture.GetTemporary(_Width, _Height, 24, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear, 4, RenderTextureMemoryless.MSAA);
            if(null != tRT)
            {
                tPreview.DoInit(tRT, tPos, _BackgroundPath, _Fov);
                m_ActivePreviews.Add(tPreview);
            }
            return tPreview;
        }
         


        /// <summary>
        /// 不需要预览的时候调用，以回收资源
        /// </summary>
        public void DestroyPreview(ThreeDPreview _Preview)
        {
            if (!_Preview) return;
            m_ActivePreviews.Remove(_Preview);
            m_PreviewCaches.Enqueue(_Preview);
            if (_Preview.pos >= 0)
                m_PosCaches.Enqueue(_Preview.pos);
            if(null != _Preview.renderTex)
                RenderTexture.ReleaseTemporary(_Preview.renderTex);
            _Preview.DoClear();
        }
    }
}
