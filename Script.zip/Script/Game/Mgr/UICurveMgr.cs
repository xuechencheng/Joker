﻿using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{

    public class UICurveMgr : ClientSingleton<UICurveMgr>
	{
		private bool m_Inited = false;



		private Dictionary<string, AnimationCurve> m_CurveMap = new Dictionary<string, AnimationCurve>(Const.kCap4);



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
		}



        public void Clear()
        {

        }



        /// <summary>
        /// 加载数据（ui/curvedatas/ui_curves.asset）
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
			CurveAsset tCA = UIUtility.LoadCurveAsset();
			if (tCA != null)
			{
				CurveConfig[] tCurves = tCA.curves;
				int tCount = tCurves.Length;
				for (int tIdx = 0; tIdx < tCount; tIdx++)
				{
					CurveConfig tConfig = tCurves[tIdx];
					m_CurveMap.Add(tConfig.name, tConfig.curve);
				}
			}
			m_Inited = true;
		}



		public AnimationCurve GetCurve(string name)
		{
			if (!m_Inited)
				Load();
			AnimationCurve tCurve = null;
			m_CurveMap.TryGetValue(name, out tCurve);
			return tCurve;
		}
	}



	/// <summary>
	/// 包装曲线的类
	/// </summary>
	public class UICurve
	{
		private AnimationCurve m_Curve;



		private UICurve(AnimationCurve curve)
		{
			m_Curve = curve;
		}



		public static UICurve GetCurve(string name)
		{
			return new UICurve(UICurveMgr.Instance.GetCurve(name));
		}



		public float Sample(float percenet)
		{
			float tValue = 0;
			if (m_Curve != null)
				tValue = m_Curve.Evaluate(Mathf.Clamp01(percenet));
			return tValue;
		}



		public void Destroy()
		{
			m_Curve = null;
        }
	}
}
