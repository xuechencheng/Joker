using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bokura;

namespace Bokura
{
    public class MiniGameNetData
    {
        private uint m_gameId = 0;
        public uint GameId
        {
            get
            {
                return m_gameId;
            }
            
        }

        public void Clear()
        {
            m_gameId = 0;
        }

        public void Refresh(swm.NotifyStartMiniGame _msg)
        {
            m_gameId = _msg.gameid;
        }
    }
    class MiniGameModel : ClientSingleton<MiniGameModel>
    {
        private MiniGameNetData m_TmpGameNetData = new MiniGameNetData();

        public GameEvent<MiniGameNetData> onNotifyStartGameEvent = new GameEvent<MiniGameNetData>();
        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyStartMiniGame>(ProcNotifyStartMiniGame);
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_TmpGameNetData.Clear();
        }

        /// <summary>
        /// 接收 通知开始小游戏
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyStartMiniGame(swm.NotifyStartMiniGame _msg)
        {
            m_TmpGameNetData.Clear();
            m_TmpGameNetData.Refresh(_msg);
            onNotifyStartGameEvent.Invoke(m_TmpGameNetData);
        }

        /// <summary>
        /// 发送 客户端结束小游戏
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_data"></param>
        public void SendReqEndMiniGame(uint _id,List<ulong> _data,bool _bIsGiveUp)
        {

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.ReqEndMiniGame.CreateResultVector(fbb, _data.ToArray());
            swm.ReqEndMiniGame.StartReqEndMiniGame(fbb);
            swm.ReqEndMiniGame.AddGameid(fbb,_id);
            swm.ReqEndMiniGame.AddResult(fbb, vec);
            swm.ReqEndMiniGame.AddState(fbb, !_bIsGiveUp);
            var msg = swm.ReqEndMiniGame.EndReqEndMiniGame(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEndMiniGame.HashID, fbb);
        }
    }
}
