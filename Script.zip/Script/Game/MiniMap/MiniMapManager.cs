﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Bokura;

namespace Bokura
{
    public enum MiniMapUniqueType
    {
        MainChar        = 1,
        MainCharSearch  = 2,
    }
    public enum MiniMapIconType
    {
        NPC         = 1,
        Player      = 2,
        Mission     = 3,
        TeamMember  = 4,
        WayPoint    = 5,
        DestPoint   = 6,
        CommitMission = 7,
        Resource = 8
    }
    /// <summary>
    /// 小地图管理器
    /// </summary>
	public class MiniMapManager: ClientSingleton<MiniMapManager>
	{		
		/// <summary>
		/// 注册通信消息
		/// </summary>
		[XLua.BlackList]
		public void Init()
		{
            MapManager.Instance.onEndLoading.AddListener(InitMiniMap);
            MapManager.Instance.onMainCharMoved.AddListener(OnMainCharMoved);
        }
        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
		public void Load()
		{
            MiniMapTableManager.Load();
            m_Config = UIUtility.GetScriptableObject("asset/ui/configs/config_MiniMap") as MiniMapConfig;
            if (null == m_Config)
            {
                m_Config = ScriptableObject.CreateInstance<MiniMapConfig>();
                m_Config.minRadius = 60;
                m_Config.maxRadius = 80;
            }
        }
        /// <summary>
        /// （大退/小退）清理缓存
        /// </summary>
        public void Clear()
		{
            m_MapData = new MiniMapData();
            SetViewSize(null);
		}
        private MiniMapConfig m_Config = null;
        private MiniMapData m_MapData = new MiniMapData();
        public MiniMapData mapData { get { return m_MapData; } }
        /// <summary>
        /// 小地图显示范围
        /// </summary>
        private Vector2 m_ViewSize = new Vector2(200, 200);
        private GameEvent m_OnInitMiniMap = new GameEvent();
        /// <summary>
        /// 总是在跳场景后重新初始化小地图
        /// </summary>
        public GameEvent onInitMiniMap { get { return m_OnInitMiniMap; } }
        private GameEvent m_OnMainCharMoved = new GameEvent();
        /// <summary>
        /// 主角移动时更新地图和图标位置
        /// </summary>
        public GameEvent onMainCharMoved { get { return m_OnMainCharMoved; } }
        /// <summary>
        /// 主角移动
        /// </summary>
        private void OnMainCharMoved()
        {
            m_OnMainCharMoved.Invoke();
        }

        /// <summary>
        /// 设置小地图的可见范围
        /// </summary>
        public void SetViewSize(GameObject _View)
        {
            var tMapView = _View?.GetComponent<RectTransform>();
            if (null != tMapView)
                m_ViewSize = tMapView.rect.size;
            else
                m_ViewSize = new Vector2(200, 200);
        }

        /// <summary>
        /// Loading结束后初始化小地图
        /// </summary>
        private void InitMiniMap()
        {
            SetMapData();
            //初始化Icon缓存池
            m_OnInitMiniMap.Invoke();
        }

        /// <summary>
        /// 更新地图数据
        /// </summary>
        private void SetMapData()
        {
            var tConfig = MiniMapTableManager.GetData((int)GameScene.Instance.CurrentMapId);

            if (!tConfig.HasValue)
                InitMapData();
            else
            {
                var tConfigValue        = tConfig.Value;
                m_MapData.WorldSize     = UIUtility.ParseVector3(tConfigValue.WorldSize);
                m_MapData.MapSize       = UIUtility.ParseVector3(tConfigValue.MapSize);
                m_MapData.ChunkSize     = tConfigValue.ChunkSize;
                m_MapData.ChunkNum      = m_MapData.MapSize / m_MapData.ChunkSize;
                m_MapData.MapName       = tConfigValue.MapName;
                m_MapData.SceneName     = tConfigValue.SceneName;
                m_MapData.IsInBigWorld  = (m_MapData.MapName.Contains("World_JZ"));
            }
            m_MapData.UpdateViewSize(m_ViewSize);
        }

        /// <summary>
        /// 初始化地图数据
        /// </summary>
        private void InitMapData()
        {
            m_MapData.WorldSize.x       = 8192;
            m_MapData.WorldSize.y       = 8192;

            m_MapData.MapSize.x         = 8192;
            m_MapData.MapSize.y         = 8192;

            m_MapData.ChunkSize         = 512;
            m_MapData.ChunkNum          = new UnityEngine.Vector2(16, 16);

            m_MapData.MapName           = "map_world_minimap";

            m_MapData.IsInBigWorld      = true;
        }

        /// <summary>
        /// 设置小地图图标的遮罩
        /// </summary>
        public void InitIconMaterialProperties(GameObject _Mask, Image _Img)
        {
            if (null == _Mask || null == _Img) return;
            var tMaskTran   = _Mask.transform as RectTransform;
            if (null == tMaskTran) return;
            Canvas tCvs     = _Mask.GetComponentInParent<Canvas>();
            if (null == tCvs) return;
            tCvs = tCvs.rootCanvas;
            var tMat = _Img.material;
            if(tMat.HasProperty(ConstValue.sCircularId))
            {
                var tCorners = Const.s_Corners;
                tMaskTran.GetWorldCorners(tCorners);
                var tCenter = tCvs.transform.worldToLocalMatrix.MultiplyPoint3x4((tCorners[0] + tCorners[2]) / 2);
                tMat.SetVector(ConstValue.sCircularId, new Vector4(tCenter.x, tCenter.y, m_Config.minRadius, m_Config.maxRadius - m_Config.minRadius));
            }
        }

        /// <summary>
        /// 设置小地图地块的遮罩
        /// </summary>
        public void InitTileMaterialProperties(Image _Img)
        {
            if (null == _Img) return;
            var tMaskSprite = UIUtility.GetSpriteByPath(m_Config.tileMaskSpritePath);
            if(tMaskSprite)
            {
                var tMat = _Img.material;
                if (tMat.HasProperty(ConstValue.sMaskId))
                    tMat.SetTexture(ConstValue.sMaskId, tMaskSprite.texture);
            }
        }
    }
    /// <summary>
    /// 存放小地图所需的数据
    /// </summary>
    public class MiniMapData
    {
        /// <summary>
        /// 地图根节点的坐标（确保玩家图标在视图内，且大部分情况居中不动）
        /// </summary>
        public Vector2 RootPos;
        /// <summary>
        /// 世界地图大小,单位：米
        /// </summary>
        public Vector2 WorldSize;
        /// <summary>
        /// 地图集的总大小，单位：像素
        /// </summary>
        public Vector2 MapSize;
        /// <summary>
        /// 每一个地图块的大小，单位：像素
        /// </summary>
        public int ChunkSize;
        /// <summary>
        /// 地图块索引的最大值
        /// </summary>
        public Vector2 ChunkNum;
        /// <summary>
        /// 场景的名称（中文）
        /// </summary>
        public string SceneName;
        /// <summary>
        /// 地图的名称（英文）
        /// </summary>
        public string MapName;
        /// <summary>
        /// 地图可见范围，单位：像素
        /// </summary>
        public Vector2 ViewSize;
        /// <summary>
        /// 是否在大世界中
        /// </summary>
        public bool IsInBigWorld;
        /// <summary>
        /// 保证主角图标居中，主角可以移动到的最小坐标。否则要么图标偏移，要么小地图会空缺
        /// </summary>
        private Vector2 minPos;
        /// <summary>
        /// 保证主角图标居中，主角可以移动到的最大坐标。否则要么图标偏移，要么小地图会空缺
        /// </summary>
        private Vector2 maxPos;
        /// <summary>
        /// 更新小地图窗口大小
        /// </summary>
        [XLua.BlackList]
        public void UpdateViewSize(Vector2 size)
        {
            ViewSize = size;
            minPos = size / 2;
            maxPos = MapSize - minPos;
        }
        /// <summary>
        /// 世界坐标转地图坐标
        /// </summary>
        public Vector2 World2MapPos(Vector3 worldPos)
        {
            return World2MapPos(worldPos, false);
        }
        /// <summary>
        /// 世界坐标转地图坐标
        /// </summary>
        public void EntityPos2MapPos(Entity _Entity, out float _X, out float _Y)
        {
            var tPos = World2MapPos(_Entity.GlobalPosition);
            _X = tPos.x;
            _Y = tPos.y;
        }
        /// <summary>
        /// 更新地图布的偏移量以及主角的位置
        /// </summary>
        public Vector2 UpdateMapRootPos(Vector3 worldPos)
        {
            Vector2 tPos = World2MapPos(worldPos, true);
            //当主角移动超出最大最小范围时，主角图标不在小地图中心。
            Vector2 tMapRootOffset = Vector2.Min(Vector2.Max(tPos, minPos), maxPos);
            RootPos = -tMapRootOffset;
            return (tPos + RootPos);
        }
        /// <summary>
        /// 世界坐标转当前大陆地图的像素坐标（左下角原点）
        /// </summary>
        private Vector2 World2MapPos(Vector3 wPos, bool updateMapName)
        {
            if (IsInBigWorld)
            {
                if(updateMapName)
                    wPos = WorldHelper.WorldPos2MapPosForMiniMap(wPos, ref MapName);
                else
                    wPos = WorldHelper.WorldPos2MapPos(wPos);
            }
            else
            {
                if (GameScene.Instance.CurrentIntomapInfo.Value.map_baseid == 9)
                {
                    //版属版本，战场副本 制作问题，这段代码特殊处理一下战场位置
                    wPos.x = wPos.x + WorldSize.x / 2;
                    wPos.z = wPos.z + WorldSize.y / 2 - 102;
                }
            }

            //比例尺缩放
            Vector2 mPos = Vector2.zero;
            mPos.x = wPos.x * MapSize.x / WorldSize.x;
            mPos.y = wPos.z * MapSize.y / WorldSize.y;
            return mPos;
        }
    }
}
