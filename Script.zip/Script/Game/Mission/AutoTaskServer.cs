﻿using System;
using System.Net;
using System.Threading;
using System.Net.Sockets;
using System.Text;

using UnityEngine;
using Bokura.Common;

namespace Bokura
{
    public class AutoTaskServer
    {
        private static AutoTaskServer m_Instance = null;
        public static AutoTaskServer Instance
        {
            get
            {
                if(m_Instance == null)
                    m_Instance = new AutoTaskServer();
                return m_Instance;
            }
        }

        #region Properties
        private string m_ip = string.Empty;
        private int m_port = 0;
        private Socket clientSocket;
        #endregion

        public void StartConnection(string ip, int port)
        {
            if (IsConnected())
                return;

            m_ip = ip;
            m_port = port;
            IPAddress _ip = IPAddress.Parse(m_ip);
            IPEndPoint ipendpoint = new IPEndPoint(_ip, m_port);
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            clientSocket.Connect(ipendpoint);
            clientSocket.Send(Encoding.UTF8.GetBytes("Connection is success\n"));
        }
        public void EndConnect()
        {
            if (clientSocket != null)
            {
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();
                clientSocket = null;
            }
        }

        public void SendMsg(string msg)
        {
            if (IsConnected())
            {
                clientSocket.Send(Encoding.UTF8.GetBytes(msg + "\n"));
            }
        }

        public bool IsConnected()
        {
            return (clientSocket != null && clientSocket.Connected);
        }
    }
}