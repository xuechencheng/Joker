using System;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public class SubmitItemInfo
    {
        public swm.BagType type;
        public ulong itemid;
        public uint num;
    }

    public class NpcTaskStateInfo
    {
        private swm.TaskNpcState m_NpcTaskInfoState = swm.TaskNpcState.None;
        private swm.RoleTaskType m_RoleTasInfokType = swm.RoleTaskType.None;

        public void Clear()
        {
            m_NpcTaskInfoState = swm.TaskNpcState.None;
            m_RoleTasInfokType = swm.RoleTaskType.None;
        }
        public swm.TaskNpcState NpcTaskInfoState
        {
            get
            {
                return m_NpcTaskInfoState;
            }
            set
            {
                m_NpcTaskInfoState = value;
            }
        }

        public swm.RoleTaskType RoleTaskInfoType
        {
            get
            {
                return m_RoleTasInfokType;
            }
            set
            {
                m_RoleTasInfokType = value;
            }
        }
    }

    public class TaskIconDisplayInfo
    {
        public uint m_taskid = 0;
        public uint m_subtaskid = 0;
        public byte m_index = 0;
        public swm.RoleTaskIconType m_type = swm.RoleTaskIconType.None;
        public swm.IconDisplayType m_state = swm.IconDisplayType.None;
        public List<ulong> m_typeparams = new List<ulong>(Bokura.ConstValue.kCap4);
        public string m_icon_name = string.Empty;
        public ulong GetTypeParamByIndex(int _index)
        {
            ulong _value = 0;
            if(_index < m_typeparams.Count)
            {
                _value = m_typeparams[_index];
            }

            return _value;
        }

        public void Clear()
        {
            m_taskid = 0;
            m_subtaskid = 0;
            m_index = 0;
            m_icon_name = string.Empty;
            m_type = swm.RoleTaskIconType.None;
            m_state = swm.IconDisplayType.None;
            m_typeparams.Clear();
        }

        public void RefreshData(swm.RoleTaskIconDiaplay msg)
        {
            Clear();
            m_taskid = msg.taskid;
            m_subtaskid = msg.subtaskid;
            m_index = msg.index;
            m_type = msg.type;
            m_state = msg.state;
            m_icon_name = msg.icon_name;
            for (int i =0;i<msg.typeparamsLength;i++)
            {
                m_typeparams.Add(msg.typeparams(i));
            }
        }
    }

    public class TaskIconDisplayMgr
    {
        private List<TaskIconDisplayInfo> m_TaskIconInfoList = new List<TaskIconDisplayInfo>(Bokura.ConstValue.kCap32);
        private List<TaskIconDisplayInfo> m_TaskIconInfoListPool = new List<TaskIconDisplayInfo>(Bokura.ConstValue.kCap32);

        public List<TaskIconDisplayInfo> TaskIconInfoList
        {
            get
            {
                return m_TaskIconInfoList;
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            BackAllToPool();
        }

        private void BackAllToPool()
        {
            for (int i = 0; i < m_TaskIconInfoList.Count; i++)
            {
                m_TaskIconInfoList[i].Clear();
                m_TaskIconInfoListPool.Add(m_TaskIconInfoList[i]);
            }
            m_TaskIconInfoList.Clear();
        }

        private TaskIconDisplayInfo GetTaskIconDisplayInfoFromPool()
        {
            TaskIconDisplayInfo _data = null;
            if (m_TaskIconInfoListPool.Count > 0)
            {
                _data = m_TaskIconInfoListPool[0];
                m_TaskIconInfoListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new TaskIconDisplayInfo();
            }
            return _data;
        }

        /// <summary>
        /// 通过id获取使用icon的数据
        /// </summary>
        /// <param name="_taskId"></param>
        /// <returns></returns>
        public TaskIconDisplayInfo GetTaskIconDisplayByTaskId(uint _taskId)
        {
            TaskIconDisplayInfo _data = null;
            TaskIconDisplayInfo _tmpData = null;
            for (int i = 0; i < m_TaskIconInfoList.Count; i++)
            {
                _tmpData = m_TaskIconInfoList[i];
                if (_tmpData.m_taskid == _taskId)
                {
                    _data = _tmpData;
                    break;
                }
            }
            return _data;
        }

        private List<TaskIconDisplayInfo> m_tempIconDisplayList = new List<TaskIconDisplayInfo>(Bokura.ConstValue.kCap4);
        /// <summary>
        /// 检查是否有对npc使用的道具列表
        /// </summary>
        /// <param name="_baseid"></param>
        /// <returns></returns>
        public List<TaskIconDisplayInfo> CheckNpcIsHasIconDisplay(uint _baseid)
        {
            m_tempIconDisplayList.Clear();
            TaskIconDisplayInfo _tmpData = null;
            for (int i = 0; i < m_TaskIconInfoList.Count; i++)
            {
                _tmpData = m_TaskIconInfoList[i];
                if (_tmpData.m_state == swm.IconDisplayType.ClientConfirm)
                {
                    uint _npcBaseId = (uint)_tmpData.GetTypeParamByIndex(1);
                    if(_npcBaseId == _baseid)
                    {
                        m_tempIconDisplayList.Add(_tmpData);
                    }
                }
            }
            return m_tempIconDisplayList;
        }



        [XLua.BlackList]
        public TaskIconDisplayInfo AddTaskIconDiaplay(swm.RoleTaskIconDiaplay _msg)
        {
            TaskIconDisplayInfo _data = null;
            if (_msg.state == swm.IconDisplayType.Add || _msg.state == swm.IconDisplayType.ClientConfirm)
            {
                TaskIconDisplayInfo _tmpData = GetTaskIconDisplayByTaskId(_msg.taskid);
                if (_tmpData == null)
                {
                    _data = GetTaskIconDisplayInfoFromPool();
                    _data.RefreshData(_msg);
                    m_TaskIconInfoList.Add(_data);
                }
                else
                {
                    _tmpData.RefreshData(_msg);
                }
            }
            ///_data有值 就是增加 没有就是刷新
            return _data;
        }

        [XLua.BlackList]
        public bool RemoveTaskIconDiaplay(swm.RoleTaskIconDiaplay _msg)
        {
            bool _b = false;
            if (_msg.state == swm.IconDisplayType.Delete)
            {
                TaskIconDisplayInfo _tmpData = null;
                for (int i = 0; i < m_TaskIconInfoList.Count; i++)
                {
                    _tmpData = m_TaskIconInfoList[i];
                    if (_tmpData.m_taskid == _msg.taskid)
                    {
                        _b = true;
                        _tmpData.Clear();
                        m_TaskIconInfoListPool.Add(_tmpData);
                        m_TaskIconInfoList.RemoveAt(i);
                        break;
                    }
                }
            }
            return _b;
        }
    }



    /// <summary>
    /// 任务
    /// </summary>
    public class MissionInfoData
    {
        public class Element
        {
            public int index = 0;
            public int cur = 0;
            public int max = 0;
            public string trace = string.Empty;
            public string execute = string.Empty;
            public swm.TargetDisplayType display_type = swm.TargetDisplayType.Common;
            public string detail_trace = string.Empty;
            public swm.TaskElemType elem_type = swm.TaskElemType.None;

            [XLua.BlackList]
            public void clear()
            {
                index = 0;
                cur = 0;
                max = 0;
                trace = string.Empty;
                execute = string.Empty;

                display_type = swm.TargetDisplayType.Common;
                detail_trace = string.Empty;
                elem_type = swm.TaskElemType.None;
            }
            public Element(swm.RoleTaskElem _roleElement)
            {
                Refresh(_roleElement);

            }
            [XLua.BlackList]
            public void Refresh(swm.RoleTaskElem _roleElement)
            {
                index           = _roleElement.index;
                cur             = (int)_roleElement.var;
                max             = (int)_roleElement.tar;
                trace           = _roleElement.trace_script;
                execute         = _roleElement.execute;
                display_type    = _roleElement.display_type;
                detail_trace    = _roleElement.detail_trace;
                elem_type       = _roleElement.elem_type;
            }
            public bool isDone()
            {
                return cur >= max;
            }

            public string GetTraceDoingDescribe()
            {
                //string str = Utilities.BuildFormatString("{0}{1}\n", trace, GetCurrentProgressDes());
                return trace;
            }

            public string GetCurrentProgressDes()
            {
                string str = String.Empty;
                if (max >= 1)
                    str = Utilities.BuildFormatString("({0}/{1})", cur, max);
                else
                    str = "";
                return str;
            }
        }
        

        private bool m_bIsDirty = false;
        private uint m_missionId = 0;

        private swm.TaskState m_MissionState = swm.TaskState.Nothing;

        private List<Element> m_TaskElements = new List<Element>(Bokura.ConstValue.kCap4);
        private string m_missionName = string.Empty;
        private swm.RoleTaskType m_missionType = swm.RoleTaskType.None;
        private byte m_ringtype = 0;
        private bool m_getUp = false;
        private string m_chapter = string.Empty;
        private string m_type_name = string.Empty;
        /// <summary>
        /// 是否自动任务
        /// </summary>
        private bool m_auto_task = false;

        private uint m_auto_trace = 1;        // 是否自动追踪(0:箭头方式, 1:自动寻路) 

        private swm.TaskQuality m_quality = swm.TaskQuality.White;
        private int m_level = 0;
        private string m_describe = string.Empty;
        private string m_resume_desc = string.Empty;     // 任务简述(任务追踪面板显示)
        private uint m_done_num = 0;
        private uint m_limit_num = 0;

        private string m_accpetTrace = string.Empty;
        private string m_commitTrace = string.Empty;
        private string m_failTrace = string.Empty;

        private string m_accpetExecute = string.Empty;
        private string m_commitExecute = string.Empty;
        private string m_failExecute = string.Empty;
        private ulong m_time_limit = 0;
        private ulong m_accept_time = 0;
        private string m_add_effect = string.Empty;
        private string m_done_effect = string.Empty;

        private List<uint> m_nextidlist = new List<uint>(Const.kCap8);

        private uint m_triggerid = 0;//任务有触发器id的有这个值

        private bool m_Visible = true;//客户端记录显示用

        private uint m_startNpc = 0;//起始npc
        public uint StartNpc { get { return m_startNpc; } set { m_startNpc = value; } }

        private uint m_endNpc = 0;//结束npc
        public uint EndNpc { get { return m_endNpc; } set { m_endNpc = value; } }

        public uint MissionId { get { return m_missionId; } set { m_missionId = value; } }
        public string MissionName { get { return m_missionName; } }

        public string Chapter { get { return m_chapter; } }

        public string type_name { get { return m_type_name; } }
        public swm.RoleTaskType MissionType { get { return m_missionType; } }
        public byte Ringtype { get { return m_ringtype; } }
        public swm.TaskState missionState { get { return m_MissionState; } set { m_MissionState = value; } }
        public swm.TaskQuality Quality { get { return m_quality; } }
        public uint Done_Num { get { return m_done_num; } }
        public uint Limit_Num { get { return m_limit_num; } }
        public int Level { get { return m_level; } }
        public string Describe { get { return m_describe; } set { m_describe = value; } }
        public string Resume_desc { get { return m_resume_desc; } set { m_resume_desc = value; } }
        public ulong Time_limit { get { return m_time_limit; } set { m_time_limit = value; } }
        public ulong Accept_time { get { return m_accept_time; } set { m_accept_time = value; } }

        public string Add_Effect { get { return m_add_effect; } }

        public string Done_Effect { get { return m_done_effect; } }
        public bool IsDirty
        {
            set
            {
                m_bIsDirty = value;
            }
            get
            {
                return m_bIsDirty;
            }
        }

        public bool IsCanGiveUp { get { return m_getUp; } }

        public bool AutoTask { get { return m_auto_task; } }

        public uint Auto_trace { get { return m_auto_trace; } }

        public string AccpetExecute { get { return m_accpetExecute; } }
        public string CommitExecute { get { return m_commitExecute; } }
        public string FailExecute { get { return m_failExecute; } }

        public uint Triggerid { get { return m_triggerid; } }

        public bool Visible
        {
            get
            {
                return m_Visible;
            }
            set
            {
                m_Visible = value;
            }
        }

        /// <summary>
        /// 下列任务id列表数目
        /// </summary>
        public int NextTaskIdListNum
        {
            get { return m_nextidlist.Count; }
        }

        /// <summary>
        /// 根据索引获取下一个任务id
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public uint GetNextTaskIdByIndex(int index)
        {
            if (index < 0 || index >= m_nextidlist.Count)
                return 0;

            return m_nextidlist[index];
        }

        [XLua.BlackList]
        public void clear()
        {
           m_bIsDirty           = false;
           m_missionId          = 0;
           m_MissionState       = swm.TaskState.Nothing;
           m_TaskElements.Clear();
           m_missionName        = string.Empty;
           m_chapter            = string.Empty;
           m_type_name          = string.Empty;
           m_missionType        = swm.RoleTaskType.None;
           m_getUp              = false;
           m_quality            = swm.TaskQuality.White;
           m_ringtype           = 0;
           m_done_num           = 0;
           m_limit_num          = 0;
           m_level              = 0;
           m_time_limit         = 0;
           m_accept_time        = 0;
           m_describe           = string.Empty;
           m_resume_desc        = string.Empty;
           m_accpetTrace        = string.Empty;
           m_commitTrace        = string.Empty;
           m_failTrace          = string.Empty;
           m_accpetExecute      = string.Empty;
           m_commitExecute      = string.Empty;
           m_failExecute        = string.Empty;
           m_auto_trace         = 1;
           m_auto_task          = false;
           m_triggerid          = 0;
           m_Visible            = true;
           m_add_effect         = string.Empty;
           m_done_effect        = string.Empty;
           m_startNpc           = 0;
           m_endNpc             = 0;
        }
        [XLua.BlackList]
        public void Decode(swm.RoleTaskData _info)
        {
            m_missionId         = _info.taskid;
            m_missionType       = _info.type;
            m_ringtype          = _info.ringtype;
            m_missionName       = _info.name;
            m_quality           = _info.quality;
            m_level             = _info.level;
            m_getUp             = _info.forbiddel > 0;
            m_auto_task         = _info.auto_task > 0;
            m_done_num          = _info.done_num;
            m_limit_num         = _info.limit_num;
            m_auto_trace        = _info.auto_trace;
            m_chapter           = _info.chapter;
            m_type_name         = _info.type_name;

            m_accpetTrace       = _info.accept_trace;
            m_commitTrace       = _info.done_trace;
            m_failTrace         = _info.fail_trace;

            m_accpetExecute     = _info.accept_execute;
            m_commitExecute     = _info.done_execute;
            m_failExecute       = _info.fail_execute;

            m_describe          = _info.desc;
            m_resume_desc       = _info.resume_desc;
            m_time_limit        = _info.time_limit;
            m_accept_time       = _info.accept_time;
            m_triggerid         = _info.triggerid;
            m_add_effect        = _info.add_effect;
            m_done_effect       = _info.done_effect;
            m_endNpc = _info.endnpc;
            if (m_triggerid != 0)
            {
                if(null != TriggerManager.Instance.GetCurrentEnterTrigger((int)m_triggerid))
                {
                    m_Visible = true;
                }
                else
                {
                    m_Visible = false;
                }
            }
            Refresh(_info);
        }

        [XLua.BlackList]
        public void Refresh(swm.RoleTaskData _info)
        {
            m_MissionState = _info.state;
            m_TaskElements.Clear();
            for (int i = 0; i < _info.elemsLength; i++)
            {
                swm.RoleTaskElem _el = _info.elems(i).Value;
                m_TaskElements.Add(new Element(_el));
            }

            // 下一步任务id
            m_nextidlist.Clear();
            for (int i = 0; i < _info.next_listLength; i++)
            {
                uint nexttaskid = _info.next_list(i);
                m_nextidlist.Add(nexttaskid);
            }
        }

//         /// <summary>
//         /// 刷新任务中图标显示
//         /// </summary>
//         [XLua.BlackList]
//         public void RefreshTaskIconDiaplay(swm.RoleTaskIconDiaplay msg)//byte index, uint itemid, bool state)
//         {
//             if(msg.type == swm.RoleTaskIconType.TaskItem)
//             {
//                 if (msg.index >= 0 && msg.index < m_TaskElements.Count)
//                 {
//                     Element tTaskE = m_TaskElements[msg.index];
//                     if (null != tTaskE)
//                     {
//                         tTaskE.itemId = (uint)msg.typeparams(0);
//                         tTaskE.showItem = msg.state;
//                     }
//                 }
//             }
// 
//         }
        [XLua.BlackList]
        public void Refresh(swm.CanAcceptRoleTaskData _info)
        {
            m_MissionState = swm.TaskState.Give;
            m_missionId = _info.taskid;
            m_missionType = (swm.RoleTaskType)_info.type;
            m_missionName = _info.name;
            m_chapter = _info.chapter;
            m_type_name = _info.type_name;
            m_level = _info.level;
            m_getUp = false;
            m_accpetTrace = _info.accept_trace;
            m_accpetExecute = _info.accept_execute;
           // m_describe = _info.desc;
            m_auto_task = _info.auto_task > 0;
            m_auto_trace = _info.auto_trace;
            m_startNpc = _info.startnpc;
            

            // 下一步任务id
            m_nextidlist.Clear();
            for (int i = 0; i < _info.next_listLength; i++)
            {
                uint nexttaskid = _info.next_list(i);
                m_nextidlist.Add(nexttaskid);
            }
        }

        public void RefreshElement(int index, int curvalue)
        {
            for (int i = 0; i < m_TaskElements.Count; i++)
            {
                if (index == m_TaskElements[i].index)
                {
                    m_TaskElements[i].cur = curvalue;
                }

            }
        }
        /// <summary>
        /// 获得当前执行的元素顺序 
        /// </summary>
        /// <returns></returns>
        public int GetElementCurrentDoIndex()
        {
            int _index = -1;
            if (m_TaskElements != null && m_TaskElements.Count > 0)
            {
                for (int i = 0; i < m_TaskElements.Count; i++)
                {
                    Element _element = m_TaskElements[i];
                    if (_element.cur < _element.max)
                    {
                        _index = (int)_element.index;
                        break;
                    }
                }
            }
            return _index;
        }

        public Element GetMissionElementByIndex(int _index)
        {
            if (_index < m_TaskElements.Count)
            {
                return m_TaskElements[_index];
            }
            return null;
        }

        /// <summary>
        /// 是否任务正在做
        /// </summary>
        /// <returns></returns>
        public bool IsTaskDoing()
        {
            return missionState == swm.TaskState.Doing;
        }

        /// <summary>
        /// 是否任务做完了
        /// </summary>
        /// <returns></returns>
        public bool IsTaskDone()
        {
            return missionState == swm.TaskState.Done;
        }

        /// <summary>
        /// 获取任务在当前状态下的追踪元素数量
        /// </summary>
        public int traceElementCount
        {
            get
            {
                return m_TaskElements.Count;
            }
        }



        /// <summary>
        /// 获取任务在当前状态下的特定追踪描述
        /// </summary>
        public string GetTraceDescribe(int index)
        {
            string str = "";
            switch (missionState)
            {
                case swm.TaskState.Doing:
                    if (index >= 0 && index < m_TaskElements.Count)
                    {
                        Element tElement = m_TaskElements[index];
                        str = tElement.GetTraceDoingDescribe();
//                         if (tElement.max > 1)
//                             str = Utilities.BuildFormatString("{0}({1}/{2})\n", tElement.trace, tElement.cur, tElement.max);
//                         else
//                             str = Utilities.BuildFormatString("{0}\n", tElement.trace);
                    }
                    break;
                case swm.TaskState.Done:
                    str = m_commitTrace;
                    break;
                case swm.TaskState.Fail:
                    str = m_failTrace;
                    break;
                case swm.TaskState.Give:
                    str = m_accpetTrace;
                    break;
                default:
                    str = "(未知任务状态)";
                    break;
            }
            if(null == str)
            {
                str = "";
            }
            return str;
        }



        /// <summary>
        /// 获取进行中任务的元素
        /// </summary>
        public Element GetElement(int index)
        {
            Element tResult = null;
            switch (missionState)
            {
                case swm.TaskState.Doing:
                    if (index >= 0 && index < m_TaskElements.Count)
                        tResult = m_TaskElements[index];
                    break;
            }
            return tResult;
        }

        public string GetDetailTrace()
        {
            switch (missionState)
            {
                case swm.TaskState.Doing:
                    {
                        for (int i = 0; i < m_TaskElements.Count; i++)
                        {
                            if (!m_TaskElements[i].isDone())
                            {
                                return m_TaskElements[i].detail_trace;
                            }
                        }
                        return string.Empty;
                    }
                case swm.TaskState.Done:
                case swm.TaskState.Fail:
                case swm.TaskState.Give:
                default:
                    return string.Empty;
            }
        }

        public string GetTraceExecute()
        {
            switch (missionState)
            {
                case swm.TaskState.Doing:
                    {
                        for (int i = 0; i < m_TaskElements.Count; i++)
                        {
                            if (!m_TaskElements[i].isDone())
                            {
                                return m_TaskElements[i].execute;//"gotopos({x=10,y=10,z=10})"; //
                            }
                        }
                        return string.Empty;
                    }
                case swm.TaskState.Done:
                    return CommitExecute;
                case swm.TaskState.Fail:
                    return FailExecute;
                case swm.TaskState.Give:
                    return AccpetExecute;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// 指定的taskid是不是下一步id
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns></returns>
        public bool IsNextTaskId(uint taskid)
        {
            return m_nextidlist.Contains(taskid);
        }
    }
}
