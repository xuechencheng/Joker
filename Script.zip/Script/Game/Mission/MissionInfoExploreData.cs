﻿using System;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 势力 探索任务的奖励
    /// </summary>
    public class ExploreAwardData
    {
        private uint m_baseid = 0;
        private uint m_num = 0;
        public uint BaseId
        {
            get
            {
                return m_baseid;
            }
        }
        public uint Num
        {
            get
            {
                return m_num;
            }
        }
        [XLua.BlackList]
        public void Refresh(uint _baseId, uint _num)
        {
            m_baseid = _baseId;
            m_num = _num;
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_baseid = 0;
            m_num = 0;
        }
    }
    /// <summary>
    /// 势力 探索任务数据
    /// </summary>
    public class ExploreMissionData
    {
        private uint m_taskid;
        private swm.RoleTaskType m_type;
        private string m_name;
        private string m_desc;
        private swm.TaskQuality m_quality;
        private ulong m_expaward;
        private swm.TaskState m_state;
        private List<ExploreAwardData> m_ExploreAwardDataList = new List<ExploreAwardData>(Bokura.ConstValue.kCap32);
        private List<ExploreAwardData> m_ExploreAwardDataListPool = new List<ExploreAwardData>(Bokura.ConstValue.kCap32);


        private List<MissionInfoData.Element> m_TaskElements = new List<MissionInfoData.Element>(Bokura.ConstValue.kCap4);
        private List<MissionInfoData.Element> m_TaskElementsPool = new List<MissionInfoData.Element>(Bokura.ConstValue.kCap4);
        public List<ExploreAwardData> ExploreAwardDataList
        {
            get
            {
                return m_ExploreAwardDataList;
            }
        }
        public uint taskId
        {
            get
            {
                return m_taskid;
            }
        }

        public swm.RoleTaskType Type
        {
            get
            {
                return m_type;
            }
        }

        public string Name
        {
            get
            {
                return m_name;
            }
        }

        public string Desc
        {
            get
            {
                return m_desc;
            }
        }
        public swm.TaskQuality Quality
        {
            get
            {
                return m_quality;
            }
        }
        public ulong Expaward
        {
            get
            {
                return m_expaward;
            }
        }
        public swm.TaskState State
        {
            get
            {
                return m_state;
            }
            set
            {
                m_state = value;
            }
        }

        public  int GetElementCount()
        {
            return m_TaskElements.Count;
        }

        public MissionInfoData.Element GetMissionElementByIndex(int _index)
        {
            if (_index < m_TaskElements.Count)
            {
                return m_TaskElements[_index];
            }
            return null;
        }

//         public string GetElementDescribe()
//         {
//             string str = string.Empty;
//             for (int i = 0; i < m_TaskElements.Count; i++)
//             {
//                 string _des = m_TaskElements[i].GetTraceDoingDescribe();
//                 str = Utilities.BuildString(str, _des);
//             }
//             return str;
//         }

        private void BackToPool()
        {
            for (int i = 0; i < m_ExploreAwardDataList.Count; i++)
            {
                m_ExploreAwardDataListPool.Add(m_ExploreAwardDataList[i]);
            }
            m_ExploreAwardDataList.Clear();

            for (int i = 0; i < m_TaskElements.Count; i++)
            {
                m_TaskElementsPool.Add(m_TaskElements[i]);
            }
            m_TaskElements.Clear();
        }

        private ExploreAwardData GetExploreAwardDataFromPool()
        {
            ExploreAwardData _data = null;
            if (m_ExploreAwardDataListPool.Count > 0)
            {
                _data = m_ExploreAwardDataListPool[0];
                m_ExploreAwardDataListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new ExploreAwardData();
            }
            return _data;
        }

        private MissionInfoData.Element GetExploreTaskElementFromPool(swm.RoleTaskElem _el)
        {
            MissionInfoData.Element _data = null;
            if (m_TaskElementsPool.Count > 0)
            {
                _data = m_TaskElementsPool[0];
                m_TaskElementsPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new MissionInfoData.Element(_el);
            }
            _data.Refresh(_el);
            return _data;
        }

        [XLua.BlackList]
        public void Refresh(swm.ExploreTaskData _info)
        {
            BackToPool();
            m_taskid = _info.taskid;
            m_type = _info.type;
            m_name = _info.name;
            m_desc = _info.desc;
            m_quality = _info.quality;
            m_expaward = _info.expaward;
            m_state = _info.state;

            for (int i = 0; i < _info.itemsawardLength; i++)
            {
                swm.Award _exploreData = _info.itemsaward(i).Value;
                ExploreAwardData _data = GetExploreAwardDataFromPool();
                _data.Refresh(_exploreData.baseid, _exploreData.num);
                m_ExploreAwardDataList.Add(_data);
            }

            for (int i = 0; i < _info.elemsLength; i++)
            {
                swm.RoleTaskElem _el = _info.elems(i).Value;
                MissionInfoData.Element _data = GetExploreTaskElementFromPool(_el);
                m_TaskElements.Add(_data);
            }
        }
    }
    /////
    ///势力任务
    /// <summary>
    /// 势力 探索任务 委托榜消息
    /// </summary>
    public class ExploreEntrustInfo
    {
        private uint m_baseid;// 委托榜npc
        private ulong m_time;// 时间戳
        private uint m_fieldid;// 对应的势力ID
        private byte m_refreshmax;// 当前势力可刷新多少次
        private byte m_refreshnum;// 当前势力已经刷新过多少次
        private byte m_dailymax;// 所有势力最大次数
        private byte m_dailydone;// 所有势力今天多少次
        private byte m_fieldmax;//当前势力可做次数
        private byte m_fielddone;//当前势力已经完成次数
        private uint m_orderid;// 对应的orderID

        private List<ExploreMissionData> m_ExploreMissionDataList = new List<ExploreMissionData>(Bokura.ConstValue.kCap32);
        private List<ExploreMissionData> m_ExploreMissionDataListPool = new List<ExploreMissionData>(Bokura.ConstValue.kCap32);
        public uint BaseId
        {
            get
            {
                return m_baseid;
            }
        }
        public ulong Time
        {
            get
            {
                return m_time;
            }
        }

        public uint Fieldid
        {
            get
            {
                return m_fieldid;
            }
        }

        public byte Refreshmax
        {
            get
            {
                return m_refreshmax;
            }
        }

        public byte Refreshnum
        {
            get
            {
                return m_refreshnum;
            }
        }

        public byte Dailymax
        {
            get
            {
                return m_dailymax;
            }
        }

        public byte Dailydone
        {
            get
            {
                return m_dailydone;
            }
        }

        public byte Fieldmax
        {
            get
            {
                return m_fieldmax;
            }
        }

        public byte Fielddone
        {
            get
            {
                return m_fielddone;
            }
        }

        public uint Orderid
        {
            get
            {
                return m_orderid;
            }
        }



        public List<ExploreMissionData> ExploreMissionDataList
        {
            get
            {
                return m_ExploreMissionDataList;
            }
        }
        private void BackToPool()
        {
            for (int i = 0; i < m_ExploreMissionDataList.Count; i++)
            {
                m_ExploreMissionDataListPool.Add(m_ExploreMissionDataList[i]);
            }
            m_ExploreMissionDataList.Clear();
        }
        private ExploreMissionData GetExploreMissionDataFromPool()
        {
            ExploreMissionData _data = null;
            if (m_ExploreMissionDataListPool.Count > 0)
            {
                _data = m_ExploreMissionDataListPool[0];
                m_ExploreMissionDataListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new ExploreMissionData();
            }
            return _data;
        }

        [XLua.BlackList]
        public void Refresh(swm.RspEntrustList _info)
        {
            BackToPool();
            m_baseid = _info.baseid;
            m_time = _info.time;
            m_fieldid = _info.fieldid;// 对应的势力ID
            m_refreshmax = _info.refreshmax;// 当前势力可刷新多少次
            m_refreshnum = _info.refreshnum;// 当前势力已经刷新过多少次
            m_dailymax = _info.dailymax;// 所有势力最大次数
            m_dailydone = _info.dailydone;// 所有势力今天多少次
            m_fieldmax = _info.fieldmax;//当前势力可做次数
            m_fielddone = _info.fielddone;//当前势力已经完成次数
            m_orderid = _info.orderid;// 对应的orderID
            for (int i = 0; i < _info.expltasklistLength; i++)
            {
                swm.ExploreTaskData? _exploreData = _info.expltasklist(i);
                AddExploreMissionData(_exploreData.Value);
            }
        }

        public void ResetTaskState(uint _taskId, swm.TaskState _state)
        {
            for (int i = 0; i < m_ExploreMissionDataList.Count; i++)
            {
                ExploreMissionData _data = m_ExploreMissionDataList[i];
                if (_data.taskId == _taskId)
                {
                    _data.State = _state;
                }
            }
        }

        public ExploreMissionData AddExploreMissionData(swm.ExploreTaskData _exploreData)
        {
            ExploreMissionData _data = GetExploreMissionDataFromPool();
            _data.Refresh(_exploreData);
            m_ExploreMissionDataList.Add(_data);
            return _data;
        }
    }
    /////
}
