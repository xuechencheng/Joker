using System;
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    ///势力世界任务

    /// <summary>
    /// 势力世界任务 势力开启状态数据
    /// </summary>
//     public class ForceWorldOpenData
//     {
//         private uint m_ForceId = 0;
//         private bool m_state = false;
// 
//         public uint ForceId
//         {
//             get
//             {
//                 return m_ForceId;
//             }
//         }
// 
//         public bool State
//         {
//             get
//             {
//                 return m_state;
//             }
//         }
//         [XLua.BlackList]
//         public void Refresh(uint _forceId, bool _state)
//         {
//             m_ForceId = _forceId;
//             m_state = _state;
//         }
//         [XLua.BlackList]
//         public void Clear()
//         {
//             m_ForceId = 0;
//             m_state = false;
//         }
//     }

    /// <summary>
    /// 势力世界任务 返回势力世界任务势力开启状态
    /// </summary>
//     public class ForceWorldOpenState
//     {
//         private uint m_perfectureId = 0;
//         private List<ForceWorldOpenData> m_ForceWorldOpenDataList = new List<ForceWorldOpenData>(Bokura.ConstValue.kCap32);
//         private List<ForceWorldOpenData> m_ForceWorldOpenDataListPool = new List<ForceWorldOpenData>(Bokura.ConstValue.kCap32);
//         public uint PerFectureId
//         {
//             get
//             {
//                 return m_perfectureId;
//             }
//         }
// 
//         public List<ForceWorldOpenData> ForceWorldOpenDataList
//         {
//             get
//             {
//                 return m_ForceWorldOpenDataList;
//             }
//         }
// 
//         public void Clear()
//         {
//             m_perfectureId = 0;
//             BackAllToPool();
//         }
// 
//         private void BackAllToPool()
//         {
//             for (int i = 0; i < m_ForceWorldOpenDataList.Count; i++)
//             {
//                 m_ForceWorldOpenDataList[i].Clear();
//                 m_ForceWorldOpenDataListPool.Add(m_ForceWorldOpenDataList[i]);
//             }
//             m_ForceWorldOpenDataList.Clear();
//         }
// 
//         private ForceWorldOpenData GetForceWorldOpenDataFromPool()
//         {
//             ForceWorldOpenData _data = null;
//             if (m_ForceWorldOpenDataListPool.Count > 0)
//             {
//                 _data = m_ForceWorldOpenDataListPool[0];
//                 m_ForceWorldOpenDataListPool.RemoveAt(0);
//             }
//             if (_data == null)
//             {
//                 _data = new ForceWorldOpenData();
//             }
//             return _data;
//         }
// 
//         [XLua.BlackList]
//         public void Init(swm.RsqForceWorldOpenState _msg)
//         {
//             BackAllToPool();
//             m_perfectureId = _msg.perfecture_id;
//             for (int i = 0; i < _msg.open_listLength; i++)
//             {
//                 swm.ForceOpenState _netData = _msg.open_list(i).Value;
//                 ForceWorldOpenData _stateData = GetForceWorldOpenDataFromPool();
//                 _stateData.Refresh(_netData.force_id, _netData.state);
//                 m_ForceWorldOpenDataList.Add(_stateData);
//             }
//         }
//     }

    /// <summary>
    /// 势力世界任务 势力世界任务信息数据
    /// </summary>
//     public class ForceWorldTaskInfoData
//     {
//         private uint m_TaskId = 0;
//         private string m_Name = string.Empty;
//         private uint m_State = 0;
//         private List<ExploreAwardData> m_AwardDataList = new List<ExploreAwardData>(Bokura.ConstValue.kCap32);
//         private List<ExploreAwardData> m_AwardDataListPool = new List<ExploreAwardData>(Bokura.ConstValue.kCap32);
// 
//         public uint TaskId
//         {
//             get
//             {
//                 return m_TaskId;
//             }
//         }
// 
//         public string Name
//         {
//             get
//             {
//                 return m_Name;
//             }
//         }
// 
//         public uint State
//         {
//             get
//             {
//                 return m_State;
//             }
//         }
//         public List<ExploreAwardData> AwardDataList
//         {
//             get
//             {
//                 return m_AwardDataList;
//             }
//         }
//         [XLua.BlackList]
//         public void Clear()
//         {
//             m_TaskId = 0;
//             m_Name = string.Empty;
//             m_State = 0;
//             BackAllToPool();
//         }
//         private void BackAllToPool()
//         {
//             for (int i = 0; i < m_AwardDataList.Count; i++)
//             {
//                 m_AwardDataList[i].Clear();
//                 m_AwardDataListPool.Add(m_AwardDataList[i]);
//             }
//             m_AwardDataList.Clear();
//         }
//         private ExploreAwardData GetAwardDataFromPool()
//         {
//             ExploreAwardData _data = null;
//             if (m_AwardDataListPool.Count > 0)
//             {
//                 _data = m_AwardDataListPool[0];
//                 m_AwardDataListPool.RemoveAt(0);
//             }
//             if (_data == null)
//             {
//                 _data = new ExploreAwardData();
//             }
//             return _data;
//         }
// 
//         [XLua.BlackList]
//         public ExploreAwardData AddAwardToList(swm.Award _netData)
//         {
//             ExploreAwardData _stateData = GetAwardDataFromPool();
//             _stateData.Refresh(_netData.baseid, _netData.num);
//             m_AwardDataList.Add(_stateData);
//             return _stateData;
//         }
// 
//         [XLua.BlackList]
//         public void Init(swm.ForceWorldTaskInfo _msg)
//         {
//             BackAllToPool();
//             m_TaskId    = _msg.taskid;
//             m_Name      = _msg.name;
//             m_State     = _msg.state;
//             for(int i=0;i< _msg.awardLength;i++)
//             {
//                 AddAwardToList(_msg.award(i).Value);
//             }
//         }
//     }

    /// <summary>
    /// 势力世界任务 势力世界任务列表
    /// </summary>
//     public class ForceWorldTaskList
//     {
//         private uint m_ForceId = 0;
//         private List<ForceWorldTaskInfoData> m_ForceWorldTaskInfoDataList = new List<ForceWorldTaskInfoData>(Bokura.ConstValue.kCap32);
//         private List<ForceWorldTaskInfoData> m_ForceWorldTaskInfoDataListPool = new List<ForceWorldTaskInfoData>(Bokura.ConstValue.kCap32);
// 
//         public uint ForceId
//         {
//             get
//             {
//                 return m_ForceId;
//             }
//         }
// 
//         public List<ForceWorldTaskInfoData> ForceWorldTaskInfoDataList
//         {
//             get
//             {
//                 return m_ForceWorldTaskInfoDataList;
//             }
//         }
// 
//         [XLua.BlackList]
//         public void Clear()
//         {
//             m_ForceId = 0;
//             BackAllToPool();
//         }
// 
//         private void BackAllToPool()
//         {
//             for (int i = 0; i < m_ForceWorldTaskInfoDataList.Count; i++)
//             {
//                 m_ForceWorldTaskInfoDataList[i].Clear();
//                 m_ForceWorldTaskInfoDataListPool.Add(m_ForceWorldTaskInfoDataList[i]);
//             }
//             m_ForceWorldTaskInfoDataList.Clear();
//         }
// 
//         private ForceWorldTaskInfoData GetForceWorldTaskInfoDataFromPool()
//         {
//             ForceWorldTaskInfoData _data = null;
//             if (m_ForceWorldTaskInfoDataListPool.Count > 0)
//             {
//                 _data = m_ForceWorldTaskInfoDataListPool[0];
//                 m_ForceWorldTaskInfoDataListPool.RemoveAt(0);
//             }
//             if (_data == null)
//             {
//                 _data = new ForceWorldTaskInfoData();
//             }
//             return _data;
//         }
// 
//         [XLua.BlackList]
//         public void Init(swm.RspForceWorldTaskList _msg)
//         {
//             BackAllToPool();
//             m_ForceId = _msg.force_id;
//             for(int i =0;i< _msg.force_listLength;i++)
//             {
//                 ForceWorldTaskInfoData _stateData = GetForceWorldTaskInfoDataFromPool();
//                 _stateData.Init(_msg.force_list(i).Value);
//                 m_ForceWorldTaskInfoDataList.Add(_stateData);
//             }
//         }
//     }

    /// <summary>
    /// 势力世界任务 势力任务槽状态
    /// </summary>
    public class ForceWorldTaskState
    {
        private uint m_TriggerId = 0;//触发器id
        private uint m_TaskId = 0;// 任务id 
        private swm.TaskQuality m_Qulity = swm.TaskQuality.Max;//任务品质
        private swm.TaskState m_TaskState = swm.TaskState.Nothing;//任务状态
        private uint m_forceid = 0;//势力id
        public uint TaskId
        {
            get
            {
                return m_TaskId;
            }
        }

        public swm.TaskQuality Qulity
        {
            get
            {
                return m_Qulity;
            }
        }

        public uint TriggerId
        {
            get
            {
                return m_TriggerId;
            }
        }

        public swm.TaskState TaskState
        {
            get
            {
                return m_TaskState;
            }
        }

        public uint ForceId
        {
            get
            {
                return m_forceid;
            }
        }
        [XLua.BlackList]
        public void Init(swm.ForceWorldTaskData _info)
        {
            m_TriggerId = _info.triggerid;
            m_TaskId = _info.taskid;
            m_Qulity = _info.quality;
            m_TaskState = _info.state;
            m_forceid = _info.forceid;


        }
        [XLua.BlackList]
        public void Clear()
        {
            m_TaskId = 0;
            m_Qulity = swm.TaskQuality.Max;
            m_TriggerId = 0;
            m_TaskState = swm.TaskState.Nothing;
            m_forceid = 0;
        }
    }

    public class ForceWorldGiftBag
    {
        private uint m_itembaseid = 0;//礼包
        private uint m_forceid = 0;// 势力id
        private uint m_cur = 0;// 当前进度
        private uint m_total = 0;// 全部
        private ulong m_stamp = 0;//刷新时间点
        private uint m_receive_npc = 0;// 领取npc
        private bool m_is_receive = false;// 是否已领取
 
        public uint ItemBaseId
        {
            get
            {
                return m_itembaseid;
            }
        }
        public uint ForceId
        {
            get
            {
                return m_forceid;
            }
        }
        public uint Cur
        {
            get
            {
                return m_cur;
            }
        }
        public uint Total
        {
            get
            {
                return m_total;
            }
        }

        public ulong Stamp
        {
            get
            {
                return m_stamp;
            }
        }

        public uint Receive_npc
        {
            get
            {
                return m_receive_npc;
            }
        }

        public bool Is_receive
        {
            get
            {
                return m_is_receive;
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_itembaseid = 0;//礼包
            m_forceid = 0;// 势力id
            m_cur = 0;// 当前进度
            m_total = 0;// 全部
            m_stamp = 0;
            m_receive_npc = 0;// 领取npc
            m_is_receive = false;// 是否已领取
    }

        public void Refresh(swm.ForceGiftBag _netData)
        {
            m_itembaseid    = _netData.itembaseid;
            m_forceid       = _netData.forceid;
            m_cur           = _netData.cur;
            m_total         = _netData.total;
            m_stamp         = _netData.stamp;
            m_receive_npc   = _netData.receive_npc;
            m_is_receive    = _netData.is_receive;
        }

    }

    /// <summary>
    /// 势力世界任务 势力总任务槽
    /// </summary>
    public class ForceWorldTask
    {
        private List<ForceWorldTaskState> m_ForceWorldTaskStateList = new List<ForceWorldTaskState>(Bokura.ConstValue.kCap4);
        private List<ForceWorldTaskState> m_ForceWorldTaskStateListPool = new List<ForceWorldTaskState>(Bokura.ConstValue.kCap4);

        private List<ForceWorldGiftBag> m_AwardDataList = new List<ForceWorldGiftBag>(Bokura.ConstValue.kCap32);
        private List<ForceWorldGiftBag> m_AwardDataListPool = new List<ForceWorldGiftBag>(Bokura.ConstValue.kCap32);



        public List<ForceWorldGiftBag> AwardDataList
        {
            get
            {
                return m_AwardDataList;
            }
        }

        public List<ForceWorldTaskState> ForceWorldTaskStateList
        {
            get
            {
                return m_ForceWorldTaskStateList;
            }
        }

        
        public void Clear()
        {
            BackAllToPool();
            BackAllAwardToPool();
        }

        public ForceWorldGiftBag GetForceWorldGiftBagByForceId(uint _id)
        {
            ForceWorldGiftBag _data;
            for (int i = 0; i < m_AwardDataList.Count; i++)
            {
                _data = m_AwardDataList[i];
                if(_data.ForceId == _id)
                {
                    return _data;
                }
            }
            return null;
        }

        private ForceWorldTaskState GetForceWorldTaskStateFromPool()
        {
            ForceWorldTaskState _data = null;
            if (m_ForceWorldTaskStateListPool.Count > 0)
            {
                _data = m_ForceWorldTaskStateListPool[0];
                m_ForceWorldTaskStateListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new ForceWorldTaskState();
            }
            return _data;
        }

        private ForceWorldGiftBag GetAwardDataFromPool()
        {
            ForceWorldGiftBag _data = null;
            if (m_AwardDataListPool.Count > 0)
            {
                _data = m_AwardDataListPool[0];
                m_AwardDataListPool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new ForceWorldGiftBag();
            }
            return _data;
        }

        public ForceWorldTaskState GetForceWorldTaskStateById(uint _id)
        {
            for (int i = 0; i < m_ForceWorldTaskStateList.Count; i++)
            {
                ForceWorldTaskState _tmpData = m_ForceWorldTaskStateList[i];
                if (_tmpData.TriggerId == _id)
                {
                    return _tmpData;
                }
            }
            return null;
        }

        private void BackAllToPool()
        {
            for (int i = 0; i < m_ForceWorldTaskStateList.Count; i++)
            {
                m_ForceWorldTaskStateList[i].Clear();
                m_ForceWorldTaskStateListPool.Add(m_ForceWorldTaskStateList[i]);
            }
            m_ForceWorldTaskStateList.Clear();
        }

        private void BackAllAwardToPool()
        {
            for (int i = 0; i < m_AwardDataList.Count; i++)
            {
                m_AwardDataList[i].Clear();
                m_AwardDataListPool.Add(m_AwardDataList[i]);
            }
            m_AwardDataList.Clear();
        }

        [XLua.BlackList]
        public void RefreshForceWorldTask(swm.RspForceWorldTasks _msg)
        {
            BackAllToPool();

            for (int i = 0; i < _msg.all_tasksLength; i++)
            {
                AddForceWorldTaskStateToList(_msg.all_tasks(i).Value);
            }

//             for (int i = 0; i < _msg.awardLength; i++)
//             {
//                 AddAwardToList(_msg.award(i).Value);
//             }
        }

        [XLua.BlackList]
        public ForceWorldTaskState AddForceWorldTaskStateToList(swm.ForceWorldTaskData _netData)
        {
            ForceWorldTaskState _stateData = GetForceWorldTaskStateById(_netData.triggerid);
            if (null == _stateData)
            {
                _stateData = GetForceWorldTaskStateFromPool();
                _stateData.Init(_netData);
                m_ForceWorldTaskStateList.Add(_stateData);
            }
            return _stateData;
        }

        [XLua.BlackList]
        public void RefreshNotifyAllForceGiftBag(swm.NotifyAllForceGiftBag _msg)
        {
            BackAllAwardToPool();
            for (int i = 0; i < _msg.force_giftsLength; i++)
            {
                AddAwardToList(_msg.force_gifts(i).Value);
            }
        }

        [XLua.BlackList]
        public ForceWorldGiftBag AddAwardToList(swm.ForceGiftBag _netData)
        {
            ForceWorldGiftBag _stateData = GetAwardDataFromPool();
            _stateData.Refresh(_netData);
            m_AwardDataList.Add(_stateData);
            return _stateData;
        }

        [XLua.BlackList]
        public ForceWorldGiftBag RefreshAwardToList(swm.ForceGiftBag _netData)
        {
            ForceWorldGiftBag _stateData = null;
            for (int i =0;i<m_AwardDataList.Count;i++)
            {
                ForceWorldGiftBag _data = m_AwardDataList[i];
                if(_data.ForceId == _netData.forceid && _data.ItemBaseId == _netData.itembaseid)
                {
                    _stateData = _data;
                    break;
                }
            }
            if(null == _stateData)
            {
                _stateData = AddAwardToList(_netData);
            }
            else
            {
                _stateData.Refresh(_netData);
            }
            return _stateData;
        }
    }
}
