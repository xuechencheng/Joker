using System;
using System.Collections.Generic;
using swm;
using Bokura;
using FlatBuffers;

namespace Bokura
{
    internal class MissionModel : ClientSingleton<MissionModel>
    {
        private Dictionary<uint, NpcTaskStateInfo> m_npcheadstate = new Dictionary<uint, NpcTaskStateInfo>(Bokura.ConstValue.kCap32);//任务npc状态 列表
        private List<NpcTaskStateInfo> m_npcheadstatePool = new List<NpcTaskStateInfo>(Bokura.ConstValue.kCap32);

        private List<uint> m_missionResourceStateList = new List<uint>(Bokura.ConstValue.kCap32);//任务可采集资源 列表

        //数据池
        private List<MissionInfoData> m_MissionInfoPoolList = new List<MissionInfoData>(Bokura.ConstValue.kCap32);
        //可接任务列表
        private List<MissionInfoData> m_acceptTaskList = new List<MissionInfoData>(Bokura.ConstValue.kCap32);
        //已接任务列表(进行中和可交的 doing和done状态的)
        private List<MissionInfoData> m_doingTaskList = new List<MissionInfoData>(Bokura.ConstValue.kCap32);
        //已经完成任务列表
        private List<MissionInfoData> m_doneTaskList = new List<MissionInfoData>(Bokura.ConstValue.kCap32);

        //任务显示功能图标
        private TaskIconDisplayMgr m_TaskIconDisplayManager = new TaskIconDisplayMgr();

        public TaskIconDisplayMgr TaskIconDisplayManager
        {
            get
            {
                return m_TaskIconDisplayManager;
            }
        }

        //势力悬赏 相关
        private ExploreEntrustInfo m_ExploreEntrustInfoData = new ExploreEntrustInfo();//势力任务的委托数据（这个数据委托数据会变的）注意使用

        public ExploreEntrustInfo ExploreEntrustInfoData
        {
            get
            {
                return m_ExploreEntrustInfoData;
            }
        }

        //

        //势力世界任务相关
        private ForceWorldTask m_ForceWorldTaskData = new ForceWorldTask();//势力总任务槽
        public ForceWorldTask ForceWorldTaskData
        {
            get
            {
                return m_ForceWorldTaskData;
            }
        }

        private swm.RspForceWorldTaskInfoT m_TempStoreForceWorldTaskInfo = new RspForceWorldTaskInfoT();

//         private ForceWorldTaskList m_ForceWorldTaskListData = new ForceWorldTaskList();//该势力任务列表(动态变化的数据)
//         public ForceWorldTaskList ForceWorldTaskListData
//         {
//             get
//             {
//                 return m_ForceWorldTaskListData;
//             }
//         }

//         private ForceWorldOpenState m_ForceWorldOpenStateData = new ForceWorldOpenState();//该势力任务状态列表(动态变化的数据)
//         public ForceWorldOpenState ForceWorldOpenStateData
//         {
//             get
//             {
//                 return m_ForceWorldOpenStateData;
//             }
//         }
        ///
        public List<MissionInfoData> AcceptTaskList
        {
            get
            {
                return m_acceptTaskList;
            }
        }

        public List<MissionInfoData> DoingTaskList
        {
            get
            {
                return m_doingTaskList;
            }
        }

        public List<MissionInfoData> DoneTaskList
        {
            get
            {
                return m_doneTaskList;
            }
        }

        public class MissionEvent : GameEvent<MissionInfoData>
        {
        }

        public GameEvent onOpenNpcDialog = new GameEvent();

        public GameEvent onRefreshAcceptTask = new GameEvent();
        public MissionEvent onRemoveAcceptTask = new MissionEvent();
        public MissionEvent onAddAcceptTask = new MissionEvent();
        public MissionEvent onAddAcceptTaskNoIni = new MissionEvent();
        public GameEvent onInitDoingTask = new GameEvent();
        public MissionEvent onAddDoingTask = new MissionEvent();
        public MissionEvent onRefreshDoingTask = new MissionEvent();
        public MissionEvent onRemoveDoingTask = new MissionEvent();

        public MissionEvent onCompletedTask = new MissionEvent();
        public MissionEvent onRemoveDoneTask = new MissionEvent();

        public MissionEvent onStartAutoDoTask = new MissionEvent();

        public GameEvent onAllNpcTaskStateEvent = new GameEvent();
        public GameEvent<uint> onRefreshBaseIdNpcTaskStateEvent = new GameEvent<uint>();

        public class CommitTaskPrizeListEvent : GameEvent<swm.CommitTaskPrizeList>
        {
        }
        public CommitTaskPrizeListEvent onCommitTaskPrizeList = new CommitTaskPrizeListEvent();

        public GameEvent<uint, byte> onMissionResourceStateEvent = new GameEvent<uint, byte>();

        public GameEvent<string> onRefreshRoleTaskInfoEvent = new GameEvent<string>();

        public GameEvent<byte> onAutoSelectNpcDlgOption = new GameEvent<byte>();
        public GameEvent<ExploreEntrustInfo> onGetEntrustInfoEvent = new GameEvent<ExploreEntrustInfo>();
        public GameEvent<uint,swm.TaskState> onExploreTaskStateEvent = new GameEvent<uint, swm.TaskState>();
        public GameEvent<uint, ExploreMissionData> onCheckExploreTaskOrderEvent = new GameEvent<uint, ExploreMissionData>();

        public GameEvent<bool> onManualSubmitItemEvent = new GameEvent<bool>();

        public GameEvent<TaskIconDisplayInfo> onAddTaskIconDiaplay = new GameEvent<TaskIconDisplayInfo>();
        public GameEvent<TaskIconDisplayInfo> onRefreshTaskIconDiaplay = new GameEvent<TaskIconDisplayInfo>();
        public GameEvent<TaskIconDisplayInfo> onRemoveTaskIconDiaplay = new GameEvent<TaskIconDisplayInfo>();

        public GameEvent<string, uint> onPlayTimeLineWithTaskId = new GameEvent<string, uint>();

        //public GameEvent onInitForceWorldTaskStateEvent = new GameEvent();
        //public GameEvent<ForceWorldTaskState> onAddForceWorldTaskStateEvent = new GameEvent<ForceWorldTaskState>();
        //public GameEvent<ForceWorldTaskState> onRefreshForceWorldTaskStateEvent = new GameEvent<ForceWorldTaskState>();
        //public GameEvent<uint, bool> onOpenForceWorldTaskResultEvent = new GameEvent<uint, bool>();
        //public GameEvent onForceWorldTaskListDataChangeEvent = new GameEvent();
        // public GameEvent onForceWorldOpenStateDataChangeEvent = new GameEvent();

        public GameEvent<uint, string,uint> onRspTriggerForceWorldTaskEvent = new GameEvent<uint, string, uint>();
        public GameEvent<int> onForceWorldTasksEvent = new GameEvent<int>();
        public GameEvent onNotifyAllForceGiftBagEvent = new GameEvent();
        public GameEvent<ForceWorldGiftBag> onRefreshForceGiftBagEvent = new GameEvent<ForceWorldGiftBag>();
        public GameEvent<swm.RspForceWorldTaskInfoT> onRspForceWorldTaskInfoTEvent = new GameEvent<swm.RspForceWorldTaskInfoT>();

        public GameEvent<MissionInfoData> onMissionVisibleChangeEvent = new GameEvent<MissionInfoData>();
        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshRoleTaskState>(ProcRefreshRoleTaskState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.UpdateRoleTaskElem>(ProcUpdateRoleTaskElem);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.DoneTaskList>(ProcDoneTaskList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshTaskCanAccept>(ProcRefreshTaskCanAccept);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.DeleteRoleTask>(ProcDeleteRoleTask);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AllNpcTaskState>(ProcAllNpcTaskState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshNpcTaskState>(ProcRefreshNpcTaskState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshRoleTask>(ProcRefreshRoleTask);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SendAllRoleTask>(ProcSendAllRoleTask);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NpcDlgMessage>(ProcNpcDlgMessage);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.CloseDlgMessage>(ProcCloseDlgMessage);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshRoleTaskInfo>(ProcRefreshRoleTaskInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshCanAcceptRoleTask>(ProcRefreshCanAcceptRoleTask);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SendAllCanAcceptRoleTask>(ProcSendAllCanAcceptRoleTask);
            
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SyncGatherResourceState>(ProcSyncGatherResourceState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ResourceState>(ProcTaskResourceState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.AutoVisitNpc>(NotifyAutoVisitNpc_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RoleTaskIconDiaplay>(RefreshTaskItem_SC);
            //MsgDispacther.instance.RegisterFBMsgProc<swm.AutoNpcDlgSelectOption>(NotifyAutoSelectNpcDlgOption_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspEntrustList>(ProcRspEntrustList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspSetExploreTaskState>(ProcRspSetExploreTaskState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCheckExploreTaskOrder>(ProcRspCheckExploreTaskOrder);

            //             MsgDispatcher.instance.RegisterFBMsgProc<swm.RspTotalForceWorldTaskProgressState>(ProcRefreshForceWorldTaskProgressState);
            //             MsgDispatcher.instance.RegisterFBMsgProc<swm.RspForceWorldTaskList>(ProcRspForceWorldTaskList);
            //             MsgDispatcher.instance.RegisterFBMsgProc<swm.RsqForceWorldOpenState>(ProcRsqForceWorldOpenState);
            //             MsgDispatcher.instance.RegisterFBMsgProc<swm.RspOpenForceWorldTask>(ProcRspOpenForceWorldTask);
            //             MsgDispatcher.instance.RegisterFBMsgProc<swm.ForceWorldTaskProgressState>(ProcRspForceWorldTaskProgressState);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspTriggerForceWorldTask>(ProcRspTriggerForceWorldTask);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspForceWorldTasks>(ProcRspForceWorldTasks);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspForceWorldTaskInfo>(ProcRspForceWorldTaskInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyAllForceGiftBag>(ProcNotifyAllForceGiftBag);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshForceGiftBag>(ProcRefreshForceGiftBag);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspUserAllTaskData>(ProcRspUserAllTaskData);


            //奇遇任务奖励协议  需要显示特殊的奖励结算界面
            MsgDispatcher.instance.RegisterFBMsgProc<swm.CommitTaskPrizeList>(ProcCommitTaskPrizeList);

            //注册其他逻辑系统消息
            TriggerManager.Instance.onTriggerBoundRemoveAll.AddListener(ProcessTriggerBoundRemoveAll);

            UserDataMgr.Instance.onUserDataSync.AddListener(ReqUserAllTaskData);
        }
      
        public void ReqUserAllTaskData()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqUserAllTaskData.StartReqUserAllTaskData(fbb);
            fbb.Finish(swm.ReqUserAllTaskData.EndReqUserAllTaskData(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUserAllTaskData.HashID,fbb);
        }


        public void Clear()
        {
            m_TaskIconDisplayManager.Clear();
            m_ForceWorldTaskData.Clear();
            BackAllNpcTaskStateInfoToPool();
            m_acceptTaskList.Clear();
            m_doingTaskList.Clear();
            m_doneTaskList.Clear();
            m_missionResourceStateList.Clear();
            m_MissionInfoPoolList.Clear();
        }

        public void NotifyPlayTimeLineWithTask(string _filename,uint _taskid)
        {
            onPlayTimeLineWithTaskId.Invoke(_filename, _taskid);
        }
        
        /// <summary>
        /// 世界任务 进入触发处理
        /// </summary>
        /// <param name="_triggerId"></param>
        public void TriggerForceWorldTaskEnter(int _triggerId)
        {
            MissionInfoData _info = CheckTriggerIsHasDoingMission(_triggerId);
            if(null == _info)
            {
                SendReqTriggerForceWorldTask((uint)_triggerId);
            }
            else
            {
                if (!_info.Visible)
                {
                    _info.Visible = true;
                    onMissionVisibleChangeEvent.Invoke(_info);
                }
            }
           
        }

        /// <summary>
        /// 世界任务 离开区域处理
        /// </summary>
        /// <param name="_triggerId"></param>
        public void TriggerForceWorldTaskExit(int _triggerId)
        {
            MissionInfoData _info = CheckTriggerIsHasDoingMission(_triggerId);
            if(null != _info)
            {
                if(_info.Visible)
                {
                    _info.Visible = false;
                    onMissionVisibleChangeEvent.Invoke(_info);
                }
            }
        }

        private MissionInfoData CheckTriggerIsHasDoingMission(int _triggerId)
        {
            MissionInfoData _data = null;
            if(_triggerId != 0)
            {
                if (m_doingTaskList != null && m_doingTaskList.Count > 0)
                {
                    for (int i = 0; i < m_doingTaskList.Count; i++)
                    {
                        MissionInfoData _infoData = m_doingTaskList[i];
                        if (_infoData.Triggerid == _triggerId)
                        {
                            _data = _infoData;
                            break;
                        }
                    }
                }
            }
            return _data;
        }

        private void ProcessTriggerBoundRemoveAll()
        {
            if (m_doingTaskList != null && m_doingTaskList.Count > 0)
            {
                for (int i = 0; i < m_doingTaskList.Count; i++)
                {
                    MissionInfoData _infoData = m_doingTaskList[i];
                    if (_infoData.Triggerid != 0 && _infoData.Visible )
                    {
                        _infoData.Visible = false;
                        onMissionVisibleChangeEvent.Invoke(_infoData);
                    }
                }
            }
        }

        #region 网络消息

        /// <summary>
        /// 服务器主动通知：忽略距离自动访问Npc
        /// </summary>
        private void NotifyAutoVisitNpc_SC(AutoVisitNpc msg)
        {
            string tScript = string.Format("AutoVisitNpcByBaseId({0})", msg.baseid);
            LuaFastCall.DoString(tScript);
        }



        /// <summary>
        /// 服务器主动通知：自动选择Npc对话选项
        /// </summary>
        //private void NotifyAutoSelectNpcDlgOption_SC(AutoNpcDlgSelectOption msg)
        //{
        //    onAutoSelectNpcDlgOption.Invoke(msg.index);
        //}

        /// <summary>
        /// 刷新任务状态 tanpan加的这个函数有点问题
        /// </summary>
        private void ProcRefreshRoleTaskState(swm.RefreshRoleTaskState _msg)
        {
            var info = GetDoingMissionInfoDataById(_msg.taskid);
            if (info != null)
            {
                if (info.missionState != (swm.TaskState)_msg.state)
                {
                    info.missionState = (swm.TaskState)_msg.state;
                    if (info.missionState == swm.TaskState.HaveDone)
                    {
                        //m_doingTaskList.Remove(info);
                        m_doneTaskList.Add(info);
                        onCompletedTask.Invoke(info);
                    }
                    else
                    {
                        if (info.missionState == swm.TaskState.Doing || info.missionState == swm.TaskState.Done || info.missionState == swm.TaskState.Fail)
                        {
                            onRefreshDoingTask.Invoke(info);
                        }
                            
                    }
                }
            }
            else
            {
                LogHelper.LogFormat("not find task ,id is {0}", _msg.taskid);
            }
        }
        /// <summary>
        /// 更新目标元素进度
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcUpdateRoleTaskElem(swm.UpdateRoleTaskElem _msg)
        {
            var info = GetDoingMissionInfoDataById(_msg.taskid);
            if (info != null)
            {
                info.RefreshElement((int)_msg.index, (int)_msg.cur);
                onRefreshDoingTask.Invoke(info);

            }
            else
            {
                LogHelper.LogFormat("not find task ,id is {0}", _msg.taskid);
            }
        }

        /// <summary>
        /// 完成任务列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcDoneTaskList(swm.DoneTaskList _msg)
        {
            for (int i = 0; i < _msg.taskidLength; i++)
            {
                MissionInfoData info = GetMissionInfoDataFromPool();
                info.MissionId = _msg.taskid(i);
                m_doneTaskList.Add(info);
            }
        }
        /// <summary>
        /// 刷新可接任务
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshTaskCanAccept(swm.RefreshTaskCanAccept _msg)
        {
            //LogHelper.LogFormat("ProcRefreshTaskCanAccept ,id is {0}", _msg.taskid);
            //if (_msg.state > 0)
            //{
            //    var info = GetAcceptMissionInfoDataById(_msg.taskid);
            //    if(info == null)
            //    {
            //        info = GetMissionInfoDataFromPool();
            //        info.MissionId = _msg.taskid;
            //        info.missionState = swm.TaskState.Give;
            //        m_acceptTaskList.Add(info);
            //        onAddAcceptTask.Invoke(info);
            //    }else
            //    {
            //LogHelper.LogFormat("ProcRefreshTaskCanAccept ,id is {0}", _msg.taskid);
            //    }
            //}
        }

        /// <summary>
        /// 批量刷新可接任务
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcSendAllCanAcceptRoleTask(swm.SendAllCanAcceptRoleTask _msg)
        {
            m_acceptTaskList.Clear();
            for (int i = 0; i < _msg.tasksLength; i++)
            {
                var data = _msg.tasks(i);
                if (data.HasValue)
                {
                    var info = GetMissionInfoDataFromPool();
                    info.Refresh(data.Value);
                    m_acceptTaskList.Add(info);
                    onAddAcceptTask.Invoke(info);
                }
            }
        }

        /// <summary>
        ///检查是否存在任务采集的资源
        /// </summary>
        /// <param name="_baseId"></param>
        /// <returns></returns>
        public bool CheckIsHasResourceStateByBaseId(uint _baseId)
        {
            for (int i = 0; i < m_missionResourceStateList.Count; i++)
            {
                if (_baseId == m_missionResourceStateList[i])
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 接收  初始化资源状态消息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcSyncGatherResourceState(swm.SyncGatherResourceState _msg)
        {
            if(_msg.reslistLength > 0)
            {
                for(int i=0;i < _msg.reslistLength;i++)
                {
                   uint _baseId = _msg.reslist(i);
                    SetResourceState(_baseId, 1, false);
                }
            }

            MainCharacter mainchar = GameScene.Instance.MainChar;
            if (mainchar != null)
            {
                mainchar.CheckIsCloseEntity(true);
            }
        }

        /// <summary>
        /// 接收 任务资源状态消息
        /// </summary>
        /// <param name="_msg"></param>
        [XLua.BlackList]
        private void ProcTaskResourceState(swm.ResourceState _msg)
        {
            SetResourceState(_msg.resbaseid, _msg.state, true);
        }

        /// <summary>
        /// 设置采集资源状态
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="_state"></param>
        /// <param name="_bIsSendEvent"></param>
        private void SetResourceState(uint _baseId,byte _state,bool _bIsSendEvent)
        {
            bool _bIsStateChange = false;
            if (_state == 1)// 1可接，0不可接
            {
                if (!CheckIsHasResourceStateByBaseId(_baseId))
                {
                    m_missionResourceStateList.Add(_baseId);
                    _bIsStateChange = true;
                }
            }
            else if (_state == 0)
            {
                for (int i = 0; i < m_missionResourceStateList.Count; i++)
                {
                    if (_baseId == m_missionResourceStateList[i])
                    {
                        m_missionResourceStateList.RemoveAt(i);
                        _bIsStateChange = true;
                        break;
                    }
                }
            }

            if (_bIsStateChange && _bIsSendEvent)
            {
                onMissionResourceStateEvent.Invoke(_baseId, _state);
                GameScene.Instance.RefreshAllGatherResourceMissionState(_baseId, _state);
            }
        }

        /// <summary>
        /// 可接任务消息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshCanAcceptRoleTask(swm.RefreshCanAcceptRoleTask _msg)
        {
            if (_msg.data.HasValue)
            {
                var info = GetAcceptMissionInfoDataById(_msg.data.Value.taskid);
                if (info == null)
                {
                    info = GetMissionInfoDataFromPool();
                    info.Refresh(_msg.data.Value);
                    m_acceptTaskList.Add(info);
                    onAddAcceptTask.Invoke(info);
                    onAddAcceptTaskNoIni.Invoke(info);
                }
                else
                {
                    info.Refresh(_msg.data.Value);
                    //LogHelper.LogFormat("ProcRefreshTaskCanAccept ,id is {0}", _msg.taskid);
                }
            }
        }
        /// <summary>
        ///  删除任务
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcDeleteRoleTask(swm.DeleteRoleTask _msg)
        {
            MissionInfoData info;
            DeleteMissionInfoById(ref m_doingTaskList, _msg.taskid, out info);
            if (info != null)
            {
                InvokeRemoveDoingTask(info);
            }
                
        }

        private void InvokeRemoveDoingTask(MissionInfoData _data)
        {
            if(_data.Triggerid != 0)
            {
                //重置任务触发器的 重复触发功能
                TriggerManager.Instance.ResetCollisionBound((int)_data.Triggerid);
            }
            onRemoveDoingTask.Invoke(_data);
        }

        private NpcTaskStateInfo GetNpcTaskStateInfoFromPool()
        {
            NpcTaskStateInfo _data = null;
            if (m_npcheadstatePool.Count > 0)
            {
                _data = m_npcheadstatePool[0];
                m_npcheadstatePool.RemoveAt(0);
            }
            if (_data == null)
            {
                _data = new NpcTaskStateInfo();
            }
            return _data;
        }

        private void BackAllNpcTaskStateInfoToPool()
        {
            foreach(var v in m_npcheadstate)
            {
                v.Value.Clear();
                m_npcheadstatePool.Add(v.Value);
            }
            m_npcheadstate.Clear();
        }
        /// <summary>
        /// 刷新全部npc头顶任务状态
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcAllNpcTaskState(swm.AllNpcTaskState _msg)
        {
            BackAllNpcTaskStateInfoToPool();
            for (int i = 0; i < _msg.taskstateLength; i++)
            {
                var state = _msg.taskstate(i).Value;
                uint _npcBaseId = state.npcbaseid;
                NpcTaskStateInfo _info = AddTaskINfoState(_npcBaseId, state.state, state.type);
                List<Entity> npcList = GameScene.Instance.GetNpcEntityListByBaseId(_npcBaseId);
                if (npcList.Count > 0)
                {
                    for(int j=0;j< npcList.Count;j++)
                    {
                        Entity _data = npcList[j];
                        if(_data.IsNpc())
                        {
                            var npc = _data as Npc;
                            npc.RefreshTaskState(_info);
                        }
                        else if(_data.IsClientNpc())
                        {
                            var npc = _data as ClientNpc;
                            npc.RefreshTaskState(_info);
                        }
                    }
                    GameScene.Instance.ClearAllTempEntityEntity();
                }
            }
            GameScene.Instance.RefreshAllNpcMissionState();
            onAllNpcTaskStateEvent.Invoke();
        }

        
        private NpcTaskStateInfo AddTaskINfoState(uint _npcBaseId, swm.TaskNpcState _npcState,swm.RoleTaskType _type)
        {
            NpcTaskStateInfo _info;
            if (!m_npcheadstate.TryGetValue(_npcBaseId, out _info))
            {
                _info = GetNpcTaskStateInfoFromPool();
                m_npcheadstate.Add(_npcBaseId, _info);
            }
            _info.NpcTaskInfoState = _npcState;
            _info.RoleTaskInfoType = _type;
            return _info;
        }
        /// <summary>
        /// 刷新npc头顶任务状态
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshNpcTaskState(swm.RefreshNpcTaskState _msg)
        {
            if (_msg.taskstate.HasValue)
            {
                var state = _msg.taskstate.Value;
                uint _npcBaseId = state.npcbaseid;
                NpcTaskStateInfo _info = AddTaskINfoState(_npcBaseId, state.state, state.type);
                List<Entity> npcList = GameScene.Instance.GetNpcEntityListByBaseId(_npcBaseId);
                if (npcList.Count > 0)
                {
                    for (int j = 0; j < npcList.Count; j++)
                    {
                        Entity _data = npcList[j];
                        if(_data.IsNpc())
                        {
                            var npc = _data as Npc;
                            npc.RefreshTaskState(_info);
                        }
                        else if(_data.IsClientNpc())
                        {
                            var npc = _data as ClientNpc;
                            npc.RefreshTaskState(_info);
                        }

                    }
                    GameScene.Instance.ClearAllTempEntityEntity();
                }
                onRefreshBaseIdNpcTaskStateEvent.Invoke(_npcBaseId);
            }
        }

        /// <summary>
        /// 任务信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshRoleTask(swm.RefreshRoleTask _msg)
        {
            if (_msg.data.HasValue)
            {
                ProcDoingTaskByData(_msg.data.Value);
            }
        }

        /// <summary>
        /// 刷新任务信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshRoleTaskInfo(swm.RefreshRoleTaskInfo _msg)
        {
            if (!string.IsNullOrEmpty(_msg.taskinfo))
            {
//                 string str = Utilities.BuildString(_msg.taskinfo, " RefreshTaskContent(taskinfo)");
//                 LuaFunctor.DoString(str);

                onRefreshRoleTaskInfoEvent.Invoke(_msg.taskinfo);
            }
        }

        /// <summary>
        /// 批量刷新任务
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcSendAllRoleTask(swm.SendAllRoleTask _msg)
        {
            for (int i = 0; i < _msg.tasksLength; i++)
            {
                var data = _msg.tasks(i);
                if (data.HasValue)
                {
                    ProcDoingTaskByData(data.Value,false);
                }
            }
            onInitDoingTask.Invoke();
        }

        private void ProcDoingTaskByData(RoleTaskData _data ,bool _bIsSend = true)
        {
            //LogHelper.LogFormat("ProcDoingTaskByData:{0}", _data.taskid);

            var info = GetDoingMissionInfoDataById(_data.taskid);
            if (info != null)
            {
                info.Decode(_data);
                if(_bIsSend)
                {
                    onRefreshDoingTask.Invoke(info);
                }
            }
            else
            {
                info = GetMissionInfoDataFromPool();
                info.Decode(_data);
                m_doingTaskList.Add(info);
                //LogHelper.LogFormat("add doningtasklist:{0}", _data.taskid);

                MissionInfoData delinfo = null;
                DeleteMissionInfoById(ref m_acceptTaskList, _data.taskid, out delinfo);
                if(_bIsSend)
                {
                    onAddDoingTask.Invoke(info);
                }
            }

            //var mainchar = GameScene.Instance.MainChar;
            //if (mainchar != null)
            //{
            //    mainchar.CheckIsCloseEntity(true);
            //}
        }

        /// <summary>
        /// 显示npc对话框
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNpcDlgMessage(swm.NpcDlgMessage _msg)
        {
            string tScript = _msg.scriptcmd;
            if (_msg.display)
                tScript = Bokura.Utilities.BuildString(tScript, "ui_npcvisit:ShowOrHideUI(true)");
            else
                tScript = Bokura.Utilities.BuildString(tScript, "ui_npcvisit:ShowOrHideUI(false)");
            //LogHelper.Log(tScript, " ", _msg.title);
            try
            {
                LuaFunctor.DoString(tScript);
                onOpenNpcDialog.Invoke();
            }
            catch (Exception e)
            {
                LogHelper.LogError("ProcNpcDlgMessageError!script:", tScript , e.ToString());
            }

        }
        /// <summary>
        /// 关闭npc对话框
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcCloseDlgMessage(swm.CloseDlgMessage _msg)
        {
            LuaFunctor.DoString("CloseVisitNpcDialog()");
        }

        public void SendCloseDlgMsg()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.CloseDlgMessage.StartCloseDlgMessage(fbb);
            var msg = swm.CloseDlgMessage.EndCloseDlgMessage(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.CloseDlgMessage.HashID, fbb);
        }

        private void ClearDoingMissionList()
        {
            for (int i = 0; i < m_doingTaskList.Count; i++)
            {
                MissionInfoData _data = m_doingTaskList[i];
                InvokeRemoveDoingTask(_data);
            }
            m_doingTaskList.Clear();
        }

        private MissionInfoData ProcDeleteDoingMissionById(uint _missionId)
        {
            MissionInfoData _data = null;
            DeleteMissionInfoById(ref m_doingTaskList, _missionId, out _data);
            if (_data != null)
            {
                InvokeRemoveDoingTask(_data);
                RefeshNpcEntityMissionState();
            }
            return _data;
        }

        private MissionInfoData PorcDeleteAcceptMissionById(uint _missionId, bool _bIsDispatch = true)
        {
            MissionInfoData _data = null;
            DeleteMissionInfoById(ref m_acceptTaskList, _missionId, out _data);
            if (_bIsDispatch && _data != null)
            {
                onRemoveAcceptTask.Invoke(_data);
            }
            return _data;
        }

        /// <summary>
        /// 刷新任务中图标显示
        /// </summary>
        private void RefreshTaskItem_SC(swm.RoleTaskIconDiaplay msg)
        {
            //if (msg.type != RoleTaskIconType.TaskItem) return;
            //LogHelper.LogFormat("RefreshTaskItem_SC data：{0},{1}", msg.taskid, msg.state);
            if(msg.state == swm.IconDisplayType.Add || msg.state == swm.IconDisplayType.ClientConfirm)
            {
                //增加
                TaskIconDisplayInfo _data = m_TaskIconDisplayManager.AddTaskIconDiaplay(msg);
                if(null != _data)
                {
                    onAddTaskIconDiaplay.Invoke(_data);
                }
                else
                {
                    //刷新了数据
                    _data = m_TaskIconDisplayManager.GetTaskIconDisplayByTaskId(msg.taskid);
                    if(null != _data)
                    {
                        onRefreshTaskIconDiaplay.Invoke(_data);
                    }
                }
            }
            else if(msg.state == swm.IconDisplayType.Delete)
            {
                //删除
                TaskIconDisplayInfo _data = m_TaskIconDisplayManager.GetTaskIconDisplayByTaskId(msg.taskid);
                if(null != _data)
                {
                    _data.m_state = swm.IconDisplayType.Delete;
                    onRemoveTaskIconDiaplay.Invoke(_data);
                    m_TaskIconDisplayManager.RemoveTaskIconDiaplay(msg);
                }
            }

//             MissionInfoData tInfo = GetDoingMissionInfoDataById(msg.taskid);
//             if (tInfo != null)
//             {
//                 tInfo.RefreshTaskIconDiaplay(msg);//msg.index, msg.typeparamsLength > 0 ? (uint)msg.typeparams(0) : 0, msg.state);
//                 //onRefreshDoingTask.Invoke(tInfo);
//                 
//             }
//             else
//                 LogHelper.LogFormat("RefreshTaskItem_SC not find task ,id is {0}", msg.taskid);
        }

        /// <summary>
        /// 势力悬赏 势力悬赏委托榜消息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspEntrustList(swm.RspEntrustList _msg)
        {
            m_ExploreEntrustInfoData.Refresh(_msg);
            onGetEntrustInfoEvent.Invoke(m_ExploreEntrustInfoData);
        }

        /// <summary>
        /// 势力悬赏 响应设置势力悬赏探索任务状态(接取/放弃)
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspSetExploreTaskState(swm.RspSetExploreTaskState _msg)
        {
            m_ExploreEntrustInfoData.ResetTaskState(_msg.taskid, (TaskState)_msg.state);
            onExploreTaskStateEvent.Invoke(_msg.taskid, (TaskState)_msg.state);
        }

        /// <summary>
        /// 势力悬赏 返回命令对接结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspCheckExploreTaskOrder(swm.RspCheckExploreTaskOrder _msg)
        {
            ExploreMissionData _data = null;
            if (_msg.result> 0)
            {
                if(m_ExploreEntrustInfoData != null && m_ExploreEntrustInfoData.Fieldid == _msg.fieldid)
                {
                    _data = m_ExploreEntrustInfoData.AddExploreMissionData(_msg.explhidetask.Value);
                }
            }
            onCheckExploreTaskOrderEvent.Invoke(_msg.result, _data);
        }



        /// <summary>
        /// 势力世界任务 返回势力世界任务触发提示
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspTriggerForceWorldTask(swm.RspTriggerForceWorldTask _msg)
        {
            onRspTriggerForceWorldTaskEvent.Invoke(_msg.taskid, _msg.taskname, _msg.triggerid);
        }

        /// <summary>
        /// 势力世界任务 返回全部势力任务
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspForceWorldTasks(swm.RspForceWorldTasks _msg)
        {
            m_ForceWorldTaskData.RefreshForceWorldTask(_msg);
            onForceWorldTasksEvent.Invoke((int)_msg.perfectureid);
        }

        /// <summary>
        /// 势力世界任务 返回势力世界任务信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspForceWorldTaskInfo(swm.RspForceWorldTaskInfo _msg)
        {
            m_TempStoreForceWorldTaskInfo.FromMsg(_msg);
            onRspForceWorldTaskInfoTEvent.Invoke(m_TempStoreForceWorldTaskInfo);
        }

        /// <summary>
        /// 势力世界任务 通知全部势力礼包信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcNotifyAllForceGiftBag(swm.NotifyAllForceGiftBag _msg)
        {
            m_ForceWorldTaskData.RefreshNotifyAllForceGiftBag(_msg);
            onNotifyAllForceGiftBagEvent.Invoke();
        }

        /// <summary>
        /// 势力世界任务 更新礼包状态
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshForceGiftBag(swm.RefreshForceGiftBag _msg)
        {
            ForceWorldGiftBag _data = m_ForceWorldTaskData.RefreshAwardToList(_msg.gift.Value);
            onRefreshForceGiftBagEvent.Invoke(_data);
        }

        private void ProcRspUserAllTaskData(swm.RspUserAllTaskData _msg)
        {
            if(_msg.all_task.HasValue)
                ProcSendAllRoleTask(_msg.all_task.Value);
            if (_msg.task_state.HasValue)
                ProcAllNpcTaskState(_msg.task_state.Value);
            if (_msg.can_accept_list.HasValue)
                ProcSendAllCanAcceptRoleTask(_msg.can_accept_list.Value);
            if (_msg.force_gift_bag.HasValue)
                ProcNotifyAllForceGiftBag(_msg.force_gift_bag.Value);
            if (_msg.client_npc_list.HasValue)
                ClientNpcEntityManager.Instance.ProcBatchClientEntityList(_msg.client_npc_list.Value);
        }

//         /// <summary>
//         /// 势力世界任务 刷新势力世界任务任务槽状态
//         /// </summary>
//         /// <param name="_msg"></param>
//         private void ProcRefreshForceWorldTaskProgressState(swm.RspTotalForceWorldTaskProgressState _msg)
//         {
//             m_ForceWorldTaskData.RefreshForceWorldTask(_msg);
//             onInitForceWorldTaskStateEvent.Invoke();
//         }
// 
//         /// <summary>
//         /// 势力世界任务 返回势力世界任务列表
//         /// </summary>
//         /// <param name="_msg"></param>
//         private void ProcRspForceWorldTaskList(swm.RspForceWorldTaskList _msg)
//         {
//             m_ForceWorldTaskListData.Init(_msg);
//             onForceWorldTaskListDataChangeEvent.Invoke();
//         }
// 
//         /// <summary>
//         /// 势力世界任务 返回势力世界任务势力开启状态
//         /// </summary>
//         /// <param name="_msg"></param>
//         private void ProcRsqForceWorldOpenState(swm.RsqForceWorldOpenState _msg)
//         {
//             m_ForceWorldOpenStateData.Init(_msg);
//             onForceWorldOpenStateDataChangeEvent.Invoke();
//         }
// 
//         /// <summary>
//         /// 势力世界任务 返回开启势力世界任务
//         /// </summary>
//         /// <param name="_msg"></param>
//         private void ProcRspOpenForceWorldTask(swm.RspOpenForceWorldTask _msg)
//         {
//             onOpenForceWorldTaskResultEvent.Invoke(_msg.force_id, _msg.is_ok);
//         }
// 
//         /// <summary>
//         /// 势力世界任务 势力世界任务进度状态(增量刷新使用)
//         /// </summary>
//         /// <param name="_msg"></param>
//         private void ProcRspForceWorldTaskProgressState(swm.ForceWorldTaskProgressState _msg)
//         {
//             ForceWorldTaskState _stateData = m_ForceWorldTaskData.GetForceWorldTaskStateById(_msg.force_id);
//             if(null == _stateData)
//             {
//                 //增加
//                 _stateData = m_ForceWorldTaskData.AddForceWorldTaskStateToList(_msg);
//                 onAddForceWorldTaskStateEvent.Invoke(_stateData);
//             }
//             else
//             {
//                 //刷新
//                 _stateData.Init(_msg);
//                 onRefreshForceWorldTaskStateEvent.Invoke(_stateData);
//             }
//         }
///

        //发送消息
        /// <summary>
        /// 请求使用任务道具
        /// </summary>
        public bool SendReqRoleTaskUseItem(uint _taskid,ulong _targetId=0)
        {
            bool _b = false;
            TaskIconDisplayInfo tInfo = m_TaskIconDisplayManager.GetTaskIconDisplayByTaskId(_taskid);
            if (tInfo != null && tInfo.m_taskid > 0)
            {
                int _itemBaseId = (int)tInfo.GetTypeParamByIndex(0);
                ItemBase tItemBase = BagManager.Instance.GetItemByBaseID(_itemBaseId);
                ulong _id = 0;
                uint _itemNumber = 0;
                if (null != tItemBase)
                {
                    _b = true;
                    _id = tItemBase.ID;
                    _itemNumber = tItemBase.ItemNum;
                }
                else
                {
                    return false;
                }
                var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqRoleTaskUseItem.StartReqRoleTaskUseItem(tFBB);
                swm.ReqRoleTaskUseItem.AddTaskid(tFBB, _taskid);
                swm.ReqRoleTaskUseItem.AddSubtaskid(tFBB, tInfo.m_subtaskid);
                swm.ReqRoleTaskUseItem.AddIndex(tFBB, tInfo.m_index);
                swm.ReqRoleTaskUseItem.AddItemid(tFBB, _id);
                swm.ReqRoleTaskUseItem.AddNum(tFBB, _itemNumber);
                swm.ReqRoleTaskUseItem.AddDir(tFBB, swm.Vector3.CreateVector3(tFBB, 0, 0, 0));
                swm.ReqRoleTaskUseItem.AddTargetid(tFBB, _targetId);
                swm.ReqRoleTaskUseItem.AddTargetpos(tFBB, swm.Vector3.CreateVector3(tFBB, 0, 0, 0));
                var tOffset = swm.ReqRoleTaskUseItem.EndReqRoleTaskUseItem(tFBB);
                tFBB.Finish(tOffset.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqRoleTaskUseItem.HashID, tFBB);

            }
            return _b;
        }

        /// <summary>
        /// 发送 请求播放timeline
        /// </summary>
        /// <param name="_taskid"></param>
        public bool SendReqRoleTaskPlayTimeline(uint _taskid)
        {
            TaskIconDisplayInfo tInfo = m_TaskIconDisplayManager.GetTaskIconDisplayByTaskId(_taskid);
            if (tInfo != null && tInfo.m_taskid > 0)
            {
                var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqRoleTaskPlayTimeline.StartReqRoleTaskPlayTimeline(tFBB);
                swm.ReqRoleTaskPlayTimeline.AddTaskid(tFBB, tInfo.m_taskid);
                swm.ReqRoleTaskPlayTimeline.AddSubtaskid(tFBB, tInfo.m_subtaskid);
                swm.ReqRoleTaskPlayTimeline.AddIndex(tFBB, tInfo.m_index);
                //swm.ReqRoleTaskPlayTimeline.AddTimelineid(tFBB, (uint)tInfo.m_typeparams[0]);
                //swm.ReqRoleTaskPlayTimeline.AddIsalias(tFBB, (byte)tInfo.m_typeparams[1]);
                var tOffset = swm.ReqRoleTaskPlayTimeline.EndReqRoleTaskPlayTimeline(tFBB);
                tFBB.Finish(tOffset.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqRoleTaskPlayTimeline.HashID, tFBB);
                return true;
            }
            return false;
        }

         /// <summary>
         /// 请求使用技能
         /// </summary>
         /// <param name="_taskid"></param>
         public bool SendReqRoleTaskReleaseSkill(uint _taskid)
         {
             TaskIconDisplayInfo tInfo = m_TaskIconDisplayManager.GetTaskIconDisplayByTaskId(_taskid);
             if (tInfo != null)
             {
                 int skillid = (int)tInfo.GetTypeParamByIndex(0);
                RootSkill rs = SkillManager.Instance.GetSkill(skillid);
                SkillBase _skillBase = rs.ActuralSkill;//SkillManager.Instance.GetSubSkillByID(skillid);
                 if (null != _skillBase)
                 {
                    _skillBase.SendSkillCast(0, null);
//                      var tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
//                      FlatBuffers.Offset<swm.ReqCastSpell> _data = _skillBase.GetSkillCastFbb(tFBB, (int)tInfo.m_typeparams[0], null);
//                      swm.ReqRoleTaskReleaseSkill.StartReqRoleTaskReleaseSkill(tFBB);
//                      swm.ReqRoleTaskReleaseSkill.AddTaskid(tFBB, tInfo.m_taskid);
//                      swm.ReqRoleTaskReleaseSkill.AddSubtaskid(tFBB, tInfo.m_subtaskid);
//                      swm.ReqRoleTaskReleaseSkill.AddIndex(tFBB, tInfo.m_index);
//                      swm.ReqRoleTaskReleaseSkill.AddSpellcast(tFBB, _data);
//  
//                      var tOffset = swm.ReqRoleTaskReleaseSkill.EndReqRoleTaskReleaseSkill(tFBB);
//                      tFBB.Finish(tOffset.Value);
//                      MsgDispatcher.instance.SendFBPackage(swm.ReqRoleTaskReleaseSkill.HashID, tFBB);
                     return true;
                 }
             }
 
             return false;
         }

        public void ProcAutoDoDisplayIcon(uint _taskid, ulong _targetId = 0)
        {
            TaskIconDisplayInfo tInfo = m_TaskIconDisplayManager.GetTaskIconDisplayByTaskId(_taskid);
            if (tInfo != null)
            {
                switch(tInfo.m_type)
                {
                    case RoleTaskIconType.TaskItem:
                    case RoleTaskIconType.ItemSpecify:
                        SendReqRoleTaskUseItem(_taskid,_targetId);
                        break;
                     case RoleTaskIconType.Skill:
                         SendReqRoleTaskReleaseSkill(_taskid);
                         break;
                    case RoleTaskIconType.Timeline:
                        SendReqRoleTaskPlayTimeline(_taskid);
                        break;
                    default:
                        break;
                }
            }
        }



        /// <summary>
        /// 访问npc
        /// </summary>
        /// <param name="_uid"></param>
        public void SendVisitNpcEvent(ulong _uid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.RequestVisitNpc.StartRequestVisitNpc(fbb);
            swm.RequestVisitNpc.AddId(fbb, _uid);
            var msg = swm.RequestVisitNpc.EndRequestVisitNpc(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.RequestVisitNpc.HashID, fbb);
        }

        /// <summary>
        /// 请求任务信息
        /// </summary>
        /// <param name="_uid"></param>
        public void SendGetRoleTaskInfo(ulong _uid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.GetRoleTaskInfo.StartGetRoleTaskInfo(fbb);
            swm.GetRoleTaskInfo.AddTaskid(fbb, (uint)_uid);
            var msg = swm.GetRoleTaskInfo.EndGetRoleTaskInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.GetRoleTaskInfo.HashID, fbb);

            //string response = "local taskinfo={taskid=1,name='第一个表任务',desc='<color=#3eff1d>获取途径：</color><color=#ff1dff>主线任务</color>',itemaward={{id=1000,num=10},{id=100,num=99}}}";
            //response += " RefreshTaskContent(taskinfo);";
            //LuaFunctor.DoString(response);
        }

        /// <summary>
        /// npc对话
        /// </summary>
        /// <param name="_uid"></param>
        /// <param name="title"></param>
        /// <param name="index"></param>
        public void SendNpcDialogMsg(ulong _uid, string title, byte index)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var offset_title = fbb.CreateString(title);
            swm.NpcDlgSelectOption.StartNpcDlgSelectOption(fbb);
            swm.NpcDlgSelectOption.AddUid(fbb, _uid);
            swm.NpcDlgSelectOption.AddTitle(fbb, offset_title);
            swm.NpcDlgSelectOption.AddIndex(fbb, index);
            var msg = swm.NpcDlgSelectOption.EndNpcDlgSelectOption(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.NpcDlgSelectOption.HashID, fbb);
        }



        /// <summary>
        /// 删除任务
        /// </summary>
        /// <param name="missionid"></param>
        public void SendGiveupMission(uint missionid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.DeleteRoleTask.StartDeleteRoleTask(fbb);
            swm.DeleteRoleTask.AddTaskid(fbb, missionid);
            var msg = swm.DeleteRoleTask.EndDeleteRoleTask(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.DeleteRoleTask.HashID, fbb);
        }
        /// <summary>
        /// 势力悬赏 获取势力委托榜信息
        /// </summary>
        public void SendReqEntrustList(uint _ownerfield)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqEntrustList.StartReqEntrustList(fbb);
            swm.ReqEntrustList.AddOwnerfield(fbb, _ownerfield);
            var msg = swm.ReqEntrustList.EndReqEntrustList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEntrustList.HashID, fbb);
        }
        /// <summary>
        /// 势力悬赏 设置势力接取探索任务状态
        /// Doing:接取   Give:放弃
        /// </summary>
        public void SendReqSetExploreTaskState(uint _taskid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSetExploreTaskState.StartReqSetExploreTaskState(fbb);
            swm.ReqSetExploreTaskState.AddTaskid(fbb, _taskid);
            var msg = swm.ReqSetExploreTaskState.EndReqSetExploreTaskState(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSetExploreTaskState.HashID, fbb);
        }

        /// <summary>
        /// 势力悬赏 请求刷新委托榜
        /// </summary>
        public void SendReqRefreshEntrustList(uint _fieldid,uint _basenpcid)
         {
             var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
             swm.ReqRefreshEntrustList.StartReqRefreshEntrustList(fbb);
             swm.ReqRefreshEntrustList.AddFieldid(fbb, _fieldid);
             swm.ReqRefreshEntrustList.AddBasenpcid(fbb, _basenpcid);
             var msg = swm.ReqRefreshEntrustList.EndReqRefreshEntrustList(fbb);
             fbb.Finish(msg.Value);
             MsgDispatcher.instance.SendFBPackage(swm.ReqRefreshEntrustList.HashID, fbb);
         }

        /// <summary>
        /// 势力悬赏 请求对接密令
        /// </summary>
        /// <param name="_fieldid"></param>
        public void SendReqCheckExploreTaskOrder(uint _fieldid,string _answer)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            FlatBuffers.StringOffset _answerOffset = fbb.CreateString(_answer);
            swm.ReqCheckExploreTaskOrder.StartReqCheckExploreTaskOrder(fbb);
            swm.ReqCheckExploreTaskOrder.AddFieldid(fbb, _fieldid);
            swm.ReqCheckExploreTaskOrder.AddAnswer(fbb, _answerOffset);
            var msg = swm.ReqCheckExploreTaskOrder.EndReqCheckExploreTaskOrder(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCheckExploreTaskOrder.HashID, fbb);
        }

        /// <summary>
        /// 请求采集npc
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_pos"></param>
        public void SendReqRoleTaskGatherNpc(ulong _id,UnityEngine.Vector3 _pos)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqRoleTaskGatherNpc.StartReqRoleTaskGatherNpc(fbb);
            swm.ReqRoleTaskGatherNpc.AddTarUid(fbb, _id);
            swm.ReqRoleTaskGatherNpc.AddTarPos(fbb, swm.Vector3.CreateVector3(fbb, _pos.x, _pos.y, _pos.z));
            var msg = swm.ReqRoleTaskGatherNpc.EndReqRoleTaskGatherNpc(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRoleTaskGatherNpc.HashID, fbb);
        }

        /// <summary>
        /// 请求手动提交道具
        /// </summary>
        /// <param name="_taskid"></param>
        /// <param name="_subtaskid"></param>
        /// <param name="_target"></param>
        /// <param name="_type"></param>
        /// <param name="_list"></param>
//         public void SendReqManualSubmitItem(uint _taskid, uint _subtaskid, byte _target, SubmitItemType _type,List<SubmitItemInfo> _list)
//         {
//             var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
//             var data = new FlatBuffers.Offset<swm.ItemInfo>[_list.Count];
//             for (int i = 0; i < _list.Count; i++)
//             {
//                 SubmitItemInfo info = _list[i];
//                 swm.ItemInfo.StartItemInfo(fbb);
//                 swm.ItemInfo.AddItemid(fbb, info.itemid);
//                 swm.ItemInfo.AddNum(fbb, info.num);
//                 swm.ItemInfo.AddType(fbb, (swm.BagType)info.type);
//                 data[i] = swm.ItemInfo.EndItemInfo(fbb);
//             }
//             var vec = swm.ReqManualSubmitItem.CreateSubmititemVector(fbb, data);
//             swm.ReqManualSubmitItem.StartReqManualSubmitItem(fbb);
//             swm.ReqManualSubmitItem.AddTaskid(fbb,_taskid);
//             swm.ReqManualSubmitItem.AddSubtaskid(fbb, _subtaskid);
//             swm.ReqManualSubmitItem.AddTarget(fbb, _target);
//             swm.ReqManualSubmitItem.AddType(fbb, _type);
//        
//             swm.ReqManualSubmitItem.AddSubmititem(fbb, vec);
//             var msg = swm.ReqManualSubmitItem.EndReqManualSubmitItem(fbb);
//             fbb.Finish(msg.Value);
//             MsgDispatcher.instance.SendFBPackage(swm.ReqManualSubmitItem.HashID, fbb);
//         }
        //         /// <summary>
        //         /// 势力世界任务 请求势力世界任务进度槽状态
        //         /// </summary>
        //         public void SendReqOpenForceWorldProgressState()
        //         {
        //             var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
        //             swm.ReqOpenForceWorldProgressState.StartReqOpenForceWorldProgressState(fbb);
        //             var msg = swm.ReqOpenForceWorldProgressState.EndReqOpenForceWorldProgressState(fbb);
        //             fbb.Finish(msg.Value);
        //             MsgDispatcher.instance.SendFBPackage(swm.ReqOpenForceWorldProgressState.HashID, fbb);
        //         }
        // 
        //         /// <summary>
        //         /// 势力世界任务 请求势力世界势力对应的任务
        //         /// </summary>
        //         /// <param name="_forceId"></param>
        //         public void SendReqForceWorldTaskList(uint _forceId)
        //         {
        //             var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
        //             swm.ReqForceWorldTaskList.StartReqForceWorldTaskList(fbb);
        //             swm.ReqForceWorldTaskList.AddForceId(fbb, _forceId);
        //             var msg = swm.ReqForceWorldTaskList.EndReqForceWorldTaskList(fbb);
        //             fbb.Finish(msg.Value);
        //             MsgDispatcher.instance.SendFBPackage(swm.ReqForceWorldTaskList.HashID, fbb);
        //         }
        // 
        //         /// <summary>
        //         /// 势力世界任务 请求势力世界势力状态
        //         /// </summary>
        //         /// <param name="_perfecture_id"></param>
        //         public void SendRepForceWorldState(uint _perfecture_id)
        //         {
        //             var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
        //             swm.RepForceWorldState.StartRepForceWorldState(fbb);
        //             swm.RepForceWorldState.AddPerfectureId(fbb, _perfecture_id);
        //             var msg = swm.RepForceWorldState.EndRepForceWorldState(fbb);
        //             fbb.Finish(msg.Value);
        //             MsgDispatcher.instance.SendFBPackage(swm.RepForceWorldState.HashID, fbb);
        //         }
        // 
        //         /// <summary>
        //         /// 势力世界任务 请求开启势力世界任务
        //         /// </summary>
        //         /// <param name="_forceId"></param>
        //         public void SendReqOpenForceWorldTask(uint _forceId)
        //         {
        //             var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
        //             swm.ReqOpenForceWorldTask.StartReqOpenForceWorldTask(fbb);
        //             swm.ReqOpenForceWorldTask.AddForceId(fbb, _forceId);
        //             var msg = swm.ReqOpenForceWorldTask.EndReqOpenForceWorldTask(fbb);
        //             fbb.Finish(msg.Value);
        //             MsgDispatcher.instance.SendFBPackage(swm.ReqOpenForceWorldTask.HashID, fbb);
        //         }

        /// <summary>
        /// 请求获取接取势力世界任务触发提示
        /// </summary>
        /// <param name="_id"></param>
        public void SendReqTriggerForceWorldTask(uint _id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqTriggerForceWorldTask.StartReqTriggerForceWorldTask(fbb);
            swm.ReqTriggerForceWorldTask.AddTriggerid(fbb, _id);
            var msg = swm.ReqTriggerForceWorldTask.EndReqTriggerForceWorldTask(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqTriggerForceWorldTask.HashID, fbb);
        }

        /// <summary>
        /// 请求获取势力世界任务
        /// </summary>
        /// <param name="_taskId"></param>
        /// <param name="_triggerId"></param>
        public void SendReqAddForceWorldTask(uint _taskId,uint _triggerId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqAddForceWorldTask.StartReqAddForceWorldTask(fbb);
            swm.ReqAddForceWorldTask.AddTaskid(fbb, _taskId);
            swm.ReqAddForceWorldTask.AddTriggerid(fbb, _triggerId);
            var msg = swm.ReqAddForceWorldTask.EndReqAddForceWorldTask(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAddForceWorldTask.HashID, fbb);
        }

        /// <summary>
        /// 请求查看势力任务
        /// </summary>
        /// <param name="_forces"></param>
        public void SendReqForceWorldTasks(List<uint> _forces, int _mapBaseId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.ReqForceWorldTasks.CreateForcesVector(fbb, _forces.ToArray());

            swm.ReqForceWorldTasks.StartReqForceWorldTasks(fbb);
            swm.ReqForceWorldTasks.AddForces(fbb, vec);
            swm.ReqForceWorldTasks.AddPerfectureid(fbb, (uint)_mapBaseId);
            var msg = swm.ReqForceWorldTasks.EndReqForceWorldTasks(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqForceWorldTasks.HashID, fbb);
        }

        /// <summary>
        /// 请求获取势力世界任务信息
        /// </summary>
        /// <param name="_triggerid"></param>
        public void SendReqForceWorldTaskInfo(uint _triggerid)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqForceWorldTaskInfo.StartReqForceWorldTaskInfo(fbb);
            swm.ReqForceWorldTaskInfo.AddTriggerid(fbb, _triggerid);
            var msg = swm.ReqForceWorldTaskInfo.EndReqForceWorldTaskInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqForceWorldTaskInfo.HashID, fbb);
        }
        #endregion 网络消息

        public void RefeshNpcEntityMissionState()
        {
            GameScene.Instance.RefreshAllNpcMissionState();
        }

        /// <summary>
        /// 获得npc 当前的头顶状态
        /// </summary>
        /// <param name="_npcBaseId"></param>
        /// <returns></returns>
        public NpcTaskStateInfo GetNpcMissionState(uint _npcBaseId)
        {
            NpcTaskStateInfo _info = null;
            m_npcheadstate.TryGetValue(_npcBaseId, out _info);
            return _info;
        }

        public MissionInfoData GetMissionInfoDataByNpcBaseId(uint _npcBaseId)
        {
            MissionInfoData _missioninfo = null;
            NpcTaskStateInfo _npcStateInfo = GetNpcMissionState( _npcBaseId );
            if(null != _npcStateInfo)
            {
                if(_npcStateInfo.NpcTaskInfoState == swm.TaskNpcState.Give)
                {
                    if (m_acceptTaskList != null && m_acceptTaskList.Count > 0)
                    {
                        for (int i = 0; i < m_acceptTaskList.Count; i++)
                        {
                            MissionInfoData _infoData = m_acceptTaskList[i];
                            if (_infoData.StartNpc != 0 && _infoData.StartNpc == _npcBaseId)
                            {
                                _missioninfo = _infoData;
                            }
                        }
                    }
                }
                else
                {
                    if (m_doingTaskList != null && m_doingTaskList.Count > 0)
                    {
                        for (int i = 0; i < m_doingTaskList.Count; i++)
                        {
                            MissionInfoData _infoData = m_doingTaskList[i];
                            if (_infoData.EndNpc != 0 && _infoData.EndNpc == _npcBaseId)
                            {
                                _missioninfo = _infoData;
                            }
                        }
                    }
                }
            }

            return _missioninfo;
        }

        /// <summary>
        /// 从正在进行的列表里面 获得对应id的任务
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public MissionInfoData GetDoingMissionInfoDataById(uint _id)
        {
            return GetMissionInfoDataById(m_doingTaskList, _id);
        }
        /// <summary>
        /// 从可接列表里面 获得对应id的任务
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public MissionInfoData GetAcceptMissionInfoDataById(uint _id)
        {
            return GetMissionInfoDataById(m_acceptTaskList, _id);
        }
        /// <summary>
        /// 从列表里面 获得对应id的任务
        /// </summary>
        /// <param name="_list"></param>
        /// <param name="_id"></param>
        /// <returns></returns>
        public MissionInfoData GetMissionInfoDataById(List<MissionInfoData> _list, uint _id)
        {
            MissionInfoData _data = null;
            if (_list != null && _list.Count > 0)
            {
                for (int i = 0; i < _list.Count; i++)
                {
                    MissionInfoData _infoData = _list[i];
                    if (_infoData.MissionId == _id)
                    {
                        _data = _infoData;
                    }
                }
            }
            return _data;
        }


        /// <summary>
        /// 从对应列表里面删除，返回池子
        /// </summary>
        /// <param name="_list"></param>
        /// <param name="_id"></param>
        /// <param name="_deleteValue"></param>
        private void DeleteMissionInfoById(ref List<MissionInfoData> _list, uint _id, out MissionInfoData _deleteValue)
        {
            _deleteValue = null;
            if (null != _list && _list.Count > 0)
            {
                for (int i = 0; i < _list.Count; i++)
                {
                    MissionInfoData _data = _list[i];
                    if (_data.MissionId == _id)
                    {
                        _deleteValue = _data;
                        m_MissionInfoPoolList.Add(_data);//返回池子
                        _list.RemoveAt(i);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// 从池子里面取
        /// </summary>
        /// <returns></returns>
        private MissionInfoData GetMissionInfoDataFromPool()
        {
            MissionInfoData _data = null;
            if(m_MissionInfoPoolList.Count>0)
            {
                _data = m_MissionInfoPoolList[0];
                m_MissionInfoPoolList.RemoveAt(0);
            }
            else
            {
                _data = new MissionInfoData();
            }
            _data.clear();
            return _data;
        }

        /// <summary>
        /// 仅仅用于显示奇遇任务奖励界面
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcCommitTaskPrizeList(swm.CommitTaskPrizeList _msg)
        {
            onCommitTaskPrizeList.Invoke(_msg);
        }

        [XLua.BlackList]
        public void GM_CommitTaskPrizeList()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            var baseitemoff_1 = swm.BaseItemInfo.CreateBaseItemInfo(tFBB, 9, 10);
            var baseitemoff_2 = swm.BaseItemInfo.CreateBaseItemInfo(tFBB, 11, 33);
            var baseitemoff_3 = swm.BaseItemInfo.CreateBaseItemInfo(tFBB, 1001, 37);

            var baseitemofflist = new Offset<BaseItemInfo>[] { baseitemoff_1, baseitemoff_2, baseitemoff_3 };
            var itemoffset = swm.CommitTaskPrizeList.CreateItemsVector(tFBB, baseitemofflist);

            var tOffset = swm.CommitTaskPrizeList.CreateCommitTaskPrizeList(tFBB, RoleTaskType.Career, itemoffset);
            tFBB.Finish(tOffset.Value);

            OfflineViewMsgTamper.ProcFBMsg(swm.CommitTaskPrizeList.HashID, tFBB);
        }
    }
}