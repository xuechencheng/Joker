using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using Bokura;
using LitJson;

namespace Bokura
{
	public class MsgDispatcher
	{

		static MsgDispatcher m_instance;

        VMemoryStream       m_memoryStream = new VMemoryStream(true);
		BinaryWriter m_binaryWrite;
		public static MsgDispatcher instance
		{
			get
			{
				if (m_instance == null)
					m_instance = new MsgDispatcher();
				return m_instance;
			}
		}

#if FBS_TOSTRING_SUPPORT && DEBUG

        delegate string FBToString(byte[] buff, int offset, int len);
        Dictionary<ulong, FBToString> m_FBToStringFuncs = new Dictionary<ulong, FBToString>(256);
#endif
        MsgDispatcher()
		{
			m_binaryWrite = new BinaryWriter(m_memoryStream);
#if FBS_TOSTRING_SUPPORT && DEBUG

            System.Reflection.Assembly m_assembly = System.Reflection.Assembly.GetCallingAssembly();
            var types = m_assembly.GetTypes();
            var typeFlatbuffer = typeof(FlatBuffers.IFlatbufferObject);
            var bb = new FlatBuffers.ByteBuffer(32*1024);
            object[] param_obj = new object[2];
            foreach (var type in types)
            {
                if(typeFlatbuffer.IsAssignableFrom(type))
                {
                    var hashidf = type.GetField("HashID");
                    if (hashidf==null)
                        continue;
                    ulong hashid =(ulong)hashidf.GetValue(null);
                    //var con = type.GetConstructors();
                    var __init = type.GetMethod("__init");
                    var toString = type.GetMethod("ToString");
                    m_FBToStringFuncs.Add(hashid, (byte[] buff, int offset, int len) =>
                    {
                        bb.Reset(buff, offset);
                        var obj = m_assembly.CreateInstance(type.FullName);// con[0].Invoke(null);
                        param_obj[0] = bb.GetInt(bb.Position) + bb.Position;
                        param_obj[1] = bb;
                        __init.Invoke(obj, param_obj);
                        return (string)toString.Invoke(obj,null);
                        //return string.Empty;
                    });
                   
                }
            }

#endif

        }

        public delegate void MsgProcDelegate<T>(T msg);

        public delegate bool FlatBufferRawProc(ulong msgid, byte[] data, int offset, int size);
        //public FlatBufferProc PreFlatBufferProc;

        Dictionary<Type, ProcFun> m_msgProcList = new Dictionary<Type, ProcFun>(10);
		Dictionary<ulong, FlatBufferProcFun> m_fbmsgProcList = new Dictionary<ulong, FlatBufferProcFun>(100);
        Dictionary<ulong, FlatBufferRawProc> m_fbmsgRawProcList = new Dictionary<ulong, FlatBufferRawProc>(100);

        FlatBuffers.ByteBuffer m_flatByteBuffer = new FlatBuffers.ByteBuffer(32*1024);
		FlatBuffers.FlatBufferBuilder m_flatBufferBuilder = new FlatBuffers.FlatBufferBuilder(1024);

		class ProcFun
		{

			public virtual void Invoke(object msg)
			{

			}
		}

		class ProcFunT<T> : ProcFun
		{
			public ProcFunT(MsgProcDelegate<T> dlg)
			{
				m_dlg = dlg;
			}
			MsgProcDelegate<T> m_dlg;

			public override void Invoke(object msg)
			{
				m_dlg((T)msg);
			}
		}

		class FlatBufferProcFun
		{

			public virtual void Invoke(FlatBuffers.ByteBuffer bb)
			{

			}
		}

		class FlatBufferProcFunT<T> : FlatBufferProcFun where T : struct, FlatBuffers.IFlatbufferObject
		{
			public FlatBufferProcFunT(MsgProcDelegate<T> dlg)
			{
				m_dlg = dlg;
			}
			MsgProcDelegate<T> m_dlg;
			T m_obj = default(T);
			public override void Invoke(FlatBuffers.ByteBuffer bb)
			{
				m_obj.__init(bb.GetInt(bb.Position) + bb.Position, bb);
				try
				{
#if FBS_TOSTRING_SUPPORT && DEBUG && !NOLOG
                    LogHelper.Log(LogCategory.Network,"[MSG]", m_obj.ToString());
#endif
                    m_dlg(m_obj);

				}
				catch(Exception e)
				{
                    LogHelper.LogError("process msg error!" , typeof(T).FullName, e.ToString());
                    //LogHelper.LogError(e.ToString());
				}
			}
        }

		//public void RegisterMsgProc<T>(MsgProcDelegate<T> dlg) where T : ProtoBuf.IExtensible
		//{
		//	m_msgProcList[typeof(T)] = new ProcFunT<T>(dlg);
		//}

        public void RegisterFBMsgProcRaw(ulong msgid, FlatBufferRawProc rawproc )
        {
            FlatBufferRawProc exist;
            if (m_fbmsgRawProcList.TryGetValue(msgid, out exist))
            {
                LogHelper.LogError(Utilities.BuildString("RegisterFBMsgProcRaw Exist!", msgid.ToString()));
            }
            else
                m_fbmsgRawProcList.Add(msgid, rawproc);

        }

        public void RegisterFBMsgProc<T>(MsgProcDelegate<T> dlg) where T : struct, FlatBuffers.IFlatbufferObject
		{
			var fieldinfo = typeof(T).GetField("HashID", BindingFlags.Static | BindingFlags.Public);

			ulong hashid = (ulong)fieldinfo.GetValue(null);
            FlatBufferProcFun exist;
            if (m_fbmsgProcList.TryGetValue(hashid, out exist))
            {
                LogHelper.LogError(Utilities.BuildString("FBMsgProc Exist!", typeof(T).Name));
                //throw new Exception(Utilities.BuildString("FBMsgProc Exist!", typeof(T).Name));
            }
            else
                m_fbmsgProcList.Add(hashid, new FlatBufferProcFunT<T>(dlg));
            
		}


		public bool ProcFlatBufferPackage(ulong msgid, byte[] bytes, int offset, int size)
		{
			FlatBufferProcFun procfun;
            FlatBufferRawProc rawProcFun;
            if (m_fbmsgRawProcList.TryGetValue(msgid, out rawProcFun))
            {
                if(rawProcFun(msgid, bytes, offset, size))
                    return true;
            }
             if (m_fbmsgProcList.TryGetValue(msgid, out procfun))
			{
				m_flatByteBuffer.Reset(bytes, offset);
				procfun.Invoke(m_flatByteBuffer);
                return true;
			}
            else
            {
#if FBS_TOSTRING_SUPPORT && DEBUG

                FBToString toString;
                if (m_FBToStringFuncs.TryGetValue(msgid, out toString))
                {
                    var s = toString(bytes, offset, size);
                    LogHelper.LogWarning(LogCategory.Network,"[NOPROCESS_MSG]", s);
                }

#endif
                //LogHelper.Log("[MSG]UnknownMsg:", msgid.ToString("X16"));

            }
            return false;
		}


		public bool ProcPackage(Type t, object obj)
		{
			ProcFun procfun;
			if (m_msgProcList.TryGetValue(t, out procfun))
			{

				procfun.Invoke(obj);
				return true;

			}
			return false;
		}

        public void Dispatch()
        {
            int maxmsgcount = 100;
            while (NetworkConnection.Instance.Depacker.getMsg() && maxmsgcount>0) maxmsgcount--;
            NetworkConnection.Instance.CheckBufferAndReceive();
        }

        public FlatBuffers.FlatBufferBuilder GetFlatBufferBuilder()
		{
			m_flatBufferBuilder.Clear();
			return m_flatBufferBuilder;
        }
        public bool SendFBPackage(ulong msgid, FlatBuffers.FlatBufferBuilder fb)
        { 
			return SendFBPackage(msgid, fb.DataBuffer.RawBuffer, fb.DataBuffer.Position, fb.DataBuffer.Length-fb.DataBuffer.Position);
		}
        public bool SendFBPackage(FlatBuffers.IFlatBufferHelperObject msgT)
        {
            var fbb = GetFlatBufferBuilder();
            fbb.Finish(msgT.ToMsg(fbb));
            return SendFBPackage(msgT.HashID, fbb);
        }

        public bool SendFBPackage(ulong msgid, byte[] data, int offset, int size)
        {
            if (NetworkConnection.networkMsgTamper != null && !NetworkConnection.networkMsgTamper.OnSendFBPackage(msgid, ref data, ref offset, ref size))
            {
                return false;
            }

            MsgPrintLogger.instance.OnSendFBPackage(msgid, data, offset);

			var sendbuffer = GetStdHeadBuffer(250, 251);
			m_binaryWrite.Write(msgid);
	
			m_binaryWrite.Write(size);
			m_binaryWrite.Write(data, offset, size);

			int packlen = (int)m_memoryStream.Position - 4;
			sendbuffer.Buffer[0] = (byte)(packlen & 0xFF);
			sendbuffer.Buffer[1] = (byte)(packlen >> 8);            

		    var r = GameApplication.Instance.GetNetwork().SendPackage(sendbuffer, (int)m_memoryStream.Position);
#if FBS_TOSTRING_SUPPORT && DEBUG  && !NOLOG
            if (r)
            {
                FBToString toString;
                if(m_FBToStringFuncs.TryGetValue(msgid, out toString))
                {
                    var s = toString(data, offset, size);
                    LogHelper.Log(LogCategory.Network,"[SENDMSG]", s);
                }
            }
#endif
            return r;
		}
		//public bool SendPBPackage(string protoname, byte[] luaPBData)
  //      {
  //          if (NetworkConnection.networkMsgTamper != null && !NetworkConnection.networkMsgTamper.OnSendProtobufPackage(protoname, ref luaPBData))
  //          {
  //              return false;
  //          }

  //          MsgPrintLogger.instance.OnSendProtobufPackage(protoname, luaPBData);

  //          var sendbuf = GetStdHeadBuffer(250, 250);
		//	int bytes_len = Encoding.UTF8.GetBytes(protoname, 0, protoname.Length, m_packStrBuff, 0);
		//    m_packStrBuff[bytes_len] = 0;
  //          m_binaryWrite.Write(m_packStrBuff, 0, 64);
		//	m_binaryWrite.Write((int)luaPBData.Length);
		//	m_binaryWrite.Write(luaPBData, 0, luaPBData.Length);
		//	int npacklen = (int)m_memoryStream.Position-4;
		//	//复写最终包长
		//	sendbuf.Buffer[0] = (byte)(npacklen & 0xFF);
		//	sendbuf.Buffer[1] = (byte)(npacklen >>8);

		//	return GameApplication.Instance.GetNetwork().SendPackage(sendbuf, (int)m_memoryStream.Position);
		//}

		int m_packageIdx = 1;
 
		System.Net.Sockets.SocketAsyncEventArgs GetStdHeadBuffer(byte cmd, byte para)
		{
			var sendbuffer = GameApplication.Instance.GetNetwork().GetSendBuffer();
			m_memoryStream.SetLength(sendbuffer.Buffer.Length);
			m_memoryStream.Buffer = sendbuffer.Buffer;
			m_memoryStream.Position = 0;
			//write head len
			m_binaryWrite.Write((int)0);
			m_binaryWrite.Write((byte)cmd);
			m_binaryWrite.Write((byte)para);

			m_binaryWrite.Write((int)m_packageIdx);
			m_packageIdx++;
			m_binaryWrite.Write((int)(GameScene.Instance.GetServerTime() / 1000));

			return sendbuffer;
		}

	}
}