﻿using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using Bokura;
using LitJson;
using System.Xml;

namespace Bokura
{
    public class MsgPrintLogger
    {
        static MsgPrintLogger m_instance;
        public static MsgPrintLogger instance
        {
            get
            {
                if (m_instance == null)
                    m_instance = new MsgPrintLogger();
                return m_instance;
            }
        }
        
        public bool allowMessage_Move;
        
        private Dictionary<ulong, FlatBuffers.IFlatbufferObject> flatbufferMsgMapping;
        public MsgPrintLogger()
        {
            Assembly asm = Assembly.GetExecutingAssembly();

            flatbufferMsgMapping = new Dictionary<ulong, FlatBuffers.IFlatbufferObject>(32);
            
            foreach (Type type in asm.GetTypes())
            {
                if (string.Equals(type.Namespace, "swm"))
                {
                    if (type.GetInterface("FlatBuffers.IFlatbufferObject") != null)
                    {
                        FieldInfo fi = type.GetField("HashID");
                        if (fi != null)
                        {
                            ulong hashID = (ulong)fi.GetValue(null);
                            flatbufferMsgMapping.Add(hashID, (FlatBuffers.IFlatbufferObject)Activator.CreateInstance(type));
                        }
                    }
                }
            }

//             flatbufferMsgMapping[swm.ZoneData.HashID] = new swm.ZoneData();
//             flatbufferMsgMapping[swm.ReqLoginAccount.HashID] = new swm.ReqLoginAccount();
//             flatbufferMsgMapping[swm.RspLoginAccount.HashID] = new swm.RspLoginAccount();
//             flatbufferMsgMapping[swm.ReqSelectZone.HashID] = new swm.ReqSelectZone();
//             flatbufferMsgMapping[swm.RspSelectZone.HashID] = new swm.RspSelectZone();
//             flatbufferMsgMapping[swm.MoveTo.HashID] = new swm.MoveTo();
//             flatbufferMsgMapping[swm.MoveStop.HashID] = new swm.MoveStop();
//             flatbufferMsgMapping[swm.SyncEntityAction.HashID] = new swm.SyncEntityAction();
//             flatbufferMsgMapping[swm.TestHello.HashID] = new swm.TestHello();
//             flatbufferMsgMapping[swm.PhoneNumber.HashID] = new swm.PhoneNumber();
        }
        //public void OnSendProtobufPackage<T>(T msg) where T : ProtoBuf.IExtensible
        //{
        //    if (IDebugSystem.Instance == null || !IDebugSystem.Instance.m_showNetworkLog)
        //        return;

        //    string rootName;
        //    string s = ProtobufToXML(msg, out rootName);
        //    Type type = typeof(T);
        //    LogHelper.LogFormat("{0}.{1}: {2}", type.Namespace, rootName, s);
        //}
        //public void OnSendProtobufPackage(string protoname, byte[] luaPBData)
        //{
        //    if (IDebugSystem.Instance == null || !IDebugSystem.Instance.m_showNetworkLog)
        //        return;

        //    using (var memoryStream = new MemoryStream(luaPBData))
        //    {
        //        var type = Type.GetType(protoname);
        //        var msg = ProtoBuf.Serializer.Deserialize(type, memoryStream);

        //        string rootName;
        //        string s = ProtobufToXML(msg, out rootName);
        //        LogHelper.LogFormat("{0}.{1}: {2}", type.Namespace, rootName, s);
        //    }
        //}
        public void OnReceiveProtobufPackage(object msg)
        {
            //if (IDebugSystem.Instance == null || !IDebugSystem.Instance.m_showNetworkLog)
            //    return;

            //string rootName;
            //string s = ProtobufToXML(msg, out rootName);
            //Type type = msg.GetType();
            //LogHelper.LogFormat("{0}.{1}: {2}", type.Namespace, rootName, s);
        }
        // const string XMLEncodingConstant = "<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n";
         const string XMLSchema = " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"";
        string ProtobufToXML(object msg, out string rootName)
        {
            using (StringWriter writer = new StringWriter())
            {
                System.Xml.Serialization.XmlSerializer xml = new System.Xml.Serialization.XmlSerializer(msg.GetType());
                xml.Serialize(writer, msg);

                string s = writer.ToString();
                //s = s.Replace(XMLEncodingConstant, "");
                s = s.Replace(XMLSchema, "");

                
                return XMLToJson(s, out rootName);
            }
        }
        void XMLNodeToJosn(XmlNode node, JsonData json)
        {
            for (int i = 0; i < node.ChildNodes.Count; ++i)
            {
                XmlNode child = node.ChildNodes[i];

                if (child.ChildNodes.Count > 0)
                {
                    if (child.ChildNodes.Count == 1 && child.ChildNodes[0].NodeType == XmlNodeType.Text)
                    {
                        json[child.Name] = child.InnerText;
                    }
                    else
                    {
                        JsonData childJson = new JsonData();
                        XMLNodeToJosn(child, childJson);
                        //json[child.Name] = childJson;
                        json.Add(childJson);
                    }
                }
                else
                {
                    json[child.Name] = child.InnerText;
                }
            }
        }
        string XMLToJson(string xml, out string rootName)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);

            XmlNode root = (XmlNode)doc.DocumentElement;
            if (root == null)
            {
                rootName = null;
                return "{}";
            }

            rootName = root.Name;

            return XmlToJSONParser.XmlToJSON(doc);

//             JsonData json = new JsonData();
//             XMLNodeToJosn(root, json);
// 
//             return json.ToJson();
        }
        FlatBuffers.ByteBuffer m_flatByteBuffer = new FlatBuffers.ByteBuffer(32*1024);
        void ObjectToJson(object obj, JsonData root) 
        {
            Type type = obj.GetType();
            PropertyInfo[] propertyInfos = type.GetProperties();
            for (int i = 0; i < propertyInfos.Length; ++i)
            {
                PropertyInfo prop = propertyInfos[i];
                Type propType = prop.PropertyType;
                if (propType == typeof(FlatBuffers.ByteBuffer))
                    continue;

                ObjectPropertyToJson(obj, root, prop, propType);
            }
        }
        void ObjectPropertyToJson(object obj, JsonData json, PropertyInfo prop, Type propType) 
        {
            if (propType.IsEnum)
            {
                json[prop.Name] = Enum.GetName(propType, prop.GetValue(obj));
            }
            else if (propType == typeof(string))
            {
                string s = Convert.ToString(prop.GetValue(obj));
                if (!string.IsNullOrEmpty(s))
                {
                    json[prop.Name] = s;
                }
            }
            else if (propType == typeof(bool))
            {
                bool b = Convert.ToBoolean(prop.GetValue(obj));
                if (b)
                {
                    json[prop.Name] = b;
                }
            }
            else if (propType == typeof(UInt16))
            {
                int n = Convert.ToUInt16(prop.GetValue(obj));
                if (n != 0)
                {
                    json[prop.Name] = 0;
                }
            }
            else if (propType == typeof(uint))
            {
                uint n = Convert.ToUInt32(prop.GetValue(obj));
                if (n != 0)
                {
                    json[prop.Name] = n;
                }
            }
            else if (propType == typeof(int))
            {
                int n = Convert.ToInt32(prop.GetValue(obj));
                if (n != 0)
                {
                    json[prop.Name] = 0;
                }
            }
            else if (propType == typeof(ulong))
            {
                ulong n = Convert.ToUInt64(prop.GetValue(obj));
                if (n != 0)
                {
                    json[prop.Name] = n.ToString();
                }
            }
            else if (propType == typeof(long))
            {
                long n = Convert.ToInt64(prop.GetValue(obj));
                if (n != 0)
                {
                    json[prop.Name] = n.ToString();
                }
            }
            else if (propType == typeof(float))
            {
                json[prop.Name] = Convert.ToSingle(prop.GetValue(obj)).ToString("0.####");
            }
            else if (propType == typeof(double))
            {
                json[prop.Name] = Convert.ToDouble(prop.GetValue(obj));
            }
            else if (propType == typeof(Byte))
            {
                json[prop.Name] = Convert.ToByte(prop.GetValue(obj));
            }
            else if (propType == typeof(SByte))
            {
                json[prop.Name] = Convert.ToSByte(prop.GetValue(obj));
            }
            else if (propType.IsGenericType && propType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                Type subType = propType.GetGenericArguments()[0];
                if (subType.Name != null)
                {

                }
                object value = prop.GetValue(obj);
                if (value != null)
                {
                    JsonData subJson = new JsonData();
                    ObjectToJson(value, subJson);
                    json[prop.Name] = subJson;
                }
            }
            else
            {
                LogHelper.LogErrorFormat("Unknown Flatbuffer property type {0}", propType);
            }
        }
        public bool DecodeFlatBuffer(ulong msgid, byte[] bytes, int offset, out FlatBuffers.IFlatbufferObject flatObj)
        {
            if (flatbufferMsgMapping.TryGetValue(msgid, out flatObj))
            {
                m_flatByteBuffer.Reset(bytes, offset);

                flatObj.__init(m_flatByteBuffer.GetInt(m_flatByteBuffer.Position) + m_flatByteBuffer.Position, m_flatByteBuffer);

                return true;
            }

            return false;
        }
        public string FlatBufferToJson(ulong msgid, byte[] bytes, int offset, out string namespaceName, out string typeName)
        {
            FlatBuffers.IFlatbufferObject flatObj;
            if (DecodeFlatBuffer(msgid, bytes, offset, out flatObj))
            {
                JsonData root = new JsonData();

                Type type = flatObj.GetType();
                PropertyInfo[] propertyInfos = type.GetProperties();
                for (int i = 0; i < propertyInfos.Length; ++i)
                {
                    PropertyInfo prop = propertyInfos[i];
                    Type propType = prop.PropertyType;
                    if (propType == typeof(FlatBuffers.ByteBuffer))
                        continue;

                    ObjectPropertyToJson(flatObj, root, prop, propType);
                }

                namespaceName = type.Namespace;
                typeName = type.Name;
                return JsonMapper.ToJson(root);
            }
            else
            {
                namespaceName = null;
                typeName = null;
                return null;
            }
        }
        public void OnSendFBPackage(ulong msgid, byte[] bytes, int offset)
        {
            //if (IDebugSystem.Instance == null || !IDebugSystem.Instance.m_showNetworkLog)
            //    return;

            //string namespaceName;
            //string typeName;
            //string json = FlatBufferToJson(msgid, bytes, offset, out namespaceName, out typeName);
            //if (json != null)
            //    LogHelper.LogFormat("{0}.{1}: {2}", namespaceName, typeName, json);
            //else
            //    LogHelper.LogWarningFormat("OnSendFBPackage - unregistered flatbuffer message {0:X}", msgid);
        }
        public void OnReceiveFBPackage(ulong msgid, byte[] bytes, int offset)
        {
            //if (IDebugSystem.Instance == null || !IDebugSystem.Instance.m_showNetworkLog)
            //    return;

            //string namespaceName;
            //string typeName;
            //string json = FlatBufferToJson(msgid, bytes, offset, out namespaceName, out typeName);
            //if (json != null)
            //    LogHelper.LogFormat("{0}.{1}: {2}", namespaceName, typeName, json);
            //else
            //    LogHelper.LogWarningFormat("OnReceiveFBPackage - unregistered flatbuffer message {0:X}", msgid);
        }

        public class XmlToJSONParser
        {
            private static void OutputNode(string childname, object alChild, StringBuilder sbJSON, bool showNodeName)
            {
                if (alChild == null)
                {
                    if (showNodeName)
                    {
                        sbJSON.Append(SafeJSON(childname));
                        sbJSON.Append(": ");
                    }
                    sbJSON.Append("null");
                }
                else if (alChild is string)
                {
                    if (showNodeName)
                    {
                        sbJSON.Append(SafeJSON(childname));
                        sbJSON.Append(": ");
                    }
                    string s = (string)alChild;
                    s = s.Trim();
                    sbJSON.Append(SafeJSON(s));
                }
                else
                {
                    XmlToJSONnode(sbJSON, (XmlElement)alChild, showNodeName);
                }
                sbJSON.Append(", ");
            }
            public static string SafeJSON(string s)
            {
                if ((s == null) || (s.Length == 0))
                {
                    return "\"\"";
                }
                int length = s.Length;
                StringBuilder builder = new StringBuilder(length + 4);
                builder.Append('"');
                for (int i = 0; i < length; i++)
                {
                    char ch = s[i];
                    switch (ch)
                    {
                        case '\\':
                        case '"':
                        case '>':
                            builder.Append('\\');
                            builder.Append(ch);
                            break;
                        case '\b':
                            builder.Append(@"\b");
                            break;
                        case '\t':
                            builder.Append(@"\t");
                            break;
                        case '\n':
                            builder.Append(@"\n");
                            break;
                        case '\f':
                            builder.Append(@"\f");
                            break;
                        case '\r':
                            builder.Append(@"\r");
                            break;
                        default:
                            if (ch < ' ')
                            {
                                string str2 = new string(ch, 1);

                                string str = Bokura.Utilities.BuildString("000", int.Parse(str2, System.Globalization.NumberStyles.HexNumber).ToString());
                                builder.Append(@"\u");
                                builder.Append(str.Substring(str.Length - 4));
                            }
                            else
                            {
                                builder.Append(ch);
                            }
                            break;
                    }
                }
                builder.Append('"');
                return builder.ToString();
            }
            private static void StoreChildNode(IDictionary childNodeNames, string nodeName, object nodeValue)
            {
                ArrayList list2;
                if (nodeValue is XmlElement)
                {
                    XmlNode node = (XmlNode)nodeValue;
                    if (node.Attributes.Count == 0)
                    {
                        XmlNodeList childNodes = node.ChildNodes;
                        if (childNodes.Count == 0)
                        {
                            nodeValue = null;
                        }
                        else if ((childNodes.Count == 1) && (childNodes[0] is XmlText))
                        {
                            nodeValue = childNodes[0].InnerText;
                        }
                    }
                }
                object obj2 = childNodeNames[nodeName];
                if (obj2 == null)
                {
                    list2 = new ArrayList();
                    childNodeNames[nodeName] = list2;
                }
                else
                {
                    list2 = (ArrayList)obj2;
                }
                list2.Add(nodeValue);
            }
            public static string XmlToJSON(XmlDocument xmlDoc)
            {
                StringBuilder sbJSON = new StringBuilder();
                sbJSON.Append("{ ");
                XmlToJSONnode(sbJSON, xmlDoc.DocumentElement, true);
                sbJSON.Append("}");
                return sbJSON.ToString();
            }
            private static void XmlToJSONnode(StringBuilder sbJSON, XmlNode node, bool showNodeName)
            {
                if (showNodeName)
                {
                    sbJSON.Append(node.Name);
                    sbJSON.Append(": ");
                }
                sbJSON.Append("{");
                SortedList childNodeNames = new SortedList();
                if (node.Attributes != null)
                {
                    foreach (XmlAttribute attribute in node.Attributes)
                    {
                        StoreChildNode(childNodeNames, attribute.Name, attribute.InnerText);
                    }
                }
                foreach (XmlNode node2 in node.ChildNodes)
                {
                    if (node2 is XmlText)
                    {
                        StoreChildNode(childNodeNames, "value", node2.InnerText);
                    }
                    else if (node2 is XmlElement)
                    {
                        StoreChildNode(childNodeNames, node2.Name, node2);
                    }
                }
                foreach (string str in childNodeNames.Keys)
                {
                    ArrayList list2 = (ArrayList)childNodeNames[str];
                    if (list2.Count == 1)
                    {
                        OutputNode(str, list2[0], sbJSON, true);
                    }
                    else
                    {
                        sbJSON.Append(str);
                        sbJSON.Append(": [ ");
                        foreach (object obj2 in list2)
                        {
                            OutputNode(str, obj2, sbJSON, false);
                        }
                        sbJSON.Remove(sbJSON.Length - 2, 2);
                        sbJSON.Append(" ], ");
                    }
                }
                sbJSON.Remove(sbJSON.Length - 2, 2);
                sbJSON.Append(" }");
            }
        }
    }
}
