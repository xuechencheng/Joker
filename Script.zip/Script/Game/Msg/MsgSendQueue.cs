﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bokura;
using UnityEngine;

namespace Bokura
{
    //public class MsgSendQueue
    //{
    //    static MsgSendQueue m_instance;
        
    //    public static MsgSendQueue instance
    //    {
    //        get
    //        {
    //            if (m_instance == null)
    //                m_instance = new MsgSendQueue();
    //            return m_instance;
    //        }
    //    }

    //    struct FlatBufferMessage
    //    {
    //        public FlatBuffers.ByteBuffer bb;
    //        public Type type;
    //        public object param;
    //    }

    //    private List<global::ProtoBuf.IExtensible> m_SendQueuePb = new List<ProtoBuf.IExtensible>(8);
    //    private List<FlatBufferMessage> m_SendQueueFb = new List<FlatBufferMessage>(8);

    //    public void EnqueuePb<T>(T msg) where T : global::ProtoBuf.IExtensible
    //    {
    //        m_SendQueuePb.Add(msg);
    //    }
    //    public T DequeuePb<T>() where T : global::ProtoBuf.IExtensible
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueuePb.Count; ++i)
    //        {
    //            var msg = m_SendQueuePb[i];
    //            if (msg.GetType() == type)
    //            {
    //                m_SendQueuePb.RemoveAt(i);
    //                return (T)msg;
    //            }
    //        }
    //        return default(T);
    //    }
    //    public T PeekPb<T>() where T : global::ProtoBuf.IExtensible
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueuePb.Count; ++i)
    //        {
    //            var msg = m_SendQueuePb[i];
    //            if (msg.GetType() == type)
    //            {
    //                return (T)msg;
    //            }
    //        }
    //        return default(T);
    //    }
    //    public int FirstIndexOfPb<T>() where T : global::ProtoBuf.IExtensible
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueuePb.Count; ++i)
    //        {
    //            var msg = m_SendQueuePb[i];
    //            if (msg.GetType() == type)
    //            {
    //                return i;
    //            }
    //        }
    //        return -1;
    //    }

    //    public void EnqueueFb<T>(FlatBuffers.ByteBuffer bb, object param = null) where T : struct, FlatBuffers.IFlatbufferObject
    //    {
    //        FlatBufferMessage buffer = new FlatBufferMessage()
    //        {
    //            bb = bb.Duplicate(),
    //            type = typeof(T),
    //            param = param,
    //        };

    //        m_SendQueueFb.Add(buffer);
    //    }
    //    public T DequeueFb<T>() where T : struct, FlatBuffers.IFlatbufferObject
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueueFb.Count; ++i)
    //        {
    //            var buffer = m_SendQueueFb[i];
    //            if (buffer.type == type)
    //            {
    //                m_SendQueueFb.RemoveAt(i);
    //                T msg = new T();
    //                msg.__init(buffer.bb.GetInt(buffer.bb.Position) + buffer.bb.Position, buffer.bb);
    //                return msg;
    //            }
    //        }
    //        return default(T);
    //    }
    //    public T DequeueFb<T>(out object param) where T : struct, FlatBuffers.IFlatbufferObject
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueueFb.Count; ++i)
    //        {
    //            var buffer = m_SendQueueFb[i];
    //            if (buffer.type == type)
    //            {
    //                m_SendQueueFb.RemoveAt(i);
    //                T msg = new T();
    //                msg.__init(buffer.bb.GetInt(buffer.bb.Position) + buffer.bb.Position, buffer.bb);

    //                param = buffer.param;

    //                return msg;
    //            }
    //        }
    //        param = null;
    //        return default(T);
    //    }
    //    public T PeekFb<T>() where T : struct, FlatBuffers.IFlatbufferObject
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueueFb.Count; ++i)
    //        {
    //            var buffer = m_SendQueueFb[i];
    //            if (buffer.type == type)
    //            {
    //                T msg = new T();
    //                msg.__init(buffer.bb.GetInt(buffer.bb.Position) + buffer.bb.Position, buffer.bb);
    //                return msg;
    //            }
    //        }
    //        return default(T);
    //    }
    //    public int FirstIndexOfFb<T>() where T : struct, FlatBuffers.IFlatbufferObject
    //    {
    //        Type type = typeof(T);
    //        for (int i = 0; i < m_SendQueueFb.Count; ++i)
    //        {
    //            var buffer = m_SendQueueFb[i];
    //            if (buffer.type == type)
    //            {
    //                return i;
    //            }
    //        }
    //        return -1;
    //    }
    //    public void Clear()
    //    {
    //        m_SendQueuePb.Clear();
    //        m_SendQueueFb.Clear();
    //    }
    //}
}
