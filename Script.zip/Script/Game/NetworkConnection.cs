using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Bokura;

namespace Bokura
{
    public class NetworkConnection : INetworkSimulate
    {

        Socket m_socket;

        MsgDepacker m_Depacker;

        public delegate void ConnectResultDelegate(bool bOK, SocketError _Error);

        public delegate void ReceivePackageDelegate(byte[] package, int nsize);

        public delegate void DisconnectDelegate();

        public delegate void OnPreFBPackageProcess(ulong msgid, byte[] pack, int offset, int nsize);

        public ReceivePackageDelegate onReceivePackage;
        public DisconnectDelegate onDisconnect;


        [XLua.BlackList]
        public OnPreFBPackageProcess onPreFBPackageProcess;

        public static INetworkMsgTamper networkMsgTamper;

        const int PackSize = 32 * 1024;
        const int RecvBuffSize = 512 * 1024;
        long m_sendBytes = 0;
        long m_recvBytes = 0;
        long m_sendPacks = 0;
        long m_recvPacks = 0;

        Stack<SocketAsyncEventArgs> m_freeSendBuffers = new Stack<SocketAsyncEventArgs>(Bokura.ConstValue.kCap32);

        INetworkMonitor m_NetworkMonitor;

        public MsgDepacker Depacker { get => m_Depacker; }

        public long SendBytes{ get => m_sendBytes; set => m_sendBytes = value; }
        public long RecvBytes { get => m_recvBytes; set => m_recvBytes = value; }
        public long SendPacks { get => m_sendPacks; set => m_sendPacks = value; }
        public long RecvPacks { get => m_recvPacks; set => m_recvPacks = value; }


        public void SetNetworkMonitor(INetworkMonitor networkMonitor)
        {
            if (networkMonitor != null)
            {
                this.m_NetworkMonitor = networkMonitor;
                m_Depacker.m_NetworkMonitor = networkMonitor;

                networkMonitor.SetNetworkSimulate(this);
            }
            else
            {
                this.m_NetworkMonitor = null;
                m_Depacker.m_NetworkMonitor = null;
            }
        }

        public NetworkConnection()
		{
			m_instance = this;
			m_Depacker = new MsgDepacker(RecvBuffSize);
			m_Depacker.m_RecvPackageDelegate += (byte[] sb, int size) =>
			{
				if (onReceivePackage != null)
					onReceivePackage(sb, size);
			};
            m_onSendCompelete = onSendCompelte;
            m_onDisconnectTask = onDisconnectTask;

        }

		static NetworkConnection m_instance;
		public static NetworkConnection Instance
		{
			get
			{
				return m_instance;
			}
		}

		public void Connect(string address, int port, ConnectResultDelegate fun)
		{
			Disconnect();


            SocketAsyncEventArgs saea = new SocketAsyncEventArgs();
			IPAddress ip = null;
			try
			{
				ip = IPAddress.Parse(address);
			}
			catch
			{

			}
			if (ip == null)
			{
				var hosts = Dns.GetHostEntry(address);
				ip = hosts.AddressList[hosts.AddressList.Length - 1];
			}

            saea.RemoteEndPoint = new IPEndPoint(ip, port);
			saea.Completed += new EventHandler<SocketAsyncEventArgs>((object sender, SocketAsyncEventArgs e) =>
			{
				bool bOk = e.SocketError == SocketError.Success;
                
                MainThreadTask.getSingleton().push_task(() =>
				{
					fun(bOk, e.SocketError);
				});


				if (bOk)
					requestReceiveData();


			});
			m_socket = new Socket(ip.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
			m_sendThread = new Thread(SendThread);
			m_sendThread.Start();
#if !RELEASE
            //60s 超时,避免真机调试连接时阻塞导致的超时
            m_socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, 60000);
#else
            //5s 超时
            m_socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, 5000);
#endif
            m_socket.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.NoDelay, true);

			m_socket.ConnectAsync(saea);
        }


		AutoResetEvent m_sendEvent = new AutoResetEvent(false);
		Queue<SocketAsyncEventArgs> m_sendQueue = new Queue<SocketAsyncEventArgs>(10);
		Thread m_sendThread;
		void SendThread()
		{
			while(m_socket!=null)
			{

				if(m_sendEvent.WaitOne(100))
				{

					while(m_sendQueue.Count>0)
					{
						SocketAsyncEventArgs saea;
						lock(m_sendQueue)
						{
							saea = m_sendQueue.Dequeue();
						} 
						SocketError socketerr;
						if (m_socket.Send(saea.Buffer, 0, saea.Count, SocketFlags.None, out socketerr) != saea.Count)
						{

						}
					
						saea.SocketError = socketerr;
					
						onSendCompelte(m_socket, saea);
					}
				}
			}
		}

		public bool IsConnected()
		{
            if (networkMsgTamper != null)
                return true;
			if (m_socket != null)
				return m_socket.Connected;
			else
				return false;
		}
        
		public void Disconnect(bool bForceEvent = false)
		{
            lock (this)
			{
				if (m_socket != null)
				{
                    if (m_socket.Connected || bForceEvent)
					{
						if (m_socket.Connected)
							m_socket.Close();

                        MainThreadTask.getSingleton().push_task(m_onDisconnectTask);
                    }

					m_socket = null;
                    LogHelper.Log("Disconnect m_socket = null");

                }

				m_Depacker.clear();
				//m_Depacker = null;
			}
            lock(m_sendQueue)
            {
                m_sendQueue.Clear();
            }
			if(m_sendThread!=null)
			{
                m_sendThread.Join();
                m_sendThread = null;
			}
            

		}


        bool m_receiveBlocked = false;
        public void CheckBufferAndReceive()
        {
            if(m_receiveBlocked)
            {
                lock(this)
                {
                    if (m_Depacker.CheckBufferFreeSize(PackSize))
                    {
                        m_receiveBlocked = false;
                        requestReceiveData();
                    }
                }
                LogHelper.LogWarning("net peak!");
            }
        }

        MainThreadTask.TaskFun m_onDisconnectTask;
        private void onDisconnectTask()
        {
            onDisconnect?.Invoke();
        }

		//原始发包函数自动添加4字节包长度
		public bool SendPackage(byte[] buf)
		{
			if (buf.Length > PackSize)
				return false;
			var sabuf = GetSendBuffer();
			sabuf.Buffer[0] = (byte)(buf.Length & 0xFF);
			sabuf.Buffer[1] = (byte)(buf.Length >> 8);
			sabuf.Buffer[2] = 0;
			sabuf.Buffer[3] = 0;
			System.Array.Copy(buf, 0, sabuf.Buffer, 4, (int)buf.Length);
			return SendPackage(sabuf, buf.Length + 4);
		}
	
		
		

		public bool SendPackage(SocketAsyncEventArgs saea, int size)
        {
            bool handled = false;
            if (m_NetworkMonitor != null)
            {
                m_NetworkMonitor.BeforeSend(saea.Buffer, size, out handled);
            }
            if (handled)
            {
                return true;
            }

            if (m_socket == null )
			{
                LogHelper.LogWarning("send error! :socket is null");
                return false;
			}
			if (!m_socket.Connected)
			{
                LogHelper.LogWarning("send error! :socket is not connect!");
                return false;
			}

			saea.SetBuffer(saea.Buffer, 0, size);
			try
			{
				
				//m_socket.SendAsync(saea);
				lock(m_sendQueue)
				{
					m_sendQueue.Enqueue(saea);
				}
				m_sendEvent.Set();
			}
			catch(Exception e)
			{
                LogHelper.LogWarning("send error! :", e.ToString());
                Disconnect(true);
				return false;
			}

			return true;

		}

		public SocketAsyncEventArgs GetSendBuffer()
		{
			lock(m_freeSendBuffers)
			{
				if (m_freeSendBuffers.Count > 0)
				{
					return m_freeSendBuffers.Pop();
				}
				else
				{
					SocketAsyncEventArgs saea = new SocketAsyncEventArgs();
					saea.Completed += m_onSendCompelete;
					byte[] data = new byte[PackSize];
					saea.SetBuffer(data, 0, data.Length);
					return saea;
				}
			}

		}

        EventHandler<SocketAsyncEventArgs> m_onSendCompelete;
        void onSendCompelte(object sender, SocketAsyncEventArgs e)
		{
			bool bOk = e.SocketError == SocketError.Success;

			if (!bOk)
			{

                if (sender == m_socket)
                {
                    MainThreadTask.getSingleton().push_task(() => 
                    {
                        Disconnect(true);
                    });                    
                }

			}
            m_sendBytes += e.Count;
            m_sendPacks++;
            lock (m_freeSendBuffers)
			{
				m_freeSendBuffers.Push(e);
			}
            if (bOk && m_NetworkMonitor != null)
            {
                lock (m_NetworkMonitor)
                {
                    m_NetworkMonitor.SendComplete(e.Buffer, e.Count);
                }
            }
            
		}

		void onReceiveData(object sender, SocketAsyncEventArgs e)
		{
			lock (this)
			{
				bool bOk = e.SocketError == SocketError.Success;

				if (bOk)
				{
                    //LogHelper.Log(string.Format("net work recv {0} bytes", e.BytesTransferred));
                    if (e.BytesTransferred > 0 && sender == m_socket)
					{
                        //byte[] recvdatas = new byte[e.BytesTransferred];
                        //System.Array.Copy(e.Buffer, recvdatas, recvdatas.Length);
                        m_recvBytes += e.BytesTransferred;
                        m_recvPacks++;
						if(!m_Depacker.writeData(e.Buffer,0,e.BytesTransferred))
                        {
                            LogHelper.LogError("net buffer overflow!");
                            
                            Disconnect(true);
                        }
					}
                    m_freeEvent.Push(e);
                    if(m_Depacker.CheckBufferFreeSize(PackSize))
                    {
                        requestReceiveData();
                    }
                    else
                    {
                        m_receiveBlocked = true;
                    }
                        
				}
				else
				{
                    m_freeEvent.Push(e);
                    if (sender == m_socket)
						Disconnect(true);
				}
			}
		}


        // SocketAsyncEventArgs m_recvEvent;// = new SocketAsyncEventArgs();
        Stack<SocketAsyncEventArgs> m_freeEvent = new Stack<SocketAsyncEventArgs>(4);

        int m_socketEventCount = 0;
        public int SocketEventCount { get => m_socketEventCount; }
        void requestReceiveData()
		{


			try
			{
				lock(this)
				{
                    SocketAsyncEventArgs ea;// = m_Depacker.GetFreeBuf();
					if (m_freeEvent.Count == 0)
					{
                        ea = new SocketAsyncEventArgs();
                        ea.SetBuffer(new byte[PackSize], 0, PackSize);
                        ea.Completed += onReceiveData;
                        m_socketEventCount++;

                    }
                    else
                    {
                        ea = m_freeEvent.Pop();
 
                    }

					if (m_socket != null && !m_socket.ReceiveAsync(ea))
					{
						onReceiveData(m_socket, ea);
					}
				}	

			}
			catch (ObjectDisposedException ode)
			{
				Disconnect(true);
                LogHelper.LogError(ode.ToString());
            }
			catch(SocketException se)
			{
				Disconnect(true);
                LogHelper.LogError(se.ToString());
            }
			catch(Exception e)
			{
				Disconnect(true);
                LogHelper.LogError(e.ToString());
            }

		}

        void INetworkSimulate.SimulateSendEvent(byte[] buffer, int buflen)
        {
            
        }

        //void INetworkSimulate.SimulateReceiveProtoBufferEvent(string msgTypeName, byte[] buffer, int buflen)
        //{
        //    m_Depacker.SimulateReceiveProtoBuffer(msgTypeName, buffer, buflen);
        //}

        void INetworkSimulate.SimulateReceiveFlatBufferEvent(ulong msgid, byte[] bytes, int offset, int size)
        {
            m_Depacker.SimulateReceiveFlatBuffer(msgid, bytes, offset, size);
        }

        public class MsgDepacker
		{
            public INetworkMonitor m_NetworkMonitor;

            public delegate void RecvPackageDelegate(byte[] sb, int size);
			public RecvPackageDelegate m_RecvPackageDelegate;


            FIFOFixedStream m_fifo;

            int m_nCurPackSize;
            byte[] m_tempBuffer = new byte[68 * 1024];

            public FIFOFixedStream FIFO { get => m_fifo; }
            public MsgDepacker(int buffsize=128*1024)
			{
                m_fifo = new FIFOFixedStream(buffsize);
            }

			public void clear()
			{
                m_fifo.Reset();
               
            }

			public bool writeData(byte[] data, int offset, int len)
			{
                lock (this)
                {

                    return m_fifo.Write(data, offset, len);
				}

			}

           
            public bool CheckBufferFreeSize(int size)
            {
                return m_fifo.FreeSize >= size;
            }

			bool decodeFlatBuffer(byte[] data, int offset, int len)
			{
                offset += 8;
                var msgid = Utility.ReadUInt64(data, offset);offset += 8;//m_binaryReader.ReadUInt64();
                var buflen = Utility.ReadInt32(data, offset);offset += 4; //m_binaryReader.ReadInt32();

                if (networkMsgTamper == null || networkMsgTamper.OnReceiveFBPackage(msgid, ref data, ref offset, ref buflen))
                {
                    if (m_NetworkMonitor != null)
                    {
                        m_NetworkMonitor.ReceiveFlatBufferComplete(msgid, data, offset, buflen);
                    }
                   

                    Game.MsgDispatcher.instance.ProcFlatBufferPackage(msgid, data, (int)offset, buflen);
                }



                return true;
			
			}

			public bool getMsg()
			{
                //lock(this)
                //{
                if (m_nCurPackSize == 0)
                {
                    if (m_fifo.DataSize < 4)
                        return false;

                    m_nCurPackSize = m_fifo.ReadInt();



                }


                if (m_nCurPackSize <= m_fifo.DataSize)
                {
                    byte[] data;
                    int offset;
                    var packlen = m_nCurPackSize;
                    m_nCurPackSize = 0;
                    lock(m_fifo)
                    {
                        offset = m_fifo.CanDirectRead(packlen);
                        if (offset >= 0)
                        {
                            data = m_fifo.RawBuffer;
                        }
                        else
                        {
                            lock (m_fifo)
                                m_fifo.Read(m_tempBuffer, 0, packlen);
                            offset = 0;
                            data = m_tempBuffer;
                        }
                    }


                    var cmd = data[offset]; offset++;
                    var param = data[offset]; offset++;

                    if (cmd == 250 && param == 251)
                    {
                        bool handled = false;
                        if (m_NetworkMonitor != null)
                        {
                            m_NetworkMonitor.BeforeReceiveFlatBuffer(data, offset, packlen, out handled);
                        }
                        if (handled)
                        {
                            return true;
                        }

                        decodeFlatBuffer(data, offset, packlen);

                    }
                    else
                    {
                        LogHelper.LogFormat("msg not support, cmd={0}, param={1}", cmd, param);
                    }

                    if (data != m_tempBuffer)
                    {
                        lock (m_fifo)
                        {
                            m_fifo.EmptyRead(packlen);
                        }
                    }
                    return true;
                }



                return false;
                //}

            }



           
            public void SimulateReceiveFlatBuffer(ulong msgid, byte[] bytes, int offset, int size)
            {
                Game.MsgDispatcher.instance.ProcFlatBufferPackage(msgid, bytes, offset, size);
            }


          
			
		}

	}

    public interface INetworkSimulate
    {
        void SimulateSendEvent(byte[] buffer, int buflen);
        //void SimulateReceiveProtoBufferEvent(string msgTypeName, byte[] buffer, int buflen);
        void SimulateReceiveFlatBufferEvent(ulong msgid, byte[] bytes, int offset, int size);
    }

    public interface INetworkMonitor
    {
        void SetNetworkSimulate(INetworkSimulate simulator);

        void BeforeSend(byte[] buffer, int buflen, out bool handled);

        void SendComplete(byte[] buffer, int buflen);
        //void BeforeReceiveProtoBuffer(byte[] buffer, int buflen, out bool handled);
        //void ReceiveProtoBufferComplete(string msgtypename, byte[] buffer, int buflen);
        void BeforeReceiveFlatBuffer(byte[] buffer, int offset, int buflen, out bool handled);
        void ReceiveFlatBufferComplete(ulong msgid, byte[] bytes, int offset, int size);
    }

    /// <summary>
    /// 消息篡改器
    /// 收发消息的接口返回false表示发送或接收取消，返回true表示正常发送和接收
    /// </summary>
    public interface INetworkMsgTamper
    {
       // bool OnSendProtobufPackage<T>(ref T msg) where T : ProtoBuf.IExtensible;
        //bool OnSendProtobufPackage(string protoname, ref byte[] luaPBData);
        bool OnSendFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size);
        bool OnReceiveFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size);
        //bool OnReceiveProtobufPackage(ref object msg);
    }

    public class NetworkMonitorBase : INetworkMonitor
    {
        public virtual void BeforeReceiveFlatBuffer(byte[] buffer, int offset, int buflen, out bool handled)
        {
            handled = false;
        }

        public virtual void BeforeReceiveProtoBuffer(byte[] buffer, int buflen, out bool handled)
        {
            handled = false;
        }

        public virtual void BeforeSend(byte[] buffer, int buflen, out bool handled)
        {
            handled = false;
        }

        public virtual void ReceiveFlatBufferComplete(ulong msgid, byte[] bytes, int offset, int size)
        {
            
        }

        public virtual void ReceiveProtoBufferComplete(string msgtypename, byte[] buffer, int buflen)
        {
            
        }

        public virtual void SendComplete(byte[] buffer, int buflen)
        {
            
        }

        public virtual void SetNetworkSimulate(INetworkSimulate simulator)
        {
            
        }
    }

#if REMOTE_DEBUG

    [ParamDebug.ParamSet("Network")]
    public static class NetworkInfo
    {
        static public int BufferUsed
        {
            get
            {
                return NetworkConnection.Instance.Depacker.FIFO.DataSize;
            }
        }

        static public int SocketEventCount
        {
            get
            {
                return NetworkConnection.Instance.SocketEventCount;
            }
        }

        static public long RecvBytes
        {
            get
            {
                return NetworkConnection.Instance.RecvBytes;
            }
        }
        static public long SendBytes
        {
            get
            {
                return NetworkConnection.Instance.SendBytes;
            }
        }
        static public long RecvPacks
        {
            get
            {
                return NetworkConnection.Instance.RecvPacks;
            }
        }
        static public long SendPacks
        {
            get
            {
                return NetworkConnection.Instance.SendPacks;
            }
        }

        static ulong m_prevRecvAccessTime;
        static long m_prevRecvBytes;
        static float m_recvSpeed;
        static public float RecvSpeedKB
        {
            get
            {
                var now = (ulong)DateTime.Now.ToBinary();
                var d = now - m_prevRecvAccessTime;
                if (d>10000000)
                {
                    var curbytes = NetworkConnection.Instance.RecvBytes;
                    m_recvSpeed = (curbytes - m_prevRecvBytes) / (d / 10000.0f);
                    m_prevRecvBytes = curbytes;
                    m_prevRecvAccessTime = now;
                }
                return m_recvSpeed;
            }
        }

        static ulong m_prevSendAccessTime;
        static long m_prevSendBytes;
        static float m_sendSpeed;
        static public float SendSpeedKB
        {
            get
            {
                var now = (ulong)DateTime.Now.ToBinary();
                var d = now - m_prevSendAccessTime;
                if (d > 10000000)
                {
                    var curbytes = NetworkConnection.Instance.SendBytes;
                    m_sendSpeed = (curbytes - m_prevSendBytes) / (d / 10000.0f);
                    m_prevSendBytes = curbytes;
                    m_prevSendAccessTime = now;
                }
                return m_sendSpeed;
            }
        }

    }


#endif
}


