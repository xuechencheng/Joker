using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public enum EnumNotifyType
    {
        Notify_Default = 0,         //无
        Notify_Middle,          //从中间向上滚动(通用上浮)
        Notify_Roll,            //屏幕中上位置，从右向左滚动(跑马灯)
        Notify_SystemNotify,    //系统通知(头顶显示)
        Notify_SystemInfo,      //系统消息(频道)
        Notify_Dialog,          //弹框提示
        Notify_Special,         //特殊类型
        Notify_Sept,            //仙门(频道)
        Notify_World,           //世界(频道)
        Notify_MissionGuild,    //任务中的特殊提示
        Notify_Letter,          //信件样式的提示
    }

    /// <summary>
    /// 系统消息通知
    /// </summary>
    class NotifyModel : ClientSingleton<NotifyModel>
    {
        public class SystemMessageEvent : GameEvent<int, int, string, Ts_InfoBase?>
        {

        }
        public SystemMessageEvent onDefaultMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onMiddleMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onRollMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onSystemNotifyMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onSystemInfoMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onDialogMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onSpecialMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onSeptMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onWorldMessageEvent = new SystemMessageEvent();
        public SystemMessageEvent onMissionGuildEvent = new SystemMessageEvent();
        public SystemMessageEvent onLetterEvent = new SystemMessageEvent();

        public GameEvent<int> onMessageEvent = new GameEvent<int>();

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.SysMessage>(ProcNotifyInfo);
        }

        public void Clear()
        {

        }

		public int GetInfoSectorLength(int sectorBeginId)
		{
			int len = 0;
			var tsinfos = Ts_InfoManager.Instance.m_DataList;
			for (int i = 0; i < tsinfos.Ts_InfoLength; i ++)
			{
				if(tsinfos.Ts_Info(i).Value.id == sectorBeginId)
				{
					var nextid = sectorBeginId;
					for(;i<tsinfos.Ts_InfoLength; i++)
					{
						if (tsinfos.Ts_Info(i).Value.id != nextid)
							break;
						len++;
						nextid++;
					}
				}
			}
			return len;
		}
        public string GetInfoByData(TsInfoID _tsEnum, List<swm.TsParamsT> _list = null, Ts_InfoBase? _info = null)
        {
            return GetInfoByData((int)_tsEnum, _list,_info);
        }
        public string GetInfoByData(int _tsId,List<swm.TsParamsT> _list = null, Ts_InfoBase? _info=null)
        {
            string str = string.Empty;
            Ts_InfoBase? _infoBase = _info;
            if(null == _infoBase)
            {
                _infoBase = Ts_InfoManager.GetData(_tsId);
            }
                
            if(_infoBase.HasValue)
            {
                
                int hashcode = _infoBase.Value.content.GetHashCode();
                str = ILocalizationManager.Instance.GetText_HashCode(hashcode);
                if (string.IsNullOrEmpty(str))
                {
                    str = _infoBase.Value.content;
                }
                //int localid = _infoBase.local_id;
                //if (_infoBase.local_id > 0)
                //{
                //    str = LocalizationManager.Instance.GetText(localid);
                //}
                //else
                //{
                //    str = _infoBase.content;
                //}
               
                if (_list != null && _list.Count > 0)
                {
                    for (int i = 0; i < _list.Count; i++)
                    {
                        var _param = _list[i];
                        str = str.Replace(_param.key, _param.value);
                    }
                }
            }

            return str;
        }



		/// <summary>
		/// 获取按数据填充后的字符串信息
		/// </summary>
		public string GetInfoByData(int tsID, List<swm.TsParams?> list)
		{
			string tStr = string.Empty;
			Ts_InfoBase? tInfoBase = Ts_InfoManager.GetData(tsID);
			if (tInfoBase.HasValue)
			{
				int tHashcode = tInfoBase.Value.content.GetHashCode();
				tStr = ILocalizationManager.Instance.GetText_HashCode(tHashcode);
				if (string.IsNullOrEmpty(tStr))
					tStr = tInfoBase.Value.content;
				if (list != null && list.Count > 0)
				{
					for (int tIdx = 0; tIdx < list.Count; tIdx++)
					{
						swm.TsParams? tParam = list[tIdx];
						if (tParam.HasValue)
						{
							swm.TsParams tValue = tParam.Value;
							tStr = tStr.Replace(tValue.key, tValue.value);
						}
					}
				}
			}
			return tStr;
		}



		public void DispathTypeEvent(int _tsId, string _infoContent)
        {
            Ts_InfoBase? _infoBase = Ts_InfoManager.GetData(_tsId);
            if (null != _infoBase)
            {
                DispathTypeEvent(_infoBase.Value, _infoContent);
            }
        }
        public void GetInfoAndDispathTypeEvent(TsInfoID _tsEnum, List<swm.TsParamsT> _list=null)
        {
            GetInfoAndDispathTypeEvent((int)_tsEnum, _list);
        }
        public void GetInfoAndDispathTypeEvent(int _tsId, List<swm.TsParamsT> _list=null)
        {
            Ts_InfoBase? _infoBase = Ts_InfoManager.GetData(_tsId);
            if (null != _infoBase)
            {
                DispathTypeEvent(_infoBase.Value, GetInfoByData(_tsId, _list, _infoBase));
            }
        }
        public void DispathTypeEvent(Ts_InfoBase? _infoBase,string _infoContent)
        {
            Ts_InfoBase _infoValue = _infoBase.Value;
            if (_infoBase != null && _infoValue.show_typeLength > 0)
            {
                for (int i = 0; i < _infoValue.show_typeLength; i++)
                {
                    int _value = _infoValue.show_type(i);
                    int _id = _infoValue.id;
                    if (_value == (int)EnumNotifyType.Notify_Middle)
                    {
                        onMiddleMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_Roll)
                    {
                        onRollMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_SystemNotify)
                    {
                        onSystemNotifyMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_SystemInfo)
                    {
                        onSystemInfoMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_Dialog)
                    {
                        onDialogMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_Special)
                    {
                        onSpecialMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_Sept)
                    {
                        onSeptMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if (_value == (int)EnumNotifyType.Notify_World)
                    {
                        onWorldMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if(_value == (int)EnumNotifyType.Notify_MissionGuild)
                    {
                        onMissionGuildEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else if(_value == (int)EnumNotifyType.Notify_Letter)
                    {
                        onLetterEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                    else
                    {
                        onDefaultMessageEvent.Invoke(_value, _id, _infoContent, _infoValue);
                    }
                }
            }
        }

        //测试用，正式消息别用这个接口
        public void DisplayString(EnumNotifyType t, string _infoContent, Ts_InfoBase? _infoBase = null)
        {
            var _id = _infoBase == null ? 0 : _infoBase.Value.id;
            var _value = (int)t;
            switch (t)
            {
                case EnumNotifyType.Notify_Middle:
                    onMiddleMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_Roll:
                    onRollMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_SystemNotify:
                    onSystemNotifyMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_SystemInfo:
                    onSystemInfoMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_Dialog:
                    onDialogMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_Special:
                    onSpecialMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_Sept:
                    onSeptMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_World:
                    onWorldMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_MissionGuild:
                    onMissionGuildEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_Letter:
                    onLetterEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
                case EnumNotifyType.Notify_Default:
                default:
                    onDefaultMessageEvent.Invoke(_value, _id, _infoContent, _infoBase);
                    break;
            }
        }

        swm.SysMessageT m_recvSysMessage = new swm.SysMessageT();
        public void ProcNotifyInfo(swm.SysMessage _msg)
        {

            int _tsId = (int)_msg.ts_id;
            Ts_InfoBase? _infoBase = Ts_InfoManager.GetData(_tsId);
            m_recvSysMessage.FromMsg(_msg);
            if (null != _infoBase)
            {
                string str = GetInfoByData(_tsId, m_recvSysMessage.ts_params,_infoBase);
                DispathTypeEvent(_infoBase, str);
            }

            onMessageEvent.Invoke(_tsId);
        }
    }
}
