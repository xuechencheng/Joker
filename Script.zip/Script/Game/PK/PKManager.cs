using System.Collections.Generic;
using UnityEngine;
using Bokura;

namespace Bokura
{

	public enum PKMode
	{
		None,
		Peace,
		GoodEvil,
		Kill,
		Camp,
		Gang,
	}

	public class PKManager : ClientSingleton<PKManager>
	{
		public PKManager()
		{
			MsgDispatcher.instance.RegisterFBMsgProc<swm.RspSwitchPKMode>(ProcRspSwitchPKMode);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyUserPKMode>(ProcNotifyUserPKMode);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyHitBackList>(ProcNotifyHitBackList);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyKillerValue>(ProcNotifyKillerValue);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyStartChallenge>(ProcNotifyStartChallenge);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyChallengeOver>(ProcNotifyChallengeOver);


			MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyInviteDuel>(ProcNotifyInviteDuel);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.DuelFightPrepare>(ProcDuelFightPrepare);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.DuelFightStart>(ProcDuelFightStart);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.DuelFightOver>(ProcDuelFightOver);
			MsgDispatcher.instance.RegisterFBMsgProc<swm.ResInviteDuel>(ProcResInviteDuel);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyCancelInviteDuel>(ProcNotifyCancelInviteDuel);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ResCancelInviteDuel>(ProcResCancelInviteDuel);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyRejectDuel>(ProcNotifyRejectDuel);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyChallengeResult>(ProcNotifyChallengeResult);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspSetProtectType>(ProcRspSetProtectType);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyOutOfAreaState>(ProcNotifyOutOfAreaState);

        }

        PKMode m_curMode = PKMode.Peace;
		PKMode CurMode
		{
			get
			{
				return m_curMode;
			}
		}

		ulong m_timeout=0;
		public float TimeOut
		{
			get
			{
                var servertime = GameScene.Instance.GetServerTime();
                if (m_timeout > servertime)
                    return (m_timeout - GameScene.Instance.GetServerTime())/1000.0f;
                else
                    return 0.0f;
                
			}
		}

		ulong m_duelTargetID = 0;

		public ulong GetDuelTargetID
		{
			get
			{
				return m_duelTargetID;
			}
			
		}

		Vector3 m_duelCenter;
		public Vector3 DuelCenter
		{
			get
			{
				return m_duelCenter;
			}

		}

        public float LeaveDuelCenterDis
        {
            get
            {
                if (GameScene.Instance.MainChar)
                    return (m_duelCenter - GameScene.Instance.MainChar.Position).magnitude;
                else
                    return 0.0f;
            }
        }

		ulong m_duelStartTime = 0;
		public ulong DuelStartTime
		{
			get
			{
				return m_duelStartTime;
			}
		}

        ulong m_challengeTargetID=0;
        public ulong ChallengeTargetID
        {
            get
            {
                return m_challengeTargetID;
            }
        }

        swm.PKResultType m_challengeResult= 0;
        public swm.PKResultType ChallengeResult
        {
            get
            {
                return m_challengeResult;
            }
        }
        bool m_challengeActive= false;
        public bool ChallengeActive
        {
            get
            {
                return m_challengeActive;
            }
        }

        IAvatar m_flagAvatar = null;

		public Event OnDuelTargetChange = new Event();

		public Event OnDuelPrepare = new Event();

		public Event<ulong,string> OnDuelInvite = new Event<ulong, string>();

		public Event<int> OnDuelOver = new Event<int>();

        public Event OnInviteCancel = new Event();

        public Event OnReqInviteSuccess = new Event();
        public Event OnReqInviteCancel = new Event();

        public Event<bool> OnInviteReject = new Event<bool>();

        public Event  OnChallengeResult = new Event();
        public Event<ulong> OnAddChallenge = new Event<ulong>();
        public Event<ulong> OnRemoveChallenge = new Event<ulong>();

        public Event OnProtectTypeChange = new Event();

        public Event<bool> OnOutOfDuelRangeChange = new Event<bool>();

        int m_protectType = 0;
        public int ProtectType
        {
            get
            {
                return m_protectType;
            }
        }

        public void RequestSetProtectType(swm.PKProtectType type, bool on)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSetProtectType.StartReqSetProtectType(fbb);
            swm.ReqSetProtectType.AddProtectType(fbb, type);
            swm.ReqSetProtectType.AddIsSet(fbb, on);
            var offset = swm.ReqSetProtectType.EndReqSetProtectType(fbb);
            fbb.Finish(offset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSetProtectType.HashID, fbb);
        }

        public void RequsetChangeMode(PKMode mode)
		{
			var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.ReqSwitchPKMode.StartReqSwitchPKMode(fbb);
			swm.ReqSwitchPKMode.AddMode(fbb, (swm.PKModeType)mode);
			var offset = swm.ReqSwitchPKMode.EndReqSwitchPKMode(fbb);
			fbb.Finish(offset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqSwitchPKMode.HashID, fbb);
            //LogHelper.Log("req change pk mode" + mode);

        }

        public void RequestStartChallenge(ulong charid)
		{
			var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.ReqStartChallenge.StartReqStartChallenge(fbb);
			swm.ReqStartChallenge.AddId(fbb, charid);
			fbb.Finish(swm.ReqStartChallenge.EndReqStartChallenge(fbb).Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqStartChallenge.HashID, fbb);
            //LogHelper.Log("req start challenge!");
        }

        public void RequestInviteDuel(ulong charid)
		{
			var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.ReqInviteDuel.StartReqInviteDuel(fbb);
			swm.ReqInviteDuel.AddId(fbb,charid);
			fbb.Finish(swm.ReqInviteDuel.EndReqInviteDuel(fbb).Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqInviteDuel.HashID, fbb);
            m_duelTargetID = charid;
            //LogHelper.Log("RequestInviteDuel"+charid);
        }

        public void RequestSurrenderDuel()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSurrenderDuel.StartReqSurrenderDuel(fbb);
            fbb.Finish(swm.ReqSurrenderDuel.EndReqSurrenderDuel(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSurrenderDuel.HashID, fbb);
            // LogHelper.Log("ReqSurrenderDuel");
        }
        public void RequestCancelInviteDuel()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqCancelInviteDuel.StartReqCancelInviteDuel(fbb);
            fbb.Finish(swm.ReqCancelInviteDuel.EndReqCancelInviteDuel(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCancelInviteDuel.HashID, fbb);
            //LogHelper.Log("RequestCancelInviteDuel");

        }

        public void RequestAnswerInviteDuel(bool accept)
		{
			var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
			swm.AnswerInviteDuel.StartAnswerInviteDuel(fbb);
			swm.AnswerInviteDuel.AddAccept(fbb, accept);
			fbb.Finish(swm.AnswerInviteDuel.EndAnswerInviteDuel(fbb).Value);
			MsgDispatcher.instance.SendFBPackage(swm.AnswerInviteDuel.HashID, fbb);
            //LogHelper.Log("AnswerInviteDuel" + accept);
        }
        void ProcRspSwitchPKMode(swm.RspSwitchPKMode msg)
		{
			m_timeout = msg.timeout;
			if (GameScene.Instance.MainChar && msg.result == swm.SwitchPKModeCode.Success)
			{
				GameScene.Instance.MainChar.CurPKMode = msg.mode;
                //LogHelper.Log("res change pk mode" + GameScene.Instance.MainChar.CurPKMode);
            }

        }

		void ProcNotifyUserPKMode(swm.NotifyUserPKMode msg)
		{
			var entity = GameScene.Instance.GetEntityByID(msg.uid) as Character;
			if (!entity)
				return;
			entity.CurPKMode = msg.mode;
						
		}
		void ProcNotifyHitBackList(swm.NotifyHitBackList msg)
		{
            //LogHelper.Log("ProcNotifyHitBackList" + msg.uid + " " + msg.isadd);
            var entity = GameScene.Instance.GetEntityByID(msg.uid);
			if (!entity)
				return;
			entity.IsInHitBackList = msg.isadd;
		}

		void ProcNotifyKillerValue(swm.NotifyKillerValue msg)
		{
            //LogHelper.Log("ProcNotifyKillerValue" + msg.uid + " " + msg.killer_value);
            var entity = GameScene.Instance.GetEntityByID(msg.uid) as Character;
			if (!entity)
				return;
			entity.KillQi = msg.killer_value;

		}

        void ProcRspSetProtectType(swm.RspSetProtectType msg)
        {
            m_protectType = (int)msg.protect_type;
            OnProtectTypeChange?.Invoke();
        }

        #region 宣战
        //切磋
        void ProcNotifyStartChallenge(swm.NotifyStartChallenge msg)
		{
            //LogHelper.Log("ProcNotifyStartChallenge" + msg.id + " ");
            var entity = GameScene.Instance.GetEntityByID(msg.id) as Character;
			if (!entity)
				return;
			entity.IsChallengeTarget = true;
            OnAddChallenge?.Invoke(msg.id);

        }
		void ProcNotifyChallengeOver(swm.NotifyChallengeOver msg)
		{
            //LogHelper.Log("ProcNotifyChallengeOver" + msg.id + " ");
            for (int i = 0; i < msg.idLength; i ++ )
			{
				var entity = GameScene.Instance.GetEntityByID(msg.id(i)) as Character;
				if (!entity)
					continue;
				entity.IsChallengeTarget = false;
                OnRemoveChallenge?.Invoke(msg.id(i));
            }
			
		}

        void ProcNotifyChallengeResult(swm.NotifyChallengeResult msg)
        {
            m_challengeTargetID = msg.id;
            m_challengeResult = msg.result;
            m_challengeActive = msg.active;
            OnChallengeResult.Invoke();

        }

        #endregion

        #region 切磋

        void ProcNotifyInviteDuel(swm.NotifyInviteDuel msg)
		{
            //LogHelper.Log("[HC]Recv swm.NotifyInviteDuel", msg.id);
			var entity = GameScene.Instance.GetEntityByID(msg.id);
			if(entity)
			{
				entity.CrossFadeAll(AnimatorStateID.DuelInvite);
			}
            else
            {
                LogHelper.LogError("[HC] entity not found!", msg.id.ToString(), msg.name);
            }

			OnDuelInvite.Invoke(msg.id, msg.name);
		}

		void ProcResInviteDuel(swm.ResInviteDuel msg)
		{
            //LogHelper.Log("[HC]Recv swm.ResInviteDuel");
            GameScene.Instance.MainChar.CrossFadeAll(AnimatorStateID.DuelInvite);
            OnReqInviteSuccess.Invoke();

        }


		const string flatpath = "npc_duelflag";
		void ProcDuelFightPrepare(swm.DuelFightPrepare msg)
		{
            //LogHelper.Log("[HC]Recv swm.DuelFightPrepare");

            m_duelCenter = msg.center_pos.FBVec3Vec3();
            //LogHelper.Log("DuelFightPrepare" + m_duelCenter + " " + msg.curtime);
            m_duelStartTime = msg.curtime + msg.timeout;
            m_duelTargetID = msg.peer_id;

            OnDuelPrepare.Invoke();

			m_flagAvatar = IFactory.Instance.CreateAvatar(null);
			m_flagAvatar.LoadModel(IResourceLoader.strNpcPath, flatpath, true);
			m_flagAvatar.SetPosition(m_duelCenter);

		}

		void ProcDuelFightStart(swm.DuelFightStart msg)
		{
            //LogHelper.Log("DuelFightStart" + msg.id);

            //LogHelper.Log("[HC]Recv swm.DuelFightStart");

            m_duelTargetID = msg.id;
			OnDuelTargetChange.Invoke();
		
			var entity = GameScene.Instance.GetEntityByID(msg.id) as Character;
			if (!entity)
				return;
			entity.IsDuleTarget = true;
		}

		void ProcDuelFightOver(swm.DuelFightOver msg)
		{
            //LogHelper.Log("ProcDuelFightOver" );
            //LogHelper.Log("[HC]Recv swm.DuelFightOver");

            if (m_duelTargetID!=0)
			{
				var entity = GameScene.Instance.GetEntityByID(m_duelTargetID) as Character;
				if (entity)
				{
					entity.IsDuleTarget = false;
				}

			}
			OnDuelOver.Invoke((int)msg.result);
			if(m_flagAvatar!=null)
			{
				m_flagAvatar.Release();
                IFactory.Instance.ReleaseAvatar(m_flagAvatar);
                m_flagAvatar = null;
            }
            m_duelTargetID = 0;

        }

        void ProcNotifyRejectDuel(swm.NotifyRejectDuel msg)
        {
            OnInviteReject.Invoke(msg.is_active);
        }

        void ProcNotifyCancelInviteDuel(swm.NotifyCancelInviteDuel msg)
        {
            OnInviteCancel.Invoke();
        }

        void ProcResCancelInviteDuel(swm.ResCancelInviteDuel msg)
        {
            OnReqInviteCancel.Invoke();
        }

        void ProcNotifyOutOfAreaState(swm.NotifyOutOfAreaState msg)
        {
            OnOutOfDuelRangeChange.Invoke(msg.is_out);
        }
        #endregion
    }
}