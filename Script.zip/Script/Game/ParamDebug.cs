using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.PostProcessing;
using Bokura;

namespace Bokura
{

#if REMOTE_DEBUG

    public class X2DebugUtilities
    {
        GameObject effectCamera = null;
        PostProcessLayer layer = null;
        public static X2DebugUtilities Instance = new X2DebugUtilities();
        public PostProcessLayer postProcessLayer
        {
            get
            {
                if (effectCamera == null)
                {
                    effectCamera = GameObject.Find("Main_Camera");
                    if (effectCamera != null)
                    {
                        layer = effectCamera.GetComponent<PostProcessLayer>();
                    }
                }
                return layer;
            }
        }
    }
    [ParamDebug.ParamSet("Memory")]
    public static class ParamDebugMemoryInfo
    {
        static XLua.LuaFunction m_fun;
        static public float LuaMemory
        {
            get
            {
                //GameApplication.Instance.LuaInstance
                if (m_fun == null)
                {
                    m_fun = LuaFunctor.DoString("return function() return collectgarbage('count') / 1024 end")[0] as XLua.LuaFunction;
                }
                var v = m_fun.Func<double>();
                return (float)v;
            }
        }

        static long m_tablesMemory = 0;

        static public long TablesMemory
        {
            get
            {
                return m_tablesMemory;
            }
        }

        public static void SetTablesMemory(long value)
        {
            m_tablesMemory = value;
        }
    }

    //public enum X2ScreenScale
    //{
    //    Percent10 = 10,
    //    Percent20 = 20,
    //    Percent30 = 30,
    //    Percent40 = 40,
    //    Percent50 = 50,
    //    Percent60 = 60,
    //    Percent70 = 70,
    //    Percent80 = 80,
    //    Percent90 = 90,
    //    Percent100 = 100,

    //}

    [ParamDebug.ParamSet("Foliage")]
    public static class FoliageSetting
    {
        static GrassSetting _grassInst = null;
        static TreeSetting _treeInst = null;
        private static bool _enabled;
        public static bool EnabledDebug
        {
            get { return _enabled; }

            set { _enabled = value; }
        }

        /// <summary>
        /// key:typehash
        /// value:count
        /// </summary>
        [System.NonSerialized]
        static public Dictionary<int, int> TreeTypeList = new Dictionary<int, int>();

        static public List<int> TreeEnablelist = new List<int>(3);
        static public int MaxCountTree;
        public static bool MaxCountTreeEnable = true;

        static public int SecCountTree;
        public static bool SecCountTreeEnable = true;

        static public TreeSetting Tree
        {
            get
            {
                if (_treeInst == null)
                {
                    _treeInst = new TreeSetting();
                }
                return _treeInst;
            }
        }

        static public GrassSetting Grass
        {
            get
            {
                if (_grassInst == null)
                {
                    _grassInst = new GrassSetting();
                }
                return _grassInst;
            }
        }

        public static bool IsGrassStaticShaodw
        {
            get { return CritiasFoliage.FoliageManager.Instance.IsGrassStaticShaodw; }

            set { CritiasFoliage.FoliageManager.Instance.IsGrassStaticShaodw = value; }
        }

        public static bool IsTreeStaticShaodw
        {
            get { return CritiasFoliage.FoliageManager.Instance.IsTreeStaticShaodw; }

            set { CritiasFoliage.FoliageManager.Instance.IsTreeStaticShaodw = value; }
        }
    }
    
    public class TreeSetting
    {
        public bool _treeEnable = true;
        public bool TreeEnabale
        {
            set
            {
                _treeEnable = value;
            }
            get
            {
                return _treeEnable;
            }
        }

        public int _treeDrawCall = 0;
        public int TreeDrawCall
        {
            set
            {
                _treeDrawCall = value;
            }
            get
            {
                return _treeDrawCall;
            }
        }

        public int _treeTypeCount = 0;
        public int TreeTypeCount
        {
            set
            {
                _treeTypeCount = value;
            }
            get
            {

                return _treeTypeCount;
            }
        }

        public uint _treeCount = 0;
        public uint TreeCount
        {
            set
            {
                _treeCount = value;
            }
            get
            {

                return _treeCount;
            }
        }

        public uint _treeTrunkTris = 0;
        public uint TreeTrunkTris
        {
            set
            {
                _treeTrunkTris = value;
            }
            get
            {

                return _treeTrunkTris;
            }
        }

        public uint _treeLeavesTris = 0;
        public uint TreeLeavesTris
        {
            set
            {
                _treeLeavesTris = value;
            }
            get
            {

                return _treeLeavesTris;
            }
        }

     
    }

    public class GrassSetting
    {
        public bool _grassEnable = true;
        public bool GrassEnabale
        {
            set
            {
                _grassEnable = value;
            }
            get
            {
                return _grassEnable;
            }
        }

        public int _grassDrawCall = 0;
        public int GrassDrawCall
        {
            set
            {
                _grassDrawCall = value;
            }
            get
            {
                return _grassDrawCall;
            }
        }

        public int _grassTypeCount = 0;
        public int GrassTypeCount
        {
            set
            {
                _grassTypeCount = value;
            }
            get
            {

                return _grassTypeCount;
            }
        }

        public int _grassCount = 0;
        public int GrassCount
        {
            set
            {
                _grassCount = value;
            }
            get
            {

                return _grassCount;
            }
        }

        public uint _grassTris = 0;
        public uint GrassTris
        {
            set
            {
                _grassTris = value;
            }
            get
            {

                return _grassTris;
            }
        }
        public uint _geoGrassTris = 0;
        public uint GeoGrassTris
        {
            set
            {
                _geoGrassTris = value;
            }
            get
            {

                return _geoGrassTris;
            }
        }
    }

    [ParamDebug.ParamSet("PostProcess")]
    public static class PostProcessSetting
    {
        static X2Bloom bloom = new X2Bloom();

        static X2ColorGrading colorGrading = new X2ColorGrading();

        static X2DepthOfField depthOfField = new X2DepthOfField();

        static X2Sunshaft sunshaft = new X2Sunshaft();

        static public X2Bloom BloomSetting
        {
            get { return bloom; }
        }

        static public X2ColorGrading ColorGrading
        {
            get { return colorGrading; }
        }

        static public X2DepthOfField DepthOfField
        {
            get { return depthOfField; }
        }

        static public X2Sunshaft Sunshaft
        {
            get { return sunshaft; }
        }

        //static X2ScreenScale m_screenScale = X2ScreenScale.Percent100;

        //static public X2ScreenScale ScreenScale
        //{
        //    get
        //    {
        //        return m_screenScale;
        //    }
        //    set
        //    {
        //        m_screenScale = value;
        //        float scale = ((float)(int)m_screenScale) / 100.0f;
        //        //int width = UnityEngine.Mathf.FloorToInt(UnityEngine.Screen.width * scale);
        //        //int height = UnityEngine.Mathf.FloorToInt(UnityEngine.Screen.height * scale);
        //        //UnityEngine.Screen.SetResolution(width, height, true);
        //        ILevelSystemManager.Instance.SetResolution(scale, scale);
        //    }
        //}

        static public PostProcessLayer.Antialiasing Antialiasing
        {
            get
            {
                return ILevelSystemManager.Instance.GetAntiAliasing();
            }
            set
            {
                ILevelSystemManager.Instance.SetAntiAliasing((int)value);
            }
        }

        static public bool AAHighQuality
        {
            get
            {
                return !PostProcessManager.instance.CurrentPostprocessLayer.fastApproximateAntialiasing.fastMode;
            }
            set
            {
                PostProcessManager.instance.CurrentPostprocessLayer.fastApproximateAntialiasing.fastMode = !value;
            }
        }

        public class X2Bloom
        {
            private Bloom m_setting = null;

            private Bloom setting
            {
                get
                {
                    if (!m_setting)
                    {
                        m_setting = X2DebugUtilities.Instance.postProcessLayer.GetSettings<UnityEngine.Rendering.PostProcessing.Bloom>();
                        X2DebugUtilities.Instance.postProcessLayer.UpdateSettingFrame = false;
                    }
                    return m_setting;
                }
            }
            public X2Bloom()
            {

            }

            public bool Enabled
            {
                get { return setting.enabled.value; }

                set { setting.enabled.value = value; }
            }

            public float Intensity
            {
                get { return setting.intensity.value; }

                set { setting.intensity.value = value; }
            }

            public float Threshold
            {
                get { return setting.threshold.value; }

                set { setting.threshold.value = value; }
            }

            public float SoftKnee
            {
                get { return setting.softKnee.value; }

                set { setting.softKnee.value = value; }
            }

            public float Diffusion
            {
                get { return setting.diffusion.value; }

                set { setting.diffusion.value = value; }
            }

            public UnityEngine.Color Color
            {
                get { return setting.color.value; }

                set { setting.color.value = value; }
            }
        }
        public class X2ColorGrading
        {
            ColorGrading m_setting;
            private ColorGrading setting
            {
                get
                {
                    if (!m_setting)
                        m_setting = X2DebugUtilities.Instance.postProcessLayer.GetSettings<UnityEngine.Rendering.PostProcessing.ColorGrading>();
                    return m_setting;
                }
            }

            public bool Enabled
            {
                get { return setting.enabled.value; }

                set { setting.enabled.value = value; }
            }
            public GradingMode GradingMode
            {
                get { return setting.gradingMode.value; }

                set { setting.gradingMode.value = value; }
            }

            public float ToeStrength
            {
                get { return setting.toneCurveToeStrength.value; }

                set { setting.toneCurveToeStrength.value = value; }
            }

            public float ToeLength
            {
                get { return setting.toneCurveToeLength.value; }

                set { setting.toneCurveToeLength.value = value; }
            }

            public float ShoulderStrength
            {
                get { return setting.toneCurveShoulderStrength.value; }

                set { setting.toneCurveShoulderStrength.value = value; }
            }

            public float ShoulderLength
            {
                get { return setting.toneCurveShoulderLength.value; }

                set { setting.toneCurveShoulderLength.value = value; }
            }

            public float ShoulderAngle
            {
                get { return setting.toneCurveShoulderAngle.value; }

                set { setting.toneCurveShoulderAngle.value = value; }
            }

            public float CurveGamma
            {
                get { return setting.toneCurveGamma.value; }

                set { setting.toneCurveGamma.value = value; }
            }

            public float Temperature
            {
                get { return setting.temperature.value; }

                set { setting.temperature.value = value; }
            }

            public float Tint
            {
                get { return setting.tint.value; }

                set { setting.tint.value = value; }
            }

            public float PostExposure
            {
                get { return setting.postExposure.value; }

                set { setting.postExposure.value = value; }
            }

            public float Contrast
            {
                get { return setting.contrast.value; }

                set { setting.contrast.value = value; }
            }

            public UnityEngine.Color ColorFilter
            {
                get { return setting.colorFilter.value; }

                set { setting.colorFilter.value = value; }
            }

            public float HueShift
            {
                get { return setting.hueShift.value; }

                set { setting.hueShift.value = value; }
            }

            public float Saturation
            {
                get { return setting.saturation.value; }

                set { setting.saturation.value = value; }
            }

            public float Brightness
            {
                get { return setting.brightness.value; }

                set { setting.brightness.value = value; }
            }
            public float MixerRedOutRedIn
            {
                get { return setting.mixerRedOutRedIn.value; }

                set { setting.mixerRedOutRedIn.value = value; }
            }
            public float MixerRedOutGreenIn
            {
                get { return setting.mixerRedOutGreenIn.value; }

                set { setting.mixerRedOutGreenIn.value = value; }
            }
            public float MixerRedOutBlueIn
            {
                get { return setting.mixerRedOutBlueIn.value; }

                set { setting.mixerRedOutBlueIn.value = value; }
            }

            public float MixerGreenOutRedIn
            {
                get { return setting.mixerGreenOutRedIn.value; }

                set { setting.mixerGreenOutRedIn.value = value; }
            }
            public float MixerGreenOutGreenIn
            {
                get { return setting.mixerGreenOutGreenIn.value; }

                set { setting.mixerGreenOutGreenIn.value = value; }
            }
            public float MixerGreenOutBlueIn
            {
                get { return setting.mixerGreenOutBlueIn.value; }

                set { setting.mixerGreenOutBlueIn.value = value; }
            }

            public float MixerBlueOutRedIn
            {
                get { return setting.mixerBlueOutRedIn.value; }

                set { setting.mixerBlueOutRedIn.value = value; }
            }
            public float MixerBlueOutGreenIn
            {
                get { return setting.mixerBlueOutGreenIn.value; }

                set { setting.mixerBlueOutGreenIn.value = value; }
            }
            public float MixerBlueOutBlueIn
            {
                get { return setting.mixerBlueOutBlueIn.value; }

                set { setting.mixerBlueOutBlueIn.value = value; }
            }

            public Vector4 Lift
            {
                get { return setting.lift.value; }

                set { setting.lift.value = value; }

            }
            public Vector4 Gamma
            {
                get { return setting.gamma.value; }

                set { setting.gamma.value = value; }

            }
            public Vector4 Gain
            {
                get { return setting.gain.value; }

                set { setting.gain.value = value; }

            }

            public Spline HueVsHueCurve
            {
                get { return setting.hueVsHueCurve.value; }

                set { setting.hueVsHueCurve.value = value; }
            }
            public Spline HueVsSatCurve
            {
                get { return setting.hueVsSatCurve.value; }

                set { setting.hueVsSatCurve.value = value; }
            }
            public Spline SatVsSatCurve
            {
                get { return setting.satVsSatCurve.value; }

                set { setting.satVsSatCurve.value = value; }
            }
            public Spline LumVsSatCurve
            {
                get { return setting.lumVsSatCurve.value; }

                set { setting.lumVsSatCurve.value = value; }
            }

        }

        public class X2DepthOfField
        {
            DepthOfField m_setting;
            private DepthOfField setting
            {
                get
                {
                    if (!m_setting)
                        m_setting = X2DebugUtilities.Instance.postProcessLayer.GetSettings<UnityEngine.Rendering.PostProcessing.DepthOfField>();
                    return m_setting;
                }
            }

            public bool Enabled
            {
                get { return setting.enabled.value; }

                set { setting.enabled.value = value; }
            }

            public float FocusDistance
            {
                get { return setting.focusDistance.value; }

                set { setting.focusDistance.value = value; }
            }

            public float Aperture
            {
                get { return setting.aperture.value; }

                set { setting.aperture.value = value; }
            }

            [Range(1f, 300f), Tooltip("Distance between the lens and the film. The larger the value is, the shallower the depth of field is.")]
            public UnityEngine.Rendering.PostProcessing.FloatParameter focalLength = new UnityEngine.Rendering.PostProcessing.FloatParameter { value = 50f };

            public float FocalLength
            {
                get { return setting.focalLength.value; }

                set { setting.focalLength.value = value; }
            }

            public KernelSize kernelSize
            {
                get { return setting.kernelSize.value; }

                set { setting.kernelSize.value = value; }
            }
        }

        public class X2Sunshaft
        {
            Sunshaft m_setting;
            private Sunshaft setting
            {
                get
                {
                    if (!m_setting)
                        m_setting = X2DebugUtilities.Instance.postProcessLayer.GetSettings<Sunshaft>();
                    return m_setting;
                }
            }

            public bool Enabled
            {
                get { return setting.enabled.value; }

                set { setting.enabled.value = value; }
            }
            public Color color
            {
                get { return setting.color.value; }

                set { setting.color.value = value; }
            }
        }
    }

#if false
    [ParamDebug.ParamSet("Shadow")]
    public static class ShadowSetting
    {

        public static float s_giScale = 4.0f;
        static public float GIScale
        {
            set
            {
                s_giScale = value;
                Shader.SetGlobalFloat("_DebugGICoef", s_giScale);//
            }
            get
            {
                return s_giScale;
            }
        }
        static public float ShadowNearPlaneOffset
        {
            set
            {
                QualitySettings.shadowNearPlaneOffset = value;
            }
            get
            {
                return QualitySettings.shadowNearPlaneOffset;
            }
        }
        static public float ShadowDistance
        {
            set
            {
                QualitySettings.shadowDistance = value;
            }
            get
            {
                return QualitySettings.shadowDistance;
            }
        }

        static public ShadowmaskMode ShadowmaskMode
        {
            set
            {
                QualitySettings.shadowmaskMode = value;
            }
            get
            {
                return QualitySettings.shadowmaskMode;
            }
        }

        static public ShadowProjection ShadowProjection
        {
            set
            {
                QualitySettings.shadowProjection = value;
            }
            get
            {
                return QualitySettings.shadowProjection;
            }
        }

        static public ShadowResolution ShadowResolution
        {
            set
            {
                QualitySettings.shadowResolution = value;
            }
            get
            {
                return QualitySettings.shadowResolution;
            }
        }
        static public ShadowQuality Shadows
        {
            set
            {
                QualitySettings.shadows = value;
            }
            get
            {
                return QualitySettings.shadows;
            }
        }

        static UnityEngine.Light Sun
        {
            get
            {
                if (!Bokura.EnvironmentSystem.instance)
                    return null;
                return Bokura.EnvironmentSystem.instance.m_sun;
            }
        }

        static public float ShadowStrength
        {
            set
            {
                if (!Sun)
                    return;
                Sun.shadowStrength = value;
            }
            get
            {
                if (!Sun)
                    return 0.0f;
                return Sun.shadowStrength;
            }
        }
        static public float ShadowBias
        {
            set
            {
                if (!Sun)
                    return;
                Sun.shadowBias = value;
            }
            get
            {
                if (!Sun)
                    return 0.0f;
                return Sun.shadowBias;
            }
        }
        static public float ShadowNearPlane
        {
            set
            {
                if (!Sun)
                    return;
                Sun.shadowNearPlane = value;
            }
            get
            {
                if (!Sun)
                    return 0.0f;
                return Sun.shadowNearPlane;
            }
        }

        static public float ShadowNormalBias
        {
            set
            {
                if (!Sun)
                    return;
                Sun.shadowNormalBias = value;
            }
            get
            {
                if (!Sun)
                    return 0.0f;
                return Sun.shadowNormalBias;
            }
        }

        static public Bokura.SystemLevelInfo.LevelEnum QualityLevel
        {
            set
            {
                ILevelSystemManager.Instance.SetLevelSystemInt((int)value);
            }
            get
            {
                return (Bokura.SystemLevelInfo.LevelEnum)ILevelSystemManager.Instance.GetLevelSystemInt();
            }
        }

        static public bool ShowDecalShadow
        {
            set
            {
                ILevelSystemManager.Instance.SetIsShowDecalShadow(value);
            }
            get
            {
                return ILevelSystemManager.Instance.IsShowDecalShadow();
            }
        }
    }
#endif

    [ParamDebug.ParamSet("LevelSystem")]
    public static class LevelSystemSetting
    {
        public static float s_giScale = 4.0f;
        static public float GIScale
        {
            set
            {
                s_giScale = value;
                Shader.SetGlobalFloat("_DebugGICoef", s_giScale);//
            }
            get
            {
                return s_giScale;
            }
        }

        static public bool WideColorGamutEnable
        {
            get { return Graphics.activeColorGamut == ColorGamut.DisplayP3; }
            set {  }
        }
        //static public float ShadowDistance
        //{
        //    set
        //    {
        //        QualitySettings.shadowDistance = value;
        //        Bokura.EngineMain.PipelineAsset.shadowDistance = value;
        //    }
        //    get
        //    {
        //        return Bokura.EngineMain.PipelineAsset.shadowDistance;
        //    }
        //}

        //static public float ShadowDepthBias
        //{
        //    set
        //    {
        //        Bokura.EngineMain.PipelineAsset.shadowDepthBias = value;
        //    }
        //    get
        //    {
        //        return Bokura.EngineMain.PipelineAsset.shadowDepthBias;
        //    }
        //}

        static public Bokura.SystemLevelInfo.LevelEnum QualityLevel
        {
            set
            {
                ILevelSystemManager.Instance.SetLevelSystemInt((int)value);
            }
            get
            {
                return (Bokura.SystemLevelInfo.LevelEnum)ILevelSystemManager.Instance.GetLevelSystemInt();
            }
        }

        static public bool ShowDecalShadow
        {
            set
            {
                ILevelSystemManager.Instance.SetIsShowDecalShadow(value);
            }
            get
            {
                return ILevelSystemManager.Instance.IsShowDecalShadow();
            }
        }

        static public bool supportsCameraDepthTexture
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsCameraDepthTexture; }
            set { Bokura.EngineMain.PipelineAsset.supportsCameraDepthTexture = value; }
        }

        static public bool supportsCameraOpaqueTexture
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsCameraOpaqueTexture; }
            set { Bokura.EngineMain.PipelineAsset.supportsCameraOpaqueTexture = value; }
        }

        static public UnityEngine.Rendering.Universal.Downsampling opaqueDownsampling
        {
            get { return Bokura.EngineMain.PipelineAsset.opaqueDownsampling; }
        }

        static public bool supportsHDR
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsHDR; }
            set { Bokura.EngineMain.PipelineAsset.supportsHDR = value; }
        }

        static public UnityEngine.Rendering.Universal.MsaaQuality msaaSampleCount
        {
            get { return (UnityEngine.Rendering.Universal.MsaaQuality)Bokura.EngineMain.PipelineAsset.msaaSampleCount; }
            set { Bokura.EngineMain.PipelineAsset.msaaSampleCount = (int)value; }
        }

        static float ValidateRenderScale(float value)
        {
            return Mathf.Max(UnityEngine.Rendering.Universal.UniversalRenderPipeline.minRenderScale, Mathf.Min(value, UnityEngine.Rendering.Universal.UniversalRenderPipeline.maxRenderScale));
        }

        static public float renderScale
        {
            get { return Bokura.EngineMain.PipelineAsset.renderScale; }
            set { Bokura.EngineMain.PipelineAsset.renderScale = ValidateRenderScale(value); }
        }

        //static public UnityEngine.Rendering.LWRP.LightRenderingMode mainLightRenderingMode
        //{
        //    get { return Bokura.EngineMain.PipelineAsset.mainLightRenderingMode; }
        //}

        //static public bool supportsMainLightShadows
        //{
        //    get { return Bokura.EngineMain.PipelineAsset.supportsMainLightShadows; }
        //}

        static public UnityEngine.Rendering.Universal.ShadowResolution mainLightShadowmapResolution
        {
            get { return (UnityEngine.Rendering.Universal.ShadowResolution)Bokura.EngineMain.PipelineAsset.mainLightShadowmapResolution; }
            set { Bokura.EngineMain.PipelineAsset.mainLightShadowmapResolution = (int)value; }
        }
        //static public UnityEngine.Rendering.LWRP.LightRenderingMode additionalLightsRenderingMode
        //{
        //    get { return Bokura.EngineMain.PipelineAsset.additionalLightsRenderingMode; }
        //}
        static int ValidatePerObjectLights(int value)
        {
            return System.Math.Max(0, System.Math.Min(value, UnityEngine.Rendering.Universal.UniversalRenderPipeline.maxPerObjectLights));
        }
        static public int maxAdditionalLightsCount
        {
            get { return Bokura.EngineMain.PipelineAsset.maxAdditionalLightsCount; }
            set { Bokura.EngineMain.PipelineAsset.maxAdditionalLightsCount = ValidatePerObjectLights(value); }
        }

        static public float shadowDistance
        {
            get { return Bokura.EngineMain.PipelineAsset.shadowDistance; }
            set { Bokura.EngineMain.PipelineAsset.shadowDistance = Mathf.Max(0.0f, value); }
        }

        static public UnityEngine.Rendering.Universal.ShadowCascadesOption shadowCascadeOption
        {
            get { return Bokura.EngineMain.PipelineAsset.shadowCascadeOption; }
            set { Bokura.EngineMain.PipelineAsset.shadowCascadeOption = value; }
        }

        static float ValidateShadowBias(float value)
        {
            return Mathf.Max(0.0f, Mathf.Min(value, UnityEngine.Rendering.Universal.UniversalRenderPipeline.maxShadowBias));
        }

        static public float shadowDepthBias
        {
            get { return Bokura.EngineMain.PipelineAsset.shadowDepthBias; }
            set { Bokura.EngineMain.PipelineAsset.shadowDepthBias = ValidateShadowBias(value); }
        }

        static public float shadowNormalBias
        {
            get { return Bokura.EngineMain.PipelineAsset.shadowNormalBias; }
            set { Bokura.EngineMain.PipelineAsset.shadowNormalBias = ValidateShadowBias(value); }
        }

        static public bool supportsSoftShadows
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsSoftShadows; }
            set { Bokura.EngineMain.PipelineAsset.supportsSoftShadows = value; }
        }

        static public bool supportShadows
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsMainLightShadows; }
            set { Bokura.EngineMain.PipelineAsset.supportsMainLightShadows = value; }
        }

        static public bool supportsDynamicBatching
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsDynamicBatching; }
            set { Bokura.EngineMain.PipelineAsset.supportsDynamicBatching = value; }
        }

        static public bool supportsMixedLighting
        {
            get { return Bokura.EngineMain.PipelineAsset.supportsMixedLighting; }
        }

        static public UnityEngine.Rendering.Universal.ShaderVariantLogLevel shaderVariantLogLevel
        {
            get { return Bokura.EngineMain.PipelineAsset.shaderVariantLogLevel; }
            set { Bokura.EngineMain.PipelineAsset.shaderVariantLogLevel = value; }
        }

        static public bool useSRPBatcher
        {
            get { return Bokura.EngineMain.PipelineAsset.useSRPBatcher; }
            set { Bokura.EngineMain.PipelineAsset.useSRPBatcher = value; }
        }
    }

    [ParamDebug.ParamSet("Log")]
    public static class DebugLogSetting
    {
        static public bool OpenLog
        {
            set
            {
                ILogSystem.isCloseLog = !value;
            }
            get
            {
                return !ILogSystem.isCloseLog;
            }
        }

        static public bool OpenFPS
        {
            set
            {
                if (value)
                {
                    DebugShowOnGUI.OpenOnGUI();
                }
                else
                {
                    DebugShowOnGUI.CloseOnGUI();
                }
            }
            get
            {
                return DebugShowOnGUI.isOpen;
            }
        }

        //static public bool UIRootMainUI
        //{
        //    set
        //    {
        //        GameObject go = GameObject.Find("UIRoot");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 4)
        //            {
        //                go.transform.GetChild(2).gameObject.SetActive(value);
        //            }
        //        }
        //    }
        //    get
        //    {
        //        GameObject go = GameObject.Find("UIRoot");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 4)
        //            {
        //                return go.transform.GetChild(2).gameObject.activeSelf;
        //            }
        //        }

        //        return false;
        //    }
        //}

        static public int TargetFrameRate
        {
            set
            {
                UnityEngine.QualitySettings.vSyncCount = -1;
                UnityEngine.Application.targetFrameRate = value;
            }
            get
            {

                return UnityEngine.Application.targetFrameRate;
            }
        }

        static public bool RenderShadows
        {
            set
            {
                var mainCamera = ICameraHelper.Instance.MainCamera;
                if (mainCamera != null)
                {

                    var simple_renderer = mainCamera.gameObject.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
                    if (simple_renderer != null)
                    {
                        ICameraHelper.Instance.MainCamera.gameObject.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>().renderShadows = value;
                    }
                    else
                    {
                        if (!value)
                        {
                            simple_renderer = mainCamera.gameObject.AddComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
                            simple_renderer.renderShadows = value;
                        }
                    }
                }
            }
            get
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    return ICameraHelper.Instance.MainCamera.gameObject.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>().renderShadows;
                }

                return true;
            }
        }

        static public float NearClipPlane
        {
            set
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    ICameraHelper.Instance.MainCamera.nearClipPlane = value;
                }
            }
            get
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    return ICameraHelper.Instance.MainCamera.nearClipPlane;
                }

                return 0;
            }
        }

        static public float FarClipPlane
        {
            set
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    ICameraHelper.Instance.MainCamera.farClipPlane = value;
                }
            }
            get
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    return ICameraHelper.Instance.MainCamera.farClipPlane;
                }

                return 0;
            }
        }

        static public float ScreenScale
        {
            set
            {
                ILevelSystemManager.Instance.SetResolution(value);
            }
            get
            {
                return Bokura.EngineMain.PipelineAsset.renderScale;
            }
        }

        static public int MipMapBias
        {
            set
            {
                QualitySettings.masterTextureLimit = value;
            }
            get
            {
                return QualitySettings.masterTextureLimit;
            }
        }
        static public bool EnabledProFlare
        {
            set
            {
                if (Bokura.EnvironmentSystem.instance != null)
                {
                    Bokura.EnvironmentSystem.instance.EnabledProFlare = value;
                }
            }
            get
            {
                if (Bokura.EnvironmentSystem.instance != null)
                {
                    return Bokura.EnvironmentSystem.instance.EnabledProFlare;
                }

                return false;
            }
        }

        static public bool VisibleMainRole
        {
            set
            {
                if (Game.Instance.GetMainCharacter() != null)
                {
                    Game.Instance.GetMainCharacter().VisibleByLevelSystem = value;
                }
            }
            get
            {
                if (Game.Instance.GetMainCharacter() != null)
                {
                    return Game.Instance.GetMainCharacter().VisibleByLevelSystem;
                }

                return false;
            }
        }
        //static public bool OpenTriggerZone
        //{
        //    set
        //    {
        //        GameObject go = GameObject. Find("Trigger");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 1)
        //            {
        //                go.transform.GetChild(0).gameObject.SetActive(value);
        //            }
        //        }
        //    }
        //    get
        //    {
        //        GameObject go = GameObject.Find("Trigger");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 1)
        //            {
        //                return go.transform.GetChild(0).gameObject.activeSelf;
        //            }
        //        }

        //        return false;
        //    }
        //}

        //static public bool OpenStaticBig
        //{
        //    set
        //    {
        //        GameObject go = GameObject.Find("StaticBig");
        //        if (go != null)
        //        {
        //            for(int i=0; i< go.transform.childCount; ++i)
        //            {
        //                go.transform.GetChild(i).gameObject.SetActive(value);
        //            }
        //        }
        //    }
        //    get
        //    {
        //        GameObject go = GameObject.Find("StaticBig");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 1)
        //            {
        //                return go.transform.GetChild(0).gameObject.activeSelf;
        //            }
        //        }

        //        return false;
        //    }
        //}

        //static public bool OpenStaticMiddle
        //{
        //    set
        //    {
        //        GameObject go = GameObject.Find("StaticMiddle");
        //        if (go != null)
        //        {
        //            for (int i = 0; i < go.transform.childCount; ++i)
        //            {
        //                go.transform.GetChild(i).gameObject.SetActive(value);
        //            }
        //        }
        //    }
        //    get
        //    {
        //        GameObject go = GameObject.Find("StaticMiddle");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 1)
        //            {
        //                return go.transform.GetChild(0).gameObject.activeSelf;
        //            }
        //        }

        //        return false;
        //    }
        //}

        //static public bool OpenStaticSmall
        //{
        //    set
        //    {
        //        GameObject go = GameObject.Find("StaticSmall");
        //        if (go != null)
        //        {
        //            for (int i = 0; i < go.transform.childCount; ++i)
        //            {
        //                go.transform.GetChild(i).gameObject.SetActive(value);
        //            }
        //        }
        //    }
        //    get
        //    {
        //        GameObject go = GameObject.Find("StaticSmall");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 1)
        //            {
        //                return go.transform.GetChild(0).gameObject.activeSelf;
        //            }
        //        }

        //        return false;
        //    }
        //}

        //static public bool OpenTree
        //{
        //    set
        //    {
        //        GameObject go = GameObject.Find("Tree");
        //        if (go != null)
        //        {
        //            for (int i = 0; i < go.transform.childCount; ++i)
        //            {
        //                go.transform.GetChild(i).gameObject.SetActive(value);
        //            }
        //        }
        //    }
        //    get
        //    {
        //        GameObject go = GameObject.Find("Tree");
        //        if (go != null)
        //        {
        //            if (go.transform.childCount >= 1)
        //            {
        //                return go.transform.GetChild(0).gameObject.activeSelf;
        //            }
        //        }

        //        return false;
        //    }
        //}
        

        //static public bool OpenCloud
        //{
        //    set
        //    {
        //        if (value)
        //        {
        //            if (Game.Instance.IsInGame())
        //            {
        //                Game.WeatherCloudManager.Instance.CreateCloud();
        //            }
        //        }
        //        else
        //        {
        //            Game.WeatherCloudManager.Instance.DestroyCloud();

        //            GC.Collect();
        //            Resources.UnloadUnusedAssets();
        //        }
        //    }
        //    get
        //    {
        //        Camera cam = Bokura.ICameraHelper.Instance.MainCamera;
        //        return (cam.cullingMask & (int)Bokura.UserLayerMask.Ocean) == 0;
        //    }
        //}

        static public OpaqueSortMode CamreaOpaqueSort
        {
            get
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    return ICameraHelper.Instance.MainCamera.opaqueSortMode;
                }

                return OpaqueSortMode.Default;
            }

            set
            {
                if (ICameraHelper.Instance.MainCamera != null)
                {
                    ICameraHelper.Instance.MainCamera.opaqueSortMode = value;
                }
            }
        }

        static public WeatherType weatherType
        {
            set
            {
                if ((value == WeatherType.MorningRain)
                    || (value == WeatherType.MiddayRain)
                    || (value == WeatherType.DuskRain)
                    || (value == WeatherType.EveningRain))
                {
                    WeatherManager.Instance.StartFlashLighting();
                }
                else
                {
                    WeatherManager.Instance.StopFlashLighting();
                }

                WeatherManager.Instance.ResetWeather(value);
            }
            get
            {
                return (WeatherType)WeatherManager.Instance.GetCurrWeatherType();
            }
        }

        static public int AllEntitysCount
        {
            get { return GameScene.Instance.AllEntitys.Count; }
        }

        static public int NpcCount
        {
            get { return GameScene.Instance.GetNpcEntityCount(); }
        }

        static public int CharacterCount
        {
            get { return GameScene.Instance.GetCharacterEntityCount(); }
        }

        static public int GatherResourceCount
        {
            get { return GameScene.Instance.GetGatherResourceEntityCount(); }
        }

        static public int ShowNpcCount
        {
            get { return Bokura.LevelSystemManager.s_npcShowNumber; }
            set { Bokura.LevelSystemManager.s_npcShowNumber = value; }
        }

        static public int ShowCharacterCount
        {
            get { return Bokura.LevelSystemManager.s_characterShowNumber; }
            set { Bokura.LevelSystemManager.s_characterShowNumber = value; }
        }
    }
        [XLua.LuaCallCSharp]
    public class ParamDebug
    {
        public class ParamSet : Attribute
        {
            public ParamSet(string name)
            {
                m_name = name;
            }

            string m_name;
            public string Name
            {
                get
                {
                    return m_name;
                }
            }
        }
        Dialog m_guiDialog;
        static ParamDebug m_instance;
        static public ParamDebug Instance
        {
            get
            {
                if (m_instance == null)
                    m_instance = new ParamDebug();
                return m_instance;
            }
        }

        Timer? m_refreshTimer;
        GameObject m_editPanel;
        public void ShowGUI()
        {
            if (m_refreshTimer != null)
            {
                if(m_editPanel)
                    m_editPanel.SetActive(true);
                return;
            }
            m_refreshTimer = GameApplication.Instance.GetTimerManager().AddTimer(RefreshParam, 0.2f, -1);
            if (m_guiDialog != null)
            {
                if(m_guiDialog.gameObject)
                    m_guiDialog.gameObject.SetActive(true);
                if(m_editPanel)
                    m_editPanel.SetActive(true);
                return;
            }

            m_guiDialog = new Dialog();
            m_guiDialog.Layout = "ui_panel_paramdebug";
            m_guiDialog.OnCreate();
            m_guiDialog.SetParent(UIManager.Instance.GetUILayer(UILayer.Top));
            if(m_guiDialog.gameObject)
                m_guiDialog.gameObject.SetActive(true);

            m_editPanel = m_guiDialog.GetChildObject("panel_edit") as GameObject;

            m_guiDialog.GetButtonControl("btn_close").onClick.AddListener(() =>
            {
                GameApplication.Instance.GetTimerManager().RemoveTimer(m_refreshTimer.Value.ID);
                m_refreshTimer = null;
                m_guiDialog.Close();
                m_debugPanels.Clear();
                m_allrefreshInfos.Clear();
                m_guiDialog = null;
            });
            m_guiDialog.GetButtonControl("btn_min").onClick.AddListener(() =>
            {
                if(m_editPanel)
                    m_editPanel.SetActive(!m_editPanel.activeSelf);
            });
            if(m_editPanel)
                m_editPanel.SetActive(true);

            var toggletemplate = m_guiDialog.GetChildObject("toggle_btn_template") as GameObject;
            if(toggletemplate)
                toggletemplate.SetActive(false);

            //var type = GetType();
            //var fields = type.GetFields();
            //var types = type.GetNestedTypes();
            int count = 0;

            var curassembly = System.Reflection.Assembly.GetCallingAssembly();
            var types = curassembly.GetTypes();

            foreach (var f in types)
            {
                //var memtype = f.GetType();
                var paramsetinfo = f.GetCustomAttributes(typeof(ParamSet), false);
                if (paramsetinfo.Length == 0)
                {
                    continue;
                }

                var newInstance = GameObject.Instantiate(toggletemplate, toggletemplate.transform.parent);
                var toggle = newInstance.GetComponent<UnityEngine.UI.Toggle>();

                newInstance.SetActive(true);
                LuaFastCall.GetTextControl(newInstance, "txt_name").text = (paramsetinfo[0] as ParamSet).Name;
                toggle.onValueChanged.AddListener((bool active) =>
                {

                    ShowDebugPanel(f, active);

                });
                if (count == 0)
                {
                    toggle.isOn = true;
                    ShowDebugPanel(f, true);
                }
                else
                {
                    toggle.isOn = false;
                }
                count++;
            }

        }
        class RefreshInfo
        {
            public RefreshInfo(System.Reflection.PropertyInfo pi, UnityEngine.UI.Dropdown dropdown, object obj = null)
            {
                m_valueHolder = obj;
                m_pi = pi;
                m_oldValue = null;
                m_text = null;
                m_dropdown = dropdown;

                var names = new List<string>(m_pi.PropertyType.GetEnumNames());
                dropdown.AddOptions(names);
                m_enumValues = m_pi.PropertyType.GetEnumValues();
                m_dropdown.onValueChanged.AddListener((int i) =>
                {
                    m_pi.SetValue(m_valueHolder, m_enumValues.GetValue(i));
                    m_oldValue = m_enumValues.GetValue(i);
                });
            }
            public RefreshInfo(System.Reflection.PropertyInfo pi, UnityEngine.UI.Toggle toggle, object obj = null)
            {
                m_valueHolder = obj;
                m_pi = pi;
                m_oldValue = null;
                m_text = null;
                m_toggle = toggle;
                m_toggle.onValueChanged.AddListener((bool check) =>
                {
                    m_pi.SetValue(m_valueHolder, check);
                    m_oldValue = m_pi.GetValue(m_valueHolder);
                });
            }

            public RefreshInfo(int idx,GameObject row, UnityEngine.UI.Toggle toggle)
            {
                paramguimax = row;
                m_valueHolder = idx;
                m_oldValue = null;
                m_text = null;
                m_toggle = toggle;
               
            }

            public RefreshInfo(UnityEngine.UI.Button expand, UnityEngine.UI.Button fold, GameObject[] subProps)
            {
                //m_valueHolder = obj;
                m_pi = null;
                m_oldValue = null;
                m_text = null;
                expand.gameObject.SetActive(false);
                fold.gameObject.SetActive(true);
                expand.onClick.AddListener(() =>
                {
                    for (int i = 0; i < subProps.Length; i++)
                    {
                        subProps[i].SetActive(true);
                    }
                    expand.gameObject.SetActive(false);
                    fold.gameObject.SetActive(true);
                });

                fold.onClick.AddListener(() =>
                {
                    for (int i = 0; i < subProps.Length; i++)
                    {
                        subProps[i].SetActive(false);
                    }
                    expand.gameObject.SetActive(true);
                    fold.gameObject.SetActive(false);
                });
            }
            System.Reflection.PropertyInfo m_pi;
            object m_oldValue;
            object m_valueHolder;
            UnityEngine.UI.InputField m_text;
            UnityEngine.UI.Dropdown m_dropdown;
            UnityEngine.UI.Toggle m_toggle;
            GameObject paramguimax;
            Array m_enumValues;

            public void Refresh()
            {
                if (m_pi == null)
                {
                    if (paramguimax != null)
                    {
                        int idx = (int)m_valueHolder;
                        if (FoliageSetting.Tree.TreeEnabale && FoliageSetting.TreeEnablelist.Count>0)
                        {
                            if (idx == 0 )
                            {
                                FoliageSetting.MaxCountTreeEnable = m_toggle.isOn;
                                FoliageSetting.MaxCountTree = FoliageSetting.TreeEnablelist[0];
                                LuaFastCall.GetTextControl(paramguimax, "txt_name").text ="Top1 Tree:" + FoliageSetting.TreeEnablelist[0].ToString();
                            }
                            if (idx == 1 && FoliageSetting.TreeEnablelist.Count > 1)
                            {
                                FoliageSetting.SecCountTreeEnable = m_toggle.isOn;
                                FoliageSetting.SecCountTree = FoliageSetting.TreeEnablelist[1];
                                LuaFastCall.GetTextControl(paramguimax, "txt_name").text = "Top2 Tree:" + FoliageSetting.TreeEnablelist[1].ToString();
                            }

                        }

                    }
                    return;
                }
                   
                object c;
                try
                {
                    c = m_pi.GetValue(m_valueHolder);
                    if (c.Equals(m_oldValue) || (m_text && m_text.isFocused))
                    {
                        return;

                    }
                    m_oldValue = c;
                }
                catch (Exception)
                {
                    return;
                }
                if (m_dropdown)
                {

                    for (int i = 0; i < m_enumValues.Length; i++)
                    {
                        if (c.Equals(m_enumValues.GetValue(i)))
                        {
                            m_dropdown.value = i;// p.GetValue(null)
                            break;
                        }
                    }
                }
                else if (m_toggle)
                {
                    m_toggle.isOn = (bool)c;
                }
                else
                {
                    m_text.text = c.ToString();
                }
            }
        }
        List<RefreshInfo> m_refreshList;

        void RefreshParam()
        {
            for (int i = 0; i < m_refreshList.Count; i++)
            {
                var ri = m_refreshList[i];
                ri.Refresh();
            }
        }

        Dictionary<System.Type, List<RefreshInfo>> m_allrefreshInfos = new Dictionary<System.Type, List<RefreshInfo>>(4);

        Dictionary<System.Type, GameObject> m_debugPanels = new Dictionary<System.Type, GameObject>(4);

        GameObject AddFoliageTypeUI(int idx,string name, GameObject ui_template)
        {
            var paramgui = GameObject.Instantiate(ui_template, ui_template.transform.parent) as GameObject;
            paramgui.SetActive(true);
            LuaFastCall.GetTextControl(paramgui, "txt_name").text = name;
            UnityEngine.UI.Toggle toggle = LuaFastCall.GetToggleControl(paramgui, "toggle_value") as UnityEngine.UI.Toggle;
            toggle.isOn = true;
            toggle.transform.parent.gameObject.SetActive(true);
            toggle.transform.position = new Vector3(toggle.transform.position.x + 100, toggle.transform.position.y, toggle.transform.position.z);
            m_refreshList.Add(new RefreshInfo(idx,paramgui, toggle));
          
            return paramgui;
        }
        GameObject AddAccessorUI(System.Reflection.PropertyInfo pi, GameObject ui_template, object valueholder, float offset = 0.0f)
        {
            var paramgui = GameObject.Instantiate(ui_template, ui_template.transform.parent) as GameObject;
            paramgui.SetActive(true);

            LuaFastCall.GetTextControl(paramgui, "txt_name").text = pi.Name;
            LuaFastCall.GetChildRectTransform(paramgui.transform, "img_background").anchoredPosition = new Vector2(offset, 0.0f);

            if (pi.PropertyType.IsEnum)
            {
                var dropdown = LuaFastCall.GetDropDownControl(paramgui, "dropdown_value");
                dropdown.transform.parent.gameObject.SetActive(true);

                m_refreshList.Add(new RefreshInfo(pi, dropdown, valueholder));

                if (pi.GetSetMethod() == null)
                {
                    dropdown.interactable = false;
                }

            }
            else if (pi.PropertyType == typeof(bool))
            {
                var toggle = LuaFastCall.GetToggleControl(paramgui, "toggle_value");
                toggle.transform.parent.gameObject.SetActive(true);
                m_refreshList.Add(new RefreshInfo(pi, toggle, valueholder));
                if (pi.GetSetMethod() == null)
                {
                    toggle.interactable = false;
                }
            }
            else if (pi.PropertyType.IsClass)
            {
                var expand = LuaFastCall.GetButtonControl(paramgui, "btn_expand");
                var fold = LuaFastCall.GetButtonControl(paramgui, "btn_fold");
                fold.transform.parent.gameObject.SetActive(true);

                var val = pi.GetValue(valueholder);
                var props = pi.PropertyType.GetProperties();
                List<GameObject> subgos = new List<GameObject>(Bokura.ConstValue.kCap16);
                foreach (var subp in props)
                {
                    if (subp.GetGetMethod().IsStatic)
                        continue;
                    subgos.Add(AddAccessorUI(subp, ui_template, val, offset + 10.0f));
                }
                m_refreshList.Add(new RefreshInfo(expand, fold, subgos.ToArray()));
            }
            else
            {

                var inputfield = LuaFastCall.GetEnhancedInputFieldControl(paramgui, "input_value");
                inputfield.transform.parent.gameObject.SetActive(true);
                var add = LuaFastCall.GetButtonControl(paramgui, "btn_add");
                var dec = LuaFastCall.GetButtonControl(paramgui, "btn_dec");
                m_refreshList.Add(new RefreshInfo(pi, inputfield, add, dec, valueholder));
                if (pi.GetSetMethod() == null)
                {
                    inputfield.interactable = false;
                    add.interactable = false;
                    dec.interactable = false;
                }
            }
            return paramgui;
        }
        void ShowDebugPanel(System.Type fi, bool show)
        {
            GameObject panel;
            if (m_debugPanels.TryGetValue(fi, out panel))
            {
                panel.SetActive(show);
                if (show)
                {
                    m_refreshList = m_allrefreshInfos[fi];
                }
                return;
            }
            if (!show)
                return;
            List<RefreshInfo> refreshList = new List<RefreshInfo>(10);
            m_allrefreshInfos.Add(fi, refreshList);
            m_refreshList = refreshList;

            var panel_template = m_guiDialog.GetChildObject("scroll_view_params") as GameObject;
            panel_template.SetActive(false);
            panel = GameObject.Instantiate(panel_template, panel_template.transform.parent) as GameObject;
            //panel.transform.SetParent();
            panel.SetActive(true);
            m_debugPanels.Add(fi, panel);

            var paramtemplate = LuaFastCall.GetChildObject(panel, "panel_row_template") as GameObject;
            paramtemplate.SetActive(false);

            //var setting = fi.GetValue(this);

            var props = fi.GetProperties();
            foreach (var p in props)
            {
                if (!p.GetGetMethod().IsStatic)
                    continue;
                AddAccessorUI(p, paramtemplate, null);
            }

            if (fi.Name== "FoliageSetting")
            {
                for (int i = 0; i < FoliageSetting.TreeEnablelist.Count; i++)
                {
                    //process custom UI for foliage type
                    AddFoliageTypeUI(i, FoliageSetting.TreeEnablelist[i].ToString(), paramtemplate);
                }
               
            }

        }

    }
#else
    [XLua.LuaCallCSharp]
    public class ParamDebug
    {
        public void ShowGUI()
        {

        }

        static public ParamDebug Instance
        {
            get
            {
                return null;
            }
        }

    }
#endif
}
