#if REMOTE_DEBUG
using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using LitJson;
using System.Text;
using UnityEngine.Rendering.PostProcessing;
using Bokura;
using System.IO;

namespace Bokura
{

  

    public class NetBuffer
    {


        List<byte[]> m_bufflist = new List<byte[]>();
        int m_nbuffsize;
        public NetBuffer(int prebuffsize)
        {
            m_nbuffsize = prebuffsize;
        }

        public byte[] Alloc()
        {
            lock(m_bufflist)
            if(m_bufflist.Count>0)
            {
                var data = m_bufflist[m_bufflist.Count-1];

                m_bufflist.RemoveAt(m_bufflist.Count - 1);
                return data;
            }
            return new byte[m_nbuffsize];
        }

        public void Free(byte[] buff)
        {
            lock(m_bufflist)
                m_bufflist.Add(buff);
        }

    }


    public class JsonMsgDepack
    {
        public delegate void OnPackage(JsonData jd, byte[] data, int offset, int len);


        OnPackage m_onPackage;
        FIFOFixedStream m_fifoStream = new FIFOFixedStream(1024 * 1024 * 2);
        int m_curPackLen = 0;
        byte[] m_packBuff = new byte[1024 * 1024];

        public JsonMsgDepack(OnPackage onpackage)
        {
            m_onPackage = onpackage;
        }
        public void FillData(byte[] data, int len)
        {
            m_fifoStream.Write(data, 0, len);
            //LogHelper.Log("write len:"+ len);
            do
            {
                if (m_curPackLen == 0)
                {
                    // LogHelper.Log("data size:" + m_fifoStream.DataSize);
                    if (m_fifoStream.DataSize >= 4)
                    {
                        m_curPackLen = m_fifoStream.ReadInt();
                        //LogHelper.Log("pack len:" + m_curPackLen);
                    }
                }

                if (m_curPackLen > 0 && m_curPackLen <= m_fifoStream.DataSize)
                {
                    var packlen = m_fifoStream.Read(m_packBuff, 0, m_curPackLen);
                    m_curPackLen = 0;

                    try
                    {
                        var jsonlen = packlen;
                        for(int i = 0; i < packlen; i ++)
                        {
                            if(m_packBuff[i]==0)
                            {
                                jsonlen = i;
                                break;
                            }
                        }

                        var json = Encoding.UTF8.GetString(m_packBuff, 0, jsonlen);

                        // LogHelper.Log("json :" + json);
                        //JsonReader jr = new JsonReader(json);
                        LitJson.JsonData jd = JsonMapper.ToObject(json);
                        if (!jd.IsObject)
                            return;

                        m_onPackage?.Invoke(jd, m_packBuff, jsonlen+1, packlen- jsonlen-1);

                    }
                    catch (Exception e)
                    {
                        //throw e;
                        LogHelper.LogError(e.ToString());
                    }



                }
            } while (m_fifoStream.DataSize >= 4 && m_curPackLen == 0);

        }
    }


    class ParamDebugServer
    {
        static ParamDebugServer m_instance = null;
        public static ParamDebugServer Instance
        {
            get
            {
                if (m_instance == null)
                    m_instance = new ParamDebugServer();
                return m_instance;
            }
        }





        string persistentPath = IResourceLoader.persistentDataPath;
        Socket m_listenSocket;

        Socket m_conSocket;

        JsonMsgDepack m_depack;//= new JsonMsgDepack();
        NetBuffer m_recvBuffer = new NetBuffer(64*1024);

        public bool Start(int port = 54321)
        {
            UnityEngine.Application.logMessageReceived += OnLog;

            m_listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            int nPortAdd = 0;
            while (nPortAdd < 10)
            {
                try
                {
                    var endPoint = new IPEndPoint(IPAddress.Any, port + nPortAdd);
                    m_listenSocket.Bind(endPoint);
                    m_listenSocket.Listen(1024);
                    break;
                }
                catch (Exception)
                {

                    nPortAdd++;
                }
            }

            if (nPortAdd == 10)
                return false;


            using (var se = new SocketAsyncEventArgs())
            {
                se.Completed += OnAccept;
                m_listenSocket.AcceptAsync(se);
            }


            return true;
        }

        void OnAccept(object sender, SocketAsyncEventArgs e)
        {
            if (m_listenSocket == null)
                return;

            Disconnect();
            m_conSocket = e.AcceptSocket;
            if (m_conSocket == null || m_conSocket.Handle == IntPtr.Zero)
                return;
            try
            {
                m_depack = new JsonMsgDepack(OnPackage);
                using (var serecv = new SocketAsyncEventArgs())
                {
                    serecv.Completed += OnReceive;
                    serecv.SetBuffer(new byte[64 * 1024], 0, 64 * 1024);
                    m_conSocket.ReceiveAsync(serecv);
                }

                e.AcceptSocket = null;

                using (var se = new SocketAsyncEventArgs())
                {
                    se.Completed += OnAccept;
                    m_listenSocket.AcceptAsync(se);
                }
            }
            catch (Exception err)
            {
                LogHelper.LogError(err.ToString());
            }



        }

        void OnReceive(object sender, SocketAsyncEventArgs e)
        {
            bool bOk = e.SocketError == SocketError.Success;

            if (bOk)
            {
                if (e.BytesTransferred > 0)
                {

   
                    lock (m_depack)
                    {
                        m_depack.FillData(e.Buffer, e.BytesTransferred);
                        m_recvBuffer.Free(e.Buffer);
                    }
                    using (var serecv = new SocketAsyncEventArgs())
                    {
                        serecv.Completed += OnReceive;
                        var buf = m_recvBuffer.Alloc();
                        serecv.SetBuffer(buf, 0, buf.Length);
                        m_conSocket.ReceiveAsync(serecv);
                    }
                    //FillData(e.Buffer, e.BytesTransferred);



                }


            }
            else
            {
                m_conSocket.Close();
                m_conSocket.Dispose();

            }

        }

        void OnPackage(JsonData jd, byte[] data, int offset, int len)
        {
            //


            var cmd = jd["cmd"].ToString();
            //if (cmd != "setting")
            //{
            //    return;
            //}
            switch (cmd)
            {
                case "setting":
                    SettingProcess(jd);
                    break;
                case "file":
                    FileProcess(jd, data, offset, len);
                    break;
                case "log":
                    LogProcess(jd);
                    break;
                case "update_enable":
                    UpdateEnbaleProcess(jd);
                    break;
                case "get_persistent_path":
                    GetPersistentPath(jd);
                    break;
                default:
                    break;
            }
        }

        //Bokura.IResourceLoader.persistentDataPath

        //void FillData(byte[] data, int len)
        //{

        //}

        System.Reflection.Assembly m_assembly = System.Reflection.Assembly.GetCallingAssembly();
        bool SetObjectField(string prename, JsonData json)
        {
            if (!json.IsObject)
                return false;

            foreach (var key in json.Keys)
            {
                string typename;
                if (string.IsNullOrEmpty(prename))
                    typename = key;
                else
                    typename = Bokura.Utilities.BuildString(prename , "." , key);

                var type = m_assembly.GetType(typename);
                var valjson = json[key];
                if (type == null)
                {
                    if (!valjson.IsObject)
                        continue;
                    if (!SetObjectField(typename, valjson))
                    {

                    }
                    continue;
                }
                object temp = null;
                if (!SetObjectField(type, ref temp, valjson))
                {

                }
            }
            return true;
            //var type = m_assembly.GetType(fullPath);
            //if(type==null)
            //{
            //    var idx = fullPath.LastIndexOf('.');
            //    if (idx >= 0)
            //    {

            //        split.Add(fullPath.Substring(idx + 1));
            //        return SetObjectField(fullPath.Substring(0, idx), split, val);
            //    }
            //    else
            //        return false;

            //}

            //var propinfo = type.GetProperty(split[split.Count - 1]);




            // return SetObjectField(type, null, split, val);
        }

        bool SetObjectField(Type tp, ref object instance, JsonData json)
        {
            if (tp == typeof(Spline))
            {

                //Spline sp = (Spline)instance;
                //sp.value;
                var cachedData = tp.GetField("cachedData", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (cachedData == null)
                    return false;
                //var data = cachedData.GetValue(instance);
                float[] newdata = new float[json.Count];
                for (int i = 0; i < newdata.Length; i++)
                {
                    newdata[i] = (float)(double)json[i];
                }
                cachedData.SetValue(instance, newdata);

                return true;
            }

            //var membername = fls[fls.Count - 1];
            //fls.RemoveAt(fls.Count);

            foreach (var key in json.Keys)
            {
                var valjson = json[key];

                {
                    var propinfo = tp.GetProperty(key);
                    if (propinfo != null)
                    {
                        if (propinfo.PropertyType.IsPrimitive || propinfo.PropertyType.IsEnum)
                        {
                            if (propinfo.SetMethod == null)
                                continue;

                            if (propinfo.SetMethod.IsStatic)
                            {
                                propinfo.SetValue(null, JsonDataToObject(propinfo.PropertyType, valjson));
                            }
                            else if (instance != null)
                            {
                                propinfo.SetValue(instance, JsonDataToObject(propinfo.PropertyType, valjson));
                            }
                            else
                                continue;
                        }
                        else
                        {
                            object midobj;
                            if (propinfo.GetMethod == null)
                            {
                                midobj = propinfo.PropertyType.Assembly.CreateInstance(propinfo.PropertyType.FullName);

                            }
                            else
                            {
                                if (propinfo.GetMethod.IsStatic)
                                {
                                    midobj = propinfo.GetValue(null);
                                }
                                else if (instance != null)
                                {
                                    midobj = propinfo.GetValue(instance);
                                }
                                else
                                    continue;
                            }

                            if (propinfo.PropertyType.IsValueType)
                            {
                                if (SetObjectField(midobj.GetType(), ref midobj, valjson))
                                {

                                    if (propinfo.SetMethod.IsStatic)
                                    {
                                        propinfo.SetValue(null, midobj);
                                    }
                                    else if (instance != null)
                                    {
                                        propinfo.SetValue(instance, midobj);
                                    }
                                    else
                                        continue;

                                }
                                else
                                    continue;
                            }
                            else
                                SetObjectField(midobj.GetType(), ref midobj, valjson);
                        }

                    }
                }
                var fieldinfo = tp.GetField(key);
                if (fieldinfo == null)
                    return false;

                if (fieldinfo.FieldType.IsPrimitive || fieldinfo.FieldType.IsEnum)
                {
                    if (fieldinfo.IsStatic)
                    {
                        fieldinfo.SetValue(null, JsonDataToObject(fieldinfo.FieldType, valjson));
                    }
                    else if (instance != null)
                    {
                        fieldinfo.SetValue(instance, JsonDataToObject(fieldinfo.FieldType, valjson));
                    }
                    else
                        continue;
                }
                else
                {
                    object midobj;

                    if (fieldinfo.IsStatic)
                    {
                        midobj = fieldinfo.GetValue(null);
                    }
                    else if (instance != null)
                    {
                        midobj = fieldinfo.GetValue(instance);
                        //if(midobj==null)
                        //{
                        //    midobj = fieldinfo.FieldType.Assembly.CreateInstance(fieldinfo.FieldType.FullName);
                        //    if(midobj!=null)
                        //    {
                        //        fieldinfo.SetValue(instance, midobj);
                        //    }
                        //}
                    }
                    else
                        continue;


                    if (fieldinfo.FieldType.IsValueType)
                    {
                        if (SetObjectField(midobj.GetType(), ref midobj, valjson))
                        {

                            if (fieldinfo.IsStatic)
                            {
                                fieldinfo.SetValue(null, midobj);
                            }
                            else if (instance != null)
                            {
                                fieldinfo.SetValue(instance, midobj);
                            }
                            else
                                continue;

                        }
                        else
                            continue;
                    }
                    else if (midobj != null)
                        SetObjectField(midobj.GetType(), ref midobj, valjson);
                }
            }



            return true;
        }

        static object JsonDataToObject(Type type, JsonData valstr)
        {
            if (type == typeof(float))
            {

                return (float)(double)valstr;
            }
            else if (type == typeof(int))
            {
                return (int)(valstr);
            }
            else if (type == typeof(double))
            {
                return (double)(valstr);
            }
            else if (type == typeof(long))
            {
                return (long)(valstr);
            }
            else if (type == typeof(string))
            {
                return (string)valstr;
            }
            else if (type == typeof(bool))
            {
                return (bool)(valstr);
            }
            else if (type.IsEnum)
            {
                return (int)(valstr);
            }
            else if (type == typeof(UnityEngine.Vector4))
            {
                return new UnityEngine.Vector4(
                    (float)(double)valstr["x"],
                    (float)(double)valstr["y"],
                    (float)(double)valstr["z"],
                    (float)(double)valstr["w"]
                    )
                ;
            }
            else if (type == typeof(UnityEngine.Vector3))
            {
                return new UnityEngine.Vector3(
                    (float)(double)valstr["x"],
                    (float)(double)valstr["y"],
                    (float)(double)valstr["z"]

                    )
                ;
            }
            else if (type == typeof(UnityEngine.Vector2))
            {
                return new UnityEngine.Vector3(
                    (float)(double)valstr["x"],
                    (float)(double)valstr["y"]
                    )
                ;
            }
            else if (type == typeof(UnityEngine.Color))
            {
                return new UnityEngine.Color(
                    (float)(double)valstr["r"],
                    (float)(double)valstr["g"],
                    (float)(double)valstr["b"],
                    (float)(double)valstr["a"]
                    )
                ;
            }
            return null;

        }

        void Disconnect()
        {
            if (m_conSocket != null)
            {
                m_conSocket.Close();
                m_conSocket.Dispose();
                m_conSocket = null;
            }
        }

        public void Stop()
        {
            m_listenSocket.Close();
            m_listenSocket.Dispose();
            m_listenSocket = null;
            UnityEngine.Application.logMessageReceived -= OnLog;

        }

#region 命令处理
        void SettingProcess(JsonData jd)
        {
            //TODO:Game in Engine!
            Game.X2DebugUtilities.Instance.postProcessLayer.UpdateSettingFrame = false;
            var para = jd["para"];
            if (para != null)
            {
                MainThreadTask.getSingleton().push_task(() =>
                {
                    SetObjectField(null, para);
                });

            }
        }



        string m_curOpenFileName;
        FileStream m_curFileStream;
        enum FileOperation
        {
            Unknown,
            Write,
            Read,
            Close,
        }
        FileOperation m_curFileOperation = FileOperation.Unknown;

        void MakeSureDirExist(string path)
        {
            if (Directory.Exists(path))
                return;

            MakeSureDirExist(Path.GetDirectoryName(path));

            try
            {
                Directory.CreateDirectory(path);
            }
            catch(Exception )
            {

            }
            
        }
        void FileProcess(JsonData jd, byte[] data ,int dataoffset, int datalen)
        {
            var sop = jd["operation"].ToString();

            var filename = jd["name"].ToString();
            //int opidx = (int)jd["idx"];
            FileOperation op = FileOperation.Unknown;
            if (sop == "write")
            {
                op = FileOperation.Write;
            }
            else if (sop == "read")
            {
                op = FileOperation.Read;
            }
            else if (sop == "close")
            {
                if (m_curFileStream != null)
                {
                    m_curFileStream.Close();
                    m_curFileStream.Dispose();
                    m_curFileStream = null;
                    ResponseFile(true, 0,0);
                }
                else
                {
                    ResponseFile(false, 0,0);
                }
                return;

            }
            if (filename != m_curOpenFileName || op != m_curFileOperation)
            {
                if (m_curFileStream != null)
                {
                    m_curFileStream.Close();
                    m_curFileStream.Dispose();
                    m_curFileStream = null;
                }

            }
            m_curOpenFileName = filename;
            m_curFileOperation = op;
            if (m_curFileStream == null)
            {
                if (m_curFileOperation == FileOperation.Write)
                {
                    var path = PathUtility.StandardPath(Path.Combine(persistentPath, m_curOpenFileName));
                    MakeSureDirExist(Path.GetDirectoryName(path));
                    m_curFileStream = File.OpenWrite(path);
                    if (m_curFileStream == null)
                    {
                        ResponseFile(false, 0,0);
                        return;
                    }
                    m_curFileStream.SetLength(0);
                }
            }
            long offset = jd.IsLong?(long)jd["offset"]: (int)jd["offset"];
            //var sdata = (string)jd["data"];
            //var data = Convert.FromBase64String(sdata);
            m_curFileStream.Seek(offset, SeekOrigin.Begin);
            m_curFileStream.Write(data, dataoffset, datalen);
            ResponseFile(true, offset, datalen);

        }
        void ResponseFile(bool ok, long offset, long len)
        {
       
            JsonData jd = new JsonData();
            jd.SetJsonType(JsonType.Object);
            jd["cmd"] = "file_response";
            jd["result"] = ok;
            jd["offset"] = offset;
            jd["len"] = len;
            SendString(jd.ToJson());
                //serecv.Completed += OnReceive;
                //serecv.SetBuffer(new byte[64 * 1024], 0, 64 * 1024);
                //m_conSocket.ReceiveAsync(serecv);
            
        }


        void SendString(string str)
        {
            if (m_conSocket == null || !m_conSocket.Connected)
                return;
            using (var sende = new SocketAsyncEventArgs())
            {
                var strlen = Encoding.UTF8.GetByteCount(str);
                var buff = new byte[strlen + 4];
                buff[0] = (byte)(0xff & strlen);
                buff[1] = (byte)((0x0000ff00 & strlen) >> 8);
                buff[2] = (byte)((0x00ff0000 & strlen) >> 16);
                buff[3] = (byte)((0xff000000 & strlen) >> 24);
                Encoding.UTF8.GetBytes(str, 0, str.Length, buff, 4);
                sende.SetBuffer(buff, 0, buff.Length);
                //sende.Completed += OnSendComplete;
                m_conSocket.SendAsync(sende);
            }
        }

        ///logprocess
        ///

        bool m_logNeedStack;
        bool m_bLogEnable;
        void LogProcess(JsonData jd)
        {
            m_bLogEnable = (bool)jd["enable"];
            m_logNeedStack = (bool)jd["need_stack"];
            MainThreadTask.getSingleton().push_task(() => 
            {
                //if (enable)
                //    UnityEngine.Application.logMessageReceived += OnLog;
                //else
                 //   UnityEngine.Application.logMessageReceived -= OnLog;
            });
            
        }

        void OnLog(string condition, string stackTrace, UnityEngine.LogType type)
        {
            if (!m_bLogEnable)
                return;
            JsonData jd = new JsonData();
            jd.SetJsonType(JsonType.Object);
            jd["cmd"] = "log";
            jd["data"] = condition;
            if (m_logNeedStack)
                jd["stack"] = stackTrace;
            jd["logtype"] = (int)type;
            SendString(jd.ToJson());
        }

        void GetPersistentPath(JsonData jd)
        {
            JsonData rjd = new JsonData();
            rjd.SetJsonType(JsonType.Object);
            rjd["cmd"] = "get_persistent_path_response";
            rjd["path"] = persistentPath;
            SendString(rjd.ToJson());
        }

        void UpdateEnbaleProcess(JsonData jd)
        {
            var enable = (bool)jd["enable"];
            var path = Path.Combine(persistentPath, "LuaScript/needupdate.lua");
            MakeSureDirExist(Path.GetDirectoryName(path));

            using (FileStream fs = File.OpenWrite(path))
            {
                string s = Bokura.Utilities.BuildString( "return " , (enable ? "true" : "false"));
                var bytes = Encoding.UTF8.GetBytes(s);
                fs.Write(bytes, 0, bytes.Length);
            }
        }
#endregion

    }



}
#endif