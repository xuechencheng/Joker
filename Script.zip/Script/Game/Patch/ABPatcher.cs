using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text;
using System;
using System.Threading;
using Bokura;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Bokura
{


	public class ABPatcher
	{

		Thread m_Thread;

		string persistentDataPath = IResourceLoader.persistentDataPath;
		int ApplyOnePatch(string oldfilepath, string patchpath, string outputpath)
		{
			try
			{
				oldfilepath = PathUtility.StandardPath(oldfilepath);
				patchpath = PathUtility.StandardPath(patchpath);
				outputpath = PathUtility.StandardPath(outputpath);

                LogHelper.Log("start patch file:" + oldfilepath + "->" + outputpath + "|" + patchpath);

                var r = BsDiff.Native.DiffApply(oldfilepath, patchpath, outputpath, IntPtr.Zero);

                LogHelper.Log("patch file done:" + oldfilepath + "->" + outputpath + "|" + patchpath + " result:" + r);

                //var oldbytes = Bokura.IFile.ReadApkResourceFiles(oldfilepath);
                //int oldlength = oldbytes.Length;
                //var oldmemstream = new MemoryStream(oldbytes);
                //List<Stream> openedStream = new List<Stream>();
                //System.Func<Stream> patchfs = () =>
                //{
                //	var stream = File.Open(patchpath, FileMode.Open, FileAccess.Read, FileShare.Read);
                //	openedStream.Add(stream);
                //	return stream;
                //};

                //var outpathstream = File.Open(outputpath, FileMode.Create);

                //int r = BsDiff.BinaryPatchUtility.Apply(oldmemstream, patchfs, outpathstream);
                //foreach (var a in openedStream)
                //{
                //	a.Close();
                //}
                //oldbytes = null;
                //oldmemstream = null;
                //outpathstream.Close();
                //outpathstream = null;

                //if (oldlength>1024*1024*2)
                //{
                //	System.GC.Collect();
                //}
                return r;
			}
			catch (Exception e)
			{
                LogHelper.LogError("apply patch error:" + e.ToString());
				return -1;
			}
		}

		public delegate void OnPatchProgress(int stage, int curstep, int maxstep, int state);
		public void ApplyPatchAsync(string patchdir, OnPatchProgress patchprogress)
		{
			if (m_Thread != null)
			{
                LogHelper.LogError("apply patch working...");
				return;
			}
			m_Thread = new Thread(() =>
			{
				try
				{

#if UNITY_ANDROID
				AndroidJNI.AttachCurrentThread();
#endif
				ApplyPatch(patchdir, (int stage, int curstep, int maxstep, int state) =>
					{

						MainThreadTask.getSingleton().push_task(() =>
						{
							patchprogress(stage, curstep, maxstep, state);
						});

					});


#if UNITY_ANDROID
				AndroidJNI.DetachCurrentThread();
#endif
			}
				catch (Exception e)
				{
                    LogHelper.Log(e.ToString());
					MainThreadTask.getSingleton().push_task(() =>
					{
						patchprogress(0, 0, 0, 2);
					});
				}


				m_Thread = null;
			});
			m_Thread.Start();
		}

		public void ForceStop()
		{
            if(m_Thread!=null)
            {
                m_Thread.Abort();
                m_Thread = null;
            }

        }

		public bool ApplyPatch(string patchdir, OnPatchProgress patchprogress)
		{
			patchdir = PathUtility.StandardPath(patchdir);

			if (patchdir.Substring(patchdir.Length - 1) != "/")
				patchdir += "/";

			if (persistentDataPath.Substring(persistentDataPath.Length - 1) != "/")
				persistentDataPath += "/";

			//apply bs patch
			var patchfiles = Directory.GetFiles(patchdir, "*.bp", SearchOption.AllDirectories);
			int nIdx = 0;

            foreach (var patchfullpath in patchfiles)
			{
				var patchpath = patchfullpath.Substring(patchdir.Length);
				var abpath = patchpath.Substring(0, patchpath.Length - 3);

                var tempnewfilepath = Bokura.Utilities.BuildString(patchfullpath, ".new");

                var oldpatchfile = Bokura.Utilities.BuildString(persistentDataPath, abpath);
                LogHelper.Log("patch ", oldpatchfile," ", tempnewfilepath);

                var oldpatchfile_renamed = Bokura.Utilities.BuildString(oldpatchfile, ".old");
                if (!File.Exists(oldpatchfile) && !File.Exists(oldpatchfile_renamed))
				{

                    var tempnewfiledir = Path.GetDirectoryName(tempnewfilepath);
					if (!Directory.Exists(tempnewfiledir))
					{
						Directory.CreateDirectory(tempnewfiledir);
					}
					var oldpathdir = Path.GetDirectoryName(oldpatchfile);
					if (!Directory.Exists(oldpathdir))
					{
						Directory.CreateDirectory(oldpathdir);
					}

					int appresult = ApplyOnePatch(abpath, patchfullpath, tempnewfilepath);
                    LogHelper.Log("patch result", appresult);
                    if (appresult == 0)
					{
						File.Move(tempnewfilepath, oldpatchfile);
						File.Delete(patchfullpath);
					}
					else if (appresult == 1)
					{
						File.Delete(patchfullpath);
					}
					else
					{
						patchprogress(0, nIdx, patchfiles.Length, 2);
                        LogHelper.Log("patch error!");
                        return false;
					}

				}
				else
				{

					if (!File.Exists(oldpatchfile_renamed))
					{

						try
						{
							File.Move(oldpatchfile, oldpatchfile_renamed);
						}
						catch (Exception e)
						{
                            LogHelper.LogError(e.ToString());
							patchprogress(0, nIdx, patchfiles.Length, 2);

							return false;
						}

					}
                    LogHelper.Log("patch exist ", oldpatchfile_renamed, " ", patchfullpath," ", tempnewfilepath);

                    int appresult = ApplyOnePatch(oldpatchfile_renamed, patchfullpath, tempnewfilepath);
					if (appresult == 0)
					{
						int donestep = 0;
						for(int retry=0;true; retry ++ )
						{
							try
							{
                               
								if (donestep==0)
								{
									File.Delete(oldpatchfile);
									donestep++;
								}

								if (donestep == 1)
								{
									File.Move(tempnewfilepath, oldpatchfile);
									donestep++;
								}
								if (donestep == 2 && File.Exists(patchfullpath))
								{
									File.Delete(patchfullpath);
									donestep++;
								}
								if (donestep == 3 && File.Exists(oldpatchfile_renamed))
								{
									File.Delete(oldpatchfile_renamed);
									donestep++;
								}
								break;
							}
							catch (Exception e)
							{
                                LogHelper.LogError(e.ToString());
								Thread.Sleep(1000);
								if (retry > 5)
								{
									patchprogress(0, nIdx, patchfiles.Length, 2);
									return false;
								}
							}
						}
						
					}
					else if (appresult == 1)
					{
						try
						{

							File.Move(oldpatchfile_renamed, oldpatchfile);
							File.Delete(tempnewfilepath);
							File.Delete(patchfullpath);

						}
						catch (Exception e)
						{
                            LogHelper.LogError(e.ToString());
							patchprogress(0, nIdx, patchfiles.Length, 2);
							return false;
						}
					}
				}


				++nIdx;
				if (patchprogress != null)
				{
					patchprogress(0, nIdx, patchfiles.Length, 0);
				}
			}

			var addedfiles = Directory.GetFiles(patchdir, "*", SearchOption.AllDirectories);
			nIdx = 0;
            foreach (var newfilefull in addedfiles)
			{
				var filepath = newfilefull.Substring(patchdir.Length);

                var oldpatchfile = Bokura.Utilities.BuildString(persistentDataPath, filepath);
                var filedir = Path.GetDirectoryName(oldpatchfile);
				if (!Directory.Exists(filedir))
					Directory.CreateDirectory(filedir);
				try
				{
					File.Copy(newfilefull, oldpatchfile, true);
					File.Delete(newfilefull);
				}
				catch (Exception e)
				{
                    LogHelper.LogError(e.ToString());
					patchprogress(1, nIdx, patchfiles.Length, 2);

					return false;
				}
				nIdx++;
				if (patchprogress != null)
				{
					patchprogress(1, nIdx, patchfiles.Length, 0);
				}
			}

			patchprogress(1, nIdx, patchfiles.Length, 1);

			return true;
		}

#if UNITY_EDITOR
		[MenuItem("Tools/Test Apply ABPatch")]

		static void TestApplyABPatch()
		{
			ABPatcher patcher = new ABPatcher();
			patcher.ApplyPatch(Path.Combine(IResourceLoader.persistentDataPath, "patch.zip_temp"), null);
		}

		[MenuItem("Tools/GC")]

		static void GC()
		{
			System.GC.Collect();
		}
#endif

	}

}