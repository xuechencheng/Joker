using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.Events;
using Bokura;

namespace Bokura
{
    public class AutoPathFinder : ClientSingleton<AutoPathFinder>
    {
        /// <summary>
        /// 列数
        /// </summary>
       // private const int kColumn = 32;

        /// <summary>
        /// 行数
        /// </summary>
        //private const int kRow = 32;
        private const int m_MagicNumber = 1000;

        /// <summary>
        /// 传送点：Key表示地块索引（512 * 512）,Value表示该地块内的传送点坐标
        /// </summary>
        private Dictionary<int, TransmissionGroup> m_TransPoints;
        private AutoFindPathConfig m_Config;
        /// <summary>
        /// 最小寻路距离
        /// </summary>
        public int minPathLength { get { return m_Config.minPathLength; } }
        /// <summary>
        /// 当前的访问ID
        /// </summary>
       // private int m_VisitID = Const.kInt_Min;
        private bool m_Working = false;
        /// <summary>
        /// 是否正在寻路中
        /// </summary>
        public bool working
        {
            get { return m_Working; }
        }
        /// <summary>
        /// 监听加载结束事件
        /// </summary>
        private UnityAction m_OnEndLoading = null;
        /// <summary>
        /// 传送结束回调函数
        /// </summary>
        private BoolDelegate m_OnBlinkFinished = null;
        public delegate bool MoveByPathFindFunc(Vector3 targetPos, MovableEntity.OnMoveStopDelegate onStop, float distance = 0.01f);

        private BoolDelegate m_OnProcessBlinkFinished = null;
        /// <summary>
        /// 点到点的具体寻路移动方法
        /// </summary>
        private MoveByPathFindFunc m_MoveFunc;
        /// <summary>
        /// 到达初始传送点后的移动方法
        /// </summary>
        private MovableEntity.OnMoveStopDelegate m_MoveByBlink;
        /// <summary>
        /// 寻路到终点的方法
        /// </summary>
        private BoolDelegate m_MoveToStopFunc;
        private enum MoveType
        {
            /// <summary>
            /// 使用传送点
            /// </summary>
            UseBlink,
            /// <summary>
            /// 直接移动
            /// </summary>
            DirectMove
        }
        /// <summary>
        /// 当前移动方式
        /// </summary>
        private MoveType m_CurMoveType;
        /// <summary>
        /// 外部传入的停止移动事件回调函数
        /// </summary>
        private MovableEntity.OnMoveStopDelegate m_OnStop;

        /// <summary>
        /// 到达目标点多少距离时停下来
        /// </summary>
        private float m_StopDistance;

        /// <summary>
        /// 内部包装的停止移动事件回调函数
        /// </summary>
        private MovableEntity.OnMoveStopDelegate m_OnMoveStop;
        /// <summary>
        /// 终点坐标
        /// </summary>
        private Vector3 m_StopPos;
        /// <summary>
        /// 初始传送点对应的NPC的id
        /// </summary>
        private uint m_TransPointA_NPC_ID;
        /// <summary>
        /// 初始传送点的位置
        /// </summary>
        private Vector3 m_TransPointA_POS;
        /// <summary>
        /// 目标传送点的id
        /// </summary>
        private int m_TransPointB_ID;
        /// <summary>
        /// 目标传送点对应的NPC的id
        /// </summary>
        private uint m_TransPointB_NPC_ID;
        /// <summary>
        /// 目标传送点的位置
        /// </summary>
        private Vector3 m_TransPointB_POS;
        /// <summary>
        /// 起始传送点
        /// </summary>
        private Npc m_StartTransPoint;
        /// <summary>
        /// 结束传送点
        /// </summary>
        private Npc m_StopTransPoint;
        /// <summary>
        /// 终点
        /// </summary>
        private Npc m_StopPoint;
        private GameEvent<Entity> m_OnAddEntity = new GameEvent<Entity>();
        public GameEvent<Entity> onAddEntity { get { return m_OnAddEntity; } }
        private GameEvent<Entity> m_OnRemoveEntity = new GameEvent<Entity>();
        public GameEvent<Entity> onRemoveEntity { get { return m_OnRemoveEntity; } }
        private GameEvent<Entity> m_OnAddFakeEntity = new GameEvent<Entity>();
        public GameEvent<Entity> onAddFakeEntity { get { return m_OnAddFakeEntity; } }
        private GameEvent<Entity> m_OnRemoveFakeEntity = new GameEvent<Entity>();
        public GameEvent<Entity> onRemoveFakeEntity { get { return m_OnRemoveFakeEntity; } }
        /// <summary>
        /// 初始化
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            this.m_OnEndLoading = OnEndLoadingCallback;
            this.m_MoveToStopFunc = MoveToStop;
            this.m_MoveByBlink = MoveByBlink;
            this.m_OnMoveStop = OnMoveStop;

            GameScene.Instance.onMainCharAdd.AddListener(InitPoints);
        }
        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {
            this.m_CurMoveType = MoveType.UseBlink;
            this.m_StopPos = default(Vector3);
            this.m_OnStop = null;
            this.m_StopDistance = 0;
            this.m_StopPos = default(Vector3);
            this.m_TransPointA_NPC_ID = 0;
            this.m_TransPointA_POS = default(Vector3);
            this.m_TransPointB_ID = 0;
            this.m_TransPointB_NPC_ID = 0;
            this.m_TransPointB_POS = default(Vector3);
            this.m_StartTransPoint = null;
            this.m_StopTransPoint = null;
            this.m_StopPoint = null;
            GameScene.Instance.onMainCharAdd.RemoveListener(InitPoints);
            GameScene.Instance.onMainCharAdd.AddListener(InitPoints);
        }
        /// <summary>
        /// 只需要调用一次
        /// </summary>
        /// <param name="moveFunc">执行点到点寻路的具体方法</param>
        public void Init(MoveByPathFindFunc moveFunc, BoolDelegate _ProcessBlinkFinished)
        {
            this.m_MoveFunc = moveFunc;
            m_OnProcessBlinkFinished = _ProcessBlinkFinished;//这个是外部blinkfinish的时候需要进行一些状态判断，是否能够直接走，如果没这个值 那就默认之前的逻辑
        }
        public void ClearMoveStop()
        {
            this.m_OnStop = null;
            
        }
        /// <summary>
        /// 初始化自动寻路任务
        /// </summary>
        public void Init(Vector3 curPos /*当前位置*/, Vector3 targetPos/*目标位置*/, MovableEntity.OnMoveStopDelegate onStop/*停止移动的回调*/, float distance = 0.01f/*避免骑脸*/)
        {
            this.m_StopPos = targetPos;
            this.m_OnStop = onStop;
            this.m_StopDistance = distance;

            //先判断直接寻路更快，还是经过传送更快
            int tTransPointA_ID;
            TransPoint tTransPointA = GetNearestTransPointInfo(curPos, out tTransPointA_ID);
            m_TransPointA_POS = tTransPointA.pos;
            m_TransPointA_NPC_ID = tTransPointA.npc_ID;
            TransPoint tTransPointB = GetNearestTransPointInfo(targetPos, out m_TransPointB_ID);
            m_TransPointB_POS = tTransPointB.pos;
            m_TransPointB_NPC_ID = tTransPointB.npc_ID;
            float tDistance = Vector3.Distance(curPos, targetPos);
            float tDistanceA = Vector3.Distance(m_TransPointA_POS, curPos);
            float tDistanceB = Vector3.Distance(m_TransPointB_POS, targetPos);
            //如果任意一端的跳转点没有找到，或者经过跳转点寻路更远，或者跳转点相同，就直接寻路过去
            if (m_TransPointA_POS == curPos || m_TransPointB_POS == targetPos || tTransPointA_ID == m_TransPointB_ID || tDistance < tDistanceA + tDistanceB)
                m_CurMoveType = MoveType.DirectMove;
            else
                m_CurMoveType = MoveType.UseBlink;
        }
        /// <summary>
        /// 加载世界地图跳转表（StreamingAssets/Tables/WorldTransTable.bin）
        /// </summary>
        [XLua.BlackList]
        public void Load()
        {
            /*加载一些不适合放入Excel表的Json配置数据*/
            string tJsonData = TableManager.LoadFileTable("Auto_FindPath.json", "/Datas/");
            m_Config = JsonMapper.ToObject<AutoFindPathConfig>(tJsonData);

            //在WorldTransTableManager之后调用，真正加载任务由WorldTransTableManager.Load完成
            if (WorldTransTableManager.Instance == null)
                WorldTransTableManager.Load();
            WorldTransTableBaseList tDataList = WorldTransTableManager.Instance.m_DataList;
            int tCount = tDataList.WorldTransTableLength;
            m_TransPoints = new Dictionary<int, TransmissionGroup>(Const.kCap16);
            for (int tIdx = 0; tIdx < tCount; tIdx++)
            {
                WorldTransTableBase? tDataBase = tDataList.WorldTransTable(tIdx);
                if (tDataBase.HasValue)
                {
                    WorldTransTableBase tData = tDataBase.Value;
                    Vector3 tPos = UIUtility.ParseVector3(tData.map_pos);
                    Vector2Int tIndices = GetIndexByPos(tPos);
                    int tIndex = tIndices.x * m_MagicNumber + tIndices.y;
                    TransmissionGroup tPoints = null;
                    if (!m_TransPoints.TryGetValue(tIndex, out tPoints))
                    {
                        tPoints = new TransmissionGroup();
                        m_TransPoints.Add(tIndex, tPoints);
                    }
                    TransPoint tTP;
                    tTP.pos = tPos;
                    tTP.npc_ID = (uint)tData.cor_npc;
                    tPoints.Add(tData.id, tTP);
                }
            }
        }
        /// <summary>
        /// 在主角进入游戏场景时初始化自动寻路所需的实体
        /// </summary>
        private void InitPoints()
        {
            //内部读表，因此需要在加载完成后调用
            this.m_StartTransPoint = CreateEntity();
            this.m_StopTransPoint = CreateEntity();
            this.m_StopPoint = CreateEntity();
            GameScene.Instance.onMainCharAdd.RemoveListener(InitPoints);
        }
        /// <summary>
        /// 构造实体
        /// </summary>
        private Npc CreateEntity()
        {
            var tData = new swm.MapEntityDataT();
            //tData.entity_type = swm.EntityType.Npc;
            tData.cur_dir = Vector3.forward.Vec3();

            var tNpcData = new swm.MapNpcT();
            tData.npc_data = tNpcData;
            tNpcData.baseid = 0;
            tNpcData.career_sex = swm.CareerSex.Unknown;
            tNpcData.career_type = swm.CareerType.Unknown;

            Npc tEntity = new Npc(0);
            tEntity.init();
            tEntity.SetData(tData);
            return tEntity;
        }
        /// <summary>
        /// 获取终点的图标资源路径
        /// </summary>
        public string GetStopPointIconPath()
        {
            return m_Config.pathfind_Stop;
        }
        /// <summary>
        /// call after Init(Vector3, Vector3, MovableEntity.OnMoveStopDelegate, float)
        /// </summary>
        public bool DoTask()
        {
            if (this.m_MoveFunc == null)
                return false;
            m_Working = true;
            ShowIconInMap();
            if (m_CurMoveType == MoveType.UseBlink)
                return MoveToTarget(m_TransPointA_POS, m_MoveByBlink, m_StopDistance);
            else
                return MoveToStop();
        }
        /// <summary>
        /// 在小地图上显示图标
        /// </summary>
        private void ShowIconInMap()
        {
            if (m_CurMoveType == MoveType.UseBlink)
            {
                //开启小地图的传送点标志
                if(null != m_StartTransPoint)
                {
                    m_StartTransPoint.NpcData.baseid = m_TransPointA_NPC_ID;
                    m_StartTransPoint.Position = m_TransPointA_POS;
                    m_OnAddEntity.Invoke(m_StartTransPoint);
                }
                if(null != m_StopTransPoint)
                {
                    m_StopTransPoint.NpcData.baseid = m_TransPointB_NPC_ID;
                    m_StopTransPoint.Position = m_TransPointB_POS;
                    m_OnAddEntity.Invoke(m_StopTransPoint);
                }
            }
            //开启小地图的寻路终点标志
            if(null != m_StopPoint)
            {
                m_StopPoint.Position = m_StopPos;
                m_OnAddFakeEntity.Invoke(m_StopPoint);
            }
        }
        /// <summary>
        /// 在小地图上隐藏图标
        /// </summary>
        private void HiddenIconInMap()
        {
            if (m_CurMoveType == MoveType.UseBlink)
            {
                //关闭小地图的传送点标志
                m_OnRemoveEntity.Invoke(m_StartTransPoint);
                m_OnRemoveEntity.Invoke(m_StopTransPoint);
            }
            //关闭小地图的寻路终点标志
            m_OnRemoveFakeEntity.Invoke(m_StopPoint);
        }
        /// <summary>
        /// 恢复小地图上的图标。
        /// 目前小地图在跳转场景时会重置清空
        /// </summary>
        private void RestoreIconInMap()
        {
            if (!m_Working) return;
            if (m_CurMoveType == MoveType.UseBlink)
            {
                //恢复小地图的传送点标志
                m_OnAddEntity.Invoke(m_StartTransPoint);
                m_OnAddEntity.Invoke(m_StopTransPoint);
            }
            //恢复小地图的寻路终点标志
            m_OnAddFakeEntity.Invoke(m_StopPoint);
        }
        /// <summary>
        /// 传送
        /// </summary>
        private void MoveByBlink(bool isArrive)
        {
            if (isArrive)
            {
                if(null != m_OnProcessBlinkFinished)
                {
                    BlinkTo(m_TransPointB_ID, m_OnProcessBlinkFinished);
                }
                else
                {
                    BlinkTo(m_TransPointB_ID, m_MoveToStopFunc);
                }
                
            }
            else
            {
                OnMoveStop(false);
            }
        }
        /// <summary>
        /// 移动到终点
        /// </summary>
        public bool MoveToStop()
        {
            return MoveToTarget(m_StopPos, m_OnMoveStop, m_StopDistance);
        }
        /// <summary>
        /// 移动到指定目标点
        /// </summary>
        private bool MoveToTarget(Vector3 target, MovableEntity.OnMoveStopDelegate callback, float distance)
        {
            return this.m_MoveFunc(target, callback, distance);
        }
        /// <summary>
        /// 事件回调
        /// </summary>
        private void OnMoveStop(bool isArrive)
        {
            if (false == m_Working) return;
            m_Working = false;
            HiddenIconInMap();
            if (m_OnStop != null)
            {
                var tCallback = m_OnStop;
                m_OnStop = null;
                tCallback(isArrive);
            }
        }
        /// <summary>
        /// 根据当前位置找到最近的传送点，如果没有，返回位置本身
        /// </summary>
        public Vector3 GetNearestTransPoint(Vector3 curPos)
        {
            int tID = -1;
            TransPoint tPoint = GetNearestTransPointInfo(curPos, out tID);
            return tPoint.pos;
        }
        /// <summary>
        /// 根据当前位置找到最近的传送点id，如果没有，返回-1
        /// </summary>
        public int GetNearestTransPointID(Vector3 curPos)
        {
            int tID = -1;
            GetNearestTransPointInfo(curPos, out tID);
            return tID;
        }
        public TransPoint GetNearestTransPointInfo(Vector3 curPos, out int id)
        {
            id = -1;
            Vector2Int tIndices = GetIndexByPos(curPos);
            TransPoint tPoint = new TransPoint();
            tPoint.pos = curPos;

//             if (m_VisitID >= Const.kInt_Max - 10)
//                 ResetVisitCount();
//             m_VisitID += 1;
// 
             //先在所属地块中查找传送点
             if (TryFindPoint(tIndices, 0, curPos, ref tPoint, ref id))
                 return tPoint;
             //再从周围8个地块中查找
             if (TryFindPoint(tIndices, 1, curPos, ref tPoint, ref id))
                 return tPoint;
             //再从外围16个地块中查找
             if (TryFindPoint(tIndices, 2, curPos, ref tPoint, ref id))
                 return tPoint;
             //再从外围24个地块中查找
             if (TryFindPoint(tIndices, 3, curPos, ref tPoint, ref id))
                 return tPoint;
             //否则，别查找了 找到也是太远的距离，导航也无法去到那个跳转点


            return tPoint;
        }
        /// <summary>
        /// 尝试查找指定范围的地块中最近的传送点
        /// </summary>
        private bool TryFindPoint(Vector2Int indices, int _index, Vector3 curPos, ref TransPoint point, ref int id)
        {
            float tMinDistance = Const.kInt_Max;
            bool tSuccess = false;
            if(m_TransPoints.Count > 0)
            {
                int tBottom = indices.x - _index;
                int tTop = indices.x + _index;

                int tLeft = indices.y - _index;
                int tRight = indices.y + _index;

                for (int tRow = tBottom; tRow <= tTop; tRow++)
                {
                    for (int tColumn = tLeft; tColumn <= tRight; tColumn++)
                    {
                        int tIndex = tRow * m_MagicNumber + tColumn;
                        TransmissionGroup tGroup = null;
                        if (m_TransPoints.TryGetValue(tIndex, out tGroup))
                        {
                            //查找最近点
                            foreach (var pair in tGroup)
                            {
                                TransPoint tPoint = pair.Value;
                                float tDistance = Vector3.Distance(curPos, tPoint.pos);
                                if (tDistance < tMinDistance)
                                {
                                    tMinDistance = tDistance;
                                    point = tPoint;
                                    id = pair.Key;
                                }
                            }
                            tSuccess = true;
                        }
                    }

                }
            }

            return tSuccess;
        }
        /// <summary>
        /// 重置访问次数
        /// </summary>
//         private void ResetVisitCount()
//         {
//             m_VisitID = Const.kInt_Min;
//             foreach (var pair in m_TransPoints)
//                 pair.Value.visitID = Const.kInt_Min;
//         }
        /// <summary>
        /// 根据位置获取所属地块的二维索引（行优先）
        /// </summary>
        private Vector2Int GetIndexByPos(Vector3 pos)
        {
            int tColumn = (int)(pos.x / 512);//Mathf.RoundToInt(Mathf.Max(pos.x, 0)) / 512;
            int tRow = (int)(pos.z / 512); //Mathf.RoundToInt(Mathf.Max(pos.z, 0)) / 512;
            return new Vector2Int(tRow, tColumn);
        }
        /// <summary>
        /// 传送点间的跳转
        /// </summary>
        public void BlinkTo(int id, BoolDelegate onBlinkFinished)
        {
            if (id < 0)
                return;
            m_OnBlinkFinished = onBlinkFinished;
            blinktoid = (uint)id;
            DeliveryManager.Instance.onPlayDeliveryFinishEvent.AddListener(onPlayDeliveryFinishEvent);
            DeliveryManager.Instance.AskPlayDeliveryShow();
            ////跳转前，临时移除
            //HiddenIconInMap();
            //GameScene.Instance.onEndLoading.AddListener(m_OnEndLoading);
            //MapManager.Instance.RequestTeleportToMap_CS((uint)id);
        }
        private uint blinktoid = 0;
        public void onPlayDeliveryFinishEvent()
        {
            DeliveryManager.Instance.onPlayDeliveryFinishEvent.RemoveListener(onPlayDeliveryFinishEvent);
            //跳转前，临时移除
            HiddenIconInMap();
            GameScene.Instance.onEndLoading.AddListener(m_OnEndLoading);
            MapManager.Instance.RequestTeleportToMap_CS(blinktoid);
        }
        private void OnEndLoadingCallback()
        {
            if (m_OnBlinkFinished != null)
            {
                m_OnBlinkFinished();
                m_OnBlinkFinished = null;
            }
            //跳转后，恢复图标
            RestoreIconInMap();
            GameScene.Instance.onEndLoading.RemoveListener(m_OnEndLoading);
        }
    }
    /// <summary>
    /// 传送点分组
    /// </summary>
    public class TransmissionGroup : Dictionary<int, TransPoint>
    {
        public int visitID;
        public TransmissionGroup()
        {
            visitID = Const.kInt_Min;
        }
    }
    public struct TransPoint
    {
        public Vector3 pos;
        /// <summary>
        /// 对应NPC表的id
        /// </summary>
        public uint npc_ID;
    }
    [System.Serializable]
    public struct AutoFindPathConfig
    {
        /// <summary>
        /// 寻路终点图标
        /// </summary>
        public string pathfind_Stop;
        /// <summary>
        /// 最小寻路距离
        /// </summary>
        public int minPathLength;
    }
}
