#define WITH_MAIN_PATH
#define WORLD_OFFSET

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Bokura;

namespace Bokura.AI
{
    public class PathFinderAgent
        : Bokura.IPathAgent

    {

        // Use this for initialization
        public PathFinderAgent()
        {
        }

        #region MemberData

        public Vector3 mDestPos;
        NavMeshInfo mDestNavMeshInfo;
        List<MainPathData.PathStep> mMainPath = new List<MainPathData.PathStep>(16);
        int mMainIndex;
        double mMainProgress;
        List<NavPortal> mPath = new List<NavPortal>(12);
        NavMeshPath NMPath = new NavMeshPath();
        int mPathIndex; //路径上将要经过的点索引
        Vector3? m_lastPathDest; //上一个阶段的阶段目的点
        Vector3[] mTempPath = new Vector3[2];
        //List<GameObject> m_PointObjects = new List<GameObject>();
        void AddTagObject(Vector3 pos, UnityEngine.PrimitiveType type, float scale = 1.0f)
        {
            var pobj = GameObject.CreatePrimitive(type);
            pobj.transform.position = pos;
            pobj.transform.localScale = new Vector3(scale, scale, scale);
            var coll = pobj.GetComponent<Collider>();
            if (coll)
            {
                coll.enabled = false;
            }
            //m_PointObjects.Add(pobj);
        }
        #endregion

        #region Interface Implement
        public override void NotifySceneLoaded(string sceneName)
        {
            
        }
#if UNITY_EDITOR
        /// <summary>
        /// render the finding path in scene mode, for debugging
        /// 
        /// </summary>
        /// <param name="bShow">true: render the finding path</param>
        public override void RenderPath(bool bShow)
        {
            if(bShow)
            {
                var count = mPath.Count;
                for(int i = 0; i < count - 1; ++i)
                {
#if WORLD_OFFSET
                    Vector3 startPos = mPath[i].bounds.center - LayeredSceneLoader.WorldOffset;
                    Vector3 dstPos = mPath[i + 1].bounds.center - LayeredSceneLoader.WorldOffset;
#endif
                    Gizmos.color = colors[i % colors.Length];
                    Gizmos.DrawLine(startPos, dstPos);
                    var t = (int)mPath[i].type;
                    Gizmos.color = colors[t < 4 ? 4 : t - 4];
                    Gizmos.DrawCube(startPos, mPath[i].bounds.size);
                }
                Gizmos.color = colors[mPathIndex % colors.Length];
                for (int i = 0; i < navPath.Length - 1; i++)
                {
                    var start = navPath[i];
                    var end = navPath[i + 1];
#if WORLD_OFFSET
                    start -= LayeredSceneLoader.WorldOffset;
                    end -= LayeredSceneLoader.WorldOffset;
#endif
                    Gizmos.DrawLine(start, end);
                    Gizmos.DrawWireCube(end, Vector3.one);
                }
                Gizmos.color = new Color(1, 0.5f, 0);
            }
            
        }
        static Color[] colors = { Color.red, Color.green, Color.yellow, Color.magenta, Color.blue, Color.cyan };
        Vector3[] navPath = new Vector3[0];
#endif
        /// 计算一条寻路路径。路径只是大概的路径点集合，不能直接用于寻路，每段的详细路径点需要调用onStop(Vector3 position)获得，便于navmesh的分块管理
        /// <param name="curPos">  当前的位置</param>
        /// <param name="destPos">  目标位置</param>
        private bool NavUpdatePath(Vector3 curPos, Vector3 destPos)
        {
            //LogHelper.Log("NavPathUpdate ", curPos.ToString(), " to ", destPos.ToString());
            var pathFinder = PathFinder.Instance;

            mPath.Clear();
            mPathIndex = 0;
            m_lastPathDest = null;
            //float fDelta = (mDestPos - destPos).magnitude;
            //if (fDelta > 1.0f)
            {
                var curNavMeshInfo = pathFinder.GetNavMeshInfo(curPos);
                //计算目的地属于哪一个navmesh
                mDestNavMeshInfo = pathFinder.GetNavMeshInfo(destPos);

                bool ret = (curNavMeshInfo == null || mDestNavMeshInfo == null) ? mDestNavMeshInfo != null :
                    pathFinder.CalcPath(curPos, destPos, curNavMeshInfo, mDestNavMeshInfo, mPath);

                NavPortal curDest = new NavPortal();
                curDest.type = PortalType.DirectTo;
                curDest.center = destPos;
                curDest.fromGraph = null;
                curDest.toPortal = null;
#if !DEBUG
                mPath.Add(curDest);
#else
                curDest.bounds = new Bounds(destPos, Vector3.one);
                mPath.Add(curDest);
                if (!ret)
                {
                    NavPortal start = new NavPortal();
                    start.type = PortalType.DirectTo;
                    start.center = curPos;
                    start.bounds = new Bounds(curPos, Vector3.one);
                    start.fromGraph = null;
                    start.toPortal = null;
                    mPath.Add(start);
                }
#endif

                return ret;
            }
        }

        public override bool FindMainPath(Vector3 start, Vector3 dest, List<Vector3> path)
        {
            return false;
        }
        /// 计算一条寻路路径。路径只是大概的路径点集合，不能直接用于寻路，每段的详细路径点需要调用onStop(Vector3 position)获得，便于navmesh的分块管理
        /// <param name="curPos">  当前的位置</param>
        /// <param name="destPos">  目标位置</param>
        public override bool PathUpdate(Vector3 curPos, Vector3 destPos)
        {
            //LogHelper.Log("PFA:PathUpdate ", curPos.ToString(), "-", destPos.ToString());
            var pathFinder = PathFinder.Instance;
            curPos = pathFinder.GetRealNavMeshPos(curPos, false, 0, 3);
            //LogHelper.Log("PFA:PathUpdate cur ", curPos.ToString());
            destPos = pathFinder.GetRealNavMeshPos(destPos, true, 30);

            mMainPath.Clear();
            //大于20m 才走主路径寻路
            if((curPos-destPos).magnitude>20.0f)
                pathFinder.mainPath?.FindPath(curPos, destPos, mMainPath);

            mDestPos = destPos;
            if (mMainPath.Count > 0)
            {
                //LogHelper.Log("MainPath found ", mMainPath.Count.ToString());
                //for (int i = 0; i < mMainPath.Count; i++)
                //{
                //    var s = mMainPath[i];
                //    LogHelper.Log("Step ", s.path.positions[s.start].ToString(), "-", s.path.positions[s.end].ToString());
                //}
                mMainProgress = 0;
                mMainIndex = 0;
                var p = mMainPath[mMainIndex];
                var start = p.path.GetPointPercent(p.start);
                var end = p.path.GetPointPercent(p.end);
                var c = p.path.GetClosestPoint(curPos, start, end);
                destPos = p.path.GetPoint(c);
                destPos = pathFinder.GetRealNavMeshPos(destPos, true, 10);
            }

            return NavUpdatePath(curPos, destPos);
        }

        /// 走到当前目标点时调用该函数将规划下一条寻路路径
        /// 当目标点navmesh未曾加载时，调用PathUpdate得到的路径只是一个大概的路径点集合，每个路径点之间的详细路径还是需要在navmesh加载后再计算得出的。这个函数作用就是到达了当前路径点后，等待navmesh加载并规划详细的路径图，开始下一个阶段的寻路
        /// 如果起始点经历的navmesh块都已经加载了，该函数就退化为一个简单的调用navmesh寻路的函数
        /// <param name="position">  当前的位置</param>
        public override Vector3[] onStop(Vector3 position)
        {
            //LogHelper.Log("PFA:onStop ", position.ToString());
            int count = mPath.Count;
            if(count > 0)
            {
                //计算通向下一个partal的合理路径
                var curPortal = mPath[mPathIndex];

                Vector3 startPosition;
                if (m_lastPathDest.HasValue)
                    startPosition = m_lastPathDest.Value;
                else if (mPathIndex > 0)
                {
                    var portal = mPath[mPathIndex - 1];
                    startPosition = (portal.toPortal != null ? portal.toPortal : portal).center;
                }
                else startPosition = PathFinder.Instance.GetRealNavMeshPos(position, true, 30.0f);
                m_lastPathDest = null;
				
                var targetPosition = curPortal.center;
                switch (curPortal.type)
                {
                    case PortalType.DirectTo:
                    case PortalType.DownCliff:
                        mTempPath[0] = startPosition;
                        mTempPath[1] = targetPosition;
                        //LogHelper.Log("onStop Direct");
                        //for (int i = 0; i < mTempPath.Length; i++)
                        //    LogHelper.Log("DD ", mTempPath[i].ToString());
                        if (++mPathIndex >= count)
                        {
                            //最后一个navMesh块了，清理
                            mPath.Clear();
                            mPathIndex = 0;
                            m_lastPathDest = null;
                            //LogHelper.Log("PFA:onStop DD Clear");
                        }
                        return mTempPath;
                    case PortalType.NavSearch:
                        targetPosition = PathFinder.Instance.GetRealNavMeshPos(targetPosition, true, 300.0f);
                        NavUpdatePath(startPosition, targetPosition);
                        count = mPath.Count;
                        if (count > 0)
                        {
                            mPathIndex = 0;
                            curPortal = mPath[0];
                            targetPosition = curPortal.center;
                        }
                        break;
                    default:
                        if (mPathIndex + 1 < count)
                        {
                            var nextPortal = mPath[mPathIndex + 1];
                            var target = PathFinder.Instance.GetRealNavMeshPos(nextPortal.center);
                            if (NavMesh.CalculatePath(startPosition, target, 1, NMPath))
                            {
                                var nbCorners = NMPath.corners.Length;
                                var distance = (target - targetPosition).magnitude;
                                var last = target;
                                while (nbCorners > 1)
                                {
                                    var p = NMPath.corners[nbCorners - 1];
                                    var d = (last - p).magnitude;
                                    if (d > distance) break;
                                    nbCorners--;
                                    distance -= d;
                                    last = p;
                                }
                                var ret = new Vector3[nbCorners];
                                for (int i = 0; i < nbCorners; i++)
                                {
                                    ret[i] = NMPath.corners[i];
                                }
                                m_lastPathDest = ret[nbCorners - 1];
                                mPathIndex++;
    	                    	//LogHelper.Log("onStop NextTarget");
	                        	//for (int i = 0; i < ret.Length; i++)
                        		//    LogHelper.Log("NT ", ret[i].ToString());
                                return ret;
                            }
                        }
                        break;
                }

                //计算下一段可能的路径
                targetPosition = PathFinder.Instance.GetRealNavMeshPos(targetPosition);
                NavMesh.CalculatePath(startPosition, targetPosition, 1, NMPath);

                Vector3[] tmpPath;
                switch (NMPath.status)
                {
                    default:
                    case NavMeshPathStatus.PathComplete:
                        tmpPath = NMPath.corners;
                        break;
                    case NavMeshPathStatus.PathPartial:
						if (mPathIndex == 0)
						{
	                        var nbFirst = NMPath.corners.Length;
                            var first = NMPath.corners;
	                        var path = new List<Vector3>(8);
	                        var srcPos = first[nbFirst - 1];
	                        for (int i = 0; i < 10; i++)
	                        {
	                            NMPath.ClearCorners();
                                srcPos = PathFinder.Instance.GetRealNavMeshPos(srcPos);        
                                targetPosition = PathFinder.Instance.GetRealNavMeshPos(targetPosition);
                                NavMesh.CalculatePath(srcPos, targetPosition, 1, NMPath);
	                            var nbCorners = NMPath.corners.Length;
	                            for (int j = 0; j < nbCorners; j++)
	                                path.Add(NMPath.corners[j]);
	                            if (NMPath.status != NavMeshPathStatus.PathPartial)
	                                break;
	                            var lastPos = path[path.Count - 1];
	                            if (lastPos == srcPos)
	                                srcPos += (targetPosition - srcPos).normalized * 0.3f;
	                            else srcPos = lastPos;
	                        }
	                        tmpPath = new Vector3[nbFirst + path.Count];
                            first.CopyTo(tmpPath, 0);
                            path.CopyTo(tmpPath, nbFirst);
						}
						else
						{
                            var portal = mPath[mPathIndex - 1];
                            if (portal.toPortal != null) portal = portal.toPortal;
                            var srcPos = portal.bounds.center;
                            
                            var step = (targetPosition - srcPos).normalized * 0.3f;;
							for (int i = 0; i < 10; i++)
							{
                                srcPos = PathFinder.Instance.GetRealNavMeshPos(srcPos);
                                targetPosition = PathFinder.Instance.GetRealNavMeshPos(targetPosition);
                                NMPath.ClearCorners();
                                NavMesh.CalculatePath(srcPos, targetPosition, 1, NMPath);
                                if (NMPath.status == NavMeshPathStatus.PathComplete)
                                    break;
                                srcPos += step;
                                targetPosition += step;                   
                            }
                            tmpPath = NMPath.corners;
                        }
                        break;
                    case NavMeshPathStatus.PathInvalid:
                        LogHelper.LogError("PFA onStop PathInvalid");
                        // 不应该啊。不管怎样，走着
                        tmpPath = new Vector3[2];
                        tmpPath[0] = startPosition;
                        tmpPath[1] = targetPosition;
                        break;
                }

                if (++mPathIndex >= count)
                {
                    //最后一个navMesh块了，清理
                    mPath.Clear();
                    mPathIndex = 0;
                    m_lastPathDest = null;
                    //LogHelper.Log("PFA:onStop Clear");
                }


#if UNITY_EDITOR
                navPath = tmpPath;
#endif
                //LogHelper.Log("onStop PathFind");
                //for (int i = 0; i < tmpPath.Length; i++)
                //    LogHelper.Log("PF ", tmpPath[i].ToString());
                return tmpPath;
            }
            else if (mMainPath.Count > 0)
            {
                var p = mMainPath[mMainIndex];
                var progress = mMainProgress;
                if (progress <= 0)
                    progress = p.path.GetClosestPoint(position);
                var start = p.path.GetPoint(progress);
                const int Steps = 8;
                var num = p.path.positions.Length - 1;
                Debug.Assert(num > 0);
                var step = 1.0 / num;
                var end = p.path.GetPointPercent(p.end);
                var finish = false;
                if (progress < end)
                {
                    if (progress + step >= end)
                        finish = true;
                }
                else
                {
                    step = -step;
                    if (progress + step <= end)
                        finish = true;
                }
                if (finish) step = end - progress;
                step /= Steps;
                var next = progress + step;
                var pos = p.path.GetPoint(next);
                var dist = (pos - start).magnitude;
                const float MaxStepDistance = 5;
                const float MinStepDistance = 0.5f;
                var steps = Steps;
                if (dist > MaxStepDistance)
                    step = step * MaxStepDistance / dist;
                else if (dist < MinStepDistance)
                {
                    step *= Steps;
                    steps = 1;
                }
                var pathFinder = PathFinder.Instance;
                var retPath = new Vector3[steps];
                next = progress;
                for (int i = 0; i < steps; i++)
                {
                    next += step;
                    retPath[i] = pathFinder.GetRealNavMeshPos(p.path.GetPoint(next));
                }
                if (finish)
                {
                    if (++mMainIndex >= mMainPath.Count)
                    {
                        mMainPath.Clear();
                        mMainIndex = 0;
                        //LogHelper.Log("PFA:onStop MP Clear");
                        NavUpdatePath((steps > 0 ? retPath[steps - 1] : position), mDestPos);
                    }
                    else
                    {
                        mMainProgress = 0;
                    }
                }
                else mMainProgress = next;
                //LogHelper.Log("onStop MainPath");
                //for (int i = 0; i < retPath.Length; i++)
                //    LogHelper.Log("MP ", retPath[i].ToString());
                return retPath;
            }

            return null;
        }

        public override Vector3 DestPos()
        {
            return mDestPos;
        }
        #endregion

        #region 原先的寻路方式

        //更新寻路目标的位置
        //public void PathUpdate(NavMeshAgent agent, Vector3 curPos, Vector3 destPos)
        //{
        //    if (mPathFinder == null || !mPathFinder.isValid())
        //    {
        //        return;
        //    }

        //    float fDelta = (mDestPos - destPos).magnitude;
        //    if (fDelta > 1.0f)
        //    {
        //        mDestPos = destPos;

        //        //计算目的地属于哪一个navmesh
        //        mDestNavMeshInfo = mPathFinder.GetNavMeshInfo(destPos);
        //        if (mDestNavMeshInfo == null)
        //            return;

        //        if (mDestNavMeshInfo.bLoaded)
        //        {
        //            agent.destination = destPos;
        //            return;
        //        }

        //        var curNavMeshInfo = mPathFinder.GetNavMeshInfo(curPos);
        //        if (curNavMeshInfo == null)
        //        {
        //            return;
        //        }

        //        mPathFinder.CalcPath(curPos, destPos, curNavMeshInfo, mDestNavMeshInfo, mPath);
        //    }

        //    if (mPath.Count > 0)
        //    {
        //        NavPortal curDestPortal = mPath[0];

        //        var agentDestPos = agent.destination;
        //        if ((curDestPortal.spos - agentDestPos).magnitude > 5.0f)
        //        {
        //            agent.destination = curDestPortal.spos;
        //        }

        //        if ((curDestPortal.spos - curPos).magnitude < 5.0f)
        //        {
        //            mPath.RemoveAt(0);
        //        }
        //    }
        //    else
        //    {
        //        agent.destination = destPos;
        //    }
        //}
        #endregion
    }


}//name space
