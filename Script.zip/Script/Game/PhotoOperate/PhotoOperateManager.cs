using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using System.Net;
using System.Text;
using System;
using Bokura;

/// <summary>
/// �½� GallerySDKCallBack �����ر��ű�;
/// </summary>
public class PhotoOperateManager : MonoBehaviour
{
    private Texture2D m_texture;

    private int m_flagId = 0;//1-��������;

    public static PhotoOperateManager ResetPhotoOperateManager(GameObject go, int flagId)
    {
        go.name = "GallerySDKCallBack";
        PhotoOperateManager po = go.GetComponent<PhotoOperateManager>();
        if (po == null)
        {
            po = go.AddComponent<PhotoOperateManager>();
        }

        po.m_flagId = flagId;

        return po;
    }

    public Texture2D GetCurrTexture()
    {
        return m_texture;
    }

    public void Open()
    {
#if (UNITY_EDITOR || UNITY_STANDALONE_WIN)
        OpenDialogFile pth = new OpenDialogFile();
        pth.structSize = Marshal.SizeOf(pth);
        pth.filter = "ͼƬ(*.png;*jpg)\0*.png;*.jpg";
        pth.file = new string(new char[512]);
        pth.maxFile = pth.file.Length;
        pth.fileTitle = new string(new char[64]);
        pth.maxFileTitle = pth.fileTitle.Length;
        pth.title = "ѡ��ͼƬ";
        pth.defExt = "txt";
        pth.flags = 0x00080000 | 0x00001000 | 0x00000800 | 0x00000200 | 0x00000008;

        if (GetOpenFileName(pth))
        {
            StartCoroutine(GetImageByPath(pth.file));
        }

#elif UNITY_ANDROID 
        if (m_gallerySdk == null)
        {
            using (AndroidJavaClass Player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            {
                m_unityActivity = Player.GetStatic<AndroidJavaObject>("currentActivity");
                m_gallerySdk = new AndroidJavaClass("com.unity.gallerylibrary.GalleryManager");
            }
        }

        using (AndroidJavaObject intentObject = new AndroidJavaObject("android.content.Intent", m_unityActivity, m_gallerySdk))
        {
            intentObject.Call<AndroidJavaObject>("putExtra", "type", "openGallery");
            intentObject.Call<AndroidJavaObject>("putExtra", "UnityPersistentDataPath", Application.persistentDataPath);
            intentObject.Call<AndroidJavaObject>("putExtra", "isCutPicture", true);
            m_unityActivity.Call("startActivity", intentObject);
        }
#elif UNITY_IPHONE
        _iosOpenPhotoLibrary_allowsEditing();
#endif
    }

#if (UNITY_EDITOR || UNITY_STANDALONE_WIN)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public class OpenDialogFile
    {
        public int structSize = 0;
        public IntPtr dlgOwner = IntPtr.Zero;
        public IntPtr instance = IntPtr.Zero;
        public String filter = null;
        public String customFilter = null;
        public int maxCustFilter = 0;
        public int filterIndex = 0;
        public String file = null;
        public int maxFile = 0;
        public String fileTitle = null;
        public int maxFileTitle = 0;
        public String initialDir = null;
        public String title = null;
        public int flags = 0;
        public short fileOffset = 0;
        public short fileExtension = 0;
        public String defExt = null;
        public IntPtr custData = IntPtr.Zero;
        public IntPtr hook = IntPtr.Zero;
        public String templateName = null;
        public IntPtr reservedPtr = IntPtr.Zero;
        public int reservedInt = 0;
        public int flagsEx = 0;
    }

    [DllImport("Comdlg32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]
    public static extern bool GetOpenFileName([In, Out] OpenDialogFile ofn);
#elif UNITY_ANDROID
    private AndroidJavaObject m_unityActivity;
    private AndroidJavaClass m_gallerySdk;

    /// <summary>
    /// Android �ص�����;
    /// </summary>
    /// <param name="path"></param>
    public void GetImagePath(string path)
    {
        StartCoroutine(GetImageByPath(path));
    }
#elif UNITY_IPHONE
    [DllImport("__Internal")]
	private static extern void _iosOpenPhotoLibrary();
	[DllImport("__Internal")]
	private static extern void _iosOpenPhotoAlbums();
	[DllImport("__Internal")]
	private static extern void _iosOpenCamera();
	[DllImport("__Internal")]
	private static extern void _iosOpenPhotoLibrary_allowsEditing();
	[DllImport("__Internal")]
	private static extern void _iosOpenPhotoAlbums_allowsEditing();
	[DllImport("__Internal")]
	private static extern void _iosOpenCamera_allowsEditing();
	[DllImport("__Internal")]
	private static extern void _iosSaveImageToPhotosAlbum(string readAddr);

    /// <summary>
    /// iOS �ص�����;
    /// </summary>
    /// <param name="base64"></param>
    public void PickImageCallBack_Base64(string base64)
	{
		Texture2D tex = new Texture2D (4, 4, TextureFormat.ARGB32, false);
		try
		{
			byte[] bytes = System.Convert.FromBase64String(base64);
            tex.LoadImage(bytes, false);
            m_texture = tex;
            
            IEventDispatchManager.Instance.Invoke(GlobalEventID.PHOTO_CALLBACK, m_flagId);
        }
		catch(System.Exception ex)
		{
            throw ex;
		}
	}
#endif

    private IEnumerator GetImageByPath(string path)
    {
        yield return null;

        StringBuilder sb = new StringBuilder();
        sb.Append("file://");
        sb.Append(path);

        UnityWebRequest request = UnityWebRequest.Get(sb.ToString());
        DownloadHandlerTexture dTexture = new DownloadHandlerTexture(true);
        request.downloadHandler = dTexture;

        yield return request.SendWebRequest();

        if (request.isDone)
        {
            if (!(request.isHttpError || request.isNetworkError))
            {
                m_texture = dTexture.texture;

                IEventDispatchManager.Instance.Invoke(GlobalEventID.PHOTO_CALLBACK, m_flagId);
            }
        }

        dTexture.Dispose();
        request.Dispose();
    }

    private void OnDestroy()
    {
#if (UNITY_EDITOR || UNITY_STANDALONE_WIN)
#elif UNITY_ANDROID
        if (m_gallerySdk != null)
        {
            m_gallerySdk.Dispose();

            m_gallerySdk = null;
        }
#elif UNITY_IPHONE
#endif
    }
}
