﻿namespace Bokura
{
    public class PlayerInfoData
    {
        private ulong m_Id = 0;
        private string m_Name = string.Empty;
        private ushort m_Level = 0;
        private swm.CareerType m_career = swm.CareerType.Unknown;
        private swm.CareerSex m_Sex = swm.CareerSex.Unknown;
        private ulong m_SociatyId = 0;
        private string m_SociatyName;
        private ulong m_NextGetInfoTime = 0;
        private ProfessionTableBase? m_ProfessionTableBaseConfig = null;

        public ulong NextGetInfoTime
        {
            get
            {
                return m_NextGetInfoTime;
            }
            set
            {
                m_NextGetInfoTime = value;
            }
        }

        public string Name
        {
            get
            {
                return m_Name;
            }
            set
            {
                m_Name = value;
            }
           
        }
        public ulong ID
        {
            get
            {
                return m_Id;
            }
            set
            {
                m_Id = value;
            }
        }

        public ushort Level
        {
            get
            {
                return m_Level;
            }
            set
            {
                m_Level = value;
            }
        }

        public swm.CareerType Career
        {
            get
            {
                return m_career;
            }
            set
            {
                if (null == m_ProfessionTableBaseConfig || m_career != value)
                {
                    m_ProfessionTableBaseConfig = ProfessionTableManager.GetData((int)value);
                }
                m_career = value;
            }
        }

        public ProfessionTableBase? ProfessionTableBaseConfig
        {
            get
            {
                return m_ProfessionTableBaseConfig;
            }
        }



        public string headIcon
        {
            get
            {
                if (m_ProfessionTableBaseConfig.HasValue)
                    return m_ProfessionTableBaseConfig.Value.headicon;
                else
                    return string.Empty;
            }
        }



        public string careerIcon
        {
            get
            {
                if (m_ProfessionTableBaseConfig.HasValue)
                    return m_ProfessionTableBaseConfig.Value.icon;
                else
                    return string.Empty;
            }
        }



        public string careerName
        {
            get
            {
                if (m_ProfessionTableBaseConfig.HasValue)
                    return m_ProfessionTableBaseConfig.Value.name;
                else
                    return string.Empty;
            }
        }



        public swm.CareerSex Sex
        {
            get
            {
                return m_Sex;
            }
            set
            {
                m_Sex = value;
            }
        }

        public ulong SociatyId
        {
            get { return m_SociatyId; }
            set { m_SociatyId = value; }
        }

        public string SociatyName
        {
            get { return m_SociatyName; }
            set { m_SociatyName = value; }
        }

        /// <summary>
        /// 是否加入仙门
        /// </summary>
        /// <returns></returns>
        public bool HasJoinSociaty()
        {
            return (m_SociatyId != 0);
        }

        /// <summary>
        /// 检查是不是已经过了限定时间
        /// </summary>
        /// <returns></returns>
        public bool CheckIsOverTime()
        {
            return GameScene.Instance.GetServerTime() > m_NextGetInfoTime;
        }

        public void RefreshData(swm.UserShowInfo _info)
        {
            ID                  = _info.charid;
            Name                = _info.name;
            Level               = _info.level;
            Career              = _info.career;
            Sex                 = _info.sex;
            m_SociatyId         = _info.septid;
            m_SociatyName       = _info.septname;
            m_NextGetInfoTime   = GameScene.Instance.GetServerTime() + PlayerInfoModel.InfoOverTime;

        }
    }
}
