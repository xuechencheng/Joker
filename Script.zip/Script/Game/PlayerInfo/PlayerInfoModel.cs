using System.Collections.Generic;

namespace Bokura
{
    /// <summary>
    /// 仅进入游戏后可用（无法获取跨区服信息，无法在角色创建和选择阶段使用）
    /// </summary>
    class PlayerInfoModel : ClientSingleton<PlayerInfoModel>
    {
        public static ulong InfoOverTime = 300000;//信息过期时间 暂定300秒 
        private Dictionary<ulong, PlayerInfoData> m_PlayerInfoNetDataList = new Dictionary<ulong, PlayerInfoData>(Bokura.ConstValue.kCap32);

        private List< PlayerInfoData> m_PlayerInfoNetDataPoolList = new List< PlayerInfoData>(Bokura.ConstValue.kCap32);

        public Event<ulong> onReceiveNetPlayerInfoEvent = new Event<ulong>();

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspUserShowInfo>(ProcRspUserInfoById);

            GameScene.Instance.onRefreshLevelAndExp.AddListener(procRefreshLevelAndExp);
        }

        private void procRefreshLevelAndExp(Entity _ety)
        {
            PlayerInfoData _data = GetPlayerInfoDataById(_ety.ThisID);
            if(_data != null)
            {
                _data.Level = (ushort)_ety.Level;
            }
        }

        public void Clear()
        {
            m_PlayerInfoNetDataPoolList.Clear();
            m_PlayerInfoNetDataList.Clear();
        }
        /// <summary>
        /// 通过id 获得玩家信息
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public PlayerInfoData GetPlayerInfoDataById(ulong _id)
        {
            PlayerInfoData _data = null;
            if(m_PlayerInfoNetDataList.TryGetValue(_id,out _data))
            {
                return _data;
            }
            return _data;
        }

        /// <summary>
        /// 移除 玩家信息
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public bool RemovePlayerInfoDataById(ulong _id)
        {
            PlayerInfoData _data = null;
            if (!m_PlayerInfoNetDataList.TryGetValue(_id, out _data))
            {
                return false;
            }
            m_PlayerInfoNetDataPoolList.Add(_data);
            return m_PlayerInfoNetDataList.Remove(_id);
        }

        /// <summary>
        /// 从池子里拿一个空闲的
        /// </summary>
        /// <returns></returns>
        private PlayerInfoData GetInfoDataFromPool()
        {
            PlayerInfoData _data = null;
            if (m_PlayerInfoNetDataPoolList.Count>0)
            {
                _data = m_PlayerInfoNetDataPoolList[0];
                m_PlayerInfoNetDataPoolList.RemoveAt(0);
            }
            else
            {
                _data = new PlayerInfoData();
            }

            return _data;
        }

        /// <summary>
        ///  增加或者更新一条数据
        /// </summary>
        /// <param name="_info"></param>
        /// <returns></returns>
        private PlayerInfoData AddPlayerInfo(swm.UserShowInfo _info)
        {
            PlayerInfoData _data = GetPlayerInfoDataById(_info.charid);
            if(null == _data)
            {
                //没有 就新增
                _data = GetInfoDataFromPool();
                _data.RefreshData(_info);
                m_PlayerInfoNetDataList[_info.charid] = _data;
            }
            else
            {
                //有了 只是刷新数据
                _data.RefreshData(_info);
            }
            onReceiveNetPlayerInfoEvent.Invoke(_info.charid);
            return _data;
        }

        /// <summary>
        /// 接收玩家信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspUserInfoById(swm.RspUserShowInfo _msg)
        {
            if(_msg.ok)
            {
                AddPlayerInfo(_msg.data.Value);
            }


//             if( null != _msg.infos && _msg.infos.Count>0 )
//             {
//                 for(int i=0;i< _msg.infos.Count;i++)
//                 {
//                     x2m.UserBaseInfo _data = _msg.infos[i];
//                     AddPlayerInfo(_data);
//                 }
//             }
        }

        /// <summary>
        /// 发送 请求玩家信息
        /// </summary>
        /// <param name="_id"></param>
        public void SendReqPlayerInfo(ulong _id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqUserShowInfo.StartReqUserShowInfo(fbb);
            swm.ReqUserShowInfo.AddCharid(fbb, _id);
            var msg = swm.ReqUserShowInfo.EndReqUserShowInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUserShowInfo.HashID, fbb);
        }
     }
}
