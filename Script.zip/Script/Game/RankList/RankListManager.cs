﻿using System.Collections.Generic;
using FlatBuffers;
using LitJson;
using swm;
using Bokura;



namespace Bokura
{
    /// <summary>
    /// 排行榜数据层
    /// </summary>
	public class RankListManager: ClientSingleton<RankListManager>
	{
        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRankMainInfos>(ResponseMainRankInfos_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRankSelfInfo>(ResponseSelfRankInfo_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRankArenaInfo>(ResponseUserArenaInfo_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspUserAvatarData>(ResponseUserAvatarData_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspUserWeaponData>(ResponseUserWeaponData_SC);
        }



        /// <summary>
        /// 重置数据
        /// </summary>
        [XLua.BlackList]
        public void Clear()
        {
            m_SelfRankInfos?.Clear();
            m_PowerRankInfos?.Clear();
            m_WeaponRankInfos?.Clear();
            m_FlowerRankInfos?.Clear();
            m_PvP1RankInfos?.Clear();
            m_PvP3RankInfos?.Clear();
            m_PvP5RankInfos?.Clear();
            m_SeptRankInfos?.Clear();
            m_HotRankInfos?.Clear();
            m_AvatarDataCaches?.Clear();
            m_WeaponAttrsCaches?.Clear();
            m_PvP1InfoCaches?.Clear();
            m_PvP3InfoCaches?.Clear();
            m_PvP5InfoCaches?.Clear();
        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
            string tRankConfig = TableManager.LoadFileTable("rank_list.json", "/Datas/");
            JsonData tJsonData = JsonMapper.ToObject(tRankConfig);
            if (tJsonData.IsObject)
                m_Config = JsonMapper.ToObject<RankConfig>(tJsonData.ToJson());
            else
                m_Config = default(RankConfig);

            m_PanelId = AvatarShowManager.Instance.GetPanelId("ui_panel_rank");
        }



        /// <summary>
        /// UI界面的id
        /// </summary>
        private int m_PanelId = 0;

        /// <summary>
        /// 记录的panel id
        /// </summary>
        private int m_RecordAvatarPanelId = -1;


        private RankConfig m_Config;

        /// <summary>
        /// 详细介绍说明内容
        /// </summary>
        public string introduce { get { return m_Config.introduce; } }



        private const int kCap = 51;



        /// <summary>
        /// 存放自己的排行榜信息
        /// </summary>
        private Dictionary<int, CommonRankInfo> m_SelfRankInfos = new Dictionary<int, CommonRankInfo>(Const.kCap8);



        #region 战力排行榜

        /// <summary>
        /// 存放战力排行信息
        /// </summary>
        private List<CommonRankInfo> m_PowerRankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 战力排行信息的数量（有可能不满）
        /// </summary>
        public int powerRankCount { get { return m_PowerRankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的战力排行信息
        /// </summary>
        public CommonRankInfo GetPowerRankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < powerRankCount) return m_PowerRankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的战力排行榜数据
        /// </summary>
        private void ResponsePowerRankInfos(RspRankMainInfos msg)
        {
            m_PowerRankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_PowerRankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion



        #region 神兵排行榜

        /// <summary>
        /// 存放神兵排行信息
        /// </summary>
        private List<CommonRankInfo> m_WeaponRankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 神兵排行信息的数量（有可能不满）
        /// </summary>
        public int weaponRankCount { get { return m_WeaponRankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的神兵排行信息
        /// </summary>
        public CommonRankInfo GetWeaponRankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < weaponRankCount) return m_WeaponRankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的神兵排行榜数据
        /// </summary>
        private void ResponseWeaponRankInfos(RspRankMainInfos msg)
        {
            m_WeaponRankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_WeaponRankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion



        #region 鲜花排行榜

        /// <summary>
        /// 存放鲜花排行信息
        /// </summary>
        private List<CommonRankInfo> m_FlowerRankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 鲜花排行信息的数量（有可能不满）
        /// </summary>
        public int flowerRankCount { get { return m_FlowerRankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的鲜花排行信息
        /// </summary>
        public CommonRankInfo GetFlowerRankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < flowerRankCount) return m_FlowerRankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的鲜花排行榜数据
        /// </summary>
        private void ResponseFlowerRankInfos(RspRankMainInfos msg)
        {
            m_FlowerRankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_FlowerRankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion



        #region 1vs1排行榜

        /// <summary>
        /// 存放1vs1排行信息
        /// </summary>
        private List<CommonRankInfo> m_PvP1RankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 1vs1排行信息的数量（有可能不满）
        /// </summary>
        public int pvp1RankCount { get { return m_PvP1RankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的1vs1排行信息
        /// </summary>
        public CommonRankInfo GetPvP1RankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < pvp1RankCount) return m_PvP1RankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的1vs1排行榜数据
        /// </summary>
        private void ResponsePvP1RankInfos(RspRankMainInfos msg)
        {
            m_PvP1RankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_PvP1RankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion



        #region 3vs3排行榜

        /// <summary>
        /// 存放3vs3排行信息
        /// </summary>
        private List<CommonRankInfo> m_PvP3RankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 3vs3排行信息的数量（有可能不满）
        /// </summary>
        public int pvp3RankCount { get { return m_PvP3RankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的3vs3排行信息
        /// </summary>
        public CommonRankInfo GetPvP3RankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < pvp3RankCount) return m_PvP3RankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的3vs3排行榜数据
        /// </summary>
        private void ResponsePvP3RankInfos(RspRankMainInfos msg)
        {
            m_PvP3RankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_PvP3RankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion



        #region 5vs5排行榜

        /// <summary>
        /// 存放5vs5排行信息
        /// </summary>
        private List<CommonRankInfo> m_PvP5RankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 5vs5排行信息的数量（有可能不满）
        /// </summary>
        public int pvp5RankCount { get { return m_PvP5RankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的5vs5排行信息
        /// </summary>
        public CommonRankInfo GetPvP5RankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < pvp5RankCount) return m_PvP5RankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的5vs5排行榜数据
        /// </summary>
        private void ResponsePvP5RankInfos(RspRankMainInfos msg)
        {
            m_PvP5RankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_PvP5RankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion



        #region 帮会排行榜

        /// <summary>
        /// 存放帮会排行信息
        /// </summary>
        private List<CommonRankInfo> m_SeptRankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 帮会排行信息的数量（有可能不满）
        /// </summary>
        public int septRankCount { get { return m_SeptRankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的帮会排行信息
        /// </summary>
        public CommonRankInfo GetSeptRankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < septRankCount) return m_SeptRankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的帮会排行榜数据
        /// </summary>
        private void ResponseSeptRankInfos(RspRankMainInfos msg)
        {
            m_SeptRankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
            {
                CommonRankInfo info = new CommonRankInfo(msg.infos(tIdx));
                m_SeptRankInfos.Add(info);
            }
                
        }

        #endregion



        #region 空间热度排行榜

        /// <summary>
        /// 存放空间热度排行信息
        /// </summary>
        private List<CommonRankInfo> m_HotRankInfos = new List<CommonRankInfo>(kCap);



        /// <summary>
        /// 空间热度排行信息的数量（有可能不满）
        /// </summary>
        public int hotRankCount { get { return m_HotRankInfos.Count; } }



        /// <summary>
        /// 获取指定索引对应的空间热度排行信息
        /// </summary>
        public CommonRankInfo GetHotRankInfoByIndex(int idx)
        {
            if (idx >= 0 && idx < hotRankCount) return m_HotRankInfos[idx];
            return default(CommonRankInfo);
        }



        /// <summary>
        /// 保存服务器下发的空间热度排行榜数据
        /// </summary>
        private void ResponseHotRankInfos(RspRankMainInfos msg)
        {
            m_HotRankInfos.Clear();
            for (int tIdx = 0, tCount = msg.infosLength; tIdx < tCount; tIdx++)
                m_HotRankInfos.Add(new CommonRankInfo(msg.infos(tIdx)));
        }

        #endregion


        /// <summary>
        /// 缓存角色外观数据
        /// </summary>
        private Dictionary<ulong, UserAvatarData> m_AvatarDataCaches = new Dictionary<ulong, UserAvatarData>(Const.kCap4);

        /// <summary>
        /// 缓存神兵数据
        /// </summary>
        private Dictionary<ulong, ulong> m_WeaponDataCaches = new Dictionary<ulong, ulong>(Const.kCap4);



        /// <summary>
        /// 缓存神兵属性
        /// </summary>
        private Dictionary<ulong, ItemBase> m_WeaponAttrsCaches = new Dictionary<ulong, ItemBase>(kCap);



        /// <summary>
        /// 1v1竞技场信息缓存
        /// </summary>
        private Dictionary<ulong, RankArenaInfo> m_PvP1InfoCaches = new Dictionary<ulong, RankArenaInfo>(kCap);



        /// <summary>
        /// 3v3竞技场信息缓存
        /// </summary>
        private Dictionary<ulong, RankArenaInfo> m_PvP3InfoCaches = new Dictionary<ulong, RankArenaInfo>(kCap);



        /// <summary>
        /// 5v5竞技场信息缓存
        /// </summary>
        private Dictionary<ulong, RankArenaInfo> m_PvP5InfoCaches = new Dictionary<ulong, RankArenaInfo>(kCap);



        private GameEvent<int> m_OnRankInfosDataArrived = new GameEvent<int>();
        /// <summary>
        /// 服务器返回排行榜数据
        /// </summary>
        public GameEvent<int> onRankInfosDataArrived
        {
            get { return m_OnRankInfosDataArrived; }
        }



        private GameEvent<ulong> m_OnWeaponDataArrived = new GameEvent<ulong>();
        /// <summary>
        /// 服务器返回武器数据
        /// </summary>
        public GameEvent<ulong> onWeaponDataArrived
        {
            get { return m_OnWeaponDataArrived; }
        }



        private GameEvent<ulong> m_OnWeaponAttrsArrived = new GameEvent<ulong>();
        /// <summary>
        /// 服务器返回武器属性
        /// </summary>
        public GameEvent<ulong> onWeaponAttrsArrived
        {
            get { return m_OnWeaponAttrsArrived; }
        }



        private GameEvent<ulong> m_OnAvatarDataArrived = new GameEvent<ulong>();
        /// <summary>
        /// 服务器返回角色数据
        /// </summary>
        public GameEvent<ulong> onAvatarDataArrived
        {
            get { return m_OnAvatarDataArrived; }
        }



        private GameEvent<ulong, int> m_OnArenaInfoArrived = new GameEvent<ulong, int>();
        /// <summary>
        /// 服务器返回竞技场信息
        /// </summary>
        public GameEvent<ulong, int> onArenaInfoArrived
        {
            get { return m_OnArenaInfoArrived; }
        }


        /// <summary>
        /// 请求指定排行榜
        /// </summary>
        public void RequestRankInfos_CS(int rankType)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqRankInfos> tOffset = swm.ReqRankInfos.CreateReqRankInfos(tFBB, (swm.RankType)rankType);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRankInfos.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回排行榜数据
        /// </summary>
        private void ResponseMainRankInfos_SC(RspRankMainInfos msg)
        {
            switch (msg.rank_type)
            {
                case RankType.Power:
                    ResponsePowerRankInfos(msg);
                    break;
                case RankType.Weapon:
                    ResponseWeaponRankInfos(msg);
                    break;
                case RankType.Flower:
                    ResponseFlowerRankInfos(msg);
                    break;
                case RankType.PvP1:
                    ResponsePvP1RankInfos(msg);
                    break;
                case RankType.PvP3:
                    ResponsePvP3RankInfos(msg);
                    break;
                case RankType.PvP5:
                    ResponsePvP5RankInfos(msg);
                    break;
                case RankType.Sept:
                    ResponseSeptRankInfos(msg);
                    break;
                case RankType.Hot:
                    ResponseHotRankInfos(msg);
                    break;
            }
            if (msg.rank_type != RankType.None)
                m_OnRankInfosDataArrived.Invoke((int)msg.rank_type);
        }



        /// <summary>
        /// 服务器下发自己的排行榜数据(在主榜数据之前)
        /// </summary>
        private void ResponseSelfRankInfo_SC(RspRankSelfInfo msg)
        {
            int tType = (int)msg.rank_type;
            m_SelfRankInfos[tType] = new CommonRankInfo(msg.my_info);
        }



        /// <summary>
        /// 获取当前角色指定排行榜的数据
        /// </summary>
        public CommonRankInfo GetSelfRankInfo(int type)
        {
            CommonRankInfo tResult;
            if (!m_SelfRankInfos.TryGetValue(type, out tResult))
                tResult = default(CommonRankInfo);
            return tResult;
        }

        public void RequestUserAvatarData_CS(ulong charID, int panelid)
        {
            //如果已缓存，直接返回
            if (m_AvatarDataCaches.ContainsKey(charID))
            {
                m_OnAvatarDataArrived.Invoke(charID);
                return;
            }

            m_RecordAvatarPanelId = panelid;

            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqUserAvatarData> tOffset = swm.ReqUserAvatarData.CreateReqUserAvatarData(tFBB, charID);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUserAvatarData.HashID, tFBB);
        }

        /// <summary>
        /// 请求指定角色的模型数据
        /// </summary>
        public void RequestUserAvatarData_CS(ulong charID)
        {
            RequestUserAvatarData_CS(charID, m_PanelId);
        }

        /// <summary>
        /// 服务器返回角色的模型数据
        /// </summary>
        private void ResponseUserAvatarData_SC(RspUserAvatarData msg)
        {
            ulong tCharID = msg.char_id;

            FillUserAvatarData(msg, m_RecordAvatarPanelId);

            m_OnAvatarDataArrived.Invoke(tCharID);
        }

        [XLua.BlackList]
        public void FillUserAvatarData(RspUserAvatarData msg, int panelid)
        {
            ulong tCharID = msg.char_id;

            if (m_AvatarDataCaches.ContainsKey(tCharID))
                m_AvatarDataCaches[tCharID].Dispose();

            m_AvatarDataCaches[tCharID] = new UserAvatarData(msg, panelid);
        }

        /// <summary>
        /// 请求指定角色的武器数据
        /// </summary>
        public void RequestUserWeaponData_CS(ulong charID)
        {            
            //如果已缓存，直接返回
            if (m_WeaponDataCaches.ContainsKey(charID))
            {
                m_OnWeaponDataArrived.Invoke(charID);
                return;
            }

            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqUserWeaponData> tOffset = swm.ReqUserWeaponData.CreateReqUserWeaponData(tFBB, charID);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUserWeaponData.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回角色的武器数据
        /// </summary>
        private void ResponseUserWeaponData_SC(RspUserWeaponData msg)
        {
            ulong tCharID = msg.char_id;
            m_WeaponDataCaches[tCharID] = msg.weapon_id;
            m_OnWeaponDataArrived.Invoke(tCharID);
        }



        /// <summary>
        /// 请求指定角色的武器属性
        /// </summary>
        public void RequestUserWeaponAttrs_CS(ulong charID)
        {
            //如果已缓存，直接返回
            if (m_WeaponAttrsCaches.ContainsKey(charID))
            {
                m_OnWeaponAttrsArrived.Invoke(charID);
                return;
            }

        }



        /// <summary>
        /// 服务器返回角色的武器属性
        /// </summary>
        private void ResponseUserWeaponAttrs_SC(swm.RspQueryItem msg)
        {
            if (null != msg.item)
            {
                ItemTableBase? tConfig = ItemTableManager.GetData((int)msg.item.Value.baseid);
                if (tConfig.HasValue)
                {
                    ItemBase tItem = ItemFactory.Instance.CreateItem(tConfig.Value, msg.item.Value);
                    //CharID
                    m_WeaponAttrsCaches.Add(0, tItem);
                    m_OnWeaponAttrsArrived.Invoke(0);
                }
            }
        }



        /// <summary>
        /// 请求指定角色的竞技场信息
        /// </summary>
        public void RequestUserArenaInfo_CS(ulong id, int arenaType)
        {
            Dictionary<ulong, RankArenaInfo> tCaches = GetArenaInfoCacher((ArenaType)arenaType);
            //如果已缓存，直接返回
            if (tCaches != null && tCaches.ContainsKey(id))
            {
                m_OnArenaInfoArrived.Invoke(id, arenaType);
                return;
            }

            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqRankArenaInfo> tOffset = swm.ReqRankArenaInfo.CreateReqRankArenaInfo(tFBB, id, (ArenaType)arenaType);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRankArenaInfo.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回指定角色的竞技场信息
        /// </summary>
        private void ResponseUserArenaInfo_SC(swm.RspRankArenaInfo msg)
        {
            ulong tID = msg.id;
            ArenaType tType = msg.arena_type;
            Dictionary<ulong, RankArenaInfo> tCaches = GetArenaInfoCacher(tType);
            if (null != tCaches)
            {
                tCaches.Add(tID, new RankArenaInfo(msg));
                m_OnArenaInfoArrived.Invoke(tID, (int)tType);
            }
        }



        /// <summary>
        /// 获取指定类型的竞技场信息缓存器
        /// </summary>
        private Dictionary<ulong, RankArenaInfo> GetArenaInfoCacher(ArenaType arenaType)
        {
            Dictionary<ulong, RankArenaInfo> tCaches = null;
            switch (arenaType)
            {
                case ArenaType.ARENA_1VS1:
                    tCaches = m_PvP1InfoCaches;
                    break;
                case ArenaType.ARENA_3VS3:
                    tCaches = m_PvP3InfoCaches;
                    break;
            }
            return tCaches;
        }



        /// <summary>
        /// 获取神兵属性数据
        /// </summary>
        public ItemBase GetWeaponAttrs(ulong charID)
        {
            ItemBase tData = null;
            m_WeaponAttrsCaches.TryGetValue(charID, out tData);
            return tData;
        }



        /// <summary>
        /// 根据id获取角色Show
        /// </summary>
        public AvatarShow GetCharacterShow(ulong charID)
        {
            AvatarShow tShow = null;
            UserAvatarData tAvatarData;
            if(m_AvatarDataCaches.TryGetValue(charID, out tAvatarData))
                tShow = AvatarShowManager.Instance.GetAvatarShow(tAvatarData);
            return tShow;
        }



        /// <summary>
        /// 根据id获取武器Show
        /// </summary>
        public AvatarShow GetWeaponShow(ulong charID)
        {
            AvatarShow tShow = null;
            ulong tWeaponID;
            if (m_WeaponDataCaches.TryGetValue(charID, out tWeaponID))
            {
                //TODO:暂时没有神兵
                WeaponAvatarData tWeaponData = new WeaponAvatarData(1, m_PanelId);
                tShow = AvatarShowManager.Instance.GetAvatarShow(tWeaponData);
                tWeaponData.Dispose();
            }
            return tShow;
        }



        /// <summary>
        /// 回收Show
        /// </summary>
        public void RecycleShow(AvatarShow show)
        {
            AvatarShowManager.Instance.RecycleAvatarShow(show);
        }



        /// <summary>
        /// 获取指定类型排行榜的指标名称
        /// </summary>
        public string GetScoreTitleName(int rankType)
        {
            RankType tType = (RankType)rankType;
            string tName = null;
            switch (tType)
            {
                case RankType.Power:
                    tName = m_Config.powerTitle;
                    break;
                case RankType.Weapon:
                    tName = m_Config.weaponTitle;
                    break;
                case RankType.Flower:
                    tName = m_Config.flowerTitle;
                    break;
                case RankType.PvP1:
                    tName = m_Config.pvp1Title;
                    break;
                case RankType.PvP3:
                    tName = m_Config.pvp3Title;
                    break;
                case RankType.PvP5:
                    tName = m_Config.pvp5Title;
                    break;
                case RankType.Sept:
                    tName = m_Config.septTitle;
                    break;
                case RankType.Hot:
                    tName = m_Config.hotTitle;
                    break;
            }
            if (string.IsNullOrEmpty(tName))
                tName = "积分";
            return tName;
        }



        /// <summary>
        /// 根据类型和id获取竞技场信息
        /// </summary>
        public RankArenaInfo GetArenaInfo(int arenaType, ulong id)
        {
            ArenaType tType = (ArenaType)arenaType;
            Dictionary<ulong, RankArenaInfo> tCaches = null;
            switch (tType)
            {
                case ArenaType.ARENA_1VS1:
                    tCaches = m_PvP1InfoCaches;
                    break;
                case ArenaType.ARENA_3VS3:
                    tCaches = m_PvP3InfoCaches;
                    break;
            }
            RankArenaInfo tResult;
            if (null == tCaches || !tCaches.TryGetValue(id, out tResult))
                tResult = default(RankArenaInfo);
            return tResult;
        }

        /// <summary>
        /// 移除某个avatar cache data
        /// </summary>
        /// <param name="charid"></param>
        public void RemoveAvatarCacheData(ulong charid)
        {
            if (!m_AvatarDataCaches.ContainsKey(charid))
                return;

            UserAvatarData useravatardata = m_AvatarDataCaches[charid];
            useravatardata.Dispose();
            m_AvatarDataCaches.Remove(charid);
        }
         
        /// <summary>
        /// 当关闭排行榜时，清空缓存数据
        /// </summary>
        public void ClearCacheDatas()
        {
            foreach (var tPair in m_AvatarDataCaches)
                tPair.Value.Dispose();
            m_AvatarDataCaches.Clear();
            m_WeaponDataCaches.Clear();
            m_WeaponAttrsCaches.Clear();
            m_PvP1InfoCaches.Clear();
            m_PvP3InfoCaches.Clear();
            m_PvP5InfoCaches.Clear();
        }
    }



    public struct RankConfig
    {
        /// <summary>
        /// 排行榜简介
        /// </summary>
        public string introduce;
        /// <summary>
        /// 战力排行榜的指标名称
        /// </summary>
        public string powerTitle;
        public string weaponTitle;
        public string flowerTitle;
        public string pvp1Title;
        public string pvp3Title;
        public string pvp5Title;
        public string septTitle;
        public string hotTitle;
    }



    /// <summary>
    /// 战力/神兵/鲜花/热度排行榜数据
    /// </summary>
    public struct CommonRankInfo
    {
        /// <summary>
        /// 排行
        /// </summary>
        public uint rank;
        /// <summary>
        /// 角色id/帮会id/战队id
        /// </summary>
        public ulong id;
        /// <summary>
        /// 角色姓名/帮会名称
        /// </summary>
        public string name;
        /// <summary>
        /// （主要分数）个人战力/武器评分/鲜花数量/热度值/帮会战力/大段
        /// </summary>
        public ulong score;
        /// <summary>
        /// （次要分数）竞技小段
        /// </summary>
        public ulong score2;
        /// <summary>
        /// （第三分数）竞技星星
        /// </summary>
        public ulong score3;



        public CommonRankInfo(RankInfo? rInfo)
        {
            if(rInfo.HasValue)
            {
                RankInfo tValue = rInfo.Value;
                this.rank = tValue.rank;
                this.id = tValue.id;
                this.name = tValue.name;
                this.score = tValue.score;
                this.score2 = tValue.score2;
                this.score3 = tValue.score3;
            }
            else
            {
                this.rank = 0;
                this.id = 0;
                this.name = string.Empty;
                this.score = 0;
                this.score2 = 0;
                this.score3 = 0;
            }
        }
    }



    /// <summary>
    /// 排行榜使用的竞技场信息
    /// </summary>
    public struct RankArenaInfo
    {
        /// <summary>
        /// 胜利次数
        /// </summary>
        public uint winCount;
        /// <summary>
        /// 失败次数
        /// </summary>
        public uint failCount;
        /// <summary>
        /// 队长（队员0）
        /// </summary>
        public ulong user0;
        /// <summary>
        /// 队员1
        /// </summary>
        public ulong user1;
        /// <summary>
        /// 队员2
        /// </summary>
        public ulong user2;
        /// <summary>
        /// 队员3
        /// </summary>
        public ulong user3;
        /// <summary>
        /// 队员4
        /// </summary>
        public ulong user4;



        public RankArenaInfo(RspRankArenaInfo msg)
        {
            this.winCount = msg.win;
            this.failCount = msg.fail;
            int tUserLength = msg.usersLength;
            this.user0 = tUserLength > 0 ? msg.users(0) : 0;
            this.user1 = tUserLength > 1 ? msg.users(1) : 0;
            this.user2 = tUserLength > 2 ? msg.users(2) : 0;
            this.user3 = tUserLength > 3 ? msg.users(3) : 0;
            this.user4 = tUserLength > 4 ? msg.users(4) : 0;
        }
    }
}
