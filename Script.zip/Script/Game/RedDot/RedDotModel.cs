using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bokura;

namespace Bokura
{
    public class RedDotData
    {
        private swm.RedDotType m_RedDotType = swm.RedDotType.UNKNOWN;
        private bool m_bIsRed = false;
        private uint m_Num = 0;

        public swm.RedDotType RedDotType
        {
            get
            {
                return m_RedDotType;
            }
            set
            {
                m_RedDotType = value;
            }
        }

        public bool IsRed
        {
            get
            {
                return m_bIsRed;
            }
            set
            {
                m_bIsRed = value;
            }
        }

        public uint Num
        {
            get
            {
                return m_Num;
            }
            set
            {
                m_Num = value;
            }
        }
        [XLua.BlackList]
        public void clear()
        {
            m_RedDotType = swm.RedDotType.UNKNOWN;
            m_bIsRed = false;
            m_Num = 0;
        }
        [XLua.BlackList]
        public void Refresh(swm.RedDotType _type, bool _bIsRed, uint _num)
        {
            m_RedDotType = _type;
            m_bIsRed = _bIsRed;
            m_Num = _num;
        }

    }

    /// <summary>
    /// 所有红点的 存储 和 设置入口
    /// </summary>
    class RedDotModel : ClientSingleton<RedDotModel>
    {
        private Dictionary<int, RedDotData> m_RedDotList = new Dictionary<int, RedDotData>(Bokura.ConstValue.kCap32);
        public Dictionary<int, RedDotData> RedDotList
        {
            get
            {
                return m_RedDotList;
            }
        }


        public GameEvent<RedDotData> onRedDotEvent = new GameEvent<RedDotData>();

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshRedDot>(ProcRefreshRedDot);
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_RedDotList.Clear();
        }

        ///服务器更新红点
        /// <summary>
        /// 刷新红点
        /// </summary>oun
        private void ProcRefreshRedDot(swm.RefreshRedDot msg)
        {
            SetRedDotData(msg.type, msg.num > 0, msg.num);
        }
        ///

        ///客户端使用

        /// <summary>
        /// 设置红点状态  （核心函数）
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_bIsRed"></param>
        /// <param name="_num"></param>
        /// <returns></returns>
        public RedDotData SetRedDotData(swm.RedDotType _type,bool _bIsRed, uint _num)
        {
            RedDotData _data = GetRedDotDataByType(_type);
            if(null == _data)
            {
                _data = new RedDotData();
                m_RedDotList.Add((int)_type, _data);
            }
            _data.Refresh(_type, _bIsRed, _num);
            onRedDotEvent.Invoke(_data);
            return _data;
        }

        /// <summary>
        /// 获得红点 通过类型
        /// </summary>
        /// <param name="_type"></param>
        /// <returns></returns>
        public RedDotData GetRedDotDataByType(swm.RedDotType _type)
        {
            RedDotData _data = null;
            m_RedDotList.TryGetValue((int)_type, out _data);
            return _data;
        }
        ///结束客户端使用
    }
}
