using System;
using Bokura;

#if REMOTE_DEBUG
namespace Bokura
{
    class RemoteDebug : IRemoteDebug
    {
        public override float GIScale
        {
            get { return Game.LevelSystemSetting.s_giScale; }
        }

        public override void InitFoliageSettings()
        {
            Game.FoliageSetting.Tree.TreeTypeCount = 0;
            Game.FoliageSetting.TreeTypeList.Clear();
            Game.FoliageSetting.Tree.TreeCount = 0;
            Game.FoliageSetting.Tree.TreeTrunkTris = 0;
            Game.FoliageSetting.Tree.TreeLeavesTris = 0;
            Game.FoliageSetting.Tree.TreeDrawCall = 0;

            Game.FoliageSetting.Grass.GrassTypeCount = 0;
            Game.FoliageSetting.Grass.GrassCount = 0;
            Game.FoliageSetting.Grass.GrassTris = 0;
            Game.FoliageSetting.Grass.GrassDrawCall = 0;
            Game.FoliageSetting.Grass.GeoGrassTris = 0;
        }

        public override bool CheckEnable()
        {
            return Game.FoliageSetting.Tree.TreeEnabale;
        }

        public override bool CheckEnable(int hash)
        {

            if (Game.FoliageSetting.MaxCountTreeEnable == false)
            {
                if (hash == Game.FoliageSetting.MaxCountTree)
                {
                    return false;
                }
            }
            if (Game.FoliageSetting.SecCountTreeEnable == false)
            {
                if (hash == (Game.FoliageSetting.SecCountTree))
                {
                    return false;
                }
            }

            return true;
        }

        public override void RefreshTreeCount(int hash, int count = 1)
        {
            if (!Game.FoliageSetting.TreeTypeList.ContainsKey(hash))
            {
                Game.FoliageSetting.TreeTypeList.Add(hash, count);
            }
            else
            {
                Game.FoliageSetting.TreeTypeList[hash] += count;
            }


            Game.FoliageSetting.Tree.TreeCount += (uint)count;

            return;
        }

        public override void RefreshTreeDrawCall()
        {
            if (Game.FoliageSetting.Tree.TreeEnabale)
            {
                Game.FoliageSetting.Tree.TreeDrawCall++;
            }
        }

        public override void RefreshTreeTris(uint triCount, bool isleaves)
        {
            if (Game.FoliageSetting.Tree.TreeEnabale)
            {
                if (isleaves)
                {
                    Game.FoliageSetting.Tree.TreeLeavesTris += triCount;
                }
                else
                {
                    Game.FoliageSetting.Tree.TreeTrunkTris += triCount;
                }
            }
        }

        public override void RefreshGrassDrawCall()
        {
            if (Game.FoliageSetting.Grass.GrassEnabale)
            {
                Game.FoliageSetting.Grass.GrassDrawCall++;
            }
        }

        public override void RefreshTop2Trees()
        {
            Game.FoliageSetting.TreeEnablelist.Clear();
            Game.FoliageSetting.Tree.TreeTypeCount = Game.FoliageSetting.TreeTypeList.Count;
            int maxcount = 0;
            int maxtreeHash = -1;
            foreach (var item in Game.FoliageSetting.TreeTypeList)
            {
                if (item.Value > maxcount)
                {
                    maxcount = item.Value;
                    maxtreeHash = item.Key;
                }
            }
            if (-1 !=  maxtreeHash)
            {
                Game.FoliageSetting.TreeEnablelist.Add(maxtreeHash);
            }
            maxcount = 0;
            int sectreeHash = -1;
            foreach (var item in Game.FoliageSetting.TreeTypeList)
            {
                if (item.Key != maxtreeHash && item.Value > maxcount)
                {
                    maxcount = item.Value;
                    sectreeHash = item.Key;
                }
            }
            if (-1 != (sectreeHash))
            {
                Game.FoliageSetting.TreeEnablelist.Add(sectreeHash);
            }

        }
    }
}
#endif