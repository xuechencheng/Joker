using System;
using System.Collections.Generic;
using FlatBuffers;
using LitJson;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using Bokura.Particle;
using Bokura;
using x2m.MakeUp;
using Bokura.Timeline;

namespace Bokura
{
    /// <summary>
    /// 角色创建相关的数据Model
    /// </summary>
    public class RoleCreationManager : ClientSingleton<RoleCreationManager>
	{
		private List<RoleCreationData> m_DataList;



		public int Count
		{
			get { return m_DataList != null ? m_DataList.Count : 0; }
		}

        /// <summary>
        /// 武器数量;
        /// </summary>
        public int ArmsCount
        {
            get
            {
                RoleCreateArmsBaseList tDataList = RoleCreateArmsManager.Instance.m_DataList;
                int tCount = tDataList.RoleCreateArmsLength;

                return tCount;
            }
        }



		private Dictionary<int, Entity> m_Entities = new Dictionary<int, Entity>(Const.kCap8);



		private GameEvent<int> m_OnCreateRoleFailedDataArrived = new GameEvent<int>();
		/// <summary>
		/// 服务器返回创建角色失败的原因
		/// </summary>
		public GameEvent<int> onCreateRoleFailedDataArrived
        {
			get { return m_OnCreateRoleFailedDataArrived; }
		}



		private GameEvent<uint> m_OnCreateRoleSucceedDataArrived = new GameEvent<uint>();
		/// <summary>
		/// 服务器在创建角色成功后返回角色列表
		/// </summary>
		public GameEvent<uint> onCreateRoleSucceedDataArrived
        {
			get { return m_OnCreateRoleSucceedDataArrived; }
		}


        private GameEvent m_OnFadeOutFinish = new GameEvent();
        /// <summary>
        /// fadeout结束
        /// </summary>
        public GameEvent OnFadeOutFinish
        {
            get { return m_OnFadeOutFinish; }
        }

        private GameEvent m_OnFadeInFinish = new GameEvent();
        /// <summary>
        /// fadein结束
        /// </summary>
        public GameEvent OnFadeInFinish
        {
            get { return m_OnFadeInFinish; }
        }


        private RoleCreationConfig m_Config;
        /// <summary>
        /// 角色创建的配置
        /// </summary>
        public RoleCreationConfig config
        {
            get { return m_Config; }
        }



        /// <summary>
        /// 摄像机自动移动使用的归一距离曲线
        /// </summary>
        private AnimationCurve m_AutoMoveCurve = null;



		/// <summary>
		/// 摄像机手动移动使用的归一距离曲线
		/// </summary>
		private AnimationCurve m_ManualMoveCurve = null;



		/// <summary>
		/// 特效透明度变化曲线
		/// </summary>
		private AnimationCurve m_AlphaCurve = null;



		/// <summary>
		/// 最大角色数量
		/// </summary>
		public int maxRoles { get { return m_Config.max_Roles; } }



		/// <summary>
		/// 相对角色位置的高度
		/// </summary>
		public float roleHeight { get { return m_Config.roleHeight; } }


        /// <summary>
        /// 预加载timeline
        /// </summary>
        public string preloadtimeline { get { return m_Config.preloadtimeline; } }


        /// <summary>
        /// UI隐藏的绝对高度
        /// </summary>
        public Vector2 hiddenHeight { get { return m_Config.hidden_Height; } }



        /// <summary>
        /// 摄像机在选角场景中的默认位置
        /// </summary>
        public Vector3 camDefaultPos { get { return m_Config.cam_DefaultPos; } }



		/// <summary>
		/// 摄像机在选角场景中的默认朝向
		/// </summary>
		public Vector3 camDefaultDir { get { return m_Config.cam_DefaultDir; } }



		/// <summary>
		/// 摄像机的FOV
		/// </summary>
		public float fov { get { return m_Config.fov; } }



		/// <summary>
		/// 站立动作
		/// </summary>
		public int standAnimHashName { get { return AnimatorStateID.ShowTime_Makeup; } }



		/// <summary>
		/// 待机动作
		/// </summary>
		public int idleAnimHashName { get { return AnimatorStateID.ShowTime_Idle; } }



        /// <summary>
        /// 缓存环境系统组件
        /// </summary>
        private EnvironmentSystem m_EnvSystem = null;



        /// <summary>
        /// 初始的环境配置
        /// </summary>
        private EnvironmentProfile m_OriginEnvProfile = null;



        /// <summary>
        /// 缓存后期组件
        /// </summary>
        private PostProcessVolume m_PostVolume = null;



        /// <summary>
        /// 初始的后期配置
        /// </summary>
        private PostProcessProfile m_OriginPostProfile = null;



        /// <summary>
        /// 缓存环境系统配置
        /// </summary>
        private Dictionary<string, EnvironmentProfile> m_EnvProfileCaches = new Dictionary<string, EnvironmentProfile>(4);



        /// <summary>
        /// 缓存后期配置
        /// </summary>
        private Dictionary<string, PostProcessProfile> m_PostProfileCaches = new Dictionary<string, PostProcessProfile>(4);



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
			MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCreateRole>(ResponseCreateRole_SC);
			RoleSelectionManager.Instance.onRoleSelectionDataArrived.AddListener(OnRoleSelectionDataArrived);
		}



        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {
            UnloadEntities();
            m_EnvProfileCaches.Clear();
            m_PostProfileCaches.Clear();
            m_EnvSystem = null;
            m_OriginEnvProfile = null;
            m_PostVolume = null;
            m_OriginPostProfile = null;
        }



        /// <summary>
        /// 加载数据表（/Tables/RoleCreate.bin）
        /// </summary>
        [XLua.BlackList]
        public void Load()
		{
			/*加载一些不适合放入Excel表的Json配置数据*/
			ImporterFunc<double, float> tImporter = input => Convert.ToSingle(input);
			string tJsonData = TableManager.LoadFileTable("role_creation.json", "/Datas/");
			//将double转为float，否则会报错
			JsonMapper.RegisterImporter<double, float>(tImporter);
			m_Config = JsonMapper.ToObject<RoleCreationConfig>(tJsonData);
			//记得清理
			JsonMapper.UnregisterImporters();

			/*加载一些不适合使用Excel或Json存储的曲线数据*/
			m_AutoMoveCurve = UICurveMgr.Instance.GetCurve("FadeOut");
			if (m_AutoMoveCurve == null)
				m_AutoMoveCurve = AnimationCurve.Linear(0,0,1,1);
			m_ManualMoveCurve = UICurveMgr.Instance.GetCurve("FadeInOut");
			if (m_ManualMoveCurve == null)
				m_ManualMoveCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);
			m_AlphaCurve = UICurveMgr.Instance.GetCurve("FXAlpha");
			if (m_AlphaCurve == null)
				m_AlphaCurve = AnimationCurve.EaseInOut(1, 1, 0, 0);

			/*加载Excel表数据*/
			RoleCreateManager.Load();
			RoleCreateBaseList tDataList = RoleCreateManager.Instance.m_DataList;
            int tCount = tDataList.RoleCreateLength;
			if (tCount > 0)
			{
				m_DataList = new List<RoleCreationData>(tCount);
				for (int tIdx = 0; tIdx < tCount; tIdx++)
				{
					RoleCreateBase? tRCBase = tDataList.RoleCreate(tIdx);
					if (tRCBase.HasValue)
					{
						RoleCreationData tRCData = new RoleCreationData();
						RoleCreateBase tValue = tRCBase.Value;
						tRCData.id = tValue.id;
						tRCData.name = tValue.name;

                        //开放性别;
                        tRCData.sex_open = tValue.sex_open;
                        //默认性别;
                        tRCData.default_sex = tValue.default_sex;

                        Vector3 tVec3 = Vector3.zero;

                        //public Vector3 scene_man_cem_startpos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_cem_startposLength; i++)
                            tVec3[i] = (float)tValue.scene_man_cem_startpos(i);
                        tRCData.scene_man_cem_startpos = tVec3;
                        //public Vector3 scene_man_cem_endpos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_cem_endposLength; i++)
                            tVec3[i] = (float)tValue.scene_man_cem_endpos(i);
                        tRCData.scene_man_cem_endpos = tVec3;
                        //public Vector3 scene_man_cem_enddir;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_cem_enddirLength; i++)
                            tVec3[i] = (float)tValue.scene_man_cem_enddir(i);
                        tRCData.scene_man_cem_enddir = tVec3;
                        //public int scene_man_cem_endfov;
                        tRCData.scene_man_cem_endfov = tValue.scene_man_cem_endfov;
                        //public Vector3 scene_man_prot_pos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_prot_posLength; i++)
                            tVec3[i] = (float)tValue.scene_man_prot_pos(i);
                        tRCData.scene_man_prot_pos = tVec3;
                        //public Vector3 scene_man_prot_dir;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_prot_dirLength; i++)
                            tVec3[i] = (float)tValue.scene_man_prot_dir(i);
                        tRCData.scene_man_prot_dir = tVec3;
                        //public Vector3 scene_man_facepos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_faceposLength; i++)
                            tVec3[i] = (float)tValue.scene_man_facepos(i);
                        tRCData.scene_man_facepos = tVec3;
                        //public int scene_man_facefov;
                        tRCData.scene_man_facefov = tValue.scene_man_facefov;
                        //public Vector3 scene_man_facedir;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_man_facedirLength; i++)
                            tVec3[i] = (float)tValue.scene_man_facedir(i);
                        tRCData.scene_man_facedir = tVec3;



                        //public Vector3 scene_female_cem_startpos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_cem_startposLength; i++)
                            tVec3[i] = (float)tValue.scene_female_cem_startpos(i);
                        tRCData.scene_female_cem_startpos = tVec3;
                        //public Vector3 scene_female_cem_endpos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_cem_endposLength; i++)
                            tVec3[i] = (float)tValue.scene_female_cem_endpos(i);
                        tRCData.scene_female_cem_endpos = tVec3;
                        //public Vector3 scene_female_cem_enddir;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_cem_enddirLength; i++)
                            tVec3[i] = (float)tValue.scene_female_cem_enddir(i);
                        tRCData.scene_female_cem_enddir = tVec3;
                        //public int scene_female_cem_endfov;
                        tRCData.scene_female_cem_endfov = tValue.scene_female_cem_endfov;
                        //public Vector3 scene_female_prot_pos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_prot_posLength; i++)
                            tVec3[i] = (float)tValue.scene_female_prot_pos(i);
                        tRCData.scene_female_prot_pos = tVec3;
                        //public Vector3 scene_female_prot_dir;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_prot_dirLength; i++)
                            tVec3[i] = (float)tValue.scene_female_prot_dir(i);
                        tRCData.scene_female_prot_dir = tVec3;
                        //public Vector3 scene_female_facepos;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_faceposLength; i++)
                            tVec3[i] = (float)tValue.scene_female_facepos(i);
                        tRCData.scene_female_facepos = tVec3;
                        //public int scene_female_facefov;
                        tRCData.scene_female_facefov = tValue.scene_female_facefov;
                        //public Vector3 scene_female_facedir;
                        tVec3 = Vector3.zero;
                        for (int i = 0; i < tValue.scene_female_facedirLength; i++)
                            tVec3[i] = (float)tValue.scene_female_facedir(i);
                        tRCData.scene_female_facedir = tVec3;

                        ProfessionTableBase? tPTBase = ProfessionTableManager.GetData(tValue.id);
                        if (tPTBase.HasValue)
                        {
                            ProfessionTableBase tPTValue = tPTBase.Value;
                            tRCData.prof_head = tPTValue.icon;
                            tRCData.prof_head_select = tPTValue.icon_select;
                        }
                        else
                        {
                            tRCData.prof_head = null;
                            tRCData.prof_head_select = null;
                        }



                        m_DataList.Add(tRCData);
					}
				}
			}


            RoleCreateArmsManager.Load();//js-角色创建武器表;

        }




		public RoleCreationData GetData(int index)
		{
			if (index < 0 || index >= Count)
			{
				index = 0;
				//UIUtility.LogError("RoleCreationManager.GetData:IndexOutOfRangeException");
			}
			return m_DataList[index];
		}

        public RoleCreateArmsBase GetArmsData(int index)
        {
            if (index < 0 || index >= ArmsCount)
            {
                index = 0;
            }

            RoleCreateArmsBase? tRCBase = RoleCreateArmsManager.Instance.m_DataList.RoleCreateArms(index);
            if (tRCBase.HasValue)
            {
                return tRCBase.Value;
            }

            return default(RoleCreateArmsBase);
        }


        public void LoadEntityByIndex(int tIdx)
        {
            RoleCreationData tData = GetData(tIdx);
            int tSex_Open = tData.sex_open;
            if (tSex_Open >= Const.kSex_Female)
            {
                Entity tChar = LoadEntity(tIdx, Const.kSex_Female);
                m_Entities.Add(UIUtility.GetCareerAndSexInOne(tIdx, Const.kSex_Female), tChar);
            }
            if (tSex_Open == Const.kSex_Man || tSex_Open == Const.kSex_All)
            {
                Entity tChar = LoadEntity(tIdx, Const.kSex_Man);
                m_Entities.Add(UIUtility.GetCareerAndSexInOne(tIdx, Const.kSex_Man), tChar);
            }
        }

        public void ClearEntities()
        {
            m_Entities.Clear();
        }

        public void LoadEntities()
		{
			m_Entities.Clear();
			int tCount = Count;

            for (int tIdx = 0; tIdx < tCount; tIdx++)
			{
                LoadEntityByIndex(tIdx);
            }
		}



		public void UnloadEntities()
		{
			foreach (var pair in m_Entities)
			{
				Entity tEntity = pair.Value;
				if (tEntity != null)
					tEntity.Release();
			}
			m_Entities.Clear();
		}



		/// <summary>
		/// 角色创建完成后，对应实体直接移交给角色选择界面，为角色创建界面重新补足新的实体
		/// </summary>
		public void ReplaceEntity(int idx, int sex)
		{
			int tKey = UIUtility.GetCareerAndSexInOne(idx, sex);
			m_Entities.Remove(tKey);
			Entity tChar = LoadEntity(idx, sex);
			m_Entities.Add(tKey, tChar);
		}



		public Entity GetEntity(int idx, int sex)
		{
			Entity tEntity = null;
			m_Entities.TryGetValue(UIUtility.GetCareerAndSexInOne(idx, sex), out tEntity);
			return tEntity;
		}



		private Entity LoadEntity(int idx, int sex)
		{
			RoleCreationData tRCData	= m_DataList[idx];
			var tData	= new swm.MapEntityDataT();
            //tData.entity_type			= swm.EntityType.Player;
            float x, z = 0;
            if (sex == (int)swm.CareerSex.Female)
            {
                Utilities.Angle2Vector2(tRCData.scene_female_prot_dir.Vec3().y, out z, out x);
                tData.cur_dir = UtilityExtensionClass.Vec3(new Vector3(x, 0, z));
                tData.cur_pos = tRCData.scene_female_prot_pos.Vec3();
            }
            else
            {
                Utilities.Angle2Vector2(tRCData.scene_man_prot_dir.Vec3().y, out z, out x);
                tData.cur_dir = UtilityExtensionClass.Vec3(new Vector3(x, 0, z));
                tData.cur_pos = tRCData.scene_man_prot_pos.Vec3();
            }

			var tUserData		        = new swm.MapUserT();
            tData.user_data             = tUserData;
            tUserData.career_type		= (swm.CareerType)tRCData.id;
			tUserData.career_sex		= (swm.CareerSex)sex;
			//tUserData.is_show_weapon	= true;

            //因为分性别，暂时无法缓存;
            RoleCreateBase? tRoleCreateData = RoleCreateManager.GetData(tRCData.id);
            RoleCreateBase tRoleCreateConfig = tRoleCreateData.Value;
            for (int tIdx = 0, tClothLength = tRoleCreateConfig.initial_clothingLength; tIdx < tClothLength; ++tIdx)
            {
                var tClothing = tRoleCreateConfig.initial_clothing(tIdx);
                var tClothingConfig = tClothing.Value;
                swm.CareerSex tSexCreate = (swm.CareerSex)tClothingConfig.key;
                if (tSexCreate == tUserData.career_sex)
                {
                    var tFids = new List<uint>(6);
                    for (int tFIdx = 0; tFIdx < 6; ++tFIdx)
                        tFids.Add(0);

                    string[] tFidStrs = tClothingConfig.value.Split(',');
                    for (int tStrIdx = 0, tFidStrsLength = tFidStrs.Length; tStrIdx < tFidStrsLength; ++tStrIdx)
                    {
                        var tFid = uint.Parse(tFidStrs[tStrIdx]);
                        FashionTableBase? tFsConfig = FashionTableManager.GetData((int)tFid);
                        tFids[tFsConfig.Value.slottype] = tFid;
                    }
                    tUserData.fids = tFids;
                }
            }

            Character tEntity			= new Character(tData.entity_id);
            tEntity.Avatar.EnableLOD    = false;
            tEntity.Avatar.shadowType = AvatarShadowType.Unique;
			tEntity.Layer				= (Int32)UserLayer.Layer_MainCharacter;
            tEntity.SyncLoad            = true;
			tEntity.Visible				= true;
            tEntity.Actived             = false;
            tEntity.init();
            tEntity.SetData(tData);
			tEntity.OnAddToScene();

			return tEntity;
		}

        private PreviewConfigData[] m_previews = null;
        public const string startFilePath = "Assets/Asset/datas/pinchingface/";
        private const string previewsFileName = "previews";
        private MakeUpRouterData m_tempRouterData = null;
        private Character entity = null;
        private Renderer bodyRender;


        void InitBodyPart()
        {
            if (entity != null)
            {
                var entityUnityObject = entity.Avatar.unityObject;

                Renderer[] rs = entityUnityObject.GetComponentsInChildren<Renderer>();

//                 GameObject obj = null;
                for (int i = 0; i < rs.Length; i++)
                {
//                     obj = rs[i].gameObject;
                    string objName = rs[i].gameObject.name.ToLower();

                    if (objName.Contains("body"))
                    {
                        bodyRender = rs[i];
                    }
                }
            }
        }

        public PreviewConfigData GetPreviewConfigData(int sexIndex, int careerIndex)
        {
            if (m_previews == null)
            {
                UnityEngine.Object o = ResourceHelper.LoadResourceSync(startFilePath, previewsFileName, IResourceLoader.strAssetSuffix);
                if (o != null)
                {
                    m_previews = (o as FacePreviewAssets).prevews;
                }
            }

            foreach (var data in m_previews)
            {
                if ((data.sexIndex == sexIndex) && (data.careerIndex == careerIndex))
                {
                    return data;
                }
            }

            return null;
        }


        public int GetPreviewListCount(int sexIndex, int careerIndex)
        {
            PreviewConfigData data = GetPreviewConfigData(sexIndex, careerIndex);
            if (data != null)
            {
                if (data.datas != null)
                {
                    return data.datas.clothes.Count;
                }
            }

            return 0;
        }

        public MakeUpRouterData GetMakeUpRouterData(int sexIndex, int careerIndex, int index)
        {
            if (m_tempRouterData == null)
            {
                m_tempRouterData = new MakeUpRouterData();
            }

            PreviewConfigData data = GetPreviewConfigData(sexIndex, careerIndex);
            if (data != null)
            {
                if (data.datas != null)
                {
                    var currData = data.datas.clothes[index];
                    m_tempRouterData.stringArg1 = currData.name;
                    m_tempRouterData.stringArg2 = currData.imagePaths[0];
                    m_tempRouterData.stringArg3 = currData.imagePaths[1];
                }
            }

            return m_tempRouterData;
        }

        List<int> defaultClothes = null;

        public void RevertClothes()
        {
            if (defaultClothes != null)
            {
                ApplyFashion(defaultClothes);
                defaultClothes = null;
            }
                
        }

        public void OnChangeClothesClick(int sexIndex, int careerIndex, int index)
        {
            PreviewConfigData data = GetPreviewConfigData(sexIndex, careerIndex);
            if (data != null)
            {
                if (data.datas != null)
                {
                    var currData = data.datas.clothes[index];
                    defaultClothes = data.datas.clothes[0].clothId;

                    ApplyFashion(currData.clothId);

//                     var rot = new Vector3(currData.camDefaultSet[0], currData.camDefaultSet[1], currData.camDefaultSet[2]);
//                     var pos = new Vector3(currData.camDefaultSet[3], currData.camDefaultSet[4], currData.camDefaultSet[5]);

                }
            }
        }

        public void ApplyFashion(List<int> fashionCfg)
        {
            if (entity != null)
            {
                FashionModel.Instance.SetCharacterFashions(entity, fashionCfg);
                if (!bodyRender)
                {
                    InitBodyPart();
                    if (!bodyRender)
                    {
                        return;
                    }
                }
            }
        }

        public void SetEntity(Character role)
        {
            entity = role;
        }

        public Character GetCurrEntity()
        {
            return entity;
        }

        public void SetUniqueShadowForHead(bool isHead)
        {
            ILevelSystemManager.Instance.SetUniqueShadowForHead(isHead);
        }

        public List<BasePartConfig> GetFaceBasePartConfigs(int sexIndex, int careerIndex)
        {
            List<BasePartConfig> configs = null;

            MakeUpUtility.GetFaceBasePartConfigs(sexIndex, careerIndex, out configs);

            return configs;
        }

        private byte[] m_makeupdatas = null;
        [XLua.BlackList]
        public void SaveMakeupBytes(byte[] makeupdatas)
        {
            m_makeupdatas = makeupdatas;
        }

        [XLua.BlackList]
        public byte[] MakeupdatasProp
        {
            get { return m_makeupdatas; }
        }

        public string GetCourtVerdictTableString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (CourtVerdictTableManager.Instance == null)
            {
                CourtVerdictTableManager.Load();
            }

            List<CourtVerdictTableBase?> wordsTitle = new List<CourtVerdictTableBase?>(0);
            Dictionary<int, List<CourtVerdictTableBase?>> wordsMid = new Dictionary<int, List<CourtVerdictTableBase?>>(0);
            Dictionary<int, List<CourtVerdictTableBase?>> wordsEnd = new Dictionary<int, List<CourtVerdictTableBase?>>(0);
            for (int i = 0; i < CourtVerdictTableManager.Instance.m_DataList.CourtVerdictTableLength; ++i)
            {
                var data = CourtVerdictTableManager.Instance.m_DataList.CourtVerdictTable(i);
                if (data != null)
                {
                    if (data.Value.type == 1)
                    {
                        wordsTitle.Add(data);
                    }
                    else if (data.Value.type == 2)
                    {
                        if (!wordsMid.ContainsKey(data.Value.show_level))
                        {
                            wordsMid[data.Value.show_level] = new List<CourtVerdictTableBase?>(0);
                        }
                        wordsMid[data.Value.show_level].Add(data);
                    }
                    else if (data.Value.type == 3)
                    {
                        if (!wordsEnd.ContainsKey(data.Value.show_level))
                        {
                            wordsEnd[data.Value.show_level] = new List<CourtVerdictTableBase?>(0);
                        }
                        wordsEnd[data.Value.show_level].Add(data);
                    }
                }
            }
            sb.Append("{");
            sb.Append("first=").Append(ListTableDataToString(wordsTitle)).Append(",");
            sb.Append("mid=").Append(DicTableDataTostring(wordsMid)).Append(",");
            sb.Append("last=").Append(DicTableDataTostring(wordsEnd));
            sb.Append("}");
            return sb.ToString();
        }
        string ListTableDataToString(List<CourtVerdictTableBase?> list)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("{");
            for (int i = 0; i < list.Count; i++)
            {
                CourtVerdictTableBase? data = list[i];
                VString vs = VString.Concat(AllocType.Tmp,
                          "{id=", data.Value.id.ToString(),
                          ",type=", data.Value.type.ToString(),
                          ",text=\"", data.Value.text, "\"",
                          ",level=", data.Value.show_level.ToString(),
                          ",sex=", data.Value.sex.ToString(),
                          "}");
                string split = ",";
                if (i == list.Count - 1)
                {
                    split = "";
                }
                sb.Append("[").Append(i + 1).Append("]=").Append(vs).Append(split);
                vs.Dispose();
            }
            sb.Append("}");
            return sb.ToString();
        }
        string DicTableDataTostring(Dictionary<int, List<CourtVerdictTableBase?>> wordsDic)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            List<int> list = new List<int>(wordsDic.Keys);
            sb.Append("{");
            for (int i = 0; i < list.Count; i++)
            {
                string vs = ListTableDataToString(wordsDic[list[i]]);
                string split = ",";
                if (i == list.Count - 1)
                {
                    split = "";
                }
                sb.Append("[").Append(list[i]).Append("]=").Append(vs).Append(split);
            }
            sb.Append("}");
            return sb.ToString();
        }



        /// <summary>
        /// 切换环境;
        /// </summary>
        public void ChangeEnv(string envProfileName, string postProfileName)
        {
            if(null == m_EnvSystem)
            {
                m_EnvSystem = Component.FindObjectOfType<EnvironmentSystem>();
                if (null != m_EnvSystem)
                    m_OriginEnvProfile = m_EnvSystem.sharedProfile;
            }
            if(null != m_EnvSystem && !string.IsNullOrEmpty(envProfileName))
            {
                EnvironmentProfile tProfile = null;
                if(!m_EnvProfileCaches.TryGetValue(envProfileName, out tProfile) || null == tProfile)
                {
                    tProfile = ResourceHelper.LoadResourceSync(IResourceLoader.strEnvProfilePath, envProfileName, IResourceLoader.strAssetSuffix) as EnvironmentProfile;
                    if (null != tProfile)
                        m_EnvProfileCaches[envProfileName] = tProfile;
                }
                if(null != tProfile)
                    m_EnvSystem.LoadProfile(tProfile);
            }
            if (null == m_PostVolume)
            {
                m_PostVolume = Component.FindObjectOfType<PostProcessVolume>();
                if (null != m_PostVolume)
                    m_OriginPostProfile = m_PostVolume.sharedProfile;
            }
            if (null != m_PostVolume && !string.IsNullOrEmpty(postProfileName))
            {
                PostProcessProfile tProfile = null;
                if (!m_PostProfileCaches.TryGetValue(postProfileName, out tProfile) || null == tProfile)
                {
                    tProfile = ResourceHelper.LoadResourceSync(IResourceLoader.strPostProfilePath, postProfileName, IResourceLoader.strAssetSuffix) as PostProcessProfile;
                    if (null != tProfile)
                        m_PostProfileCaches[postProfileName] = tProfile;
                }
                if (null != tProfile)
                    m_PostVolume.sharedProfile = tProfile;
            }
        }



        public void RecoverEnvAndLight()
        {
            if (null != m_EnvSystem)
                m_EnvSystem.LoadProfile(m_OriginEnvProfile);
            if (null != m_PostVolume)
                m_PostVolume.sharedProfile = m_OriginPostProfile;
        }




        /// <summary>
        /// 切换角色时，需要销毁已经激活的特效和正在渐隐的特效
        /// </summary>
        public void StopActionEffect(Entity entity)
		{
			if (entity == null) return;
			IAvatar tAvatar = entity.Avatar;
			if (tAvatar == null) return;
			ActionEffectManager.Instance.StopActionEffect(tAvatar.unityObject);
			X2ParticleFadeOut.Instance.StopFadeOut(tAvatar.unityObject);
		}



		public float SampleAutoCurve(float percenet)
		{
			return m_AutoMoveCurve.Evaluate(Mathf.Clamp01(percenet));
		}



		public float SampleManualCurve(float percent)
		{
			return m_ManualMoveCurve.Evaluate(Mathf.Clamp01(percent));
		}



		public float SampleAlphaCurve(float percent)
		{
			return m_AlphaCurve.Evaluate(Mathf.Clamp01(percent));
		}


        void FadeOutFinish()
        {
            m_OnFadeOutFinish.Invoke();
        }

        void FadeInFinish()
        {
            m_OnFadeInFinish.Invoke();
        }

        public void StartFadeOut()
        {
            ScreenFade.StartFading(0, FadeOutFinish, From.SkipClip, Level.Bottom);
        }

        public void StartFadeIn()
        {
            ScreenFade.StartFading(1, FadeInFinish, From.SkipClip, Level.Bottom);
        }


		//向GameServer请求创建角色
		public void RequestCreateRole_CS(string roleName, Entity selected)
		{
            if (string.IsNullOrEmpty(roleName) || selected == null) return;
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            StringOffset tNameOffset = tFBB.CreateString(roleName);
            if (m_makeupdatas == null) { m_makeupdatas = new byte[0]; }//捏脸的数据;
            VectorOffset vo = swm.ReqCreateRole.CreateMakeupDataVector(tFBB, m_makeupdatas);//捏脸的数据;
            Offset<swm.ReqCreateRole> tOffset = swm.ReqCreateRole.CreateReqCreateRole(tFBB, tNameOffset, selected.CareerType, selected.Sex, vo, GetWeaponType());
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCreateRole.HashID, tFBB);
        }



        /// <summary>
        /// 服务器返回角色创建失败的原因
        /// </summary>
		private void ResponseCreateRole_SC(swm.RspCreateRole msg)
		{
			m_OnCreateRoleFailedDataArrived.Invoke((int)msg.code);
		}



        /// <summary>
        /// 服务器在角色创建成功后返回最新角色列表
        /// </summary>
		private void OnRoleSelectionDataArrived(uint result)
		{
			m_OnCreateRoleSucceedDataArrived.Invoke(result);
		}


        private int m_selectedArmsIndex = 0;
        public void SetSelectedArmsIndex(int index)
        {
            m_selectedArmsIndex = index;
        }

        public uint GetWeaponType()
        {
            return (uint)GetArmsData(m_selectedArmsIndex).id;
        }

    }



	public class RoleCreationData
	{
		public int      id;
		public string   name;
        public string   prof_name;

		public int      sex_open;
		public int      default_sex;

        public Vector3 scene_man_cem_startpos;
        public Vector3 scene_man_cem_endpos;
        public Vector3 scene_man_cem_enddir;
        public int scene_man_cem_endfov;
        public Vector3 scene_man_prot_pos;
        public Vector3 scene_man_prot_dir;
        public Vector3 scene_man_facepos;
        public int      scene_man_facefov;
        public Vector3 scene_man_facedir;

        public Vector3 scene_female_cem_startpos;
        public Vector3 scene_female_cem_endpos;
        public Vector3 scene_female_cem_enddir;
        public int scene_female_cem_endfov;
        public Vector3 scene_female_prot_pos;
        public Vector3 scene_female_prot_dir;
        public Vector3 scene_female_facepos;
        public int scene_female_facefov;
        public Vector3 scene_female_facedir;

        public string prof_head;
        public string prof_head_select;


        //public string   preview_effect;
    }



	[System.Serializable]
	public struct RoleCreationConfig
    {
        /// <summary>
        /// 计算观察点时的X偏移量（右侧 +）
        /// </summary>
        public float target_x;
        /// <summary>
        /// 计算观察点时的Y偏移量（上方 +）
        /// </summary>
        public float target_y;
        /// <summary>
        /// 计算观察点时的Z偏移量（后方 -）
        /// </summary>
        public float target_z;
        /// <summary>
        /// 入口点离观察点的高度
        /// </summary>
		public float relative_height;
        /// <summary>
        /// 进入职业场景的摄像机速度
        /// </summary>
		public float moveSpeedToCareer;
        /// <summary>
        /// 职业场景内的摄像机速度
        /// </summary>
		public float moveSpeedInCareer;
        /// <summary>
        /// 贴近脸部的摄像机速度
        /// </summary>
		public float moveSpeedToFace;
        /// <summary>
        /// 沙盘内的摄像机缩放速度
        /// </summary>
		public float zoomSpeed;
        /// <summary>
        /// 沙盘内的摄像机缩放最小高度
        /// </summary>
		public float zoomMin;
        /// <summary>
        /// 沙盘内的摄像机缩放最大高度
        /// </summary>
		public float zoomMax;
        /// <summary>
        /// 沙盘内的初始位置
        /// </summary>
		public Vector3 cam_StartPos;
        /// <summary>
        /// 列表弹出速度
        /// </summary>
		public float expandSpeed;
        /// <summary>
        /// 职业按钮缩放速度
        /// </summary>
		public float scaleSpeed;
        /// <summary>
        /// 景深持续时间
        /// </summary>
		public float fxDuration;
        /// <summary>
        /// 沙盘内职业图标隐藏/显示的摄像机高度
        /// </summary>
		public Vector2 hidden_Height;
        /// <summary>
        /// 最大角色数量
        /// </summary>
		public int max_Roles;
        /// <summary>
        /// 摄像机相对于脸部点的高度
        /// </summary>
		public float face_y;
        /// <summary>
        /// 摄像机相对于脸部点的Z轴距离
        /// </summary>
		public float face_z;
        /// <summary>
        /// 摄像机相对于角色位置的焦点高度
        /// </summary>
		public float roleHeight;
        /// <summary>
        /// 摄像机在选角场景中的默认位置
        /// </summary>
		public Vector3 cam_DefaultPos;
        /// <summary>
        /// 摄像机在选角场景中的默认转角
        /// </summary>
		public Vector3 cam_DefaultDir;
        /// <summary>
        /// 沙盘中摄像机在最高点的平移速度
        /// </summary>
		public float dragSpeed;
        /// <summary>
        /// 沙盘中摄像机平移的平滑时间
        /// </summary>
		public float smoothTime;
        /// <summary>
        /// 用于沙盘和职业场景间切换过程镜头模糊的最大焦距
        /// </summary>
		public float maxFocusDistance;
        /// <summary>
        /// 摄像机观察角色时的视野
        /// </summary>
		public float fov;
        /// <summary>
        /// 摄像机在最低点和最高点能够移动到的最左侧位置
        /// </summary>
        public Vector2 leftRange;
        /// <summary>
        /// 摄像机在最低点和最高点能够移动到的最右侧位置
        /// </summary>
        public Vector2 rightRange;
        /// <summary>
        /// 摄像机在最低点和最高点能够移动到的最下侧位置
        /// </summary>
        public Vector2 bottomRange;
        /// <summary>
        /// 摄像机在最低点和最高点能够移动到的最上侧位置
        /// </summary>
        public Vector2 topRange;
        /// <summary>
        /// 预加载timeline
        /// </summary>
        public string preloadtimeline;
    }
}
