using System;
using System.Collections.Generic;
using FlatBuffers;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class RoleSelectionManager : ClientSingleton<RoleSelectionManager>
	{
        /// <summary>
        /// 存放当前账号登陆的服务器中的角色信息
        /// </summary>
		private List<RoleSelectionData> m_DataList = new List<RoleSelectionData>(Const.kCap8);



        /// <summary>
        /// 当前账号登陆的服务器中的角色数量
        /// </summary>
		public int Count
		{
			get { return m_DataList.Count; }
		}



        private int m_DefaultIdx = -1;
        /// <summary>
        /// 上一次登陆游戏的角色序号
        /// </summary>
        public int defaultIdx { get { return m_DefaultIdx; } }



		private GameEvent<uint> m_OnRoleSelectionDataArrived = new GameEvent<uint>();
		/// <summary>
		/// 服务器返回角色列表的事件
		/// </summary>
		public GameEvent<uint> onRoleSelectionDataArrived
		{
			get { return m_OnRoleSelectionDataArrived; }
		}



        private GameEvent<int> m_OnRoleDeleteResultArrived = new GameEvent<int>();
        /// <summary>
        /// 服务器返回角色删除结果的事件
        /// </summary>
        public GameEvent<int> onRoleDeleteResultArrived
        {
            get { return m_OnRoleDeleteResultArrived; }
        }



        private GameEvent<int> m_OnRoleRecoverResultArrived = new GameEvent<int>();
        /// <summary>
        /// 服务器返回角色恢复结果的事件
        /// </summary>
        public GameEvent<int> onRoleRecoverResultArrived
        {
            get { return m_OnRoleRecoverResultArrived; }
        }



        /// <summary>
        /// 待机动作的状态哈希名
        /// </summary>
        public int idleAnimHashName { get { return AnimatorStateID.ShowTime_IdleLoop; } }



        /// <summary>
        /// 展示动作的状态哈希名
        /// </summary>
        public int makeupAnimHashName { get { return AnimatorStateID.ShowTime_Makeup; } }



        /// <summary>
        /// 没有删除的在前，按进入时间从近到远，删除的在后，删除时间由远到近
        /// </summary>
        private Comparison<RoleSelectionData> m_SortCamparer = (left, right) =>
		{
            if (left.timeForDelete == 0 && right.timeForDelete > 0) return -1;
            else if (left.timeForDelete > 0 && right.timeForDelete == 0) return 1;
            else if (left.timeForDelete == 0 && right.timeForDelete == 0)
            {
                if (left.last_game_time > right.last_game_time)
                    return -1;
                else if (left.last_game_time < right.last_game_time)
                    return 1;
                else
                    return 0;
            }
            else
            {
                if (left.timeForDelete < right.timeForDelete)
                    return -1;
                else if (left.timeForDelete > right.timeForDelete)
                    return 1;
                else
                    return 0;
            }
        };



        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
		{
			MsgDispatcher.instance.RegisterFBMsgProc<swm.RspRoleList>(ResponseRoleList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspDeleteRole>(ResponseDeleteRole_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspCancelDeleteRole>(ResponseRecoverRole_SC);
        }



        /// <summary>
        /// 重置数据
        /// </summary>
        public void Clear()
        {

        }


        private byte[] m_lastMakeupData = null;

        public void GetLastMakeupData(ref byte[] makeupData)
        {
            makeupData = m_lastMakeupData;
        }

		//Cache gi boost ppid moved to makeup utilities
        public void OnEnterState()
        {
        }

        public void OnLeaveState()
        {
        }


        /// <summary>
        /// ServersManager.RequestLoginGame:创建角色、登录服务器、删除角色、恢复角色
        /// </summary>
        private void ResponseRoleList_SC(swm.RspRoleList msg)
		{
            Bokura.Clothify.EventHandler.OnEnterNonGameScene();

            m_DataList.Clear();
            for (int tIdx = 0, tCount = msg.role_listLength; tIdx < tCount; tIdx++)
			{
				swm.SelectRoleBase? tSRB = msg.role_list(tIdx);
				if (tSRB.HasValue)
				{
					swm.SelectRoleBase tValue	= tSRB.Value;
					RoleSelectionData tData		= new RoleSelectionData();
					tData.charid				= tValue.charid;
					tData.name					= tValue.name;
					tData.career				= (int)tValue.career;
					tData.sex					= (int)tValue.sex;
					tData.level					= tValue.level;
					tData.create_time			= tValue.create_time;
                    tData.timeForDelete         = tValue.delete_time;
                    tData.last_game_time        = tValue.offline_time;
                    tData.hasPlayed				= false;

                    tData.weaponid = tValue.weaponid;

                    byte[] tMakeupData          = new byte[tValue.makeup_dataLength];
                    for (int tMcIdx = 0, tMcDataLength = tValue.makeup_dataLength; tMcIdx < tMcDataLength; tMcIdx++)
                        tMakeupData[tMcIdx] = tValue.makeup_data(tMcIdx);
                    tData.makeup_data = tMakeupData;

                    var tFashions        = new List<uint>(6);
                    for (int tFsIdx = 0, tFsDataLength = tValue.fashion_dataLength; tFsIdx < tFsDataLength; ++tFsIdx)
                    {
                        var tFid = tValue.fashion_data(tFsIdx);
                        tFashions.Add( tFid);
                    }
                    tData.fashions = tFashions;

                    //应该根据是否进入过游戏设置角色和摄像机的位置和朝向
                    if (tData.hasPlayed)
					{
						//进入过游戏的角色，界面使用通用背景，所有职业相同的位置和朝向
					}
					else
					{
						//没进入过游戏的角色(包括刚创建的角色)，背景为当前门派背景
						RoleCreationData tRCD	= RoleCreationManager.Instance.GetData(tData.career - 1);

                        if (tValue.sex == swm.CareerSex.Female)
                        {
                            tData.role_pos = tRCD.scene_female_prot_pos;

                            float x, z = 0;
                            Utilities.Angle2Vector2(tRCD.scene_female_prot_dir.Vec3().y, out z, out x);
                            tData.role_dir = new Vector3(x, 0, z);
                            tData.cam_pos = tRCD.scene_female_cem_endpos;
                            tData.fov = tRCD.scene_female_cem_endfov;
                            tData.prof_head = tRCD.prof_head;
                            tData.prof_head_select = tRCD.prof_head_select;
                            // 						Vector3 tLookAtPos		= tRCD.scene_prot_pos + Vector3.up * RoleCreationManager.Instance.roleHeight;
                            // 						Vector3 tVector			= tLookAtPos - tRCD.scene_cem_endpos;
                            // 						tVector.x				= 0;
                            // 						//左手顺时针为正
                            // 						float tAngleX			= Vector3.SignedAngle(Vector3.forward, tVector, Vector3.right);
                            tData.cam_dir = tRCD.scene_female_cem_enddir;
                        }
                        else
                        {
                            tData.role_pos = tRCD.scene_man_prot_pos;

                            float x, z = 0;
                            Utilities.Angle2Vector2(tRCD.scene_man_prot_dir.Vec3().y, out z, out x);
                            tData.role_dir = new Vector3(x, 0, z);
                            tData.cam_pos = tRCD.scene_man_cem_endpos;
                            tData.fov = tRCD.scene_man_cem_endfov;
                            tData.prof_head = tRCD.prof_head;
                            tData.prof_head_select = tRCD.prof_head_select;
                            // 						Vector3 tLookAtPos		= tRCD.scene_prot_pos + Vector3.up * RoleCreationManager.Instance.roleHeight;
                            // 						Vector3 tVector			= tLookAtPos - tRCD.scene_cem_endpos;
                            // 						tVector.x				= 0;
                            // 						//左手顺时针为正
                            // 						float tAngleX			= Vector3.SignedAngle(Vector3.forward, tVector, Vector3.right);
                            tData.cam_dir = tRCD.scene_man_cem_enddir;
                        }
                    }

					m_DataList.Add(tData);
				}
			}
            //没有删除的在前，按进入时间从近到远，删除的在后，删除时间由远到近
            m_DataList.Sort(m_SortCamparer);

            //寻找最近进入过游戏的角色的索引,没有就默认为第一个，否则为-1
            m_DefaultIdx = -1;
            if (m_DataList.Count > 0)
                m_DefaultIdx = 0;

            m_OnRoleSelectionDataArrived.Invoke(msg.result);
		}



		/// <summary>
		/// 请求以所选角色登录游戏
		/// </summary>
		public void RequestSelectRole_CS(ulong charid)
		{
            if (m_DataList != null)
            {
                foreach (var info in m_DataList)
                {
                    if (info.charid == charid)
                    {
                        m_lastMakeupData = info.makeup_data;
                        break;
                    }
                }
            }




            Bokura.Clothify.EventHandler.OnExitNonGameScene();
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
			Offset<swm.ReqSelectRole> tOffset = swm.ReqSelectRole.CreateReqSelectRole(tFBB, charid);
			tFBB.Finish(tOffset.Value);
			MsgDispatcher.instance.SendFBPackage(swm.ReqSelectRole.HashID, tFBB);
		}



		/// <summary>
		/// 请求删除指定角色
		/// </summary>
		public void RequestDeleteRole_CS(ulong charid)
		{
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqDeleteRole> tOffset = swm.ReqDeleteRole.CreateReqDeleteRole(tFBB, charid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqDeleteRole.HashID, tFBB);
        }



        /// <summary>
        /// 删除角色结果返回
        /// </summary>
        private void ResponseDeleteRole_SC(swm.RspDeleteRole msg)
        {
            m_OnRoleDeleteResultArrived.Invoke((int)msg.code);
        }



        /// <summary>
        /// 请求恢复指定角色
        /// </summary>
        public void RequestRecoverRole_CS(ulong charid)
		{
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqCancelDeleteRole> tOffset = swm.ReqCancelDeleteRole.CreateReqCancelDeleteRole(tFBB, charid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCancelDeleteRole.HashID, tFBB);
        }



        /// <summary>
        /// 恢复角色结果返回
        /// </summary>
        private void ResponseRecoverRole_SC(swm.RspCancelDeleteRole msg)
        {
            m_OnRoleRecoverResultArrived.Invoke((int)msg.code);
        }



        /// <summary>
        /// 指定角色的删除时间到了
        /// </summary>
        public void OnDeleteTimeOut(ulong charId, bool refresh = false)
        {
            for (int tIdx = 0, tCount = Count; tIdx < tCount; tIdx++)
            {
                if (m_DataList[tIdx].charid == charId)
                {
                    m_DataList.RemoveAt(tIdx);
                    break;
                }
            }
            if (refresh)
            {
                m_DefaultIdx = -1;
                if (m_DataList.Count > 0)
                    m_DefaultIdx = 0;
                m_OnRoleSelectionDataArrived.Invoke(0);
            }
        }



        public RoleSelectionData GetData(int index)
		{
			if (index < 0 || index >= Count)
				throw new IndexOutOfRangeException("RoleSelectionManager:GetData");
			return m_DataList[index];
		}



		/// <summary>
		/// 根据名称获取角色数据索引
		/// </summary>
		public int GetIndexByName(string name)
		{
			int tIndex = -1;
			if (!string.IsNullOrEmpty(name))
			{
				for (int tIdx = 0, tCount = Count; tIdx < tCount; tIdx++)
				{
					if (m_DataList[tIdx].name == name)
					{
						tIndex = tIdx;
						break;
					}
				}
			}
			return tIndex;
		}



		/// <summary>
		/// 根据数据索引获取角色实体
		/// </summary>
		public Entity GetEntity(int index)
		{
			//TODO：自定义的脸部
			RoleSelectionData tRSData	= m_DataList[index];
			var tData	                = new swm.MapEntityDataT();
			//tData.entity_type			= swm.EntityType.Player;
			tData.cur_dir               = tRSData.role_dir.Vec3();
			tData.cur_pos               = tRSData.role_pos.Vec3();

			var user_data		        = new swm.MapUserT();
            tData.user_data             = user_data;
			user_data.career_type		= (swm.CareerType)tRSData.career;
			user_data.career_sex		= (swm.CareerSex)tRSData.sex;
            //user_data.makeup_data       = new List<byte>(tRSData.makeup_data);
			//user_data.is_show_weapon	= true;
            user_data.fids              = new List<uint>(tRSData.fashions);

			Character tEntity			= new Character(tData.entity_id);
            tEntity.SetMakeupData(tRSData.makeup_data);
            tEntity.Avatar.EnableLOD    = false;
            tEntity.Avatar.shadowType   = AvatarShadowType.Unique;
			tEntity.Layer				= (Int32)UserLayer.Layer_MainCharacter;
            tEntity.SyncLoad            = true;
            tEntity.Visible             = true;
            tEntity.Actived             = true;
            tEntity.init();
            tEntity.SetData(tData);
			tEntity.OnAddToScene();

			return tEntity;
		}



		/// <summary>
		/// 切换角色时，需要销毁已经激活的特效和正在渐隐的特效
		/// </summary>
		public void StopActionEffect(Entity entity)
		{
			RoleCreationManager.Instance.StopActionEffect(entity);
		}



		/// <summary>
		/// 获取实体的焦点
		/// </summary>
		public Vector3 GetEntityLookAtPos(Entity entity)
		{
			if (entity != null)
				return entity.Position + new Vector3(0, RoleCreationManager.Instance.roleHeight, 0);
			else
				return Vector3.zero;
		}

        public void LoadTimeLine()
        {
            ResourceHelper.LoadResourceAsync(IResourceLoader.strTimeline, RoleCreationManager.Instance.preloadtimeline, IResourceLoader.strPrefabSuffix);
        }
	}



	/// <summary>
	/// 角色选择数据
	/// </summary>
	public struct RoleSelectionData
	{
		public ulong			charid;
		public string			name;
		public int				career;
		public int				sex;
		public uint				level;
		public uint				create_time;
		public bool				hasPlayed;
        /// <summary>
        /// 上次进入游戏的时间
        /// </summary>
        public uint             last_game_time;
		public Vector3			role_pos;
		public Vector3			role_dir;
		public Vector3			cam_pos;
		public Vector3			cam_dir;
        public int             fov;
        public byte[]           makeup_data;
        /// <summary>
        /// 删除剩余时间（0表示没有被删除）
        /// </summary>
        public uint				timeForDelete;
		public string			prof_head;
		public string			prof_head_select;
        public List<uint>        fashions;

        public uint weaponid;
    }
}