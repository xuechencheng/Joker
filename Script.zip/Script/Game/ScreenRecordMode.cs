using UnityEngine;
using Bokura;

namespace Bokura
{
   
    static class ScreenRecordMode
    {

        static bool m_enable = false;
        static float m_curShadowDistance;
        public static bool Enable
        {
            get
            {
                return m_enable;
            }
            set
            {
                m_enable = value;
                if(m_enable)
                {
                    ICameraHelper.Instance.SwitchController(CameraControlMode.FreeCamera);
                    if(UIManager.Instance.ToggleSwitchUI())
                    {
                        UIManager.Instance.ToggleSwitchUI();
                    }
                    GameScene.Instance.MainChar.Visible = false;
                    m_curShadowDistance = QualitySettings.shadowDistance;
                    QualitySettings.shadowDistance = 1000.0f;
                }
                else
                {
                    ICameraHelper.Instance.SwitchController(CameraControlMode.ThreeCamera);
                    if (!UIManager.Instance.ToggleSwitchUI())
                    {
                        UIManager.Instance.ToggleSwitchUI();
                    }
                    GameScene.Instance.MainChar.Visible = true;
                    QualitySettings.shadowDistance = m_curShadowDistance;
                    
                    // 重新设置玩家位置到摄像机的位置
                    //var curpos = CameraController.Instance.GetCameraPosition();
                    //curpos += LayeredSceneLoader.WorldOffset;
                    //curpos += Quaternion.FromToRotation(Vector3.forward, CameraController.Instance.Direction)* (Vector3.forward * CameraController.Instance.CurDistance);

                    //GameScene.Instance.MainChar.Position = curpos;
                    //x2m.GmCommand cmd = new x2m.GmCommand();
                    //cmd.command = string.Format("goto {0} {1} {2}", curpos.x, curpos.y, curpos.z);
                    //MsgDispatcher.instance.SendPackage(cmd);
                }
            }
        }
    }
}