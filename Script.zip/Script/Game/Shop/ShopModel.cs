
using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    class ShopModel : ClientSingleton<ShopModel>
    {
        #region 变量

        /// <summary>
        /// 商店页签
        /// </summary>
        private List<ShopPageData> m_ShopPageList = new List<ShopPageData>(Const.kCap8);


        /// <summary>
        /// 商城页签
        /// </summary>
        private List<ShopPageData> m_ShopMallPageList = new List<ShopPageData>(Const.kCap8);

        /// <summary>
        /// 临时页签信息
        /// </summary>
        private List<ShopPageData> m_ShopTempPageList = new List<ShopPageData>(Const.kCap8);

        /// <summary>
        /// 接收网络消息
        /// </summary>
        /// <param name="_msg"></param>
        private swm.RspShopInfoT m_recvRspShopInfo = new swm.RspShopInfoT();

        /// <summary>
        /// 接收商店
        /// </summary>
        /// <param name="_msg"></param>
        private swm.RspShopGoodsInfoT m_recvRspShopGoodsInfo = new swm.RspShopGoodsInfoT();

        /// <summary>
        /// 请求出售单个物品
        /// </summary>
        private swm.ReqSellShopGoodsT m_sendReqSellShopGoods;

        public List<ShopPageData> ShopPageList
        {
            get
            {
                return m_ShopPageList;
            }
        }

        public List<ShopPageData> ShopMallPageList
        {
            get
            {
                return m_ShopMallPageList;
            }
        }

        public class ShopPageNetEvent : GameEvent<swm.RspShopInfoT>
        {

        }

        public class ShopGoodsNetEvent :GameEvent<swm.RspShopGoodsInfoT, List<swm.ShopGoodsT>>
        {

        }
        public class RefreshShopGoodsInfoEvent :GameEvent<swm.RefreshShopGoodsInfo>
        {

        }

        /// <summary>
        /// 通用事件
        /// </summary>
        public ShopPageNetEvent onGetShopPageNetEvent = new ShopPageNetEvent();

        /// <summary>
        /// 通用获得物品事件
        /// </summary>
        public ShopGoodsNetEvent onGetShopGoodsNetEvent = new ShopGoodsNetEvent();

        /// <summary>
        /// 刷新商品信息
        /// </summary>
        public RefreshShopGoodsInfoEvent onRefreshShopGoodsInfoEvent = new RefreshShopGoodsInfoEvent();

        private List<ShopItemData> m_shopDataList = new List<ShopItemData>(0);

        #endregion

        #region 内置

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspShopInfo>(ProcRefreshShopInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspShopGoodsInfo>(ProcRspShopGoodsInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshShopGoodsInfo>(ProcRefreshShopGoodsInfo); 
        }

        /// <summary>
        /// 加载配置数据;
        /// </summary>
        [XLua.BlackList]
        public void Load()
        {
            ShopTableManager.Load();

            ShopTableBaseList list = ShopTableManager.Instance.m_DataList;
            for (int i = 0, count = list.ShopTableLength; i < count; ++i)
            {
                ShopTableBase table = list.ShopTable(i).Value;

                ShopItemData one = new ShopItemData();
                one.id = table.id;
                one.good_id = table.good_id;
                one.slot = table.slot;

                one.unlockKey = table.unlock(0).Value.key;
                one.unlockValue = int.Parse(table.unlock(0).Value.value);

                m_shopDataList.Add(one);
            }
        }

        /// <summary>
        /// 清除所有数据
        /// </summary>
        [XLua.BlackList]
        public void Clear()
        {
            m_ShopTempPageList.Clear();

            for (int i=0;i<m_ShopPageList.Count;i++)
            {
               m_ShopPageList[i].Destory();
            }
            m_ShopPageList.Clear();

            for(int i=0;i<m_ShopMallPageList.Count;i++)
            {
                m_ShopMallPageList[i].Destory();
            }
            m_ShopMallPageList.Clear();
        }

        #endregion

        #region 函数

        /// <summary>
        /// 检查是否存在pageid
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public ShopPageData CheckIsHasShopPageById(ulong _id)
        {
            ShopPageData _data = null;
            for (int i = 0; i < m_ShopPageList.Count; i++)
            {
                _data = m_ShopPageList[i];
                if (_data.PageId == _id)
                {
                    return _data;
                }
            }

            return null;
        }

        /// <summary>
        /// 获取商店的第一个有数据的id
        /// </summary>
        /// <returns></returns>
        public ulong GetFirstShopPageId()
        {
            ulong _id = 0;
            ShopPageData _data = null;
            for (int i = 0; i < m_ShopPageList.Count; i++)
            {
                _data = m_ShopPageList[i];
                if (!_data.IsHasMainPage)
                {
                    _id = _data.PageId;
                    break;
                }
            }

            return _id;
        }

        public ShopPageData GetShopMallPageDataById(ulong _id)
        {
            return GetShopPageDataById(_id, m_ShopMallPageList);
        }

        /// <summary>
        /// 从列表中获取一个shoppagedata
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_list"> 如果为null  就会默认找m_ShopPageList</param>
        /// <returns></returns>
        public ShopPageData GetShopPageDataById(ulong _id, List<ShopPageData> _list = null)
        {
            ShopPageData _data = null;
            if (null == _list)
            {
                _list = m_ShopPageList;
            }

            for (int i = 0; i < _list.Count; i++)
            {
                _data = _list[i];
                if (_id == _data.PageId)
                {
                    return _data;
                }
            }

            return null;
        }

        /// <summary>
        /// 刷新相关页签列表
        /// </summary>
        /// <param name="_msg"></param>
        /// <param name="_list"></param>
        /// <returns></returns>
        private bool RefreshShopPageByNetData(swm.RspShopInfo _msg, List<ShopPageData> _list)
        {
            bool _bIsHasShopPageChange = false;
            ShopPageData _data = null;
            m_ShopTempPageList.Clear();
            for (int i = 0; i < _list.Count; i++)
            {
                m_ShopTempPageList.Add(_list[i]);
            }

            _list.Clear();
            //x2m.ShopPage _page = null;
            for (int j = 0; j < _msg.pagesLength; j++)
            {
                var _page = _msg.pages(j).Value;
                _data = GetShopPageDataById(_page.page_id, m_ShopTempPageList);
                if (null != _data)
                {
                    _data.RefreshNetData(_page);
                    _list.Add(_data);
                    m_ShopTempPageList.Remove(_data);
                }
                else
                {
                    _data = new ShopPageData();
                    _data.RefreshNetData(_page);
                    _list.Add(_data);
                    _bIsHasShopPageChange = true;
                }
            }

            if (m_ShopTempPageList.Count > 0)
            {
                _bIsHasShopPageChange = true;
                for (int k = 0; k < m_ShopTempPageList.Count; k++)
                {
                    m_ShopTempPageList[k].Destory();
                }
                m_ShopTempPageList.Clear();
            }

            return _bIsHasShopPageChange;
        }

        #endregion

        #region 消息

        private void ProcRefreshShopInfo(swm.RspShopInfo _msg)
        {
            m_recvRspShopInfo.FromMsg(_msg);

            // 检查商店页签
 //           if (_msg.shop_id == 1)
//            {
                RefreshShopPageByNetData(_msg, m_ShopPageList);
//            }
//             else if(_msg.shop_id == 2)
//             {
//                 RefreshShopPageByNetData(_msg, m_ShopMallPageList);
//             }

            onGetShopPageNetEvent.Invoke(m_recvRspShopInfo);
        }

        private void ProcRspShopGoodsInfo(swm.RspShopGoodsInfo _msg)
        {
            m_recvRspShopGoodsInfo.FromMsg(_msg);
            onGetShopGoodsNetEvent.Invoke(m_recvRspShopGoodsInfo, m_recvRspShopGoodsInfo.goods);
        }

        /// <summary>
        /// 接收 刷新商品信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshShopGoodsInfo(swm.RefreshShopGoodsInfo _msg)
        {
            onRefreshShopGoodsInfoEvent.Invoke(_msg);
        }

        /// <summary>
        /// 发送 请求打开商店
        /// </summary>
        /// <param name="_shopid">默认 0 就不是商店 </param>
        /// /// <param name="_npcid">默认0 就不是访问的npc商店</param>
        public void SendReqOpenShop(ulong _shopid=0, ulong _npcid = 0)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqShopInfo.StartReqShopInfo(fbb);

            if (0 != _npcid)
            {
                swm.ReqShopInfo.AddNpcId(fbb, _npcid);
            }

            if(0 != _shopid)
            {
                swm.ReqShopInfo.AddShopId(fbb, _shopid);
            }

            fbb.Finish(swm.ReqShopInfo.EndReqShopInfo(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqShopInfo.HashID, fbb);
        }

        /// <summary>
        /// 发送 请求页签物品列表
        /// </summary>
        /// <param name="_shopid"></param>
        /// <param name="_pageid"></param>
        public void SendReqShopGoodsInfop(ulong _shopid = 0, ulong _pageid = 0)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqShopGoodsInfo.StartReqShopGoodsInfo(fbb);
            swm.ReqShopGoodsInfo.AddPageId(fbb, _pageid);
            swm.ReqShopGoodsInfo.AddShopId(fbb, _shopid);
            fbb.Finish(swm.ReqShopGoodsInfo.EndReqShopGoodsInfo(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqShopGoodsInfo.HashID, fbb);
        }

        /// <summary>
        /// 发送 请求购买货物
        /// </summary>
        /// <param name="_goodid"></param>
        /// <param name="_num"></param>
        public void SendReqBuyShopGoods(ulong _goodid,uint _num)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqBuyShopGoods.StartReqBuyShopGoods(fbb);
            swm.ReqBuyShopGoods.AddGoodsId(fbb, _goodid);
            swm.ReqBuyShopGoods.AddGoodsNum(fbb, _num);
            fbb.Finish(swm.ReqBuyShopGoods.EndReqBuyShopGoods(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqBuyShopGoods.HashID, fbb);
        }

        /// <summary>
        /// 发送 请求出售单个物品
        /// </summary>
        /// <param name="_itemId"></param>
        /// <param name="_num"></param>
        public void SendReqSellShopGoods(ulong _itemId, uint _num)
        {
            if(m_sendReqSellShopGoods==null)
            {
                m_sendReqSellShopGoods = new swm.ReqSellShopGoodsT()
                {
                    goods = new List<swm.SellShopGoodsInfoT>(1) { new swm.SellShopGoodsInfoT() }
                };
            }

            m_sendReqSellShopGoods.goods[0].itemid = _itemId;
            m_sendReqSellShopGoods.goods[0].itemnum = _num;
            MsgDispatcher.instance.SendFBPackage(m_sendReqSellShopGoods);
        }

        #endregion


        public ShopItemData GetShopItemData(int shopId, int good_id)
        {
            foreach(var item in m_shopDataList)
            {
                if (item.id == shopId && item.good_id == good_id)
                {
                    return item;
                }
            }

            return null;
        }

        public class ShopItemData
        {
            public int id;
            public int good_id;
            public int slot;
            public int unlockKey;
            public int unlockValue;
        }
    }
}
