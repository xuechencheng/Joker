﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bokura
{
    class ShopPageData
    {
        private ulong m_PageId = 0;
        private swm.ShopPageT m_NetPageData = null;
        private bool m_bIsHasMainPage = false;
        public bool IsHasMainPage
        {

            get
            {
                return m_bIsHasMainPage;
            }

        }
        public swm.ShopPageT NetPageData
        {
            get
            {
                return m_NetPageData;
            }
            set
            {
                m_NetPageData = value;
            }
        }
        public ulong PageId
        {
            get
            {
                return m_PageId;
            }
            set
            {
                m_PageId = value;
            }
        }

        public void RefreshNetData(swm.ShopPage _data)
        {
            PageId = _data.page_id;
            m_bIsHasMainPage = _data.main_page != 0;
            if (m_NetPageData == null)
                m_NetPageData = new swm.ShopPageT();
            m_NetPageData.FromMsg(_data);
        }

        public void Destory()
        {
            m_NetPageData = null;
            m_PageId = 0;
        }
    }
}
