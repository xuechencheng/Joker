using UnityEngine;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using FlatBuffers;

namespace Bokura
{
    public class OfflineViewMsgTamper : INetworkMsgTamper
    {
        private Dictionary<ulong, MethodInfo> m_FBMessageHandlerMap = new Dictionary<ulong, MethodInfo>(24);
        private Dictionary<string, MethodInfo> m_PBMessageHandlerMap = new Dictionary<string, MethodInfo>(4);

        FlatBufferBuilder m_flatBufferBuilder = new FlatBufferBuilder(1024);
        private ulong Player_Entity_ID = 72057594037963047;

        public OfflineViewMsgTamper()
        {
            Type type = this.GetType();
            var methodInfos = type.GetMethods();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < methodInfos.Length; ++i)
            {
                var method = methodInfos[i];
                
                Match fb_match = Regex.Match(method.Name, "FB_(\\w+)_(\\w+)");
                if (fb_match.Success)
                {
                    string ns = fb_match.Groups[1].Value;
                    string clsname = fb_match.Groups[2].Value;
                    sb.Length = 0;
                    sb.AppendFormat("{0}.{1}", ns, clsname);
                    Type typeMsg = Type.GetType(sb.ToString());
                    FieldInfo fi = typeMsg.GetField("HashID");
                    ulong hashID = (ulong)fi.GetValue(null);

                    m_FBMessageHandlerMap.Add(hashID, method);
                }

                Match pb_match = Regex.Match(method.Name, "PB_(\\w+)_(\\w+)");
                if (pb_match.Success)
                {
                    string ns = pb_match.Groups[1].Value;
                    string clsname = pb_match.Groups[2].Value;
                    sb.Length = 0;
                    sb.AppendFormat("{0}.{1}", ns, clsname);
                    string fullName = sb.ToString();

                    Type typeMsg = Type.GetType(fullName);
                    if (typeMsg != null)
                        m_PBMessageHandlerMap.Add(fullName, method);
                }
            }

            FB_swm_ReqLoginAccount(new swm.ReqLoginAccount());
        }

        public FlatBufferBuilder GetFlatBufferBuilder()
        {
            m_flatBufferBuilder.Clear();
            return m_flatBufferBuilder;
        }

        public bool OnReceiveFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size)
        {
            return false;
        }

        public bool OnReceiveProtobufPackage(ref object msg)
        {
            return false;
        }

        public bool OnSendFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size)
        {
            MethodInfo method;
            if (m_FBMessageHandlerMap.TryGetValue(msgid, out method))
            {
                IFlatbufferObject flatObj;
                if (MsgPrintLogger.instance.DecodeFlatBuffer(msgid, bytes, offset, out flatObj))
                {
                    var paramList = new object[] { flatObj };
                    /*bool ret = (bool)*/method.Invoke(this, paramList);
                }
            }
            return false;
        }

        //public bool OnSendProtobufPackage(string protoname, ref byte[] luaPBData)
        //{
        //    using (var memoryStream = new MemoryStream(luaPBData))
        //    {
        //        Type type = Type.GetType(protoname);
        //        var msg = ProtoBuf.Serializer.Deserialize(type, memoryStream);
        //        MethodInfo method;
        //        if (m_PBMessageHandlerMap.TryGetValue(type.FullName, out method))
        //        {
        //            var paramList = new object[] { msg };
        //            bool ret = (bool)method.Invoke(this, paramList);
        //        }
        //    }
        //    return false;
        //}

        //public bool OnSendProtobufPackage<T>(ref T msg) where T : IExtensible
        //{
        //    Type type = msg.GetType();
        //    MethodInfo method;
        //    if (m_PBMessageHandlerMap.TryGetValue(type.FullName, out method))
        //    {
        //        var paramList = new object[] { msg };
        //        bool ret = (bool)method.Invoke(this, paramList);
        //    }
        //    return false;
        //}

        #region 拦截FlatBuffer消息
        public bool FB_swm_ReqLoginAccount(swm.ReqLoginAccount msg)
        {
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            string servername = "内网测试1";
            StringOffset tNameOffset = tfbb.CreateString(servername);
            Offset<swm.ZoneData> tZoneOffset = swm.ZoneData.CreateZoneData(tfbb, 101, tNameOffset, swm.ZoneState.Idle, true);
            Offset<swm.ZoneData>[] tZoneList = new Offset<swm.ZoneData>[] { tZoneOffset };

            VectorOffset tZoneListOffset = swm.RspLoginAccount.CreateZoneListVector(tfbb, tZoneList);
            swm.RspLoginAccount.StartRspLoginAccount(tfbb);
            swm.RspLoginAccount.AddZoneList(tfbb, tZoneListOffset);
            var rsp = swm.RspLoginAccount.EndRspLoginAccount(tfbb);
            tfbb.Finish(rsp.Value);
            ProcFBMsg(swm.RspLoginAccount.HashID, tfbb);
            return true;
        }

        public bool FB_swm_ReqSelectZone(swm.ReqSelectZone msg)
        {
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            StringOffset taddrOffset = tfbb.CreateString("127.0.0.1");
            Offset<swm.RspSelectZone> tOffset = swm.RspSelectZone.CreateRspSelectZone(tfbb, swm.SelectZoneErrorCode.Ok, 596516650, taddrOffset, 8080);
            tfbb.Finish(tOffset.Value);
            ProcFBMsg(swm.RspSelectZone.HashID, tfbb);
            return true;
        }

        public bool FB_swm_ReqLoginGame(swm.ReqLoginGame msg)
        {
            GameApplication.Instance.GetTimerManager().AddTimer(ProcRspLoginGame, 0.1f);
            return true;
        }

        public bool FB_swm_ReqSelectRole(swm.ReqSelectRole msg)
        {
            GameApplication.Instance.GetTimerManager().AddTimer(ProcRspSyncMainUserData, 0.1f);
            GameApplication.Instance.GetTimerManager().AddTimer(delegate ()
            {
                ProcInToMap(3, 1, 2893.0f, 329.0f, -1627.0f);
            }, 0.2f);
            return true;
        }

        public bool FB_swm_MapTeleport(swm.MapTeleport msg)
        {
            int id = (int)msg.teleportid;
            WorldTransTableBase? v = WorldTransTableManager.GetData(id);
            if (v.HasValue)
            {
                try
                {
                    WorldTransTableBase config = v.Value;
                    string[] posStr = config.map_pos.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    Vector3 pos;
                    pos.x = float.Parse(posStr[0]);
                    pos.y = float.Parse(posStr[1]);
                    pos.z = float.Parse(posStr[2]);
                    string[] dirStr = config.map_dir.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    Vector3 dir;
                    dir.x = float.Parse(dirStr[0]);
                    dir.y = float.Parse(dirStr[1]);
                    dir.z = float.Parse(dirStr[2]);
                    ProcBlinkTo(GameScene.Instance.MainChar.Position, pos, dir);
                }
                catch (Exception e)
                {
                    Bokura.LogHelper.LogError("解析传送地图信息出错. exception:" + e.Message);
                }
            }
            return true;
        }
        
        private uint curSpeed = 5000;
        private const uint Max_Speed = 45000;
        private const uint Min_Speed = 5000;
        public bool FB_swm_GmCommand(swm.GmCommand msg)
        {
            if (StringStartWith(msg.command, "speed 1"))
            {
                string[] str_command = msg.command.Split(new char[] { ' ' });
                uint addSpeed = 10;
                if (str_command.Length == 3)
                    addSpeed = uint.Parse(str_command[2]);
                FlatBufferBuilder tfbb = GetFlatBufferBuilder();
                if (curSpeed < Max_Speed)
                    curSpeed += addSpeed;
                var rsp = swm.RefreshEntityMoveSpeed.CreateRefreshEntityMoveSpeed(tfbb,  Player_Entity_ID, curSpeed);
                tfbb.Finish(rsp.Value);
                ProcFBMsg(swm.RefreshEntityMoveSpeed.HashID, tfbb);
                GameScene.Instance.MainChar.AdjustSpeed = curSpeed;
                GameScene.Instance.MainChar.AdjustTargetSpeed = curSpeed;
            }
            else if (StringStartWith(msg.command, "speed 0"))
            {
                string[] str_command = msg.command.Split(new char[] { ' ' });
                uint addSpeed = 10;
                if (str_command.Length == 3)
                    addSpeed = uint.Parse(str_command[2]);
                FlatBufferBuilder tfbb = GetFlatBufferBuilder();
                if (curSpeed > Min_Speed)
                    curSpeed -= addSpeed;
                var rsp = swm.RefreshEntityMoveSpeed.CreateRefreshEntityMoveSpeed(tfbb,Player_Entity_ID, curSpeed);
                tfbb.Finish(rsp.Value);
                ProcFBMsg(swm.RefreshEntityMoveSpeed.HashID, tfbb);
                GameScene.Instance.MainChar.AdjustSpeed = curSpeed;
                GameScene.Instance.MainChar.AdjustTargetSpeed = curSpeed;
            }
            else if (StringStartWith(msg.command, "goto "))
            {
                string dstParam = msg.command.Substring(5);
                string[] paramArray = dstParam.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                if (paramArray.Length == 3)
                {
                    try
                    {
                        Vector3 dstPos = new Vector3();
                        dstPos.x = float.Parse(paramArray[0]);
                        dstPos.y = float.Parse(paramArray[1]);
                        dstPos.z = float.Parse(paramArray[2]);
                        ProcBlinkTo(GameScene.Instance.MainChar.Position, dstPos, Vector3.zero);
                    }
                    catch (Exception e)
                    {
                        Bokura.LogHelper.LogError("解析goto位置失败. exception:" + e.Message);
                    }
                }
            }
            return true;
        }
        #endregion

        #region 消息处理
        public static void ProcFBMsg(ulong msgId, FlatBufferBuilder tfbb)
        {
            byte[] bytes = tfbb.DataBuffer.RawBuffer;
            int offset = tfbb.DataBuffer.Position;
            int size = tfbb.DataBuffer.Length - tfbb.DataBuffer.Position;
            MsgDispatcher.instance.ProcFlatBufferPackage(msgId, bytes, offset, size);
        }

        //public void ProcPBMsg(string typeFullName, object msg)
        //{
        //    Type t = Type.GetType(typeFullName);
        //    MsgDispatcher.instance.ProcPackage(t, msg);
        //}

        void ProcRspLoginGame()
        {
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            StringOffset tNameOffset = tfbb.CreateString("小虾米");
            uint[] fashion_data = new uint[] { 97, 102, 0, 0, 0, 0 };
            VectorOffset tfashionOffset = swm.SelectRoleBase.CreateFashionDataVector(tfbb, fashion_data);
            Offset<swm.SelectRoleBase> tSRBOffset = swm.SelectRoleBase.CreateSelectRoleBase(tfbb, Player_Entity_ID, tNameOffset,
                swm.CareerType.Warrior, swm.CareerSex.Male, 1, swm.RoleDataStatus.Normal, 1560652933, default(VectorOffset), tfashionOffset,
                1560495520, 0);
            Offset<swm.SelectRoleBase>[] tRoleList = new Offset<swm.SelectRoleBase>[] { tSRBOffset };
            VectorOffset tRoleListOffset = swm.RspRoleList.CreateRoleListVector(tfbb, tRoleList);
            swm.RspRoleList.StartRspRoleList(tfbb);
            swm.RspRoleList.AddRoleList(tfbb, tRoleListOffset);
            swm.RspRoleList.AddResult(tfbb, 0);
            var rsp = swm.RspRoleList.EndRspRoleList(tfbb);
            tfbb.Finish(rsp.Value);
            ProcFBMsg(swm.RspRoleList.HashID, tfbb);
        }

        private void ProcRspSyncMainUserData()
        {
            var maindata = new swm.SyncMainUserDataT();
            
            maindata.entity_id = Player_Entity_ID;
            maindata.model_radius = 1.0f;
            maindata.model_radius2 = 2.0f;
            maindata.max_hp = maindata.cur_hp = 2640;
            maindata.max_mp = 20;
            maindata.max_ap = 100;
            maindata.cur_pos = new swm.Vector3T() { x = 2893.0f, y = 329.0f, z = -1627.0f };
            maindata.cur_dir = new swm.Vector3T() { x = 0.0f, y = 0.0f, z = 1.0f };
            var attdata = new swm.MapEntityAttrsT();

            attdata.attack_speed = 1000;
            attdata.move_speed = 5000;
            attdata.crit_effect = 0.5f;
            attdata.crit_pct = 0.1639f;
            attdata.max_mdam = 11;
            attdata.min_mdam = 9;
            attdata.max_pdam = 46;
            attdata.min_pdam = 37;
            attdata.prop_dex = 10;
            attdata.prop_sta = 32;
            attdata.prop_int = 10;
            attdata.prop_str = 32;
            maindata.attrs = attdata;

            var userdata = new swm.MapUserT();
            userdata.career_sex = swm.CareerSex.Male;
            userdata.career_type = swm.CareerType.Warrior;
            maindata.user_data = userdata;

            FlatBufferBuilder tfbb = GetFlatBufferBuilder();

            tfbb.Finish(maindata.ToMsg(tfbb));
            ProcFBMsg(swm.SyncMainUserData.HashID, tfbb);

            /*
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            StringOffset tNameOffset = tfbb.CreateString("小虾米");
            
            var mapUserData = swm.MapUser.CreateMapUser(tfbb, swm.CareerType.Warrior, swm.CareerSex.Male, 0, true, 0, 0, 0, 0,
                swm.PKModeType.Peace);
            swm.MapEntityAttrs.StartMapEntityAttrs(tfbb);
            swm.MapEntityAttrs.AddProfInspiration(tfbb, 0);
            swm.MapEntityAttrs.AddProfTechnique(tfbb, 0);
            swm.MapEntityAttrs.AddProfArmforce(tfbb, 0);
            swm.MapEntityAttrs.AddCooldownDec(tfbb, 0);
            swm.MapEntityAttrs.AddAttackSpeed(tfbb, 1000);
            swm.MapEntityAttrs.AddMoveSpeed(tfbb, 5000);
            swm.MapEntityAttrs.AddSufCritEffectDec(tfbb, 0);
            swm.MapEntityAttrs.AddSufHealPct(tfbb, 0);
            swm.MapEntityAttrs.AddHealPct(tfbb, 0);
            swm.MapEntityAttrs.AddSufRangedDpct(tfbb, 0);
            swm.MapEntityAttrs.AddSufMeleeDpct(tfbb, 0);
            swm.MapEntityAttrs.AddRangedPct(tfbb, 0);
            swm.MapEntityAttrs.AddMeleePct(tfbb, 0);
            swm.MapEntityAttrs.AddRenew(tfbb, 0);
            swm.MapEntityAttrs.AddAttackRenew(tfbb, 0);
            swm.MapEntityAttrs.AddCritEffect(tfbb, 0.5f);
            swm.MapEntityAttrs.AddCritPct(tfbb, 0.1639f);
            swm.MapEntityAttrs.AddMpenPct(tfbb, 0);
            swm.MapEntityAttrs.AddPpenPct(tfbb, 0);
            swm.MapEntityAttrs.AddMpen(tfbb, 0);
            swm.MapEntityAttrs.AddPpen(tfbb, 0);
            swm.MapEntityAttrs.AddMaxMdam(tfbb, 11);
            swm.MapEntityAttrs.AddMinMdam(tfbb, 9);
            swm.MapEntityAttrs.AddMaxPdam(tfbb, 46);
            swm.MapEntityAttrs.AddMinPdam(tfbb, 37);
            swm.MapEntityAttrs.AddMdef(tfbb, 0);
            swm.MapEntityAttrs.AddPdef(tfbb, 0);
            swm.MapEntityAttrs.AddPropDex(tfbb, 10);
            swm.MapEntityAttrs.AddPropSta(tfbb, 32);
            swm.MapEntityAttrs.AddPropInt(tfbb, 10);
            swm.MapEntityAttrs.AddPropStr(tfbb, 22);
            var MEAOffset = swm.MapEntityAttrs.EndMapEntityAttrs(tfbb);

            swm.SyncMainUserData.StartSyncMainUserData(tfbb);
            swm.SyncMainUserData.AddIsNewuser(tfbb, false);
            swm.SyncMainUserData.AddEntityId(tfbb, Player_Entity_ID);
            swm.SyncMainUserData.AddName(tfbb, tNameOffset);
            swm.SyncMainUserData.AddLevel(tfbb, 1);
            swm.SyncMainUserData.AddExp(tfbb, 0);
            swm.SyncMainUserData.AddModelRadius(tfbb, 1.0f);
            swm.SyncMainUserData.AddModelRadius2(tfbb, 2.0f);
            swm.SyncMainUserData.AddMaxHp(tfbb, 2640);
            swm.SyncMainUserData.AddCurHp(tfbb, 2640);
            swm.SyncMainUserData.AddMaxMp(tfbb, 20);
            swm.SyncMainUserData.AddCurMp(tfbb, 0);
            swm.SyncMainUserData.AddMaxAp(tfbb, 100);
            swm.SyncMainUserData.AddCurAp(tfbb, 0);
            swm.SyncMainUserData.AddMaxEp(tfbb, 0);
            swm.SyncMainUserData.AddCurEp(tfbb, 0);
            swm.SyncMainUserData.AddMaxQp(tfbb, 0);
            swm.SyncMainUserData.AddCurQp(tfbb, 0);
            swm.SyncMainUserData.AddCurPos(tfbb, swm.Vector3.CreateVector3(tfbb, 2893.0f, 329.0f, -1627.0f));
            swm.SyncMainUserData.AddCurDir(tfbb, swm.Vector3.CreateVector3(tfbb, 0.0f, 0.0f, 0.0f));
            swm.SyncMainUserData.AddUserData(tfbb, mapUserData);
            swm.SyncMainUserData.AddAttrs(tfbb, MEAOffset);
            swm.SyncMainUserData.AddCurtime(tfbb, 0);
            var rsp = swm.SyncMainUserData.EndSyncMainUserData(tfbb);
            tfbb.Finish(rsp.Value);
            
            
            ProcFBMsg(swm.SyncMainUserData.HashID, tfbb);
            */
        }

        void ProcInToMap(uint mapBaseId, uint mapId, float x, float y, float z)
        {
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            swm.IntoMap.StartIntoMap(tfbb);
            swm.IntoMap.AddMapBaseid(tfbb, mapBaseId);
            swm.IntoMap.AddMapId(tfbb, mapId);
            swm.IntoMap.AddPos(tfbb, swm.Vector3.CreateVector3(tfbb, x, y, z));
            swm.IntoMap.AddDir(tfbb, swm.Vector3.CreateVector3(tfbb, 0.0f, 0.0f, 0.0f));
            var rsp = swm.IntoMap.EndIntoMap(tfbb);
            tfbb.Finish(rsp.Value);
            ProcFBMsg(swm.IntoMap.HashID, tfbb);
            //GameApplication.Instance.GetTimerManager().AddTimer(ProcNotifySkillPlan, 0.1f);
        }

        /*void ProcNotifySkillPlan()
        {
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            StringOffset tName1Offset = tfbb.CreateString("方案0");
            StringOffset tName2Offset = tfbb.CreateString("方案1");
            StringOffset tName3Offset = tfbb.CreateString("方案2");
            StringOffset tName4Offset = tfbb.CreateString("方案3");
            StringOffset tName5Offset = tfbb.CreateString("方案4");
            StringOffset tName6Offset = tfbb.CreateString("方案5");

            Offset<swm.SkillSlot> offset_skill_1 = swm.SkillSlot.CreateSkillSlot(tfbb, 0, 1011011);
            Offset<swm.SkillSlot> offset_skill_2 = swm.SkillSlot.CreateSkillSlot(tfbb, 1, 1011061);
            Offset<swm.SkillSlot> offset_skill_3 = swm.SkillSlot.CreateSkillSlot(tfbb, 2, 1011031);
            Offset<swm.SkillSlot> offset_skill_4 = swm.SkillSlot.CreateSkillSlot(tfbb, 3, 1011111);
            Offset<swm.SkillSlot> offset_skill_5 = swm.SkillSlot.CreateSkillSlot(tfbb, 4, 1011051);
            Offset<swm.SkillSlot> offset_skill_6 = swm.SkillSlot.CreateSkillSlot(tfbb, 5, 1011141);
            Offset<swm.SkillSlot> offset_skill_7 = swm.SkillSlot.CreateSkillSlot(tfbb, 6, 1011021);
            Offset<swm.SkillSlot>[] offset_skill_array = new Offset<swm.SkillSlot>[] {offset_skill_1, offset_skill_2, offset_skill_3,
                offset_skill_4, offset_skill_5, offset_skill_6, offset_skill_7 };
            VectorOffset offset_skills = swm.SkillPlan.CreateSkillsVector(tfbb, offset_skill_array);

            Offset<swm.SkillPlan> offset_plan1 = swm.SkillPlan.CreateSkillPlan(tfbb, tName1Offset, 0, offset_skills);
            Offset<swm.SkillPlan> offset_plan2 = swm.SkillPlan.CreateSkillPlan(tfbb, tName2Offset, 1, offset_skills);
            Offset<swm.SkillPlan> offset_plan3 = swm.SkillPlan.CreateSkillPlan(tfbb, tName3Offset, 2, offset_skills);
            Offset<swm.SkillPlan> offset_plan4 = swm.SkillPlan.CreateSkillPlan(tfbb, tName4Offset, 3, offset_skills);
            Offset<swm.SkillPlan> offset_plan5 = swm.SkillPlan.CreateSkillPlan(tfbb, tName5Offset, 4, offset_skills);
            Offset<swm.SkillPlan> offset_plan6 = swm.SkillPlan.CreateSkillPlan(tfbb, tName6Offset, 5, offset_skills);
            Offset<swm.SkillPlan>[] offset_skillplan_array = new Offset<swm.SkillPlan>[] {offset_plan1, offset_plan2, offset_plan3,
                offset_plan4, offset_plan5, offset_plan6 };
            VectorOffset offset_plans = swm.NotifySkillPlan.CreatePlansVector(tfbb, offset_skillplan_array);

            swm.NotifySkillPlan.StartNotifySkillPlan(tfbb);
            swm.NotifySkillPlan.AddCurPlanid(tfbb, 0);
            swm.NotifySkillPlan.AddPlans(tfbb, offset_plans);
            var rsp = swm.NotifySkillPlan.EndNotifySkillPlan(tfbb);
            tfbb.Finish(rsp.Value);
            
            ProcFBMsg(swm.NotifySkillPlan.HashID, tfbb);
        }*/

        void ProcBlinkTo(Vector3 fromPos, Vector3 toPos, Vector3 dir)
        {
            FlatBufferBuilder tfbb = GetFlatBufferBuilder();
            swm.BlinkTo.StartBlinkTo(tfbb);
           // swm.BlinkTo.AddEntityType(tfbb, swm.EntityType.Unknown);
            swm.BlinkTo.AddEntityId(tfbb, Player_Entity_ID);
            swm.BlinkTo.AddFromPos(tfbb, swm.Vector3.CreateVector3(tfbb, fromPos.x, fromPos.y, fromPos.z));
            swm.BlinkTo.AddToPos(tfbb, swm.Vector3.CreateVector3(tfbb, toPos.x, toPos.y, toPos.z));
            swm.BlinkTo.AddType(tfbb, swm.BlinkType.GOTO);
            swm.BlinkTo.AddSpeed(tfbb, 0);
            swm.BlinkTo.AddDelayTime(tfbb, 0);
            swm.BlinkTo.AddToDir(tfbb, swm.Vector3.CreateVector3(tfbb, dir.x, dir.y, dir.z));
            var rsp = swm.BlinkTo.EndBlinkTo(tfbb);
            tfbb.Finish(rsp.Value);
            ProcFBMsg(swm.BlinkTo.HashID, tfbb);
        }
        #endregion

        bool StringStartWith(string testStr, string matchStr)
        {
            char[] testArray = testStr.ToCharArray();
            char[] matchArray = matchStr.ToCharArray();
            if (testArray.Length < matchArray.Length)
                return false;
            for (int i = 0; i < matchArray.Length; i++)
            {
                if (testArray[i] != matchArray[i])
                    return false;
            }
            return true;
        }


    }
}