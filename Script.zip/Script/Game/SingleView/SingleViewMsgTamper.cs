﻿using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using FlatBuffers;

namespace Bokura
{
    public class SingleViewMsgTamper : INetworkMsgTamper
    {
        private Dictionary<ulong, MethodInfo> m_FBMessageHandlerMap = new Dictionary<ulong, MethodInfo>(24);
        private Dictionary<string, MethodInfo> m_PBMessageHandlerMap = new Dictionary<string, MethodInfo>(4);

        FlatBufferBuilder m_flatBufferBuilder = new FlatBufferBuilder(1024);

        public SingleViewMsgTamper()
        {
            Type type = this.GetType();
            var methodInfos = type.GetMethods();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < methodInfos.Length; ++i)
            {
                var method = methodInfos[i];

                Match fb_match = Regex.Match(method.Name, "FB_(\\w+)_(\\w+)");
                if (fb_match.Success)
                {
                    string ns = fb_match.Groups[1].Value;
                    string clsname = fb_match.Groups[2].Value;
                    sb.Length = 0;
                    sb.AppendFormat("{0}.{1}", ns, clsname);
                    Type typeMsg = Type.GetType(sb.ToString());
                    FieldInfo fi = typeMsg.GetField("HashID");
                    ulong hashID = (ulong)fi.GetValue(null);

                    m_FBMessageHandlerMap.Add(hashID, method);
                }

                Match pb_match = Regex.Match(method.Name, "PB_(\\w+)_(\\w+)");
                if (pb_match.Success)
                {
                    string ns = pb_match.Groups[1].Value;
                    string clsname = pb_match.Groups[2].Value;
                    sb.Length = 0;
                    sb.AppendFormat("{0}.{1}", ns, clsname);
                    string fullName = sb.ToString();

                    Type typeMsg = Type.GetType(fullName);
                    if (typeMsg != null)
                        m_PBMessageHandlerMap.Add(fullName, method);
                }
            }
        }

        public FlatBufferBuilder GetFlatBufferBuilder()
        {
            m_flatBufferBuilder.Clear();
            return m_flatBufferBuilder;
        }

        public bool OnReceiveFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size)
        {
            MethodInfo method;
            if (m_FBMessageHandlerMap.TryGetValue(msgid, out method))
            {
                IFlatbufferObject flatObj;
                FlatBufferBuilder tfbb = GetFlatBufferBuilder();
                if (MsgPrintLogger.instance.DecodeFlatBuffer(msgid, bytes, offset, out flatObj))
                {
                    var paramList = new object[] { flatObj, tfbb };
                    bool ret = (bool)method.Invoke(this, paramList);
                    tfbb = (FlatBufferBuilder)paramList[1];
                    if (ret)
                    {
                        bytes = tfbb.DataBuffer.RawBuffer;
                        offset = tfbb.DataBuffer.Position;
                        size = tfbb.DataBuffer.Length - tfbb.DataBuffer.Position;
                    }
                    return true;
                }
            }
            return false;
        }

        public bool OnReceiveProtobufPackage(ref object msg)
        {
            Type type = msg.GetType();
            MethodInfo method;
            if (m_PBMessageHandlerMap.TryGetValue(type.FullName, out method))
            {
                var paramList = new object[] { msg };
                bool ret = (bool)method.Invoke(this, paramList);
                if (ret)
                {
                    msg = paramList[0];
                }
                return true;
            }
            return false;
        }

        public bool OnSendFBPackage(ulong msgid, ref byte[] bytes, ref int offset, ref int size)
        {
            MethodInfo method;
            if (m_FBMessageHandlerMap.TryGetValue(msgid, out method))
            {
                IFlatbufferObject flatObj;
                FlatBufferBuilder tfbb = GetFlatBufferBuilder();
                if (MsgPrintLogger.instance.DecodeFlatBuffer(msgid, bytes, offset, out flatObj))
                {
                    var paramList = new object[] { flatObj, tfbb };
                    bool ret = (bool)method.Invoke(this, paramList);
                    tfbb = (FlatBufferBuilder)paramList[1];
                    if (ret)
                    {
                        bytes = tfbb.DataBuffer.RawBuffer;
                        offset = tfbb.DataBuffer.Position;
                        size = tfbb.DataBuffer.Length - tfbb.DataBuffer.Position;
                    }
                    return true;
                }
            }
            return false;
        }

        //public bool OnSendProtobufPackage(string protoname, ref byte[] luaPBData)
        //{
        //    using (var memoryStream = new MemoryStream(luaPBData))
        //    {
        //        Type type = Type.GetType(protoname);
        //        var msg = ProtoBuf.Serializer.Deserialize(type, memoryStream);
        //        MethodInfo method;
        //        if (m_PBMessageHandlerMap.TryGetValue(type.FullName, out method))
        //        {
        //            var paramList = new object[] { msg };
        //            bool ret = (bool)method.Invoke(this, paramList);
        //            if (ret)
        //            {
        //                msg = paramList[0];
        //                using (var ms2 = new MemoryStream())
        //                {
        //                    ProtoBuf.Serializer.Serialize(ms2, msg);
        //                    luaPBData = ms2.ToArray();
        //                }
        //            }
        //            return true;
        //        }
        //    }
        //    return false;
        //}

        //public bool OnSendProtobufPackage<T>(ref T msg) where T : IExtensible
        //{
        //    Type type = msg.GetType();
        //    MethodInfo method;
        //    if (m_PBMessageHandlerMap.TryGetValue(type.FullName, out method))
        //    {
        //        var paramList = new object[] { msg };
        //        bool ret = (bool)method.Invoke(this, paramList);
        //        if (ret)
        //        {
        //            msg = (T)paramList[0];
        //        }
        //        return true;
        //    }
        //    return false;
        //}

        #region Flatbuffer消息,返回true表示篡改消息内容,返回false表示不篡改消息内容,未定义在此的FlatBuffer消息不会被发送和接收
        public bool FB_swm_ReqLoginAccount(swm.ReqLoginAccount msg, FlatBufferBuilder tfbb)
        {
            //string account = "map001";
            //string accid = "accid-1-map001";
            //string token = msg.token;
            //string version = msg.version;
            //StringOffset tAccountOffset = tfbb.CreateString(account);
            //StringOffset tAccidOffset = tfbb.CreateString(accid);
            //StringOffset tTokenOffset = tfbb.CreateString(token);
            //StringOffset tVersionOffset = tfbb.CreateString(version);
            //Offset<swm.ReqLoginAccount> tOffset = swm.ReqLoginAccount.CreateReqLoginAccount(tfbb, tAccountOffset, tAccidOffset, tTokenOffset, tVersionOffset);
            //tfbb.Finish(tOffset.Value);
            //return true;
            return false;
        }

        public bool FB_swm_RspLoginAccount(swm.RspLoginAccount msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_ReqSelectZone(swm.ReqSelectZone msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_RspSelectZone(swm.RspSelectZone msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_ReqLoginGame(swm.ReqLoginGame msg, FlatBufferBuilder tfbb)
        {
            //string account = "map001";
            //string accid = "accid-1-map001";
            //string token = msg.token;
            //string version = msg.version;
            //uint secureCode = msg.secure_code;
            //bool isReconnect = msg.is_reconnect;
            //StringOffset tAccountOffset = tfbb.CreateString(account);
            //StringOffset tAccidOffset = tfbb.CreateString(accid);
            //StringOffset tTokenOffset = tfbb.CreateString(token);
            //StringOffset tVersionOffset = tfbb.CreateString(version);
            //Offset<swm.ReqLoginGame> tOffset = swm.ReqLoginGame.CreateReqLoginGame(tfbb, tAccountOffset, tAccidOffset, tTokenOffset, tVersionOffset, secureCode, isReconnect);
            //tfbb.Finish(tOffset.Value);
            //return true;
            return false;
        }

        public bool FB_swm_RspRoleList(swm.RspRoleList msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_ReqCreateRole(swm.ReqCreateRole msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_RspCreateRole(swm.RspCreateRole msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_ReqSelectRole(swm.ReqSelectRole msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_IntoMap(swm.IntoMap msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_SyncMainUserData(swm.SyncMainUserData msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_ReqAck(swm.ReqAck msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_RspAck(swm.RspAck msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_MoveTo(swm.MoveTo msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_MoveToDown(swm.MoveToDown msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_SyncEntityAction(swm.SyncEntityAction msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_FallStart(swm.FallStart msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_FallMove(swm.FallMove msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        //public bool FB_swm_RequestQingKung(swm.RequestQingKung msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_SendQingKungAction(swm.SendQingKungAction msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungMoveTo(swm.QingKungMoveTo msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungMoveToDown(swm.QingKungMoveToDown msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungStart(swm.QingKungStart msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungEnd(swm.QingKungEnd msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_RequestQingKungLand(swm.RequestQingKungLand msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungLand(swm.QingKungLand msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_RequestQingKungForceLand(swm.RequestQingKungForceLand msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungForceLand(swm.QingKungForceLand msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_RequestQingKungPeak(swm.RequestQingKungPeak msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungPeak(swm.QingKungPeak msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_RequestQingKungGliding(swm.RequestQingKungGliding msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_QingKungGliding(swm.QingKungGliding msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        //public bool FB_swm_NotifyQingKungLand(swm.NotifyQingKungLand msg, FlatBufferBuilder tfbb)
        //{
        //    return false;
        //}

        public bool FB_swm_RefreshQingKungPep(swm.RefreshQingKungPep msg, FlatBufferBuilder tfbb)
        {
            return false;
        }
        
        public bool FB_swm_RefreshEntityMoveSpeed(swm.RefreshEntityMoveSpeed msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_BatchLeaveMap(swm.BatchLeaveMap msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_BatchEnterMap(swm.BatchEnterMap msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_BlinkTo(swm.BlinkTo msg, FlatBufferBuilder tfbb)
        {
            return false;
        }

        public bool FB_swm_MapTeleport(swm.MapTeleport msg, FlatBufferBuilder tfbb)
        {
            return false;
        }
        #endregion

        #region Protobuf消息,返回true表示篡改消息内容,返回false表示不篡改消息内容,未定义在此的Protobuf消息不会被发送和接收
        //public bool PB_x2m_NotifySkillPlan(x2m.NotifySkillPlan msg)
        //{
        //    return false;
        //}

        //public bool PB_x2m_SyncServerTime(x2m.SyncServerTime msg)
        //{
        //    return false;
        //}

        //public bool PB_x2m_GmCommand(swm.GmCommand msg)
        //{
        //    //msg.command = "speed 1";
        //    //return true;
        //    return false;
        //}
        #endregion
    }
}