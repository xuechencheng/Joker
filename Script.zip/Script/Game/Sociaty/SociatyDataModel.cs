using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FlatBuffers;
using swm;
using LitJson;

namespace Bokura
{
    // ---------------------------基础功能----------------------------

    /// <summary>
    /// 帮会数据
    /// </summary>
    public class SociatyBaseData
    {
        /// <summary>
        /// 帮主id
        /// </summary>
        public ulong leaderID;

        /// <summary>
        /// 帮主名称
        /// </summary>
        public string leaderName;

        /// <summary>
        /// 等级
        /// </summary>
        public uint level;

        /// <summary>
        /// id
        /// </summary>
        public ulong id;

        /// <summary>
        /// 图标id
        /// </summary>
        public int iconid;

        /// <summary>
        /// 名字
        /// </summary>
        public string name;

        /// <summary>
        /// 成员数目
        /// </summary>
        public uint membercnt;

        /// <summary>
        /// 战斗力
        /// </summary>
        public ulong power;

        /// <summary>
        /// 金钱
        /// </summary>
        public ulong money;

        /// <summary>
        /// 每日活跃度
        /// </summary>
        public ulong daily_activity;

        /// <summary>
        /// 每日维护消耗
        /// </summary>
        public ulong daily_consum;

        /// <summary>
        /// 公告
        /// </summary>
        public string bulletin;

        /// <summary>
        /// 是否允许自动加入
        /// </summary>
        public bool enable_auto_join;

        /// <summary>
        /// 经验（繁荣度）
        /// </summary>
        public ulong exp;

        /// <summary>
        /// 最低等级限制
        /// </summary>
        public ulong limit_level;

        /// <summary>
        /// 最低战斗力限制
        /// </summary>
        public ulong limit_power;

        /// <summary>
        /// 最大等级
        /// </summary>
        public uint maxlevel;

        /// <summary>
        /// 最大战斗力
        /// </summary>
        public ulong maxpower;

        [XLua.BlackList]
        /// <summary>
        /// 组数据
        /// </summary>
        public List<SociatyGroup> grouplist = new List<SociatyGroup>(Const.kCap16);

        [XLua.BlackList]
        /// <summary>
        /// 建筑物数据
        /// </summary>
        public List<SociatyBuilding> buildinglist = new List<SociatyBuilding>(Const.kCap8);

        /// <summary>
        /// 得到建筑物的数目
        /// </summary>
        /// <returns></returns>
        public int GetBuildingCount()
        {
            return buildinglist.Count;
        }

        /// <summary>
        /// 获取建筑物
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SociatyBuilding GetBuildingByIndex(int index)
        {
            if (index < 0 || index >= buildinglist.Count)
                return null;

            return buildinglist[index];
        }

        /// <summary>
        /// 根据类型得到建筑物
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public SociatyBuilding GetBuilding(int type)
        {
            for (int i = 0; i < buildinglist.Count; i++)
            {
                SociatyBuilding building = buildinglist[i];
                if (building.type == type)
                    return building;
            }

            return null;
        }

        /// <summary>
        /// 根据索引得到仙门组
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SociatyGroup GetSociatyGroupByIndex(int index)
        {
            if (index < 0 || index >= grouplist.Count)
                return null;

            return grouplist[index];
        }

        /// <summary>
        /// 根据groupid得到仙门组
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public SociatyGroup GetSociatyGroupByGroupId(int id)
        {
            for (int i = 0; i < grouplist.Count; i++)
            {
                SociatyGroup groupdata = grouplist[i];
                if (groupdata == null)
                    continue;

                if (groupdata.gid == id)
                {
                    return groupdata;
                }
            }

            return null;
        }

        /// <summary>
        /// 获取组数目
        /// </summary>
        /// <returns></returns>
        public int GetGroupCount()
        {
            return grouplist.Count;
        }

        [XLua.BlackList]
        /// <summary>
        /// 修改仙门组的名字
        /// </summary>
        /// <param name="gid"></param>
        /// <param name="name"></param>
        public void ModifySociatyGroupName(uint gid, string name)
        {
            for (int i = 0; i < grouplist.Count; i++)
            {
                SociatyGroup group = grouplist[i];
                if (group.gid == gid)
                {
                    group.name = name;
                }
            }
        }

        private void InitGroupData(swm.SeptBaseData basedata)
        {
            grouplist.Clear();

            for (int i = 0; i < basedata.groupsLength; i++)
            {
                swm.SeptGroup? swmgroupdata = basedata.groups(i);
                if (!swmgroupdata.HasValue)
                    continue;

                SociatyGroup group = new SociatyGroup(swmgroupdata.Value);
                grouplist.Add(group);
            }
        }

        [XLua.BlackList]
        public void InitBuildingData(swm.SeptBaseData basedata)
        {
            buildinglist.Clear();

            for (int i = 0; i < basedata.buildingsLength; i++)
            {
                swm.SeptBuilding? buildingdata = basedata.buildings(i);
                if (!buildingdata.HasValue)
                    continue;

                SociatyBuilding building = new SociatyBuilding(buildingdata.Value);
                buildinglist.Add(building);
            }
        }

        [XLua.BlackList]
        public void InitBuildingData(swm.RspSeptAllBuilding msg)
        {
            buildinglist.Clear();

            for (int i = 0; i < msg.buildingsLength; i++)
            {
                swm.SeptBuilding? buildingdata = msg.buildings(i);
                if (!buildingdata.HasValue)
                    continue;

                SociatyBuilding building = new SociatyBuilding(buildingdata.Value);
                buildinglist.Add(building);
            }
        }

        [XLua.BlackList]
        public void SetBuildingData(uint buildingtype, uint curlevel)
        {
            bool find = false;
            for (int i = 0; i < buildinglist.Count; i++)
            {
                SociatyBuilding building = buildinglist[i];
                if (building.type == buildingtype)
                {
                    building.level = curlevel;
                    find = true;
                    break;
                }
            }

            if (!find)
            {
                SociatyBuilding building = new SociatyBuilding();
                building.type = buildingtype;
                building.level = curlevel;
                buildinglist.Add(building);
            }
        }

        private void ResetBaseInfo()
        {
            // baseinfo
            level = 0;
            id = 0;
            iconid = 0;
            name = "";
            membercnt = 0;
            power = 0;
            money = 0;
            daily_activity = 0;
            daily_consum = 0;
            bulletin = "";
            enable_auto_join = true;
            exp = 0;
            limit_level = 0;
            limit_power = 0;
            maxlevel = 0;
            maxpower = 0;
            leaderName = "";
            leaderID = 0;
        }

        private void InitBaseInfo(swm.SeptBaseData basedata)
        {
            level = basedata.level;
            id = basedata.id;
            iconid = (int)basedata.iconid;
            name = basedata.name;
            membercnt = basedata.members_num;
            power = basedata.fight_point;
            money = basedata.money;
            daily_activity = basedata.daily_activity;
            daily_consum = basedata.daily_consum;
            bulletin = basedata.bulletin;
            enable_auto_join = basedata.enable_auto_join;
            exp = basedata.exp;
            limit_level = basedata.limit_level;
            limit_power = basedata.limit_power;

            swm.UserShowInfo? tLeaderInfo = basedata.master_user_info;
            if (tLeaderInfo.HasValue)
            {
                swm.UserShowInfo tInfo = tLeaderInfo.Value;
                leaderName = tInfo.name;
                leaderID = tInfo.charid;
            }
            else
            {
                leaderName = "";
                leaderID = 0;
            }
        }

        [XLua.BlackList]
        public SociatyBaseData()
        {
            ResetBaseInfo();

            grouplist.Clear();
            buildinglist.Clear();
        }

        [XLua.BlackList]
        public void RefreshData(swm.SeptBaseData basedata)
        {
            // baseinfo
            InitBaseInfo(basedata);

            // group
            InitGroupData(basedata);

            // building
            InitBuildingData(basedata);
        }

        [XLua.BlackList]
        public SociatyBaseData(swm.SeptBaseData basedata)
        {
            RefreshData(basedata);
        }
    }

    /// <summary>
    /// 仙门组
    /// </summary>
    public class SociatyGroup
    {
        /// <summary>
        /// 帮会id
        /// </summary>
        public ulong septid;

        /// <summary>
        /// 服务器分配唯一id
        /// </summary>
        public uint gid;

        /// <summary>
        /// 小组权限
        /// </summary>
        public uint commission;

        /// <summary>
        /// 分组成员最大数量
        /// </summary>
        public uint capacity;

        /// <summary>
        /// 组名字
        /// </summary>
        public string name;

        /// <summary>
        /// 是否开启
        /// </summary>
        public bool isopen;

        /// <summary>
        /// 权限id列表
        /// </summary>
        public List<uint> commidlist = new List<uint>(Const.kCap16);

        /// <summary>
        /// 获取权限id列表
        /// </summary>
        /// <returns></returns>
        public int GetCommIdListNum()
        {
            return commidlist.Count;
        }

        /// <summary>
        /// 根据索引获取权限id
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public uint GetCommIdByIndex(int index)
        {
            if (index < 0 || index >= commidlist.Count)
                return 0;

            return commidlist[index];
        }

        [XLua.BlackList]
        public SociatyGroup(swm.SeptGroup group)
        {
            septid = group.septid;
            gid = group.gid;
            commission = group.commission;
            capacity = group.capacity;
            name = group.name;
            isopen = group.isopen;

            commidlist.Clear();
            for (int i = 0; i < group.cilistLength; i++)
            {
                uint commid = group.cilist(i);
                commidlist.Add(commid);
            }
        }
    }

    /// <summary>
    /// 帮会成员数据
    /// </summary>
    public struct SociatyMemberData
    {
        /// <summary>
        /// 玩家id
        /// </summary>
        public ulong charid;

        /// <summary>
        /// 上一次离线时间
        /// </summary>
        public uint last_offline_time;

        /// <summary>
        /// 贡献度
        /// </summary>
        public ulong contribution;

        /// <summary>
        /// 战斗力
        /// </summary>
        public ulong power;

        /// <summary>
        /// 门派
        /// </summary>
        public ulong career;

        /// <summary>
        /// 小组id
        /// </summary>
        public uint groupid;

        /// <summary>
        /// 加入时间
        /// </summary>
        public ulong jointime;

        /// <summary>
        /// 名字
        /// </summary>
        public string name;

        /// <summary>
        /// 等级
        /// </summary>
        public uint level;

        /// <summary>
        /// 头像
        /// </summary>
        public string headicon;

        [XLua.BlackList]
        public void CopyData(SociatyMemberData srcdata)
        {
            charid = srcdata.charid;
            last_offline_time = srcdata.last_offline_time;
            contribution = srcdata.contribution;
            power = srcdata.power;
            career = srcdata.career;
            groupid = srcdata.groupid;
            jointime = srcdata.jointime;
            name = srcdata.name;
            level = srcdata.level;
            headicon = srcdata.headicon;
        }

        [XLua.BlackList]
        public SociatyMemberData(swm.SeptMemberData data)
        {
            charid = data.charid;
            last_offline_time = data.last_offline_time;
            contribution = data.contribution_value;
            power = data.fight_point;
            career = data.career;
            groupid = data.groupid;
            jointime = data.jointime;

            swm.UserShowInfo? user_info = data.user_info;
            if (user_info.HasValue)
            {
                swm.UserShowInfo tInfo = user_info.Value;
                name = tInfo.name;
                level = tInfo.level;

                ProfessionTableBase? procfgdata = ProfessionTableManager.GetData((int)career);
                if (procfgdata.HasValue)
                {
                    headicon = procfgdata.Value.headicon;
                }
                else
                {
                    headicon = "";
                }
            }
            else
            {
                name = "";
                level = 0;
                headicon = "";
            }
        }
    }

    /// <summary>
    /// 仙门信息配置(json)
    /// </summary>
    public struct SociatyInfoCfg
    {
        #region 仙门基础系统

        /// <summary>
        /// 功能预告表里的帮会id
        /// </summary>
        public uint comingnextcfg_septid;

        /// <summary>
        /// 创建需要消耗的金币
        /// </summary>
        public uint create_coin;

        /// <summary>
        /// 仙门地契道具id
        /// </summary>
        public uint leaseid;

        /// <summary>
        /// 仙门公告最大字数
        /// </summary>
        public uint declarationmaxnum;

        /// <summary>
        /// 最大等级描述
        /// </summary>
        public string maxleveldesc;

        /// <summary>
        /// 最大战斗力描述
        /// </summary>
        public string maxpowerdesc;

        /// <summary>
        /// 仙门介绍标题
        /// </summary>
        public string introduce_title;

        /// <summary>
        /// 仙门介绍内容
        /// </summary>
        public string introduce_content;

        /// <summary>
        /// 权限界面移动分组弹窗内容
        /// </summary>
        public string condition_movegroup_content;

        /// <summary>
        /// 权限界面开启分组弹窗内容
        /// </summary>
        public string condition_opengroup_content;

        /// <summary>
        /// 权限设置界面移交门主权限名字
        /// </summary>
        public string conditionsetting_canmaster;

        /// <summary>
        /// 权限设置界面管理资金权限名字
        /// </summary>
        public string conditionsetting_canmoney;

        /// <summary>
        /// 权限设置界面管理建筑权限名字
        /// </summary>
        public string conditionsetting_canbuilding;

        /// <summary>
        /// 权限设置界面管理活动权限名字
        /// </summary>
        public string conditionsetting_canactive;

        /// <summary>
        /// 权限设置界面管理信息权限名字
        /// </summary>
        public string conditionsetting_caninfo;

        /// <summary>
        /// 权限设置界面浇灌神树权限名字
        /// </summary>
        public string conditionsetting_cangodtree;

        /// <summary>
        /// 权限设置界面收人权限名字
        /// </summary>
        public string conditionsetting_canrecruit;

        /// <summary>
        /// 权限设置界面踢人权限名字
        /// </summary>
        public string conditionsetting_canexpel;

        /// <summary>
        /// 权限设置界面仙门频道发言权限名字
        /// </summary>
        public string conditionsetting_canspeak;

        /// <summary>
        /// 权限设置界面移动组成员权限名字
        /// </summary>
        public string conditionsetting_modifygroup;

        /// <summary>
        /// 移交门主权重
        /// </summary>
        public uint conditionsetting_canmaster_weight;

        /// <summary>
        /// 管理资金权重
        /// </summary>
        public uint conditionsetting_canmoney_weight;

        /// <summary>
        /// 管理建筑权重
        /// </summary>
        public uint conditionsetting_canbuilding_weight;

        /// <summary>
        /// 管理活动权重
        /// </summary>
        public uint conditionsetting_canactive_weight;

        /// <summary>
        /// 管理信息权重
        /// </summary>
        public uint conditionsetting_caninfo_weight;

        /// <summary>
        /// 激活星象权重
        /// </summary>
        public uint conditionsetting_cangodtree_weight;

        /// <summary>
        /// 收人权重
        /// </summary>
        public uint conditionsetting_canrecruit_weight;

        /// <summary>
        /// 踢人权重
        /// </summary>
        public uint conditionsetting_canexpel_weight;

        /// <summary>
        /// 仙门频道发言权重
        /// </summary>
        public uint conditionsetting_canspeak_weight;

        /// <summary>
        /// 移动组成员权重
        /// </summary>
        public uint conditionsetting_modifygroup_weight;

        /// <summary>
        /// 捐献界面弹窗内容
        /// </summary>
        public string donate_content;

        /// <summary>
        /// 信息界面退出仙门弹窗内容
        /// </summary>
        public string info_quitesept_content;

        /// <summary>
        /// 邀请弹出界面邀请格式
        /// </summary>
        public string invite_applyname;

        /// <summary>
        /// 踢除玩家的弹窗内容
        /// </summary>
        public string kickmember_content;

        /// <summary>
        /// 转让会长的弹窗内容
        /// </summary>
        public string changeseptmaster_content;

        /// <summary>
        /// 申请界面打开的创建帮会界面两行文字配置
        /// </summary>
        public string uicreatesept_desc1;

        /// <summary>
        /// 申请界面打开的创建帮会界面两行文字配置
        /// </summary>
        public string uicreatesept_desc2;

        /// <summary>
        /// 申请界面打开的创建帮会界面购买地契弹窗内容
        /// </summary>
        public string uicreatesept_buglease_content;

        /// <summary>
        /// 申请界面打开的创建帮会界面购买地契金币不够弹窗内容
        /// </summary>
        public string uicreatesept_buglease_unmoney_content;

        /// <summary>
        /// 自动寻路到目标点打开的创建帮会界面弹窗内容
        /// </summary>
        public string createsept_buy_content;

        #endregion

        #region 仙门建筑物与福利

        /// <summary>
        /// 仙门管理建筑物npc的id
        /// </summary>
        public uint npc_septmgr;

        /// <summary>
        /// 仙门药房npc的id
        /// </summary>
        public uint npc_septpharmacy;

        /// <summary>
        /// 仙门铸造npc的id
        /// </summary>
        public uint npc_septcast;

        /// <summary>
        /// 仙门占卜npc的id
        /// </summary>
        public uint npc_septdivine;

        /// <summary>
        /// 仙门星象npc的id
        /// </summary>
        public uint npc_septstar;

        /// <summary>
        /// 仙门活动npc的id
        /// </summary>
        public uint npc_septactivity;

        /// <summary>
        /// 仙门传送npc的id
        /// </summary>
        public uint npc_septtransfer;

        /// <summary>
        /// 请求激活星象对话框内容
        /// </summary>
        public string starhouse_activestar;

        /// <summary>
        /// 创建建筑对话框内容
        /// </summary>
        public string building_create;

        /// <summary>
        /// 升级建筑对话框内容
        /// </summary>
        public string building_upgrade;

        #endregion

        #region 仙门盛宴

        /// <summary>
        /// 仙门盛宴第一阶段时长(秒)
        /// </summary>
        public uint feast_step1_totaltime;

        /// <summary>
        /// 仙门盛宴第二阶段时长(秒)
        /// </summary>
        public uint feast_step2_totaltime;

        /// <summary>
        /// 仙门检测着火玩家距离
        /// </summary>
        public double feast_checkfirechardis;

        /// <summary>
        /// 仙门检测着火玩家的buff列表
        /// </summary>
        public uint[] feast_checkfirechar_bufflist;

        /// <summary>
        /// 仙门盛宴唱歌倒计时(和服务器同步的一个倒计时)
        /// </summary>
        public uint feast_sing_cooldown;

        /// <summary>
        /// npc邀请男玩家唱歌
        /// </summary>
        public string feast_sing_npcinvite_content;

        #endregion

        #region 顶视角摄像机

        /// <summary>
        /// 切顶视角摄像机的初始查看位置
        /// </summary>
        public UnityEngine.Vector3 topcam_seepos;

        /// <summary>
        /// 顶视角摄像机的中心位置
        /// </summary>
        public UnityEngine.Vector3 topcam_middlepos;

        /// <summary>
        /// 顶视角摄像机从中心往左边移动的最大距离
        /// </summary>
        public float topcam_leftmaxdis;

        /// <summary>
        /// 顶视角摄像机从中心往右边移动的最大距离
        /// </summary>
        public float topcam_rightmaxdis;

        /// <summary>
        /// 顶视角摄像机从中心往上边移动的最大距离
        /// </summary>
        public float topcam_topmaxdis;

        /// <summary>
        /// 顶视角摄像机从中心往下边移动的最大距离
        /// </summary>
        public float topcam_bottommaxdis;

        #endregion

        /// <summary>
        /// 寻路到仙门的位置
        /// </summary>
        public UnityEngine.Vector3 arrived_pos;

        /// <summary>
        /// 包含buff
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool ContainBuff(Entity entity)
        {
            if (entity == null)
                return false;

            if (entity.BuffProxy == null)
                return false;

            for (int i = 0; i < feast_checkfirechar_bufflist.Length; i++)
            {
                bool container = entity.BuffProxy.ContainBuff(feast_checkfirechar_bufflist[i]);
                if (container)
                {
                    return true;
                }
            }

            return false;
        }

        [XLua.BlackList]
        public void LoadData()
        {
            var cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_ComingNextCfgId);
            if (cfg != null)
            {
                try
                {
                    comingnextcfg_septid = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_CreateCoin);
            if (cfg != null)
            {
                try
                {
                    create_coin = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_DeclarationMaxNum);
            if (cfg != null)
            {
                try
                {
                    declarationmaxnum = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_MaxLevelDesc);
            if (cfg != null)
            {
                try
                {
                    maxleveldesc = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_MaxPowerDesc);
            if (cfg != null)
            {
                try
                {
                    maxpowerdesc = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Introduce_Title);
            if (cfg != null)
            {
                try
                {
                    introduce_title = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Introduce_Content);
            if (cfg != null)
            {
                try
                {
                    introduce_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_MoveGroup_Content);
            if (cfg != null)
            {
                try
                {
                    condition_movegroup_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_OpenGroup_Content);
            if (cfg != null)
            {
                try
                {
                    condition_opengroup_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanMaster);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canmaster = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanMoney);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canmoney = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanBuilding);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canbuilding = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanActive);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canactive = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanInfo);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_caninfo = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanGodtree);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_cangodtree = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanRecruit);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canrecruit = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanExpel);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canexpel = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanSpeak);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canspeak = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_ModifyGroup);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_modifygroup = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanMaster_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canmaster_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanMoney_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canmoney_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanBuilding_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canbuilding_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanActive_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canactive_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanInfo_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_caninfo_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanGodtree_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_cangodtree_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanRecruit_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canrecruit_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanExpel_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canexpel_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_CanSpeak_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_canspeak_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Condition_Setting_ModifyGroup_Weight);
            if (cfg != null)
            {
                try
                {
                    conditionsetting_modifygroup_weight = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Donate_Content);
            if (cfg != null)
            {
                try
                {
                    donate_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Info_QuitSept_Content);
            if (cfg != null)
            {
                try
                {
                    info_quitesept_content = cfg.Value.cfg_val;
                    info_quitesept_content = info_quitesept_content.Replace("\\n", "\n");
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Invite_ApplyName);
            if (cfg != null)
            {
                try
                {
                    invite_applyname = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_KickMember_Content);
            if (cfg != null)
            {
                try
                {
                    kickmember_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_ChangeSeptMaster_Content);
            if (cfg != null)
            {
                try
                {
                    changeseptmaster_content = cfg.Value.cfg_val;
                }
                catch { }
            }


            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_CreateSept_Unmoney_Content);
            if (cfg != null)
            {
                try
                {
                    uicreatesept_buglease_unmoney_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_CreateSept_Buy_Content);
            if (cfg != null)
            {
                try
                {
                    createsept_buy_content = cfg.Value.cfg_val;
                    createsept_buy_content = createsept_buy_content.Replace("\\n", "\n");
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Npc_SeptMgr);
            if (cfg != null)
            {
                try
                {
                    npc_septmgr = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Npc_SeptPharmacy);
            if (cfg != null)
            {
                try
                {
                    npc_septpharmacy = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Npc_SeptDivine);
            if (cfg != null)
            {
                try
                {
                    npc_septdivine = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Npc_SeptStar);
            if (cfg != null)
            {
                try
                {
                    npc_septstar = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Npc_SeptActivity);
            if (cfg != null)
            {
                try
                {
                    npc_septactivity = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Npc_SeptTransfer);
            if (cfg != null)
            {
                try
                {
                    npc_septtransfer = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Starhorse_ActiveStar);
            if (cfg != null)
            {
                try
                {
                    starhouse_activestar = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Building_Create);
            if (cfg != null)
            {
                try
                {
                    building_create = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Building_Upgrade);
            if (cfg != null)
            {
                try
                {
                    building_upgrade = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Feast_Step1_Totaltime);
            if (cfg != null)
            {
                try
                {
                    feast_step1_totaltime = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Feast_Step2_Totaltime);
            if (cfg != null)
            {
                try
                {
                    feast_step2_totaltime = (uint)float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Feast_CheckFireCharDis);
            if (cfg != null)
            {
                try
                {
                    feast_checkfirechardis = double.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Feast_CheckFireChar_Bufflist);
            if (cfg != null)
            {
                try
                {
                    var templist = TableExtra.GetListUint(cfg.Value.cfg_val, ';');
                    feast_checkfirechar_bufflist = templist.ToArray();
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Feast_Sing_Cooldown);
            if (cfg != null)
            {
                try
                {
                    feast_sing_cooldown = (uint)(float.Parse(cfg.Value.cfg_val));
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Feast_Sing_NpcInvite_Content);
            if (cfg != null)
            {
                try
                {
                    feast_sing_npcinvite_content = cfg.Value.cfg_val;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_TopCam_SeePos);
            if (cfg != null)
            {
                try
                {
                    var vec = TableExtra.GetVector(cfg.Value.cfg_val, ';');
                    topcam_seepos = vec;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_TopCam_MiddlePos);
            if (cfg != null)
            {
                try
                {
                    var vec = TableExtra.GetVector(cfg.Value.cfg_val, ';');
                    topcam_middlepos = vec;
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_TopCam_LeftMaxDis);
            if (cfg != null)
            {
                try
                {
                    topcam_leftmaxdis = float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_TopCam_RightMaxDis);
            if (cfg != null)
            {
                try
                {
                    topcam_rightmaxdis = float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_TopCam_TopMaxDis);
            if (cfg != null)
            {
                try
                {
                    topcam_topmaxdis = float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_TopCam_BottomMaxDis);
            if (cfg != null)
            {
                try
                {
                    topcam_bottommaxdis = float.Parse(cfg.Value.cfg_val);
                }
                catch { }
            }

            cfg = GameCfgTableManager.GetData((int)GameCfgID.Sept_Pos);
            if (cfg != null)
            {
                try
                {
                    var vec = TableExtra.GetVector(cfg.Value.cfg_val, ';');
                    arrived_pos = vec;
                }
                catch { }
            }
        }
    }

    /// <summary>
    /// 仙门组权限
    /// </summary>
    public struct SociatyGroupCommission
    {
        /// <summary>
        /// 权限
        /// </summary>
        public uint commision;

        /// <summary>
        /// 是否开启
        /// </summary>
        public bool isopen;

        [XLua.BlackList]
        public SociatyGroupCommission(swm.SeptGroupCommisionData commisiondata)
        {
            commision = (uint)commisiondata.comitype;
            isopen = commisiondata.enable;
        }

        [XLua.BlackList]
        public SociatyGroupCommission(SociatyGroupCommission srcdata)
        {
            commision = srcdata.commision;
            isopen = srcdata.isopen;
        }
    }

    /// <summary>
    /// 仙门组权限集合
    /// </summary>
    public class SociatyGroupCommSet
    {
        /// <summary>
        /// 仙门组权限集合
        /// </summary>
        private List<SociatyGroupCommission> commlist = new List<SociatyGroupCommission>(Const.kCap32);

        /// <summary>
        /// 分组id
        /// </summary>
        public uint groupid;

        /// <summary>
        /// 得到数目
        /// </summary>
        /// <returns></returns>
        public int GetCommCount()
        {
            return commlist.Count;
        }

        [XLua.BlackList]
        /// <summary>
        /// 清理
        /// </summary>
        public void Clear()
        {
            commlist.Clear();
        }

        /// <summary>
        /// 根据索引获取权限
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SociatyGroupCommission? GetCommByIndex(int index)
        {
            if (index < 0 || (index >= commlist.Count))
                return null;

            return commlist[index];
        }

        /// <summary>
        /// 是否权限开放
        /// </summary>
        /// <param name="comm"></param>
        /// <returns></returns>
        public bool HasCommOpen(uint comm)
        {
            for (int i = 0; i < commlist.Count; i++)
            {
                SociatyGroupCommission? data = commlist[i];
                if (!data.HasValue)
                    continue;

                SociatyGroupCommission groupcomm = data.Value;
                if (groupcomm.commision != comm)
                    continue;

                return groupcomm.isopen;
            }

            return false;
        }

        [XLua.BlackList]
        public SociatyGroupCommSet(RspModifySeptGroupCommission msg)
        {
            SetData(msg);
        }

        public void FillData(uint commision, bool isopen)
        {
            bool find = false;
            for (int i = 0; i < commlist.Count; i++)
            {
                SociatyGroupCommission? commdata = commlist[i];
                if (!commdata.HasValue)
                    continue;

                SociatyGroupCommission comm = commdata.Value;
                if (comm.commision != commision)
                    continue;

                find = true;
                comm.isopen = isopen;
            }

            if (!find)
            {
                SociatyGroupCommission comm = new SociatyGroupCommission();
                comm.commision = commision;
                comm.isopen = isopen;
                commlist.Add(comm);
            }
        }

        public void CopyData(SociatyGroupCommSet srccommset)
        {
            this.groupid = srccommset.groupid;

            commlist.Clear();

            for (int i = 0; i < srccommset.GetCommCount(); i++)
            {
                SociatyGroupCommission? srcdata = srccommset.GetCommByIndex(i);
                if (srcdata.HasValue)
                {
                    SociatyGroupCommission dstdata = new SociatyGroupCommission(srcdata.Value);
                    commlist.Add(dstdata);
                }
            }
        }

        public void SetData(RspModifySeptGroupCommission msg)
        {
            this.groupid = msg.gid;

            commlist.Clear();

            for (int i = 0; i < msg.commisionsLength; i++)
            {
                SeptGroupCommisionData? srcdata = msg.commisions(i);
                if (srcdata.HasValue)
                {
                    SociatyGroupCommission data = new SociatyGroupCommission(srcdata.Value);
                    commlist.Add(data);
                }
            }
        }

        [XLua.BlackList]
        /// <summary>
        /// 是否某一位存在
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private bool HasBit(uint value, uint compare)
        {
            return (value & compare) != 0;
        }

        [XLua.BlackList]
        public SociatyGroupCommSet(SociatyGroup groupinfo)
        {
            groupid = groupinfo.gid;

            commlist.Clear();

            int commidnum = groupinfo.GetCommIdListNum();
            for (int i = 0; i < commidnum; i++)
            {
                uint commid = groupinfo.GetCommIdByIndex(i);

                SociatyGroupCommission comm = new SociatyGroupCommission();
                comm.isopen = HasBit(groupinfo.commission, commid);
                comm.commision = commid;
                commlist.Add(comm);
            }
        }

        [XLua.BlackList]
        public SociatyGroupCommSet()
        {

        }
    }
    
    /// <summary>
    /// 请求入会的玩家信息
    /// </summary>
    public struct ApplyPlayerInfo
    {
        /// <summary>
        /// 玩家id
        /// </summary>
        public ulong charID;

        /// <summary>
        /// 加入时间
        /// </summary>
        public ulong addtime;

        /// <summary>
        /// 战斗力
        /// </summary>
        public ulong power;

        /// <summary>
        /// 门派
        /// </summary>
        public uint career;

        /// <summary>
        /// 名字
        /// </summary>
        public string name;

        /// <summary>
        /// 等级
        /// </summary>
        public uint level;

        /// <summary>
        /// 头像
        /// </summary>
        public string headicon;

        [XLua.BlackList]
        public ApplyPlayerInfo(swm.SeptRequestJoinUserInfo info)
        {
            addtime = info.add_time;

            swm.UserShowInfo? tUserInfo = info.user_info;
            if (tUserInfo.HasValue)
            {
                swm.UserShowInfo tUserInfoValue = tUserInfo.Value;
                charID = tUserInfoValue.charid;
                power = tUserInfoValue.power;
                career = (uint)tUserInfoValue.career;
                name = tUserInfoValue.name;
                level = tUserInfoValue.level;


                ProfessionTableBase? procfgdata = ProfessionTableManager.GetData((int)career);
                if (procfgdata.HasValue)
                {
                    headicon = procfgdata.Value.headicon;
                }
                else
                {
                    headicon = "";
                }
            }
            else
            {
                charID = 0;
                power = 0;
                career = 0;
                name = "";
                level = 0;
                headicon = "";
            }
        }
    }


    // ---------------------------建筑物与福利----------------------------

    /// <summary>
    /// 仙门建筑物
    /// </summary>
    public class SociatyBuilding
    {
        /// <summary>
        /// 建筑类型
        /// </summary>
        public uint type;

        /// <summary>
        /// 建筑等级
        /// </summary>
        public uint level;

        [XLua.BlackList]
        public SociatyBuilding(swm.SeptBuilding data)
        {
            type = data.type;
            level = data.level;
        }

        [XLua.BlackList]
        public SociatyBuilding()
        {
            type = 0;
            level = 0;
        }
    }

    /// <summary>
    /// 仙门所有的星象数据
    /// </summary>
    public class SociatyAllStarData
    {
        /// <summary>
        /// 仙门id
        /// </summary>
        public ulong septid = 0;

        /// <summary>
        /// 最大可激活数目
        /// </summary>
        public uint activemaxnum = 0;

        [XLua.BlackList]
        /// <summary>
        /// 星象数据
        /// </summary>
        public List<uint> staridlist = new List<uint>(Const.kCap16);

        /// <summary>
        /// 获取激活星象数目
        /// </summary>
        /// <returns></returns>
        public int GetActiveStarNum()
        {
            return staridlist.Count;
        }

        /// <summary>
        /// 根据索引获取激活星象id
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public uint GetActiveStarByIndex(int index)
        {
            if (index < 0 || index >= staridlist.Count)
                return 0;

            return staridlist[index];
        }

        /// <summary>
        /// 是否激活
        /// </summary>
        /// <param name="starid"></param>
        /// <returns></returns>
        public bool IsActive(uint starid)
        {
            return staridlist.Contains(starid);
        }

        /// <summary>
        /// 获取指定基础星象类型的激活星象数目
        /// </summary>
        /// <param name="basestartype"></param>
        /// <returns></returns>
        public int GetActiveNumByBaseId(uint basestartype)
        {
            int count = 0;
            for (int i = 0; i < staridlist.Count; i++)
            {
                uint starid = staridlist[i];

                SeptStarTypeBase? starcfg = SeptStarTypeManager.GetData((int)starid);
                if (starcfg.HasValue)
                {
                    if (starcfg.Value.startype == basestartype)
                    {
                        count++;
                    }
                }
            }

            return count;
        }

        [XLua.BlackList]
        public void InitAllStarData(RspSeptAllStarsData? allstardata)
        {
            if (!allstardata.HasValue)
                return;

            RspSeptAllStarsData allstardataval = allstardata.Value;

            staridlist.Clear();
            septid = allstardataval.septid;
            activemaxnum = allstardataval.activemaxnum;

            for (int i = 0; i < allstardataval.starlistLength; i++)
            {
                SeptStarData? stardata = allstardataval.starlist(i);
                if (!stardata.HasValue)
                    continue;

                SeptStarData stardataval = stardata.Value;
                staridlist.Add(stardataval.starid);
            }
        }

        [XLua.BlackList]
        public void AddActiveStar(uint starid)
        {
            if (staridlist.Contains(starid))
                return;

            staridlist.Add(starid);
        }

    }

    /// <summary>
    /// 帮会星象数据
    /// </summary>
    public struct SociatyStarData
    {
        /// <summary>
        /// 星象id
        /// </summary>
        public uint starid;
    }

    /// <summary>
    /// 排行榜中显示仙门需要的信息
    /// </summary>
    public class TopListSeptInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public ulong septid;

        /// <summary>
        /// 
        /// </summary>
        public string sept_name;

        /// <summary>
        /// 门主名字
        /// </summary>
        public string sept_master_name;

        /// <summary>
        /// 门主id
        /// </summary>
        public ulong sept_master_charid;

        /// <summary>
        /// 仙门等级
        /// </summary>
        public uint sept_level;

        /// <summary>
        /// 仙门当前成员数量
        /// </summary>
        public uint sept_member;

        /// <summary>
        /// 仙门宣言
        /// </summary>
        public string sept_bulletin;

        public void Copy(RspTopListSeptInfo msg)
        {
            septid = msg.septid;
            sept_name = msg.sept_name;
            sept_master_name = msg.sept_master_name;
            sept_level = msg.sept_level;
            sept_member = msg.sept_member;
            sept_bulletin = msg.sept_bulletin;
            sept_master_charid = msg.sept_master_charid;
        }
    }


    // ---------------------------仙门盛宴----------------------------

    /// <summary>
    /// 盛宴制作食材
    /// </summary>
    public class SociatyFeastIngredients
    {
        /// <summary>
        /// 食材id
        /// </summary>
        public uint baseid;

        /// <summary>
        /// 食材数量
        /// </summary>
        public uint num;

        [XLua.BlackList]
        public SociatyFeastIngredients(FeastIngredients msg)
        {
            baseid = msg.baseid;
            num = msg.num;
        }
    }

    /// <summary>
    /// 仙门盛宴灶台菜单
    /// </summary>
    public class SociatyFeastCookingMenu
    {
        /// <summary>
        /// 灶台baseid
        /// </summary>
        public uint baseid;

        /// <summary>
        /// 菜品id
        /// </summary>
        public uint foodid;

        /// <summary>
        /// 菜品已制作的数量
        /// </summary>
        public uint foodnum;

        /// <summary>
        /// 食材状态
        /// </summary>
        public List<SociatyFeastIngredients> ingredients = new List<SociatyFeastIngredients>(Const.kCap8);

        /// <summary>
        /// 灶台信息发布CD结束时间
        /// </summary>
        public uint end_cd;

        /// <summary>
        /// 操作cd结束时间
        /// </summary>
        public uint cd_end_time;

        [XLua.BlackList]
        public void Refresh(RspSeptFeastCookingMenu msg)
        {
            baseid = msg.baseid;
            foodid = msg.foodid;
            foodnum = msg.foodnum;
            end_cd = msg.end_cd;
            cd_end_time = msg.end_cd;

            ingredients.Clear();
            for (int i = 0; i < msg.ingredientsLength; i++)
            {
                FeastIngredients? ingredata = msg.ingredients(i);
                if (!ingredata.HasValue)
                    continue;

                SociatyFeastIngredients ingre = new SociatyFeastIngredients(ingredata.Value);
                ingredients.Add(ingre);
            }
        }

        [XLua.BlackList]
        public void Refresh(RspBeginCooking msg)
        {
            cd_end_time = msg.cd_end_time;
        }
    }

    /// <summary>
    /// 仙门盛宴奖励物品
    /// </summary>
    public struct SociatyFeastRewardItem
    {
        public uint id;

        public uint num;
    }

    /// <summary>
    /// 仙门盛宴结算
    /// </summary>
    public class SociatyFeastSettle
    {
        /// <summary>
        /// 最佳玩家
        /// </summary>
        public ulong best_charid;

        /// <summary>
        /// 最佳玩家名字
        /// </summary>
        public string best_name;

        /// <summary>
        /// 最佳玩家第一阶段展示类型
        /// </summary>
        public int first_type;

        /// <summary>
        /// 最佳玩家第一阶段数量
        /// </summary>
        public uint best_first;

        /// <summary>
        /// 最佳玩家第二阶段数量
        /// </summary>
        public uint best_second;

        /// <summary>
        /// 仙门经验增加值
        /// </summary>
        public uint sept_exp;

        /// <summary>
        /// 仙门资金增加值
        /// </summary>
        public uint sept_moeny;

        /// <summary>
        /// 玩家经验增加值
        /// </summary>
        public uint user_exp;

        /// <summary>
        /// 玩家银币增加值
        /// </summary>
        public uint user_ticket;

        /// <summary>
        /// 玩家仙门代币增加值
        /// </summary>
        public uint user_septtoken;

        /// <summary>
        /// 奖励物品列表
        /// </summary>
        private List<SociatyFeastRewardItem> rewarditemlist = new List<SociatyFeastRewardItem>(Const.kCap4);

        public int GetRewardItemNum()
        {
            return rewarditemlist.Count;
        }

        public SociatyFeastRewardItem? GetRewardItemByIndex(int index)
        {
            if (index < 0 || index >= rewarditemlist.Count)
                return null;

            return rewarditemlist[index];
        }

        [XLua.BlackList]
        public void Refresh(RspSettleSeptFeast msg)
        {
            best_charid = msg.best_charid;
            best_name = msg.best_name;
            first_type = (int)msg.first_type;
            best_first = msg.best_first;
            best_second = msg.best_second;
            sept_exp = msg.sept_exp;
            sept_moeny = msg.sept_moeny;
            user_exp = msg.user_exp;
            user_ticket = msg.user_ticket;
            user_septtoken = msg.user_septtoken;

            rewarditemlist.Clear();
            for (int i = 0; i < msg.extra_awardLength; i++)
            {
                ExtraAward? reward = msg.extra_award(i);
                if (reward.HasValue)
                {
                    SociatyFeastRewardItem item = new SociatyFeastRewardItem();
                    item.id = reward.Value.baseid;
                    item.num = reward.Value.num;
                    rewarditemlist.Add(item);
                }
            }
        }

        public void Test()
        {
            rewarditemlist.Clear();

            SociatyFeastRewardItem item = new SociatyFeastRewardItem();
            item.id = 11;
            item.num = 1;
            rewarditemlist.Add(item);

            item.id = 12;
            item.num = 2;
            rewarditemlist.Add(item);

            item.id = 13;
            item.num = 3;
            rewarditemlist.Add(item);
        }
    }


    // ---------------------------摇钱树----------------------------
    public class MoneyTreeData
    {
        public uint effect_rate; //每分钟产出
        public uint adduptime;      //累计时间 (秒)
        public uint cangainmoney;   //可领取的货币奖励
        public List<uint> cangainitem=new List<uint>(3);    //可领取的宝箱

        [XLua.BlackList]
        public void Refresh(RspSeptTreeData msg)
        {
            effect_rate = msg.effect_rate;
            adduptime = msg.adduptime;
            cangainmoney = msg.cangainmoney;
            //cangainitem = msg.cangainitem;
            cangainitem.Clear();
            for (int i = 0; i < msg.cangainitemLength; i++)
            {
               uint id = msg.cangainitem(i);
               cangainitem.Add(id);
            }
        }
    }
    public class MoneyTreeBoxData
    {
        public int id; //宝箱编号
        public uint BoxMaxNum = 0;  //总共可领取数量
        public uint BoxMaxHas = 0;  //已经领取数量
        public List<string> GetRoleNameList=new List<string>(1);      //获得宝箱玩家名字列表
        public List<int> ShowRewardIdList = new List<int>(1);
        public string Des ;


        [XLua.BlackList]
        public void Refresh(RspSeptTreeChestObtain msg)
        {
            BoxMaxNum = msg.chest_num;
            BoxMaxHas = msg.drawed_chest_num;
            GetRoleNameList.Clear();
            for (int i=0;i<msg.usernameLength;i++)
            {
                GetRoleNameList.Add(msg.username(i));
            }
        }
    }
    public class MoneyTreeBoxList
    {
       
        public Dictionary<int,MoneyTreeBoxData> GetRoleNameList = new Dictionary<int, MoneyTreeBoxData>(1);      //获得宝箱玩家名字列表
        private int[] rewardid2boxid = { 600035, 600036, 600037 };
        public MoneyTreeBoxData GetBoxInfo(int id)
        {
            MoneyTreeBoxData boxdata=null;
            if (GetRoleNameList.TryGetValue(id,out boxdata)==false)
            {
                boxdata = new MoneyTreeBoxData();
                boxdata.id = id;
                ItemTableBase? itembase = ItemTableManager.GetData(rewardid2boxid[id - 1]);
                if (itembase.HasValue)
                {
                    string des = itembase.Value.description;
                    string[] deslist = des.Split('#');
                    if(deslist.Length>0)
                    {
                        boxdata.Des = deslist[0];
                        for(int i=1;i< deslist.Length;i++)
                        {
                            boxdata.ShowRewardIdList.Add(int.Parse(deslist[i]));
                        }
                    }
                }
                GetRoleNameList.Add(id, boxdata);
            }

            return boxdata;
        }

        [XLua.BlackList]
        public void Refresh(RspSeptTreeChestObtain msg)
        {
            MoneyTreeBoxData tempdata= GetBoxInfo((int)msg.id);
            if (tempdata != null) { tempdata.Refresh(msg); }
        }
    }

    // ---------------------------暂时未使用----------------------------

    /// <summary>
    /// 大事件信息
    /// </summary>
    public struct BigEventInfo
    {
        /// <summary>
        /// 时间戳
        /// </summary>
        public uint timeStamp;
        /// <summary>
        /// 除时间外的其他信息
        /// </summary>
        public string info;
    }
}
