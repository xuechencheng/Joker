using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;
using LitJson;
using UnityEngine;

namespace Bokura
{
    public class SociatyManager : ClientSingleton<SociatyManager>
    {
        #region 数据

        /// <summary>
        /// 帮会数量
        /// </summary>
        public int sociatyCount
        {
            get
            {
                int count = 0;
                foreach (var iter in m_SociatyPageDict)
                {
                    if (iter.Value != null)
                    {
                        count += iter.Value.Count;
                    }
                }

                return count;
            }
        }


        /// <summary>
        /// 仙门最大页数
        /// </summary>
        private uint m_SociatyTotalPage = 0;


        /// <summary>
        /// 仙门页数据
        /// </summary>
        private Dictionary<uint, List<SociatyBaseData>> m_SociatyPageDict = new Dictionary<uint, List<SociatyBaseData>>(Const.kCap16);


        /// <summary>
        /// 正在申请的帮会数量
        /// </summary>
        public int applyingSociatyCount { get { return m_ApplyingSociatyList.Count; } }


        /// <summary>
        /// 正在申请的帮会列表
        /// </summary>
        private List<ulong> m_ApplyingSociatyList = new List<ulong>(Const.kCap16);


        /// <summary>
        /// 所属帮会基本数据
        /// </summary>
        private SociatyBaseData m_SelfSociatyBaseData = new SociatyBaseData();


        /// <summary>
        /// 所有成员数量
        /// </summary>
        public int allmemberCount
        {
            get { return m_AllMemberList.Count; }
        }


        /// <summary>
        /// 成员数量，不包含主角
        /// </summary>
        public int memberCount
        {
            get { return m_MemberList.Count; }
        }


        /// <summary>
        /// 成员数据列表（不包含主角）
        /// </summary>
        private List<SociatyMemberData> m_MemberList = new List<SociatyMemberData>(Const.kCap32);


        /// <summary>
        /// 所有成员数据列表
        /// </summary>
        private List<SociatyMemberData> m_AllMemberList = new List<SociatyMemberData>(Const.kCap32);


        /// <summary>
        /// 主角的帮会成员数据
        /// </summary>
        private SociatyMemberData m_MainCharMemberData = new SociatyMemberData();


        private SociatyMemberData m_LeaderMemberData = new SociatyMemberData();
        /// <summary>
        /// 主角的帮会成员数据
        /// </summary>
        public SociatyMemberData leaderMemberData
        {
            get { return m_LeaderMemberData; }
        }


        private SociatyInfoCfg m_InfoCfg;
        /// <summary>
        /// 一些配置信息
        /// </summary>
        public SociatyInfoCfg infoCfg
        {
            get { return m_InfoCfg; }
        }


        /// <summary>
        /// 申请入会的人数
        /// </summary>
        public int applyCount { get { return m_ApplyList.Count; } }


        /// <summary>
        /// 申请入会的人员信息
        /// </summary>
        private List<ApplyPlayerInfo> m_ApplyList = new List<ApplyPlayerInfo>(Const.kCap16 + 4);


        /// <summary>
        /// 权限集合表
        /// </summary>
        private Dictionary<int, SociatyGroupCommSet> m_GroupCommSetDict = new Dictionary<int, SociatyGroupCommSet>(Const.kCap16);


        /// <summary>
        /// 需要修改的权限集合
        /// </summary>
        private SociatyGroupCommSet m_ModifyGroupCommSet = new SociatyGroupCommSet();


        private SociatyAllStarData m_AllStarData = new SociatyAllStarData();
        /// <summary>
        /// 所有的星象数据
        /// </summary>
        public SociatyAllStarData allStarData
        {
            get { return m_AllStarData; }
        }


        /// <summary>
        /// 排行榜中需要显示的信息
        /// </summary>
        private TopListSeptInfo m_TopListSeptInfo = new TopListSeptInfo();


        // ---------------------------仙门盛宴----------------------------

        /// <summary>
        /// 灶台菜单集合
        /// </summary>
        private Dictionary<uint, SociatyFeastCookingMenu> m_FeastCookingMenuDict = new Dictionary<uint, SociatyFeastCookingMenu>(Const.kCap8);


        private SociatyFeastSettle m_FeastSettle = new SociatyFeastSettle();
        /// <summary>
        /// 仙门盛宴结算
        /// </summary>
        public SociatyFeastSettle feastSettle
        {
            get { return m_FeastSettle; }
        }


        // ---------------------------通用----------------------------

        private uint m_RedPointNum = 0;
        /// <summary>
        /// 红点数目
        /// </summary>
        public uint redPointNum
        {
            get { return m_RedPointNum; }
        }


        private bool m_HasShowRedPoint = false;
        /// <summary>
        /// 是否显示红点
        /// </summary>
        public bool hasShowRedPoint
        {
            set { m_HasShowRedPoint = value; }
            get { return m_HasShowRedPoint; }
        }


        private bool m_buildingTopViewMode = false;
        /// <summary>
        /// 是否建筑顶视角查看模式
        /// </summary>
        public bool buildingTopViewMode
        {
            get { return m_buildingTopViewMode; }
            set { m_buildingTopViewMode = value; }
        }

        // ---------------------------暂时未使用----------------------------

        /// <summary>
        /// 大事件数量
        /// </summary>
        public int bigEventCount { get { return m_BigEventList.Count; } }

        /// <summary>
        /// 大事件列表
        /// </summary>
        private List<BigEventInfo> m_BigEventList = new List<BigEventInfo>(Const.kCap32);

        /// <summary>
        /// 提示数据缓存列表（用于填充提示信息）
        /// </summary>
        private List<swm.TsParams?> m_TsCaches = new List<TsParams?>(Const.kCap32);

        #endregion

        #region 事件变量

        private GameEvent m_OnApplyingSociatyDataArrived = new GameEvent();
        /// <summary>
        /// 服务器下发正在申请的帮会列表
        /// </summary>
        public GameEvent onApplyingSociatyDataArrived
        {
            get { return m_OnApplyingSociatyDataArrived; }
        }



        private GameEvent<ulong> m_OnApplyJoinSociatyDataArrived = new GameEvent<ulong>();
        /// <summary>
        /// 服务器返回申请是否已经收到
        /// </summary>
        public GameEvent<ulong> onApplyJoinSociatyDataArrived
        {
            get { return m_OnApplyJoinSociatyDataArrived; }
        }



        private GameEvent<uint, ulong> m_OnCancelJoinSociatyDataArrived = new GameEvent<uint, ulong>();
        /// <summary>
        /// 服务器返回取消申请是否已经收到
        /// </summary>
        public GameEvent<uint, ulong> onCancelJoinSociatyDataArrived
        {
            get { return m_OnCancelJoinSociatyDataArrived; }
        }



        private GameEvent<int, string> m_OnCreateSociatyDataArrived = new GameEvent<int, string>();
        /// <summary>
        /// 服务器下发创建帮会结果
        /// </summary>
        public GameEvent<int, string> onCreateSociatyDataArrived
        {
            get { return m_OnCreateSociatyDataArrived; }
        }



        private GameEvent m_OnSelfSociatyDataArrived = new GameEvent();
        /// <summary>
        /// 服务器下发所属帮会的数据
        /// </summary>
        public GameEvent onSelfSociatyDataArrived
        {
            get { return m_OnSelfSociatyDataArrived; }
        }



        private GameEvent<bool> m_OnModifyDeclarationDataArrived = new GameEvent<bool>();
        /// <summary>
        /// 服务器下发修改宣言的结果
        /// </summary>
        public GameEvent<bool> onModifyDeclarationDataArrived
        {
            get { return m_OnModifyDeclarationDataArrived; }
        }



        private GameEvent<bool> m_OnModifyAutoApproveDataArrived = new GameEvent<bool>();
        /// <summary>
        /// 服务器下发修改自动收人设置的结果
        /// </summary>
        public GameEvent<bool> onModifyAutoApproveDataArrived
        {
            get { return m_OnModifyAutoApproveDataArrived; }
        }



        private GameEvent<uint> m_OnInviteJoinSociatyDataArrived = new GameEvent<uint>();
        /// <summary>
        /// 服务器下发的邀请加入帮派回应事件
        /// </summary>
        public GameEvent<uint> onInviteJoinSociatyDataArrived
        {
            get { return m_OnInviteJoinSociatyDataArrived; }
        }



        private GameEvent m_OnApplyListArrived = new GameEvent();
        /// <summary>
        /// 服务器下发入会申请列表
        /// </summary>
        public GameEvent onApplyListArrived
        {
            get { return m_OnApplyListArrived; }
        }



        private GameEvent<bool> m_OnChangeMasterDataArrived = new GameEvent<bool>();
        /// <summary>
        /// 服务器下发转让会长的结果
        /// </summary>
        public GameEvent<bool> onChangeMasterDataArrived
        {
            get { return m_OnChangeMasterDataArrived; }
        }



        private GameEvent<bool> m_OnKickMemberDataArrived = new GameEvent<bool>();
        /// <summary>
        /// 服务器下发踢人的结果
        /// </summary>
        public GameEvent<bool> onKickMemberDataArrived
        {
            get { return m_OnKickMemberDataArrived; }
        }



        private GameEvent<uint> m_OnSociatyListDataArrived = new GameEvent<uint>();
        /// <summary>
        /// 服务器下发帮会列表数据
        /// </summary>
        public GameEvent<uint> onSociatyListDataArrived
        {
            get { return m_OnSociatyListDataArrived; }
        }



        private GameEvent<ulong> m_OnMainCharSociatyIDChanged = new GameEvent<ulong>();
        /// <summary>
        /// 服务器下发所属帮会id
        /// </summary>
        public GameEvent<ulong> onMainCharSociatyIDChanged
        {
            get { return m_OnMainCharSociatyIDChanged; }
        }



        private GameEvent<ulong, ulong> m_OnModifySeptIconDataArrived = new GameEvent<ulong, ulong>();
        /// <summary>
        /// 修改仙门icon
        /// </summary>
        public GameEvent<ulong, ulong> onModifySeptIconDataArrived
        {
            get { return m_OnModifySeptIconDataArrived; }
        }



        private GameEvent<uint> m_OnModifySeptLimitCondDataArrived = new GameEvent<uint>();
        /// <summary>
        /// 回应修改仙门限制条件
        /// </summary>
        public GameEvent<uint> onModifySeptLimitCondDataArrived
        {
            get { return m_OnModifySeptLimitCondDataArrived; }
        }


        private GameEvent<uint> m_OnOpenSeptGroupDataArrived = new GameEvent<uint>();
        /// <summary>
        /// 回应开启一个仙门分组
        /// </summary>
        public GameEvent<uint> onOpenSeptGroupDataArrived
        {
            get { return m_OnOpenSeptGroupDataArrived; }
        }



        private GameEvent<uint> m_OnMoveSeptGroupMemberEvent = new GameEvent<uint>();
        /// <summary>
        /// 回应移动仙门小组成员
        /// </summary>
        public GameEvent<uint> onMoveSeptGroupMemberEvent
        {
            get { return m_OnMoveSeptGroupMemberEvent; }
        }



        private GameEvent<uint> m_OnModifySeptGroupNameEvent = new GameEvent<uint>();
        /// <summary>
        /// 回应修改组名
        /// </summary>
        public GameEvent<uint> onModifySeptGroupNameEvent
        {
            get { return m_OnModifySeptGroupNameEvent; }
        }



        private GameEvent<uint> m_OnModifySeptGroupCommissionEvent = new GameEvent<uint>();
        /// <summary>
        /// 回应请求修改仙门组的权限
        /// </summary>
        public GameEvent<uint> onModifySeptGroupCommissionEvent
        {
            get { return m_OnModifySeptGroupCommissionEvent; }
        }



        private GameEvent<uint> m_OnSeptLevelUpEvent = new GameEvent<uint>();
        /// <summary>
        /// 回应请求仙门升级
        /// </summary>
        public GameEvent<uint> onSeptLevelUpEvent
        {
            get { return m_OnSeptLevelUpEvent; }
        }



        private GameEvent<ulong, string, ulong, string> m_OnNotifySeptInvitedUserEvent = new GameEvent<ulong, string, ulong, string>();
        /// <summary>
        /// 通知玩家仙门邀请
        /// </summary>
        public GameEvent<ulong, string, ulong, string> onNotifySeptInvitedUserEvent
        {
            get { return m_OnNotifySeptInvitedUserEvent; }
        }



        private GameEvent<uint> m_OnReplySeptInviteEvent = new GameEvent<uint>();
        /// <summary>
        /// 回复玩家回复收到的仙门邀请
        /// </summary>
        public GameEvent<uint> onReplySeptInviteEvent
        {
            get { return m_OnReplySeptInviteEvent; }
        }



        private GameEvent m_OnDonateSeptEvent = new GameEvent();
        /// <summary>
        /// 回应请求仙门成员捐献
        /// </summary>
        public GameEvent onDonateSeptEvent
        {
            get { return m_OnDonateSeptEvent; }
        }



        private GameEvent<uint> m_OnBuySeptLeaseEvent = new GameEvent<uint>();
        /// <summary>
        /// 回应请求购买仙门地契
        /// </summary>
        public GameEvent<uint> onBuySeptLeaseEvent
        {
            get { return m_OnBuySeptLeaseEvent; }
        }


        private GameEvent<uint, UnityEngine.Vector3> m_OnGoToCreateSeptEvent = new GameEvent<uint, UnityEngine.Vector3>();
        /// <summary>
        /// 回应去仙门地契点
        /// </summary>
        public GameEvent<uint, UnityEngine.Vector3> onGoToCreateSeptEvent
        {
            get { return m_OnGoToCreateSeptEvent; }
        }


        private GameEvent m_OnSeptApplyLimitCondEvent = new GameEvent();
        /// <summary>
        /// 回应获得仙门当前限制信息
        /// </summary>
        public GameEvent onSeptApplyLimitCondEvent
        {
            get { return m_OnSeptApplyLimitCondEvent; }
        }

        // ---------------------------仙门建筑物与福利----------------------------

        private GameEvent<uint, uint> m_OnUpgradeBuildingEvent = new GameEvent<uint, uint>();
        /// <summary>
        /// 升级仙门建筑
        /// </summary>
        public GameEvent<uint, uint> onUpgradeBuildingEvent
        {
            get { return m_OnUpgradeBuildingEvent; }
        }

       
        private GameEvent<SociatyAllStarData> m_OnNtfAllStarsDataEvent = new GameEvent<SociatyAllStarData>();
        /// <summary>
        /// 通知星象数据
        /// </summary>
        public GameEvent<SociatyAllStarData> onNtfAllStarsDataEvent
        {
            get { return m_OnNtfAllStarsDataEvent; }
        }



        private GameEvent m_OnActiveSeptStarEvent = new GameEvent();
        /// <summary>
        /// 通知激活星象
        /// </summary>
        public GameEvent onActiveSeptStarEvent
        {
            get { return m_OnActiveSeptStarEvent; }
        }



        private GameEvent<TopListSeptInfo> m_OnTopListSeptInfoEvent = new GameEvent<TopListSeptInfo>();
        /// <summary>
        /// 排行榜中显示仙门需要的信息
        /// </summary>
        public GameEvent<TopListSeptInfo> onTopListSeptInfoEvent
        {
            get { return m_OnTopListSeptInfoEvent; }
        }



        private GameEvent m_OnSeptAllBuildingEvent = new GameEvent();
        /// <summary>
        /// 返回客户端某个仙门的建筑列表
        /// </summary>
        public GameEvent onSeptAllBuildingEvent
        {
            get { return m_OnSeptAllBuildingEvent; }
        }



        // ---------------------------仙门盛宴----------------------------

        private GameEvent<bool> m_OnBeginSeptFeastStateEvent = new GameEvent<bool>();
        /// <summary>
        /// 返回开启仙府盛宴活动状态
        /// </summary>
        public GameEvent<bool> onBeginSeptFeastStateEvent
        {
            get { return m_OnBeginSeptFeastStateEvent; }
        }



        private GameEvent<uint, uint> m_OnSyncFirstSeptFeastDoingStateEvent = new GameEvent<uint, uint>();
        /// <summary>
        /// 同步第一阶段仙府盛宴进行的状态
        /// </summary>
        public GameEvent<uint, uint> onSyncFirstSeptFeastDoingStateEvent
        {
            get { return m_OnSyncFirstSeptFeastDoingStateEvent; }
        }



        private GameEvent<uint, uint, uint> m_OnSyncSecondSeptFeastDoingStateEvent = new GameEvent<uint, uint, uint>();
        /// <summary>
        /// 同步第二阶段仙府盛宴进行的状态
        /// </summary>
        public GameEvent<uint, uint, uint> onSyncSecondSeptFeastDoingStateEvent
        {
            get { return m_OnSyncSecondSeptFeastDoingStateEvent; }
        }



        private GameEvent m_OnCloseSeptFeastStepDisplayEvent = new GameEvent();
        /// <summary>
        /// 玩家离开仙府大厅, 通知客户端关闭活动状态显示
        /// </summary>
        public GameEvent onCloseSeptFeastStepDisplayEvent
        {
            get { return m_OnCloseSeptFeastStepDisplayEvent; }
        }



        private GameEvent<bool> m_OnSeptFeastOperateCookingBenchEvent = new GameEvent<bool>();
        /// <summary>
        /// 返回请求操作灶台
        /// </summary>
        public GameEvent<bool> onSeptFeastOperateCookingBenchEvent
        {
            get { return m_OnSeptFeastOperateCookingBenchEvent; }
        }



        private GameEvent m_OnLeaveCookingZoneEvent = new GameEvent();
        /// <summary>
        /// 玩家离开灶台操作区域
        /// </summary>
        public GameEvent onLeaveCookingZoneEvent
        {
            get { return m_OnLeaveCookingZoneEvent; }
        }



        private GameEvent<SociatyFeastCookingMenu> m_OnSeptFeastCookingMenuEvent = new GameEvent<SociatyFeastCookingMenu>();
        /// <summary>
        /// 返回灶台菜单状态
        /// </summary>
        public GameEvent<SociatyFeastCookingMenu> onSeptFeastCookingMenuEvent
        {
            get { return m_OnSeptFeastCookingMenuEvent; }
        }



        private GameEvent<uint, uint> m_OnBeginCookingEvent = new GameEvent<uint, uint>();
        /// <summary>
        /// 返回开始烹饪
        /// </summary>
        public GameEvent<uint, uint> onBeginCookingEvent
        {
            get { return m_OnBeginCookingEvent; }
        }



        private GameEvent<uint, uint, uint, bool> m_OnCookingFoodNumEvent = new GameEvent<uint, uint, uint, bool>();
        /// <summary>
        /// 刷新灶台制作菜品
        /// </summary>
        public GameEvent<uint, uint, uint, bool> onCookingFoodNumEvent
        {
            get { return m_OnCookingFoodNumEvent; }
        }



        private GameEvent m_OnSettleSeptFeastEvent = new GameEvent();
        /// <summary>
        /// 仙门盛宴结算
        /// </summary>
        public GameEvent onSettleSeptFeastEvent
        {
            get { return m_OnSettleSeptFeastEvent; }
        }



        private GameEvent<uint, ulong> m_OnDisplayServeEvent = new GameEvent<uint, ulong>();
        /// <summary>
        /// 仙门盛宴送菜特殊事件的客户端显示
        /// </summary>
        public GameEvent<uint, ulong> onDisplayServeEvent
        {
            get { return m_OnDisplayServeEvent; }
        }


        // ---------------------------通用事件----------------------------

        private GameEvent<uint> m_OnRedPointEvent = new GameEvent<uint>();
        /// <summary>
        /// 刷新红点事件
        /// </summary>
        public GameEvent<uint> onRedPointEvent
        {
            get { return m_OnRedPointEvent; }
        }


        // ---------------------------暂时未使用----------------------------

        private GameEvent m_OnAllBigEventsDataArrived = new GameEvent();
        /// <summary>
        /// 服务器下发所有大事件数据
        /// </summary>
        public GameEvent onAllBigEventsDataArrived
        {
            get { return m_OnAllBigEventsDataArrived; }
        }



        private GameEvent<uint> m_OnSeptBenefitEvent = new GameEvent<uint>();
        /// <summary>
        /// 回应请求领取仙门资金
        /// </summary>
        public GameEvent<uint> onSeptBenefitEvent
        {
            get { return m_OnSeptBenefitEvent; }
        }

        #endregion


        
        #region 消息函数

        // ---------------------------仙门基础系统----------------------------

        /// <summary>
        /// 请求帮会列表
        /// </summary>
        public void RequestSociatyList_CS(uint page)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqSeptList> tOffset = swm.ReqSeptList.CreateReqSeptList(tFBB, page);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSeptList.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回帮会列表
        /// </summary>
        private void ResponseSociatyList_SC(swm.RspSeptList sociatyList)
        {
            m_SociatyTotalPage = sociatyList.totalpage;

            uint curpage = sociatyList.currpage;

            if (m_SociatyPageDict.ContainsKey(curpage))
            {
                m_SociatyPageDict[curpage].Clear();
            }
            else
            {
                List<SociatyBaseData> templist = new List<SociatyBaseData>(Const.kCap32);
                m_SociatyPageDict[curpage] = templist;
            }
            
            for (int tIdx = 0, tCount = sociatyList.septsLength; tIdx < tCount; tIdx++)
            {
                swm.SeptBaseData? tBaseData = sociatyList.septs(tIdx);
                if (tBaseData.HasValue)
                {
                    SociatyBaseData sociatydata = new SociatyBaseData(tBaseData.Value);
                    m_SociatyPageDict[curpage].Add(sociatydata);
                }
            }

            m_OnSociatyListDataArrived.Invoke(curpage);
        }

        /// <summary>
        /// 请求正在请求的帮会列表
        /// </summary>
        public void RequestApplyingSociatyList_CS()
        {
            // ReqUserRequestJoinList
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqUserRequestJoinList.StartReqUserRequestJoinList(tFBB);
            Offset<swm.ReqUserRequestJoinList> tOffset = swm.ReqUserRequestJoinList.EndReqUserRequestJoinList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUserRequestJoinList.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回正在请求的帮会列表
        /// </summary>
        private void ResponseApplyingSociatyList_SC(swm.RspUserRequestJoinList msg)
        {
            m_ApplyingSociatyList.Clear();
            for (int tIdx = 0, tCount = msg.septsLength; tIdx < tCount; tIdx++)
            {
                m_ApplyingSociatyList.Add(msg.septs(tIdx));
            }

            m_OnApplyingSociatyDataArrived.Invoke();
        }

        /// <summary>
        /// 申请加入帮会
        /// </summary>
        public void RequestApplyJoinSociaty_CS(ulong sociatyID)
        {
            // ReqRequestJoinSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqRequestJoinSept> tOffset = swm.ReqRequestJoinSept.CreateReqRequestJoinSept(tFBB, sociatyID);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqRequestJoinSept.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回申请是否已经收到
        /// </summary>
        private void ResponseApplyJoinSociaty_SC(RspRequestJoinSept msg)
        {
            ulong septid = msg.septid;

            if (!msg.result)
                return;

            if (!m_ApplyingSociatyList.Contains(septid))
            {
                m_ApplyingSociatyList.Add(septid);
            }

            m_OnApplyJoinSociatyDataArrived.Invoke(septid);
        }

        /// <summary>
        /// 请求取消加入帮会
        /// </summary>
        /// <param name="sociatyid"></param>
        public void RequestCancelJoinSociaty_CS(ulong sociatyid)
        {
            // ReqCancelJoinSeptRequest
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqCancelJoinSeptRequest> tOffset = swm.ReqCancelJoinSeptRequest.CreateReqCancelJoinSeptRequest(tFBB, sociatyid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCancelJoinSeptRequest.HashID, tFBB);
        }

        /// <summary>
        /// 回应取消加入帮会
        /// </summary>
        /// <param name="msg"></param>
        private void ResponseCancelJoinSociaty_SC(swm.RspCancelJoinSeptRequest msg)
        {
            uint errorcode = msg.errorcode;
            ulong septid = msg.septid;

            if (errorcode == 0)
            {
                m_ApplyingSociatyList.Remove(septid);
            }

            m_OnCancelJoinSociatyDataArrived.Invoke(errorcode, septid);
        }

        /// <summary>
        /// 请求创建帮会
        /// </summary>
        public void RequestCreateSociaty_CS(string name, string declaration, bool autoApprove)
        {
            // ReqCreateSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            StringOffset tNameOffset = tFBB.CreateString(name);
            StringOffset tDeclarationOffset = tFBB.CreateString(declaration);
            Offset<swm.ReqCreateSept> tOffset = swm.ReqCreateSept.CreateReqCreateSept(tFBB, tNameOffset, tDeclarationOffset, autoApprove);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqCreateSept.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回创建结果
        /// </summary>
        private void ResponseCreateSociaty_SC(swm.RspCreateSept result)
        {
            m_OnCreateSociatyDataArrived.Invoke((int)result.ret_code, result.name);
        }

        /// <summary>
        /// 请求解散帮会
        /// </summary>
        public void RequsetDismissSociaty()
        {
            // DismissSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.DismissSept.StartDismissSept(tFBB);
            Offset<swm.DismissSept> tOffset = swm.DismissSept.EndDismissSept(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.DismissSept.HashID, tFBB);
        }

        /// <summary>
        /// 请求所属帮会的数据
        /// </summary>
        public void RequestSelfSociatyData_CS()
        {
            // ReqSelfSeptData
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqSelfSeptData.StartReqSelfSeptData(tFBB);
            Offset<ReqSelfSeptData> tOffset = swm.ReqSelfSeptData.EndReqSelfSeptData(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSelfSeptData.HashID, tFBB);
        }

        /// <summary>
        /// 服务器下发所属帮会的数据
        /// </summary>
        private void ResponseSelfSociatyData_SC(RspSelfSeptData selfSeptData)
        {
            //m_HasSociatyData = true;

            ulong maincharid = GameScene.Instance.MainChar.ThisID;
            m_MemberList.Clear();
            m_AllMemberList.Clear();

            SeptAllData? alldata = selfSeptData.data;
            if (alldata.HasValue)
            {
                SeptAllData alldataval = alldata.Value;
                SeptBaseData? basedata = alldataval.base_data;
                if (basedata.HasValue)
                {
                    m_SelfSociatyBaseData.RefreshData(basedata.Value);
                    InitSociatyGroupCommission();
                }

                int count = alldataval.membersLength;
                if (m_MemberList.Capacity < count)
                    m_MemberList.Capacity = count;

                if (m_AllMemberList.Capacity < count)
                    m_AllMemberList.Capacity = count;

                for (int idx = 0; idx < count; idx++)
                {
                    SeptMemberData? memberdata = alldataval.members(idx);
                    if (memberdata.HasValue)
                    {
                        SociatyMemberData data = new SociatyMemberData(memberdata.Value);

                        // 主角
                        if (data.charid == maincharid)
                        {
                            m_MainCharMemberData.CopyData(data);
                        }
                        else
                        {
                            m_MemberList.Add(data);
                        }

                        if (IsLeader(data.charid))
                        {
                            m_LeaderMemberData.CopyData(data);
                        }

                        m_AllMemberList.Add(data);
                    }
                }
            }

            m_OnSelfSociatyDataArrived.Invoke();
        }

        /// <summary>
        /// 请求修改帮会宣言
        /// </summary>
        public void RequestModifySociatyDeclaration_CS(string declaration)
        {
            // ReqModifySeptBulletin
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            StringOffset tDeclarationOffset = tFBB.CreateString(declaration);
            Offset<swm.ReqModifySeptBulletin> tOffset = swm.ReqModifySeptBulletin.CreateReqModifySeptBulletin(tFBB, tDeclarationOffset);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqModifySeptBulletin.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回修改帮会宣言的结果
        /// </summary>
        public void ResponseModifySociatyDeclaration_SC(RspModifySeptBulletin data)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            m_SelfSociatyBaseData.bulletin = data.bulletin;

            m_OnModifyDeclarationDataArrived.Invoke(data.result);
        }

        /// <summary>
        /// 请求修改自动收人设置
        /// </summary>
        public void RequestModifySociatyAutoApprove_CS(bool autoApprove)
        {
            // ReqModifySeptAutoJoin
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqModifySeptAutoJoin> tOffset = swm.ReqModifySeptAutoJoin.CreateReqModifySeptAutoJoin(tFBB, autoApprove);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqModifySeptAutoJoin.HashID, tFBB);
        }

        /// <summary>
        /// 服务器下发修改自动收人设置的结果
        /// </summary>
        private void ResponseModifySociatyAutoApprove_SC(swm.RspModifySeptAutoJoin data)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            m_SelfSociatyBaseData.enable_auto_join = data.autojoin;

            m_OnModifyAutoApproveDataArrived.Invoke(data.result);
        }

        /// <summary>
        /// 邀请加入帮会
        /// </summary>
        /// <param name="charid"></param>
        public void RequestInviteJoinSociaty_CS(ulong charid)
        {
            // InviteJoinSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.InviteJoinSept> tOffset = swm.InviteJoinSept.CreateInviteJoinSept(tFBB, charid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.InviteJoinSept.HashID, tFBB);
        }

        /// <summary>
        /// 回应邀请加入帮会
        /// </summary>
        /// <param name="msg"></param>
        private void ResponseInviteJoinSociaty_SC(RspInviteJoinSept msg)
        {
            uint errorcode = msg.errorcode;
            m_OnInviteJoinSociatyDataArrived.Invoke(errorcode);
        }

        /// <summary>
        /// 请求所属公会的申请列表
        /// </summary>
        public void RequestSociatyApplyList_CS()
        {
            // ReqSeptRequestList
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSeptRequestList.StartReqSeptRequestList(tFBB);
            Offset<swm.ReqSeptRequestList> tOffset = swm.ReqSeptRequestList.EndReqSeptRequestList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSeptRequestList.HashID, tFBB);
        }

        /// <summary>
        /// 服务器下发入会申请列表
        /// </summary>
        private void ResponseSociatyApplyList_SC(RspSeptRequestList data)
        {
            m_ApplyList.Clear();
            for (int tIdx = 0, tCount = data.usersLength; tIdx < tCount; tIdx++)
            {
                swm.SeptRequestJoinUserInfo? tInfo = data.users(tIdx);
                if (tInfo.HasValue)
                {
                    swm.SeptRequestJoinUserInfo tInfoValue = tInfo.Value;
                    ApplyPlayerInfo tPlayerInfo = new ApplyPlayerInfo(tInfoValue);
                    m_ApplyList.Add(tPlayerInfo);
                }
            }

            m_OnApplyListArrived.Invoke();
        }

        /// <summary>
        /// 服务器通知管理层有人申请加入帮会
        /// </summary>
        private void ResponseNewApplyForJoinSociaty_SC(swm.NotifyRequestJoinSept data)
        {
            
        }

        /// <summary>
        /// 审批入会申请
        /// </summary>
        /// <param name="charID">0表示针对当前所有申请者</param>
        public void RequestApproveApply_CS(ulong charID, bool allow)
        {
            // ApprovalRequestJoinSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ApprovalRequestJoinSept> tOffset = swm.ApprovalRequestJoinSept.CreateApprovalRequestJoinSept(tFBB, charID, allow);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ApprovalRequestJoinSept.HashID, tFBB);

            if(!allow)
            {
                RemoveApplyListByClient(charID);
            }
        }

        /// <summary>
        /// 请求将会长转让给指定成员
        /// </summary>
        public void RequestChangeSociatyMaster_CS(ulong charID)
        {
            // ReqChangeSeptMaster
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqChangeSeptMaster> tOffset = swm.ReqChangeSeptMaster.CreateReqChangeSeptMaster(tFBB, charID);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqChangeSeptMaster.HashID, tFBB);
        }

        /// <summary>
        /// 服务器下发转让会长的结果
        /// </summary>
        private void ResponseChangeSociatyMaster_SC(RspChangeSeptMaster msg)
        {
            m_OnChangeMasterDataArrived.Invoke(msg.result);
        }

        /// <summary>
        /// 请求将指定成员踢出帮会
        /// </summary>
        public void RequestKickSociatyMember_CS(ulong charID)
        {
            // ReqKickSeptMember
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqKickSeptMember> tOffset = swm.ReqKickSeptMember.CreateReqKickSeptMember(tFBB, charID);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqKickSeptMember.HashID, tFBB);
        }

        /// <summary>
        /// 服务器下发踢人的结果
        /// </summary>
        private void ResponseKickSociatyMember_SC(RspKickSeptMember msg)
        {
            m_OnKickMemberDataArrived.Invoke(msg.result);
        }

        /// <summary>
        /// 请求主动退出当前帮会
        /// </summary>
        public void RequestQuitSociaty_CS()
        {
            // QuitSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            QuitSept.StartQuitSept(tFBB);
            Offset<QuitSept> tOffset = QuitSept.EndQuitSept(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(QuitSept.HashID, tFBB);
        }

        /// <summary>
        /// 请求所有大事件
        /// </summary>
        public void RequestAllBigEvents_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqAllSeptHistorys.StartReqAllSeptHistorys(tFBB);
            Offset<swm.ReqAllSeptHistorys> tOffset = swm.ReqAllSeptHistorys.EndReqAllSeptHistorys(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAllSeptHistorys.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回所有大事件数据
        /// </summary>
        private void ResponseAllBigEvents_SC(swm.RspAllSeptHistorys msg)
        {
            m_BigEventList.Clear();
            for (int tIdx = 0, tCount = msg.historysLength; tIdx < tCount; tIdx++)
            {
                SeptHistory? tHistory = msg.historys(tIdx);
                if (tHistory.HasValue)
                {
                    SeptHistory tValue = tHistory.Value;
                    BigEventInfo tInfo = new BigEventInfo();
                    tInfo.timeStamp = tValue.timestamp;
                    m_TsCaches.Clear();

                    //提前构造提示信息
                    int tTsCount = tValue.ts_paramsLength;
                    for (int tPairIdx = 0; tPairIdx < tTsCount; tPairIdx++)
                        m_TsCaches.Add(tValue.ts_params(tPairIdx));
                    tInfo.info = NotifyModel.Instance.GetInfoByData((int)tValue.ts_id, m_TsCaches);
                    m_BigEventList.Add(tInfo);
                }
            }

            m_OnAllBigEventsDataArrived.Invoke();
        }

        /// <summary>
        /// 修改仙门icon
        /// </summary>
        /// <param name="iconid"></param>
        public void RequsetModifySeptIcon_CS(ulong iconid)
        {
            // ReqModifySeptIcon
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqModifySeptIcon> tOffset = ReqModifySeptIcon.CreateReqModifySeptIcon(tFBB, iconid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqModifySeptIcon.HashID, tFBB);
        }
        
        /// <summary>
        /// 回应修改仙门icon
        /// </summary>
        /// <param name="msg"></param>
        private void ResponseModifySeptIcon_SC(RspModifySeptIcon msg)
        {
            uint errorcode = (uint)msg.errorcode;
            ulong iconid = msg.iconid;

            if (errorcode == 0)
            {
                m_SelfSociatyBaseData.iconid = (int)iconid;
            }

            m_OnModifySeptIconDataArrived.Invoke(errorcode, iconid);
        }

        /// <summary>
        /// 修改仙门限制条件
        /// </summary>
        /// <param name="conds"></param>
        public void RequsetModifySeptLimitCond_CS(uint _level, ulong _power)
        {
            // ReqModifySeptLimitCond
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<swm.ReqModifySeptLimitCond> tOffset = swm.ReqModifySeptLimitCond.CreateReqModifySeptLimitCond(tFBB, level : _level, power : _power);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqModifySeptLimitCond.HashID, tFBB);
        }

        /// <summary>
        /// 回应修改仙门限制条件
        /// </summary>
        /// <param name="msg"></param>
        private void ResponseModifySeptLimitCond_SC(RspModifySeptLimitCond msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode == 0)
            {
                m_SelfSociatyBaseData.level = msg.level;
                m_SelfSociatyBaseData.power = msg.power;
            }

            m_OnModifySeptLimitCondDataArrived.Invoke(errorcode);
        }

        /// <summary>
        /// 开启一个仙门分组
        /// </summary>
        /// <param name="gid"></param>
        public void RequsetOpenSeptGroup_CS(uint gid)
        {
            // ReqOpenSeptGroup
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqOpenSeptGroup> tOffset = ReqOpenSeptGroup.CreateReqOpenSeptGroup(tFBB, gid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqOpenSeptGroup.HashID, tFBB);
        }

        /// <summary>
        /// 回应开启一个仙门分组
        /// </summary>
        /// <param name="msg"></param>
        private void ResponseOpenSeptGroup_SC(RspOpenSeptGroup msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode == 0)
            {
                // todo something ...

            }

            m_OnOpenSeptGroupDataArrived.Invoke(errorcode);
        }

        /// <summary>
        /// 移动仙门小组成员
        /// </summary>
        public void ReqMoveSeptGroupMember_CS(uint srcgid, uint dstgid, List<ulong> charlist)
        {
            // ReqMoveSeptGroupMember
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            VectorOffset charoffset = ReqMoveSeptGroupMember.CreateCharidsVector(tFBB, charlist.ToArray());
            Offset<ReqMoveSeptGroupMember> tOffset = ReqMoveSeptGroupMember.CreateReqMoveSeptGroupMember(tFBB, srcgid, dstgid, charoffset);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqMoveSeptGroupMember.HashID, tFBB);
        }

        /// <summary>
        /// 回应移动仙门小组成员
        /// </summary>
        /// <param name="msg"></param>
        private void RspMoveSeptGroupMember_SC(RspMoveSeptGroupMember msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode == 0)
            {

            }

            m_OnMoveSeptGroupMemberEvent.Invoke(errorcode);
        }

        /// <summary>
        /// 修改组名
        /// </summary>
        public void ReqModifySeptGroupName_CS(uint groupid, string groupname)
        {
            // ReqModifySeptGroupName
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            StringOffset tNameOffset = tFBB.CreateString(groupname);
            Offset<ReqModifySeptGroupName> tOffset = ReqModifySeptGroupName.CreateReqModifySeptGroupName(tFBB, groupid, tNameOffset);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqModifySeptGroupName.HashID, tFBB);
        }


        /// <summary>
        /// 回应修改组名
        /// </summary>
        /// <param name="msg"></param>
        private void RspModifySeptGroupName_SC(RspModifySeptGroupName msg)
        {
            m_SelfSociatyBaseData.ModifySociatyGroupName(msg.gid, msg.name);

            m_OnModifySeptGroupNameEvent.Invoke(msg.errorcode);
        }

        /// <summary>
        /// 请求修改仙门组的权限
        /// </summary>
        public void ReqModifySeptGroupCommission_CS(uint groupid)
        {
            // ReqModifySeptGroupCommission
            int commcount = m_ModifyGroupCommSet.GetCommCount();
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            var data = new FlatBuffers.Offset<swm.SeptGroupCommisionData>[commcount];
            for (int i = 0; i < commcount; i++)
            {
                SociatyGroupCommission? srccomm = m_ModifyGroupCommSet.GetCommByIndex(i);
                if (!srccomm.HasValue)
                    continue;

                SociatyGroupCommission srccommdata = srccomm.Value;
                swm.SeptGroupCommisionData.StartSeptGroupCommisionData(tFBB);
                swm.SeptGroupCommisionData.AddComitype(tFBB, (swm.SeptCommissionType)srccommdata.commision);
                swm.SeptGroupCommisionData.AddEnable(tFBB, srccommdata.isopen);
                data[i] = swm.SeptGroupCommisionData.EndSeptGroupCommisionData(tFBB);
            }

            var vec = swm.ReqModifySeptGroupCommission.CreateCommisionsVector(tFBB, data);
            swm.ReqModifySeptGroupCommission.StartReqModifySeptGroupCommission(tFBB);
            swm.ReqModifySeptGroupCommission.AddGid(tFBB, groupid);
            swm.ReqModifySeptGroupCommission.AddCommisions(tFBB, vec);
            var msg = swm.ReqModifySeptGroupCommission.EndReqModifySeptGroupCommission(tFBB);

            tFBB.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqModifySeptGroupCommission.HashID, tFBB);
        }

        /// <summary>
        /// 回应请求仙门组的权限
        /// </summary>
        /// <param name="msg"></param>
        private void RspModifySeptGroupCommission_SC(RspModifySeptGroupCommission msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode == 0)
            {
                // 设置数据
                int groupid = (int)msg.gid;
                if (m_GroupCommSetDict.ContainsKey(groupid))
                {
                    SociatyGroupCommSet commset = m_GroupCommSetDict[groupid];
                    commset.SetData(msg);
                }
                else
                {
                    SociatyGroupCommSet commset = new SociatyGroupCommSet(msg);
                    m_GroupCommSetDict[groupid] = commset;
                }
            }

            m_OnModifySeptGroupCommissionEvent.Invoke(errorcode);
        }

        /// <summary>
        /// 请求仙门升级
        /// </summary>
        public void ReqSeptLevelUp_CS()
        {
            // ReqSeptLevelUp
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqSeptLevelUp.StartReqSeptLevelUp(tFBB);
            Offset<ReqSeptLevelUp> tOffset = ReqSeptLevelUp.EndReqSeptLevelUp(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptLevelUp.HashID, tFBB);
        }

        /// <summary>
        /// 回应请求仙门升级
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptLevelUp_SC(RspSeptLevelUp msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode == 0)
            {
                m_SelfSociatyBaseData.level = msg.curlv;
                m_SelfSociatyBaseData.money = msg.curmoney;
                m_SelfSociatyBaseData.exp = msg.curexp;
            }

            m_OnSeptLevelUpEvent.Invoke(msg.errorcode);
        }

        /// <summary>
        /// 请求领取仙门资金
        /// </summary>
        public void ReqSeptBenefit_CS()
        {
            // ReqSeptBenefit
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqSeptBenefit.StartReqSeptBenefit(tFBB);
            Offset<ReqSeptBenefit> tOffset = ReqSeptBenefit.EndReqSeptBenefit(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptBenefit.HashID, tFBB);
        }

        /// <summary>
        /// 回应请求领取仙门资金
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptBenefit_SC(RspSeptBenefit msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode == 0)
            {
                m_SelfSociatyBaseData.money = msg.curmoney;
            }

            m_OnSeptBenefitEvent.Invoke(errorcode);
        }

        /// <summary>
        /// 通知玩家仙门邀请
        /// </summary>
        /// <param name="msg"></param>
        private void RspNotifySeptInvitedUser_SC(RspNotifySeptInvitedUser msg)
        {
            uint errorcode = msg.errorcode;
            if (errorcode != 0)
                return;
               
            m_OnNotifySeptInvitedUserEvent.Invoke(msg.charid, msg.username, msg.septid, msg.septname);
        }

        /// <summary>
        /// 请求玩家回复收到的仙门邀请
        /// </summary>
        public void ReqReplySeptInvite_CS(uint septid, byte reply, ulong charid)
        {
            // ReqReplySeptInvite
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqReplySeptInvite> tOffset = ReqReplySeptInvite.CreateReqReplySeptInvite(tFBB, septid, (sbyte)reply, charid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqReplySeptInvite.HashID, tFBB);
        }

        /// <summary>
        /// 回复玩家回复收到的仙门邀请
        /// </summary>
        /// <param name="msg"></param>
        private void RspReplySeptInvite_SC(RspReplySeptInvite msg)
        {
            uint errorcode = msg.errorcode;
            m_OnReplySeptInviteEvent.Invoke(errorcode);
        }

        /// <summary>
        /// 请求仙门成员捐献
        /// </summary>
        public void ReqDonateSept_CS(ulong sociatyid, ulong num)
        {
            // ReqDonateSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqDonateSept> tOffset = ReqDonateSept.CreateReqDonateSept(tFBB, sociatyid, num);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqDonateSept.HashID, tFBB);
        }

        /// <summary>
        /// 回应请求仙门成员捐献
        /// </summary>
        /// <param name="msg"></param>
        private void RspDonateSept_SC(RspDonateSept msg)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            m_SelfSociatyBaseData.money = msg.allmoney;

            m_OnDonateSeptEvent.Invoke();
        }

        /// <summary>
        /// 请求去仙门地契点
        /// </summary>
        public void ReqGoToCreateSept_CS(ulong itemid)
        {
            // ReqGoToCreateSept
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqGoToCreateSept> tOffset = ReqGoToCreateSept.CreateReqGoToCreateSept(tFBB, itemid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqGoToCreateSept.HashID, tFBB);
        }

        private void RspGoToCreateSept_SC(RspGoToCreateSept msg)
        {
            UnityEngine.Vector3 pos = UnityEngine.Vector3.zero;
            if (msg.pos.HasValue)
            {
                swm.Vector3 serverpos = msg.pos.Value;
                pos = new UnityEngine.Vector3(serverpos.x, serverpos.y, serverpos.z);
            }

            m_OnGoToCreateSeptEvent.Invoke(msg.errorcode, pos);
        }

        /// <summary>
        /// 请求购买仙门地契
        /// </summary>
        public void ReqBuySeptLease_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqBuySeptLease.StartReqBuySeptLease(tFBB);
            Offset<ReqBuySeptLease> tOffset = ReqBuySeptLease.EndReqBuySeptLease(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqBuySeptLease.HashID, tFBB);
        }

        /// <summary>
        /// 回应请求购买仙门地契
        /// </summary>
        /// <param name="msg"></param>
        private void RspBuySeptLease_SC(RspBuySeptLease msg)
        {
            m_OnBuySeptLeaseEvent.Invoke(msg.errorcode);
        }

        /// <summary>
        /// 总的刷新函数 (只通知申请人和审核人) (网络消息数据量已经很小了)
        /// 创建/加入/退出/解散/被踢帮会成功后单独更新主角的帮会信息
        /// </summary>
        private void ResponseRefreshSociatyID_SC(swm.RefreshSeptId data)
        {
            //Bokura.LogHelper.Log(Bokura.LogCategory.GameLogic, Bokura.Utilities.BuildString("RefreshSeptId : " , data.septid.ToString()));

            GameScene.Instance.MainChar.SociatyID = data.septid;

            //加入帮会后请求帮会数据（创建、申请、接受邀请）
            if (data.septid != 0)
            {
                RequestSelfSociatyData_CS();
            }

            m_OnMainCharSociatyIDChanged.Invoke(data.septid);
        }

        /// <summary>
        /// 服务器通知帮会数据发生变化（不包括入会）(只通知申请人和审核人) (网络消息数据量已经很小了)
        /// </summary>
        private void ResponseSociatyChangedNotify_SC(swm.NotifySeptChanged data)
        {
            //Bokura.LogHelper.Log(Bokura.LogCategory.GameLogic, "NotifySeptChanged");

            RequestSelfSociatyData_CS();
        }

        /// <summary>
        /// 被踢出
        /// </summary>
        /// <param name="_msg"></param>
        private void OnNoitfyModelMessageEvent(int _tsId)
        {
            if (_tsId == (int)TsInfoID.TS_SC_BEKICKED)
            {
                ulong sociatyid = 0;
                GameScene.Instance.MainChar.SociatyID = sociatyid;
                m_OnMainCharSociatyIDChanged.Invoke(sociatyid);
            }
        }

        /// <summary>
        /// 请求获得仙门当前限制信息
        /// </summary>
        public void ReqSeptApplyLimitCond_CS()
        {
            // ReqSeptApplyLimitCond
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqSeptApplyLimitCond.StartReqSeptApplyLimitCond(tFBB);
            Offset<ReqSeptApplyLimitCond> tOffset = ReqSeptApplyLimitCond.EndReqSeptApplyLimitCond(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptApplyLimitCond.HashID, tFBB);
        }

        /// <summary>
        /// 回应获得仙门当前限制信息
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptApplyLimitCond_SC(RspSeptApplyLimitCond msg)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            m_SelfSociatyBaseData.limit_level = msg.limitlevel;
            m_SelfSociatyBaseData.limit_power = msg.limitpower;
            m_SelfSociatyBaseData.maxlevel = msg.maxlevel;
            m_SelfSociatyBaseData.maxpower = msg.maxpower;

            m_OnSeptApplyLimitCondEvent.Invoke();
        }

        // ---------------------------仙门建筑物与福利----------------------------

        /// <summary>
        /// 请求升级建筑
        /// </summary>
        /// <param name="buildingtype"></param>
        public void ReqSeptUpgradeBuilding_CS(uint buildingtype)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqSeptUpgradeBuilding> tOffset = ReqSeptUpgradeBuilding.CreateReqSeptUpgradeBuilding(tFBB, buildingtype);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptUpgradeBuilding.HashID, tFBB);
        }

        /// <summary>
        /// 回应升级建筑
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptUpgradeBuilding_SC(swm.RspSeptUpgradeBuilding msg)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            m_SelfSociatyBaseData.money = msg.curmoney;
            m_SelfSociatyBaseData.SetBuildingData(msg.buildingtype, msg.curlevel);

            RefreshNpcVisible();

            m_OnUpgradeBuildingEvent.Invoke(msg.buildingtype, msg.curlevel);
        }

        /// <summary>
        /// 请求激活上周星象
        /// </summary>
        public void ReqUseLastWeekSeptStarData_CS()
        {
            //ReqUseLastWeekSeptStarData
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqUseLastWeekSeptStarData.StartReqUseLastWeekSeptStarData(tFBB);
            Offset<ReqUseLastWeekSeptStarData> tOffset = ReqUseLastWeekSeptStarData.EndReqUseLastWeekSeptStarData(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqUseLastWeekSeptStarData.HashID, tFBB);
        }

        /// <summary>
        /// 请求自己的星象数据
        /// </summary>
        public void ReqSelfSeptAllStarsData_CS()
        {
            if (m_SelfSociatyBaseData == null)
                return;

            ulong septid = m_SelfSociatyBaseData.id;
            ReqSeptAllStarsData_CS(septid);
        }

        /// <summary>
        /// 请求所有的星象数据
        /// </summary>
        public void ReqSeptAllStarsData_CS(ulong septid)
        {
            // ReqSeptAllStarsData
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqSeptAllStarsData> tOffset = ReqSeptAllStarsData.CreateReqSeptAllStarsData(tFBB, septid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptAllStarsData.HashID, tFBB);
        }

        /// <summary>
        /// 回应所有的星象数据
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptAllStarsData_SC(RspSeptAllStarsData msg)
        {
            m_AllStarData.InitAllStarData(msg);
            m_OnNtfAllStarsDataEvent.Invoke(m_AllStarData);
        }

        public void ReqActiveSeptStar_CS(uint starid)
        {
            // ReqActiveSeptStar
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqActiveSeptStar> tOffset = ReqActiveSeptStar.CreateReqActiveSeptStar(tFBB, starid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqActiveSeptStar.HashID, tFBB);
        }

        private void RspActiveSeptStar_SC(RspActiveSeptStar msg)
        {
            if (m_SelfSociatyBaseData != null)
            {
                m_SelfSociatyBaseData.money = msg.curmoney;
            }

            m_AllStarData.AddActiveStar(msg.starid);

            m_OnActiveSeptStarEvent.Invoke();
        }

        /// <summary>
        /// 查询指定仙门的数据
        /// </summary>
        /// <param name="septid"></param>
        public void ReqTopListSeptInfo_CS(ulong septid)
        {
            // ReqTopListSeptInfo
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqTopListSeptInfo> tOffset = ReqTopListSeptInfo.CreateReqTopListSeptInfo(tFBB, septid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqTopListSeptInfo.HashID, tFBB);
        }

        /// <summary>
        /// 返回查询指定仙门的数据
        /// </summary>
        private void RspTopListSeptInfo_SC(RspTopListSeptInfo msg)
        {
            m_TopListSeptInfo.Copy(msg);
            m_OnTopListSeptInfoEvent.Invoke(m_TopListSeptInfo);
        }

        /// <summary>
        /// 客户端请求自己仙门的建筑列表
        /// </summary>
        public void ReqSelfSeptAllBuilding_CS()
        {
            if (m_SelfSociatyBaseData == null)
                return;

            ulong septid = m_SelfSociatyBaseData.id;
            ReqSeptAllBuilding_CS(septid);
        }

        /// <summary>
        /// 客户端请求某个仙门的建筑列表
        /// </summary>
        /// <param name="septid"></param>
        public void ReqSeptAllBuilding_CS(ulong septid)
        {
            // ReqSeptAllBuilding
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqSeptAllBuilding> tOffset = ReqSeptAllBuilding.CreateReqSeptAllBuilding(tFBB, septid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptAllBuilding.HashID, tFBB);
        }

        /// <summary>
        /// 返回客户端某个仙门的建筑列表
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptAllBuilding_SC(RspSeptAllBuilding msg)
        {
            if (m_SelfSociatyBaseData != null)
            {
                if (m_SelfSociatyBaseData.id == msg.septid)
                {
                    m_SelfSociatyBaseData.InitBuildingData(msg);
                }
            }

            foreach(var iterpage in m_SociatyPageDict)
            {
                for (int i = 0; i < iterpage.Value.Count; i++)
                {
                    SociatyBaseData septdata = iterpage.Value[i];
                    if (septdata == null)
                        continue;

                    if (septdata.id != msg.septid)
                        continue;

                    septdata.InitBuildingData(msg);
                }
            }

            m_OnSeptAllBuildingEvent.Invoke();
        }

        /// <summary>
        /// 监听增加entity事件
        /// </summary>
        /// <param name="entity"></param>
        private void OnAddEntityEvent(Entity entity)
        {
            SetNpcVisible(entity);
        }

        // ---------------------------仙门盛宴----------------------------

        /// <summary>
        /// 请求开启仙府盛宴活动
        /// </summary>
        public void ReqBeginSeptFeast_CS()
        {
            // ReqBeginSeptFeast
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqBeginSeptFeast.StartReqBeginSeptFeast(tFBB);
            Offset<ReqBeginSeptFeast> tOffset = ReqBeginSeptFeast.EndReqBeginSeptFeast(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqBeginSeptFeast.HashID, tFBB);
        }

        /// <summary>
        /// 返回开启仙府盛宴活动状态(此消息可以用提示信息表代替)  
        /// </summary>
        private void RspBeginSeptFeastState_SC(RspBeginSeptFeastState msg)
        {
            m_OnBeginSeptFeastStateEvent.Invoke(msg.is_ok);
        }

        /// <summary>
        /// 同步第一阶段仙府盛宴进行的状态
        /// </summary>
        /// <param name="msg"></param>
        private void RspSyncFirstSeptFeastDoingState_SC(RspSyncFirstSeptFeastDoingState msg)
        {
            GameScene.Instance.StartCheckCloseCharacter(m_InfoCfg.feast_checkfirechardis, (int)ECheckCloseCharacterType.CheckBuff, m_InfoCfg.feast_checkfirechar_bufflist);
            m_OnSyncFirstSeptFeastDoingStateEvent.Invoke(msg.done, msg.endtime);
        }

        /// <summary>
        /// 同步第二阶段仙府盛宴进行的状态
        /// </summary>
        /// <param name="msg"></param>
        private void RspSyncSecondSeptFeastDoingState_SC(RspSyncSecondSeptFeastDoingState msg)
        {
            GameScene.Instance.StartCheckCloseCharacter(m_InfoCfg.feast_checkfirechardis, (int)ECheckCloseCharacterType.CheckBuff, m_InfoCfg.feast_checkfirechar_bufflist);
            m_OnSyncSecondSeptFeastDoingStateEvent.Invoke(msg.remain, msg.satisfaction, msg.endtime);
        }

        /// <summary>
        /// 玩家离开仙府大厅, 通知客户端关闭活动状态显示
        /// </summary>
        /// <param name="msg"></param>
        private void RspCloseSeptFeastStepDisplay_SC(RspCloseSeptFeastStepDisplay msg)
        {
            GameScene.Instance.EndCheckCloseCharacter();
            m_OnCloseSeptFeastStepDisplayEvent.Invoke();
        }

        /// <summary>
        /// 请求操作灶台
        /// </summary>
        /// <param name="uid">灶台uid</param>
        public void ReqSeptFeastOperateCookingBench_CS(ulong uid)
        {
            // ReqSeptFeastOperateCookingBench
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqSeptFeastOperateCookingBench> tOffset = ReqSeptFeastOperateCookingBench.CreateReqSeptFeastOperateCookingBench(tFBB, uid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSeptFeastOperateCookingBench.HashID, tFBB);
        }

        /// <summary>
        /// 返回请求操作灶台
        /// </summary>
        private void RspSeptFeastOperateCookingBench_SC(RspSeptFeastOperateCookingBench msg)
        {
            m_OnSeptFeastOperateCookingBenchEvent.Invoke(msg.is_ok);
        }

        /// <summary>
        /// 玩家离开灶台操作区域
        /// </summary>
        /// <param name="msg"></param>
        private void RspLeaveCookingZone_SC(RspNotifyUserQuitCooking msg)
        {
            m_OnLeaveCookingZoneEvent.Invoke();
        }

        /// <summary>
        /// 返回灶台菜单状态
        /// </summary>
        /// <param name="msg"></param>
        private void RspSeptFeastCookingMenu_SC(RspSeptFeastCookingMenu msg)
        {
            uint baseid = msg.baseid;
            SociatyFeastCookingMenu menu = null;
            if (m_FeastCookingMenuDict.ContainsKey(baseid))
            {
                menu = m_FeastCookingMenuDict[baseid];
            }
            else
            {
                menu = new SociatyFeastCookingMenu();
                m_FeastCookingMenuDict.Add(baseid, menu);
            }

            menu.Refresh(msg);

            m_OnSeptFeastCookingMenuEvent.Invoke(menu);
        }

        /// <summary>
        /// 请求开始烹饪
        /// </summary>
        /// <param name="uid">灶台uid</param>
        public void ReqBeginCooking_CS(uint baseid)
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqBeginCooking> tOffset = ReqBeginCooking.CreateReqBeginCooking(tFBB, baseid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqBeginCooking.HashID, tFBB);
        }

        /// <summary>
        /// 返回开始烹饪
        /// </summary>
        /// <param name="msg"></param>
        private void RspBeginCooking_SC(RspBeginCooking msg)
        {
            if (!msg.is_ok)
                return;

            uint baseid = msg.baseid;
            if (!m_FeastCookingMenuDict.ContainsKey(baseid))
                return;

            SociatyFeastCookingMenu menu = m_FeastCookingMenuDict[baseid];
            if (menu == null)
                return;

            menu.Refresh(msg);

            m_OnBeginCookingEvent.Invoke(baseid, msg.cd_end_time);
        }

        /// <summary>
        /// 刷新灶台制作菜品(用于显示暴击界面)
        /// </summary>
        /// <param name="msg"></param>
        private void RspCookingFoodNum_SC(RspCookingFoodNum msg)
        {
            m_OnCookingFoodNumEvent.Invoke(msg.baseid, msg.foodid, msg.makenum, msg.is_crit);
        }

        /// <summary>
        /// 请求退出烹饪
        /// </summary>
        /// <param name="baseid">灶台baseid</param>
        public void ReqQuitCooking_CS(uint baseid)
        {
            // ReqQuitCooking
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqQuitCooking> tOffset = ReqQuitCooking.CreateReqQuitCooking(tFBB, baseid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqQuitCooking.HashID, tFBB);
        }

        /// <summary>
        /// 上交食材
        /// </summary>
        /// <param name="baseid">灶台baseid</param>
        public void ReqSubmitIngredients_CS(uint baseid)
        {
            // ReqSubmitIngredients
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqSubmitIngredients> tOffset = ReqSubmitIngredients.CreateReqSubmitIngredients(tFBB, baseid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSubmitIngredients.HashID, tFBB);
        }

        /// <summary>
        /// 灶台操作者请求发布灶台菜单
        /// </summary>
        /// <param name="baseid">灶台baseid</param>
        public void ReqAnnounceCookingBenchMenu_CS(uint baseid)
        {
            // ReqAnnounceCookingBenchMenu
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqAnnounceCookingBenchMenu> tOffset = ReqAnnounceCookingBenchMenu.CreateReqAnnounceCookingBenchMenu(tFBB, baseid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqAnnounceCookingBenchMenu.HashID, tFBB);
        }

        /// <summary>
        /// 玩家请求扇灭火种
        /// </summary>
        /// <param name="fire_uid">失火玩家</param>
        public void ReqFireFightingByFan_CS(ulong fire_uid)
        {
            // ReqFireFightingByFan
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqFireFightingByFan> tOffset = ReqFireFightingByFan.CreateReqFireFightingByFan(tFBB, fire_uid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqFireFightingByFan.HashID, tFBB);
        }

        /// <summary>
        /// 玩家请求浇灭火种
        /// </summary>
        /// <param name="fire_uid">失火玩家</param>
        /// <param name="item_uid">水桶道具itemuid</param>
        public void ReqFireFightingByWater_CS(ulong fire_uid, ulong item_uid)
        {
            // ReqFireFightingByWater
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqFireFightingByWater> tOffset = ReqFireFightingByWater.CreateReqFireFightingByWater(tFBB, fire_uid, item_uid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqFireFightingByWater.HashID, tFBB);
        }

        /// <summary>
        /// 玩家给宾客上菜
        /// </summary>
        /// <param name="npc_id">宾客npc_uid</param>
        public void ReqUserServeFood_CS(ulong npc_id)
        {
            // ReqUserServeFood
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqUserServeFood> tOffset = ReqUserServeFood.CreateReqUserServeFood(tFBB, npc_id);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqUserServeFood.HashID, tFBB);
        }

        /// <summary>
        /// 仙门盛宴结算
        /// </summary>
        /// <param name="msg"></param>
        private void RspSettleSeptFeast_SC(RspSettleSeptFeast msg)
        {
            //LogHelper.Log(LogCategory.GameLogic, "RspSettleSeptFeast_SC");

            m_FeastSettle.Refresh(msg);

            GameScene.Instance.EndCheckCloseCharacter();

            m_OnSettleSeptFeastEvent.Invoke();
        }

        /// <summary>
        /// 仙门盛宴送菜特殊事件的客户端显示
        /// </summary>
        /// <param name="msg"></param>
        private void RspDisplayServeEvent_SC(RspDisplayServeEvent msg)
        {
            m_OnDisplayServeEvent.Invoke((uint)msg.type, msg.npc_uid);
        }

        /// <summary>
        /// 反馈是否歌唱
        /// </summary>
        /// <param name="state"></param>
        /// <param name="npc_uid">事件触发者</param>
        public void ReqSingState_CS(bool state, ulong npc_uid)
        {
            // ReqSingState
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            Offset<ReqSingState> tOffset = ReqSingState.CreateReqSingState(tFBB, state, npc_uid);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(ReqSingState.HashID, tFBB);
        }

        // ---------------------------通用事件----------------------------

        /// <summary>
        /// 处理红点
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRedPoint(RedDotData _msg)
        {
            if (_msg.RedDotType != swm.RedDotType.SEPTJOIN)
                return;

            if (_msg.Num > 0)
            {
                m_HasShowRedPoint = true;
            }
            else
            {
                m_HasShowRedPoint = false;
            }

            m_RedPointNum = _msg.Num;

            m_OnRedPointEvent.Invoke(m_RedPointNum);
        }




        /// <summary>
        /// 仙门摇钱树
        /// </summary>
        private GameEvent m_OnGetMoneyTreeDataEvent = new GameEvent();
        public GameEvent OnGetMoneyTreeDataEvent
        {
            get { return m_OnGetMoneyTreeDataEvent; }
        }

        private GameEvent<bool> m_OnPickSeptTreePrizeEvent = new GameEvent<bool>();
        public GameEvent<bool> OnPickSeptTreePrizeEvent
        {
            get { return m_OnPickSeptTreePrizeEvent; }
        }
        #endregion
        #region 仙门摇钱树
        /// <summary>
        /// 请求摇钱树信息
        /// </summary>
        /// 
        private MoneyTreeData m_MoneyTreeData=new MoneyTreeData();
        public MoneyTreeData MoneyTreeInfo
        {
            get
            {
                return m_MoneyTreeData;
            }
        }

        public void RequestMoneyTreeData_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSeptTreeData.StartReqSeptTreeData(tFBB);
            var msg = swm.ReqSeptTreeData.EndReqSeptTreeData(tFBB);
            tFBB.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSeptTreeData.HashID, tFBB);
        }

        /// <summary>
        /// 服务器返回摇钱树信息
        /// </summary>
        private void ResponseMoneyTreeData_SC(swm.RspSeptTreeData moneytreedata)
        {
            m_MoneyTreeData.Refresh(moneytreedata);
            m_OnGetMoneyTreeDataEvent.Invoke();
        }


        //请求领取摇钱树奖励
        public void RequestPickSeptTreePrize_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqPickSeptTreePrize.StartReqPickSeptTreePrize(tFBB);
            var msg = swm.ReqPickSeptTreePrize.EndReqPickSeptTreePrize(tFBB);
            tFBB.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqPickSeptTreePrize.HashID, tFBB);
        }

        private void ResponsePickSeptTreePrize_SC(swm.RspPickSeptTreePrize msg)
        {
            m_OnPickSeptTreePrizeEvent.Invoke(msg.result);
        }

        private GameEvent m_OnGetMoneyTreeBoxDataEvent = new GameEvent();
        public GameEvent OnGetMoneyTreeBoxDataEvent
        {
            get { return m_OnGetMoneyTreeBoxDataEvent; }
        }
        //请求显示宝箱信息
        public void ReqSeptTreeChestObtain_CS(int id)
        {
            m_MoneyTreeBoxList.GetBoxInfo(id);
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqSeptTreeChestObtain.StartReqSeptTreeChestObtain(tFBB);
            swm.ReqSeptTreeChestObtain.AddId(tFBB, (uint)id);
            var msg = swm.ReqSeptTreeChestObtain.EndReqSeptTreeChestObtain(tFBB);
            
            tFBB.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqSeptTreeChestObtain.HashID, tFBB);
        }
        private MoneyTreeBoxList m_MoneyTreeBoxList=new MoneyTreeBoxList();
        public MoneyTreeBoxList GetMoneyTreeBoxList
        {
            get
            {
                return m_MoneyTreeBoxList;
            }
        }

        private void RspSeptTreeChestObtain_SC(swm.RspSeptTreeChestObtain msg)
        {
            m_MoneyTreeBoxList.Refresh(msg);
            m_OnGetMoneyTreeBoxDataEvent.Invoke();
        }

        public MoneyTreeBoxData GetBoxInfo(int id)
        {
            return m_MoneyTreeBoxList.GetBoxInfo(id);
        }
        #endregion

        #region 内置

        /// <summary>
        /// 注册通信消息
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            // ---------------------------仙门基础系统----------------------------
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptList>(ResponseSociatyList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspUserRequestJoinList>(ResponseApplyingSociatyList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspRequestJoinSept>(ResponseApplyJoinSociaty_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCancelJoinSeptRequest>(ResponseCancelJoinSociaty_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCreateSept>(ResponseCreateSociaty_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSelfSeptData>(ResponseSelfSociatyData_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspModifySeptBulletin>(ResponseModifySociatyDeclaration_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspModifySeptAutoJoin>(ResponseModifySociatyAutoApprove_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspInviteJoinSept>(ResponseInviteJoinSociaty_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptRequestList>(ResponseSociatyApplyList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<NotifyRequestJoinSept>(ResponseNewApplyForJoinSociaty_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspChangeSeptMaster>(ResponseChangeSociatyMaster_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspKickSeptMember>(ResponseKickSociatyMember_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspAllSeptHistorys>(ResponseAllBigEvents_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspModifySeptIcon>(ResponseModifySeptIcon_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspModifySeptLimitCond>(ResponseModifySeptLimitCond_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspOpenSeptGroup>(ResponseOpenSeptGroup_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspMoveSeptGroupMember>(RspMoveSeptGroupMember_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspModifySeptGroupName>(RspModifySeptGroupName_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspModifySeptGroupCommission>(RspModifySeptGroupCommission_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptLevelUp>(RspSeptLevelUp_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptBenefit>(RspSeptBenefit_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspNotifySeptInvitedUser>(RspNotifySeptInvitedUser_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspReplySeptInvite>(RspReplySeptInvite_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspDonateSept>(RspDonateSept_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspBuySeptLease>(RspBuySeptLease_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspGoToCreateSept>(RspGoToCreateSept_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspTopListSeptInfo>(RspTopListSeptInfo_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptApplyLimitCond>(RspSeptApplyLimitCond_SC);

            // ---------------------------建筑物和福利----------------------------
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptUpgradeBuilding>(RspSeptUpgradeBuilding_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptAllStarsData>(RspSeptAllStarsData_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspActiveSeptStar>(RspActiveSeptStar_SC);

            MsgDispatcher.instance.RegisterFBMsgProc<RefreshSeptId>(ResponseRefreshSociatyID_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<NotifySeptChanged>(ResponseSociatyChangedNotify_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptAllBuilding>(RspSeptAllBuilding_SC);


            // ---------------------------仙门盛宴----------------------------
            MsgDispatcher.instance.RegisterFBMsgProc<RspBeginSeptFeastState>(RspBeginSeptFeastState_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSyncFirstSeptFeastDoingState>(RspSyncFirstSeptFeastDoingState_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSyncSecondSeptFeastDoingState>(RspSyncSecondSeptFeastDoingState_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCloseSeptFeastStepDisplay>(RspCloseSeptFeastStepDisplay_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptFeastOperateCookingBench>(RspSeptFeastOperateCookingBench_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspNotifyUserQuitCooking>(RspLeaveCookingZone_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptFeastCookingMenu>(RspSeptFeastCookingMenu_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspBeginCooking>(RspBeginCooking_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspCookingFoodNum>(RspCookingFoodNum_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspSettleSeptFeast>(RspSettleSeptFeast_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<RspDisplayServeEvent>(RspDisplayServeEvent_SC);


            // ---------------------------及时更新帮会数据----------------------------
            RedDotModel.Instance.onRedDotEvent.AddListener(ProcRedPoint);
            GameScene.Instance.onMainCharAdd.AddListener(RequestSelfSociatyData_CS);
            GameScene.Instance.onMainCharAdd.AddListener(RequestSociatyApplyList_CS);
            GameScene.Instance.onAddEntity.AddListener(OnAddEntityEvent);
            NotifyModel.Instance.onMessageEvent.AddListener(OnNoitfyModelMessageEvent);

            //GameScene.Instance.onMainCharAdd.AddListener(RequestAllBigEvents_CS);
            //摇钱树
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptTreeData>(ResponseMoneyTreeData_SC);
            
            MsgDispatcher.instance.RegisterFBMsgProc<RspPickSeptTreePrize>(ResponsePickSeptTreePrize_SC);
            
            MsgDispatcher.instance.RegisterFBMsgProc<RspSeptTreeChestObtain>(RspSeptTreeChestObtain_SC);



        }

        /// <summary>
        /// 重置数据
        /// </summary>
        [XLua.BlackList]
        public void Clear()
        {
            // -------------------------------------------------------------
            m_SociatyPageDict?.Clear();
            m_ApplyingSociatyList?.Clear();
            m_MemberList?.Clear();
            m_AllMemberList?.Clear();
            m_ApplyList?.Clear();
            m_GroupCommSetDict?.Clear();

            // ---------------------------仙门盛宴----------------------------
            m_FeastCookingMenuDict.Clear();



            // ---------------------------暂时未使用----------------------------
            m_BigEventList?.Clear();
            m_TsCaches?.Clear();

            m_buildingTopViewMode = false;
        }

        /// <summary>
        /// 加载配置表
        /// </summary>
        [XLua.BlackList]
        public void Load()
        {
            LoadCfg();
        }

        /// <summary>
        /// 加载配置
        /// </summary>
        private void LoadCfg()
        {
            SeptLevelupTableManager.Load();
            SeptGroupTableManager.Load();
            SeptBaseTableManager.Load();
            SeptIconTableManager.Load();
            SeptBuildingManager.Load();
            SeptBuildingUpgradeManager.Load();
            SeptStarBaseTypeManager.Load();
            SeptStarTypeManager.Load();
            SociatyDailyTaskManager.Load();

            // ---------------------------仙门盛宴----------------------------
            SeptFeastMenuTableManager.Load();

            m_InfoCfg.LoadData();
        }

        #endregion

        #region 函数

        /// <summary>
        /// 是否最大页数
        /// </summary>
        public bool HasMaxPage(uint curpageid)
        {
            return (curpageid == m_SociatyTotalPage);
        }

        /// <summary>
        /// 是否有仙门当前页数据
        /// </summary>
        /// <param name="curpageid"></param>
        /// <returns></returns>
        public bool HasSociatyCurPageData(uint curpageid)
        {
            return m_SociatyPageDict.ContainsKey(curpageid);
        }

        /// <summary>
        /// 清理仙门页面数据
        /// </summary>
        public void ClearSociatyPageData()
        {
            m_SociatyPageDict.Clear();
        }

        /// <summary>
        /// 获得总页数目
        /// </summary>
        /// <returns></returns>
        public int GetSociatyPageCount()
        {
            return m_SociatyPageDict.Count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageid"></param>
        /// <returns></returns>
        public int GetSociatyPageListCount(uint pageid)
        {
            if (!m_SociatyPageDict.ContainsKey(pageid))
                return 0;

            return m_SociatyPageDict[pageid].Count;
        }

        /// <summary>
        /// 根据页数和索引获取仙门信息
        /// </summary>
        /// <param name="pageid"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public SociatyBaseData GetSociatyInfoByPageIndex(uint pageid, int index)
        {
            if (!m_SociatyPageDict.ContainsKey(pageid))
                return null;

            List<SociatyBaseData> list = m_SociatyPageDict[pageid];
            if (list != null)
            {
                int count = list.Count;
                if (index < 0 || index >= count)
                    return null;
                
                return list[index];
            }

            return null;
        }

        /// <summary>
        /// 获取指定帮会id的帮会信息
        /// </summary>
        public SociatyBaseData GetSociatyInfoById(ulong id)
        {
            foreach (var iter in m_SociatyPageDict)
            {
                if (iter.Value != null)
                {
                    for (int i = 0; i < iter.Value.Count; i++)
                    {
                        SociatyBaseData tInfo = iter.Value[i];
                        if (tInfo.id == id)
                            return tInfo;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// 获取指定索引的正在被申请的帮会id
        /// </summary>
        public ulong GetApplyingSociatyByIndex(int index)
        {
            if (index < 0 || index >= applyingSociatyCount)
                return 0;

            return m_ApplyingSociatyList[index];
        }

        /// <summary>
        /// 获取仙门组配表
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        public SeptGroupTableBase? GetSeptGroupTable(int groupid)
        {
            SeptGroupTableBase? data = SeptGroupTableManager.GetData(groupid);
            if (data.HasValue)
            {
                return data.Value;
            }

            return null;
        }

        /// <summary>
        /// 是否有仙门组配表
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        public bool HasSeptGroupTable(int groupid)
        {
            SeptGroupTableBase? data = SeptGroupTableManager.GetData(groupid);
            return data.HasValue;
        }

        /// <summary>
        /// 获取仙门组配表
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SeptGroupTableBase GetSeptGroupTableByIndex(int index)
        {
            if (index < 0 || index >= SeptGroupTableManager.Instance.m_DataList.SeptGroupTableLength)
            {
                return default(SeptGroupTableBase);
            }

            SeptGroupTableBase? data = SeptGroupTableManager.Instance.m_DataList.SeptGroupTable(index);
            if (data.HasValue)
            {
                return data.Value;
            }

            return default(SeptGroupTableBase);
        }

        /// <summary>
        /// 获取仙门组配表数目
        /// </summary>
        /// <returns></returns>
        public int GetSeptGroupTableCnt()
        {
            return SeptGroupTableManager.Instance.m_DataList.SeptGroupTableLength;
        }

        /// <summary>
        /// 获取仙门基础表
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public SeptBaseTableBase? GetSeptBaseTable(int level)
        {
            return SeptBaseTableManager.GetData(level);
        }

        /// <summary>
        /// 是否有仙门基础表
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public bool HasSeptBaseTable(int level)
        {
            SeptBaseTableBase? data = SeptBaseTableManager.GetData(level);
            return data.HasValue;
        }

        /// <summary>
        /// 根据id获取仙门icon表
        /// </summary>
        /// <param name="iconid"></param>
        /// <returns></returns>
        public SeptIconTableBase GetSeptIconTableById(int iconid)
        {
            SeptIconTableBase? data = SeptIconTableManager.GetData(iconid);
            if (data.HasValue)
            {
                return data.Value;
            }

            return default(SeptIconTableBase);
        }

        /// <summary>
        /// 是否有id获取的仙门icon表
        /// </summary>
        /// <param name="iconid"></param>
        /// <returns></returns>
        public bool HasSeptIconTableById(int iconid)
        {
            SeptIconTableBase? data = SeptIconTableManager.GetData(iconid);
            return data.HasValue;
        }

        /// <summary>
        /// 根据index获取仙门icon表
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SeptIconTableBase GetSeptIconTableByIndex(int index)
        {
            if (index < 0 || index >= SeptIconTableManager.Instance.m_DataList.SeptIconTableLength)
            {
                return default(SeptIconTableBase);
            }

            SeptIconTableBase? data = SeptIconTableManager.Instance.m_DataList.SeptIconTable(index);
            if (data.HasValue)
            {
                return data.Value;
            }

            return default(SeptIconTableBase);
        }

        /// <summary>
        /// 是否有index获取的仙门icon表
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool HasSeptIconTableByIndex(int index)
        {
            if (index < 0 || index >= SeptIconTableManager.Instance.m_DataList.SeptIconTableLength)
            {
                return false;
            }

            SeptIconTableBase? data = SeptIconTableManager.Instance.m_DataList.SeptIconTable(index);
            return data.HasValue;
        }

        /// <summary>
        /// 获取仙门icon表数目
        /// </summary>
        /// <returns></returns>
        public int GetSeptIconTableCnt()
        {
            return SeptIconTableManager.Instance.m_DataList.SeptIconTableLength;
        }

        /// <summary>
        /// 获取指定等级对应的帮会配置
        /// </summary>   
        public SeptLevelupTableBase GetSeptLevelupTable(int level)
        {
            SeptLevelupTableBase? data = SeptLevelupTableManager.GetData(level);
            if (data.HasValue)
            {
                return data.Value;
            }

            return default(SeptLevelupTableBase);
        }

        /// <summary>
        /// 获取所属帮会的基本数据
        /// </summary>
        public SociatyBaseData GetSociatyBaseData()
        {
            return m_SelfSociatyBaseData;
        }

        /// <summary>
        /// 获取主角的帮会成员数据
        /// </summary>
        /// <returns></returns>
        public SociatyMemberData GetMainCharMemberData()
        {
            return m_MainCharMemberData;
        }

        /// <summary>
        /// 获取指定索引的成员信息
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SociatyMemberData? GetAllMemberDataByIndex(int index)
        {
            if (index < 0 || index >= allmemberCount)
                return null;

            return m_AllMemberList[index];
        }


        /// <summary>
        /// 获取指定id的帮会成员信息
        /// </summary>
        public SociatyMemberData? GetAllMemberDataById(ulong id)
        {
            for (int tIdx = 0, tCount = allmemberCount; tIdx < tCount; tIdx++)
            {
                if (m_AllMemberList[tIdx].charid == id)
                    return m_AllMemberList[tIdx];
            }

            return null;
        }

        /// <summary>
        /// 获取指定索引的成员信息
        /// </summary>
        public SociatyMemberData GetMemberDataByIndex(int index)
        {
            if (index < 0 || index >= memberCount)
                return default(SociatyMemberData);

            return m_MemberList[index];
        }

        /// <summary>
        /// 获取指定id的帮会成员信息
        /// </summary>
		public SociatyMemberData? GetMemberDataById(ulong id)
        {
            for (int tIdx = 0, tCount = memberCount; tIdx < tCount; tIdx++)
            {
                if (m_MemberList[tIdx].charid == id)
                    return m_MemberList[tIdx];
            }

            return null;
        }

        /// <summary>
        /// 获取指定索引的申请人员信息
        /// </summary>
        public ApplyPlayerInfo GetApplyDataByIndex(int index)
        {
            if (index < 0 || index >= applyCount)
                return default(ApplyPlayerInfo);

            return m_ApplyList[index];
        }

        /// <summary>
        /// 是否门主组
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        public bool IsSeptGroupMaster(int groupid)
        {
            return (groupid == (int)SeptGroupType.gmaster);
        }

        /// <summary>
        /// 是否帮主
        /// </summary>
        /// <param name="charid"></param>
        /// <returns></returns>
        public bool IsLeader(ulong charid)
        {
            return (m_SelfSociatyBaseData.leaderID == charid);
        }

        /// <summary>
        /// 玩家是否是帮主
        /// </summary>
        /// <returns></returns>
        public bool IsMainMemberLeader()
        {
            ulong charid = m_MainCharMemberData.charid;
            if (charid == 0)
                return false;

            if (m_SelfSociatyBaseData.leaderID == 0)
                return false;

            return IsLeader(charid);
        }

        /// <summary>
        /// 玩家能不能编辑组
        /// </summary>
        /// <returns></returns>
        public bool IsMainMemberCanEditGroup(int targroupid)
        {
            uint groupid = m_MainCharMemberData.groupid;
            return groupid < targroupid;
        }

        /// <summary>
        /// 获取组类型
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        public SociatyGroupCommSet GetGroupCommSet(int groupid)
        {
            if (m_GroupCommSetDict.ContainsKey(groupid))
                return m_GroupCommSetDict[groupid];

            return null;
        }

        /// <summary>
        /// 是否分组被打开
        /// </summary>
        /// <param name="groupid"></param>
        /// <returns></returns>
        public bool HasGroupOpen(int groupid)
        {
            SociatyGroup group = m_SelfSociatyBaseData.GetSociatyGroupByGroupId(groupid);
            if (group == null)
                return false;

            return group.isopen;
        }

        /// <summary>
        /// 玩家的某个权限是否被打开
        /// </summary>
        /// <returns></returns>
        public bool HasMainMemCommOpen(uint commtype)
        {
            int groupid = (int)m_MainCharMemberData.groupid;
            return HasCommOpenByGroupId(groupid, commtype);
        }

        /// <summary>
        /// 根据groupid查找是否权限被打开
        /// </summary>
        /// <param name="groupid"></param>
        /// <param name="commtype"></param>
        /// <returns></returns>
        public bool HasCommOpenByGroupId(int groupid, uint commtype)
        {
            return HasCommOpenByGroupType(groupid, commtype);
        }

        /// <summary>
        /// 根据grouptype查找是否权限被打开
        /// </summary>
        /// <param name="grouptype"></param>
        /// <param name="commtype"></param>
        /// <returns></returns>
        public bool HasCommOpenByGroupType(int groupid, uint commtype)
        {
            SociatyGroupCommSet commset = GetGroupCommSet(groupid);
            if (commset == null)
                return false;

            return commset.HasCommOpen(commtype);
        }

        /// <summary>
        /// 复位修改的组权限表
        /// </summary>
        /// <param name="groupid"></param>
        public void ResetModifyGroupComm(uint groupid)
        {
            m_ModifyGroupCommSet.groupid = groupid;
            m_ModifyGroupCommSet.Clear();
        }

        /// <summary>
        /// 填充修改的组权限表
        /// </summary>
        /// <param name="commision"></param>
        /// <param name="isopen"></param>
        public void FillModifyGroupComm(uint commision, bool isopen)
        {
            m_ModifyGroupCommSet.FillData(commision, isopen);
        }

        /// <summary>
        /// 是否仙门成员满员
        /// </summary>
        /// <returns></returns>
        public bool HasSociatyMemberFull()
        {
            SeptBaseTableBase? septcfgdata = GetSeptBaseTable((int)m_SelfSociatyBaseData.level);
            if (!septcfgdata.HasValue)
                return true;

            SeptBaseTableBase septcfg = septcfgdata.Value;
            int maxnum = septcfg.maxmember;
            return (m_SelfSociatyBaseData.membercnt >= maxnum);
        }

        /// <summary>
        /// 初始化自己的仙门组权限
        /// </summary>
        private void InitSociatyGroupCommission()
        {
            m_GroupCommSetDict.Clear();

            int groupcount = m_SelfSociatyBaseData.grouplist.Count;
            for (int i = 0; i < groupcount; i++)
            {
                SociatyGroup group = m_SelfSociatyBaseData.grouplist[i];
                if (group == null)
                    continue;

                SociatyGroupCommSet commset = new SociatyGroupCommSet(group);
                m_GroupCommSetDict.Add((int)group.gid, commset);
            }
        }

        /// <summary>
        /// 客户端模拟删除申请列表
        /// </summary>
        /// <param name="charid"></param>
        private void RemoveApplyListByClient(ulong charid)
        {
            if (charid <= 0)
            {
                m_ApplyList.Clear();
            }
            else
            {
                bool hasremoveid = false;
                int removeid = 0;
                for (int i = 0; i < m_ApplyList.Count; i++)
                {
                    ApplyPlayerInfo applyinfo = m_ApplyList[i];
                    if (applyinfo.charID == charid)
                    {
                        hasremoveid = true;
                        removeid = i;
                    }
                }

                if (hasremoveid)
                {
                    m_ApplyList.RemoveAt(removeid);
                }
            }

            m_OnApplyListArrived.Invoke();
        }

        /// <summary>
        /// 获取仙门建筑物表
        /// </summary>
        /// <param name="buildingtype"></param>
        /// <returns></returns>
        public SeptBuildingBase? GetSeptBuildingTable(int buildingtype)
        {
            return SeptBuildingManager.GetData(buildingtype);
        }

        /// <summary>
        /// 获取建筑物升级表
        /// </summary>
        /// <param name="buildingtype"></param>
        /// <param name="buildinglevel"></param>
        /// <returns></returns>
        public SeptBuildingUpgradeBase? GetSeptBuildingUpgradeTable(int buildingtype, int buildinglevel)
        {
            return SeptBuildingUpgradeManager.GetData(buildingtype, buildinglevel);
        }

        /// <summary>
        /// 获取星象基础类型表数目
        /// </summary>
        /// <returns></returns>
        public int GetSeptStarBaseTypeTableCount()
        {
            return SeptStarBaseTypeManager.Instance.m_DataList.SeptStarBaseTypeLength;
        }

        /// <summary>
        /// 根据索引获取星象类型表
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SeptStarBaseTypeBase? GetSeptStarBaseTypeTableByIndex(int index)
        {
            return SeptStarBaseTypeManager.Instance.m_DataList.SeptStarBaseType(index);
        }

        /// <summary>
        /// 获取星象表数目
        /// </summary>
        /// <returns></returns>
        public int GetSeptStarTypeTableCount()
        {
            return SeptStarTypeManager.Instance.m_DataList.SeptStarTypeLength;
        }

        /// <summary>
        /// 根据索引获取星象表数据
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public SeptStarTypeBase? GetSeptStarTypeTableByIndex(int index)
        {
            return SeptStarTypeManager.Instance.m_DataList.SeptStarType(index);
        }

        /// <summary>
        /// 建筑物是否星象类型
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public bool IsBuildingStarType(int type)
        {
            return (type == (int)SeptBuildingType.star);
        }

        /// <summary>
        /// 设置npc的可见性
        /// </summary>
        /// <param name="entity"></param>
        public void SetNpcVisible(Entity entity)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            if (entity == null)
                return;

            bool isnpc = entity.IsNpc();
            if (!isnpc)
                return;

            Npc _npcData = entity as Npc;
            if (_npcData == null)
                return;

            NpcTableBase? npccfg = _npcData.NpcConfig;
            if (!npccfg.HasValue)
                return;

            if (npccfg.Value.id == m_InfoCfg.npc_septpharmacy)  // 药房
            {
                SetNpcVisible(entity, (int)swm.SeptBuildingType.drugstore);
            }
            else if (npccfg.Value.id == m_InfoCfg.npc_septcast)     // 铸造炉
            {
                SetNpcVisible(entity, (int)swm.SeptBuildingType.furnace);
            }
            else if (npccfg.Value.id == m_InfoCfg.npc_septdivine)    // 占卜台
            {
                SetNpcVisible(entity, (int)swm.SeptBuildingType.divine);
            }
            else if (npccfg.Value.id == m_InfoCfg.npc_septstar)     // 星象阁
            {
                SetNpcVisible(entity, (int)swm.SeptBuildingType.star);
            }
        }

        private void SetNpcVisible(Entity entity, int buildingtype)
        {
            if (m_SelfSociatyBaseData == null)
                return;

            SociatyBuilding building = m_SelfSociatyBaseData.GetBuilding(buildingtype);
            if (building != null && building.level > 0)
            {
                entity.Visible = true;
                entity.CanSelect = true;
            }
            else
            {
                entity.Visible = false;
                entity.CanSelect = false;
            }
        }

        /// <summary>
        /// 刷新npc可见性
        /// </summary>
        private void RefreshNpcVisible()
        {
            Entity pharmacynpc = GameScene.Instance.GetNpcEntityByBaseId(m_InfoCfg.npc_septpharmacy, false, false);
            if (pharmacynpc != null)
            {
                SetNpcVisible(pharmacynpc, (int)swm.SeptBuildingType.drugstore);
            }

            Entity castnpc = GameScene.Instance.GetNpcEntityByBaseId(m_InfoCfg.npc_septcast, false, false);
            if (castnpc != null)
            {
                SetNpcVisible(castnpc, (int)swm.SeptBuildingType.furnace);
            }

            Entity divinenpc = GameScene.Instance.GetNpcEntityByBaseId(m_InfoCfg.npc_septdivine, false, false);
            if (divinenpc != null)
            {
                SetNpcVisible(divinenpc, (int)swm.SeptBuildingType.divine);
            }

            Entity starnpc = GameScene.Instance.GetNpcEntityByBaseId(m_InfoCfg.npc_septstar, false, false);
            if (starnpc != null)
            {
                SetNpcVisible(starnpc, (int)swm.SeptBuildingType.star);
            }
        }


        public void MoveBuildCamera(float dx, float dz)
        {
            var hcamera = ICameraHelper.Instance.CurrentController as SeptBuildCameraController;
            if (hcamera != null)
                hcamera.MoveXZ(dx, dz);
        }

        /// <summary>
        /// 根据鼠标位置拾取坐标id
        /// </summary>
        /// <returns></returns>
        public int GetBuildingIdByMousePos(out UnityEngine.Vector3 trigger_pos)
        {
            trigger_pos = UnityEngine.Vector3.zero;

            Camera mainCamera = ICameraHelper.Instance.MainCamera;
            var pos = IUnityInput.Instance.mousePosition;
            Ray ray = mainCamera.ScreenPointToRay(pos);

            var mask = UserLayerMask.StaticMeshBig |
                UserLayerMask.StaticMeshMiddle | UserLayerMask.StaticMeshSmall;

            // 测试
            //var mask = UserLayerMask.Default | UserLayerMask.NPC | UserLayerMask.StaticMeshBig |
            //    UserLayerMask.StaticMeshMiddle | UserLayerMask.StaticMeshSmall;

            RaycastHit hitinfo;
            if (!Physics.Raycast(ray, out hitinfo, 1000.0f, (int)mask))
                return 0;

            var _pos = hitinfo.point;
            _pos = _pos.UnityToWorldVec();

            var trigger_proxy = TriggerManager.Instance.TriggerProxy;
            if (trigger_proxy == null)
                return 0;

            TriggerBound triggerbound = trigger_proxy.GetTriggerBoundByLblAndPos((int)TriggerLabel.SeptBuilding, _pos);
            if (triggerbound == null)
                return 0;

            trigger_pos = triggerbound.Center;
            return triggerbound.GetTriggerDataInt();
        }

        public bool GetBuildingModelPos(int buildingtype, out UnityEngine.Vector3 _pos)
        {
            _pos = UnityEngine.Vector3.zero;

            var trigger_proxy = TriggerManager.Instance.TriggerProxy;
            if (trigger_proxy == null)
                return false;

            var triggerbound = trigger_proxy.GetTriggerBoundByLblAndIntData((int)TriggerLabel.SeptBuilding, buildingtype);
            if (triggerbound == null)
                return false;

            _pos = triggerbound.Center;
            _pos = _pos.WorldToUnityVec();
            return true;
        }

        // ---------------------------仙门盛宴----------------------------

        /// <summary>
        /// 获取仙门盛宴菜单
        /// </summary>
        /// <param name="baseid"></param>
        /// <returns></returns>
        public SociatyFeastCookingMenu GetFeastCookingMenu(uint baseid)
        {
            if (!m_FeastCookingMenuDict.ContainsKey(baseid))
                return null;

            return m_FeastCookingMenuDict[baseid];
        }




        // ---------------------------暂时未使用----------------------------

        /// <summary>
        /// 获取指定索引的大事件信息
        /// </summary>
        public BigEventInfo GetBigEventByIndex(int index)
		{
            if (index < 0 || index >= bigEventCount)
                return default(BigEventInfo);

			return m_BigEventList[index];
		}

        #endregion
    }
}

