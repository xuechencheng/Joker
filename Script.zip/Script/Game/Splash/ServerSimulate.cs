﻿namespace Bokura
{
	public class ServerSimulate
	{
		protected ServerSimulate() { }



		private static object s_SyncObj = new object();
		private static ServerSimulate s_Instance;
		public static ServerSimulate Instance
		{
			get
			{
				if (s_Instance == null)
				{
					lock (s_SyncObj)
					{
						if (s_Instance == null)
							s_Instance = new ServerSimulate();
					}
				}
				return s_Instance;
			}

		}
	}
}
