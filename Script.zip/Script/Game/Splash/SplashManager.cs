using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Bokura
{
    public class SplashManager:MonoBehaviour
	{
        /// <summary>
        /// Splash的状态
        /// </summary>
        private enum State
        {
            FadeIn  = 0,
            Stay    = 1,
            FadeOut = 2,
            Finish  = 3,
            None    = 4,
        }



		protected SplashManager()
		{
			s_Instance = this;
		}



		private static SplashManager s_Instance;
        /// <summary>
        /// 单例
        /// </summary>
		public static SplashManager Instance
		{
			get { return s_Instance; }
		}



        /// <summary>
        /// 配置
        /// </summary>
		[System.Serializable]
		public struct SplashConfig
		{
            /// <summary>
            /// Logo的资源路径
            /// </summary>
			public string   logoPath;
            /// <summary>
            /// 淡入时长
            /// </summary>
			public float    fadeInDuration;
            /// <summary>
            /// 停留时长
            /// </summary>
			public float    stayDuration;
            /// <summary>
            /// 淡出时长
            /// </summary>
			public float    fadeOutDuration;
		}



		[SerializeField]
		private List<SplashConfig> m_SplashConfigs = new List<SplashConfig>(2);



        /// <summary>
        /// 显示Logo的组件
        /// </summary>
		public Image m_Splash;



        /// <summary>
        /// 背景组件
        /// </summary>
		public GameObject m_Background;



        /// <summary>
        /// 资源更新组件
        /// </summary>
        private Transform m_UpdateWnd;



        /// <summary>
        /// Logo的颜色
        /// </summary>
        private Color m_LogoColor;



        /// <summary>
        /// 当前状态
        /// </summary>
        private State m_CurState;



        /// <summary>
        /// 当前使用的配置索引
        /// </summary>
        private int m_SplashIdx;



        /// <summary>
        /// 当前动画总时长
        /// </summary>
        private float m_Duration;



        /// <summary>
        /// 当前动画播放时长
        /// </summary>
        private float m_Elapse;



        /// <summary>
        /// 完成后的回调
        /// </summary>
        private UnityAction m_OnFinishCallback;



        /// <summary>
        /// 唯一入口：播放Splash
        /// </summary>
		public void ShowSplash(UnityAction callback)
		{
            m_OnFinishCallback = callback;
            InitSplash();
            PrepareForFadeIn();
        }



        /// <summary>
        /// 初始化
        /// </summary>
        private void InitSplash()
        {
            //激活UI对象
            gameObject.SetActive(true);

            m_UpdateWnd = GameObject.Find("UIRoot")?.transform.Find("ui_single_UpdateWnd");

            m_LogoColor = new Color(1, 1, 1, 0);

            if (null == m_Splash)
                m_Splash = transform.Find("img_splash")?.GetComponent<Image>();

            m_SplashIdx = -1;
        }



        private void Update()
        {
            switch (m_CurState)
            {
                case State.FadeIn:
                    SplashFadeIn();
                    break;
                case State.Stay:
                    SplashStay();
                    break;
                case State.FadeOut:
                    SplashFadeOut();
                    break;
                case State.Finish:
                    SplashFinish();
                    break;
                case State.None:
                    break;
            }
        }



        /// <summary>
        /// Splash是否可行
        /// </summary>
        private bool CheckSplashValid()
        {
            if(null == m_Splash)
            {
                m_CurState = State.Finish;
                return false; 
            }
            return true;
        }



        /// <summary>
        /// 准备FadeIn所需的数据和状态
        /// </summary>
        private void PrepareForFadeIn()
        {
            if (!CheckSplashValid()) return;

            m_SplashIdx     = m_SplashIdx + 1;
            m_LogoColor.a   = 0.0f;
            m_Splash.color  = m_LogoColor;
            m_Splash.sprite = null;
            m_Duration      = 0;
            m_Elapse        = 0;

            if (m_SplashIdx >= 0 && m_SplashIdx < m_SplashConfigs.Count)
            {
                SplashConfig tPair = m_SplashConfigs[m_SplashIdx];
                m_Splash.sprite = LoadSpriteFromResourcesFolder(tPair.logoPath);
                m_Duration = tPair.fadeInDuration;

                if (m_Duration <= 0)
                    PrepareForStay();
                else
                    m_CurState = State.FadeIn;
            }
            else
                PrepareForFinish();
        }



        private void SplashFadeIn()
        {
            //淡入
            if (m_Elapse < m_Duration)
            {
                m_LogoColor.a = Mathf.Clamp01(m_Elapse / m_Duration);
                m_Splash.color = m_LogoColor;
                m_Elapse += Time.deltaTime;
            }
            else
                PrepareForStay();
        }



        /// <summary>
        /// 准备Stay所需的数据和状态
        /// </summary>
        private void PrepareForStay()
        {
            if (!CheckSplashValid()) return;

            m_LogoColor.a   = 1.0f;
            m_Splash.color  = m_LogoColor;
            m_Duration      = 0;
            m_Elapse        = 0;

            if (m_SplashIdx >= 0 && m_SplashIdx < m_SplashConfigs.Count)
            {
                SplashConfig tPair = m_SplashConfigs[m_SplashIdx];
                m_Duration = tPair.stayDuration;

                if (m_Duration <= 0)
                    PrepareForFadeOut();
                else
                    m_CurState = State.Stay;
            }
            else
                PrepareForFinish();
        }



        private void SplashStay()
        {
            //停留
            if (m_Elapse < m_Duration)
                m_Elapse += Time.deltaTime;
            else
                PrepareForFadeOut();
        }



        /// <summary>
        /// 准备FadeOut所需的数据和状态
        /// </summary>
        private void PrepareForFadeOut()
        {
            if (!CheckSplashValid()) return;

            m_Duration = 0;
            m_Elapse = 0;

            if (m_SplashIdx >= 0 && m_SplashIdx < m_SplashConfigs.Count)
            {
                SplashConfig tPair = m_SplashConfigs[m_SplashIdx];
                m_Duration = tPair.fadeOutDuration;

                if (m_Duration <= 0)
                    PrepareForFadeIn();
                else
                    m_CurState = State.FadeOut;
            }
            else
                PrepareForFinish();
        }



        private void SplashFadeOut()
        {
            //淡出
            if (m_Elapse < m_Duration)
            {
                m_LogoColor.a = 1 - Mathf.Clamp01(m_Elapse / m_Duration);
                m_Splash.color = m_LogoColor;
                m_Elapse += Time.deltaTime;
            }
            else
                PrepareForFadeIn();
        }



        /// <summary>
        /// 准备Finish所需的数据和状态
        /// </summary>
        private void PrepareForFinish()
        {
            //Logo显示过程结束，显示更新检查画面
            m_UpdateWnd?.gameObject.SetActive(true);
            if (null == m_Background)
                m_Background = transform.Find("img_background")?.gameObject;
            m_Background?.SetActive(false);

            m_CurState = State.Finish;
        }



        private void SplashFinish()
        {
            GameObject.Destroy(gameObject);
            m_CurState = State.None;
            //开始更新检查
            //或者直接初始化（时间较长，可能卡顿）
            var tCallback = m_OnFinishCallback;
            m_OnFinishCallback = null;
            if(null != tCallback)
                tCallback.Invoke();
        }



		private Sprite LoadSpriteFromResourcesFolder(string path)
		{
			Sprite tSprite = null;
			if(!string.IsNullOrEmpty(path))
				tSprite = Resources.Load<Sprite>(path);
			return tSprite;
		}
	}
}
