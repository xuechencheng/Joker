using System;
using System.Collections.Generic;
using swm;
using Bokura;

namespace Bokura
{

    [XLua.LuaCallCSharpAttribute]
    public class StarPosInfo
    {
        StarPositionTableBase m_config;
        StarPosInfo m_parent;
        List<StarPosInfo> m_children = new List<StarPosInfo>();

        public bool Unlock = false;
        public bool Active = false;

        [XLua.BlackList]
        public StarPosInfo(int id)
        {
            var config = StarPositionTableManager.GetData(id);
            //UnityEngine.Debug.Assert(config.HasValue, Bokura.Utilities.BuildString(id.ToString(), " not found!"));
            m_config = config.Value;
        }

        public StarPositionTableBase Config
        {
            get
            {
                return m_config;
            }
        }


        public int ID
        {
            
            get
            {
                return m_config.id;
            }
        }

        public StarPosInfo Parent
        {
            get
            {
                return m_parent;
            }
            set {
                m_parent = value;
            }
        }

        public List<StarPosInfo> GetChilds() {
            return m_children;
        }

        public void AddChild(StarPosInfo starpos)
        {
            m_children.Add(starpos);
        }

        public void UnlockChild()
        {
            for (int i = 0; i < m_children.Count; i++) {
                m_children[i].Unlock = true;
            }
        }

        public void Reset()
        {
            Unlock = false;
            Active = false;
        }
    }



    [XLua.LuaCallCSharpAttribute]
    public class StarData {
        //private bool m_active = false;
        //private uint m_starposlist = 0;
        public StarTableBase Config;
        public List<StarPosInfo> m_starposinfo = new List<StarPosInfo>();
        //解锁没
        private bool m_unlock = false;
        //装备没
        private bool m_active = false;

        public bool Unlock {
            get {
                return m_unlock;
            }
            set {
                m_unlock = value;
            }
            
        }

        public bool Active {
            get {
                return m_active;
            }
            set {
                m_active = value;
            }
            
        }

        public int id {
            get {
                return Config.id;
            }
        }

        private StarPosInfo GetStarpos(int id) {
            for (int i = 0; i < m_starposinfo.Count; i++) {
                if (m_starposinfo[i].ID == id)
                    return m_starposinfo[i];
            }
            return null;
        }

        public void SetStarPos() {
            for (int i = 0; i < m_starposinfo.Count; i++) {
                var starpos = m_starposinfo[i];
                int fatherid = starpos.Config.father_position;
                var father = GetStarpos(fatherid);
                if (father != null)
                {
                    starpos.Parent = father;
                    father.AddChild(starpos);
                }
                else
                {
                    starpos.Parent = null;
                }

            }
        }

        //解锁星位
        /*public void UnlockStarpos(uint starposition)
        {
            for (int i = 0; i < m_starposinfo.Count; i++) {
                if (m_starposinfo[i].ID == starposition) {
                    m_starposinfo[i].Unlock = true;
                }
            }
        }*/

        public void LightStar(uint starposition)
        {
            for (int i = 0; i < m_starposinfo.Count; i++)
            {
                if (m_starposinfo[i].ID == starposition)
                {
                    m_starposinfo[i].Unlock = true;
                    m_starposinfo[i].Active = true;//点亮
                    m_starposinfo[i].UnlockChild();
                    return;
                }
            }
        }

        public void Reset()
        {
            Unlock = false;
            Active = false;
            for (int i = 0; i < m_starposinfo.Count; i++) {
                m_starposinfo[i].Reset();
            }
        }
    }


    [XLua.LuaCallCSharpAttribute]
    public class StarMgr : ClientSingleton<StarMgr>
    {


        public Event<int> OnStartRefresh = new Event<int>();
        public Event<int, int> OnStarPosRefresh = new Event<int, int>();
        public Event<int> OnGetStar = new Event<int>();
        public Event<int> OnStarPerfect = new Event<int>();

        //Dictionary<int, StarInfo> m_starInfoList = new Dictionary<int, StarInfo>(10);
        //StarInfo[] m_activeStarSlots = new StarInfo[9];
        //bool[] m_StarSlotsUnlock = new bool[9];
        //以上老代码

        public Event OnStarLoaded = new Event();
        public Event onStarDataChange = new Event();
        public Event onStarPosDataChange = new Event();
        public Event<int> onLightStarPos = new Event<int>();
        public Event onStarWatchChange = new Event();
        public Event onStarResetCountChange = new Event();
        public bool HasValue = false;
        private List<StarData> m_starDatas_in = new List<StarData>();
        private List<StarData> m_starDatas_mid = new List<StarData>();
        private List<StarData> m_starDatas_out = new List<StarData>();

        private uint m_cur_watching_times = 0;//当前观星次数
        private uint m_max_watching_times = 0;//最大观星次数
        private List<uint> m_active_star_count = new List<uint>();//星蕴装备数量信息
        private uint m_star_reset_count = 0;//归元次数

        public int StarWatchingCostExp {
            get {
                return (int)StarWatchingCost.Num;
            }
        }

        public uint Cur_watchingTimes {
            get {
                return m_cur_watching_times;
            }
        }

        public uint Max_watchingtimes {
            get {
                return m_max_watching_times;
            }
        }

        public List<uint> Active_starcount {
            get {
                return m_active_star_count;
            }
        }

        public uint StarResetCount {
            get {
                return m_star_reset_count;
            }
        }


        public List<StarData> GetStarDatasByType(int type) {
            if (type == 0)
                return m_starDatas_in;
            else if (type == 1)
                return m_starDatas_mid;
            else
                return m_starDatas_out;
        }

        public StarData GetStarData(int id) {
            var starcfg = StarTableManager.GetData(id);
            if (starcfg.HasValue) {
                return GetStarData(starcfg.Value.type, id);
            }
            return null;
        }

        public StarData GetStarData(int type, int id) {
            if (type == 0)
            {
                for (int i = 0; i < m_starDatas_in.Count; i++) {
                    if (m_starDatas_in[i].id == id)
                        return m_starDatas_in[i];
                }

            }
            else if (type == 1)
            {
                for (int i = 0; i < m_starDatas_mid.Count; i++)
                {
                    if (m_starDatas_mid[i].id == id)
                        return m_starDatas_mid[i];
                }
            }
            else {
                for (int i = 0; i < m_starDatas_out.Count; i++)
                {
                    if (m_starDatas_out[i].id == id)
                        return m_starDatas_out[i];
                }
            }
            return null;
        }

        public int GetActiveStarCount(int type) {
            int ret = 0;
            if (type == 0)
            {
               for(int i = 0; i < m_starDatas_in.Count; i++)
                {
                    if (m_starDatas_in[i].Unlock)
                        ret++;

                }
            }
            else if (type == 1)
            {
                for (int i = 0; i < m_starDatas_mid.Count; i++)
                {
                    if (m_starDatas_mid[i].Unlock)
                        ret++;

                }
            }
            else
            {
                for (int i = 0; i < m_starDatas_out.Count; i++)
                {
                    if (m_starDatas_out[i].Unlock)
                        ret++;

                }
            }

            return ret;
        }



        [XLua.BlackList]
        public StarMgr()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspStarData>(ProcRspStarData);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyAddStar>(ProcNotifyAddStar);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspStarExercises>(ProcRspStarExercises);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspLoadStar>(ProcRspLoadStar);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspUnloadStar>(ProcRspUnloadStar);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshStarWatching>(ProcRefreshStarWatching);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshStarReset>(ProcRefreshStarReset);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspStarReset>(ProprspStarReset);
        }

        private void LoadStarConfigData() {
            m_starDatas_in.Clear();
            m_starDatas_mid.Clear();
            m_starDatas_out.Clear();
            //设置星蕴数据
            var datas = StarTableManager.Instance.m_DataList;
            for (int i = 0; i < datas.StarTableLength; i++) {
                var st = datas.StarTable(i);
                if (st.HasValue) {
                    StarData sd = new StarData();
                    sd.Config = st.Value;
                    if (st.Value.type == 0)
                        m_starDatas_in.Add(sd);
                    else if (st.Value.type == 1)
                        m_starDatas_mid.Add(sd);
                    else
                        m_starDatas_out.Add(sd);
                }
            }

            //设置星蕴的星位数据
            var posdatas = StarPositionTableManager.Instance.m_DataList;
            for (int i = 0; i < posdatas.StarPositionTableLength; i++) {
                var data = posdatas.StarPositionTable(i);
                if (data.HasValue) {
                    var starcfg = StarTableManager.GetData(data.Value.starid);
                    if (starcfg.HasValue) {
                        var stardata = GetStarData(starcfg.Value.type, data.Value.starid);
                        stardata.m_starposinfo.Add(new StarPosInfo(data.Value.id));
                    }
                }
            }

            for (int i = 0; i < m_starDatas_in.Count; i++) {
                m_starDatas_in[i].SetStarPos();
            }

            for (int i = 0; i < m_starDatas_mid.Count; i++)
            {
                m_starDatas_mid[i].SetStarPos();
            }

            for (int i = 0; i < m_starDatas_out.Count; i++)
            {
                m_starDatas_out[i].SetStarPos();
            }

        }

#if UNITY_EDITOR
        private void PrintStarInfo()
        {
            for (int i = 0; i < m_starDatas_in.Count; i++)
            {
                PrintStar(m_starDatas_in[i]);
            }
            for (int i = 0; i < m_starDatas_mid.Count; i++)
            {
                PrintStar(m_starDatas_mid[i]);
            }
            for (int i = 0; i < m_starDatas_out.Count; i++)
            {
                PrintStar(m_starDatas_out[i]);
            }
        }

        private void PrintStar(StarData star)
        {
            var id = star.id;
            var unlock = star.Unlock;
            var active = star.Active;
            LogHelper.LogError("starid:" + id + " unlock " + unlock + " active:" + active);
            for (int i = 0; i < star.m_starposinfo.Count; i++)
            {
                PrintStarPos(star.m_starposinfo[i]);
            }
        }

        private void PrintStarPos(StarPosInfo starPosInfo)
        {
            LogHelper.LogError("    starposid:" + starPosInfo.ID + " unlock " + starPosInfo.Unlock + " active:" + starPosInfo.Active);
        }
#endif


        //请求星蕴数据
        public void ReqStarData() {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqStarData.StartReqStarData(fbb);
            fbb.Finish(swm.ReqStarData.EndReqStarData(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqStarData.HashID, fbb);
        }

        //服务器返回星蕴数据
        private void ProcRspStarData(RspStarData msg)
        {
            //看看耗时。。
            LoadStarConfigData();
            //UnityEngine.Debug.LogError("starcout " + msg.star_listLength);
            for (int i = 0; i < msg.star_listLength; i++) {
                var star = msg.star_list(i);
                if (star.HasValue) {
                    var starid = star.Value.starid;
                    var isactive = star.Value.is_active;
                    var stardata = GetStarData((int)starid);
                    stardata.Unlock = true;
                    stardata.Active = isactive;
                    for (int j = 0; j < star.Value.star_position_listLength; j++) {
                        uint starpos = star.Value.star_position_list(j);
                        stardata.LightStar(starpos);
                    }
                }
            }

            m_cur_watching_times = msg.cur_watching_times;
            m_max_watching_times = msg.max_watching_times;
            m_active_star_count.Clear();
            for (int i = 0; i < msg.active_star_countLength; i++) {
                m_active_star_count.Add(msg.active_star_count(i));
            }
            m_star_reset_count = msg.star_reset_count;

            HasValue = true;

            if (OnStarLoaded != null) OnStarLoaded.Invoke();
        }

        //激活星蕴
        public void ReqAddStar(uint starid) {

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqAddStar.StartReqAddStar(fbb);
            swm.ReqAddStar.AddStarid(fbb, starid);
            fbb.Finish(swm.ReqAddStar.EndReqAddStar(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAddStar.HashID, fbb);
        }

        private void ProcNotifyAddStar(NotifyAddStar msg) {
            //UnityEngine.Debug.LogError("NotifyAddStar " + msg.starid + msg.starposition);
            var stardata = GetStarData((int)msg.starid);
            if (stardata != null) {
                stardata.Unlock = true;
                stardata.LightStar(msg.starposition);
                if (onStarDataChange != null) onStarDataChange.Invoke();
            }
        }

        //修炼星位
        public void ReqStarExercises(uint starposition) {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqStarExercises.StartReqStarExercises(fbb);
            swm.ReqStarExercises.AddStarposition(fbb, starposition);
            fbb.Finish(swm.ReqStarExercises.EndReqStarExercises(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqStarExercises.HashID, fbb);
        }

        //服务器返回修炼星位
        private void ProcRspStarExercises(RspStarExercises msg)
        {
            //UnityEngine.Debug.LogError("点亮星位 " + msg.result + " " + msg.starposition);
            if (msg.result) {
                var cfg = StarPositionTableManager.GetData((int)msg.starposition);
                if (cfg.HasValue) {
                    var starinfo = GetStarData(cfg.Value.starid);
                    starinfo.LightStar(msg.starposition);
                    if (onLightStarPos != null) onLightStarPos.Invoke((int)msg.starposition);
                }
                //成功
            }
        }

        //装备星蕴
        public void ReqLoadStar(uint starid){
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqLoadStar.StartReqLoadStar(fbb);
            swm.ReqLoadStar.AddStarid(fbb, starid);
            fbb.Finish(swm.ReqLoadStar.EndReqLoadStar(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqLoadStar.HashID, fbb);
        }

        //服务器返回装备星蕴
        private void ProcRspLoadStar(RspLoadStar msg)
        {
            //UnityEngine.Debug.LogError("ProcRspLoadStar");
            var stardata = GetStarData((int)msg.starid);
            if (stardata != null) {
                stardata.Active = true;
                if (onStarDataChange != null) onStarDataChange.Invoke();
            }
            //if (msg.result)
            {
                //装备星蕴成功
                //var starid = msg.starid;
            }
            //else
            {
                //装备星蕴失败
            }
        }

        //向服务器发送卸载星蕴
        public void ReqUnloadStar(uint starid) {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqUnloadStar.StartReqUnloadStar(fbb);
            swm.ReqUnloadStar.AddStarid(fbb, starid);
            fbb.Finish(swm.ReqUnloadStar.EndReqUnloadStar(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqUnloadStar.HashID, fbb);
        }

        //收到服务器卸载星蕴回复
        private void ProcRspUnloadStar(RspUnloadStar msg)
        {
            //UnityEngine.Debug.LogError("ProcRspUnloadStar");
            var stardata = GetStarData((int)msg.starid);
            if (stardata != null)
            {
                stardata.Active = false;
                if (onStarDataChange != null) onStarDataChange.Invoke();
            }
            //if (msg.result) {
            //var starid = msg.starid;
            //卸载星蕴成功
            //}
        }

        //请求观星
        public bool ReqStarWatching() {


            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqStarWatching.StartReqStarWatching(fbb);
            fbb.Finish(swm.ReqStarWatching.EndReqStarWatching(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqStarWatching.HashID, fbb);
            return true;
        }

        private void ProcRefreshStarWatching(RefreshStarWatching msg)
        {
            //UnityEngine.Debug.LogError("ProcRefreshStarWatching");
            m_cur_watching_times = msg.cur_watching_times;
            m_max_watching_times = msg.max_watching_times;
            if (onStarWatchChange != null) onStarWatchChange.Invoke();
        }

        //请求归元
        public void ReqStarReset(int starid) {
            //UnityEngine.Debug.LogError("ReqStarReset " + starid);
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqStarReset.StartReqStarReset(fbb);
            swm.ReqStarReset.AddStarid(fbb, (uint)starid);
            fbb.Finish(swm.ReqStarReset.EndReqStarReset(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqStarReset.HashID, fbb);
        }

        private void ProprspStarReset(RspStarReset msg)
        {
            //UnityEngine.Debug.LogError("ProprspStarReset");
            var stardata = GetStarData((int)msg.star.Value.starid);
            stardata.Reset();
            var isactive = msg.star.Value.is_active;
            stardata.Unlock = true;
            stardata.Active = isactive;
            for (int j = 0; j < msg.star.Value.star_position_listLength; j++)
            {
                uint starpos = msg.star.Value.star_position_list(j);
                stardata.LightStar(starpos);
            }

            m_star_reset_count = msg.star_reset_count;
           // UnityEngine.Debug.LogError("reset count " + m_star_reset_count);
            if(onStarPosDataChange != null) onStarPosDataChange.Invoke();

        }

        private void ProcRefreshStarReset(RefreshStarReset msg)
        {
            m_star_reset_count = msg.star_reset_count;
            //UnityEngine.Debug.LogError("reset count " + m_star_reset_count);
            if (onStarResetCountChange != null) onStarResetCountChange.Invoke();
            //if (onStarPosDataChange != null) onStarPosDataChange.Invoke();
        }

    }
}