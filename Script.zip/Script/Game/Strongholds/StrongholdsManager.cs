using System.Collections.Generic;
using FlatBuffers;
using swm;
using Bokura;
using x2m;

namespace Bokura
{
    /// <summary>
    /// 用于管理据点系统;
    /// </summary>
    public class StrongholdsManager : ClientSingleton<StrongholdsManager>
    {

        /// <summary>
        /// 注册通信消息;
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspForceActivityList>(RspStrongHoldActivityList_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspForceInfo>(RspStrongHoldPrestige_SC);
            MsgDispatcher.instance.RegisterFBMsgProc <swm.NotifyPrestigeChange>(NotifyPrestigeChange_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyOpenForceWorldTask>(NotifyOpenForceWorldTask_SC);
            
        }

        /// <summary>
        /// 加载配置数据;
        /// </summary>
        [XLua.BlackList]
        public void Load()
        {
            StrongholdTableManager.Load();
            MapStrongholdTableManager.Load();


            StrongholdTableBaseList list = StrongholdTableManager.Instance.m_DataList;
            for(int i=0, count = list.StrongholdTableLength; i<count; ++i)
            {
                StrongholdTableBase table = list.StrongholdTable(i).Value;

                StrongholdBase one = new StrongholdBase();
                one.id = table.id;
                one.name = table.name;//据点名称;
                one.position = "";// table.position;//据点立场;
                //one.location = table.location;//据点位置;
                one.describe = table.describe;//据点背景;
                one.icon = table.icon;//据点icon;
                one.background = table.background;//据点背景图;
                one.leader_name = table.leader_name; //首领称呼;
                one.command_name = table.command_name; //长老称谓;
                one.member_name = table.member_name; //帮众称谓;
                one.isHide = (table.is_hide == 1);
                m_strongholdIdList.Add(one.id);
                m_strongholdMap.Add(one.id, one);

                List<int> regionList = null;
                m_strongholdMapStrongholdIdMap.TryGetValue(one.region, out regionList);
                if (regionList == null)
                {
                    regionList = new List<int>(Const.kCap16);
                    m_strongholdMapStrongholdIdMap.Add(one.region, regionList);
                }

                regionList.Add(table.id);
            }


            
           
        }

        public void Clear()
        {

        }

        #region 网络消息部分;

        /// <summary>
        /// 请求玩家据点声望;
        /// </summary>
        public void ReqStrongHoldPrestige_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqForceInfo.StartReqForceInfo(tFBB);
            Offset<swm.ReqForceInfo> tOffset = swm.ReqForceInfo.EndReqForceInfo(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqForceInfo.HashID, tFBB);
        }
        private void RspStrongHoldPrestige_SC(RspForceInfo msg)
        {
            for (int tIdx = 0, tCount = msg.prestige_listLength; tIdx < tCount; tIdx++)
            {
                ForceData? tInfo = msg.prestige_list(tIdx);
                if (tInfo.HasValue)
                {
                    ForceData tInfoValue = tInfo.Value;

                    StrongholdBase sb = null;

                    if (m_strongholdMap.TryGetValue((int)tInfoValue.force_id, out sb))
                    {
                        sb.prestige = (int)tInfoValue.prestige;
                        sb.prestige_level = (int)tInfoValue.prestige_level;
                        sb.world_task_state =  tInfoValue.world_task_state;
                    }
                }
            }

            m_OnStrongHoldPrestigeArrived.Invoke();
        }

        private void NotifyPrestigeChange_SC(NotifyPrestigeChange msg)
        {
            StrongholdBase sb = null;

            if (!m_strongholdMap.TryGetValue((int)msg.force_id, out sb))
            {
                sb = new StrongholdBase();
                m_strongholdMap.Add((int)msg.force_id, sb);
            }
            sb.prestige = msg.prestige;
            sb.prestige_level = msg.prestige_level;

            onPrestigeLevelChanged?.Invoke(msg.force_id, msg.prestige, msg.prestige_level, msg.level_change);
        }

        private void NotifyOpenForceWorldTask_SC(swm.NotifyOpenForceWorldTask msg)
        {
            StrongholdBase sb = null;

            if (!m_strongholdMap.TryGetValue((int)msg.force_id, out sb))
            {
                sb = new StrongholdBase();
                m_strongholdMap.Add((int)msg.force_id, sb);
            }
            sb.prestige = msg.prestige;
            sb.prestige_level = msg.prestige_level;

            onOpenForceWorldTask?.Invoke(msg.force_id, msg.prestige, msg.prestige_level, msg.world_task_state);
        }


        private GameEvent m_OnStrongHoldActivityArrived = new GameEvent();
        private GameEvent m_OnStrongHoldPrestigeArrived = new GameEvent();
        private GameEvent<uint, int, int, int> m_OnPrestigeLevelChanged = new GameEvent<uint, int, int, int>();
        private GameEvent<uint, int, int, bool> m_onOpenForceWorldTask = new GameEvent<uint, int, int, bool>();
        public GameEvent onStrongHoldActivityArrived
        {
            get { return m_OnStrongHoldActivityArrived; }
        }

        public GameEvent onStrongHoldPrestigeArrived
        {
            get { return m_OnStrongHoldPrestigeArrived; }
        }

        public GameEvent<uint, int, int, int> onPrestigeLevelChanged
        {
            get { return m_OnPrestigeLevelChanged; }
        }

        public GameEvent<uint, int, int, bool> onOpenForceWorldTask
        {
            get { return m_onOpenForceWorldTask; }
        }

        /// <summary>
        /// 请求据点活动列表;
        /// </summary>
        public void ReqStrongHoldActivityList_CS()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqForceActivityList.StartReqForceActivityList(tFBB);
            Offset<swm.ReqForceActivityList> tOffset = swm.ReqForceActivityList.EndReqForceActivityList(tFBB);
            tFBB.Finish(tOffset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqForceActivityList.HashID, tFBB);
        }
        private void RspStrongHoldActivityList_SC(RspForceActivityList msg)
        {
            FullStrongholdDailyActivityList();

            for (int tIdx = 0, tCount = msg.act_listLength; tIdx < tCount; tIdx++)
            {
                ActivityElemInfo? tInfo = msg.act_list(tIdx);
                if (tInfo.HasValue)
                {
                    ActivityElemInfo tInfoValue = tInfo.Value;

                    int index = 0;

                    DailyActivity tActivity = GetDailyActivityByIdOut((int)tInfoValue.act_id, out index);

                    tActivity.curNum = (int)tInfoValue.cur_num;
                    tActivity.maxNum = (int)tInfoValue.max_num;
                    tActivity.state = (int)tInfoValue.act_state;

                    m_dailyActivityList[index] = tActivity;
                }
            }

            m_OnStrongHoldActivityArrived.Invoke();
        }

        #endregion 网络消息部分;

        //据点列表;
        private Dictionary<int, StrongholdBase> m_strongholdMap = new Dictionary<int, StrongholdBase>(Const.kCap16);//key-据点ID;
        private List<int> m_strongholdIdList = new List<int>(Const.kCap16);//据点ID列表;

        //据点成员信息;
        private List<StrongholdMemberBase> m_strongholdMemberList = new List<StrongholdMemberBase>(Const.kCap32);
        private Dictionary<int, List<StrongholdMemberBase>> m_strongholdMemberMap = new Dictionary<int, List<StrongholdMemberBase>>(Const.kCap16);//key-据点ID;

        //据点活动信息;
        private List<StrongholdDailyActivityBase> m_strongholdDailyActivityList = new List<StrongholdDailyActivityBase>(Const.kCap32);
        private Dictionary<int, List<StrongholdDailyActivityBase>> m_strongholdDailyActivityMap = new Dictionary<int, List<StrongholdDailyActivityBase>>(Const.kCap16);//key-据点ID;
        private List<DailyActivity> m_dailyActivityList = new List<DailyActivity>(Const.kCap32);

        //据点收集信息;
        private Dictionary<int, List<CollectionBase>> m_collectionMap = new Dictionary<int, List<CollectionBase>>(Const.kCap16);//key-区域ID;


        //据点地图信息;
        private Dictionary<int, List<int>> m_strongholdMapStrongholdIdMap = new Dictionary<int, List<int>>(Const.kCap16);//key-区域ID;


        #region 据点列表;

        /// <summary>
        /// 获取据点的信息;
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public StrongholdBase GetStrongholdDataById(int id)
        {
            StrongholdBase sb = null;

            m_strongholdMap.TryGetValue(id, out sb);

            return sb;
        }

        public int GetPrestigeTypeByStrongholdId(int strongholdId)
        {
            StrongholdBase sb = GetStrongholdDataById(strongholdId);
            if (sb != null)
            {
                return sb.prestige_level;
            }

            return -1;
        }

        /// <summary>
        /// 据点的数量;
        /// </summary>
        /// <returns></returns>
        public int StrongholdCount()
        {
            return m_strongholdIdList.Count;
        }

        /// <summary>
        /// 据点的ID;
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public int GetStrongholdIdByIndex(int index)
        {
            if (m_strongholdIdList.Count > index)
            {
                return m_strongholdIdList[index];
            }

            return 0;
        }

        #endregion 据点列表;

        #region 据点成员信息;

        public void FullStrongholdMemberList()
        {
            if (m_strongholdMemberList.Count == 0)
            {
                NpcTableBaseList list = NpcTableManager.Instance.m_DataList;
                for (int i = 0, count = list.NpcTableLength; i < count; ++i)
                {
                    NpcTableBase table = list.NpcTable(i).Value;

                    if (table.stronghold != 0)
                    {
                        StrongholdMemberBase one = new StrongholdMemberBase();
                        one.npcId = table.id;
                        one.strongholdId = table.stronghold;
                        one.identity = table.identity;

                        m_strongholdMemberList.Add(one);
                    }
                    
                }
            }
        }

        public List<StrongholdMemberBase> GetStrongholdMembersById(int id)
        {
            if (m_strongholdMemberMap.ContainsKey(id))
            {
                return m_strongholdMemberMap[id];
            }
            else
            {
                FullStrongholdMemberList();

                List<StrongholdMemberBase> oneList = new List<StrongholdMemberBase>(Const.kCap16);

                for (int i = 0, count = m_strongholdMemberList.Count; i < count; ++i)
                {

                    if (m_strongholdMemberList[i].strongholdId == id)
                    {
                        oneList.Add(m_strongholdMemberList[i]);
                    }
                }

                m_strongholdMemberMap[id] = oneList;

                return oneList;
            }
        }

        //public AvatarShow GetNpcShow(uint npcId)
        //{
        //    AvatarShow tShow = null;

        //    NpcAvatarData data = new NpcAvatarData();
        //    data.baseID = npcId;
        //    data.originPos = new UnityEngine.Vector3(0.0f, -1.6f, 5f);
        //    data.originRot = new UnityEngine.Vector3(0.0f, -180f, 0);
        //    tShow = AvatarShowManager.Instance.GetAvatarShow(data);
        //    data.Dispose();

        //    return tShow;
        //}



        ///// <summary>
        ///// 回收Show
        ///// </summary>
        //public void RecycleShow(AvatarShow show)
        //{
        //    AvatarShowManager.Instance.RecycleAvatarShow(show);
        //}

        #endregion 据点成员信息;

        #region 据点活动信息;
        
        public void FullStrongholdDailyActivityList()
        {
            if (m_strongholdDailyActivityList.Count == 0)
            {
                DailyActivityTableBaseList list = DailyActivityTableManager.Instance.m_DataList;
                for (int i = 0, count = list.DailyActivityTableLength; i < count; ++i)
                {
                    DailyActivityTableBase table = list.DailyActivityTable(i).Value;

                    if (table.type == 8|| table.type == 9|| table.type == 10) //据点活动 在任务表中类型id
                    {
                        StrongholdDailyActivityBase one = new StrongholdDailyActivityBase();
                        one.activityId = table.id;
                        one.strongholdId = table.stronghold;

                        m_strongholdDailyActivityList.Add(one);

                        DailyActivity tActivity = new DailyActivity(table);

                        m_dailyActivityList.Add(tActivity);
                    }

                }
            }
        }

        public List<StrongholdDailyActivityBase> GetStrongholdDailyActivityById(int id)
        {
            if (m_strongholdDailyActivityMap.ContainsKey(id))
            {
                return m_strongholdDailyActivityMap[id];
            }
            else
            {
                FullStrongholdDailyActivityList();

                List<StrongholdDailyActivityBase> oneList = new List<StrongholdDailyActivityBase>(Const.kCap16);

                for (int i = 0, count = m_strongholdDailyActivityList.Count; i < count; ++i)
                {

                    if (m_strongholdDailyActivityList[i].strongholdId == id)
                    {
                        oneList.Add(m_strongholdDailyActivityList[i]);
                    }
                }

                m_strongholdDailyActivityMap[id] = oneList;

                return oneList;
            }
        }

        public DailyActivity GetDailyActivityById(int id)
        {
            for(int i=0, count = m_dailyActivityList.Count; i<count; ++i)
            {
                if (m_dailyActivityList[i].id == id)
                {
                    return m_dailyActivityList[i];
                }
            }

            return default(DailyActivity);
        }

        public DailyActivity GetDailyActivityByIdOut(int id, out int index)
        {
            for (int i = 0, count = m_dailyActivityList.Count; i < count; ++i)
            {
                if (m_dailyActivityList[i].id == id)
                {
                    index = i;

                    return m_dailyActivityList[i];
                }
            }

            index = 0;

            return default(DailyActivity);
        }

        public AwardInfo GetActivityAwardInfoByIndex(int activityId, int awardIndex)
        {
            return DailyActivityManager.Instance.GetActivenessAwardInfoByIndex(activityId, awardIndex);
        }

        public string GetAwardIconPath(uint itemID)
        {
            return DailyActivityManager.Instance.GetAwardIconPath(itemID);
        }
        #endregion 据点活动信息;

        #region 据点收集信息;
        public List<CollectionBase> GetCollectionsByRegionId(int regionId)
        {
            List<CollectionBase> me = null;

            if (!m_collectionMap.TryGetValue(regionId, out me))
            {
                me = new List<CollectionBase>(Const.kCap16);
                m_collectionMap.Add(regionId, me);
            }

            return me;
        }
        #endregion 据点收集信息;



        /// <summary>
        /// 
        /// </summary>
        /// <param name="regionId">区域ID;</param>
        /// <returns></returns>
        public List<StrongholdDailyActivityBase> GetStrongholdMapDailyActivityById(int regionId)
        {
            List<int> regionList = null;
            if (m_strongholdMapStrongholdIdMap.TryGetValue(regionId, out regionList))
            {
                List<StrongholdDailyActivityBase> sb = new List<StrongholdDailyActivityBase>(Const.kCap16);

                for(int i=0, len = regionList.Count; i<len; ++i)
                {
                    List<StrongholdDailyActivityBase> temp = GetStrongholdDailyActivityById(regionList[i]);

                    sb.AddRange(temp);
                }

                return sb;
            }

            return null;
        }


        public class StrongholdBase
        {
            public int id;
            public int prestige;//据点声望;
            public int prestige_level;//据点声望等级;
            public int region;//所属区域;
            public string name;//据点名称;
            public string position;//据点立场;
            public string location;//据点位置;
            public string describe;//据点背景;
            public string icon;//据点icon;
            public string background ;//据点背景图;
            public string leader_name;//首领称呼;
            public string command_name;//长老称谓;
            public string member_name;//帮众称谓;
            public bool isHide;
            public bool world_task_state;
        }

        public class StrongholdMapBase
        {
            public int id;
            public int classfication;//所属州;
            public string name;//区域名称;
            public string image;//背景图;
        }

        public enum JobEnum
        {
            ASSISTANT = 1, //1 - 帮主;
            ELDERS = 2, //2 - 长老;
            MEMBER = 3, //3 - 帮众;
        }

        public class StrongholdMemberBase
        {
            public int npcId;//npc表ID;
            public int strongholdId;//据点ID;
            public int identity;//身份标识;
        }

        public class StrongholdDailyActivityBase
        {
            public int activityId;//每日活动表ID;
            public int strongholdId;//据点ID;
        }

        public class CollectionBase
        {
            public int id;
            public string name;
            public int region;//所属区域; 
        }

    }
}
