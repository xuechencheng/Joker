﻿using System.Collections;
using System.Collections.Generic;
using System;
using Bokura;
using UnityEngine.UI;

namespace Bokura
{
    public enum CameraSetting
    {
        CameraReset = 0,
        APUCIB = 1,                 //Auto Pull Up Camera In Battle
        APUCIBB = 2,                //Auto Pull Up Camera In Boss Battle
        USC = 3,                    //Ultimate Skill Camera
        RLLC = 4,                   //Right Left Locomotion Camera
        NCC = 5,                    //Navigation Camera Correction
        CLOT = 6,                   //Camera Lock On Target
        CAH = 7,                    //Camera Adjustment Vertical
        CAV = 8,                    //Camera Adjustment Horitonzal
        CZ = 9,                     //Camera Zoom
        QingKung = 10,               //轻功镜头
        AutoAdjust = 11             //Camera auto adjust when attack
    }

    public enum CameraMode
    {
        Mode3D = 1,
        Ordinary3D,
        Mode2_5D,
        ModeCustom,
    }

    public enum GraphMode
    {
        Energy = 1,
        Smooth = 2,
        Good = 3,
        Great = 4,
        Custom = 5
    }

    //----HEADER(2)
    //--------TotalLength(2)
    //----[DESC](?)
    //--------Length(2)
    //--------ID(2)
    //--------Data(?)
    public class SysSettingSharedData : SysSettingData
    {
        #region CAMERA_SETTINGS
        private Dictionary<int, bool> m_CameraSetInfo = new Dictionary<int, bool>(11);
        
        private CameraMode m_CameraMode = CameraMode.Ordinary3D;
        public CameraMode iCameraMode
        {
            get { return m_CameraMode; }
            set
            {
                m_CameraMode = value;
            }
        }
        
        public bool bCameraReset
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.CameraReset] : true; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.CameraReset] = value;
            }
        }
        public bool bCameraControlVertical
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.CAV] : (iCameraMode == CameraMode.Mode2_5D ? false : true); }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.CAV] = value;
            }
        }
        public bool bCameraControlHorizontal
        {
            get { return iCameraMode == CameraMode.ModeCustom ?   m_CameraSetInfo[(int)CameraSetting.CAH] : true; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.CAH] = value;
            }
        }
        public bool bCameraControlDistance
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.CZ] : true; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.CZ] = value;
            }
        }
        public bool bCameraGreatSkillSpecial
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.USC] : (iCameraMode == CameraMode.Mode3D) ? true : false; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.USC] = value;
            }
        }
        public bool bCameraAttackAuto
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.APUCIB] : (iCameraMode == CameraMode.Mode3D ? true : false); }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.APUCIB] = value;
            }
        }
        public bool bCameraAttackBossAuto
        {
            get { return iCameraMode == CameraMode.Mode3D ? true : (iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.APUCIBB] : false); }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.APUCIBB] = value;
            }
        }
        public bool bCameraMoveAdjust
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.RLLC] :false ; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.RLLC] = value;
            }
        }
        public bool bCameraFindPathAdjust
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.NCC] : (iCameraMode == CameraMode.Mode2_5D) ? false : true; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.NCC] = value;
            }
        }
        public bool bCameraTargetLock
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.CLOT] : (iCameraMode == CameraMode.Mode2_5D) ? false : true; ; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.CLOT] = value;
                //if (m_CameraSetInfo[(int)CameraSetting.CLOT])
                //{
                //    m_CameraSetInfo[(int)CameraSetting.CAV] = false;
                //    m_CameraSetInfo[(int)CameraSetting.CAH] = false;
                //}
            }
        }
        public bool bCameraQingKung
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.QingKung]:false; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.QingKung] = value;
            }
        }

        public bool bCameraAutoAdjust
        {
            get { return iCameraMode == CameraMode.ModeCustom ? m_CameraSetInfo[(int)CameraSetting.AutoAdjust] : false; }
            set
            {
                m_CameraSetInfo[(int)CameraSetting.AutoAdjust] = value;
            }
        }

        public void CameraConfigSet(int id, bool val)
        {
            m_CameraSetInfo[id] = val;
        }

        public bool CameraConfigGet(int id)
        {
            var set = (CameraSetting)id;
            switch (set)
            {
                case CameraSetting.CameraReset: return bCameraReset;
                case CameraSetting.APUCIB: return bCameraAttackAuto;
                case CameraSetting.APUCIBB: return bCameraAttackBossAuto;
                case CameraSetting.USC: return bCameraGreatSkillSpecial;
                case CameraSetting.RLLC: return bCameraMoveAdjust;
                case CameraSetting.NCC: return bCameraFindPathAdjust;
                case CameraSetting.CLOT: return bCameraTargetLock;
                case CameraSetting.CAH: return bCameraControlHorizontal;
                case CameraSetting.CAV: return bCameraControlVertical;
                case CameraSetting.CZ: return bCameraControlDistance;
                case CameraSetting.QingKung: return bCameraQingKung;
                case CameraSetting.AutoAdjust: return bCameraAutoAdjust;
            }

            //bool retMe;
            //if (!m_CameraSetInfo.TryGetValue(id, out retMe))
            //    retMe = false;

            return false;
        }
        #endregion

        #region PREFERENCE
        private bool m_RejectFriendApply = false;   
        /// <summary>
        /// 拒绝添加好友的申请
        /// </summary>
        public bool rejectFriendApply
        {
            get { return m_RejectFriendApply; }
            set { m_RejectFriendApply = value; }
        }



        private bool m_ShowOtherEffects = true;    
        /// <summary>
        /// 是否显示他人特效
        /// </summary>
        public bool showOtherEffects
        {
            get { return m_ShowOtherEffects; }
            set { m_ShowOtherEffects = value; }
        }



        private bool m_RejuectPK = false;     
        /// <summary>
        /// 决绝切磋申请
        /// </summary>
        public bool rejectPK
        {
            get { return m_RejuectPK; }
            set { m_RejuectPK = value; }
        }



        private bool m_bNpcVisitAutoPlayTalk = false;
        public bool bNpcVisitAutoPlayTalk
        {
            get { return m_bNpcVisitAutoPlayTalk; }
            set { m_bNpcVisitAutoPlayTalk = value; }
        }
        #endregion

        #region AutoRecovery
        private bool m_iAutoMedicine = true;
        public bool iAutoMedicine
        {
            get { return m_iAutoMedicine; }
            set { m_iAutoMedicine = value; }
        }
        private short m_AutoMedicineTriggerPercent = 50;
        public short AutoMedicineTriggerPercent
        {
            get { return m_AutoMedicineTriggerPercent; }
            set { m_AutoMedicineTriggerPercent = value; }
        }
        private int m_AutoMedicineItem1;
        public int AutoMedicineItem1
        {
            get { return m_AutoMedicineItem1; }
            set { m_AutoMedicineItem1 = value; }
        }
        private int m_AutoMedicineItem2;
        public int AutoMedicineItem2
        {
            get { return m_AutoMedicineItem2; }
            set { m_AutoMedicineItem2 = value; }
        }
        private int m_AutoMedicineItem3;
        public int AutoMedicineItem3
        {
            get { return m_AutoMedicineItem3; }
            set { m_AutoMedicineItem3 = value; }
        }
        private int m_AutoMedicineItem4;
        public int AutoMedicineItem4
        {
            get { return m_AutoMedicineItem4; }
            set { m_AutoMedicineItem4 = value; }
        }

        private bool m_iAutoFood = true;
        public bool iAutoFood
        {
            get { return m_iAutoFood; }
            set { m_iAutoFood = value; }
        }
        private short m_AutoFoodTriggerPercent = 50;
        public short AutoFoodTriggerPercent
        {
            get { return m_AutoFoodTriggerPercent; }
            set { m_AutoFoodTriggerPercent = value; }
        }
        private int m_AutoFoodItem1;
        public int AutoFoodItem1
        {
            get { return m_AutoFoodItem1; }
            set { m_AutoFoodItem1 = value; }
        }
        private int m_AutoFoodItem2;
        public int AutoFoodItem2
        {
            get { return m_AutoFoodItem2; }
            set { m_AutoFoodItem2 = value; }
        }
        private int m_AutoFoodItem3;
        public int AutoFoodItem3
        {
            get { return m_AutoFoodItem3; }
            set { m_AutoFoodItem3 = value; }
        }
        private int m_AutoFoodItem4;
        public int AutoFoodItem4
        {
            get { return m_AutoFoodItem4; }
            set { m_AutoFoodItem4 = value; }
        }
        #endregion

        #region MedicineKey
        private int m_MedicineKeyItem;
        public int MedicineKeyItem
        {
            get { return m_MedicineKeyItem; }
            set { m_MedicineKeyItem = value; }
        }
        #endregion

        #region Graph
        private GraphMode m_GraphMode = GraphMode.Great;
        public GraphMode GraphMode
        {
            get { return m_GraphMode; }
            set { m_GraphMode = value; }
        }

        private List<bool> m_PostProcess = new List<bool>(4);
        public bool AntiAlias
        {
            get { return m_PostProcess[0]; }
            set
            {
                m_PostProcess[0] = value;
                if (value)
                    ILevelSystemManager.Instance.SetAntiAliasing(1);
                else
                    ILevelSystemManager.Instance.SetAntiAliasing(0);
            }
        }
        public bool Halo
        {
            get { return m_PostProcess[1]; }
            set
            {
                m_PostProcess[1] = value;
                //ILevelSystemManager.Instance.SetEnableSunshaft(value);
                //ILevelSystemManager.Instance.SetEnableLensFlare(value);
            }
        }
        public bool HighFrequency
        {
            get { return m_PostProcess[2]; }
            set
            {
                m_PostProcess[2] = value;
                ILevelSystemManager.Instance.SetTargetFrameRate(value);
            }
        }
        public bool DepthOfField
        {
            get { return m_PostProcess[3]; }
            set
            {
                m_PostProcess[3] = value;
                //ILevelSystemManager.Instance.SetEnableDepthOfField(value);
            }
        }
        public bool Bloom
        {
            get { return m_PostProcess[4]; }
            set
            {
                m_PostProcess[4] = value;
                //ILevelSystemManager.Instance.SetEnableBloom(value);
            }
        }

        private int m_WideAngle = 55;
        public int WideAngle
        {
            get { return m_WideAngle; }
            set { m_WideAngle = value; }
        }

        private int m_VisionDistance = 500;
        public int VisionDis
        {
            get { return m_VisionDistance; }
            set { m_VisionDistance = value; }
        }

        private List<int> m_PrecisionList = new List<int>(0);
        public void SetPrecision(int id, int val)
        {
            m_PrecisionList[id] = val;

            if (id == 1)
            {
                if (val == 0)
                {
                    ILevelSystemManager.Instance.SetRenderScaleTypeNum((int)Bokura.SystemLevelInfo.LevelEnum.LOW);
                }
                else if (val == 1)
                {
                    ILevelSystemManager.Instance.SetRenderScaleTypeNum((int)Bokura.SystemLevelInfo.LevelEnum.MIDDLE);
                }
                else if (val == 2)
                {
                    ILevelSystemManager.Instance.SetRenderScaleTypeNum((int)Bokura.SystemLevelInfo.LevelEnum.HIGH);
                }
            }
        }
        public int GetPrecision(int id) { return m_PrecisionList[id]; }

        public void SetPostProcess(int id, bool val)
        {
            m_PostProcess[id] = val;
        }
        public bool GetPostProcess(int id)
        {
            return m_PostProcess[id];
        }
        #endregion

        [XLua.BlackList]
        public SysSettingSharedData()
        {
            // DO NOT REPEAT ID!
            // DO NOT REPEAT ID!
            // DO NOT REPEAT ID!
            RegisterByte(1, (v) => { m_CameraMode = (CameraMode)v; }, () => (byte)m_CameraMode);

            RegisterBool(2, (v) => { rejectFriendApply = v; }, () => rejectFriendApply);
            RegisterBool(3, (v) => { rejectPK = v; }, () => rejectPK);
            RegisterBool(4, (v) => { iAutoMedicine = v; }, () => iAutoMedicine);
            
            int len = SysSettingModel.Instance.GetConfigNum(2, 0);
            for (int i = 0; i < len; i++)
                m_CameraSetInfo.Add(i, true);
            int precisionLen = SysSettingModel.Instance.GetConfigNum(3, 2);
            for (int i = 0; i < precisionLen; i++)
                m_PrecisionList.Add(1);
            int postlen = SysSettingModel.Instance.GetConfigNum(3, 1);
            for (int i = 0; i < postlen; i++)
            {
                if (i == 0)
                {
                    bool addMe = (int)ILevelSystemManager.Instance.GetAntiAliasing() != 0;
                    m_PostProcess.Add(addMe);
                }
                else
                    m_PostProcess.Add(true);
            }

            RegisterBool(5, (v) => { m_CameraSetInfo[0] = v; }, () => m_CameraSetInfo[0]);
            RegisterBool(6, (v) => { m_CameraSetInfo[1] = v; }, () => m_CameraSetInfo[1]);
            RegisterBool(7, (v) => { m_CameraSetInfo[2] = v; }, () => m_CameraSetInfo[2]);
            RegisterBool(8, (v) => { m_CameraSetInfo[3] = v; }, () => m_CameraSetInfo[3]);
            RegisterBool(9, (v) => { m_CameraSetInfo[4] = false; }, () => m_CameraSetInfo[4]);
            RegisterBool(10, (v) => { m_CameraSetInfo[5] = v; }, () => m_CameraSetInfo[5]);
            RegisterBool(11, (v) => { m_CameraSetInfo[6] = v; }, () => m_CameraSetInfo[6]);
            RegisterBool(12, (v) => { m_CameraSetInfo[7] = v; }, () => m_CameraSetInfo[7]);
            RegisterBool(13, (v) => { m_CameraSetInfo[8] = v; }, () => m_CameraSetInfo[8]);
            RegisterBool(14, (v) => { m_CameraSetInfo[9] = v; }, () => m_CameraSetInfo[9]);
            RegisterBool(15, (v) => { m_CameraSetInfo[10] = false; }, () => m_CameraSetInfo[10]); //临时取消这个开关
            RegisterBool(16, (v) => { m_CameraSetInfo[11] = v; }, () => m_CameraSetInfo[11]);

            RegisterInt16(17, (v) => { AutoMedicineTriggerPercent = v; }, () => AutoMedicineTriggerPercent);
            RegisterInt32(18, (v) => { AutoMedicineItem1 = v; }, () => AutoMedicineItem1);
            RegisterInt32(19, (v) => { AutoMedicineItem2 = v; }, () => AutoMedicineItem2);
            RegisterInt32(20, (v) => { AutoMedicineItem3 = v; }, () => AutoMedicineItem3);
            RegisterInt32(21, (v) => { AutoMedicineItem4 = v; }, () => AutoMedicineItem4);
            RegisterBool(22, (v) => { iAutoFood = v; }, () => iAutoFood);
            RegisterInt16(23, (v) => { AutoFoodTriggerPercent = v; }, () => AutoFoodTriggerPercent);
            RegisterInt32(24, (v) => { AutoFoodItem1 = v; }, () => AutoFoodItem1);
            RegisterInt32(25, (v) => { AutoFoodItem2 = v; }, () => AutoFoodItem2);
            RegisterInt32(26, (v) => { AutoFoodItem3 = v; }, () => AutoFoodItem3);
            RegisterInt32(27, (v) => { AutoFoodItem4 = v; }, () => AutoFoodItem4);
            RegisterInt32(28, (v) => { MedicineKeyItem = v; }, () => MedicineKeyItem);

            RegisterInt32(29, (v) => { m_WideAngle = v; }, () => m_WideAngle);
            RegisterInt32(30, (v) => { m_VisionDistance = v; }, () => m_VisionDistance);

            RegisterInt32(31, (v) => { m_PrecisionList[0] = v; }, () => m_PrecisionList[0]);
            RegisterInt32(32, (v) => { m_PrecisionList[1] = v; }, () => m_PrecisionList[1]);
            RegisterInt32(33, (v) => { m_PrecisionList[2] = v; }, () => m_PrecisionList[2]);
            RegisterInt32(34, (v) => { m_PrecisionList[3] = v; }, () => m_PrecisionList[3]);
            RegisterInt32(35, (v) => { m_PrecisionList[4] = v; }, () => m_PrecisionList[4]);
            RegisterInt32(36, (v) => { m_PrecisionList[5] = v; }, () => m_PrecisionList[5]);
            
            RegisterBool(37, (v) => { AntiAlias = v; }, () => AntiAlias);
            RegisterBool(38, (v) => { Halo = v; }, () => Halo);
            RegisterBool(39, (v) => { HighFrequency = v; }, () => HighFrequency);
            RegisterBool(40, (v) => { DepthOfField = v; }, () => DepthOfField);
            RegisterBool(41, (v) => { Bloom = v; }, () => Bloom);

            RegisterInt32(42, (v) => { CameraController.Instance.CameraSensitivity = v; }, () => CameraController.Instance.CameraSensitivity);

            RegisterBool(43, (v) => { bNpcVisitAutoPlayTalk = v; }, () => bNpcVisitAutoPlayTalk);
        }

        public override void InitData()
        {
            //ICameraController.Instance.Config = new ICameraController.CameraConfig();

            iAutoMedicine = true;
            AutoMedicineTriggerPercent = 50;
            AutoMedicineItem1 = 0;
            AutoMedicineItem2 = 0;
            AutoMedicineItem3 = 0;
            AutoMedicineItem4 = 0;
            iAutoFood = true;
            AutoFoodTriggerPercent = 50;
            AutoFoodItem1 = 0;
            AutoFoodItem2 = 0;
            AutoFoodItem3 = 0;
            AutoFoodItem4 = 0;
            MedicineKeyItem = 0;
        }
    }

    public class SysSettingLocalData : SysSettingData
    {
        // 0: Custom
        // 1 ~ 4 : low -> high
        private byte m_iGraphicLevel = 4;
        public byte iGraphicLevel
        {
            get { return m_iGraphicLevel; }
            set { m_iGraphicLevel = value; }
        }

        #region Music
        /// <summary>
        /// 音乐的音量
        /// </summary>
        private byte m_iBGM = 100;
        public byte iBGM
        {
            get { return m_iBGM; }
            set
            {
                if(SetPropertyUtility.SetStruct(ref m_iBGM, value))
                    AudioCtrl.SetMusicVolume(value / 100f);
            }
        }



        /// <summary>
        /// 是否启用音乐
        /// </summary>
        private bool m_bIsOn_BGM = true;
        public bool IsBGMOn
        {
            get { return m_bIsOn_BGM; }
            set
            {
                if(SetPropertyUtility.SetStruct(ref m_bIsOn_BGM, value))
                    AudioCtrl.MusicCtrl(m_bIsOn_BGM);
            }
        }



        /// <summary>
        /// 音效音量
        /// </summary>
        private byte m_iSoundEffect = 100;
        public byte iSoundEffect
        {
            get { return m_iSoundEffect; }
            set
            {
                if(SetPropertyUtility.SetStruct(ref m_iSoundEffect, value))
                    AudioCtrl.SetSoundVolume(value / 100f);
            }
        }



        /// <summary>
        /// 是否启用音效
        /// </summary>
        private bool m_bIsOn_SoundEffect = true;
        public bool IsSoundEffectOn
        {
            get { return m_bIsOn_SoundEffect; }
            set
            {
                if(SetPropertyUtility.SetStruct(ref m_bIsOn_SoundEffect, value))
                    AudioCtrl.SoundCtrl(m_bIsOn_SoundEffect);
            }
        }



        /// <summary>
        /// 语音音量
        /// </summary>
        private byte m_iVoice = 100;
        public byte iVoice
        {
            get { return m_iVoice; }
            set
            {
                if(SetPropertyUtility.SetStruct(ref m_iVoice, value))
                    AudioCtrl.SetVoiceVolume(value / 100f);
            }
        }



        /// <summary>
        /// 是否启用语音
        /// </summary>
        private bool m_bIsOn_Voice = true;
        public bool IsVoiceOn
        {
            get { return m_bIsOn_Voice; }
            set
            {
                if(SetPropertyUtility.SetStruct(ref m_bIsOn_Voice, value))
                    AudioCtrl.VoiceCtrl(m_bIsOn_Voice);
            }
        }
        #endregion



        #region Same-Screen
        private int m_PersonNumInScreen = 50;
        /// <summary>
        /// 同屏人数
        /// </summary>
        public int PersonNumInScreen
        {
            get { return m_PersonNumInScreen; }
            set { m_PersonNumInScreen = value; }
        }



        private int m_PersonNameNumInScreen = 50;
        /// <summary>
        /// 同屏名字数
        /// </summary>
        public int PersonNameNumInScreen
        {
            get { return m_PersonNameNumInScreen; }
            set { m_PersonNameNumInScreen = value; }
        }



        private int m_EffectInScreen = 80;
        /// <summary>
        /// 同屏特效数
        /// </summary>
        public int EffectInScreen
        {
            get { return m_EffectInScreen; }
            set { m_EffectInScreen = value; }
        }
        #endregion



        private GameEvent<bool> m_OnValueChange;
        private GameEvent<bool> OnValueChange
        {
            get { return m_OnValueChange; }
        }

        [XLua.BlackList]
        public SysSettingLocalData()
        {
            // DO NOT REPEAT ID!
            // DO NOT REPEAT ID!
            // DO NOT REPEAT ID!
            RegisterByte(1, (v) => { m_iGraphicLevel = v; }, () => m_iGraphicLevel);
            RegisterByte(2, (v) => {
                m_iBGM = v;
                AudioCtrl.SetMusicVolume(m_iBGM / 100f);
            }, () => m_iBGM);
            RegisterByte(3, (v) => {
                m_iSoundEffect = v;
                AudioCtrl.SetSoundVolume(m_iSoundEffect / 100f);
            }, () => m_iSoundEffect);
            RegisterByte(4, (v) => {
                m_iVoice = v;
                AudioCtrl.SetVoiceVolume(m_iVoice / 100f);
            }, () => m_iVoice);

            RegisterBool(5, (v) => { IsBGMOn = v; }, () => IsBGMOn);
            RegisterBool(6, (v) => { IsSoundEffectOn = v; }, () => IsSoundEffectOn);
            RegisterBool(7, (v) => { IsVoiceOn = v; }, () => IsVoiceOn);

            RegisterInt32(8, (v) => { PersonNumInScreen = v; }, () => PersonNumInScreen);
            RegisterInt32(9, (v) => { PersonNameNumInScreen = v; }, () => PersonNameNumInScreen);
            RegisterInt32(10, (v) => { EffectInScreen = v; }, () => EffectInScreen);
        }

        public override void InitData()
        {
            m_OnValueChange = new GameEvent<bool>();

            m_iGraphicLevel = 4;
            iBGM = 100;
            iSoundEffect = 100;
            iVoice = 100;
        }
    }

    public class SysSettingData
    {
        public delegate void ParseFunc(ArraySegment<byte> data, uint offset);
        public delegate void SaveFunc(SysSettingSerializer s);
        public Dictionary<ushort, ParseFunc> parse_funcs;
        public Dictionary<ushort, SaveFunc> save_funcs;

        private SysSettingSerializer m_serializer = new SysSettingSerializer();
        
        public SysSettingData()
        {
            parse_funcs = new Dictionary<ushort, ParseFunc>(32);
            save_funcs = new Dictionary<ushort, SaveFunc>(32);
        }

        public virtual void InitData()
        {

        }

        public void LoadFromBytes(ArraySegment<byte> _bytedata, bool _clearIfInvalid)
        {
            try
            {
                if (SysSettingUtility.IsDataValid(_bytedata))
                {
                    SysSettingByteHeader header = new SysSettingByteHeader();
                    if (header.ExtractFrom(_bytedata, 0))
                    {
                        SysSettingByteItem item = new SysSettingByteItem();
                        var curOffset = SysSettingUtility.HEADER_LENGTH;
                        while (true)
                        {
                            if (item.ExtractFrom(_bytedata, (uint)curOffset))
                            {
                                ParseFunc parsefunc;
                                if (parse_funcs.TryGetValue(item.id, out parsefunc))
                                {
                                    parsefunc.Invoke(_bytedata, (uint)(curOffset + SysSettingUtility.SETTING_ITEM_HEADER_LENGTH));
                                }
                                curOffset += item.length + SysSettingUtility.SETTING_ITEM_HEADER_LENGTH;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
                else if (_clearIfInvalid)
                {

                }

            }
            catch(Exception e)
            {
                LogHelper.LogError("Error when loading system setting: " , e.ToString());
            }
        }

        public void SaveToBytes(ref byte[] _bytedata)
        {
            try
            {
                var s = m_serializer;
                s.BeginSerialize();
                foreach (var kv in save_funcs)
                {
                    kv.Value?.Invoke(s);
                }
                if (s.EndSerialize())
                {
                    _bytedata = s.array.ToArray();
                }
                else
                {
                    _bytedata = null;
                    LogHelper.LogError("Save System Setting Data Failed: bytes overflow! -" , s.array.Count.ToString());
                }
            }
            catch(Exception e)
            {
                _bytedata = null;
                LogHelper.LogError("Error when saving system setting: " , e.ToString());
            }
        }

        public void RegisterBool(ushort id, Action<bool> onDeserialize, Func<bool> onSerialize)
        {
            parse_funcs.Add(id, (d, o) => { onDeserialize?.Invoke(SysSettingUtility.GetBool(d, o)); });
            save_funcs.Add(id, (s) => { s.AddBoolValue(id, onSerialize?.Invoke() ?? false); });
        }
        public void RegisterByte(ushort id, Action<byte> onDeserialize, Func<byte> onSerialize)
        {
            parse_funcs.Add(id, (d, o) => { onDeserialize?.Invoke(SysSettingUtility.GetByte(d, o)); });
            save_funcs.Add(id, (s) => { s.AddByteValue(id, onSerialize?.Invoke() ?? 0); });
        }
        public void RegisterInt16(ushort id, Action<short> onDeserialize, Func<short> onSerialize)
        {
            parse_funcs.Add(id, (d, o) => { onDeserialize?.Invoke(SysSettingUtility.GetShort(d, o)); });
            save_funcs.Add(id, (s) => { s.AddInt16Value(id, (ushort)(onSerialize?.Invoke() ?? 0)); });
        }
        public void RegisterInt32(ushort id, Action<int> onDeserialize, Func<int> onSerialize)
        {
            parse_funcs.Add(id, (d, o) => { onDeserialize?.Invoke(SysSettingUtility.GetInt(d, o)); });
            save_funcs.Add(id, (s) => { s.AddInt32Value(id, (uint)(onSerialize?.Invoke() ?? 0)); });
        }
        public void RegisterInt64(ushort id, Action<long> onDeserialize, Func<long> onSerialize)
        {
            parse_funcs.Add(id, (d, o) => { onDeserialize?.Invoke(SysSettingUtility.GetLong(d, o)); });
            save_funcs.Add(id, (s) => { s.AddInt64Value(id, (ulong)(onSerialize?.Invoke() ?? 0)); });
        }
    }
    
    struct SysSettingByteHeader
    {
        public ushort allLength;

        public bool ExtractFrom(ArraySegment<byte> _bytedata, uint _offset)
        {
            if (_bytedata.Count < _offset + SysSettingUtility.HEADER_LENGTH)
            {
                return false;
            }
            allLength = SysSettingUtility.GetUShort(_bytedata, _offset);
            return true;
        }
    }

    struct SysSettingByteItem
    {
        public ushort id;
        public ushort length;

        public bool ExtractFrom(ArraySegment<byte> _bytedata, uint _offset)
        {
            if (_bytedata.Count < _offset + SysSettingUtility.SETTING_ITEM_HEADER_LENGTH)
            {
                return false;
            }
            length = SysSettingUtility.GetUShort(_bytedata, _offset);
            id = SysSettingUtility.GetUShort(_bytedata, _offset + 2);
            return true;
        }
    }



    public class SysSettingSerializer
    {
        public List<byte> array = new List<byte>(1024);

        public void BeginSerialize()
        {
            array.Clear();
            array.Add(0);
            array.Add(0);
        }

        public bool EndSerialize()
        {
            var count = (uint)array.Count;
            var upper16 = (ushort)(count >> 16);
            if(upper16 != 0)
            {
                return false;
            }
            var lower16 = (ushort)count;
            var upper8 = (byte)(lower16 >> 8);
            var lower8 = (byte)(lower16 & 0x00ff);
            if (BitConverter.IsLittleEndian)
            {
                array[1] = upper8;
                array[0] = lower8;
            }
            else
            {
                array[0] = upper8;
                array[1] = lower8;
            }
            return true;
        }
        void WriteItemHeader(ushort _id, ushort _length)
        {
            WriteByte2(_length);
            WriteByte2(_id);
        }

        public void AddBoolValue(ushort _id, bool _value)
        {
            WriteItemHeader(_id, 1);
            WriteByte(Convert.ToByte(_value));
        }
        public void AddByteValue(ushort _id, byte _value)
        {
            WriteItemHeader(_id, 1);
            WriteByte(_value);
        }
        public void AddInt16Value(ushort _id, ushort _value)
        {
            WriteItemHeader(_id, 2);
            WriteByte2(_value);
        }
        public void AddInt32Value(ushort _id, uint _value)
        {
            WriteItemHeader(_id, 4);
            WriteByte4(_value);
        }
        public void AddInt64Value(ushort _id, ulong _value)
        {
            WriteItemHeader(_id, 8);
            WriteByte8(_value);
        }


        void WriteByte(byte v)
        {
            array.Add(v);
        }
        void WriteByte2(ushort v)
        {
            if (BitConverter.IsLittleEndian)
            {
                WriteByte((byte)(v & 0x00ff));
                WriteByte((byte)(v >> 8));
            }
            else
            {
                WriteByte((byte)(v >> 8));
                WriteByte((byte)(v & 0x00ff));
            }
        }
        void WriteByte4(uint v)
        {
            if (BitConverter.IsLittleEndian)
            {
                WriteByte2((ushort)(v & 0x0000ffff));
                WriteByte2((ushort)(v >> 16));
            }
            else
            {
                WriteByte2((ushort)(v >> 16));
                WriteByte2((ushort)(v & 0x0000ffff));
            }
        }
        void WriteByte8(ulong v)
        {
            if (BitConverter.IsLittleEndian)
            {
                WriteByte4((uint)((v << 32) >> 32));
                WriteByte4((uint)(v >> 32));
            }
            else
            {
                WriteByte4((uint)(v >> 32));
                WriteByte4((uint)((v << 32) >> 32));
            }
        }
    }
}