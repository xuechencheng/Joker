using System.Collections.Generic;
using Bokura;
using LitJson;
using System;

namespace Bokura
{
    public class SettingElement
    {
        public int contentId;
        public string contentName;
        public int contentType;
    }

    public class SettingJsonConfig
    {
        public string Desc;
        public List<SettingElement> elements = new List<SettingElement>();
    }

    public class SysSettingModel : ClientSingleton<SysSettingModel>
    {
        public SysSettingSharedData sharedData;
        public SysSettingLocalData localData;

        private List<SettingJsonConfig> SettingConfig1;
        private List<SettingJsonConfig> SettingConfig2;
        private List<SettingJsonConfig> SettingConfig3;

        private void AddConfigToList(List<SettingJsonConfig> list, JsonData data)
        {
            if (!data.IsArray) return;

            foreach (JsonData item in data)
            {
                if (!item.IsObject) continue;

                SettingJsonConfig config = new SettingJsonConfig();
                var keys = item.Keys;
                if (keys.Contains("Desc"))
                    config.Desc = (string)item["Desc"];
                if (keys.Contains("Elements"))
                {
                    var elements = item["Elements"];
                    foreach(JsonData element in elements)
                    {
                        if (!element.IsObject) continue;

                        SettingElement subConfig = new SettingElement();
                        var subKeys = element.Keys;
                        if (subKeys.Contains("contentID"))
                            subConfig.contentId = (int)element["contentID"];
                        if (subKeys.Contains("contentName"))
                            subConfig.contentName = (string)element["contentName"];
                        if (subKeys.Contains("contentType"))
                            subConfig.contentType = (int)element["contentType"];
                        config.elements.Add(subConfig);
                    }
                }

                list.Add(config);
            }
        }
        private void InitConfig()
        {
            string strData = TableManager.LoadFileTable("SysSetting_Map.json", "/Datas/");
            if (string.IsNullOrEmpty(strData)) return;

            JsonData jsonData;
            try
            {
                jsonData = JsonMapper.ToObject(strData);
                if (jsonData == null || !jsonData.IsObject) return;

                if (jsonData.Keys.Contains("pageOne"))
                {
                    var array = jsonData["pageOne"];
                    AddConfigToList(SettingConfig1, array);
                }

                if (jsonData.Keys.Contains("pageTwo"))
                {
                    var array = jsonData["pageTwo"];
                    AddConfigToList(SettingConfig2, array);
                }

                if (jsonData.Keys.Contains("pageThree"))
                {
                    var array = jsonData["pageThree"];
                    AddConfigToList(SettingConfig3, array);
                }
            }
            catch (Exception e)
            {
                LogHelper.LogError("Error occurred when parsing json table SysSetting_Map.json : " + e.ToString());
                return;
            }
        }
        public string GetConfigString(int pageID, int areaid, int id)
        {
            string retMe = "Error";
            switch (pageID)
            {
                case 1:
                    retMe = SettingConfig1[areaid].elements[id].contentName;
                    break;
                case 2:
                    retMe = SettingConfig2[areaid].elements[id].contentName;
                    break;
                case 3:
                    retMe = SettingConfig3[areaid].elements[id].contentName;
                    break;
            }

            return retMe;
        }
        public int GetConfigType(int pageID, int areaid, int id)
        {
            int retMe = 0;

            switch (pageID)
            {
                case 1:
                    retMe = SettingConfig1[areaid].elements[id].contentType;
                    break;
                case 2:
                    retMe = SettingConfig2[areaid].elements[id].contentType;
                    break;
                case 3:
                    retMe = SettingConfig3[areaid].elements[id].contentType;
                    break;
            }

            return retMe;
        }
        public int GetConfigNum(int pageID, int areaid)
        {
            if(pageID == 1)
                return SettingConfig1[areaid].elements.Count;
            else if(pageID == 2)
                return SettingConfig2[areaid].elements.Count;
            else if(pageID == 3)
                return SettingConfig3[areaid].elements.Count;

            return 0;
        }
        public int GetAreaNum(int pageID)
        {
            if (pageID == 1)
                return SettingConfig1.Count;
            else if (pageID == 2)
                return SettingConfig2.Count;
            else if (pageID == 3)
                return SettingConfig3.Count;

            return 0;
        }

        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            // MsgDispacther.instance.RegisterFBMsgProc<swm.SyncUserClientData>(ProcessSyncUserClientData);
            ClientSyncDataMgr.Instance.OnRecvServerData.AddListener(ProcessSyncUserClientData);

        }

        public void Load()
        {
            SettingConfig1 = new List<SettingJsonConfig>(8);
            SettingConfig2 = new List<SettingJsonConfig>(8);
            SettingConfig3 = new List<SettingJsonConfig>(8);
            InitConfig();

            sharedData = new SysSettingSharedData();
            localData = new SysSettingLocalData();
            GameScene.Instance.onDisconnect.AddListener(() =>
            {
                sharedData.InitData();
                localData.InitData();
            });
        }

        public void Clear()
        {
            sharedData?.InitData();
            localData?.InitData();
        }

        private void ProcessSyncUserClientData( ClientSyncDataType t, byte[] data)
        {
            if (t != ClientSyncDataType.SettingData)
                return;
            //LogHelper.Log("receive SyncUserClientData from server - data length :" , data.dataLength.ToString());
           // var bytedata = data.GetDataBytes();
            //if (bytedata.HasValue)
            //{
            sharedData.LoadFromBytes(new System.ArraySegment<byte>(data), false);
            //}

            sharedData.SetPrecision(1, sharedData.GetPrecision(1));
        }

        public void SendSyncUserClientData(byte[] data)
        {
            ClientSyncDataMgr.Instance.SetData(ClientSyncDataType.SettingData, data);
            ClientSyncDataMgr.Instance.SaveData();
            //var fbb = MsgDispacther.instance.GetFlatBufferBuilder();
            //var datav = swm.SyncUserClientData.CreateDataVector(fbb, data);
            //swm.SyncUserClientData.StartSyncUserClientData(fbb);
            //swm.SyncUserClientData.AddData(fbb, datav);
            //var msg = swm.SyncUserClientData.EndSyncUserClientData(fbb);
            //fbb.Finish(msg.Value);
            //MsgDispacther.instance.SendFBPackage(swm.SyncUserClientData.HashID, fbb);
        }

        byte[] tempBytes;

        public void LoadLocalSysSetting()
        {
            var bytedata = GameApplication.ReadBytes(Utilities.BuildString(GameScene.Instance.MainChar.ThisIDToString, "/config.dat"));
            if(bytedata != null)
            {
                //LogHelper.Log("local sys setting loaded.");
                localData.LoadFromBytes(new System.ArraySegment<byte>(bytedata), false);
            }
        }

        public void SaveLocalSysSetting()
        {
            localData?.SaveToBytes(ref tempBytes);
            if(tempBytes != null && GameScene.Instance.MainChar != null)
            {
                //LogHelper.Log("local sys setting saved.");
                GameApplication.WriteBytes(Utilities.BuildString(GameScene.Instance.MainChar.ThisIDToString, "/config.dat"), tempBytes);
            }
        }

        public void SaveSharedSetting()
        {
            sharedData.SaveToBytes(ref tempBytes);
            if(tempBytes != null)
                SendSyncUserClientData(tempBytes);
        }

        public void BackToLogin()
            {
            SaveLocalSysSetting();
            SaveSharedSetting();
            UIManager.Instance.CloseAll(new List<string>(3) { "ui_login", "ui_accountlogin", "ui_panel_systeminfo" });
            NetworkConnection.Instance.Disconnect();
        }
    }
}