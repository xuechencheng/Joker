﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{

    public static class SysSettingUtility
    {
        public static readonly int HEADER_LENGTH = 2;
        public static readonly int SETTING_ITEM_HEADER_LENGTH = 4;


        public static bool IsDataValid(ArraySegment<byte> _bytedata)
        {
            if (_bytedata.Count < HEADER_LENGTH)
            {
                return false;
            }
            if (GetUShort(_bytedata, 0) != _bytedata.Count)
            {
                return false;
            }
            return true;
        }

        public static bool GetBool(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToBoolean(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
        public static byte GetByte(ArraySegment<byte> _bytedata, uint _offset)
        {
            return _bytedata.Array[_bytedata.Offset + (int)_offset];
        }
        public static short GetShort(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToInt16(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
        public static ushort GetUShort(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToUInt16(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
        public static int GetInt(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToInt32(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
        public static uint GetUInt(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToUInt32(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
        public static long GetLong(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToInt64(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
        public static ulong GetULong(ArraySegment<byte> _bytedata, uint _offset)
        {
            return System.BitConverter.ToUInt64(_bytedata.Array, _bytedata.Offset + (int)_offset);
        }
    }

}