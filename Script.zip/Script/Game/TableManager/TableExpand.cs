using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public static class TableExtra
    {
        public static NpcModelActionBindTableBase? GetData(this NpcModelActionBindTableManager mgr, int _npcid, int _actionid)
        {
            int length = mgr.m_DataList.NpcModelActionBindTableLength;
            for (int i = 0; i < length; ++i)
            {
                var data = mgr.m_DataList.NpcModelActionBindTable(i);
                if (!data.HasValue)
                    continue;

                int actionhashid = Animator.StringToHash(data.Value.actionname);
                if (data.Value.npcid == _npcid && actionhashid == _actionid)
                {
                    return data;
                }
            }

            return null;
        }

        public static Vector3 GetVector(string str, char split = ';')
        {
            Vector3 tempvec = Vector3.zero;
            if (string.IsNullOrEmpty(str))
                return tempvec;

            string[] strs = str.Split(split);
            if (strs.Length >= 3)
            {
                tempvec.x = float.Parse(strs[0]);
                tempvec.y = float.Parse(strs[1]);
                tempvec.z = float.Parse(strs[2]);
            }

            return tempvec;
        }

        public static List<uint> GetListUint(string str, char split = ';')
        {
            List<uint> templist = new List<uint>();
            if (string.IsNullOrEmpty(str))
                return templist;

            string[] strs = str.Split(split);
            foreach(var i in strs)
            {
                templist.Add((uint)double.Parse(i));
            }

            return templist;
        }
    }
}
