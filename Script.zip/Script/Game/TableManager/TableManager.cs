using UnityEngine;
using System;
using Bokura;
using System.Runtime.CompilerServices;

namespace Bokura
{
    public class TableManager : ClientSingleton<TableManager>
    {
        public void LoadTable()
        {
#if REMOTE_DEBUG
            var memused = System.GC.GetTotalMemory(true);
            //var time = DateTime.Now.ToBinary();
#endif


            GameCfgTableManager.Load();


            SysSettingModel.Instance.Load();

            SkillTableManager.Load();

            SkillBuffTableManager.Load();

			RootSkillTableManager.Load();

            RoleTableManager.Load();

            ProfessionTableManager.Load();

            CharLevelupTableManager.Load();
            TrapManager.Load();

            NpcTableManager.Load();

            WeaponTableManager.Load();

			ItemTableManager.Load();

            TitleTableManager.Load();

            Ts_InfoManager.Load();


			ChantTableManager.Load();

			CopyInfoTableManager.Load();


			MailTableManager.Load();

			Ts_ShowInfoManager.Load();
			Ts_SpecialShowInfoManager.Load();

			BagTableManager.Load();

			TeamTargetTableManager.Load();

			EquipTableManager.Load();

			EquipQualityTableManager.Load();

			EquipSuitTableManager.Load();

            EquipStrenTableManager.Load();

            GemTableManager.Load();

			PropTableManager.Load();

            ManorObjectTableManager.Load();

            ManorInfoTableManager.Load();

            WorldTransTableManager.Load();

			GoldWeaponTableManager.Load();

			MountTableManager.Load();

			MountSkinTableManager.Load();

            FashionTableManager.Load();

            //StarsTableManager.Load();
            // StarsPositionTableManager.Load();
            //星蕴相关表格加载
            StarTableManager.Load();
            StarPositionTableManager.Load();
            //end

            StarsSuitTableManager.Load();

            CommonSkillSlotTableManager.Load();
            ChatChanelTableManager.Load();

            TaskPasswordTableManager.Load();

            PassiveSkillTableManager.Load();

            ActionTableManager.Load();

            ShopModel.Instance.Load();
            MiniGameTableManager.Load();

            //夏军雁
            TimelineTableManager.Load();
            UICurveMgr.Instance.Load();
            AvatarShowManager.Instance.Load();
			ServersManager.Instance.Load();
			RoleCreationManager.Instance.Load();
			AutoPathFinder.Instance.Load();
			SociatyManager.Instance.Load();
			BattleFieldManager.Instance.Load();
			RandomNameManager.Instance.Load();
			SceneSpawnManager.Instance.Load();
            RankListManager.Instance.Load();
            ThreeDPreviewManager.Instance.Load();
            InlineSpriteManager.Instance.Load();
            ArenaManager.Instance.Load();
            SensitiveWordManager.Instance.Load();
            DailyActivityManager.Instance.Load();
            EquipManager.Instance.Load();
            MapManager.Instance.Load();
            MiniMapManager.Instance.Load();
            UI_AreaTigger.Instance.Load();
            ScreenNarratorManager.Instance.Load();
            DramaManager.Instance.Load();

            // xieliujian
            NpcModelBindCommonDataManager.Instance.Load();
            LifeSkillModel.Instance.Load();

            //song
            StrongholdsManager.Instance.Load();
            WeatherManager.Instance.Load();
            IdentityTableManager.Load();
            IdentityFormulaTableManager.Load();
            PlacerewardTableManager.Load();

            WorldBigMapsTableManager.Load();

           
            
            CollectTableManager.Load();
            ManufactureTableManager.Load();
            ManufactureLevelUpTableManager.Load();
            ProfessionTableManager.Load();
            ResourceTableManager.Load();
			BulletTableManager.Load();
            MaterialHelpManualTableManager.Load();
            NpcSkillListTableManager.Load();
            //ActivityTableManager.Load();
            AchievementTableManager.Load();
            QingKungTableManager.Load();
            AwakeTableManager.Load();
            CultivationTableManager.Load();
            CultivationAttrTableManager.Load();

            FieldEventTableManager.Load();

            CollectionsTableManager.Load();
            CollectionManager.Instance.Load();
            

            // xieliujian
            ShopInfoTableManager.Load();
            
            // npc模型与动作绑定
            NpcModelActionBindTableManager.Load();

            // npc喊话表
            NpcSpeakTableManager.Load();

            MonsterAttrTableManager.Load();

            GuideMgr.Load();
            TreasureMapTableManager.Load();

            MapInfoTableManager.Instance.Load();

            XiandaoExpModel.Instance.Load();

            HeartMethodTableManager.Load();
            HeartMethodComprehendTableManager.Load();

            ProfessionFormulaTableManager.Load();
            ProfessionSkillTableManager.Load();

            HomeModel.Instance.Load();


            //             string strManorObjMaskTable = LoadFileTable("manor_obj_mask.json", "/Datas/");
            //             ManorObjMaskTableManager.Load(strManorObjMaskTable);

#if REMOTE_DEBUG
            string strGMCommandTable = LoadFileTable("gm_commands.json", "/Datas/");
            GMCommandManager.Load(strGMCommandTable);
#endif
            
            //AirWallTableManager.Instance.Load();

            SystemLanguage Language = ILocalizationManager.Instance.GetcurrentLanguage();
            string strLanguage = ILocalizationManager.Instance.GetLanguageAB(Language);
            switch(strLanguage)
            {
                case LocalizationManager.LANGUAGE_CHINESES:
                    {
                       	string strZH_CNTable = LoadFileTable("c_ZH_CNTable.json", "/Tables/LocalizationTables/");
                        ZH_CNTableManager.Load(strZH_CNTable);

                    }
                    break;
                case LocalizationManager.LANGUAGE_CHINESET:
                    {
                        string strZH_HKTable = LoadFileTable("c_ZH_HKTable.json", "/Tables/LocalizationTables/");
                        ZH_HKTableManager.Load(strZH_HKTable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_ENGLISH:
                    {
                        string strENTable = LoadFileTable("c_ENTable.json", "/Tables/LocalizationTables/");
                        ENTableManager.Load(strENTable);
                    }
                    break;

                case LocalizationManager.LANGUAGE_JAPANESE:
                    {
                        string strJPTable = LoadFileTable("c_JPTable.json", "/Tables/LocalizationTables/");
                        JPTableManager.Load(strJPTable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_FRENCH:
                    {
                        string strFRTable = LoadFileTable("c_FRTable.json", "/Tables/LocalizationTables/");
                        FRTableManager.Load(strFRTable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_GERMAN:
                    {
                        string strGETable = LoadFileTable("c_GETable.json", "/Tables/LocalizationTables/");
                        GETableManager.Load(strGETable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_ITALY:
                    {
                        string strITTable = LoadFileTable("c_ITTable.json", "/Tables/LocalizationTables/");
                        ITTableManager.Load(strITTable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_KOREA:
                    {
                        string strKRTable = LoadFileTable("c_KRTable.json", "/Tables/LocalizationTables/");
                        KRTableManager.Load(strKRTable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_RUSSIA:
                    {
                        string strRUTable = LoadFileTable("c_RUTable.json", "/Tables/LocalizationTables/");
                        RUTableManager.Load(strRUTable);
                    }
                    break;
                case LocalizationManager.LANGUAGE_SPANISH:
                    {
                        string strSPTable = LoadFileTable("c_SPTable.json", "/Tables/LocalizationTables/");
                        SPTableManager.Load(strSPTable);
                    }
                    break;
                default: break;
            }
            ILocalizationManager.Instance.Init();
            //"ZH_CNTable", "ZH_HKTable", "ENTable", "FRTable", "GETable", "ITTable", "JPTable", "KRTable", "RUTable", "SPTable"



            EmoteActionTableManager.Load();
            //npc好友
            FriendLevelManager.Load();
            NpcFriendTableManager.Load();
            MainStoryManager.Load();
            //NPCStoryManager.Load();
            //NPCDescManager.Load();
            //NPCTaskManager.Load();
            //NPCMessageManager.Load();
            //FriendLevelManager.Load();
            //快速跳转界面配置
            CharInterfaceIdTableManager.Load();

            ComingNextManager.Load();
            CarryTypeTableManager.Load();

            //qipeng
            InvisibleShaderConfigMgr.Instance.Load();
            VehicleTableManager.Load();
            TestQuestionsTableManager.Load();

            //CommonVarsTableManager.Load();
            TradeTagTableManager.Load();
            InferactionPoolManager.Load();
            ShowPoolManager.Load();

            BuildCityManager.Instance.Load();

            RelicBuffListTableManager.Load();



#if REMOTE_DEBUG
            var addused = System.GC.GetTotalMemory(true) - memused;

            ParamDebugMemoryInfo.SetTablesMemory(addused);
            //LogHelper.LogError("config mem used:", addused.ToString(), "   time:", (DateTime.Now.ToBinary() - time).ToString());
#endif
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static string LoadFileTable(string jsonFile,string strFileFolder = "/Tables/")
        {         
            string strFileName = Utilities.BuildString(strFileFolder, jsonFile);
            return LoadFileData(strFileName);
        }
        public static string LoadFileData(string strFileName)
        {
            byte[] strContent = null;
            try
            {
                strContent = IFile.LoadResourceFiles(strFileName);
                if(strContent != null)
                {
                    return System.Text.Encoding.UTF8.GetString(GameApplication.UTF8Process(strContent));
                }
         
            }
            catch (Exception e)
            {
                LogHelper.LogError(e.ToString());
            }
            return string.Empty;
          
        }  

    }
}