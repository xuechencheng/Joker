using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Bokura
{

	public class AttNpcTableManager
	{
		public AttNpcTableBaseList m_DataList;
		static public void Load()
		{
			byte[] data =  Bokura.IFile.LoadResourceFiles("/Tables/AttNpcTable.bin");;
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
			m_instance = new AttNpcTableManager();
			m_instance.m_DataList = AttNpcTableBaseList.GetRootAsAttNpcTableBaseList(bb);
			CreateKeyToIdList();
		}
		public bool m_HasIniKeyToIdList =false;
		public Dictionary<Int64, int> KeyToIdList;
		static public AttNpcTableBase? GetData(int id)
		{
			if(AttNpcTableManager.Instance.m_HasIniKeyToIdList==false)
			{
				CreateKeyToIdList();
			}
			Int64 m_LongId = 0;
			m_LongId = m_LongId | (uint)id;
			int listid = 0;
			if ( AttNpcTableManager.Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
			{
				var data = AttNpcTableManager.Instance.m_DataList.AttNpcTable(listid);
				return data;
			}
			return null;
		}

		static public void CreateKeyToIdList()
		{
			int length =AttNpcTableManager.Instance.m_DataList.AttNpcTableLength;
			AttNpcTableManager.Instance.KeyToIdList = new Dictionary<Int64, int>(length);
			Int64 m_LongId = 0;
			for (int i = 0; i < length; ++i)
			{
				var data = AttNpcTableManager.Instance.m_DataList.AttNpcTable(i);
				m_LongId = 0;
				m_LongId = m_LongId | (uint)data.Value.id;
				AttNpcTableManager.Instance.KeyToIdList.Add(m_LongId, i);
			}
			AttNpcTableManager.Instance.m_HasIniKeyToIdList = true;
		 }
		static AttNpcTableManager m_instance;
		public static AttNpcTableManager Instance
		{
			get {return m_instance; }
		}
	}


}
