﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // zjc-生产原料表.xlsx
    public class BuildCityMaterialManager : ISingleton<BuildCityMaterialManager>
    {
        [XLua.BlackList]
        private BuildCityMaterialBaseList m_DataList_private;
        
        public BuildCityMaterialBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/BuildCityMaterial.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new BuildCityMaterialManager();
            m_instance.m_DataList_private = BuildCityMaterialBaseList.GetRootAsBuildCityMaterialBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static BuildCityMaterialBase? GetData(int id)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)id;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.BuildCityMaterial(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.BuildCityMaterialLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.BuildCityMaterial(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.id;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"BuildCityMaterial key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"id:{data.Value.id} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}