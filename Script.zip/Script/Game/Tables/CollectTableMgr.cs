﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // sh-生活采集身份表.xlsx
    public class CollectTableManager : ISingleton<CollectTableManager>
    {
        [XLua.BlackList]
        private CollectTableBaseList m_DataList_private;
        
        public CollectTableBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/CollectTable.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new CollectTableManager();
            m_instance.m_DataList_private = CollectTableBaseList.GetRootAsCollectTableBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static CollectTableBase? GetData(int type, int id)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)type;
            m_LongId = m_LongId << 32;
            m_LongId = m_LongId | (uint)id;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.CollectTable(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.CollectTableLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.CollectTable(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.type;
                m_LongId = m_LongId << 32;
                m_LongId = m_LongId | (uint)data.Value.id;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"CollectTable key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"type:{data.Value.type} ");
                    X2StringBuilder.Append($"id:{data.Value.id} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}