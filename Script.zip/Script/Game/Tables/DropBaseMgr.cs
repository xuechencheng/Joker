﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // dl-掉落基本表.xlsx
    public class DropBaseManager : ISingleton<DropBaseManager>
    {
        [XLua.BlackList]
        private DropBaseBaseList m_DataList_private;
        
        public DropBaseBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/DropBase.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new DropBaseManager();
            m_instance.m_DataList_private = DropBaseBaseList.GetRootAsDropBaseBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static DropBaseBase? GetData(int id, int level)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)id;
            m_LongId = m_LongId << 32;
            m_LongId = m_LongId | (uint)level;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.DropBase(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.DropBaseLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.DropBase(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.id;
                m_LongId = m_LongId << 32;
                m_LongId = m_LongId | (uint)data.Value.level;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"DropBase key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"id:{data.Value.id} ");
                    X2StringBuilder.Append($"level:{data.Value.level} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}