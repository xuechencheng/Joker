﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // bq-表情表.xlsx
    public class EmojiTableManager : ISingleton<EmojiTableManager>
    {
        [XLua.BlackList]
        private EmojiTableBaseList m_DataList_private;
        
        public EmojiTableBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/EmojiTable.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new EmojiTableManager();
            m_instance.m_DataList_private = EmojiTableBaseList.GetRootAsEmojiTableBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static EmojiTableBase? GetData(int id)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)id;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.EmojiTable(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.EmojiTableLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.EmojiTable(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.id;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"EmojiTable key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"id:{data.Value.id} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}