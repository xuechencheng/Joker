using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Bokura
{

	public class FlagTableManager
	{
		public FlagTableBaseList m_DataList;
		static public void Load()
		{
			byte[] data =  Bokura.IFile.LoadResourceFiles("/Tables/FlagTable.bin");;
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
			m_instance = new FlagTableManager();
			m_instance.m_DataList = FlagTableBaseList.GetRootAsFlagTableBaseList(bb);
			CreateKeyToIdList();
		}
		public bool m_HasIniKeyToIdList =false;
		public Dictionary<Int64, int> KeyToIdList;
		static public FlagTableBase? GetData(int id)
		{
			if(FlagTableManager.Instance.m_HasIniKeyToIdList==false)
			{
				CreateKeyToIdList();
			}
			Int64 m_LongId = 0;
			m_LongId = m_LongId | (uint)id;
			int listid = 0;
			if ( FlagTableManager.Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
			{
				var data = FlagTableManager.Instance.m_DataList.FlagTable(listid);
				return data;
			}
			return null;
		}

		static public void CreateKeyToIdList()
		{
			int length =FlagTableManager.Instance.m_DataList.FlagTableLength;
			FlagTableManager.Instance.KeyToIdList = new Dictionary<Int64, int>(length);
			Int64 m_LongId = 0;
			for (int i = 0; i < length; ++i)
			{
				var data = FlagTableManager.Instance.m_DataList.FlagTable(i);
				m_LongId = 0;
				m_LongId = m_LongId | (uint)data.Value.id;
				FlagTableManager.Instance.KeyToIdList.Add(m_LongId, i);
			}
			FlagTableManager.Instance.m_HasIniKeyToIdList = true;
		 }
		static FlagTableManager m_instance;
		public static FlagTableManager Instance
		{
			get {return m_instance; }
		}
	}


}
