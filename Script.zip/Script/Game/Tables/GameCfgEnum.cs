namespace Bokura
{
    public enum GameCfgID
    {
        Home_Field_Max_Num = 10001, // 家园田的最大数目 | 值类型 : int 
        Home_Field_Row_Num = 10002, // 家园田的行数 | 值类型 : int 
        Home_Field_Column_Num = 10003, // 家园田的列数 | 值类型 : int 
        Home_Field_Grid_Size = 10004, // 家园灵田格子尺寸 | 值类型 : float 
        Sept_ComingNextCfgId = 20001, // 功能预告表里的帮会id | 值类型 : int 
        Sept_CreateCoin = 20002, // 创建仙门消耗的金币 | 值类型 : int 
        Sept_DeclarationMaxNum = 20003, // 仙门公告最大字数 | 值类型 : int 
        Sept_MaxLevelDesc = 20004, // 最大等级描述 | 值类型 : string 
        Sept_MaxPowerDesc = 20005, // 最大战斗力描述 | 值类型 : string 
        Sept_Introduce_Title = 20006, // 仙门介绍界面 | 值类型 : string 
        Sept_Introduce_Content = 20007, // 仙门介绍界面 | 值类型 : string 
        Sept_Condition_MoveGroup_Content = 20008, // 权限界面移动分组弹窗 | 值类型 : string 
        Sept_Condition_OpenGroup_Content = 20009, // 权限界面开启分组弹窗 | 值类型 : string 
        Sept_Condition_Setting_CanMaster = 20010, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanMoney = 20011, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanBuilding = 20012, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanActive = 20013, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanInfo = 20014, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanGodtree = 20015, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanRecruit = 20016, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanExpel = 20017, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanSpeak = 20018, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_ModifyGroup = 20019, // 权限设置界面权限名字 | 值类型 : string 
        Sept_Condition_Setting_CanMaster_Weight = 20020, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanMoney_Weight = 20021, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanBuilding_Weight = 20022, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanActive_Weight = 20023, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanInfo_Weight = 20024, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanGodtree_Weight = 20025, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanRecruit_Weight = 20026, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanExpel_Weight = 20027, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_CanSpeak_Weight = 20028, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Condition_Setting_ModifyGroup_Weight = 20029, // 权限设置界面权限的权重排序(权重小的排前面) | 值类型 : int 
        Sept_Donate_Content = 20030, // 捐献界面弹窗 | 值类型 : string 
        Sept_Info_QuitSept_Content = 20031, // 信息界面退出仙门弹窗 | 值类型 : string 
        Sept_Invite_ApplyName = 20032, // 邀请弹出界面邀请格式 | 值类型 : string 
        Sept_KickMember_Content = 20033, // 踢除玩家的弹窗 | 值类型 : string 
        Sept_ChangeSeptMaster_Content = 20034, // 转让会长的弹窗 | 值类型 : string 
        Sept_CreateSept_Unmoney_Content = 20035, // 创建仙门界面金币不够弹窗 | 值类型 : string 
        Sept_Npc_SeptMgr = 20036, // 仙门管理建筑物npc的id | 值类型 : int 
        Sept_Npc_SeptPharmacy = 20037, // 仙门药房npc的id | 值类型 : int 
        Sept_Npc_SeptDivine = 20038, // 仙门占卜npc的id | 值类型 : int 
        Sept_Npc_SeptStar = 20039, // 仙门星象npc的id | 值类型 : int 
        Sept_Npc_SeptActivity = 20040, // 仙门活动npc的id | 值类型 : int 
        Sept_Npc_SeptTransfer = 20041, // 仙门传送npc的id | 值类型 : int 
        Sept_Starhorse_ActiveStar = 20042, // 请求激活星象对话框内容 | 值类型 : string 
        Sept_Building_Create = 20043, // 创建建筑对话框内容 | 值类型 : string 
        Sept_Building_Upgrade = 20044, // 升级建筑对话框内容 | 值类型 : string 
        Sept_Feast_Step1_Totaltime = 20045, // 仙门盛宴第一阶段时长(秒) | 值类型 : int 
        Sept_Feast_Step2_Totaltime = 20046, // 仙门盛宴第二阶段时长(秒) | 值类型 : int 
        Sept_Feast_CheckFireCharDis = 20047, // 仙门盛宴检测着火玩家距离 | 值类型 : float 
        Sept_Feast_CheckFireChar_Bufflist = 20048, // 仙门盛宴检测着火玩家的buff列表 | 值类型 : intlist 
        Sept_Feast_Sing_Cooldown = 20049, // 仙门盛宴唱歌倒计时(和服务器同步的一个倒计时) | 值类型 : int 
        Sept_Feast_Sing_NpcInvite_Content = 20050, // npc邀请男玩家唱歌 | 值类型 : string 
        Sept_CreateSept_Buy_Content = 20051, // 仙门创建对话框确认 | 值类型 : string 
        Sept_TopCam_SeePos = 20052, // 切顶视角摄像机后的初始查看位置 | 值类型 : floatlist 
        Sept_TopCam_MiddlePos = 20053, // 顶视角摄像机的中心位置 | 值类型 : floatlist 
        Sept_TopCam_LeftMaxDis = 20054, // 顶视角摄像机从中心往左边移动的最大距离 | 值类型 : int 
        Sept_TopCam_RightMaxDis = 20055, // 顶视角摄像机从中心往右边移动的最大距离 | 值类型 : int 
        Sept_TopCam_TopMaxDis = 20056, // 顶视角摄像机从中心往上边移动的最大距离 | 值类型 : int 
        Sept_TopCam_BottomMaxDis = 20057, // 顶视角摄像机从中心往下边移动的最大距离 | 值类型 : int 
        Sept_Pos = 20058, // 仙门在大世界的位置 | 值类型 : floatlist 
    }
}

