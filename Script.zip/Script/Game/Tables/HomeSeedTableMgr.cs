﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // jy_家园灵田.xlsx
    public class HomeSeedTableManager : ISingleton<HomeSeedTableManager>
    {
        [XLua.BlackList]
        private HomeSeedTableBaseList m_DataList_private;
        
        public HomeSeedTableBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/HomeSeedTable.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new HomeSeedTableManager();
            m_instance.m_DataList_private = HomeSeedTableBaseList.GetRootAsHomeSeedTableBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static HomeSeedTableBase? GetData(int seed_id)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)seed_id;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.HomeSeedTable(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.HomeSeedTableLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.HomeSeedTable(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.seed_id;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"HomeSeedTable key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"seed_id:{data.Value.seed_id} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}