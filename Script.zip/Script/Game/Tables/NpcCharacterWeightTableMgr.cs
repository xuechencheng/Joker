using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Bokura
{

	public class NpcCharacterWeightTableManager
	{
		public NpcCharacterWeightTableBaseList m_DataList;
		static public void Load()
		{
			byte[] data =  Bokura.IFile.LoadResourceFiles("/Tables/NpcCharacterWeightTable.bin");;
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
			m_instance = new NpcCharacterWeightTableManager();
			m_instance.m_DataList = NpcCharacterWeightTableBaseList.GetRootAsNpcCharacterWeightTableBaseList(bb);
			CreateKeyToIdList();
		}
		public bool m_HasIniKeyToIdList =false;
		public Dictionary<Int64, int> KeyToIdList;
		static public NpcCharacterWeightTableBase? GetData(int id)
		{
			if(NpcCharacterWeightTableManager.Instance.m_HasIniKeyToIdList==false)
			{
				CreateKeyToIdList();
			}
			Int64 m_LongId = 0;
			m_LongId = m_LongId | (uint)id;
			int listid = 0;
			if ( NpcCharacterWeightTableManager.Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
			{
				var data = NpcCharacterWeightTableManager.Instance.m_DataList.NpcCharacterWeightTable(listid);
				return data;
			}
			return null;
		}

		static public void CreateKeyToIdList()
		{
			int length =NpcCharacterWeightTableManager.Instance.m_DataList.NpcCharacterWeightTableLength;
			NpcCharacterWeightTableManager.Instance.KeyToIdList = new Dictionary<Int64, int>(length);
			Int64 m_LongId = 0;
			for (int i = 0; i < length; ++i)
			{
				var data = NpcCharacterWeightTableManager.Instance.m_DataList.NpcCharacterWeightTable(i);
				m_LongId = 0;
				m_LongId = m_LongId | (uint)data.Value.id;
				NpcCharacterWeightTableManager.Instance.KeyToIdList.Add(m_LongId, i);
			}
			NpcCharacterWeightTableManager.Instance.m_HasIniKeyToIdList = true;
		 }
		static NpcCharacterWeightTableManager m_instance;
		public static NpcCharacterWeightTableManager Instance
		{
			get {return m_instance; }
		}
	}


}
