using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Bokura
{

	public class NpcProfessionRatioTableManager
	{
		public NpcProfessionRatioTableBaseList m_DataList;
		static public void Load()
		{
			byte[] data =  Bokura.IFile.LoadResourceFiles("/Tables/NpcProfessionRatioTable.bin");;
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
			m_instance = new NpcProfessionRatioTableManager();
			m_instance.m_DataList = NpcProfessionRatioTableBaseList.GetRootAsNpcProfessionRatioTableBaseList(bb);
			CreateKeyToIdList();
		}
		public bool m_HasIniKeyToIdList =false;
		public Dictionary<Int64, int> KeyToIdList;
		static public NpcProfessionRatioTableBase? GetData(int id)
		{
			if(NpcProfessionRatioTableManager.Instance.m_HasIniKeyToIdList==false)
			{
				CreateKeyToIdList();
			}
			Int64 m_LongId = 0;
			m_LongId = m_LongId | (uint)id;
			int listid = 0;
			if ( NpcProfessionRatioTableManager.Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
			{
				var data = NpcProfessionRatioTableManager.Instance.m_DataList.NpcProfessionRatioTable(listid);
				return data;
			}
			return null;
		}

		static public void CreateKeyToIdList()
		{
			int length =NpcProfessionRatioTableManager.Instance.m_DataList.NpcProfessionRatioTableLength;
			NpcProfessionRatioTableManager.Instance.KeyToIdList = new Dictionary<Int64, int>(length);
			Int64 m_LongId = 0;
			for (int i = 0; i < length; ++i)
			{
				var data = NpcProfessionRatioTableManager.Instance.m_DataList.NpcProfessionRatioTable(i);
				m_LongId = 0;
				m_LongId = m_LongId | (uint)data.Value.id;
				NpcProfessionRatioTableManager.Instance.KeyToIdList.Add(m_LongId, i);
			}
			NpcProfessionRatioTableManager.Instance.m_HasIniKeyToIdList = true;
		 }
		static NpcProfessionRatioTableManager m_instance;
		public static NpcProfessionRatioTableManager Instance
		{
			get {return m_instance; }
		}
	}


}
