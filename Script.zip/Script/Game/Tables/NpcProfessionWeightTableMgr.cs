using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Bokura
{

	public class NpcProfessionWeightTableManager
	{
		public NpcProfessionWeightTableBaseList m_DataList;
		static public void Load()
		{
			byte[] data =  Bokura.IFile.LoadResourceFiles("/Tables/NpcProfessionWeightTable.bin");;
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
			m_instance = new NpcProfessionWeightTableManager();
			m_instance.m_DataList = NpcProfessionWeightTableBaseList.GetRootAsNpcProfessionWeightTableBaseList(bb);
			CreateKeyToIdList();
		}
		public bool m_HasIniKeyToIdList =false;
		public Dictionary<Int64, int> KeyToIdList;
		static public NpcProfessionWeightTableBase? GetData(int id)
		{
			if(NpcProfessionWeightTableManager.Instance.m_HasIniKeyToIdList==false)
			{
				CreateKeyToIdList();
			}
			Int64 m_LongId = 0;
			m_LongId = m_LongId | (uint)id;
			int listid = 0;
			if ( NpcProfessionWeightTableManager.Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
			{
				var data = NpcProfessionWeightTableManager.Instance.m_DataList.NpcProfessionWeightTable(listid);
				return data;
			}
			return null;
		}

		static public void CreateKeyToIdList()
		{
			int length =NpcProfessionWeightTableManager.Instance.m_DataList.NpcProfessionWeightTableLength;
			NpcProfessionWeightTableManager.Instance.KeyToIdList = new Dictionary<Int64, int>(length);
			Int64 m_LongId = 0;
			for (int i = 0; i < length; ++i)
			{
				var data = NpcProfessionWeightTableManager.Instance.m_DataList.NpcProfessionWeightTable(i);
				m_LongId = 0;
				m_LongId = m_LongId | (uint)data.Value.id;
				NpcProfessionWeightTableManager.Instance.KeyToIdList.Add(m_LongId, i);
			}
			NpcProfessionWeightTableManager.Instance.m_HasIniKeyToIdList = true;
		 }
		static NpcProfessionWeightTableManager m_instance;
		public static NpcProfessionWeightTableManager Instance
		{
			get {return m_instance; }
		}
	}


}
