﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // xm-仙门建筑物表.xlsx
    public class SeptBuildingManager : ISingleton<SeptBuildingManager>
    {
        [XLua.BlackList]
        private SeptBuildingBaseList m_DataList_private;
        
        public SeptBuildingBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/SeptBuilding.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new SeptBuildingManager();
            m_instance.m_DataList_private = SeptBuildingBaseList.GetRootAsSeptBuildingBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static SeptBuildingBase? GetData(int buildingtype)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)buildingtype;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.SeptBuilding(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.SeptBuildingLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.SeptBuilding(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.buildingtype;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"SeptBuilding key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"buildingtype:{data.Value.buildingtype} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}