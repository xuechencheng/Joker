﻿using System;
using Bokura;
using System.Collections.Generic;
namespace Bokura
{
    // xm-仙门建筑物升级表.xlsx
    public class SeptBuildingUpgradeManager : ISingleton<SeptBuildingUpgradeManager>
    {
        [XLua.BlackList]
        private SeptBuildingUpgradeBaseList m_DataList_private;
        
        public SeptBuildingUpgradeBaseList m_DataList
        {
            get{
            return m_instance.m_DataList_private;
            }
        }
        [XLua.BlackList]
        public bool m_HasIniKeyToIdList = false;
        [XLua.BlackList]
        public Dictionary<Int64, int> KeyToIdList;

        [XLua.BlackList]
        public static void Load()
        {
            byte[] data = IFile.LoadResourceFiles("/Tables/SeptBuildingUpgrade.bin");;
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);bb.EnableStringCache = true;
            m_instance = new SeptBuildingUpgradeManager();
            m_instance.m_DataList_private = SeptBuildingUpgradeBaseList.GetRootAsSeptBuildingUpgradeBaseList(bb);
            CreateKeyToIdList();
        }
        
        public static SeptBuildingUpgradeBase? GetData(int buildingtype, int buildinglevel)
        {
            if(Instance.m_HasIniKeyToIdList == false)
            {
                CreateKeyToIdList();
            }
            
            Int64 m_LongId = 0;
            m_LongId = m_LongId | (uint)buildingtype;
            m_LongId = m_LongId << 32;
            m_LongId = m_LongId | (uint)buildinglevel;
            
            int listid = 0;
            if (Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
            {
                var data = Instance.m_DataList_private.SeptBuildingUpgrade(listid);
                return data;
            }
            return null;
        }
        
        [XLua.BlackList]
        public static void CreateKeyToIdList()
        {
            int length = Instance.m_DataList_private.SeptBuildingUpgradeLength;
            Instance.KeyToIdList = new Dictionary<Int64, int>(length);
            Int64 m_LongId = 0;
            for (int i = 0; i < length; ++i)
            {
                var data = Instance.m_DataList_private.SeptBuildingUpgrade(i);
                m_LongId = 0;
                m_LongId = m_LongId | (uint)data.Value.buildingtype;
                m_LongId = m_LongId << 32;
                m_LongId = m_LongId | (uint)data.Value.buildinglevel;
                if (!Instance.KeyToIdList.ContainsKey(m_LongId))
                    Instance.KeyToIdList.Add(m_LongId, i);
#if !RELEASE
                else
                {    
                    X2StringBuilder.Clear();
                    X2StringBuilder.Append($"SeptBuildingUpgrade key exist id:{m_LongId} ");
                    X2StringBuilder.Append($"buildingtype:{data.Value.buildingtype} ");
                    X2StringBuilder.Append($"buildinglevel:{data.Value.buildinglevel} ");
                    LogHelper.LogError(X2StringBuilder.ConvertToString());
                }
#endif
            }
            Instance.m_HasIniKeyToIdList = true;
        }

    }
}