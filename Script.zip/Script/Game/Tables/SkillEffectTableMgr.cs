using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Bokura
{

	public class SkillEffectTableManager
	{
		public SkillEffectTableBaseList m_DataList;
		static public void Load()
		{
			byte[] data =  Bokura.IFile.LoadResourceFiles("/Tables/SkillEffectTable.bin");;
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(data);
			m_instance = new SkillEffectTableManager();
			m_instance.m_DataList = SkillEffectTableBaseList.GetRootAsSkillEffectTableBaseList(bb);
			CreateKeyToIdList();
		}
		public bool m_HasIniKeyToIdList =false;
		public Dictionary<Int64, int> KeyToIdList;
		static public SkillEffectTableBase? GetData(int id)
		{
			if(SkillEffectTableManager.Instance.m_HasIniKeyToIdList==false)
			{
				CreateKeyToIdList();
			}
			Int64 m_LongId = 0;
			m_LongId = m_LongId | (uint)id;
			int listid = 0;
			if ( SkillEffectTableManager.Instance.KeyToIdList.TryGetValue(m_LongId , out listid) == true)
			{
				var data = SkillEffectTableManager.Instance.m_DataList.SkillEffectTable(listid);
				return data;
			}
			return null;
		}

		static public void CreateKeyToIdList()
		{
			int length =SkillEffectTableManager.Instance.m_DataList.SkillEffectTableLength;
			SkillEffectTableManager.Instance.KeyToIdList = new Dictionary<Int64, int>(length);
			Int64 m_LongId = 0;
			for (int i = 0; i < length; ++i)
			{
				var data = SkillEffectTableManager.Instance.m_DataList.SkillEffectTable(i);
				m_LongId = 0;
				m_LongId = m_LongId | (uint)data.Value.id;
				SkillEffectTableManager.Instance.KeyToIdList.Add(m_LongId, i);
			}
			SkillEffectTableManager.Instance.m_HasIniKeyToIdList = true;
		 }
		static SkillEffectTableManager m_instance;
		public static SkillEffectTableManager Instance
		{
			get {return m_instance; }
		}
	}


}
