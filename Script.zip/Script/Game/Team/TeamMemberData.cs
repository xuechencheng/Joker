
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 组队匹配中的信息
    /// </summary>
    public class MatchTeamInfo
    {
        private uint m_intent = 0;

        public uint Intent
        {
            get
            {
                return m_intent;
            }
            set
            {
                m_intent = value;
            }
        }

        public void Clear()
        {
            m_intent = 0;
        }

    }
    /// <summary>
    /// 组队成员信息
    /// </summary>
    public class TeamMemberData
    {
        private uint m_groupid;//组id
        private ulong m_id = 0;
        private swm.CareerType m_careerType = swm.CareerType.Unknown;//职业
        private uint m_level = 0;
        private swm.TeamMemberState m_state = swm.TeamMemberState.Online;
        private uint m_mapId = 0;
        private Vector3 m_position = new Vector3();
        private bool m_bIsAway = true;
        private ProfessionTableBase? m_ProfessionTableBaseConfig = null;

        private string m_name = string.Empty;

        public swm.CareerType CareerType
        {
            get
            {
                return m_careerType;
            }
            set
            {
                if (null == m_ProfessionTableBaseConfig || m_careerType != value)
                {
                    m_ProfessionTableBaseConfig = ProfessionTableManager.GetData((int)value);
                }
                m_careerType = value;
            }
        }

        public ProfessionTableBase? ProfessionTableBaseConfig
        {
            get
            {
                return m_ProfessionTableBaseConfig;
            }
        }

        public uint GroupId
        {
            get
            {
                return m_groupid;
            }
            set
            {
                m_groupid = value;
            }
        }

        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }

        public bool IsAway//跟随状态
        {
            set
            {
                m_bIsAway = value;
            }
            get
            {
                return m_bIsAway;
            }
        }
        public uint MapId
        {
            set
            {
                m_mapId = value;
            }
            get
            {
                return m_mapId;
            }
        }

        public Vector3 Position
        {
            get
            {
                return m_position;
            }
        }
        public swm.TeamMemberState State
        {
            get
            {
                return m_state;
            }
            set
            {
                m_state = value;
                ReCheckState();
            }
        }

        public uint Level
        {
            get
            {
                return m_level;
            }
            set
            {
                m_level = value;
            }
        }
        public ulong ID
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
		}



		private bool m_IsMatchingBattle = false;
		/// <summary>
		/// 是否正在匹配战场
		/// </summary>
		public bool IsMatchingBattle
		{
			get { return m_IsMatchingBattle; }
			set { m_IsMatchingBattle = value; }
		}



		public bool ReCheckState()
        {
            bool _bIsChange = false;
            if (GameScene.Instance.MainChar != null && m_id != GameScene.Instance.MainChar.ThisID )
            {
                if(m_state == swm.TeamMemberState.Online)
                {
                    //检查是否是远离
                    bool _bIsFar =CheckIsFar();
                    if(_bIsFar)
                    {
                        m_state = swm.TeamMemberState.FarAway;
                        _bIsChange = true;
                    }
                }
                else if(m_state == swm.TeamMemberState.FarAway)
                {
                    bool _bIsFar = CheckIsFar();
                    if(!_bIsFar)
                    {
                        m_state = swm.TeamMemberState.Online;
                        _bIsChange = true;
                    }
                }

            }
            return _bIsChange;
        }


        private float m_farLen = 160.0f;//平方的
		/// <summary>
		/// 判断当前队友与主角之间是否远离
		/// </summary>
        public bool CheckIsFar()
        {
            bool _bIsFar = true;
            if (MapId == GameScene.Instance.CurrentIntomapInfo.Value.map_id)
            {
                Vector3 mainCharPos = GameScene.Instance.MainChar.Position;
                float len = (mainCharPos - Position).sqrMagnitude;
                if (len < m_farLen)
                {
                    _bIsFar = false;
                }
                else if (GameScene.Instance.GetEntityByID(m_id) != null)
                {
                    //9屏内 也不算远离
                    _bIsFar = false;
                }

            }
            return _bIsFar;
        }

        /// <summary>
        /// 判断当前队友与主角之间是否远离(只判断距离)
        /// </summary>
        /// <param name="farrange"></param>
        /// <returns></returns>
        public bool CheckIsFarWithRange(float farrange)
        {
            bool _bIsFar = true;
            if (MapId == GameScene.Instance.CurrentIntomapInfo.Value.map_id)
            {
                Vector3 mainCharPos = GameScene.Instance.MainChar.Position;
                float len = (mainCharPos - Position).sqrMagnitude;
                if (len < farrange)
                {
                    _bIsFar = false;
                }
            }

            return _bIsFar;
        }

        public void Destory()
        {

        }

        public void ResetPosition(swm.Vector3 _pos)
        {
            //m_Position = Utility.NetPos2Vector3(_pos);
            m_position.x = _pos.x;
            m_position.y = _pos.y;
            m_position.z = _pos.z;
        }
    }
    /// <summary>
    /// 组队信息
    /// </summary>
    public class TeamData
    {
        private ulong m_teamId = 0;//队伍唯一id
        private ulong m_leaderId = 0;//队长id
        private swm.TeamType m_teamType = swm.TeamType.Five;//组队规模枚举
        private TeamIntent m_teamTargetInfo = new TeamIntent();
        private List<TeamMemberData>[] m_teamMemberList = new List<TeamMemberData>[(int)(swm.TeamType.Max)];

        public TeamData()
        {
             for(int i =0; i< m_teamMemberList.Length; i++ )
             {
                 m_teamMemberList[i]= new List<TeamMemberData>();
             }
        }


        public List<TeamMemberData>[] TeamMemberList
        {
            get
            {
                return m_teamMemberList;
            }
        }

        public swm.TeamType TeamType
        {
            get
            {
                return m_teamType;
            }
            set
            {
                m_teamType = value;
            }
        }

        public TeamIntent TeamTargetInfo
        {
            get
            {
                return m_teamTargetInfo;
            }
            set
            {
                m_teamTargetInfo = value;
            }
        }

        public ulong TeamId
        {
            get
            {
                return m_teamId;
            }
            set
            {
                m_teamId = value;
            }
        }
        public ulong LeaderId
        {
            get
            {
                return m_leaderId;
            }
            set
            {
                m_leaderId = value;
            }
        }
        public delegate void foreachTeamMemberData(TeamMemberData _data);
        public void foreachTeamMember(foreachTeamMemberData _fuc)
        {
            TeamMemberData _data;
            for (int j =0;j< m_teamMemberList.Length;j++)
            {
                var lst = m_teamMemberList[j];
                for (int i = 0; i < lst.Count; i++)
                {
                    _data = lst[i];
                    _fuc(_data);
                }
            }
        }

        /// <summary>
        /// 清除队伍信息
        /// </summary>
        public void Clear()
        {
            m_teamId = 0;
            m_leaderId = 0;
            TeamMemberData _memberData;
            for (int j = 0; j < m_teamMemberList.Length; j++)
            {
                var lst = m_teamMemberList[j];
                for (int i = 0; i < lst.Count; i++)
                {
                    _memberData = lst[i];
                    _memberData.Destory();
                }
                lst.Clear();
            }
        }
        /// <summary>
        /// 获得整个队伍有多少人
        /// </summary>
        /// <returns></returns>
        public int GetTeamTotalMemberCount()
        {
            int _count = 0;
            for (int j = 0; j < m_teamMemberList.Length; j++)
            {
                var lst = m_teamMemberList[j];
                _count += lst.Count;
            }
            return _count;
        }
        /// <summary>
        /// 通过组id 获得该组成员数量
        /// </summary>
        /// <param name="_groupId"></param>
        /// <returns></returns>
        public int GetTeamGroupMemberCount(uint _groupId)
        {
            int _count = 0;
            List<TeamMemberData> _lst = GetTeamMemberListByGroupId(_groupId);
            if(null != _lst)
            {
                _count = _lst.Count;
            }
            return _count;
        }

        /// <summary>
        /// 通过组id获得 组成员列表
        /// </summary>
        /// <param name="_groupId">组id</param>
        /// <param name="_bIsNoAdd">如果没有是否创建</param>
        /// <returns></returns>
        public List<TeamMemberData> GetTeamMemberListByGroupId(uint _groupId,bool _bIsNoAdd = false)
        {
            List<TeamMemberData> lst = null;
            //if(!m_teamMemberList.TryGetValue(_groupId,out lst))
            if(_groupId < m_teamMemberList.Length)
            {
                lst= m_teamMemberList[_groupId];
            }
            return lst;
        }
        /// <summary>
        /// 通过成员id获得所在组列表
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public List<TeamMemberData> GetTeamMemberListByMemberId(ulong _id)
        {
            TeamMemberData _data;
            for (int j = 0; j < m_teamMemberList.Length; j++)
            {
                var lst = m_teamMemberList[j];
                for (int i = 0; i < lst.Count; i++)
                {
                    _data = lst[i];
                    if (_data.ID == _id)
                    {
                        return lst;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// 通过id移除一个成员
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public TeamMemberData RemoveMemberById(ulong _id)
        {
            TeamMemberData _data;
            for (int j = 0; j < m_teamMemberList.Length; j++)
            {
                var lst = m_teamMemberList[j];
                for (int i = 0; i < lst.Count; i++)
                {
                    _data = lst[i];
                    if (_data.ID == _id)
                    {
                        lst.RemoveAt(i);
                        return _data;
                    }
                }
            }
            return null;
        }
        /// <summary>
        /// 成员换组了
        /// </summary>
        /// <param name="_memberData"></param>
        /// <param name="_memeberInfo"></param>
        public TeamMemberData ChangeMemberGroupByData( swm.TeamMemberInfo _memeberInfo)
        {
            RemoveMemberById(_memeberInfo.userid);
            TeamMemberData _data = AddMembreByData(_memeberInfo);
            return _data;
        }
        /// <summary>
        /// 增加一个成员
        /// </summary>
        /// <param name="_memeberInfo"></param>
        /// <returns></returns>
        public TeamMemberData AddMembreByData(swm.TeamMemberInfo _memeberInfo)
        {
            TeamMemberData _memberData = GetMemberDataByIdAndGroupId(_memeberInfo.userid,_memeberInfo.groupid);
            if(null == _memberData)
            {
                List<TeamMemberData> _lst = GetTeamMemberListByGroupId(_memeberInfo.groupid, true);
                if(null != _lst)
                {
                    _memberData = new TeamMemberData();
                    RefreshMemberByData(_memberData, _memeberInfo);
                    _lst.Add(_memberData);
                    SortMember(_lst);
                }
            }
            else
            {
                List<TeamMemberData> _lst = GetTeamMemberListByGroupId(_memeberInfo.groupid);
                RefreshMemberByData(_memberData, _memeberInfo);
                SortMember(_lst);
            }
            return _memberData;
        }
        /// <summary>
        /// 刷新成员信息
        /// </summary>
        /// <param name="_memberData"></param>
        /// <param name="_memeberInfo"></param>
        public void RefreshMemberByData(TeamMemberData _memberData,swm.TeamMemberInfo _memeberInfo)
        {
            _memberData.GroupId = _memeberInfo.groupid;
            _memberData.ID = _memeberInfo.userid;
            _memberData.Name = _memeberInfo.name;
            _memberData.Level = _memeberInfo.level;
            _memberData.ResetPosition(_memeberInfo.cur_pos.Value);
            _memberData.MapId = _memeberInfo.mapid;
            _memberData.State = _memeberInfo.state;
            _memberData.IsAway = _memeberInfo.is_away;
            _memberData.CareerType = _memeberInfo.type;
        }
        /// <summary>
        /// 排序组列表
        /// </summary>
        /// <param name="_lst"></param>
        public void SortMember(List<TeamMemberData> _lst)
        {
            if (_lst != null && _lst.Count > 0)
            {
                _lst.Sort(ProcessSrotList);
            }
        }
        /// <summary>
        /// 排序方法
        /// </summary>
        /// <param name="_a"></param>
        /// <param name="_b"></param>
        /// <returns></returns>
        int ProcessSrotList(TeamMemberData _a, TeamMemberData _b)
        {
            int master_a = (LeaderId == _a.ID ? 1 : 0);
            int master_b = (LeaderId == _b.ID ? 1 : 0);
            if (master_a < master_b)
            {
                return 1;
            }
            else if(master_a > master_b)
            {
                return -1;
            }

            if (_a.ID < _b.ID)
            {
                return -1;
            }
            else if(_a.ID == _b.ID)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 通过id获得队伍成员信息
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
         public TeamMemberData GetMemberDataById(ulong _id)
        {
            TeamMemberData _data;
            for (int j = 0; j < m_teamMemberList.Length; j++)
            {
                var lst = m_teamMemberList[j];
                for (int i = 0; i < lst.Count; i++)
                {
                    _data = lst[i];
                    if (_data.ID == _id)
                    {
                       return _data;
                    }
                }
            }
            return null;
        }
        /// <summary>
        /// 通过组和成员id获得成员信息
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_groupId"></param>
        /// <returns></returns>
        public TeamMemberData GetMemberDataByIdAndGroupId(ulong _id,uint _groupId)
        {
            TeamMemberData _memberData = null;
            List<TeamMemberData> _lst = GetTeamMemberListByGroupId(_groupId);
            if(null != _lst)
            {
                TeamMemberData _data;
                for (int i = 0; i < _lst.Count; i++)
                {
                    _data = _lst[i];
                    if (_data.ID == _id)
                    {
                        _memberData = _data;
                        break;
                    }
                }
            }
            return _memberData;
        }
        
        //判断附近在线的队员是否全部死亡
        public bool ICanTeamRelive()
        {
            for (int i = 0; i < m_teamMemberList.Length; i++)
            {
                for (int j = 0; j < m_teamMemberList[i].Count; j++)
                {
                    if (m_teamMemberList[i][j].State != swm.TeamMemberState.Die&&
                        m_teamMemberList[i][j].State != swm.TeamMemberState.TempLeave &&
                        m_teamMemberList[i][j].State != swm.TeamMemberState.Offline &&
                        m_teamMemberList[i][j].State != swm.TeamMemberState.FarAway)
                    {
                        return false;
                    }
                }
            }
            
            return true;
        }

    }

    /// <summary>
    /// 组队跟随数据 （消息辅助类）
    /// </summary>
    public class TeamLeaderOperate
    {
        public ulong userid;
        public bool is_away;
        public Vector3 pos = new Vector3();

    }

    /// <summary>
    /// 平台 队伍成员信息 （消息辅助类）
    /// </summary>
    public class TeamMemberBaseInfo
    {
        public swm.CareerType type;
        public uint level = 0;
        public ulong CharId = 0;

        public void SetData(swm.TeamMemberBaseInfo _info)
        {
            type = _info.type;
            level = _info.level;
            CharId = _info.charid;
        }

    }

    /// <summary>
    /// 平台 队伍匹配模式属性 （消息辅助类）
    /// </summary>
    public class TeamIntent
    {
        public uint teamintent = 0;
        public uint teamminlevel = 0;
        public uint teammaxlevel = 0;
        public uint auto_add_team = 0;
        public List<swm.CareerType> needcareer = new List<swm.CareerType>(Bokura.ConstValue.kCap32);
        public void SetTeamIntent(swm.TeamIntent _info)
        {
            teamintent = _info.teamintent;
            teamminlevel = _info.teamminlevel;
            teammaxlevel = _info.teammaxlevel;
            auto_add_team = _info.auto_add_team;
            needcareer.Clear();
            for(int i=0;i< _info.need_careerLength; i++)
            {
                swm.CareerType _careerType = (swm.CareerType)_info.need_career(i);
                needcareer.Add(_careerType);
            }
        }

        public bool IsHasNeedCareer(swm.CareerType _career)
        {
            for(int i =0;i<needcareer.Count;i++)
            {
                if(_career == needcareer[i])
                {
                    return true;
                }
            }
            return false;
        }
    }
    /// <summary>
    /// 平台队伍信息 （消息辅助类）
    /// </summary>
    public class TeamPropInfo
    {
        public ulong teamid = 0;
        public TeamIntent intent = new TeamIntent();
        public ulong leaderid;
        public string leadername;
        public uint level = 0;
        public swm.CareerType type;
        public swm.TeamType teamType;
        public uint head = 0;

        public ulong createtime = 0;
        public List<TeamMemberBaseInfo> _memberInfoList = new List<TeamMemberBaseInfo>(Bokura.ConstValue.kCap32);
        private List<TeamMemberBaseInfo> _memberInfoListPool = new List<TeamMemberBaseInfo>(Bokura.ConstValue.kCap32);

        public int[] _CareerTypeNumberList = new int[(int)swm.CareerType.Max];
        public void Reset(swm.TeamPropInfo _info)
        {
            for (int i = 0; i < _CareerTypeNumberList.Length; i++)
            {
                _CareerTypeNumberList[i] = 0;
            }

            teamid          = _info.teamid;
            leaderid        = _info.leaderid;
            leadername      = _info.leadername;
            level           = _info.level;
            type            = _info.type;
            teamType        = _info.teamtype;
            head            = _info.head;
            createtime      = _info.createtime;
            intent.SetTeamIntent(_info.intent.Value);
            _memberInfoList.Clear();
            for (int i = 0; i < _info.memberLength; i++)
            {
                swm.TeamMemberBaseInfo _memInfo = _info.member(i).Value;
                TeamMemberBaseInfo _baseInfo;
                if (i < _memberInfoListPool.Count)
                {
                    _baseInfo = _memberInfoListPool[i];
                }
                else
                {
                    _baseInfo = new TeamMemberBaseInfo();
                    _memberInfoListPool.Add(_baseInfo);
                }
                _baseInfo.SetData(_memInfo);
                _CareerTypeNumberList[(int)_memInfo.type]++;
                _memberInfoList.Add(_baseInfo);
            }
        }
    }



}
