using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    class TeamModel : ClientSingleton<TeamModel>
    {
        private TeamData m_TeamData = new TeamData();
        private List<NotifyMessageBoxInfo> m_notifyMessageAddTeamList = new List<NotifyMessageBoxInfo>();
        private MatchTeamInfo m_matchInfo = new MatchTeamInfo();//这个值 如果是掉线要处清空理一下 现在暂时没掉线消息

        //private bool m_bIsFllowMove = false;
        public class TeamMemberDataEvent : GameEvent<TeamMemberData>
        {

        }

        public class TeamNotifyMessageEvent : GameEvent<NotifyMessageBoxInfo>
        {

        }

        public class ReturnTeamListEvent : GameEvent<uint,List<TeamPropInfo>>
        {

        }

        public GameEvent onInitTeamEvent = new GameEvent();
        public GameEvent onCompleteRefreshMember = new GameEvent();
        public GameEvent onChangeLeaderEvent = new GameEvent();
        public GameEvent onDisMissTeamEvent = new GameEvent();
        public GameEvent onFixTeamInfoEvent = new GameEvent();
        public GameEvent onLeaveTeamEvent = new GameEvent();
        public GameEvent onMessageRemoveAllTeam = new GameEvent();
        public GameEvent onMessageRefreshMessageInfo = new GameEvent();
        public GameEvent onMatchTeamEvent = new GameEvent();
        public GameEvent onCancelMatchTeamEvent = new GameEvent();
        public GameEvent onMemberCanTeamReliveEvent = new GameEvent();

        public GameEvent<bool> OnMoveFllowEvent = new GameEvent<bool>();

        private GameEvent<Entity, bool> m_OnLeaderAttack = new GameEvent<Entity, bool>();
		/// <summary>
		/// 队长攻击事件
		/// </summary>
		public GameEvent<Entity, bool> onLeaderAttack { get { return m_OnLeaderAttack; } }



		private GameEvent m_OnFollowStateChanged = new GameEvent();
		/// <summary>
		/// 队长跟随事件
		/// </summary>
		public GameEvent onFollowStateChanged { get { return m_OnFollowStateChanged; } }



		public TeamMemberDataEvent onAddTeamMemberEvent = new TeamMemberDataEvent();
        public TeamMemberDataEvent onRefreshTeamMemberEvent = new TeamMemberDataEvent();
        public TeamMemberDataEvent onRemoveTeamMemberEvent = new TeamMemberDataEvent();
        public TeamMemberDataEvent onRefreshMemberState = new TeamMemberDataEvent();
        
        public TeamNotifyMessageEvent onMessageAddTeam = new TeamNotifyMessageEvent();
        public TeamNotifyMessageEvent onMessageRemoveTeam = new TeamNotifyMessageEvent();
        public TeamNotifyMessageEvent onMessageInviteTeam = new TeamNotifyMessageEvent();

        public ReturnTeamListEvent onReturnTeamListEvent = new ReturnTeamListEvent();

        //public bool IsFllowMove
        //{
        //    get
        //    {
        //        return m_bIsFllowMove;
        //    }
        //}

        public TeamData TeamData
        {
            get
            {
                return m_TeamData;
            }
        }

        /// <summary>
        /// 主角
        /// </summary>
        private MainCharacter m_MainChar = null;

        public MatchTeamInfo MatchInfo
        {
            get
            {
                return m_matchInfo;
            }
        }

        public List<NotifyMessageBoxInfo> NotifyMessageAddTeamList
        {
            get
            {
                return m_notifyMessageAddTeamList;
            }
        }

        public int GetNotifyMessageAddTeamNumber()
        {
            return m_notifyMessageAddTeamList.Count;

        }

        public int GetUnReadNotifyMessageNumber()
        {
            int num = 0;
            if(m_notifyMessageAddTeamList.Count > 0)
            {
                NotifyMessageBoxInfo _info;
                for (int i=0;i< m_notifyMessageAddTeamList.Count;i++)
                {
                    _info = m_notifyMessageAddTeamList[i];
                    if(!_info.IsRead)
                    {
                        num++;
                    }
                }
            }
            return num;
        }


        public TeamMemberData GetMainCharTeamMemberData()
        {
            if(null == GameScene.Instance.MainChar)
            {
                return null;
            }
            return GetTeamMemberDataById(GameScene.Instance.MainChar.ThisID);
        }

        /// <summary>
        /// 队长是否在攻击
        /// </summary>
        /// <returns></returns>
        public bool IsTeamLeaderInAttack()
        {
            if (m_TeamData == null)
                return false;

            Entity entity = GameScene.Instance.GetEntityByID(m_TeamData.LeaderId);
            if (entity == null)
                return false;

            return entity.IsInAttack;
        }

        /// <summary>
        /// 是否主角远离
        /// </summary>
        /// <returns></returns>
        public bool IsMainCharTeamMemberAway()
        {
            TeamMemberData memberdata = GetMainCharTeamMemberData();
            if (memberdata == null)
                return true;

            return memberdata.IsAway;
        }

        /// <summary>
        /// 是否成员是主角
        /// </summary>
        /// <param name="memberdata"></param>
        /// <returns></returns>
        public bool IsTeamMemberIsMainChar(TeamMemberData memberdata)
        {
            if (memberdata == null)
                return false;

            TeamMemberData mainmemdata = GetMainCharTeamMemberData();
            if (mainmemdata == null)
                return false;

            return mainmemdata.ID == memberdata.ID;
        }

        /// <summary>
        /// 获取指定角色的队伍成员数据
        /// </summary>
        public TeamMemberData GetTeamMemberDataById(ulong id)
        {
            return m_TeamData.GetMemberDataById(id);
        }

        public swm.TeamType GetTeamType()
        {
            return m_TeamData.TeamType;
        }

        /// <summary>
        /// 队伍成员数量
        /// </summary>
        /// <returns></returns>
        public int GetMemberNumber()
        {
            return m_TeamData.GetTeamTotalMemberCount();
        }

        /// <summary>
        /// 自己是否有队伍
        /// </summary>
        /// <returns></returns>
        public bool IsHasTeam()
        {
            return GetMemberNumber() > 0;
        }

        /// <summary>
        /// 检查主角是否是队长
        /// </summary>
        /// <returns></returns>
        public bool CheckMainCharactorIsMaster()
        {
            if(null == GameScene.Instance.MainChar )
            {
                return false;
            }
            return CheckIsMasterById(GameScene.Instance.MainChar.ThisID);
        }



		/// <summary>
		/// 返回队长
		/// </summary>
		public TeamMemberData GetMaster()
		{
			TeamMemberData tMaster = null;
			if (IsHasTeam())
				tMaster = m_TeamData.GetMemberDataById(m_TeamData.LeaderId);
			return tMaster;
		}



		/// <summary>
		/// 检查输入的id是否是队长
		/// </summary>
		/// <param name="_id"></param>
		/// <returns></returns>
		public bool CheckIsMasterById(ulong _id)
        {
            bool _b = false;
            if (IsHasTeam())
            {
                _b = m_TeamData.LeaderId == _id;
            }
            return _b;
        }

        private List<uint> _deleteList = new List<uint>(16);

        public void Update()
        {
            if(m_notifyMessageAddTeamList.Count>0)
            {
                NotifyMessageBoxInfo _data = null;
                _deleteList.Clear();
                ulong serverTime = GameScene.Instance.GetServerTime();
                for (int i = 0; i < m_notifyMessageAddTeamList.Count; i++)
                {
                    _data = m_notifyMessageAddTeamList[i];
                    if(_data.NetMessage.Value.time>0 && serverTime > _data.NetMessage.Value.time)
                    {
                        _deleteList.Add(_data.NetMessage.Value.version);
                    }
                }
				for (int i = 0; i < _deleteList.Count; i++)
				{
					uint _id = _deleteList[i];
					RemoveTeamMessageById(_id);
				}
			}

		}


        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshTeamIntent>(ProcRefreshTeamInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshStateTeam>(ProcRefreshStateTeam);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RemoveTeamMember>(ProcRemoveTeamMember);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.DisMissTeam>(ProcDisMissTeam);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ChangeLeaderTeam>(ProcChangeLeaderTeam);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.FixTeamInfo>(ProcFixTeamInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.LeaveTeam>(ProcLeaveTeam);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RefreshTeamMemberPosInfo>(ProcSycPlayerPos);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ReturnTeamList>(ProcReturnTeamList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RequestMatchTeam>(ProcRequestMatchTeam);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.CancelMatchTeam>(ProcCancelMatchTeam);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ReturnTeamLeaderOperate>(ProcReturnTeamLeaderOperate);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ForwardLeaderAttack>(ProcForwardLeaderAttack);
            
            //注册其他逻辑系统消息
            GeneralMessageModel.Instance.onNotifyMessage.AddListener(ProcessNotifyMessage);
            GameScene.Instance.onMainCharSnakePosChangeEvent.AddListener(ProcessMainCharSnakePosChange);          
        }

        public void Clear()
        {
            //m_bIsFllowMove = false;
            m_TeamData.Clear();
            m_matchInfo.Clear();
            m_notifyMessageAddTeamList.Clear();

            if (m_MainChar != null)
            {
                m_MainChar.onMoveByJoyStickEvent.RemoveListener(ProcMoveByJoyStickEvent);
            }
        }

        [XLua.BlackList]
        public void SetMainChar(MainCharacter mainChar)
        {
            m_MainChar = mainChar;

            if (m_MainChar != null)
            {
                m_MainChar.onMoveByJoyStickEvent.AddListener(ProcMoveByJoyStickEvent);
            }
        }

        private void ProcMoveByJoyStickEvent(bool move)
        {
            if (!move)
                return;

            // 没有队伍不处理消息
            bool hasteam = IsHasTeam();
            if (!hasteam)
                return;

            // 队长不能取消跟随
            bool isteamleader = CheckMainCharactorIsMaster();
            if (isteamleader)
                return;

            // 队员是否跟随状态
            bool isaway = IsMainCharTeamMemberAway();
            if (isaway)
                return;

            SendFollowTeamMember(true);
        }

        private void ProcessNotifyMessage(NotifyMessageBoxInfo _info)
        {
            if (_info.NetMessage.Value.msg_type == swm.MessageBoxType.AddTeam)
            {
                AddAddTeamMessageBox(_info);
            }
            else if (_info.NetMessage.Value.msg_type == swm.MessageBoxType.InviteTeam)
            {
                onMessageInviteTeam.Invoke(_info);
            }
        }

        public NotifyMessageBoxInfo GetTeamMessageBoxById(uint _id)
        {
            NotifyMessageBoxInfo _info = null;
            NotifyMessageBoxInfo _data = null;
            for (int i = 0; i < m_notifyMessageAddTeamList.Count; i++)
            {
                _data = m_notifyMessageAddTeamList[i];
                if (_data.NetMessage.Value.version == _id)
                {
                    _info = _data;
                    break;
                }
            }
            return _info;
        }
        private void AddAddTeamMessageBox(NotifyMessageBoxInfo _info)
        {
            if (null == GetTeamMessageBoxById(_info.NetMessage.Value.version) && !CheckAddTeamMessageBoxIsHasSrc(_info.NetMessage.Value.srcid))
            {
                m_notifyMessageAddTeamList.Add(_info);
                onMessageAddTeam.Invoke(_info);
            }
        }

        private bool CheckAddTeamMessageBoxIsHasSrc(ulong _srcid)
        {
            bool _b = false;
            NotifyMessageBoxInfo _data = null;
            for (int i = 0; i < m_notifyMessageAddTeamList.Count; i++)
            {
                _data = m_notifyMessageAddTeamList[i];
                if (_data.NetMessage.Value.srcid == _srcid)
                {
                    _b = true;
                    break;
                }
            }
            return _b;
        }

        public void ClearAllTeamMessageBox()
        {
            m_notifyMessageAddTeamList.Clear();
            onMessageRemoveAllTeam.Invoke();
        }

        public void DispatchMessageRefreshMessageInfo()
        {
            
            onMessageRefreshMessageInfo.Invoke();
        }

        public void RemoveTeamMessageById(uint _id)
        {
            NotifyMessageBoxInfo _info = GetTeamMessageBoxById(_id);
            if(null != _info)
            {
                RemoveTeamMessage(_info);
            }
        }

        public void RemoveTeamMessage(NotifyMessageBoxInfo _info)
        {
            if(null != _info)
            {
                if (m_notifyMessageAddTeamList.Remove(_info))
                {
                    onMessageRemoveTeam.Invoke(_info);
                }
            }
        }
        private List<TeamLeaderOperate> m_TeamLeaderOperateList = new List<TeamLeaderOperate>();
        private List<TeamLeaderOperate> m_TeamLeaderOperateListPool = new List<TeamLeaderOperate>();
        private void ProcessMainCharSnakePosChange()
        {
             if(CheckMainCharactorIsMaster() && GetMemberNumber() > 1)//自己是队长
             {
                 List<SnakePosParam> _lst = GameScene.Instance.MainChar.SnakePosList;
                 if(null != _lst)
                 {
                     //x2m.ForwardTeamLeaderOperate _msg = null;
                     m_TeamLeaderOperateList.Clear();
                     List<TeamMemberData>[] _memberList = m_TeamData.TeamMemberList;
                     TeamMemberData _memberData;
                     int j = 1;
                     SnakePosParam _snakePosData;

                    for (int i = 0; i < _memberList.Length; i++)
                    {
                        var lst = _memberList[i];
                        for (int k = 0; k < lst.Count; k++)
                        {
                            _memberData = lst[k];
                            if (j < _lst.Count && _memberData.ID != GameScene.Instance.MainChar.ThisID &&
                               (_memberData.State == swm.TeamMemberState.Online || _memberData.State == swm.TeamMemberState.FarAway)
                               && !_memberData.IsAway)
                            {
                                _snakePosData = _lst[j];
                                TeamLeaderOperate _teamLeaderOp;
                                if (j - 1 < m_TeamLeaderOperateListPool.Count)
                                {
                                    _teamLeaderOp = m_TeamLeaderOperateListPool[j - 1];
                                }
                                else
                                {
                                    _teamLeaderOp = new TeamLeaderOperate();
                                    m_TeamLeaderOperateListPool.Add(_teamLeaderOp);
                                }
                                _teamLeaderOp.userid = _memberData.ID;
                                _teamLeaderOp.is_away = _memberData.IsAway;// _memberData.State == swm.TeamMemberState.FarAway;
                                _teamLeaderOp.pos.x = _snakePosData.m_pos.x;
                                _teamLeaderOp.pos.y = _snakePosData.m_pos.y;
                                _teamLeaderOp.pos.z = _snakePosData.m_pos.z;
                                m_TeamLeaderOperateList.Add(_teamLeaderOp);

                                j++;
                            }
                        }
                    }
 
                     if (m_TeamLeaderOperateList.Count > 0)
                     {
                         SendForwardTeamLeaderOperate();
                     }
                 }
             }
        }

        //接收数据
        /// <summary>
        /// 接收 刷新队伍信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshTeamInfo(swm.RefreshTeamIntent _msg)
        {
            bool bIsHasTeam = IsHasTeam();
            if(bIsHasTeam)
            {
                //有队伍
                if(m_TeamData.TeamType != _msg.type)
                {
                    //只是更换了队伍规模 ，那就清空了 重新加载
                    m_TeamData.Clear();
                    bIsHasTeam = false;
                }
            }
            m_TeamData.TeamId = _msg.teamid;
            m_TeamData.TeamType = _msg.type;
            m_TeamData.LeaderId = _msg.leaderid;
            m_TeamData.TeamTargetInfo.SetTeamIntent(_msg.info.Value);
            m_matchInfo.Clear();
            if (bIsHasTeam)
            {
                //已经有队伍了 是刷新数据
                if ( _msg.memberLength >0)
                {
                    swm.TeamMemberInfo _info;
                    TeamMemberData _memberData;
                    for (int i = 0; i < _msg.memberLength; i++)
                    {
                        _info = _msg.member(i).Value;
                        _memberData = m_TeamData.GetMemberDataById(_info.userid);
                        if(null == _memberData)
                        {
                            _memberData = m_TeamData.AddMembreByData(_info);
                            ProcessMainCharSnakePosChange();///新成员加入 如果是队长要把队员拉过来
                            onAddTeamMemberEvent.Invoke(_memberData);
                        }
                        else
                        {
                            if(_info.groupid != _memberData.GroupId)
                            {
                                //换组了
                                _memberData = m_TeamData.ChangeMemberGroupByData( _info);
                            }
                            else
                            {
                                m_TeamData.RefreshMemberByData(_memberData, _info);
                            }
                            onRefreshTeamMemberEvent.Invoke(_memberData);//这里要判定一下 是否真的有刷新
                        }
                    }
                    onCompleteRefreshMember.Invoke();
                }
            }
            else
            {
                if(_msg.memberLength > 0)
                {
                    swm.TeamMemberInfo _info;
                    for (int i = 0;i < _msg.memberLength; i++)
                    {
                        _info = _msg.member(i).Value;
                        m_TeamData.AddMembreByData(_info);
                        
                    }
                }
                onInitTeamEvent.Invoke();//有队伍了
            }
            CheckCanTeamRelive();
        }
        /// <summary>
        /// 接收 刷新队伍成员状态
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRefreshStateTeam(swm.RefreshStateTeam _msg)
        {
            TeamMemberData _memberData = m_TeamData.GetMemberDataById(_msg.userid);
            if(null != _memberData )
            {
                _memberData.State = _msg.state;
                bool _bOldAway = _memberData.IsAway;
                _memberData.IsAway = _msg.is_away;
				_memberData.IsMatchingBattle = _msg.is_matching_battle;

                onRefreshMemberState.Invoke(_memberData);
                CheckCanTeamRelive();
                if (_bOldAway != _msg.is_away )
                {
//                     if(!_bOldAway && _msg.userid == GameScene.Instance.MainChar.ThisID)
//                     {
//                         GameScene.Instance.MainChar.Stop();
//                     }
                    ProcessMainCharSnakePosChange();
                }
            }
            
        }
        /// <summary>
        /// 接收 删除队员
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRemoveTeamMember(swm.RemoveTeamMember _msg)
        {
            TeamMemberData _data = m_TeamData.RemoveMemberById(_msg.userid);
            if(null != _data)
            {
                onRemoveTeamMemberEvent.Invoke(_data);
                CheckCanTeamRelive();
            }
        }

        /// <summary>
        /// 接收 解散队伍
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcDisMissTeam(swm.DisMissTeam _msg)
        {
            m_TeamData.Clear();
            ClearAllTeamMessageBox();
            onDisMissTeamEvent.Invoke();
            CheckCanTeamRelive();
        }

        /// <summary>
        /// 接收 更换队长
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcChangeLeaderTeam(swm.ChangeLeaderTeam _msg)
        {
            if(_msg.leaderid != 0 && m_TeamData.LeaderId != _msg.leaderid)
            {
                m_TeamData.LeaderId = _msg.leaderid;
                List<TeamMemberData> _lst = m_TeamData.GetTeamMemberListByMemberId(m_TeamData.LeaderId);
                m_TeamData.SortMember(_lst);
                onChangeLeaderEvent.Invoke();
                ProcessMainCharSnakePosChange();
            }
        }
        /// <summary>
        /// 接收 修改队伍属性
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcFixTeamInfo(swm.FixTeamInfo _msg)
        {
            m_TeamData.TeamTargetInfo.SetTeamIntent( _msg.info.Value);
            onFixTeamInfoEvent.Invoke();
        }

        /// <summary>
        /// 接收 离开队伍
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcLeaveTeam(swm.LeaveTeam _msg)
        {
            m_TeamData.Clear();
            ClearAllTeamMessageBox();
            onLeaveTeamEvent.Invoke();
            CheckCanTeamRelive();
        }
        /// <summary>
        /// 接收 同步队员坐标和地图
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcSycPlayerPos(swm.RefreshTeamMemberPosInfo _msg)
        {
            for(int i=0;i<_msg.member_posLength; i++)
            {
                swm.TeamMemberPosInfo _info = _msg.member_pos(i).Value;
                TeamMemberData _data = m_TeamData.GetMemberDataById(_info.userid);
                if (null != _data)
                {
                    _data.ResetPosition(_info.cur_pos.Value);
                    _data.MapId = _info.mapid;
                    bool _bisChange = _data.ReCheckState();
                    if (_bisChange)
                    {
                        onRefreshMemberState.Invoke(_data);
                        CheckCanTeamRelive();
                    }
                }
            }

        }

        void CheckCanTeamRelive()
        {
            if (m_TeamData.ICanTeamRelive())
            {
                onMemberCanTeamReliveEvent.Invoke();
            }
        }

        private List<TeamPropInfo> m_TeamPropInfoListPool = null;
        private List<TeamPropInfo> m_TeamPropInfoList = null;
        /// <summary>
        /// 接收 平台队伍列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcReturnTeamList(swm.ReturnTeamList _msg)
        {
            if(null == m_TeamPropInfoList)
            {
                m_TeamPropInfoList = new List<TeamPropInfo>();
            }
            if(null == m_TeamPropInfoListPool)
            {
                m_TeamPropInfoListPool = new List<TeamPropInfo>();
            }
            m_TeamPropInfoList.Clear();

            for(int i=0;i<_msg.teamsLength;i++)
            {
                swm.TeamPropInfo _info = _msg.teams(i).Value;
                TeamPropInfo _teamInfo;
                if (i< m_TeamPropInfoListPool.Count)
                {
                    _teamInfo = m_TeamPropInfoListPool[i];
                }
                else
                {
                    _teamInfo = new TeamPropInfo();
                    m_TeamPropInfoListPool.Add(_teamInfo);
                }
                _teamInfo.Reset(_info);
                m_TeamPropInfoList.Add(_teamInfo);
            }


            onReturnTeamListEvent.Invoke(_msg.intent ,m_TeamPropInfoList);
        }

        private void SortReturnTeamListList()
        {
            if (m_TeamPropInfoList.Count > 0)
            {
                m_TeamPropInfoList.Sort(ProcessReturnTeamListList);
            }
        }

        private int ProcessReturnTeamListList(TeamPropInfo _a, TeamPropInfo _b)
        {
            
            int _aIsNeedCareer = _a.intent.IsHasNeedCareer(GameScene.Instance.MainChar.CareerType) ? 1:0;
            int _bIsNeedCareer = _b.intent.IsHasNeedCareer(GameScene.Instance.MainChar.CareerType) ? 1 : 0;
            if(_aIsNeedCareer > _bIsNeedCareer)
            {
                return -1;
            }
            else if(_aIsNeedCareer < _bIsNeedCareer)
            {
                return 1;
            }

            if (_a.createtime > _b.createtime)
            {
                return -1;
            }
            else if (_a.createtime < _b.createtime)
            {
                return 1;
            }

            if (_a.teamid < _b.teamid)
            {
                return -1;
            }
            else if (_a.teamid == _b.teamid)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 接收 匹配信息
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRequestMatchTeam(swm.RequestMatchTeam _msg)
        {
            m_matchInfo.Intent = _msg.intent;
            onMatchTeamEvent.Invoke();
        }

        /// <summary>
        /// 接收 取消匹配
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcCancelMatchTeam(swm.CancelMatchTeam _msg)
        {
            m_matchInfo.Clear();
            onCancelMatchTeamEvent.Invoke();
        }

        /// <summary>
        /// 返回跟随队长的操作
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcReturnTeamLeaderOperate(swm.ReturnTeamLeaderOperate _msg)
        {
            swm.TeamLeaderOperate? teamop = _msg.operate;
            if (!teamop.HasValue)
                return;

            if (_msg.operate.Value.userid == GameScene.Instance.MainChar.ThisID )
            {
				onFollowStateChanged.Invoke();
                
                if (!_msg.operate.Value.is_away)
                {
                    Entity _etyLeader = null;
                    if (IsHasTeam())
                    {
                        _etyLeader = GameScene.Instance.GetEntityByID(m_TeamData.LeaderId);
                    }

                     
                    if (_etyLeader != null || GameScene.Instance.curLineID == teamop.Value.TeamLeaderLineID)
                    {
                        // LogHelper.LogWarning("ProcReturnTeamLeaderOperate start:");
                        AutoPathFinder.Instance.ClearMoveStop();
                        //m_bIsFllowMove = true;
                        GameScene.Instance.MainChar.MoveByWorldPoint(_msg.operate.Value.cur_pos.FBVec3Vec3(), OnMoveStopDelegate);
                        //LogHelper.LogWarning("ProcReturnTeamLeaderOperate end:");
                    }
                    else
                    {
                        SendFollowTeamMember(true);
                    }

                }
 
            }
        }

        private void OnMoveStopDelegate(bool _bArrived)
        { 
			//m_bIsFllowMove = false;
            OnMoveFllowEvent.Invoke(_bArrived);
        }

        /// <summary>
        /// 当前锁定目标
        /// </summary>
        private Entity m_LeaderLocked;
        public Entity LeaderLocked { get { return m_LeaderLocked; } }



        /// <summary>
        /// 队长锁定目标的操作
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcForwardLeaderAttack(swm.ForwardLeaderAttack _msg)
        {
			m_LeaderLocked = GameScene.Instance.GetEntityByID( _msg.lock_entity_id);
            var data = GetMainCharTeamMemberData();
			if (data != null /*在队伍中*/&& !CheckMainCharactorIsMaster()/*不是队长*/)
				m_OnLeaderAttack.Invoke(LeaderLocked, _msg.attack);
        }



        //客户端 发送
        /// <summary>
        /// 发送 创建队伍
        /// </summary>
        public void SendCreateTeam(swm.TeamType _teamType = swm.TeamType.Five)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.CreateTeam.StartCreateTeam(fbb);
            swm.CreateTeam.AddType(fbb, _teamType);
            var msg = swm.CreateTeam.EndCreateTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.CreateTeam.HashID, fbb);
        }
        /// <summary>
        /// 发送 解散队伍
        /// </summary>
        public void SendDisMissTeam()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.DisMissTeam.StartDisMissTeam(fbb);
            var msg = swm.DisMissTeam.EndDisMissTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.DisMissTeam.HashID, fbb);
            
        }
        /// <summary>
        /// 发送 离开队伍
        /// </summary>
        public void SendLeaveTeam()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.LeaveTeam.StartLeaveTeam(fbb);
            var msg = swm.LeaveTeam.EndLeaveTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.LeaveTeam.HashID, fbb);
        }
        /// <summary>
        /// 发送 踢出队伍
        /// </summary>
        /// <param name="_id"></param>
        public void SendKickTeam(ulong _id)
        {
//             x2m.KickTeam _msg = new x2m.KickTeam();
//             _msg.userid = _id;
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.KickTeam.StartKickTeam(fbb);
            swm.KickTeam.AddUserid(fbb, _id);   
            var msg = swm.KickTeam.EndKickTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.KickTeam.HashID, fbb);
        }
        /// <summary>
        /// 发送 请求更换队长
        /// </summary>
        /// <param name="_id"></param>
        public void SendChangeLeaderTeam(ulong _id)
        {
//             x2m.ChangeLeaderTeam _msg = new x2m.ChangeLeaderTeam();
//             _msg.leaderid = _id;
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ChangeLeaderTeam.StartChangeLeaderTeam(fbb);
            swm.ChangeLeaderTeam.AddLeaderid(fbb, _id);
            var msg = swm.ChangeLeaderTeam.EndChangeLeaderTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ChangeLeaderTeam.HashID, fbb);
        }
        /// <summary>
        /// 发送 请求组队
        /// </summary>
        public void SendRequestTeam(ulong _id)
        {
//             x2m.RequestTeam _msg = new x2m.RequestTeam();
//             _msg.selecteuserid = _id;
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.RequestTeam.StartRequestTeam(fbb);
            swm.RequestTeam.AddSelecteuserid(fbb, _id);
            var msg = swm.RequestTeam.EndRequestTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.RequestTeam.HashID, fbb);
        }
        /// <summary>
        /// 发送 修改队伍属性
        /// </summary>
        /// <param name="_info"></param>
        public void SendFixTeamInfo(uint _teamintent,uint _teamminlevel,uint _teammaxlevel,uint _auto_add_team, List<uint> _list)//x2m.TeamIntent _info)
        {
            //             x2m.FixTeamInfo _msg = new x2m.FixTeamInfo();
            //             _msg.info = _info;
            //             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var vec = swm.TeamIntent.CreateNeedCareerVector(fbb, _list.ToArray());

            swm.TeamIntent.StartTeamIntent(fbb);
            swm.TeamIntent.AddTeamintent(fbb, _teamintent);
            swm.TeamIntent.AddTeamminlevel(fbb, _teamminlevel);
            swm.TeamIntent.AddTeammaxlevel(fbb, _teammaxlevel);
            swm.TeamIntent.AddAutoAddTeam(fbb, _auto_add_team);
            swm.TeamIntent.AddNeedCareer(fbb, vec);
            var ti = swm.TeamIntent.EndTeamIntent(fbb);

            swm.FixTeamInfo.StartFixTeamInfo(fbb);
            swm.FixTeamInfo.AddInfo(fbb, ti);
            var msg = swm.FixTeamInfo.EndFixTeamInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.FixTeamInfo.HashID, fbb);
        }
        /// <summary>
        /// 发送 请求队伍列表
        /// </summary>
        /// <param name="_intent"></param>
        public void SendRequestTeamList(uint _intent)
        {
//             x2m.RequestTeamList _msg = new x2m.RequestTeamList();
//             _msg.intent = _intent;
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.RequestTeamList.StartRequestTeamList(fbb);
            swm.RequestTeamList.AddIntent(fbb, _intent);
            var msg = swm.RequestTeamList.EndRequestTeamList(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.RequestTeamList.HashID, fbb);
        }
        /// <summary>
        /// 发送 请求匹配队伍
        /// </summary>
        /// <param name="_intent"></param>
        public void SendRequestMatchTeam(uint _intent)
        {
//             x2m.RequestMatchTeam _msg = new x2m.RequestMatchTeam();
//             _msg.intent = _intent;
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.RequestMatchTeam.StartRequestMatchTeam(fbb);
            swm.RequestMatchTeam.AddIntent(fbb, _intent);
            var msg = swm.RequestMatchTeam.EndRequestMatchTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.RequestMatchTeam.HashID, fbb);
        }
        /// <summary>
        /// 发送 取消匹配队伍
        /// </summary>
        public void SendCancelMatchTeam()
        {
//             x2m.CancelMatchTeam _msg = new x2m.CancelMatchTeam();
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.CancelMatchTeam.StartCancelMatchTeam(fbb);
            var msg = swm.CancelMatchTeam.EndCancelMatchTeam(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.CancelMatchTeam.HashID, fbb);
        }

        /// <summary>
        /// 发送 召集队友
        /// </summary>
        public void SendClumpTeamMember(ulong _id)
        {
//             x2m.ClumpTeamMember _msg = new x2m.ClumpTeamMember();
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ClumpTeamMember.StartClumpTeamMember(fbb);
            swm.ClumpTeamMember.AddMemberid(fbb,_id);
            var msg = swm.ClumpTeamMember.EndClumpTeamMember(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ClumpTeamMember.HashID, fbb);
        }
        /// <summary>
        /// 发送 跟随、取消跟随队长
        /// </summary>
        /// <param name="_follow"></param>
        public void SendFollowTeamMember(bool _is_away)
        {
            //             x2m.FollowTeamMember _msg = new x2m.FollowTeamMember();
            //             _msg.is_away = _is_away;
            //             _msg.is_keep_away = true;
            //             TeamMemberData _memberData = m_TeamData.GetMemberDataById(m_TeamData.LeaderId);
            //             if(null != _memberData)
            //             {
            //                 _msg.is_keep_away = _memberData.State == x2m.TeamMemberState.FarAway;
            //             }
            // 
            //             MsgDispacther.instance.SendPackage(_msg);

            bool is_keep_away = true;
            TeamMemberData _memberData = m_TeamData.GetMemberDataById(m_TeamData.LeaderId);
            if (null != _memberData)
            {
                is_keep_away = _memberData.State == swm.TeamMemberState.FarAway;
            }

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.FollowTeamMember.StartFollowTeamMember(fbb);
            swm.FollowTeamMember.AddIsAway(fbb, _is_away);
            swm.FollowTeamMember.AddIsKeepAway(fbb, is_keep_away);
            var msg = swm.FollowTeamMember.EndFollowTeamMember(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.FollowTeamMember.HashID, fbb);
        }

        /// <summary>
        /// 发送 转发队长操作（移动、跳.....）
        /// </summary>
        public void SendForwardTeamLeaderOperate()
        {
            
//             //这样发消息优点奇怪 但是为了不必要的赋值操作 不得已这样做
//             MsgDispacther.instance.SendPackage(_msg);

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            var data = new FlatBuffers.Offset<swm.TeamLeaderOperate>[m_TeamLeaderOperateList.Count];
            for (int i=0;i< m_TeamLeaderOperateList.Count;i++)
            {
                TeamLeaderOperate op = m_TeamLeaderOperateList[i];
                swm.TeamLeaderOperate.StartTeamLeaderOperate(fbb);
                swm.TeamLeaderOperate.AddUserid(fbb, op.userid);
                swm.TeamLeaderOperate.AddIsAway(fbb, op.is_away);
                swm.TeamLeaderOperate.AddTeamLeaderLineID(fbb, GameScene.Instance.curLineID);
                swm.TeamLeaderOperate.AddCurPos(fbb, swm.Vector3.CreateVector3(fbb, op.pos.x, op.pos.y, op.pos.z));
                data[i] = swm.TeamLeaderOperate.EndTeamLeaderOperate(fbb);
            }
            var vec = swm.ForwardTeamLeaderOperate.CreateOperateVector(fbb, data);

            swm.ForwardTeamLeaderOperate.StartForwardTeamLeaderOperate(fbb);
            swm.ForwardTeamLeaderOperate.AddOperate(fbb, vec);
            var msg = swm.ForwardTeamLeaderOperate.EndForwardTeamLeaderOperate(fbb);

            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ForwardTeamLeaderOperate.HashID, fbb);
        }

        /// <summary>
        /// 切换队伍类型
        /// </summary>
        /// <param name="_type"></param>
        public void SendChangeTeamType(swm.TeamType _type)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ChangeTeamType.StartChangeTeamType(fbb);
            swm.ChangeTeamType.AddNewType(fbb, _type);
            var msg = swm.ChangeTeamType.EndChangeTeamType(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ChangeTeamType.HashID, fbb);
        }

        /// <summary>
        /// 切换队员位置
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_newGroupId"></param>
        public void SendChangeMemberPos(ulong _SrcUserId,uint _SrcGroupId, ulong _TarUserId, uint _TarGroupId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ChangeMemberPos.StartChangeMemberPos(fbb);
            swm.ChangeMemberPos.AddSrcUserId(fbb, _SrcUserId);
            swm.ChangeMemberPos.AddSrcGroupId(fbb, _SrcGroupId);
            swm.ChangeMemberPos.AddTarUserId(fbb, _TarUserId);
            swm.ChangeMemberPos.AddTarGroupId(fbb, _TarGroupId);
            var msg = swm.ChangeMemberPos.EndChangeMemberPos(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ChangeMemberPos.HashID, fbb);
        }
        [XLua.BlackList]
        public void SendForwardLeaderAttack(bool isInAttack)
        {
            if(null != TargetSelector.Instance.Selected)
            {
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ForwardLeaderAttack.StartForwardLeaderAttack(fbb);
                swm.ForwardLeaderAttack.AddAttack(fbb, isInAttack);
                swm.ForwardLeaderAttack.AddLockEntityId(fbb, TargetSelector.Instance.Selected.ThisID);
                var msg = swm.ForwardLeaderAttack.EndForwardLeaderAttack(fbb);
                fbb.Finish(msg.Value);
                MsgDispatcher.instance.SendFBPackage(swm.ForwardLeaderAttack.HashID, fbb);
            }
        }
    }
}
