/*using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using XLua;
using Bokura;
namespace Bokura
{

public class TextPic : Text, UnityEngine.ICanvasRaycastFilter, IPointerDownHandler
{
	class FaceTypeRow
	{
		public int id;
		//public string name;
		public int type;
		public string icon;
		public string size;
		public string description;
		public string esc;
	}
    /// <summary>
    /// 图片�?静�?动�?
    /// </summary>
    private readonly List<GameObject> m_ImagesPool = new List<GameObject>();

    /// <summary>
    /// 图片的最后一个顶点的索引
    /// </summary>
    private readonly List<int> m_ImagesVertexIndex = new List<int>();

    /// <summary>
    /// 正则取出所需要的属�?
    /// </summary>
    private static readonly Regex s_Regex = 
        new Regex(@"<quad name=(.+?) size=(\d*\.?\d+%?) width=(\d*\.?\d+%?) isauto=(\d*\.?\d+%?) />", RegexOptions.Singleline);

    public override void SetVerticesDirty()
    {
        base.SetVerticesDirty();
        UpdateQuadImage();
        UpdatehrefText();
    }

    /// <summary>
    /// 解析完最终的文本
    /// </summary>
    private string m_OutputText;
    /// <summary>
    /// 保留原始文本
    /// </summary>
    private string m_OldText;



	// CS0169
	//static LuaFunction ms_loadfun;
	// CS0169
	//static LuaFunction ms_loadallfun;
	// CS0169
	//static LuaTable ms_loader;

	static object Load(string path, Type tp = null)
	{
		
		//GetLoader();
		//ms_loadparams[0] = ms_loader;
		//ms_loadparams[1] = path;
		//ms_loadparams[2] = tp;
		//object[] rtvalues = ms_loadfun.Call(ms_loadparams);
		//return rtvalues[0];
		return Game.GameApplication.Instance.m_ResourceLoader.Load(path, tp);
	}

	static UnityEngine.Object[] LoadAll(string path, Type tp = null)
	{	
		//GetLoader();
		//ms_loadparams[0] = ms_loader;
		//ms_loadparams[1] = path;
		//ms_loadparams[2] = tp;
		//object[] rtvalues = ms_loadallfun.Call(ms_loadparams);
		//return rtvalues[0];
		return Game.GameApplication.Instance.m_ResourceLoader.LoadAll(path, tp);
	}
	static T[] LoadAll<T>(string path) where T : UnityEngine.Object
	{
		var rt = LoadAll(path, typeof(T));// as UnityEngine.Object[];
        if(null == rt)
            return null;
		//string tp = rt.GetType().Name;
		//LogHelper.Log(tp);
		T[] target = new T[rt.Length];
		for(int i = 0; i < rt.Length; i ++ )
		{
			target[i] = rt[i] as T;
		}
		return target;
	}
	static T Load<T>(string path) where T : UnityEngine.Object
	{
		return Load(path, typeof(T)) as T;
	}

	protected override void Awake()
	{
		base.Awake();
	}
	protected void UpdateQuadImage()
    {
#if UNITY_EDITOR
        if (UnityEditor.PrefabUtility.GetPrefabType(this) == UnityEditor.PrefabType.Prefab)
        {
            return;
        }
#endif
        if(string.IsNullOrEmpty(m_Text) )
        {
            m_OldText = null;
        }
        if (m_OldText != null )
        {
            m_Text = m_OldText;
        }
        m_OutputText = GetOutputText();

        m_ImagesVertexIndex.Clear();
        MatchCollection matches = s_Regex.Matches(m_OutputText);
        foreach (Match match in matches)
        {
            var picIndex = match.Index;
            var endIndex = picIndex * 4 + 3;
            m_ImagesVertexIndex.Add(endIndex);

            m_ImagesPool.RemoveAll(GameObject => GameObject == null);

            if (m_ImagesVertexIndex.Count > m_ImagesPool.Count)
            {
                string spriteName = match.Groups[1].Value; 
                var size = float.Parse(match.Groups[2].Value);
                GameObject prefabItem =  Load(spriteName) as GameObject;
                if (prefabItem != null)
                {
                    //动�?
                    GameObject go = GameObject.Instantiate<GameObject>(prefabItem);
                    go.gameObject.SetActive(true);
                    go.transform.SetParent(rectTransform);
                    go.transform.localScale = Vector3.one;
                    go.transform.localPosition = Vector3.zero;
                    m_ImagesPool.Add(go);
                    //var img = m_ImagesPool[m_ImagesVertexIndex.Count - 1];

                    var rt = go.transform as RectTransform;
                    rt.sizeDelta = new Vector2(size, size);
                                      
                }
                else
                {
                    //静�?
                    var resources = new DefaultControls.Resources();
                    var go = DefaultControls.CreateImage(resources);
                    go.layer = gameObject.layer;
                    var rt = go.transform as RectTransform;
                    if (rt)
                    {
                        rt.SetParent(rectTransform);
                        rt.localPosition = Vector3.zero;
                        rt.localRotation = Quaternion.identity;
                        rt.localScale = Vector3.one;
                    }
                    m_ImagesPool.Add(go);

                    var img = m_ImagesPool[m_ImagesVertexIndex.Count - 1].GetComponent<Image>();
                    if (img.sprite == null || img.sprite.name != spriteName)
                    {
                        string[] split = spriteName.Split(':');
                        int len = split.Length;
                        if (len >= 2)
                        {
                            //string pa = split[0];
                            string na = split[1];
                            var imageSp = LoadAll(split[0]);

                            if (imageSp != null)
                            {
                                foreach (var sp in imageSp)
                                {
                                    if (sp !=null &&  sp.name == na)
                                    {
                                        img.sprite = sp as Sprite;
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            img.sprite = Load<Sprite>(spriteName);
                        }


                    }
                    img.rectTransform.sizeDelta = new Vector2(size, size);
                    img.enabled = true;
                }
            }
        }             

        for (var i = m_ImagesVertexIndex.Count; i < m_ImagesPool.Count; i++)
        {
            if (m_ImagesPool[i])
            {
                m_ImagesPool[i].SetActive(false);
            }
        }      
    }
    protected void UpdatehrefText()
    {
        if (m_OutputText == null)
        {
            m_OutputText = "";
        }

        m_Text = m_OutputText;
    }
    protected override void OnPopulateMesh(VertexHelper toFill)
    {

        var orignText = m_Text;
        m_Text = m_OutputText;

        ////空格设置 图标位置 的方�?
        //foreach (Match hrefmatch in s_Regex.Matches(m_Text))
        //{
        //    var hrefgroup = hrefmatch.Groups[0];
        //    var hrefesc = hrefgroup.Value;
        //    String str = hrefgroup.Value;
        //    //var linelen = 4;// System.Text.Encoding.Default.GetByteCount(str);  
        //    //var slen = System.Text.Encoding.Default.GetByteCount("_");
        //    var _len = System.Text.Encoding.Default.GetByteCount("____");
        //    for (var i = 1; i < m_ImagesVertexIndex.Count; i++)
        //    {
        //        var endIndex = m_ImagesVertexIndex[i];                
        //       // var rt = m_ImagesPool[i].transform as RectTransform;
        //        //var size = rt.sizeDelta;
        //        if (hrefmatch.Index * 4 + 3 == endIndex)
        //        {
        //            //获得链接内容字符长度(中文2)
        //            var quadlinelen = System.Text.Encoding.Default.GetByteCount(str);
        //            //var linelen = size.x;
        //            // m_ImagesVertexIndex[i] = m_ImagesVertexIndex[i - 1] + (_len * 4 + 3) * i;//(slen * 4 * 6 + 3) * i;// + (slen * 4 + 3) * i;
        //            m_ImagesVertexIndex[i] = m_ImagesVertexIndex[i] - (quadlinelen * 4 + 3) * i + (_len * 4 + 3) * i;
        //        }
        //    }
        //}
        //foreach (Match hrefmatch in s_Regex.Matches(m_Text))
        //{
        //    var hrefgroup = hrefmatch.Groups[0];
        //    var hrefesc = hrefgroup.Value;
        //    String str = hrefgroup.Value;
        //    var linelen = 4;// System.Text.Encoding.Default.GetByteCount(str); 

        //    var spacelen = "";
        //    for (int x = 0; x < linelen; x++)
        //    {
        //        spacelen += "_";
        //    }
        //    m_Text = m_Text.Replace(hrefesc, spacelen);
        //    var text_len = System.Text.Encoding.Default.GetByteCount(m_Text);
        //    print("text_len=" + text_len);
        //    print(m_Text);
        //}

        base.OnPopulateMesh(toFill);
        m_Text = orignText;

        UIVertex vert = new UIVertex();
        for (var i = 0; i < m_ImagesVertexIndex.Count; i++)
        {
            var endIndex = m_ImagesVertexIndex[i];
            var rt = m_ImagesPool[i].transform as RectTransform; 
            var size = rt.sizeDelta;
            if (endIndex < toFill.currentVertCount)
            {
                toFill.PopulateUIVertex(ref vert, endIndex);
                //print(" 抹掉左下角的小黑�? + endIndex); 
                //print("vert.position.x=" + vert.position.x);
                //print("vert.position.y=" + vert.position.y);
                //print("size.x=" + size.x);
                //print("size.y=" + size.y);
                //print(vert.position.x + size.x / 2);
                // print(vert.position.y + size.y / 2);
                //var posx = Math.Floor(vert.position.x);
                //var posy = Math.Floor(vert.position.y);
                if (vert.position.x != float.NaN && (vert.position.x >= -1000 && vert.position.x <= 1000))
                {
                    rt.anchoredPosition = new Vector2(vert.position.x + size.x / 2, vert.position.y + size.y / 2);
                    //m_ImagesPool[i].SetActive(true);
                }

                // 抹掉左下角的小黑�?
                toFill.PopulateUIVertex(ref vert, endIndex - 3);
                var pos = vert.position;
                for (int j = endIndex, m = endIndex - 3; j > m; j--)
                {
                    toFill.PopulateUIVertex(ref vert, endIndex);
                    //print(toFill);
                    vert.position = pos;
                    //print("抹掉左下角的小黑�?vert.position" + vert.position);
                    toFill.SetUIVertex(vert, j);
                }
       
            }
        }

        //if (m_ImagesVertexIndex.Count != 0)
        //{
        //    m_ImagesVertexIndex.Clear();
        //}

        // 处理超链接包围框
        foreach (var hrefInfo in m_HrefInfos)
        {
            hrefInfo.boxes.Clear();
            if (hrefInfo.startIndex >= toFill.currentVertCount)
            {
                continue;
            }

            // 将超链接里面的文本顶点索引坐标加入到包围�?
            toFill.PopulateUIVertex(ref vert, hrefInfo.startIndex);
            var pos = vert.position;
            var bounds = new Bounds(pos, Vector3.zero);
            for (int i = hrefInfo.startIndex, m = hrefInfo.endIndex; i < m; i++)
            {
                if (i >= toFill.currentVertCount)
                {
                    break;
                }

                toFill.PopulateUIVertex(ref vert, i);
                pos = vert.position;
                if (pos.x < bounds.min.x) // 换行重新添加包围�?
                {
                    hrefInfo.boxes.Add(new Rect(bounds.min, bounds.size));
                    bounds = new Bounds(pos, Vector3.zero);
                }
                else
                {
                    bounds.Encapsulate(pos); // 扩展包围�?
                }
            }
            hrefInfo.boxes.Add(new Rect(bounds.min, bounds.size));
        }
    }

    /// <summary>
    /// 超链接信息列�?
    /// </summary>
    private readonly List<HrefInfo> m_HrefInfos = new List<HrefInfo>(2);

    /// <summary>
    /// 文本构造器
    /// </summary>
    private static readonly StringBuilder s_TextBuilder = new StringBuilder();

    /// <summary>
    /// 超链接正�?
    /// </summary>
    private static readonly Regex s_HrefRegex = 
        new Regex(@"<a href=(.+?)>(.*?)(</a>)", RegexOptions.Singleline);
    
    //自定义表�?
    private static readonly Regex s_FaceRegex =
      new Regex(@"#(\d{3})", RegexOptions.Singleline);

	static FaceTypeRow[] s_FaceType;

	static FaceTypeRow[] GetFaceType()
	{
		if (s_FaceType == null)
		{
			var pRoot = Game.GameApplication.Instance;
			LuaTable facetable = LuaFunctor.DoString("require 'common/gdd/face_type.lua'")[0] as LuaTable;

			s_FaceType = new FaceTypeRow[facetable.Length];
			//表情�?
			for (int i = 1; i <= facetable.Length; i++)
			{
				var facerow = new FaceTypeRow();
				s_FaceType[i - 1] = facerow;
				var tablerow = facetable.Get<int, LuaTable>(i);
				facerow.esc = tablerow.Get<string,string>("esc");
				facerow.description = tablerow.Get<string,string>("description");
				facerow.icon = tablerow.Get<string, string>("icon") ;
				facerow.id = Convert.ToInt32(tablerow.Get<string, string>("id"));
				facerow.size = tablerow.Get<string, string>("size") as string;
				facerow.type = Convert.ToInt32(tablerow.Get<string, string>("type"));

			}
		}
		return s_FaceType;
	}

    public class HrefClickEvent : GameEvent<string> { }
  
    private HrefClickEvent m_OnHrefClick = new HrefClickEvent();

    /// <summary>
    /// 超链接点击事�?
    /// </summary>
    public HrefClickEvent onHrefClick
    {
        get { return m_OnHrefClick; }
        set { m_OnHrefClick = value; }
    }

    /// <summary>
    /// 获取超链接解析后的最后输出文�?
    /// </summary>
    /// <returns></returns>
    protected string GetOutputText()
    {        
        foreach (Match facematch in s_FaceRegex.Matches(text))
        {
            var facegroup = facematch.Groups[0];
            var faceesc = facegroup.Value;
            var strface = "<quad name=Texture/chatUI/arrow size=10 width=1 isauto=0 />";

            var pRoot = Game.GameApplication.Instance;
           
			var faces = GetFaceType();
			if (faces!=null)
			{
				for (int i = 0; i < faces.Length; i++)
				{
					//var stresc = (faces[i] as LuaTable)["esc"] as string;
					if (faces[i].esc == faceesc)
					{
						//var iconesc = (s_facetype[i] as LuaTable)["icon"] as string;
						//var sizeesc = (s_facetype[i] as LuaTable)["size"] as string;
						strface = Bokura.Utilities.BuildString("<quad name=", faces[i].icon, " size=", faces[i].size, " width=1 isauto=0 />");
					}
				}
			}
                
            //print("strface=" + strface);
            text = text.Replace(faceesc, strface);
        }
    
        MatchCollection matches = s_Regex.Matches(text);
        foreach (Match imgmatch in matches)
        {
            var imggroup = imgmatch.Groups[0];
            var imgesc = imggroup.Value;
            var strimg = "";

            var spriteName = imgmatch.Groups[1].Value;
            var size = float.Parse(imgmatch.Groups[2].Value);
            var auto = int.Parse(imgmatch.Groups[4].Value);
            var fontsize = this.fontSize;

            if (auto == 1)
            {
                //取字体大�?设置图标的大�?
                strimg = Bokura.Utilities.BuildString("<quad name=", spriteName, " size=", fontsize.ToString(), " width=1", " isauto=", auto.ToString(), " />");
            }
            else
            {
                strimg = Bokura.Utilities.BuildString("<quad name=", spriteName, " size=", size.ToString(), " width=1", " isauto=", auto.ToString(), " />");
            }
            text = text.Replace(imgesc, strimg);
        }
        s_TextBuilder.Length = 0;
        m_HrefInfos.Clear();
        var indexText = 0;
        foreach (Match match in s_HrefRegex.Matches(text))
        {
            s_TextBuilder.Append(text.Substring(indexText, match.Index - indexText));

            s_TextBuilder.Append("<color=#ead097>[");  // 超链接颜�?
        
            var group = match.Groups[1];
            var hrefInfo = new HrefInfo
            {
                startIndex = s_TextBuilder.Length * 4, // 超链接里的文本起始顶点索�?
                endIndex = (s_TextBuilder.Length + match.Groups[2].Length - 1) * 4 + 3,
                name = group.Value
            };

            m_HrefInfos.Add(hrefInfo);

            s_TextBuilder.Append(match.Groups[2].Value);
          
            s_TextBuilder.Append("]</color>");
            
            indexText = match.Index + match.Length;

            m_OldText = text;

          
        }
        s_TextBuilder.Append(text.Substring(indexText, text.Length - indexText));      

        return s_TextBuilder.ToString();
    }

    /// <summary>
    /// 点击事件检测是否点击到超链接文�?
    /// </summary>
    /// <param name="eventData"></param>
    void IPointerDownHandler.OnPointerDown(PointerEventData eventData)
    {
        Vector2 lp;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            rectTransform, eventData.position, eventData.pressEventCamera, out lp);

        foreach (var hrefInfo in m_HrefInfos)
        {
            var boxes = hrefInfo.boxes;
            for (var i = 0; i < boxes.Count; ++i)
            {
                if (boxes[i].Contains(lp))
                {
                    m_OnHrefClick.Invoke(hrefInfo.name);
                    return;
                }
            }
        }
    }

    public bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera)
    {
        // 点击在箭头框内部则无效，否则生效
       // LogHelper.Log("IsRaycastLocationValid");
        Vector2 lp;
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(rectTransform, sp, eventCamera, out lp))
        {
            //LogHelper.Log("RectangleContainsScreenPoint");

            foreach (var hrefInfo in m_HrefInfos)
            {
                var boxes = hrefInfo.boxes;
                for (var i = 0; i < boxes.Count; ++i)
                {
                    if (boxes[i].Contains(lp))
                    {
                        //LogHelper.Log("return true");
                        return true;
                    }
                }
            }
        }
        return false;        
    }
/// <summary>
/// 超链接信息类
/// </summary>
private class HrefInfo
    {
        public int startIndex;

        public int endIndex;

        public string name;

        public readonly List<Rect> boxes = new List<Rect>();
    }
}
}
*/