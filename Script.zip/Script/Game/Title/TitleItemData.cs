using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public class TitleItemData
    {
        public uint[] idVec;
        public string outOfBand;
        public ulong endTime;
    }

    public class SingleTitleItemData
    {
        public uint titleid;
        public string outOfBand;
        public ulong endTime;
    }

    public class TitleItemCfgData
    {
        public int id;
        public string name;
        public int type;
        public string img_bg;
        public string txt_color;
        public string des;
    }

}
