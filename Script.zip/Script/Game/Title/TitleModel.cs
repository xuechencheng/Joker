using swm;
using System.Collections.Generic;
using Bokura;
using FlatBuffers;
namespace Bokura
{

    class TitleModel : ClientSingleton<TitleModel>
    {
        public TitleDataEvent onTitleDataChange = new TitleDataEvent();
        public TitleDataChangeEvent onTitleUseChange = new TitleDataChangeEvent();
        Dictionary<uint, TitleItemCfgData> cfgCache = new Dictionary<uint, TitleItemCfgData>();

        public class TitleDataEvent : GameEvent<SingleTitleItemData[], TitleItemData>
        {
            
        }

        public class TitleDataChangeEvent : GameEvent<TitleItemData>
        {

        }


        //private Dictionary<uint, SingleTitleItemData> m_titleItemDataList = new Dictionary<uint, SingleTitleItemData>();

        //private TitleItemData m_curTitleItemData = new TitleItemData();

        
        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RetAllTitleData>(ProcTitleData);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RetCurTitle>(ProcRetTitleData);
        }

        public void Clear()
        {
            //m_titleItemDataList.Clear();
        }

        //public void GM_ProcTitleData(uint titleid)
        //{
        //    if (!m_titleItemDataList.ContainsKey(titleid))
        //    {
        //        SingleTitleItemData tdTem = new SingleTitleItemData();
        //        tdTem.outOfBand = "";
        //        tdTem.endTime = 0;
        //        tdTem.titleid = titleid;

        //        m_titleItemDataList.Add(titleid, tdTem);
        //    }

        //    //onTitleDataChange.Invoke(m_titleItemDataList, m_curTitleItemData);
        //}

        public void ProcTitleData(swm.RetAllTitleData data)
        {
            SingleTitleItemData[] tmds = new SingleTitleItemData[data.alltitlesLength];
            TitleItemData tmd = new TitleItemData();
            TitleData td = (TitleData)data.curtitle;
            
            for (int i = 0; i < tmds.Length; i++)
            {
                tmds[i] = new SingleTitleItemData();
                SingleTitleData tdTem = (SingleTitleData)data.alltitles(i);
                tmds[i].outOfBand = tdTem.out_of_band;
                tmds[i].endTime = tdTem.endtime;
                tmds[i].titleid = tdTem.titleid;
            }
            
            tmd.endTime = td.endtime;
            tmd.outOfBand = td.out_of_band;
            tmd.idVec = new uint[td.idvecLength];
            for (int i = 0; i < tmd.idVec.Length; i++)
            {
                tmd.idVec[i] = td.idvec(i);
            }
            onTitleDataChange.Invoke(tmds, tmd);
        }

        void ProcRetTitleData(swm.RetCurTitle data)
        {
            //修改成功
            TitleItemData tid = new TitleItemData();
            if (data.curtitle.Value.idvecLength > 0)
            {
                tid.idVec = new uint[data.curtitle.Value.idvecLength];
                for (int i = 0; i < tid.idVec.Length; i++)
                {
                    tid.idVec[i] = data.curtitle.Value.idvec(i);
                }

                tid.outOfBand = data.curtitle.Value.out_of_band;
                tid.endTime = data.curtitle.Value.endtime;
            }

            GameScene.m_instance.MainChar.OnTitleNameChange(tid.idVec);
            onTitleUseChange.Invoke(tid);
        }

        /// <summary>
        /// 请求title数据
        /// </summary>
        public void ReqTitleData()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            ReqAllTitleData.StartReqAllTitleData(fbb);
            var msg = ReqAllTitleData.EndReqAllTitleData(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqAllTitleData.HashID, fbb);
        }

        public void ReqChangeTitleData(string ids)
        {
            List<uint> idl = new List<uint>();
            if (!string.IsNullOrEmpty(ids))
            {
                string[] ss = ids.Split('.');
                for (int i = 0; i < ss.Length; i++)
                {
                    if (!string.IsNullOrEmpty(ss[i]))
                    {
                        idl.Add(uint.Parse(ss[i]));
                    }
                }
            }

            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            uint[] idvec = idl.ToArray();
            VectorOffset idVector = TitleData.CreateIdvecVector(fbb, idvec);
            Offset<TitleData> vo = swm.TitleData.CreateTitleData(fbb, idVector);
            FlatBuffers.Offset<ReqChangeCurTitle> offset = ReqChangeCurTitle.CreateReqChangeCurTitle(fbb, vo);
            fbb.Finish(offset.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqChangeCurTitle.HashID, fbb);
        }

        public TitleItemCfgData GetTiltleCfgItem(uint id)
        {
            TitleTableBase?  ttb = TitleTableManager.GetData((int)id);
            if (cfgCache.ContainsKey(id))
            {
                return cfgCache[id];
            }

            if (ttb != null)
            {
                TitleItemCfgData td = new  TitleItemCfgData()
                {
                    id = ttb.Value.id,
                    name = ttb.Value.name,
                    type = ttb.Value.type,
                    txt_color = ttb.Value.textcolor,
                    img_bg = ttb.Value.bgimg,
                    des = ttb.Value.des
                };

                cfgCache[id] = td; 
                return td;
            }

            return null;
        }
    }

}
