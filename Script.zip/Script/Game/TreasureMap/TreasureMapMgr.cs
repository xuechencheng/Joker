using UnityEngine;

using System.Collections.Generic;

using Bokura;

namespace Bokura
{
    public class TreasureMapMgr : ClientSingleton<TreasureMapMgr>
    {
        #region ClientSingleton
        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspTreasureMapOperate>(OnRspTreasureMapOperate);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspTreasureMapClientNpcID>(SetFollowNPCid);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspTreasureMapInfo>(OnRspTreasureMapInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyDecryptResult>(OnNotifyDecryptResult);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspActiveTreasureMap>(OnRspActiveTreasureMap);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyRemoveTreasureMap>(OnNotifyRemoveTreasureMap);

            //MissionModel.Instance.onStartAutoDoTask.AddListener(OnAutoMissionStart);
            MissionModel.Instance.onCompletedTask.AddListener(OnMissionFinish);

            WeatherManager.Instance.OnWeatherChangeEvent.AddListener(OnWeatherChange);
            WeatherManager.Instance.OnTimeStateChange.AddListener(OnTimeChange);

            var gameScene = GameScene.Instance;
            gameScene.onMainCharCreated.AddListener(FirstReqTreasureMapInfo);
            gameScene.onMainCharAdd.AddListener(RegisterMainCharListener);
            gameScene.onChantEndEvent.AddListener(OnGatherEnd);
            gameScene.onChantEvent2.AddListener(OnGatherStart);
            gameScene.OnSendReqGatherResource.AddListener(OnReqGather);
            gameScene.OnBlinkFinishEvent.AddListener(OnBlinkFinish);
        }

        private bool m_MainCharAdded = false;
        private void RegisterMainCharListener()
        {
            GameScene.Instance.MainChar.onMoveEvent.AddListener(DoMoveUpdate);
            GameScene.Instance.MainChar.MoveStart.AddListener(OnStartMove);
            GameScene.Instance.MainChar.OnMoveStopEvent.AddListener(OnStopMove);

            GameScene.Instance.MainChar.OnQingKungEnter.AddListener(OnQingkunStart);
            GameScene.Instance.MainChar.OnQingKungLeave.AddListener(OnQingkunStop);

            m_MainCharAdded = true;

            MaxSpeed = 0.15f;

            OnMapInfoChangedRefreshData();
        }

        [XLua.BlackList]
        public void Clear()
        {
            OnCleanData();
        }

        [XLua.BlackList]
        public void Update()
        {
            UpdateNPC();
        }
        #endregion

        #region Weather Influence
        private swm.Weather m_WeatherType;

        private void OnWeatherChange(int weatherType)
        {
            m_WeatherType = (swm.Weather)weatherType;

            DoCheckVisiblility();
        }
        #endregion

        #region Time Influence
        swm.TimeState m_TimeState;

        private void OnTimeChange(int timeState)
        {
            m_TimeState = (swm.TimeState)timeState;

            DoCheckVisiblility();
        }
        #endregion

        #region Distance influence
        public enum AreaType
        {
            Area1 = 0,                  // 距离宝藏12米以内
            Area2,                  // 距离宝藏30米至12米
            Area3,                  // 距离宝藏50米至30米
            Area4,                  // 距离宝藏70米至50米
            Area5,                  // 距离宝藏90米至70米

            OutsideOfNineScreen,


            Count,
        }

        private bool CheckDistance(GatherResourceEntity treasure, out AreaType nextAreaType, out float disSqr)
        {
            nextAreaType = AreaType.OutsideOfNineScreen;
            disSqr = float.PositiveInfinity;

            if (treasure == null)
            {
                return false;
            }

            var mainChar = GameScene.Instance.MainChar;
            var mainCharTransform = mainChar.Avatar.unityObject.transform;
            if (treasure.Avatar.unityObject == null)
            {
                return false;
            }

            var treasureTransform = treasure.Avatar.unityObject.transform;
            var offset = treasureTransform.position - mainCharTransform.position;

            disSqr = offset.sqrMagnitude;
            if (disSqr <= 144)
            {
                nextAreaType = AreaType.Area1;
            }
            else if (disSqr > 144 && disSqr <= 900)
            {
                nextAreaType = AreaType.Area2;
            }
            else if (disSqr > 900 && disSqr <= 2500)
            {
                nextAreaType = AreaType.Area3;
            }
            else if (disSqr > 2500 && disSqr <= 4900)
            {
                nextAreaType = AreaType.Area4;
            }
            else if (disSqr > 4900 && disSqr <= 8100)
            {
                nextAreaType = AreaType.Area5;
            }
            else
            {
                nextAreaType = AreaType.OutsideOfNineScreen;
            }

            return (nextAreaType == AreaType.Area1);
        }

        private void DoMoveUpdate()
        {
            DoCheckVisiblility();
        }      

        private void OnStopMove()
        {
            var entity = GameScene.Instance.GetEntityByID(m_FollowerId);
            if (entity == null) return;

            entity.CrossFadeAll(AnimatorStateID.Stand);
        }
        private void OnStartMove()
        {
            var entity = GameScene.Instance.GetEntityByID(m_FollowerId);
            if (entity == null) return;

            entity.CrossFadeAll(AnimatorStateID.FuZhongFly);
        }
        #endregion

        #region Treasure State

        

        #region -----------------新藏宝阁逻辑;

        public class SingleMapInfo
        {
            public uint mapid;
            public uint taskid;
            public uint resid;

            public List<uint> decrypt_sort = new List<uint>(0);

            public bool isopen;

            public bool red_dots;

            public ulong resThisID;//九屏内本资源的唯一ID;

            public ResourceTableBase? resourceTableBase;//资源配置表数据;
            public TreasureMapTableBase? treasureMapTableBase;//藏宝图配置表数据;

            public bool IsWeatherOK(int currWeatherType)
            {
                int weatherlen = resourceTableBase.Value.weather_limitLength;
                if (weatherlen == 0)
                {
                    return true;
                }
                else
                {
                    for (int i = 0; i < weatherlen; i++)
                    {
                        var type = resourceTableBase.Value.weather_limit(i);
                        if (type == currWeatherType)
                        {
                            return true;
                        }
                    }
                }

                return false;
            }

            public bool IsTimeOK(int timeState)
            {
                int timelen = resourceTableBase.Value.time_limitLength;
                if (timelen == 0)
                {
                    return true;
                }
                else
                {
                    for (int i = 0; i < timelen; i++)
                    {
                        var type = resourceTableBase.Value.time_limit(i);
                        if (type == timeState)
                        {
                            return true;
                        }
                    }
                }

                return true;
            }

            public AreaType nextAreaType = AreaType.OutsideOfNineScreen;
            public AreaType currAreaType = AreaType.OutsideOfNineScreen;

            public float currDisSqr = 0;
        }

        private List<SingleMapInfo> m_mapInfoList = new List<SingleMapInfo>(0);
        public List<SingleMapInfo> MapInfoList { get { return m_mapInfoList; } }

        private uint m_currMapId = 0;
        public uint CurrMapId { get { return m_currMapId; } }

        private uint m_currFindMapId = 0;//藏宝图表ID;

        private SingleMapInfo m_currInRangeSingleMapInfo = null;

        public GameEvent OnMapInfoChanged = new GameEvent();

        private SingleMapInfo NewOneSingleMapInfo(swm.PersonalMapInfo mapInfo)
        {
            SingleMapInfo info = new SingleMapInfo();
            info.mapid = mapInfo.mapid;
            info.taskid = mapInfo.taskid;
            info.resid = mapInfo.resid;

            info.decrypt_sort.Clear();

            if (mapInfo.decrypt_sortLength > 0)
            {
                for (int i = 0; i < mapInfo.decrypt_sortLength; ++i)
                {
                    info.decrypt_sort.Add(mapInfo.decrypt_sort(i));
                }
            }

            info.isopen = mapInfo.isopen;

            info.red_dots = mapInfo.red_dots;


            info.resourceTableBase = ResourceTableManager.GetData((int)mapInfo.resid);
            info.treasureMapTableBase = TreasureMapTableManager.GetData((int)mapInfo.mapid);

            return info;
        }

        public GameEvent<uint> OnNewTreasureAddEvent = new GameEvent<uint>();

        public SingleMapInfo GetCurrMapInfo()
        {
            for (int i = 0, len = m_mapInfoList.Count; i < len; ++i)
            {
                if (m_currMapId == m_mapInfoList[i].mapid)
                {
                    return m_mapInfoList[i];
                }
            }

            return null;
        }

        //// 藏宝图操作;
        private void OnRspTreasureMapOperate(swm.RspTreasureMapOperate msg)
        {
            if (msg.isnew)
            {
                if (msg.mapinfo.Value.mapid != 0)
                {
                    m_mapInfoList.Add(NewOneSingleMapInfo(msg.mapinfo.Value));

                    FilterAllEntities();

                    OnNewTreasureAddEvent.Invoke(msg.mapinfo.Value.mapid);
                }
            }
            else
            {
                for (int i = 0, len = m_mapInfoList.Count; i < len; ++i)
                {
                    if (msg.mapinfo.Value.mapid == m_mapInfoList[i].mapid)
                    {
                        m_mapInfoList[i] = NewOneSingleMapInfo(msg.mapinfo.Value);
                        FilterAllEntities();
                        break;
                    }

                }
            }

            OnMapInfoChanged.Invoke();
        }

        // 移除mapid;
        private void OnNotifyRemoveTreasureMap(swm.NotifyRemoveTreasureMap msg)
        {
            for (int i = 0, len = m_mapInfoList.Count; i < len; ++i)
            {
                if (msg.mapid == m_mapInfoList[i].mapid)
                {
                    if (msg.mapid == m_currMapId)
                    {
                        m_currMapId = 0;
                    }

                    m_mapInfoList.RemoveAt(i);
                    break;
                }
            }

            OnMapInfoChanged.Invoke();
        }

        ////请求当前藏宝图列表;
        public void ReqTreasureMapInfo()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqTreasureMapInfo.StartReqTreasureMapInfo(fbb);
            var msg = swm.ReqTreasureMapInfo.EndReqTreasureMapInfo(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqTreasureMapInfo.HashID, fbb);
        }

        private void FirstReqTreasureMapInfo()
        {
            ReqTreasureMapInfo();

            if (m_FollowerId == 0)
            {
                ReqFollowerId();
            }
        }

        //// 返回当前藏宝图列表;
        private void OnRspTreasureMapInfo(swm.RspTreasureMapInfo msg)
        {
            int len = msg.mapinfoLength;

            m_mapInfoList.Clear();

            for (int i = 0; i < len; ++i)
            {
                m_mapInfoList.Add(NewOneSingleMapInfo(msg.mapinfo(i).Value));
            }

            FilterAllEntities();

            m_currMapId = msg.mapid;

            OnMapInfoChanged.Invoke();

            OnMapInfoChangedRefreshData();
        }

        //// 请求消除红点;
        //table ReqEliminteRedDotTreasureMap
        //{
        //    mapid:uint32; // 需要移除的mapid 0 : 移除全部红点
        //}

        public void ReqEliminteRedDotTreasureMap(uint mapId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqEliminteRedDotTreasureMap.StartReqEliminteRedDotTreasureMap(fbb);
            swm.ReqEliminteRedDotTreasureMap.AddMapid(fbb, mapId);
            fbb.Finish(swm.ReqEliminteRedDotTreasureMap.EndReqEliminteRedDotTreasureMap(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqEliminteRedDotTreasureMap.HashID, fbb);
        }

        //// 请求激活藏宝图;
        //table ReqActiveTreasureMap
        //{
        //    mapid:uint32;   // 指定激活藏宝图id 0 : 表示取消激活
        //}
        public void ReqActiveTreasureMap(uint mapId)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqActiveTreasureMap.StartReqActiveTreasureMap(fbb);
            swm.ReqActiveTreasureMap.AddMapid(fbb, mapId);
            fbb.Finish(swm.ReqActiveTreasureMap.EndReqActiveTreasureMap(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqActiveTreasureMap.HashID, fbb);
        }

        //// 返回激活藏宝图;
        //table RspActiveTreasureMap
        //{
        //    mapid:uint32; //   当前激活的藏宝图id
        //}
        private void OnRspActiveTreasureMap(swm.RspActiveTreasureMap msg)
        {
            m_currMapId = msg.mapid;

            OnMapInfoChanged.Invoke();

            OnMapInfoChangedRefreshData();
        }

        public TreasureMapTableBase GetTreasureMapById(int id)
        {
            TreasureMapTableBase? b =  TreasureMapTableManager.GetData(id);

            if (b != null)
            {
                return b.Value;
            }

            return default(TreasureMapTableBase);
        }
        public bool isHaveTreasureMapById(int id)
        {
            TreasureMapTableBase? b = TreasureMapTableManager.GetData(id);

            if (b != null)
            {
                return true;
            }

            return false;
        }

        public List<uint> GetPasscodeById(int id)
        {
            for (int i = 0, len = m_mapInfoList.Count; i < len; ++i)
            {
                if (id == m_mapInfoList[i].mapid)
                {
                    return m_mapInfoList[i].decrypt_sort;
                }

            }

            return null;
        }


        private void OnCleanData()
        {
            OnResetData();

            m_MainCharAdded = false;
        }
        private void OnResetData()
        {
            m_CurType = MoveType.FollowPlayer;
            m_CurEffectType = -1;
            m_NextEffectType = -1;

            m_IsActivated = false;
            //m_PauseRandom = false;

            if (m_CurEffect != null)
            {
                m_CurEffect.Visible = false;
            }
        }

        private void OnInitData()
        {
            if (m_MainCharAdded)
            {
                if (m_currMapId != 0)
                {
                    SingleMapInfo data = GetCurrMapInfo();

                    if (data != null)
                    {
                        if (m_currFindMapId != 0 && m_currFindMapId != data.mapid)
                        {
                            m_CurType = MoveType.FollowPlayer;

                            m_currFindMapId = data.mapid;
                        }

                        if (m_FollowerId == 0)
                        {
                            ReqFollowerId();
                        }
                    }
                }
            }
        }

        private void OnMapInfoChangedRefreshData()
        {
            if (m_MainCharAdded)
            {
                FilterAllEntities();

                if (m_currMapId != 0)
                {
                    OnInitData();

                    OnAutoMissionStart();
                }
                else
                {
                    OnResetData();

                    OnAutoMissionStart();
                }
            }
        }
        #endregion -----------------新藏宝阁逻辑;

        private void FilterAllEntities()
        {
            var allEntities = GameScene.Instance.AllEntitys;

            foreach (var item in allEntities)
            {
                if (item.Value is GatherResourceEntity)
                {
                    var entity = item.Value as GatherResourceEntity;
                    tryFilterEntity(entity);
                }
            }

            DoCheckVisiblility();
        }
        [XLua.BlackList]
        public void FilterEntity(GatherResourceEntity treasure)
        {
            tryFilterEntity(treasure);
        }
        private void tryFilterEntity(GatherResourceEntity treasure)
        {
            if (treasure == null || !IsTreasure(treasure)) return;

            if (treasure.Avatar.unityObject == null)
            {
                treasure.Avatar.onCreate.AddListener(() =>
                {
                    SetTreasureVisible(treasure, false);

                    DoCheckVisiblility();
                });
            }
            else
            {
                SetTreasureVisible(treasure, false);
            }

            for (int i = 0, len = m_mapInfoList.Count; i < len; ++i)
            {
                if (treasure.BaseID == m_mapInfoList[i].resid)
                {
                    m_mapInfoList[i].resThisID = treasure.ThisID;
                    break;
                }
            }



            DoCheckVisiblility();
        }

        private void SetTreasureVisible(Entity treasure, bool isOn)
        {
            if (treasure == null) return;

            if (treasure.ActuallyVisible != isOn)
            {
                treasure.VisibleByTreasure = isOn;
                treasure.OnChangeResourceState.Invoke(treasure);
            }
        }

        private bool IsTreasure(GatherResourceEntity entity)
        {
            var baseId = entity.BaseID;

            var KeyToIdList = TreasureMapTableManager.Instance.KeyToIdList;
            foreach (var item in KeyToIdList)
            {
                var data = TreasureMapTableManager.GetData((int)item.Key).Value;
                var listlen = data.mission_listLength;
                for (int i = 0; i < listlen; i++)
                {
                    var list = data.mission_list(i);
                    var _baseId = list.Value.list(1);
                    if (_baseId == baseId)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private void OnNotifyDecryptResult(swm.NotifyDecryptResult msg)
        {
            bool isDecryptOK = msg.result;

            if (isDecryptOK)
            {
                ForceNPCTalk("解谜成功！");
            }
            else
            {
                ForceNPCTalk("解谜失败，重新开始解谜！");
            }

            DoCheckVisiblility();
        }

        /// <summary>
        /// 执行一次可见性检测;
        /// </summary>
        public void DoCheckVisiblility()
        {
            if (m_currMapId != 0)
            {
                m_currInRangeSingleMapInfo = GetCurrMapInfo();

                if (m_currInRangeSingleMapInfo != null)
                {
                    Entity treasure = GameScene.Instance.GetEntityByID(m_currInRangeSingleMapInfo.resThisID);// as GatherResourceEntity;

                    if (treasure != null)
                    {
                        bool isOpen, isDisOK, isTimeOK, isWeatherOK, isOn;

                        isOpen = m_currInRangeSingleMapInfo.isopen;

                        isDisOK = CheckDistance((treasure as GatherResourceEntity), out m_currInRangeSingleMapInfo.currAreaType, out m_currInRangeSingleMapInfo.currDisSqr);
                        isTimeOK = m_currInRangeSingleMapInfo.IsTimeOK((int)m_TimeState);
                        isWeatherOK = m_currInRangeSingleMapInfo.IsWeatherOK((int)m_WeatherType);

                        isOn = (m_IsActivated && isOpen && isDisOK && isTimeOK && isWeatherOK);

                        SetTreasureVisible(treasure, isOn);
                    }
                }
            }

            TryUpdateNPCPos();
        }

        #endregion

        #region NPC
        private ulong m_FollowerId = 0;
        private bool m_IsActivated = false;

        public ulong GetFollowerId()
        {
            return m_FollowerId;
        }

        private void ReqFollowerId()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqTreasureMapClientNpcID.StartReqTreasureMapClientNpcID(fbb);
            var msg = swm.ReqTreasureMapClientNpcID.EndReqTreasureMapClientNpcID(fbb);
            fbb.Finish(msg.Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqTreasureMapClientNpcID.HashID, fbb);
        }
        private void SetFollowNPCid(swm.RspTreasureMapClientNpcID msg)
        {
            m_FollowerId = msg.uid;
        }

        private void OnAutoMissionStart()
        {
            if (m_currMapId != 0)
            {
                m_IsActivated = true;
                ShowNPC();

                DoCheckVisiblility();
            }
            else
            {
                HideNPC();
                m_IsActivated = false;
            }
        }
        private void OnMissionFinish(MissionInfoData data)
        {
            var mapInfo = GetCurrMapInfo();

            if (mapInfo != null)
            {
                if (data.MissionId == mapInfo.taskid)
                {
                    HideNPC();

                    OnResetData();
                }
            }
            else
            {
                HideNPC();
                OnResetData();
            }
        }

        private void OnMissionFinishDo()
        {
            tryRemoveFinishTimer();

            var entity = GameScene.Instance.GetEntityByID(m_FollowerId);
            if (entity != null)
            {
                entity.CrossFadeAll(AnimatorStateID.Dead);

                m_finishTimerCache = GameApplication.Instance.m_TimerManager.AddTimer(() =>
                {

                    var entity1 = GameScene.Instance.GetEntityByID(m_FollowerId);
                    if (entity1 != null)
                    {
                        entity1.CrossFadeAll(AnimatorStateID.Stand);
                    }

                    HideNPC();

                    OnResetData();
                }, 2.5f);
            }
            else
            {
                HideNPC();
                OnResetData();
            }
        }

        private void OnQingkunStart()
        {
            if (m_IsActivated == false) return;

            HideNPC();
        }
        private void OnQingkunStop()
        {
            if (m_IsActivated == false) return;

            ShowNPC();
        }
        private void OnBlinkFinish()
        {
            if (m_IsActivated == false) return;

            var mainCharTransform = GameScene.Instance.MainChar.Avatar.unityObject.transform;

            var follower = GameScene.Instance.GetEntityByID(m_FollowerId);
            var entityTransform = follower.Avatar.unityObject.transform;
            m_Offset = mainCharTransform.right;// +  height;
            entityTransform.position = m_Offset + mainCharTransform.position;
            entityTransform.rotation = mainCharTransform.rotation;
            follower.onPositionChangeEvent.Invoke();

            m_CurType = MoveType.FollowPlayer;
        }

        private void ShowNPC()
        {
            isSearching = false;

            var mainChar = GameScene.Instance.MainChar;
            m_LastDir = mainChar.Direction;

            var entity = GameScene.Instance.GetEntityByID(m_FollowerId);

            if (entity == null)
            {
                m_Offset = mainChar.Avatar.unityObject.transform.right;// +  height;
                Vector3 pos = m_Offset + mainChar.Avatar.unityObject.transform.position;
                entity = GameScene.Instance.CreateClientNpcSync(m_FollowerId, 50, pos, Quaternion.identity);
                EffectMgr.Instance.Play("fx_spirit_xunbao_s", entity, AvatarAttachment.Root, null, false);
            }
            else
            {
                entity.CrossFadeAll(AnimatorStateID.Stand);
            }

            InitEffects(entity);
            entity.Visible = true;
            entity.Avatar.unityObject.SetActive(true);

            m_CurType = MoveType.FollowPlayer;
            OnShowNPC();
        }
        private void HideNPC()
        {
            var entity = GameScene.Instance.GetEntityByID(m_FollowerId);
            if (entity == null) return;

            entity.Visible = false;
            entity.Avatar.unityObject.SetActive(false);
        }
        private void OnShowNPC()
        {
            var mainChar = GameScene.Instance.MainChar;
            var follower = GameScene.Instance.GetEntityByID(m_FollowerId);
            var curDir = mainChar.Direction;

            follower.Avatar.unityObject.transform.position = mainChar.Avatar.unityObject.transform.position + m_Offset;
            follower.Direction = curDir;
            follower.onPositionChangeEvent.Invoke();
        }

        private uint m_targetBaseId = 0;
        private void OnReqGather(ulong _id)
        {
            if (m_IsActivated == false) return;

            Entity ety = GameScene.Instance.GetEntityByID(_id);

            if (ety != null)
            {
                m_targetBaseId = ety.BaseID;
            }
            else
            {
                m_targetBaseId = 0;
            }
        }
        private void OnGatherEnd(bool isOK)
        {
            if (m_IsActivated == false) return;

            var follower = GameScene.Instance.GetEntityByID(m_FollowerId);

            if (follower != null)
            {
                bool isRight = false;

                var mapInfo = GetCurrMapInfo();

                if (mapInfo != null)
                {
                    if (m_targetBaseId == mapInfo.resid)
                    {
                        isRight = true;
                    }
                }

                if (isOK && isRight)
                {
                    follower.Visible = false;
                }
                else
                {
                    m_CurType = MoveType.ToPlayer;
                    follower.Avatar.unityObject.transform.rotation = GameScene.Instance.MainChar.Avatar.unityObject.transform.rotation;
                }
            }
        }
        private void OnGatherStart(swm.NotifyEnterChant data)
        {
 
        }

        [XLua.BlackList]
        public void UpdateNPC()
        {
            if (m_MainCharAdded == false) return;

            if (isSearching) return;

            if (m_currMapId != 0)
            {
                if (m_FollowerId != 0)
                {
                    var entity = GameScene.Instance.GetEntityByID(m_FollowerId);
                    if (entity == null)
                    {
                        m_searchEffect = null;

                        ShowNPC();
                    }
                }

                var mainChar = GameScene.Instance.MainChar;
                var curDir = mainChar.Direction;
                float angle = Vector3.Angle(m_LastDir, curDir);
                Vector3 normal = Vector3.Cross(m_LastDir, curDir);
                angle *= Mathf.Sign(Vector3.Dot(normal, Vector3.up));
                m_LastDir = curDir;

                if (angle != 0)
                {
                    var rot = Quaternion.AngleAxis(angle, Vector3.up);
                    m_Offset = rot * m_Offset;
                }

                if (m_IsActivated == false) return;

                UpdateNPCPosition();
                //UpdateTalk();
                UpdateEffect();
            }
        }
        #endregion

        #region NPC Position
        private Vector3 m_LastDir;
        private Vector3 m_Offset;
        private Vector3 height = Vector3.up * 1.2f;

        private enum MoveType
        {
            None,
            FollowPlayer,
            OnTreasure,
            ToTreasure,
            ToPlayer,
        }
        private MoveType m_CurType;

        private float MaxSpeed = 0;
        private float speed = 0f;
        private float accelerate = 0.008f;

        private bool DoUpdateNPCPos
        {
            get { return m_FollowerId == 0 ? false : true; }
        }

        private void UpdateNPCPosition()
        {
            if (!DoUpdateNPCPos) return;

            var mainChar = GameScene.Instance.MainChar;
            Vector3 tarPos = mainChar.Avatar.unityObject.transform.position;

            if (m_CurType == MoveType.FollowPlayer)
            {
                var entity = GameScene.Instance.GetEntityByID(m_FollowerId);
                if (entity != null)
                {
                    entity.Direction = mainChar.Direction;
                    tarPos = mainChar.Avatar.unityObject.transform.position + m_Offset;
                }
            }
            else if (m_CurType == MoveType.OnTreasure)
            {

            }
            else if (m_CurType == MoveType.ToTreasure)
            {
                var mapInfo = m_currInRangeSingleMapInfo;
                if (mapInfo != null)
                {
                    var treasure = GameScene.Instance.GetEntityByID(mapInfo.resThisID);
                    if (treasure != null)
                    {
                        if (treasure.Avatar.unityObject == null) return;
                        var treasureTrasform = treasure.Avatar.unityObject.transform;
                        tarPos = treasureTrasform.position + height;
                    }
                }
            }
            else if (m_CurType == MoveType.ToPlayer)
            {
                var playerTrasform = mainChar.Avatar.unityObject.transform;
                tarPos = playerTrasform.position + m_Offset;
            }

            if (m_CurType == MoveType.OnTreasure) return;

            var follower = GameScene.Instance.GetEntityByID(m_FollowerId);

            if (follower != null)
            {
                if (follower.Avatar.unityObject == null) return;
                var followerTrasform = follower.Avatar.unityObject.transform;
                var offset = tarPos - followerTrasform.position;
                var dir = offset.normalized;
                var len = offset.magnitude;
                var desiredSpeed = Mathf.Clamp(len, 0, MaxSpeed);
                var speedOffset = speed - desiredSpeed;

                if (Mathf.Abs(speedOffset) < accelerate)
                    speed = desiredSpeed;
                if (speedOffset < 0)
                    speed += accelerate;
                else if (speedOffset > 0)
                    speed -= accelerate;

                if (len <= speed)
                {
                    followerTrasform.position = tarPos;
                    DetermineNextState();
                }
                else
                {
                    followerTrasform.position += (speed * dir);
                }

                follower.onPositionChangeEvent.Invoke();
            }
        }
        private void DetermineNextState()
        {
            if (m_CurType == MoveType.ToPlayer)
            {
                m_CurType = MoveType.FollowPlayer;
            }
            else if (m_CurType == MoveType.ToTreasure)
            {
                m_CurType = MoveType.OnTreasure;
            }
        }
        private void TryUpdateNPCPos()
        {
            if (m_currMapId != 0)
            {
                SingleMapInfo mapInfo = m_currInRangeSingleMapInfo;

                if (mapInfo != null)
                {
                    Entity treasure = GameScene.Instance.GetEntityByID(mapInfo.resThisID);// as GatherResourceEntity;

                    if (treasure != null)
                    {
                        if (treasure.ActuallyVisible)
                        {
                            m_CurType = MoveType.ToTreasure;


                            ForceNPCTalk(mapInfo.treasureMapTableBase.Value.findWord);
                        }
                        else if (m_CurType == MoveType.OnTreasure)
                        {
                            m_CurType = MoveType.ToPlayer;
                        }
                    }
                }
            }
        }
        #endregion

        #region NPC Talk

        private void ForceNPCTalk(string word)
        {
            ChatModel.Instance.ClientAddSimpleChatMsg(swm.ChatPosType.NEARBY, word, E_CHATSTYLE.CHATSTYLE_NORMALTALK, m_FollowerId);
        }

        public void ShowHintFromLua()
        {
            DoCheckVisiblility();

            SingleMapInfo mapInfo = m_currInRangeSingleMapInfo;

            if (mapInfo != null)
            {
                bool isShowError = false;

                string word = string.Empty;

                int len = mapInfo.treasureMapTableBase.Value.disWordsLength;

                int index = (int)mapInfo.currAreaType;
                if (len > index)
                {
                    word = mapInfo.treasureMapTableBase.Value.disWords(index);


                    //90以外不提示方向;
                    //90到12提示距离和方向;
                    //30以内如果条件不符合提示对应文本;
                    //12以内如果条件符合，只提示距离;
                    //如果发现了，则飞向目标;

                    if (mapInfo.currAreaType != AreaType.OutsideOfNineScreen)
                    {
                        bool isGetTargetDirIndex = true;

                        if (mapInfo.currAreaType <= AreaType.Area2)
                        {
                            bool isTimeOK = mapInfo.IsTimeOK((int)m_TimeState);
                            bool isWeatherOK = mapInfo.IsWeatherOK((int)m_WeatherType);

                            if (!mapInfo.isopen)
                            {
                                word = mapInfo.treasureMapTableBase.Value.missionTip;
                                isGetTargetDirIndex = false;

                                isShowError = true;
                            }
                            else if (!isTimeOK)
                            {
                                word = mapInfo.treasureMapTableBase.Value.timeTip;
                                isGetTargetDirIndex = false;

                                isShowError = true;
                            }
                            else if (!isWeatherOK)
                            {
                                word = mapInfo.treasureMapTableBase.Value.weatherTip;
                                isGetTargetDirIndex = false;

                                isShowError = true;
                            }
                            else if (mapInfo.currAreaType == AreaType.Area1)
                            {
                                word = "";
                                isGetTargetDirIndex = false;
                            }
                        }

                        if (isGetTargetDirIndex)
                        {
                            index = getTargetDirIndex();
                            if (index != -1)
                            {
                                len = mapInfo.treasureMapTableBase.Value.dirWordsLength;

                                if (len > index)
                                {
                                    word = Bokura.Utilities.BuildString(word, mapInfo.treasureMapTableBase.Value.dirWords(index));
                                }
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(word))
                {
                    ForceNPCTalk(word);

                    if (m_searchEffect != null)
                    {
                        isSearching = true;
                        tryRemoveSearchTimer();
                        m_timerCache = GameApplication.Instance.m_TimerManager.AddTimer(() =>
                        {
                            isSearching = false;

                            if (m_searchEffect != null)
                            {
                                m_searchEffect.Visible = false;
                            };

                            if (m_errorEffect != null)
                            {
                                if (m_errorEffect.Visible)
                                {
                                    if (m_CurEffect != null)
                                    {
                                        m_CurEffect.Visible = isCurrEffectVisible;
                                    }

                                    m_errorEffect.Visible = false;
                                }
                            }
                        }, 2);

                        m_searchEffect.Visible = true;


                        if (mapInfo.currAreaType >= AreaType.Area3)
                        {
                            var treasure = GameScene.Instance.GetEntityByID(mapInfo.resThisID);
                            if (treasure != null)
                            {
                                if (treasure.Avatar.unityObject != null)
                                {
                                    var treasureTrasform = treasure.Avatar.unityObject.transform;

                                    m_dirEffect.Visible = false;
                                    m_dirEffect.Visible = true;

                                    if (m_dirEffect.effect != null)
                                    {
                                        m_dirEffect.effect.transform.LookAt(treasureTrasform);
                                    }
                                }
                            }
                        }


                        if (isShowError)
                        {
                            if (m_errorEffect != null)
                            {
                                m_errorEffect.Visible = true;
                            }

                            if (m_CurEffect != null)
                            {
                                isCurrEffectVisible = m_CurEffect.Visible;
                                m_CurEffect.Visible = false;
                            }
                        }

                        //TryUpdateNPCPos();
                    }
                }
            }
        }

        private bool isSearching = false;
        private bool isCurrEffectVisible = false;

        private Timer m_timerCache = new Timer();
        private void tryRemoveSearchTimer()
        {
            if (m_timerCache.ID > 0)
            {
                GameApplication.Instance.m_TimerManager.RemoveTimer(m_timerCache.ID);
            }
        }

        private Timer m_finishTimerCache = new Timer();
        private void tryRemoveFinishTimer()
        {
            if (m_finishTimerCache.ID > 0)
            {
                GameApplication.Instance.m_TimerManager.RemoveTimer(m_finishTimerCache.ID);
            }
        }


        //东南西北上下;
        private int getTargetDirIndex()
        {
            var mainChar = GameScene.Instance.MainChar;
            if ((mainChar != null) && (mainChar.Avatar != null) && (mainChar.Avatar.unityObject != null))
            {
                SingleMapInfo mapInfo = m_currInRangeSingleMapInfo;

                if (mapInfo != null)
                {
                    var treasure = GameScene.Instance.GetEntityByID(mapInfo.resThisID);
                    if (treasure != null)
                    {

                        if (treasure.Avatar.unityObject != null)
                        {
                            var treasureTrasform = treasure.Avatar.unityObject.transform;

                            var dir = treasureTrasform.position - mainChar.Avatar.unityObject.transform.position;

                            dir = Vector3.Normalize(dir);

                            float a = Mathf.Abs(dir.x);
                            float b = Mathf.Abs(dir.z);
                            float c = Mathf.Abs(dir.y /1.5f);

                            int index = 0;

                            if (a > b)
                            {
                                if (a > c) { index = 0; } else { index = 2; }
                            }
                            else
                            {
                                if (b > c) { index = 1; } else { index = 2; }
                            }

                            if (index == 0)
                            {
                                if (dir.x > 0) { return 0; } else { return 2; }
                            }
                            else if (index == 1)
                            {
                                if (dir.z > 0) { return 3; } else { return 1; }
                            }
                            else if (index == 2)
                            {
                                if (dir.y > 0) { return 4; } else { return 5; }
                            }
                        }
                    }
                }
            }

            return -1;
        }
        #endregion

        #region NPC Effect

        private int m_CurEffectType = -1;
        private int m_NextEffectType = -1;
        private float m_EffectFrequency = 0.5f;

        private Dictionary<int, EffectMgr.EffectInfo> m_effectsDic = new Dictionary<int, EffectMgr.EffectInfo>(0);
        private EffectMgr.EffectInfo m_CurEffect;
        private ParticleSystem m_ParticleSystem;

        private EffectMgr.EffectInfo m_searchEffect;
        private EffectMgr.EffectInfo m_errorEffect;
        private EffectMgr.EffectInfo m_dirEffect;

        private bool DoEffectUpdate { get { return m_IsActivated == false ? false : true; } }

        private void UpdateEffect()
        {
            if (!DoEffectUpdate) return;

            if (m_errorEffect != null)
            {
                if (m_errorEffect.Visible)
                {
                    return;
                }
            }

            SingleMapInfo mapInfo = m_currInRangeSingleMapInfo;

            if (mapInfo != null)
            {
                if (mapInfo.currAreaType == AreaType.OutsideOfNineScreen)
                {
                    m_NextEffectType = -1;
                }
                else
                {
                    m_NextEffectType = (int)mapInfo.currAreaType;
                }

                if (m_NextEffectType != -1)
                {
                    float dis = Mathf.Sqrt(mapInfo.currDisSqr);
                    m_EffectFrequency = 2.5f * (90 - dis) / 90;
                    m_EffectFrequency = Mathf.Clamp(m_EffectFrequency, 0.3f, 2.5f);
                }
                else
                {
                    m_EffectFrequency = 1;
                }
            }

            if (m_CurEffectType != m_NextEffectType)
            {
                m_ParticleSystem = null;

                if (m_CurEffect != null)
                {
                    m_CurEffect.Visible = false;                  
                }

                m_effectsDic.TryGetValue((int)m_NextEffectType, out m_CurEffect);

                if (m_CurEffect != null)
                {
                    //异步加载可能尚未完成;
                    if (m_CurEffect.effect != null)
                    {
                        m_CurEffect.Visible = true;
                        m_CurEffectType = m_NextEffectType;
                    }
                }
                else
                {
                    m_CurEffectType = m_NextEffectType;
                }
            }

            if (m_CurEffect == null) return;

            if (ReferenceEquals(m_ParticleSystem, null) && m_CurEffect.effect != null)
                m_ParticleSystem = m_CurEffect.effect.GetComponentInChildren<ParticleSystem>();

            if (m_ParticleSystem != null)
            {
                var emission = m_ParticleSystem.emission;
                emission.rateOverTimeMultiplier = m_EffectFrequency;
            }
        }

        private void InitEffects(Entity follower)
        {
            if (m_searchEffect == null)
            {

                var effectinfo = EffectMgr.Instance.Play("fx_spirit_xunbao_strong03_s", follower, AvatarAttachment.Root, null, false);
                effectinfo.Visible = false;
                m_effectsDic[(int)AreaType.Area1] = effectinfo;

                effectinfo = EffectMgr.Instance.Play("fx_spirit_xunbao_strong03_s", follower, AvatarAttachment.Root, null, false);
                effectinfo.Visible = false;
                m_effectsDic[(int)AreaType.Area2] = effectinfo;

                effectinfo = EffectMgr.Instance.Play("fx_spirit_xunbao_strong02_s", follower, AvatarAttachment.Root, null, false);
                effectinfo.Visible = false;
                m_effectsDic[(int)AreaType.Area3] = effectinfo;


                effectinfo = EffectMgr.Instance.Play("fx_spirit_xunbao_strong01_s", follower, AvatarAttachment.Root, null, false);
                effectinfo.Visible = false;
                m_effectsDic[(int)AreaType.Area4] = effectinfo;

                effectinfo = EffectMgr.Instance.Play("fx_spirit_xunbao_strong_s", follower, AvatarAttachment.Root, null, false);
                effectinfo.Visible = false;
                m_effectsDic[(int)AreaType.Area5] = effectinfo;

                //错误光效;
                m_errorEffect = EffectMgr.Instance.Play("fx_spirit_xunbao_strong_red_s", follower, AvatarAttachment.Root, null, false);
                m_errorEffect.Visible = false;

                //雷达特效;
                //fx_spirit_xunbao_rader02_s;
                m_searchEffect = EffectMgr.Instance.Play("fx_spirit_xunbao_radar01_s", follower, AvatarAttachment.Root, null, false);
                m_searchEffect.Visible = false;

                m_dirEffect = EffectMgr.Instance.Play("fx_spirit_xunbao_fangxiang_s", follower, AvatarAttachment.Root, null, false);
                m_dirEffect.Visible = false;

                m_CurEffect = null;

                DoCheckVisiblility();
            }
        }
        #endregion
    }
}