using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public class TriggerBound
    {
        public bool IsActive = true;//是否激活的

        public GameObject ShowEffectObject = null;//特效实体

        public bool IsShowEffect = false;//是否现在显示了特效

        public bool IsMainCharInBound = false;

        public TriggerAssets.Item TriggerInfo = null;//配置数据

        private Vector3 m_Center = Vector3.zero;//中心位置

        private double m_height = double.MinValue;//高度

        private Quaternion m_Rotation = Quaternion.identity;

        private Quaternion m_RotationBack = Quaternion.identity;//上面旋转阀 反向旋转

        public GameObject FrameObject = null;//showbox的实体

        private int m_StoreRepeatNumber = 0;//记录触发次数  这个只是客户端记录 重启会失效

        private bool m_bIsInNineScreen = false;//是否在9屏显示

        public bool m_AsyncLoading = false;

        public  bool IsInNineScreen
        {
            get
            {
                return m_bIsInNineScreen;
            }
            set
            {
                m_bIsInNineScreen = value;
            }
        }

        public int StoreRepeatNumber
        {
            get
            {
                return m_StoreRepeatNumber;
            }
            set
            {
                m_StoreRepeatNumber = value;
            }
        }

        public Vector3 Center
        {
            get
            {
                if(m_Center == Vector3.zero)
                {
                    if(null != TriggerInfo)
                    {
                        m_Center.x = (float)TriggerInfo.position.x;
                        m_Center.y = (float)TriggerInfo.position.y;
                        m_Center.z = (float)TriggerInfo.position.z;
                    }
                }
                return m_Center;
            }
        }

        public Quaternion Rotation
        {
            get
            {
                if (m_Rotation == Quaternion.identity)
                {
                    if (null != TriggerInfo)
                    {
                        
                        m_Rotation = Quaternion.Euler(TriggerInfo.rotation);
                    }
                }
                return m_Rotation;
            }
        }

        public Quaternion RotationBack
        {
            get
            {
                if (m_RotationBack == Quaternion.identity)
                {
                    if (null != TriggerInfo)
                    {
                        Vector3 vc = new Vector3(-TriggerInfo.rotation.x, -TriggerInfo.rotation.y, -TriggerInfo.rotation.z);
                        m_RotationBack = Quaternion.Euler(vc);
                    }
                }
                return m_RotationBack;
            }
        }


        public double Height
        {
            get
            {
                if(m_height == double.MinValue)
                {
                    TriggerType boxtype = TriggerInfo.Type;
                    if (boxtype == TriggerType.AABB)//0表示长方体aabb
                    {
                        m_height = TriggerInfo.Scale.y;
                    }
                    else if(boxtype == TriggerType.Cube) //1表示长方体 非aabb
                    {
                        m_height = TriggerInfo.Scale.y;
                    }
                    else if (boxtype == TriggerType.Sphere)//球高度就是2个半径
                    {
                        m_height = TriggerInfo.Scale.y;
                    }
                    else if (boxtype == TriggerType.Cylinder)//圆柱体高度
                    {
                        m_height = TriggerInfo.Scale.y;
                    }
                    else
                    {
                        m_height = 1;
                    }
                }

                return m_height;
            }
        }

        public void SetIsCanReActive()
        {
            if (TriggerInfo.CanRepeatTriggerNumber > 0)
            {
                IsActive = TriggerInfo.CanRepeatTriggerNumber > m_StoreRepeatNumber;
            }
            else
            {
                IsActive = true;
            }
        }

        [XLua.BlackList]
        public void Clear()
        {
            SetIsCanReActive();
            DestoryShowEffectObject();
            if (null != FrameObject)
            {
                GameObject.DestroyImmediate(FrameObject);
                FrameObject = null;
            }

            IsActive = true;//是否激活的

            ShowEffectObject = null;//特效实体

            IsShowEffect = false;//是否现在显示了特效

            IsMainCharInBound = false;

            TriggerInfo = null;//配置数据

            m_Center = Vector3.zero;//中心位置

            m_height = double.MinValue;//高度

            m_Rotation = Quaternion.identity;

            m_RotationBack = Quaternion.identity;//上面旋转阀 反向旋转


            m_StoreRepeatNumber = 0;//记录触发次数  这个只是客户端记录 重启会失效

            m_bIsInNineScreen = false;//是否在9屏显示

            m_AsyncLoading = false;
        }

        [XLua.BlackList]
        public void DestoryShowEffectObject()
        {
            if (null != ShowEffectObject)
            {
                GameObject.DestroyImmediate(ShowEffectObject);
                ShowEffectObject = null;
            }
        }

        /// <summary>
        /// 得到触发器标签
        /// </summary>
        /// <returns></returns>
        [XLua.BlackList]
        public int GetTriggerLabel()
        {
            if (TriggerInfo == null)
                return (int)TriggerLabel.Normal;

            return (int)TriggerInfo.triggerLabel;
        }

        [XLua.BlackList]
        public int GetTriggerDataInt()
        {
            if (TriggerInfo == null)
                return 0;

            return TriggerInfo.triggerDataInt;
        }
    }

    public class TriggerInfoProxy
    {
        #region 常量

        private const float PositionChangeCheckDis = 0.1f;

        #endregion

        #region 变量

        private bool m_bIsClear = false;

        private Dictionary<long, List<TriggerBound>> m_triggerBound = new Dictionary<long, List<TriggerBound>>(9);///当前trigger列表

        private Dictionary<long, List<TriggerBound>> m_tempTriggerBound = new Dictionary<long, List<TriggerBound>>(9);///当前trigger列表

        private List<TriggerBound> m_triggerBoundPool = new List<TriggerBound>(Bokura.ConstValue.kCap32); //TriggerBound 的池子

        private Vector3 m_StoreMainCharPos = Vector3.zero;

        private AreaTriggerData m_CurrentAreaListData = null;


        private bool m_IsShowDrawBox = false;
        public bool IsShowDrawBox
        {
            get
            {
                return m_IsShowDrawBox;
            }
        }

        private int m_CurrentMapBaseId = 0;

        private Vector2Int m_CurrentClientNineScreenArea = new Vector2Int(1000,1000);

        #endregion

        #region 内置函数

        [XLua.BlackList]
        public void Init()
        {
            GameScene.Instance.onIntoMap.AddListener(ProcessIntoMap);
            GameScene.Instance.onEndLoading.AddListener(ProcessOnEndLoading);
            GameScene.Instance.onGameStateChange.AddListener(ProcessGameStateChange);

            GameScene.Instance.onMainCharAdd.AddListener(ProcMainCharAdd);
        }

        [XLua.BlackList]
        public void Update()
        {

        }

        #endregion

        #region 消息处理

        private void ProcMainCharAdd()
        {
            GameScene.Instance.MainChar.onPositionChangeEvent.AddListener(ProcMainCharPositionChange);
        }

        private void ProcessIntoMap(swm.IntoMap _msg)
        {
            RemoveAll();
        }

        private TriggerBound GetTriggerBoundInstanceFromPool()
        {
            TriggerBound _bound = null;
            if(m_triggerBoundPool.Count > 0)
            {
                _bound = m_triggerBoundPool[0];
                m_triggerBoundPool.RemoveAt(0);
            }
            if (_bound == null)
            {
                _bound = new TriggerBound();
            }
            return _bound;
        }
        private void BackAllTriggerBoundToPool()
        {
            if( m_triggerBound.Count > 0 )
            {
                foreach(var _value in m_triggerBound)
                {
                    for (int i = 0; i < _value.Value.Count; i++)
                    {
                        BackTriggerBoundToPool(_value.Value[i]);
                    }
                }
                m_triggerBound.Clear();
            }
        }

        private void BackTriggerBoundToPool(TriggerBound _bound)
        {
            if(_bound != null)
            {
                _bound.Clear();
                m_triggerBoundPool.Add(_bound);
            }
        }

        private void ProcessOnEndLoading()
        {
            if (!m_bIsClear)
            {
                return;
            }

            m_bIsClear = false;

            if (GameScene.Instance.currState >= GameState.InGame)
            {
                swm.IntoMap _msg = GameScene.Instance.CurrentIntomapInfo.Value;
                int _mapBaseId = (int)(_msg.map_baseid);
                if (m_CurrentMapBaseId != _mapBaseId)
                {
                    m_CurrentMapBaseId = _mapBaseId;
                    MapInfoAssets.Item _config = MapInfoTableManager.GetData(_mapBaseId);
                    if (_config != null)
                    {
                        m_CurrentAreaListData = TriggerInfoTable.Instance.GetAreaTriggerListById(_mapBaseId);
                    }

                    ProcMainCharPositionChange();
                    SetIsShowAllDrawBox(m_IsShowDrawBox);
                }
            }
        }

        private void ProcessGameStateChange(GameState oldState, GameState newState)
        {
            if (GameScene.Instance.CheckIsInGame(oldState, newState))//newState < GameState.InGame && oldState >= GameState.InGame )
            {
                if (null != GameScene.Instance.MainChar)
                {
                    GameScene.Instance.MainChar.onPositionChangeEvent.RemoveListener(ProcMainCharPositionChange);
                }
                m_StoreMainCharPos = Vector3.zero;
                RemoveAll();
            }
        }

        #endregion

        #region 函数

        public TriggerBound GetTriggerBoundById(int _id)
        {
            TriggerBound _bound = null;
            if ( m_triggerBound.Count > 0)
            {
                foreach (var _value in m_triggerBound)
                {
                    for (int i = 0; i < _value.Value.Count; i++)
                    {
                        TriggerBound _data = _value.Value[i];
                        if (_data.TriggerInfo.Triggerid == _id)
                        {
                            _bound = _data;
                            break;
                        }
                    }
                }

            }

            return _bound;
        }

        [XLua.BlackList]
        public void RemoveAll()
        {
            BackAllTriggerBoundToPool();
            TriggerManager.Instance.NotifyRemoveAllBound();

            m_bIsClear = true;
            m_CurrentMapBaseId = -1;
            m_CurrentAreaListData = null;
            m_CurrentClientNineScreenArea.x = 1000;
            m_CurrentClientNineScreenArea.y = 1000;
        }

        private void LoadEffect(TriggerBound _triggerBound)
        {
            if (_triggerBound.ShowEffectObject == null && !_triggerBound.m_AsyncLoading && !string.IsNullOrEmpty(_triggerBound.TriggerInfo.effect))
            {
                _triggerBound.m_AsyncLoading = true;
                ResourceHelper.LoadPrefabAsync(IResourceLoader.strSceneEffectPath, _triggerBound.TriggerInfo.effect, (UnityEngine.Object o) =>
                {
                    _triggerBound.m_AsyncLoading = false;
                    if (o == null)
                        return;
                    if (_triggerBound.IsInNineScreen && null == _triggerBound.ShowEffectObject)
                    {
                        _triggerBound.ShowEffectObject = GameObject.Instantiate(o, _triggerBound.Center, Quaternion.identity) as GameObject;
                        _triggerBound.ShowEffectObject.SetActive(true);
                        _triggerBound.IsShowEffect = true;
                        _triggerBound.ShowEffectObject.transform.position = new Vector3(_triggerBound.Center.x, _triggerBound.Center.y, _triggerBound.Center.z) - LayeredSceneLoader.WorldOffset;
                    }

                });
            }
        }

        private void ProcChangeClientNineScreenData()
        {
            if(m_CurrentAreaListData != null )
            {
                bool _bIsNeedChange = false;
                Vector3 _pos = GameScene.Instance.MainChar.Position;
                int x = (int)(_pos.x / TriggerAssets.CELL_SIZE);
                int y = (int)(_pos.z / TriggerAssets.CELL_SIZE);
                if (m_CurrentClientNineScreenArea.x == 1000)
                {
                    _bIsNeedChange = true;
                }
                else
                {
                    if(m_CurrentClientNineScreenArea.x != x || m_CurrentClientNineScreenArea.y != y)
                    {
                        _bIsNeedChange = true;
                    }
                }
                m_CurrentClientNineScreenArea.x = x;
                m_CurrentClientNineScreenArea.y = y;
                if (_bIsNeedChange)
                {
                    int yLow    = m_CurrentClientNineScreenArea.y - 1;
                    int yUpper  = m_CurrentClientNineScreenArea.y + 1;
                    int xLow    = m_CurrentClientNineScreenArea.x - 1;
                    int xUpper  = m_CurrentClientNineScreenArea.x + 1;
                    m_tempTriggerBound.Clear();
                    for (int i = yLow;i<=yUpper;i++)//9格
                    {
                        for(int j=xLow;j<=xUpper;j++)
                        {
                            TriggerAssets.ItemGroup _group = m_CurrentAreaListData.GetItemGroupByKey(j, i);
                            if(null != _group)
                            {
                                long key = m_CurrentAreaListData.GetKey(j, i);
                                List<TriggerBound> _list = null;
                                //原先有列表 先检查一下
                                if (m_triggerBound.TryGetValue(key, out _list))
                                {
                                    m_triggerBound.Remove(key);
                                }

                                //没有 那就看看是否配置里面有需要加一个
                                if (null == _list)
                                {
                                    int len = _group.items.Length;
                                    if(len > 0)
                                    {
                                        _list = new List<TriggerBound>(Bokura.ConstValue.kCap32);
                                        for (int iLen = 0; iLen < len; iLen++)
                                        {
                                            TriggerBound _bound = GetTriggerBoundInstanceFromPool();
                                            _bound.TriggerInfo = _group.items[iLen];
                                            _list.Add(_bound);
                                        }
                                    }

                                }
                                if (null != _list)
                                {
                                    m_tempTriggerBound[key] = _list;
                                }
                            }
                        }
                    }
                    if (m_triggerBound.Count > 0)
                    {
                        foreach (var _value in m_triggerBound)
                        {
                            for (int i = 0; i < _value.Value.Count; i++)
                            {
                                BackTriggerBoundToPool(_value.Value[i]);
                            }
                        }
                        m_triggerBound.Clear();
                    }

                    if (m_tempTriggerBound.Count > 0)
                    {
                        foreach (var _value in m_tempTriggerBound)
                        {
                            m_triggerBound[_value.Key] = _value.Value;
                        }
                        m_tempTriggerBound.Clear();
                    }

                    //开发测试用
                    if(m_IsShowDrawBox)
                    {
                        SetIsShowAllDrawBox(m_IsShowDrawBox);
                    }
                }
            }
        }

        [XLua.BlackList]
        public void ProcMainCharPositionChange()
        {
            if (null == GameScene.Instance.MainChar)
                return;

            Vector3 _pos = GameScene.Instance.MainChar.Position;

            if (m_StoreMainCharPos == Vector3.zero || (m_StoreMainCharPos - _pos).sqrMagnitude > PositionChangeCheckDis * PositionChangeCheckDis)
            {
                m_StoreMainCharPos.x = _pos.x;
                m_StoreMainCharPos.y = _pos.y;
                m_StoreMainCharPos.z = _pos.z;
                ProcChangeClientNineScreenData();
                ProcCollision();
            }
        }

        /// <summary>
        /// 复位碰撞信息 重新开启碰撞检测
        /// </summary>
        [XLua.BlackList]
        public void ResetCollisionBound(TriggerBound _bound)
        {
            if (_bound != null)
            {
                // 复位这些标志,重新检测
                _bound.IsMainCharInBound = false;
                _bound.IsActive = true;
            }
        }

        /// <summary>
        /// 碰撞检测
        /// </summary>
        [XLua.BlackList]
        public void ProcCollision()
        {
            if (null == GameScene.Instance.MainChar )
                return;

            Vector3 _pos = GameScene.Instance.MainChar.Position;

            if (m_triggerBound.Count > 0)
            {
                Vector3 mainPs = GameScene.Instance.MainChar.Position;
                foreach (var _value in m_triggerBound)
                {
                    for (int i = 0; i < _value.Value.Count; i++)
                    {
                        TriggerBound _bound = _value.Value[i];
                        var dis = (_bound.Center - mainPs).sqrMagnitude;
                        _bound.IsInNineScreen = dis < 250000;// ClientNpcEntityManager.g_NineScreenRange;

                        if (_bound.IsInNineScreen || _bound.IsMainCharInBound)
                        {
                            LoadEffect(_bound);//显示特效

                            //9屏内做碰撞计算
                            if (!_bound.IsMainCharInBound)
                            {
                                if (_bound.IsActive)
                                {
                                    if (CheckIsInBound(_bound, _pos))
                                    {
                                        _bound.IsMainCharInBound = true;
                                        _bound.IsActive = false;
                                        //Bokura.LogHelper.LogFormat("in trigger type:{0},id:{1}", _bound.TriggerInfo.Type.ToString(), _bound.TriggerInfo.Triggerid.ToString());

                                        TriggerManager.Instance.ProcessTriggerEnterLua(_bound);
                                    }
                                }
                            }
                            else
                            {
                                if (!CheckIsInBound(_bound, _pos))
                                {
                                    _bound.IsMainCharInBound = false;//out trigger
                                                                     //Bokura.LogHelper.LogFormat("out trigger type:{0},id:{1}", _bound.TriggerInfo.Type.ToString(), _bound.TriggerInfo.Triggerid.ToString());
                                    _bound.StoreRepeatNumber = _bound.StoreRepeatNumber + 1;
                                    _bound.SetIsCanReActive();

                                    TriggerManager.Instance.ProcessTriggerLeaveLua(_bound);
                                }
                            }
                        }
                        else
                        {
                            _bound.DestoryShowEffectObject();
                        }

                    }
                }

            }
        }

        public void SetIsShowAllDrawBox(bool _bIsVisible)
        {
            m_IsShowDrawBox = _bIsVisible;
            if (m_triggerBound.Count > 0)
            {
                if (_bIsVisible)
                {
                    foreach(var _value in m_triggerBound)
                    {
                        for (int i = 0; i < _value.Value.Count; i++)
                        {
                            TriggerBound _bound = _value.Value[i];
                            DrawBox(_bound);
                        }
                    }

                }
                else
                {
                    foreach (var _value in m_triggerBound)
                    {
                        for (int i = 0; i < _value.Value.Count; i++)
                        {
                            TriggerBound _bound = _value.Value[i];
                            if (_bound.FrameObject != null)
                            {
                                _bound.FrameObject.SetActive(false);
                                // GameObject.DestroyImmediate(_bound.FrameObject);
                                // _bound.FrameObject = null;
                            }
                        }
                    }

                }
            }
        }

        private void DrawBox(TriggerBound _triggerBound)
        {
            TriggerType boxtype = _triggerBound.TriggerInfo.Type;
            if (boxtype == TriggerType.AABB)
            {
                if (null == _triggerBound.FrameObject)
                {
                    _triggerBound.FrameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    _triggerBound.FrameObject.name = _triggerBound.TriggerInfo.Name;
                    _triggerBound.FrameObject.GetComponent<BoxCollider>().enabled = false;
                    _triggerBound.FrameObject.SetLayerRecursively((int)Bokura.UserLayer.Layer_Trigger);
                    _triggerBound.FrameObject.transform.position = _triggerBound.TriggerInfo.position - LayeredSceneLoader.WorldOffset;
                    var render = _triggerBound.FrameObject.GetComponent<Renderer>();
                    if (render)
                    {
                        var material = ResourceHelper.LoadResourceSync("art_resource/environment/Common/Materials/", "env_test_d", ".mat");
                        render.sharedMaterial = material as Material;
                        MaterialPropertyBlock block = new MaterialPropertyBlock();
                        block.SetColor("_Color", Color.green);
                        render.SetPropertyBlock(block);
                    }
                    _triggerBound.FrameObject.transform.localScale = _triggerBound.TriggerInfo.Scale;//new Vector3(scaleX, scaleY, scaleZ);
                }

                _triggerBound.FrameObject.SetActive(true);

            }
            else if (boxtype == TriggerType.Cube)
            {
                if (null == _triggerBound.FrameObject)
                {
                    _triggerBound.FrameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    _triggerBound.FrameObject.name = _triggerBound.TriggerInfo.Name;
                    _triggerBound.FrameObject.SetLayerRecursively((int)Bokura.UserLayer.Layer_Trigger);
                    _triggerBound.FrameObject.GetComponent<BoxCollider>().enabled = false;
                    _triggerBound.FrameObject.transform.position = _triggerBound.TriggerInfo.position - LayeredSceneLoader.WorldOffset;//new Vector3(_triggerBound.Center.x, _triggerBound.Center.y, _triggerBound.Center.z) - LayeredSceneLoader.WorldOffset;
                    var render = _triggerBound.FrameObject.GetComponent<Renderer>();
                    if (render)
                    {
                        var material = ResourceHelper.LoadResourceSync("art_resource/environment/Common/Materials/", "env_test_d", ".mat");
                        render.sharedMaterial = material as Material;
                        MaterialPropertyBlock block = new MaterialPropertyBlock();
                        block.SetColor("_Color", Color.green);
                        render.SetPropertyBlock(block);
                    }
                    _triggerBound.FrameObject.transform.localScale = _triggerBound.TriggerInfo.Scale;//new Vector3(scaleX, scaleY, scaleZ);
                    _triggerBound.FrameObject.transform.localEulerAngles = _triggerBound.TriggerInfo.rotation;
                }

                _triggerBound.FrameObject.SetActive(true);
            }
            else if (boxtype == TriggerType.Sphere)
            {
                if (null == _triggerBound.FrameObject)
                {
                    float r = _triggerBound.TriggerInfo.Scale.x; //(float)(_triggerBound.TriggerInfo.radius + _triggerBound.TriggerInfo.radius);
                    _triggerBound.FrameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    _triggerBound.FrameObject.name = _triggerBound.TriggerInfo.Name;
                    _triggerBound.FrameObject.SetLayerRecursively((int)Bokura.UserLayer.Layer_Trigger);
                    _triggerBound.FrameObject.GetComponent<SphereCollider>().enabled = false;
                    _triggerBound.FrameObject.transform.position = new Vector3(_triggerBound.Center.x, _triggerBound.Center.y, _triggerBound.Center.z) - LayeredSceneLoader.WorldOffset;
                    var render = _triggerBound.FrameObject.GetComponent<Renderer>();
                    if (render)
                    {
                        var material = ResourceHelper.LoadResourceSync("art_resource/environment/Common/Materials/", "env_test_d", ".mat");
                        render.sharedMaterial = material as Material;
                        MaterialPropertyBlock block = new MaterialPropertyBlock();
                        block.SetColor("_Color", Color.yellow);
                        render.SetPropertyBlock(block);
                    }
                    _triggerBound.FrameObject.transform.localScale = new Vector3(r, r, r);
                }
                _triggerBound.FrameObject.SetActive(true);
            }
            else if (boxtype == TriggerType.Cylinder)
            {
                if (null == _triggerBound.FrameObject)
                {
                    float r = _triggerBound.TriggerInfo.Scale.x;// (float)(_triggerBound.TriggerInfo.radius + _triggerBound.TriggerInfo.radius);

                    _triggerBound.FrameObject = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    _triggerBound.FrameObject.name = _triggerBound.TriggerInfo.Name;
                    _triggerBound.FrameObject.SetLayerRecursively((int)Bokura.UserLayer.Layer_Trigger);
                    _triggerBound.FrameObject.GetComponent<CapsuleCollider>().enabled = false;
                    _triggerBound.FrameObject.transform.position = new Vector3(_triggerBound.Center.x, _triggerBound.Center.y, _triggerBound.Center.z) - LayeredSceneLoader.WorldOffset;
                    var render = _triggerBound.FrameObject.GetComponent<Renderer>();
                    if (render)
                    {
                        var material = ResourceHelper.LoadResourceSync("art_resource/environment/Common/Materials/", "env_test_d", ".mat");
                        render.sharedMaterial = material as Material;
                        MaterialPropertyBlock block = new MaterialPropertyBlock();
                        block.SetColor("_Color", Color.red);
                        render.SetPropertyBlock(block);
                    }
                    _triggerBound.FrameObject.transform.localScale = new Vector3(r, (float)(_triggerBound.Height), r);
                }
                _triggerBound.FrameObject.SetActive(true);
            }
        }

        /// <summary>
        /// 判断点是否和长方体包围盒碰撞
        /// </summary>
        /// <param name="_mainPos"></param>
        /// <param name="_pos"></param>
        /// <param name="_scale"></param>
        /// <returns></returns>
        private bool CheckBoundAABB(Vector3 _mainPos, Vector3 _pos, Vector3 _scale)
        {
            if (_mainPos.x < _pos.x - _scale.x * 0.5) return false;
            if (_mainPos.y < _pos.y - _scale.y * 0.5) return false;
            if (_mainPos.z < _pos.z - _scale.z * 0.5) return false;
            if (_mainPos.x > _pos.x + _scale.x * 0.5) return false;
            if (_mainPos.y > _pos.y + _scale.y * 0.5) return false;
            if (_mainPos.z > _pos.z + _scale.z * 0.5) return false;
            return true;
        }

        [XLua.BlackList]
        public bool CheckIsInBound(TriggerBound _triggerBound, Vector3 _pos)
        {
            bool bIsInBound = false;
            TriggerType boxtype = _triggerBound.TriggerInfo.Type;

            // 这里为什么不检测高度
            //m_tmpMainPos.x = _pos.x;
            //m_tmpMainPos.z = _pos.z;

            var m_tmpMainPos = _pos;

            if (boxtype == TriggerType.AABB)//0表示长方体aabb
            {
                bIsInBound = CheckBoundAABB(m_tmpMainPos, _triggerBound.TriggerInfo.position, _triggerBound.TriggerInfo.Scale);
            }
            else if (boxtype == TriggerType.Cube)//1表示长方体
            {
                Vector3 _p = _triggerBound.RotationBack * (m_tmpMainPos- _triggerBound.TriggerInfo.position) + _triggerBound.TriggerInfo.position;
                bIsInBound = CheckBoundAABB(_p, _triggerBound.TriggerInfo.position, _triggerBound.TriggerInfo.Scale);
            }
            else if (boxtype == TriggerType.Sphere)//2表示球体
            {
                double r = _triggerBound.TriggerInfo.Scale.x * _triggerBound.TriggerInfo.Scale.x * 0.25;
                if ((m_tmpMainPos - _triggerBound.Center).sqrMagnitude <= r)
                {
                    bIsInBound = true;
                }
            }
            else if (boxtype == TriggerType.Cylinder)//3表示圆柱体
            {
                Vector3 ct = new Vector3(_triggerBound.Center.x, 0, _triggerBound.Center.z);
                Vector3 newPos = new Vector3(_pos.x, 0, _pos.z);
                double r = _triggerBound.TriggerInfo.Scale.x * _triggerBound.TriggerInfo.Scale.x * 0.25;
                if ((newPos - ct).sqrMagnitude <= r)//在2d的圆内
                {
                    double h = _triggerBound.Height * 0.5;
                    if (m_tmpMainPos.y > _triggerBound.Center.y - h && m_tmpMainPos.y < _triggerBound.Center.y + h)
                    {
                        bIsInBound = true;
                    }
                }
            }

            return bIsInBound;
        }

        [XLua.BlackList]
        public TriggerBound GetTriggerBoundByLblAndIntData(int _label, int intdata)
        {
            if (m_triggerBound.Count > 0)
            {
                foreach (var _value in m_triggerBound)
                {
                    for (int i = 0; i < _value.Value.Count; i++)
                    {
                        TriggerBound _bound = _value.Value[i];
                        if (_bound == null)
                            continue;

                        var label = _bound.GetTriggerLabel();
                        if (_label != (int)label)
                            continue;

                        if (_bound.GetTriggerDataInt() == intdata)
                        {
                            return _bound;
                        }
                    }
                }
            }

            return null;
        }

        [XLua.BlackList]
        public TriggerBound GetTriggerBoundByLblAndPos(int _label, Vector3 _pos)
        {
            if (m_triggerBound.Count > 0)
            {
                foreach (var _value in m_triggerBound)
                {
                    for (int i = 0; i < _value.Value.Count; i++)
                    {
                        TriggerBound _bound = _value.Value[i];
                        if (_bound == null)
                            continue;

                        var label = _bound.GetTriggerLabel();
                        if (_label != (int)label)
                            continue;

                        if (CheckIsInBound(_bound, _pos))
                        {
                            return _bound;
                        }
                    }
                }
            }

            return null;
        }

        #endregion
    }
}










//new Vector3(_triggerBound.Center.x, _triggerBound.Center.y, _triggerBound.Center.z) - LayeredSceneLoader.WorldOffset;

//float scaleX = _triggerBound.TriggerInfo.Scale.x;//Math.Abs((float)_triggerBound.TriggerInfo.p111[0] - (float)_triggerBound.TriggerInfo.p000[0]);
//float scaleY = _triggerBound.TriggerInfo.Scale.y;//Math.Abs((float)_triggerBound.TriggerInfo.p111[1] - (float)_triggerBound.TriggerInfo.p000[1]);
// float scaleZ = _triggerBound.TriggerInfo.Scale.z;//Math.Abs((float)_triggerBound.TriggerInfo.p111[2] - (float)_triggerBound.TriggerInfo.p000[2]);

//                 else 
//                 {
//                     Vector3 newPos = new Vector3(_pos.x, _pos.y+ halfBody, _pos.z);
//                     if ((newPos - ct).sqrMagnitude <= r)
//                     {
//                         bIsInBound = true;
//                     }
//                 }
//判断一个点是否在多边形内部,以这个点像X轴正方形发射一条射线，求射线与边交点的个数
//                 int num = 0;
//                 var center = _mainChar.center;
//                 for (int i = 0; i < _triggerBound.Position.Count; i++)
//                 {
//                     var pos1 = _triggerBound.Position[i] - center;
//                     var pos2 = _triggerBound.Position[(i + 1) % _triggerBound.Position.Count] - center;
// 
//                     if (pos1.z * pos2.z > 0)
//                         continue;
//                     if (pos1.z == pos2.z)
//                         continue;
//                     if (pos1.z == 0)
//                         continue;
//                     var tempX = (pos1.x * pos2.z - pos2.x * pos1.z) / (pos2.z - pos1.z);
//                     if (tempX <= 0)
//                     {
//                         continue;
//                     }
//                     num++;
//                 }
//                 if (num % 2 == 1)
//                 {
//                     bIsInBound = true;
//                 }

//                 if ((_mainChar.min - _triggerBound.Position[0]).sqrMagnitude < _triggerBound.Half.x * _triggerBound.Half.x)
//                 {
//                     bIsInBound = true;
//                 }
//                 else if ((_mainChar.max - _triggerBound.Position[0]).sqrMagnitude < _triggerBound.Half.x * _triggerBound.Half.x)
//                 {
//                     bIsInBound = true;
//                 }

//m_tmpMainPos = _triggerBound.Rotation * m_tmpMainPos;

//                 if (_mainChar.Intersects(_triggerBound.Bound))
//                 {
//                     Physics.OverlapBoxNonAlloc(_triggerBound.Position[0], _triggerBound.Half, _tempColliderList, _triggerBound.Rotation, 1 << (int)UserLayer.Layer_MainCharacter);
//                     if (_tempColliderList.Length > 0)
//                     {
//                         for (int j = 0; j < _tempColliderList.Length; j++)
//                         {
//                             bool b = _tempColliderList[j] == _mainCollider;//GameScene.Instance.MainChar.Avatar.getBoundBox();
//                             if (b)
//                             {
//                                 bIsInBound = true;
//                                 break;
//                             }
//                         }
//                     }
//                 }

//                 if(_pos.x > _triggerBound.TriggerInfo.p000[0] && _pos.x < _triggerBound.TriggerInfo.p111[0] &&
//                     _pos.z > _triggerBound.TriggerInfo.p000[2] && _pos.z < _triggerBound.TriggerInfo.p111[2])
//                 {
//                     //在矩形内
//                     if(_pos.y > _triggerBound.TriggerInfo.p000[1] && _pos.y < _triggerBound.TriggerInfo.p111[1])
//                     {
//                         bIsInBound = true;
//                     }
//                     else if(_pos.y + halfBody > _triggerBound.TriggerInfo.p000[1] && _pos.y + halfBody < _triggerBound.TriggerInfo.p111[1])
//                     {
//                         bIsInBound = true;
//                     }
//                 }

//m_tmpMainPos.y = _pos.y + halfBody;//抬高半个人的高度左右

//private float halfBody = 1.5f;
//private float AllBody = 1.5f * 2;

// TriggerManager.Instance.RemoveById(_bound.ID);
