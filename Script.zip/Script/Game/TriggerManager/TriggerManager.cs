﻿using System.Collections.Generic;
using Bokura;

namespace Bokura
{
    public class TriggerManager : ClientSingleton<TriggerManager>
    {
        #region 变量

        public class EntityTriggerBoundEvent : GameEvent<TriggerBound>
        {

        }

        public GameEvent<TriggerBound> onTriggerBoundEnter = new EntityTriggerBoundEvent();

        public GameEvent<TriggerBound> onTriggerBoundLeave = new EntityTriggerBoundEvent();

        public GameEvent onTriggerBoundRemoveAll = new GameEvent();

        private TriggerInfoProxy m_triggerInfoProxy;//第二种trigger的方式

        public TriggerInfoProxy TriggerProxy
        {
            get
            {
                return m_triggerInfoProxy;
            }
        }

        private Dictionary<int, TriggerBound> m_CurrentEnterTriggerList = new Dictionary<int, TriggerBound>(Bokura.ConstValue.kCap32);

        #endregion

        #region 内置函数

        [XLua.BlackList]
        public void Init()
        {
            m_triggerInfoProxy = new TriggerInfoProxy();
            m_triggerInfoProxy.Init();
        }

        [XLua.BlackList]
        public void Clear()
        {
            if (null != m_triggerInfoProxy)
            {
                m_triggerInfoProxy.RemoveAll();
            }
        }

        [XLua.BlackList]
        public void Update()
        {
            if(null != m_triggerInfoProxy)
            {
                m_triggerInfoProxy.Update();
            }
        }

        #endregion

        #region 函数

        public TriggerBound GetCurrentEnterTrigger(int _id)
        {
            TriggerBound _bound = null;
            m_CurrentEnterTriggerList.TryGetValue(_id, out _bound);
            return _bound;
        }

        [XLua.BlackList]
        public void NotifyRemoveAllBound()
        {
            m_CurrentEnterTriggerList.Clear();
            onTriggerBoundRemoveAll.Invoke();
        }

        [XLua.BlackList]
        public void ResetCollisionBound(int _triggerId)
        {
            TriggerBound _boundOut = null;
            if (m_CurrentEnterTriggerList.TryGetValue(_triggerId, out _boundOut))
            {
                m_triggerInfoProxy.ResetCollisionBound(_boundOut);
                m_CurrentEnterTriggerList.Remove(_triggerId);
            }
        }

        [XLua.BlackList]
        public void ProcessTriggerEnterLua(TriggerBound _bound)
        {
            TriggerBound _boundOut = null;
            int _id = _bound.TriggerInfo.Triggerid;
            if (!m_CurrentEnterTriggerList.TryGetValue(_id, out _boundOut))
            {
                m_CurrentEnterTriggerList[_id] = _bound;
            }
            onTriggerBoundEnter.Invoke(_bound);
        }

        [XLua.BlackList]
        public void ProcessTriggerLeaveLua(TriggerBound _bound)
        {
            TriggerBound _boundOut = null;
            int _id = _bound.TriggerInfo.Triggerid;
            if (m_CurrentEnterTriggerList.TryGetValue(_id, out _boundOut))
            {
                m_CurrentEnterTriggerList.Remove(_id);
            }
            onTriggerBoundLeave.Invoke(_bound);
        }

        #endregion
    }
}
