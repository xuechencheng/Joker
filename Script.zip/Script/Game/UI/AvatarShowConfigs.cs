﻿using System;
using UnityEngine;
using System.Collections.Generic;

namespace Bokura
{
    /// <summary>
    /// AvatarShow的配置，包含各个UI界面使用的配置
    /// </summary>
    [CreateAssetMenu(menuName = "UIExtend/AvatarShow Configs", fileName = "config_avatarshow.asset")]
    public class AvatarShowConfigs : ScriptableObject
    {
        public const float kDefaultFOV = 20;

        /// <summary>
        /// 默认配置
        /// </summary>
        [SerializeField]
        private AvatarShowConfig m_FallbackConfig = AvatarShowConfig.identity;
        public AvatarShowConfig fallbackConfig
        {
            get { return m_FallbackConfig; }
#if SCENE_EDITOR
            set { m_FallbackConfig = value; }
#endif
        }

        [SerializeField]
        private List<AvatarShowConfig> m_Configs = null;

        public int Count { get { return m_Configs.Count; } }

        public AvatarShowConfig this[int _Index]
        {
            get
            {
                if (_Index < 0 || _Index > Count) throw new System.IndexOutOfRangeException();
                return m_Configs[_Index];
            }
        }

        public AvatarShowConfig GetConfigByPanelId(int _PanelId)
        {
            if (null != m_Configs)
            {
                for (int tIdx = 0, tCount = Count; tIdx < tCount; tIdx++)
                {
                    if (m_Configs[tIdx].panelId == _PanelId)
                        return m_Configs[tIdx];
                }
            }
            return m_FallbackConfig;
        }

#if SCENE_EDITOR

        public void AddOrUpdateConfig(AvatarShowConfig _NewConfig)
        {
            if (null == m_Configs) m_Configs = new List<AvatarShowConfig>(Const.kCap4);
            int tPanelId = _NewConfig.panelId;
            for (int tIdx = 0, tCount = Count; tIdx < tCount; tIdx++)
            {
                if (m_Configs[tIdx].panelId == tPanelId)
                {
                    m_Configs[tIdx] = _NewConfig;
                    return;
                }
            }
            m_Configs.Add(_NewConfig);
        }

        public void RemoveConfig(int _PanelId)
        {
            if (null != m_Configs)
            {
                for (int tIdx = 0, tCount = Count; tIdx < tCount; tIdx++)
                {
                    if (m_Configs[tIdx].panelId == _PanelId)
                    {
                        m_Configs.RemoveAt(tIdx);
                        break;
                    }
                }
            }
        }
#endif
    }
    
    /// <summary>
    /// 单个模型在指定界面的配置
    /// </summary>
    [System.Serializable]
    public class AvatarShowConfig: IEquatable<AvatarShowConfig>
    {
        /// <summary>
        /// 该配置对应的UI界面的id
        /// </summary>
        public int panelId;
        /// <summary>
        /// 摄像机的位置
        /// </summary>
        public Vector3 camPos;
        /// <summary>
        /// 摄像机的角度
        /// </summary>
        public Vector3 camRot;
        /// <summary>
        /// 场景和角色主光的角度
        /// </summary>
        public Vector3 lightRot;
        /// <summary>
        /// 场景主光的颜色
        /// </summary>
        public Color lightColor = Color.white;
        /// <summary>
        /// 场景主光的强度
        /// </summary>
        public float lightIntensity = 1.0f;
        /// <summary>
        /// 角色主光的颜色
        /// </summary>
        public Color charLightColor = Color.white;
        /// <summary>
        /// 角色主光的强度
        /// </summary>
        public float charLightIntensity = 1.0f;
        /// <summary>
        /// 角色补光的颜色
        /// </summary>
        //public Color camLightColor = Color.black;
        /// <summary>
        /// 角色补光的强度
        /// </summary>
        //public float camLightIntensity = 0.0f;
        /// <summary>
        /// 环境光配置id
        /// </summary>
        public int envLightConfigId = 0;
        /// <summary>
        /// 摄像机fov
        /// </summary>
        public float fieldOfView = AvatarShowConfigs.kDefaultFOV;

        [XLua.BlackList]
        public static AvatarShowConfig identity
        {
            get
            {
                var tDefault                = new AvatarShowConfig();
                tDefault.panelId            = 0;
                tDefault.camPos             = Vector3.zero;
                tDefault.camRot             = Vector3.zero;
                tDefault.lightRot           = new Vector3(50, -30, 0);
                tDefault.lightColor         = Color.white;
                tDefault.lightIntensity     = 1.0f;
                tDefault.charLightColor     = Color.white;
                tDefault.charLightIntensity = 1f;
                //tDefault.camLightColor      = Color.black;
                //tDefault.camLightIntensity  = 0.0f;
                tDefault.envLightConfigId   = 0;
                tDefault.fieldOfView        = AvatarShowConfigs.kDefaultFOV;
                return tDefault;
            }
        }
        public bool Equals(AvatarShowConfig _Other)
        {
            return this.panelId             == _Other.panelId               &&
                this.camPos                 == _Other.camPos                &&
                this.camRot                 == _Other.camRot                &&
                this.lightRot               == _Other.lightRot              &&
                this.lightColor             == _Other.lightColor            &&
                this.lightIntensity         == _Other.lightIntensity        && 
                this.charLightColor         == _Other.charLightColor        &&
                this.charLightIntensity     == _Other.charLightIntensity    &&
                //this.camLightColor          == _Other.camLightColor         &&
                //this.camLightIntensity      == _Other.camLightIntensity     &&
                this.envLightConfigId       == _Other.envLightConfigId      &&
                this.fieldOfView            == _Other.fieldOfView;
        }

        public static bool operator ==(AvatarShowConfig _Left, AvatarShowConfig _Right)
        {
            if (object.ReferenceEquals(_Left, _Right)) return true;
            if (object.ReferenceEquals(null, _Left) || object.ReferenceEquals(null, _Right)) return false;
            return _Left.Equals(_Right);
        }

        public static bool operator !=(AvatarShowConfig _Left, AvatarShowConfig _Right)
        {
            return !(_Left == _Right);
        }

        public override bool Equals(object _Other)
        {
            if (object.ReferenceEquals(_Other, this)) return true;
            if (object.ReferenceEquals(null, _Other) || object.ReferenceEquals(null, this)) return false;
            if (!(_Other is AvatarShowConfig)) return false;
            return Equals((AvatarShowConfig)_Other);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
    /// <summary>
    /// 各个界面的通用配置
    /// </summary>
    [System.Serializable]
    public class AvatarShowPanelConfig
    {
        /// <summary>
        /// 显示AvatarShow的UI界面名称
        /// </summary>
        public string panelName;
        /// <summary>
        /// UI界面对应的id
        /// </summary>
        public int panelId;
        /// <summary>
        /// UI界面中显示AvatarShow的UI节点路径
        /// </summary>
        public string avatarShowPath;
        /// <summary>
        /// UI界面中AvatarShow的背景
        /// </summary>
        public string background;
        /// <summary>
        /// UI界面中使用的RT分辨率
        /// </summary>
        public Vector2Int aspect;
        /// <summary>
        /// UI界面使用的3D场景（非空时，background失效）
        /// </summary>
        public string env3d;
    }
}
