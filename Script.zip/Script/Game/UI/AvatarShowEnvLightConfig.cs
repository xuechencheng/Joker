﻿using UnityEngine;
using System.Collections.Generic;

namespace Bokura
{
    /// <summary>
    /// 环境光配置
    /// </summary>
    [CreateAssetMenu(menuName = "UIExtend/AvatarShow EnvLight Config", fileName = "new envLight config.asset")]
    public class AvatarShowEnvLightConfig : ScriptableObject
    {
        public List<EnvLightConfig> configs = new List<EnvLightConfig>();
        private Dictionary<int, EnvLightConfig> m_Caches = null;
        private void Init()
        {
            if(null != configs)
            {
                m_Caches = new Dictionary<int, EnvLightConfig>(configs.Count);
                for (int tIdx = 0, tCount = configs.Count; tIdx < tCount; tIdx++)
                {
                    EnvLightConfig tConfig = configs[tIdx];
                    m_Caches.Add(tConfig.id, tConfig);
                }
            }
        }
        public EnvLightConfig GetConfigById(int _Id)
        {
            if (null == m_Caches)
                Init();
            EnvLightConfig tConfig = null;
            if(null != m_Caches)
                m_Caches.TryGetValue(_Id, out tConfig);
            return tConfig;
        }
#if SCENE_EDITOR
        public void AddOrUpdateConfig(EnvLightConfig _NewConfig)
        {
            if(null != _NewConfig && null != configs && !string.IsNullOrEmpty(_NewConfig.name))
            {
                //替换同名配置
                int tMaxId = 0;
                for (int tIdx = 0, tCount = configs.Count; tIdx < tCount; tIdx++)
                {
                    var tConfig = configs[tIdx];
                    if (tConfig.name == _NewConfig.name)
                    {
                        tConfig.data = _NewConfig.data;
                        return;
                    }
                    tMaxId = Mathf.Max(tConfig.id, tMaxId);
                }
                //新增配置
                _NewConfig.id = tMaxId + 1;
                configs.Add(_NewConfig);
                m_Caches = null;
            }
        }
        public void RemoveConfig(int _Index)
        {
            if (null != configs && _Index >= 0 && _Index < configs.Count)
                configs.RemoveAt(_Index);
        }
#endif
    }
    [System.Serializable]
    public class EnvLightConfig
    {
        public int id;
        public string name;
        public float[] data = null;

        public bool baked
        {
            get { return null != data && data.Length > 0; }
        }

        private void InitData()
        {
            if (null == data || data.Length < 27)
                data = new float[3 * 9];
        }
        public void SetData(ref UnityEngine.Rendering.SphericalHarmonicsL2 _SHL2)
        {
            for (int tRGB = 0; tRGB < 3; ++tRGB)
            {
                for (int tIdx = 0; tIdx < 9; ++tIdx)
                    data[tRGB * 9 + tIdx] = _SHL2[tRGB, tIdx];
            }
        }
        public void GetData(ref UnityEngine.Rendering.SphericalHarmonicsL2 _SHL2)
        {
            if (null == data || data.Length < 1)
            {
                X2Interface.LogHelper.LogWarning("cube sky data is null!!");
                return;
            }
            for (int tRGB = 0; tRGB < 3; ++tRGB)
            {
                for (int tIdx = 0; tIdx < 9; ++tIdx)
                    _SHL2[tRGB, tIdx] = data[tRGB * 9 + tIdx];
            }
        }
        /// <summary>
        /// 烘焙环境光
        /// </summary>
        public void Bake(Color _SkyColor, Color _EqColor, Color _GroundColor)
        {
            InitData();
            Rendering.SphericalHarmonicsL2 tSH;
            SkyLight.Instance.BakeSkyColorTOSH(_SkyColor, _EqColor, _GroundColor, out tSH);
            SetData(ref tSH);
        }
        /// <summary>
        /// 应用环境光
        /// </summary>
        public void Apply()
        {
            Rendering.SphericalHarmonicsL2 tSH = new Rendering.SphericalHarmonicsL2();
            if(baked)
                GetData(ref tSH);
            SkyLight.Instance.SetSceneState(SkyLight.SCENE_STATE.kAvatarScene);
            SkyLight.Instance.SetupToShader(ref tSH, true, SkyLight.SCENE_STATE.kAvatarScene);
            X2Interface.AvatarShowGIManager.ApplyAvatarShowSetting();
        }
        /// <summary>
        /// 清除环境光
        /// </summary>
        public static void Clear()
        {
            SkyLight.Instance.SetSceneState(SkyLight.SCENE_STATE.KCommonScene);
            X2Interface.AvatarShowGIManager.CancelAvatarShowSetting();
        }
    }
}