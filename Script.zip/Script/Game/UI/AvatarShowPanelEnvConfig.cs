﻿using System;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 各个界面的环境配置
    /// </summary>
    [CreateAssetMenu(menuName = "UIExtend/AvatarShow PanelEnv Config", fileName = "new panel env config.asset")]
    public class AvatarShowPanelEnvConfig : ScriptableObject
    {
        /// <summary>
        /// UI界面对应的id
        /// </summary>
        public int panelId          = 0;
        /// <summary>
        /// 场景的世界位置
        /// </summary>
        public Vector3 envPos       = Vector3.zero;
        /// <summary>
        /// 场景的世界朝向
        /// </summary>
        public Quaternion envRot    = Quaternion.identity;
        /// <summary>
        /// 场景的世界缩放
        /// </summary>
        public Vector3 envScale     = Vector3.one;
    }
}