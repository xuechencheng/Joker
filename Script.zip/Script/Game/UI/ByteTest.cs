﻿using UnityEngine;

namespace Bokura
{
    public class ByteTest : ScriptableObject
    {
        public byte[] m_byte;

        public bool m_Optimal;

        public const int FlagOffset = 31;
        public const uint FlagMask = unchecked((uint)1 << FlagOffset);
        public const uint CountMask = FlagMask - 1;

        public uint[] m_OptByte;

        public bool CheckPixelByByte(int x, int y, int w)
        {
            if(m_Optimal)
            {
                int targetIndex = x + y * w;
                uint curIndex = 0;
                foreach (uint item in m_OptByte)
                {
                    uint offset = item & CountMask;

                    if (offset + curIndex >= targetIndex)
                    {
                        uint retMe = (item & FlagMask) >> FlagOffset;
                        return retMe == 1;
                    }
                    else
                        curIndex += offset;
                }

                return false;
            }
            else
            {
                if (null != m_byte)
                {
                    int index = x + y * w;
                    int btIndex = index / 8;
                    int btle = index % 8;
                    byte btBit = (byte)(1 << (byte)btle);
                    if (btIndex < m_byte.Length)
                    {
                        byte data = m_byte[btIndex];
                        byte bt = (byte)(data & btBit);
                        return bt == btBit;
                    }

                    return false;
                }
                return false;
            }            
        }
    }

}
