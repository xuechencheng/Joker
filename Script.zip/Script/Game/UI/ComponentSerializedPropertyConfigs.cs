﻿namespace UnityEngine.UI.Giant
{
    /// <summary>
    /// 通用的组件属性修改工具的配置文件，包含可修改的组件类型和组件内的属性类型
    /// </summary>
    [CreateAssetMenu(menuName = "UIExtend/ComponentSerializedProperty Configs", fileName = "config_ComponentSerializedProperty.asset")]
    public class ComponentSerializedPropertyConfigs : ScriptableObject
    {
        public ComponentSerializedPropertiesConfig[] configs;
    }



    /// <summary>
    /// 序列化属性的值类型
    /// </summary>
    public enum SerializedPropertyValueType
    {
        Generic         = -1,
        Integer         = 0,
        Boolean         = 1,
        Float           = 2,
        String          = 3,
        Color           = 4,
        ObjectReference = 5,
        LayerMask       = 6,
        Enum            = 7,
        Vector2         = 8,
        Vector3         = 9,
        Vector4         = 10,
        Rect            = 11,
        //12~13
        AnimationCurve  = 14,
        Bounds          = 15,
        Gradient        = 16,
        Quaternion      = 17,
        //18~19
        Vector2Int      = 20,
        Vector3Int      = 21,
        RectInt         = 22,
        BoundsInt       = 23,
        Int64           = 24,
        Double          = 25,
    }



    /// <summary>
    /// 包含同一组件类型中可序列化的属性
    /// </summary>
    [System.Serializable]
    public class ComponentSerializedPropertiesConfig
    {
        public string compName;
        public SerializedPropertyConfig[] propConfigs;
    }



    /// <summary>
    /// 单个可序列化属性的配置
    /// </summary>
    [System.Serializable]
    public class SerializedPropertyConfig
    {
        /// <summary>
        /// 支持属性路径：例如m_Navigation/m_Mode
        /// </summary>
        public string propName;
        /// <summary>
        /// 可序列化属性的显示名称，例如Source Image
        /// </summary>
        [System.NonSerialized]
        public string propDisplayName;
        public SerializedPropertyValueType valueType;
        /// <summary>
        /// AssemblyQualifiedName：例如UnityEngine.UI.Selectable+Transition, UnityEngine.UI
        /// +号连接嵌套类型
        /// </summary>
        public string typeName;
    }
}


