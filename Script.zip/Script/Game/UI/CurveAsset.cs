﻿using UnityEngine;

[CreateAssetMenu(menuName = "UIExtend/UI Curves", fileName = "ui_curves.asset")]
public class CurveAsset: ScriptableObject
{
	public CurveConfig[] curves;
}



[System.Serializable]
public struct CurveConfig
{
	public string name;
	public AnimationCurve curve;
}
