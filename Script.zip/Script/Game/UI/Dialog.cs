using System;
using UnityEngine;
using Bokura;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine.Video;

namespace Bokura
{
    public struct stObjParam
    {
        public string name;
        public string comp;
    }

    public class Dialog
    {
        string m_layoutName;
        GameObject m_baseWindow;
        Int32 m_hashCode;
        bool m_bVisible;
        bool m_bCloseIsHide;
		HashSet<UnityEngine.Events.UnityEventBase> m_unityEvents = new HashSet<UnityEngine.Events.UnityEventBase>();
        LoadCallback m_onLoad;
		private Dictionary<int, Animation> m_Animations = new Dictionary<int, Animation>(Const.kCap2);
        #region property
        public string Layout
        {
            get
            {
                return m_layoutName;
            }
            set
            {
                m_layoutName = value;
                m_hashCode = m_layoutName.GetHashCode();
            }
        }
        public GameObject gameObject
        {
            get
            {
                return m_baseWindow;
            }
        }
        public Int32 HashCode
        {
            get
            {
                return m_hashCode;
            }
        }

        public bool CloseIsHide
        {
            get
            {
                return m_bCloseIsHide;
            }
            set
            {
                m_bCloseIsHide = value;
            }
        }
       
        #endregion
        public Dialog()
        {
            UIManager.Instance.AddDialog(this);
            m_onLoad = this.OnLoad;
        }

        ~Dialog()
        {
            
        }

        public UnityEngine.Component AddComponent(Type componentType)
        {
            UnityEngine.Component component = m_baseWindow.gameObject.GetComponent(componentType);
            if( component)
            {
                return component;
            }

            return m_baseWindow.gameObject.AddComponent(componentType);
        }

        public virtual void OnCreate()
        {          
            IUILoader.Instance.Load(IResourceLoader.strUIPrefabFolder, m_layoutName, IResourceLoader.strPrefabSuffix,m_onLoad);              
        }

        public GameObject LoadSubPart(string layoutname, object parent)
        {
            var parenttransform = parent as Transform;
            if(parenttransform == null && parent!=null)
            {
                var gameobject = parent as GameObject;
                if (gameobject != null)
                    parenttransform = gameobject.transform;
                else
                {
                    var component = parent as Component;
                    if (component != null)
                        parenttransform = component.transform;
                }
            }

            MidRef<GameObject> returngo = new MidRef<GameObject>();
            
            IUILoader.Instance.Load(IResourceLoader.strUIPrefabFolder, layoutname, IResourceLoader.strPrefabSuffix, (UnityEngine.Object o) => 
            {
                if(parenttransform!=null)
                    returngo.obj = GameObject.Instantiate(o as GameObject, parenttransform);
                else
                    returngo.obj = GameObject.Instantiate(o as GameObject, m_baseWindow.transform);
            });

            return returngo.obj;
        }
        void OnLoad(UnityEngine.Object o)
        {
            if (o == null)
            {
                LogHelper.LogError("Load layout: ", m_layoutName, "failed!");
            }
            else
                m_baseWindow = GameObject.Instantiate(o as GameObject);

            if (m_baseWindow)
            {
                //ProcessCloseBtn();
            }
        }

        private void ProcessCloseBtn()
        {
            Button btn =  (Button)GetButtonControl("close");
            if (btn)
            {
                btn.onClick.AddListener( () =>
                {
                    if (m_bCloseIsHide)
                    {
                        SetVisble(false);
                    }
                    else
                    {
                        UIManager.Instance.CloseDialog(this);
                    }
                }
                );
            }
        }

        public virtual void PostShow()
        {
        }

        public virtual void PreClose()
        {
        }

        public void SetVisble(bool bVisble)
        {
            if (m_bVisible != bVisble)
            {
                m_bVisible = bVisble;
                if (!m_baseWindow)
                    return;
                if (m_bVisible)
                {
                    m_baseWindow.SetActive(bVisble);
                    PostShow();
                }
                else
                {
                    PreClose();
                    m_baseWindow.SetActive(bVisble);
                }
            }      
        }

        public virtual void Close()
        {
            SetParent(null);

            if (m_baseWindow)
            {
                var images = m_baseWindow.GetComponentsInChildren<Image>(true);
                for (int i = 0; i < images.Length; i++)
                {
                    images[i].sprite = null;
                }
            }

            foreach (var v in m_unityEvents)
            {
                v.RemoveAllListeners();
            }

            m_unityEvents.Clear();

            if (m_baseWindow)
            {
                GameObject.Destroy(m_baseWindow);
                m_baseWindow = null;
            }
            //IUILoader.Instance.Unload(Utilities.BuildString(IResourceLoader.strUIPrefabFolder, m_layoutName), m_layoutName);
            UIManager.Instance.RemoveDialog(this);
            m_Animations.Clear();
            Resources.UnloadUnusedAssets();
			//预制体被Destroy后，预制体引用的资源的引用计数应该没有马上就被更新，需要延迟一点时间再卸载资源
			GameApplication.Instance.GetTimerManager().AddTimer(() =>
			{
				Resources.UnloadUnusedAssets();
			}, 1.0f);

		}

		public void SetParent(Transform parent)
        {
            if(m_baseWindow != null)
                m_baseWindow.transform.SetParent(parent, false);
        }

        public void SetParent(UILayer layer)
        {
            m_baseWindow.transform.SetParent(UIManager.Instance.GetUILayer(layer), false);
        }
		/// <summary>
		/// 设置层级内的先后关系，0表示最底层
		/// </summary>
		public void SetSibling(int index)
		{
			m_baseWindow.transform.SetSiblingIndex(index);
		}
		public void AddBtnClickListener(Button o, UnityEngine.Events.UnityAction action)
		{
			if (o == null || action == null) return;
			o.onClick.AddListener(action);
			if(!m_unityEvents.Contains(o.onClick))
				m_unityEvents.Add(o.onClick);
		}

        public void RemoveAllBtnClickListener(Button o)
        {
            if (o == null) return;

            o.onClick.RemoveAllListeners();

            if (m_unityEvents.Contains(o.onClick))
                m_unityEvents.Remove(o.onClick);
        }

		public void AddToggleValueChangeListener(Toggle o, UnityEngine.Events.UnityAction<bool> action)
		{
			o.onValueChanged.AddListener(action);
			if (!m_unityEvents.Contains(o.onValueChanged))
				m_unityEvents.Add(o.onValueChanged);
		}

        public bool SetImageByPath(UnityEngine.UI.Image image, string path)
        {
            LuaFastCall.SetImageByPath(image, path);
            return true;
        }

        #region get control interface

        public Transform GetChildTransform(string strName)
        {
            if (m_baseWindow)
                return GetChildTransformRecursive(m_baseWindow.transform, strName);
            else
                return null;
        }

        public RectTransform GetChildRectTransform(string strName)
        {
            RectTransform rectTransform = null;
            if (string.IsNullOrEmpty(strName))
            {
                rectTransform = m_baseWindow.transform.GetComponent<RectTransform>();
            }
            else
            {
                Transform trans = GetChildTransform( strName);
                if (null != trans)
                {
                    rectTransform = trans.GetComponent<RectTransform>();
                }
            }
            return rectTransform;
        }

        public UnityEngine.Object GetChildObject(string strName)
        {
            if (m_baseWindow == null)
                return null;

            if (m_baseWindow.transform == null)
                return null;

            return GetChildObjectRecursive(m_baseWindow.transform, strName);
        }

        public Transform GetChildTransformRecursive(string parentName, string childName)
        {
            return GetChildTransformRecursive(GetChildTransformRecursive(m_baseWindow.transform, parentName),childName);
        }

        public Transform GetChildTransformRecursive(Transform transform, string strName)
        {
            Transform trans = transform.Find(strName);
            if (trans)
                return trans;
            for (int i = 0; i < transform.childCount; ++i)
            {
                trans = transform.GetChild(i);
                trans = GetChildTransformRecursive(trans, strName);
                if (trans)
                    return trans;
            }
            return null;
        }
        public UnityEngine.Object GetChildObjectRecursive(string parentName, string childName)
        {
            return GetChildObjectRecursive(GetChildTransformRecursive(m_baseWindow.transform, parentName), childName);
        }

        public UnityEngine.Object GetChildObjectRecursive(Transform transform, string strName)
        {
            Transform trans = transform.Find(strName);
            if (trans)
                return trans.gameObject;

            UnityEngine.Object obj;
            for (int i = 0; i < transform.childCount; ++i)
            {
                trans = transform.GetChild(i);
                obj = GetChildObjectRecursive(trans, strName);
                if (obj)
                    return obj;
            }
            return null;
        }

        T GetComponent<T>(string strName) where T : UnityEngine.Component
        {
            Transform trans = null;
            if (!string.IsNullOrEmpty(strName))
            {
                trans = GetChildTransform(strName);
            }
            else
            {
                trans = m_baseWindow.transform;
            }
            return trans ? trans.GetComponent<T>() : null;
        }

        public void MapObject(XLua.LuaTable luatable, XLua.LuaTable parasTable)
        {
            Transform trans;
            Component comp;
            string strName;
            stObjParam param;
            for (int i = 1; i <= parasTable.Length; i++)
            {
                parasTable.Get(i, out param);
                if (!string.IsNullOrEmpty(param.name))
                {
                    trans = GetChildTransform(param.name);
                    if (trans)
                    {
                        comp = trans.GetComponent(param.comp);
                        if (comp)
                        {
                            strName = Utilities.BuildString(Bokura.Utilities.BuildString(comp.name, "_", comp.GetType().Name));
                            luatable.Set(strName, comp);
                        }
                    }
                }
            }
        }

        public UnityEngine.UI.Dropdown GetDropDownControl(string strName)
        {
            return GetComponent<Dropdown>(strName);
        }

		public Dropdown2 GetDropDown2Control(string strName)
        {
            return GetComponent<Dropdown2>(strName);
        }

        public VerticalLayoutGroup GetVerticalLayoutGroup(string strName)
        {
            return GetComponent<VerticalLayoutGroup>(strName);
        }

        public HorizontalLayoutGroup GetHorizontalLayoutGroupInChild(UnityEngine.Object parent, string strName)
        {
            return GetComponentInChild<HorizontalLayoutGroup>(parent, strName);
        }

        public UnityEngine.UI.Text GetTextControl(string strName)
        {
            return GetComponent<UnityEngine.UI.Text>(strName);
        }

        public UnityEngine.UI.ScrollRect GetScrollRectControl(string strName)
        {
            return GetComponent<UnityEngine.UI.ScrollRect>(strName);
        }

        public UnityEngine.UI.Button GetButtonControl(string strName)
        {
            return GetComponent<UnityEngine.UI.Button>(strName);
        }

        public UnityEngine.UI.Image GetImageControl(string strName)
        {
            return GetComponent<UnityEngine.UI.Image>(strName);
        }

        public UnityEngine.UI.RawImage GetRawImageControl(string strName)
        {
            return GetComponent<UnityEngine.UI.RawImage>(strName);
        }

        public UnityEngine.UI.Slider GetSliderControl(string strName)
        {
            return GetComponent<UnityEngine.UI.Slider>(strName);
        }

        public UnityEngine.UI.Toggle GetToggleControl(string strName)
        {
            return GetComponent<UnityEngine.UI.Toggle>(strName);
        }

		public UnityEngine.UI.Text GetTextControl(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<UnityEngine.UI.Text>(parent, strName);
		}

		public UnityEngine.CanvasGroup GetCanvasGroupControl(UnityEngine.Object self)
		{
			Transform tTran = ObjectToTransform(self);
			if (tTran != null)
				return tTran.GetComponent<CanvasGroup>();
			return null;
		}

		private T GetComponentInChild<T>(UnityEngine.Object parent, string strName) where T : Component
		{
			T tResult = null;
			if (parent != null && !string.IsNullOrEmpty(strName))
			{
				Transform tParent = ObjectToTransform(parent);
				if (tParent != null)
				{
					Transform tTrans = tParent.Find(strName);
					if (tTrans)
						tResult = tTrans.GetComponent<T>();
				}
			}
			return tResult;
		}

		private Transform ObjectToTransform(UnityEngine.Object obj)
		{
			if(obj != null)
			{
				GameObject tGo = obj as GameObject;
				if (tGo != null)
					return tGo.transform;
				Component tComp = obj as Component;
				if (tComp != null)
					return tComp.transform;
			}
			return null;
		}
        #endregion

        public Vector3 GetDialogPosition()
        {
            return gameObject.transform.localPosition;
        }

        public void SetDialogPosition(Vector3 _pos)
        {
            gameObject.transform.localPosition = _pos;
        }

        public void SetLocalPosition(UnityEngine.Object obj, Vector3 localPos)
        {
            Transform tTran = ObjectToTransform(obj);
            if (tTran != null)
                tTran.localPosition = localPos;
        }

        public void SetLocalPosition(UnityEngine.Object _Obj, float _LocalX, float _LocalY, float _LocalZ)
        {
            Transform tTran = ObjectToTransform(_Obj);
            if (tTran != null)
                tTran.localPosition = new Vector3(_LocalX, _LocalY, _LocalZ);
        }

        public void SetLocalPosition(UnityEngine.Object obj, Vector2 localPos)
        {
            Transform tTran = ObjectToTransform(obj);
            if (tTran != null)
                tTran.localPosition = localPos;
        }

        public void SetLocalRotation(UnityEngine.Object obj, Quaternion localRot)
        {
            Transform tTran = ObjectToTransform(obj);
            if (tTran != null)
                tTran.localRotation = localRot;
        }

        public void SetSizeDelta(UnityEngine.Object obj, Vector2 sizeDelta)
        {
            Transform tTran = ObjectToTransform(obj);
            if (tTran != null)
            {
                RectTransform tRT = tTran as RectTransform;
                if (null != tRT)
                    tRT.sizeDelta = sizeDelta;
            }
        }
        public void SetSizeDelta(UnityEngine.Object obj, float x, float y)
        {
            Transform tTran = ObjectToTransform(obj);
            if (tTran != null)
            {
                RectTransform tRT = tTran as RectTransform;
                if (null != tRT)
                    tRT.sizeDelta = new Vector2(x,y);
            }
        }
        public void SetActive(UnityEngine.Object obj, bool value)
		{
			Transform tTran = ObjectToTransform(obj);
			if(tTran != null)
			{
				GameObject tGo = tTran.gameObject;
				if (tGo.activeSelf != value)
					tGo.SetActive(value);
			}
        }

        public void SetPivot(RectTransform rt, Vector2 pivot)
        {
            if (null != rt)
                rt.pivot = pivot;
        }

        public void SetPivot(RectTransform _RT, float _PivotX, float _PivotY)
        {
            if (null != _RT)
                _RT.pivot = new Vector2(_PivotX, _PivotY);
        }

        public void SetInteractable(Selectable sel, bool value)
		{
			if (sel == null) return;
			sel.interactable = value;
		}

		public void SetFillAmount(Image img, float value)
		{
			if (img == null) return;
			img.fillAmount = value;
		}

		public Vector3 GetLocalPosition(UnityEngine.Object parent, Vector3 worldPos, Camera worldCam)
		{
			Transform tParent = ObjectToTransform(parent);
			if (tParent == null) tParent = m_baseWindow.transform;
			RectTransform tRT = tParent as RectTransform;
			Vector2 tLocalPos = new Vector2();
			if (tRT != null)
			{
				Vector2 tScreenPos = RectTransformUtility.WorldToScreenPoint(worldCam, worldPos);
				Canvas tCanvas = UIManager.Instance.GetCanvas();
				if (tCanvas != null)
				    RectTransformUtility.ScreenPointToLocalPointInRectangle(tRT, tScreenPos, tCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : tCanvas.worldCamera, out tLocalPos);
			}
			return tLocalPos;
		}

		/// <summary>
		/// 获取子对象
		/// </summary>
		public GameObject GetChildGameObject(UnityEngine.Object parent, string childName)
		{
			GameObject tResult = null;
			if (!string.IsNullOrEmpty(childName))
			{
				Transform tChild = null;
				if (parent == null)
					tChild = m_baseWindow.transform.Find(childName);
				else
				{
					Transform tParent = ObjectToTransform(parent);
					if (tParent != null)
						tChild = tParent.Find(childName);
				}
				if (tChild != null)
					tResult = tChild.gameObject;
			}
			return tResult;
		}

		/// <summary>
		/// 实例化预制体
		/// </summary>
		public GameObject GetCopyOfGameObject(GameObject prefab)
		{
			GameObject tResult = null;
			if (prefab != null)
				tResult = GameObject.Instantiate(prefab);
			return tResult;
		}

        public UnityEngine.UI.ScrollRect GetScrollRectInChild(UnityEngine.Object parent, string strName)
        {
            return GetComponentInChild<UnityEngine.UI.ScrollRect>(parent, strName);
        }

        public UnityEngine.UI.Text GetTextInChild(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<UnityEngine.UI.Text>(parent, strName);
		}

		public UnityEngine.UI.Image GetImageInChild(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<UnityEngine.UI.Image>(parent, strName);
        }
        
        public UnityEngine.UI.RawImage GetRawImageInChild(UnityEngine.Object parent, string strName)
        {
            return GetComponentInChild<UnityEngine.UI.RawImage>(parent, strName);
        }

        public UnityEngine.UI.Button GetButtonInChild(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<UnityEngine.UI.Button>(parent, strName);
		}

        public UnityEngine.UI.Toggle GetToggleInChild(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<UnityEngine.UI.Toggle>(parent, strName);
		}

        public SkillBtnIcon GetSkillBtnIconInChild(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<SkillBtnIcon>(parent, strName);
		}

		public SkillJoyStick GetSkillJoyStickInChild(UnityEngine.Object parent, string strName)
		{
			return GetComponentInChild<SkillJoyStick>(parent, strName);
		}

        public UnityEngine.UI.Button GetButtonControl(UnityEngine.Object self)
		{
			Transform tTran = ObjectToTransform(self);
			if (tTran != null)
				return tTran.GetComponent<Button>();
			return null;
		}

        public int GetAnimationControl(UnityEngine.Object self)
		{
			Transform tTran = ObjectToTransform(self);
			if (tTran != null)
			{
				Animation tAnim = tTran.GetComponent<Animation>();
				if (tAnim != null)
				{
					int tID = tAnim.GetInstanceID();
					m_Animations.Add(tID, tAnim);
					return tID;
				}
			}
			return 0;
		}

		public void PlayAnimation(int id, string clipName)
		{
			if (string.IsNullOrEmpty(clipName)) return;
			Animation tAnim = null;
			if (m_Animations.TryGetValue(id, out tAnim))
				tAnim.CrossFade(clipName, 0.1f, PlayMode.StopSameLayer);
		}

        public void PlayAnimationClip(int id, string clipName,float time )
        {
            if (string.IsNullOrEmpty(clipName)) return;
            Animation tAnim = null;
            if (m_Animations.TryGetValue(id, out tAnim))
            {
                var state = tAnim[clipName];
                if (state != null && time > 0.0001f)
                {
                    state.speed = state.length / time;
                }
                tAnim.Play(clipName, PlayMode.StopSameLayer);
            }
        }

        public void PlayAnimationClip(int id, string clipName)
        {
            if (string.IsNullOrEmpty(clipName)) return;
            Animation tAnim = null;
            if (m_Animations.TryGetValue(id, out tAnim))
                tAnim.Play(clipName, PlayMode.StopSameLayer);
        }

        public void StopAnimation(int id)
        {
            Animation tAnim = null;
            if (m_Animations.TryGetValue(id, out tAnim))
                tAnim.Stop();
        }

        public void FindImageAndSetValue(UnityEngine.Object obj, string value)
		{
			Transform tTran = ObjectToTransform(obj);
			if (tTran != null)
			{
				Image tComp = tTran.GetComponent<Image>();
				if (tComp)
					SetImageByPath(tComp, value);
			}
		}

		public void FindImageInChildAndSetValue(UnityEngine.Object parent, string childName, string value)
		{
			Image tComp = GetImageInChild(parent, childName);
			if (tComp != null)
				SetImageByPath(tComp, value);
		}

		public void FindTextInChildAndSetValue(UnityEngine.Object parent, string childName, string value)
		{
			Text tComp = GetTextInChild(parent, childName);
			if (tComp != null)
				tComp.text = value;
		}

		public void FindButtonAndAddListener(UnityEngine.Object obj, UnityAction listener)
		{
			if (obj == null || listener == null) return;
			Transform tTran = ObjectToTransform(obj);
			if (tTran != null)
			{
				Button tComp = tTran.GetComponent<Button>();
				if (tComp)
					tComp.onClick.AddListener(listener);
			}
		}

		public void SetGraphicColor(Graphic g, Color color)
		{
			if (g == null) return;
			g.color = color;
		}

        public void SetGraphicAlpha(Graphic g, float alpha)
        {
            if (g == null) return;
            Color tColor = g.color;
            tColor.a = alpha;
            g.color = tColor;
        }

        public void SetAlpha(CanvasGroup g, float alpha)
        {
            if (g == null) return;
            g.alpha = Mathf.Clamp01(alpha);
        }

        public void BlockRaycast(CanvasGroup g, bool block)
        {
            if (g == null) return;
            g.blocksRaycasts = block;
        }

        public void SetText(Text t, string text)
		{
			if (t == null) return;
			t.text = text;
		}

        public void SetTextColor(Text t, Color color)
        {
            if (t == null) return;
            t.color = color;
        }

        public void SetRawImage(RawImage img, Texture tex)
        {
            if (img == null) return;
            img.texture = tex;
        }

        public void SetRawImage(RawImage img, string texPath)
        {
            if (img == null) return;
            img.texture = UIUtility.GetRawImageByAssetPath(texPath);
        }

        public void SetImage(Image img, string spritePath, bool useNativeSize = false)
        {
            if (img == null) return;
            Sprite tSprite = UIUtility.GetSpriteByPath(spritePath);
            if(useNativeSize && tSprite)
                SetSizeDelta(img, tSprite.rect.size);
            img.sprite = tSprite;
        }

        public void SetImage(Image img, Sprite sprite)
        {
            if (img == null) return;
            img.sprite = sprite;
        }

        public void SetImageColor (Image img, Color color)
        {
            if (null == img) return;
            img.color = color;
        }

        public void SetToggleValue(Toggle tg, bool isOn)
        {
            if (null == tg) return;
            tg.isOn = isOn;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="slider"></param>
        /// <param name="val"></param>
        public void SetSliderValue(Slider slider, float val)
        {
            if (null == slider) return;
            slider.value = val;
        }

        public void SetEnable(UnityEngine.Object obj, bool enable)
        {
            MonoBehaviour tMono = obj as MonoBehaviour;
            if(null != tMono)
                tMono.enabled = enable;
        }

        /// <summary>
        /// 将源对象的世界位置设置为目标对象的世界位置
        /// </summary>
        public void SetWorldPosAs(UnityEngine.Object source, UnityEngine.Object target)
		{
			Transform tSource = ObjectToTransform(source);
			Transform tTarget = ObjectToTransform(target);
			if (tSource != null && tTarget != null)
				tSource.position = tTarget.position;
		}

        /// <summary>
        /// 屏幕坐标系中的点到世界坐标
        /// </summary>
        public Vector3 ScreenPointToWorld(Vector3 point)
        {
            Canvas tCvs = UIManager.Instance.GetCanvas();
            if (null != tCvs)
                RectTransformUtility.ScreenPointToWorldPointInRectangle(tCvs.transform as RectTransform, point, tCvs.renderMode == RenderMode.ScreenSpaceOverlay ? null : tCvs.worldCamera, out point);
            return point;
        }

        /// <summary>
        /// 世界坐标系中的点到屏幕坐标
        /// </summary>
        public Vector3 WorldPointToScreen(Vector3 _Point)
        {
            Canvas tCvs = UIManager.Instance.GetCanvas();
            if (null != tCvs)
                _Point = RectTransformUtility.WorldToScreenPoint(tCvs.renderMode == RenderMode.ScreenSpaceOverlay ? null : tCvs.worldCamera, _Point);
            return _Point;
        }

        /// <summary>
        /// 世界坐标系中的点到屏幕坐标
        /// </summary>
        public Vector3 WorldPointToScreen(float _PosX, float _PosY, float _PosZ)
        {
            return WorldPointToScreen(new Vector3(_PosX, _PosY, _PosZ));
        }

        /// <summary>
        /// 世界坐标系中的点到画布坐标
        /// </summary>
        public Vector3 WorldPointToCanvas(float _PosX, float _PosY, float _PosZ)
        {
            Vector3 tPos = new Vector3(_PosX, _PosY, _PosZ);
            Canvas tCvs = UIManager.Instance.GetCanvas();
            if (null != tCvs)
                tPos = tCvs.transform.worldToLocalMatrix.MultiplyPoint3x4(tPos);
            return tPos;
        }

        /// <summary>
        /// 画布坐标到世界坐标
        /// </summary>
        public Vector3 CanvasToWorldPoint(float _PosX, float _PosY, float _PosZ)
        {
            Vector3 tPos = new Vector3(_PosX, _PosY, _PosZ);
            Canvas tCvs = UIManager.Instance.GetCanvas();
            if (null != tCvs)
                tPos = tCvs.transform.localToWorldMatrix.MultiplyPoint3x4(tPos);
            return tPos;
        }

        /// <summary>
        /// 强制当前UI布局元素自当前向下重建布局
        /// </summary>
        public void ForceRebuildLayout(UnityEngine.Object target)
        {
            RectTransform tRT = null;
            if (target != null)
            {
                GameObject tGo = target as GameObject;
                if (tGo != null)
                    tRT = tGo.GetComponent<RectTransform>();
                if(null == tRT)
                {
                    Component tComp = target as Component;
                    if (tComp != null)
                        tRT = tComp.GetComponent<RectTransform>();
                }
            }
            if (null != tRT)
                LayoutRebuilder.ForceRebuildLayoutImmediate(tRT);
        }

        /// <summary>
        /// 置灰
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="b"></param>
        public void SetGray(UnityEngine.Object obj, bool b,float grayamount = 1)
        {
            var gameobj = obj as UnityEngine.GameObject;
            if (null == gameobj)
            {
                Transform trans = obj as UnityEngine.Transform;
                if (null != trans)
                    gameobj = trans.gameObject;
                else
                {
                    Component tComp = obj as UnityEngine.Component;
                    if (null != tComp)
                        gameobj = tComp.gameObject;
                }
            }

            if (gameobj != null)
            {
                var gray = GrayCompent.Get(gameobj);
                if (gray != null)
                {
                    gray.setGrayCompent(b, grayamount);
                }
            }
        }
    }
}