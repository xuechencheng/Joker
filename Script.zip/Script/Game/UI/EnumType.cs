﻿using System;

namespace Bokura
{
    /// <summary>
    /// AvatarShow类型
    /// </summary>
    public enum AvatarShowType
    {
        None        = 0,
        Character   = 1,
        Npc         = 2,
        Weapon      = 3,
        Mount       = 4,
        Building    = 5,
        SandTable   = 6,
    }
    /// <summary>
    /// 对齐使用的索引类型
    /// </summary>
    public enum SnapIndexType
    {
        /// <summary>
        /// 层级结构的孩子索引
        /// </summary>
        ChildIndex = 0,
        /// <summary>
        /// 位置从左到右、从上到下的排序索引
        /// </summary>
        PosIndex = 1,
    }
    /// <summary>
    /// 奖励领取状态
    /// </summary>
    public enum AwardState
    {
        None = 0,
        /// <summary>
        /// 无法领取
        /// </summary>
        Close = 1,
        /// <summary>
        /// 可以领取
        /// </summary>
        Open = 2,
        /// <summary>
        /// 已经领取
        /// </summary>
        Opened = 3,
    }
    /// <summary>
    /// 颜色改变模式
    /// </summary>
    public enum ColorTweenMode
    {
        None = 0,
        RGB = 1,
        Alpha = 2,
        All = RGB | Alpha,
    }
    /// <summary>
    /// 滑动条可见性
    /// </summary>
    public enum ScrollbarVisibility
    {
        Permanent                   = 0,//一直显示
        AutoHide                    = 1,//没有滚动时隐藏
        AutoHideAndExpandViewport   = 2,//没有滚动时隐藏，同时控制视口的尺寸（Spacing表示视口与滚动条之间的间距）
    }
    /// <summary>
    /// 高亮变化方式
    /// </summary>
    public enum SelectableTransition
    {
        None        = 0,
        ColorTint   = 1,
        SpriteSwap  = 2,
        Animation   = 3
    }
    /// <summary>
    /// Slider的方向
    /// </summary>
    public enum ScrollDirection
    {
        LeftToRight = 0,
        RightToLeft = 1,
        BottomToTop = 2,
        TopToBottom = 3,
    }
    /// <summary>
    /// Toggle切换方式
    /// </summary>
    public enum ToggleTransition
    {
        None = 0,
        Fade = 1
    }
    /// <summary>
    /// 播放状态
    /// </summary>
    [System.Flags]
    public enum PlayState
    {
        Ready = 0,
        /// <summary>
        /// 重新开始
        /// </summary>
        Start = 1,
        /// <summary>
        /// 停止
        /// </summary>
        Stop = 2,
        /// <summary>
        /// 暂停
        /// </summary>
        Pause = 3,
        /// <summary>
        /// 继续
        /// </summary>
        Continue = 4,
        /// <summary>
        /// 播放中
        /// </summary>
        Playing = 5,
    }
    public enum RangeState
    {
        /// <summary>
        /// 在左边界之外
        /// </summary>
        OutOfLeft = -1,
        /// <summary>
        /// 在范围内
        /// </summary>
        InRange = 0,
        /// <summary>
        /// 在右边界之外
        /// </summary>
        OutOfRight = 1,
    }
	public enum TagType
	{
		None = 0x0,
		NumericalValue = 0x1,
		StringValue = 0x2,
		ColorValue = 0x4,
	}
	public enum Edge
	{
		Left = 0,
		Right = 1,
		Top = 2,
		Bottom = 3,
	}
    /// <summary>
    /// 对齐方式
    /// </summary>
    public enum Alignment
    {
        /// <summary>
        /// 上方或左侧对齐
        /// </summary>
        TopLeft = 0,
        /// <summary>
        /// 中间对齐
        /// </summary>
        MiddleCenter = 1,
        /// <summary>
        /// 下方或右侧对齐
        /// </summary>
        BottomRight = 2,
    }
	public enum Axis
	{
		Horizontal = 0,
		Vertical = 1,
	}
    /// <summary>
    /// 滑动方式
    /// </summary>
    public enum MovementType
    {
        /// <summary>
        /// 不受限制，自由滚动
        /// </summary>
        Unrestricted = 0,

        /// <summary>
        /// 受限，可以超出范围，但会回弹
        /// </summary>
        Elastic = 1,

        /// <summary>
        /// 完全受限，不能超出范围
        /// </summary>
        Clamped = 2,
    }
    /// <summary>
    /// 图标在行内的垂直对齐方式
    /// </summary>
    public enum IconAlignment
    {
        Top = 0,
        Middle = 1,
        Bottom = 2,
    }
    /// <summary>
    /// 设置节点缩进的参考边
    /// </summary>
    public enum IndentFromEdge
    {
        Top = 2,    //=Edge.Top, RectTransform.Edge.Top
        Bottom = 3, //=Edge.Bottom, RectTransform.Edge.Bottom
    }
    public enum Corner
    {
        UpperLeft = 0,
        UpperRight = 1,
        LowerLeft = 2,
        LowerRight = 3
    }
    public enum Constraint
    {
        Flexible = 0,
        FixedColumnCount = 1,
        FixedRowCount = 2
    }
    public enum ExpandAnimType
	{
		Immediate,
		Clip,
		Scale
	}
    /// <summary>
    /// 扩展控件的淡入淡出
    /// </summary>
    public enum FadeType
    {
        /// <summary>
        /// 禁用
        /// </summary>
        None    = 0,
        /// <summary>
        /// 仅右侧/下方淡入
        /// </summary>
        In      = 1,
        /// <summary>
        /// 仅左侧/上方淡出
        /// </summary>
        Out     = 2,
        /// <summary>
        /// 同时淡入淡出
        /// </summary>
        All     = In | Out,
    }
    /// <summary>
    /// 指向扩展控件中的基本元素类型 
    /// </summary>
    public enum UIPointedType
    {
        /// <summary>
        /// 背景
        /// </summary>
        Backward = 0,
        /// <summary>
        /// 内容
        /// </summary>
        Content = 1,
        /// <summary>
        /// 未知
        /// </summary>
        None = Byte.MaxValue
    }
    /// <summary>
    /// UI事件类型
    /// </summary>
    public enum UIEventType
	{
		Deselect            = 1 << 0,
		Select              = 1 << 1,
		PointerEnter        = 1 << 2,
		PointerDown         = 1 << 3,
		InitializeDrag      = 1 << 4,
		BeginDrag           = 1 << 5,
        Drag                = 1 << 6,
		PointerUp           = 1 << 7,
		PointerClick        = 1 << 8,
        Drop                = 1 << 9,
		EndDrag             = 1 << 10,
		PointerExit         = 1 << 11,
	}
    /// <summary>
    /// 扩展控件的可拖拽状态
    /// </summary>
    public enum UIDraggableState
    {
        /// <summary>
        /// 不能拖拽
        /// </summary>
        None = 0,
        /// <summary>
        /// 起始位置，可以往左/上拖拽
        /// </summary>
        Begin = 1,
        /// <summary>
        /// 可左右/上下拖拽
        /// </summary>
        Both = 2,
        /// <summary>
        /// 结束位置，可以往右/下拖拽
        /// </summary>
        End = 3,
    }
}
