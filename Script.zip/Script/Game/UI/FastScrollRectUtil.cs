using UnityEngine;
using UnityEngine.UI;
using Bokura;
using System.Collections.Generic;

namespace Bokura
{
    public class ItemLogicData
    {
        private float m_YPos = 0.0f;
        private float m_XPos = 0.0f;
        private float m_Height = 0.0f;
        private ulong m_ID = 0;
        private int m_type = 0;
        public int uniqueID;
        public ulong ID
        {
            get
            {
                return m_ID;
            }
            set
            {
                m_ID = value;
            }
        }
        public int DataType
        {
            get
            {
                return m_type;
            }
            set
            {
                m_type = value;
            }
        }

        public float XPos
        {
            get
            {
                return m_XPos;
            }
            set
            {
                m_XPos = value;
            }
        }
        public float YPos
        {
            get
            {
                return m_YPos;
            }
            set
            {
                m_YPos = value;
            }
        }

        public float Height
        {
            get
            {
                return m_Height;
            }
            set
            {
                m_Height = value;
            }
        }
    }
    public class ScrollItem
    {
        public ScrollItem m_pre = null;
        public ScrollItem m_next = null;
        public int m_iIndex = 0;
        public int m_jIndex = 0;
        private ulong m_ID;
        private Transform m_Transform = null;

        private ItemLogicData m_CurrentData;
        private bool m_bIsLoaded = false;
        private string name = string.Empty;
        public ulong ID
        {
            get
            {
                return m_ID;
            }
            set
            {
                m_ID = value;
            }
        }
        public Transform ItemTransform
        {
            get
            {
                return m_Transform;
            }
            set
            {
                m_Transform = value;
                name = value.name;
            }
        }
        
        public ItemLogicData CurrentData
        {
            set
            {
                m_CurrentData = value;
            }
            get
            {
                return m_CurrentData;
            }
        }
        public void UpdateData(ItemLogicData _Data)
        {
            CurrentData = _Data;
            ItemTransform.name = Utilities.BuildString(name, _Data.uniqueID.ToString());
            if (!m_bIsLoaded)
            {
                m_bIsLoaded = true;
                // OnLoadComponent();
            }
            SetVisible(true);
        }
        public void SetVisible(bool _b)
        {
            bool _bOld = GetIsVisible();
           
            if (_bOld != _b)
            {
                ItemTransform.gameObject.SetActive(_b);
            }
        }

        public bool GetIsVisible()
        {
            return ItemTransform.gameObject.activeSelf;
        }

        public ScrollItem()
        {
            Destory();
        }
        public void Destory()
        {
            if (null != m_Transform)
            {
                //m_Transform.SetParent(null);
                GameObject.Destroy(m_Transform.gameObject);
            }
            ID = 0;
            m_Transform = null;
            m_iIndex = 0;
            m_jIndex = 0;
            m_pre = null;
            m_next = null;
        }
    }
    public class FastScrollRectUtil : MonoBehaviour
    {
        public ScrollRect m_ScrollRect;
        public RectTransform m_Viewport;
        public RectTransform m_Content;
        public RectTransform m_ChildItem;
        protected float m_ItemHeight = 0.0f;
        protected float m_ItemWidth = 0.0f;
        private float m_ViewHeight = 0.0f;
        private ScrollItem m_First = null;
        private ScrollItem m_Last = null;
        private int m_TotalLine = 20;
        private float m_TotalItemHeight = 0.0f;
        private float m_TotalHeight = 0.0f;
        private int m_MaxChildNum = 10;
        private bool m_bIsChangeItemHeight = false;
        private float m_RestoreTime = float.NegativeInfinity;
        private bool m_IsSetScrollEnd = false;
        private int m_ColumnNumber = 1;//列数目
       

        private List<ScrollItem> m_TotalItemArray = new List<ScrollItem>();

        protected List<ItemLogicData> m_netData = new List<ItemLogicData>();
        int uniqueIDCounter;

        public class ScrollItemEvent : GameEvent<ScrollItem>
        {

        }

        public ScrollItemEvent onCreateScrollItem = new ScrollItemEvent();
        public ScrollItemEvent onUpdateScrollItem = new ScrollItemEvent();
        public GameEvent onScrollEnd = new GameEvent();
        public int ColumnNumber
        {
            get
            {
                return m_ColumnNumber;
            }
            set
            {
                m_ColumnNumber = value;
            }
        }
        public bool IsSetScrollEnd
        {
            set
            {
                m_IsSetScrollEnd = value;
            }
            get
            {
                return m_IsSetScrollEnd;
            }
        }
        public float ItemHeight
        {
            get
            {
                return m_ItemHeight;
            }
        }

        public float ItemWidth
        {
            get
            {
                return m_ItemWidth;
            }
        }
        public bool IsChangeItemHeigt
        {
            get
            {
                return m_bIsChangeItemHeight;
            }
            set
            {
                m_bIsChangeItemHeight = value;
            }
        }
        static public FastScrollRectUtil Get(GameObject go)
        {
            FastScrollRectUtil ob = go.GetComponent<FastScrollRectUtil>();
            if (ob == null)
            {
                ob = go.AddComponent<FastScrollRectUtil>();
                ob.setUiData(go);
            }
            return ob;
        }

        protected void setUiData(GameObject go)
        {
            m_ScrollRect = go.transform.GetComponent<UnityEngine.UI.ScrollRect>();
            m_Viewport = LuaFastCall.GetChildTransformRecursive(go.transform, "view_Viewport") as RectTransform;
            m_Content = LuaFastCall.GetChildTransformRecursive(go.transform, "content_frame") as RectTransform;
            m_ChildItem = LuaFastCall.GetChildTransformRecursive(go.transform, "group_childitem") as RectTransform;
            if(null != m_ChildItem)
            {
                m_ItemHeight = m_ChildItem.sizeDelta.y;
                m_ItemWidth = m_ChildItem.sizeDelta.x;
            }
            if(null != m_Viewport)
            {
                m_ViewHeight = m_Viewport.rect.height;
            }

            if(null != m_Viewport && null != m_ChildItem)
            {
                AutoCalcMaxChildNumber();

            }
        }

        void Start()
        {
            if (null != m_ScrollRect)
            {
                m_ScrollRect.onValueChanged.AddListener((Vector2 pos) =>
                {
                    UpdateScrollValueChange();
                    if(IsSetScrollEnd)
                    {
                        m_RestoreTime = UnityEngine.Time.realtimeSinceStartup;
                    }
                });
            }
        }

        private void OnDestroy()
        {
            onCreateScrollItem.RemoveAllListeners();
            onUpdateScrollItem.RemoveAllListeners();
            ClearItem();
        }
        protected FastScrollRectUtil()
        {
#if !UNITY_EDITOR
            m_DoUpdateCallback = DoUpdate;
#endif
        }
#if UNITY_EDITOR
        private void Update()
        {
            DoUpdate();
        }
#else


        private UnityEngine.Events.UnityAction m_DoUpdateCallback;
        private void OnEnable()
        {
            UnityEngine.UI.Giant.UIControlMgr.AddListenerForUpdate(m_DoUpdateCallback);
        }
        private void OnDisable()
        {
            UnityEngine.UI.Giant.UIControlMgr.RemoveListenerForUpdate(m_DoUpdateCallback);
        }
#endif



        private void DoUpdate()
        {
            if (IsSetScrollEnd && !float.IsNegativeInfinity(m_RestoreTime))
            {
                float delTime = UnityEngine.Time.realtimeSinceStartup - m_RestoreTime;
                if (delTime > 0.02)
                {
                    onScrollEnd.Invoke();
                    m_RestoreTime = float.NegativeInfinity;
                }
            }
        }
        public virtual void ClearItem()
        {
            for (int i = 0; i < m_TotalItemArray.Count; i++)
            {
                ScrollItem _curData = m_TotalItemArray[i];
                _curData.Destory();
            }
            m_TotalItemArray.Clear();
        }

        public void AutoCalcMaxChildNumber()
        {
            int _perfectNum = Mathf.FloorToInt(m_ViewHeight / m_ItemHeight) + 1;
            SetMaxChildNumber(_perfectNum * m_ColumnNumber);
        }

        public void SetMaxChildNumber(int _num)
        {
            m_MaxChildNum = _num;
        }

        private ScrollItem CreateItem()
        {
            ScrollItem item = null;
            if (m_ChildItem != null && m_Content != null && m_TotalItemArray.Count < m_MaxChildNum)
            {
                item = new ScrollItem();
                item.ID = (ulong)m_TotalItemArray.Count + 1;
                item.ItemTransform = GameObject.Instantiate(m_ChildItem);
                item.ItemTransform.SetParent(m_Content, false);
                m_TotalItemArray.Add(item);
                onCreateScrollItem.Invoke(item);
            }
            return item;
        }
        private ScrollItem GetItem( int _index)
        {
            ScrollItem item = null;
            if(_index < m_TotalItemArray.Count)
            {
                item = m_TotalItemArray[_index];
            }
            else
            {
                item = CreateItem();
            }

            return item;
        }
        public ScrollItem GetItemByID(ulong id)
        {
            for (int i = 0; i < m_TotalItemArray.Count; ++i)
            {
                var item = m_TotalItemArray[i];
                if (item.ID == id)
                {
                    return item;
                }
            }
            return null;
        }
        public void InitAllItem(int _maxChild =0 )
        {
            if (0!=_maxChild)
            {
                m_MaxChildNum = _maxChild;
            }
            ScrollItem _data = null;
            m_First = null;
            int jInterval = 0;

            for (int i = 0; i < m_MaxChildNum; i++)
            {
                ScrollItem _curData = GetItem(i);
                if(_curData == null)
                {
                    break;
                }
                if (_data != null)
                {
                    _data.m_next = _curData;
                    _curData.m_pre = _data;
                }

                _data = _curData;
                if (null == m_First)
                {
                    m_First = _data;
                }
                _data.m_iIndex = 1;
                _data.m_jIndex = i + 1 + jInterval;
                ResetItemData(_data, 0, _data.m_jIndex);
            }
            m_First.m_pre = _data;
            m_Last = _data;
            m_Last.m_next = m_First;
            ReCalcItemHeight();
        }

        public void UpdateAllItem( bool _bIsReset = false,int _jStartIndex = 0)
        {
            ScrollItem _f = m_First;
            if(null!= _f)
            {
                int _jIndex = _jStartIndex;
                if(_jIndex == 0)
                {
                    _jIndex = 1;
                }
                do
                {
                    int _j = 0;
                    if (_bIsReset)
                    {
                       _j = _f.m_jIndex = _jIndex;
                        _jIndex++;
                    }
                    else
                    {
                        _jIndex = _f.m_jIndex;
                        _j = _jIndex;
                    }
                    ResetItemData(_f, 0, _j);
                    _f = _f.m_next;
                } while (null != _f && _f != m_First);
            }
            ReCalcItemHeight();
        }

        public void RecalcCurrentLogicDataYPos()
        {
            float calcPos = 0;
            for (int i = 0; i < m_netData.Count; i++)
            {
                ItemLogicData _logicData = m_netData[i];
                _logicData.YPos = calcPos;
                calcPos += _logicData.Height;
            }
        }

        public void AddItemLogicData(ItemLogicData _LogicData,bool _bIsResetContent = false)
        {
            _LogicData.uniqueID = ++uniqueIDCounter;

            m_netData.Add(_LogicData);
            m_TotalLine = m_netData.Count;
            if (_bIsResetContent)
            {
                ResetContentHeight();
            }
        }

        public void RemoveItemLogicData( ulong _id)
        {
            if (m_netData != null)
            {
				int tNetDataCount = m_netData.Count;
				for (int i = 0; i < tNetDataCount; i++)
				{
					ItemLogicData _data = m_netData[i];
					if (_data.ID == _id)
					{
						m_netData.RemoveAt(i);
						break;
					}
				}
				m_TotalLine = m_netData.Count;
			}
		}

        public virtual void ReShow()
        {
            int jIndex = GetFirstJIndex();
            Vector2 pos = GetContentPosition();
            ResetContentHeight();
            SetContentYpos(pos.y, jIndex);
        }

        public void ClearLogicData()
        {
            uniqueIDCounter = 0;
            m_netData.Clear();
        }

        public void MoveToEnd(bool _bIsUpdate = true)
        {
            if (m_TotalHeight > m_ViewHeight)
            {
                SetContentPosition(m_Content.localPosition.x, m_TotalHeight - m_ViewHeight);

            }
            else
            {
                SetContentPosition(m_Content.localPosition.x, 0);
            }

            if (_bIsUpdate)
            {
                UpdateScrollValueChange();
            }
        }

        public void MoveToTop(bool _bIsUpdate = true)
        {
            SetContentPosition(m_Content.localPosition.x, 0);
            if (_bIsUpdate)
            {
                UpdateScrollValueChange();
            }
        }

        public void SetContentPosition(float _x,float _y)
        {
            m_Content.localPosition = new Vector2(_x, _y);
        }

        public Vector2 GetContentPosition()
        {
            return m_Content.localPosition;
        }

        public void ResetContentHeight()
        {
            m_TotalHeight = 0.0f;
            if (m_bIsChangeItemHeight)
            {
                if (m_netData != null && m_netData.Count > 0)
                {
                    for (int i = 0; i < m_netData.Count; i++)
                    {
                        if(i% m_ColumnNumber==0)
                        {
                            ItemLogicData _data = m_netData[i];
                            m_TotalHeight += _data.Height;
                        }
                    }
                }
            }
            else
            {
                int _line = m_TotalLine;
                if(m_ColumnNumber>1)
                {
                   
                    _line = m_TotalLine / m_ColumnNumber;
                    if((m_TotalLine % m_ColumnNumber)>0)
                    {
                        _line++;
                    }
                }

                m_TotalHeight = _line * m_ItemHeight;
            }
            m_Content.sizeDelta = new Vector2(m_Content.sizeDelta.x, m_TotalHeight);
        }

        public int SetContentYpos(float _y,int _setIndex)
        {
            int _index = 1;
            if(_y <= 0 || m_TotalHeight < m_ViewHeight)
            {
                _y = 0;
                _index = 1;
            }
            else if(_y+m_ViewHeight > m_TotalHeight )
            {
                _y = m_TotalHeight - m_ViewHeight;
                if(m_netData.Count >= m_TotalItemArray.Count)
                {
                    _index = m_netData.Count - m_TotalItemArray.Count+1;
                }
                else
                {
                    _index = 1;
                }
            }
            else
            {
                _index = _setIndex;
            }
            SetContentPosition(m_Content.localPosition.x, _y);
            UpdateAllItem(true, _index);
            return _index;
        }
        public int GetFirstJIndex()
        {
            int _index = 0;
            if(null != m_First)
            {
                _index = m_First.m_jIndex;
            }

            return _index;
        }
        private void UpdateScrollValueChange()
        {
            float _y = m_Content.localPosition.y;
            bool _bIsChange = false;
            if (null != m_First)
            {
                bool _bIsBreak = false;
                while (!_bIsBreak)
                {
                    if (m_First != null && m_First.GetIsVisible() && m_First.CurrentData != null && _y > m_First.CurrentData.YPos + m_First.CurrentData.Height)//m_First.m_jIndex * m_ItemHeight)
                    {
                        if(null == m_Last)
                        {
                            _bIsBreak = true;
                        }
                        else
                        {
                            int _j = m_Last.m_jIndex;
                            _j++;
                            if (_j <= m_TotalLine)
                            {
                                m_Last = m_First;
                                m_Last.m_jIndex = _j;
                                m_First = m_First.m_next;
                                ResetItemData(m_Last, 0, _j);
                            }
                            else
                            {
                                _bIsBreak = true;
                            }
                            _bIsChange = true;
                        }

                    }
                    else
                    {
                        _bIsBreak = true;
                    }
                }
            }
            if (m_Last != null && !_bIsChange)
            {
                bool _bIsBreak = false;
                while (!_bIsBreak)
                {
                    if (m_Last != null && m_Last.GetIsVisible() && m_Last.CurrentData != null && _y + m_TotalItemHeight < m_Last.CurrentData.YPos + m_Last.CurrentData.Height)//m_Last.m_jIndex * m_ItemHeight)
                    {
                        if(null == m_First)
                        {
                            _bIsBreak = true;
                        }
                        else
                        {
                            int _j = m_First.m_jIndex;
                            _j--;
                            if (_j > 0)
                            {
                                m_First = m_Last;
                                m_First.m_jIndex = _j;
                                m_Last = m_Last.m_pre;
                                ResetItemData(m_First, 0, _j);
                            }
                            else
                            {
                                _bIsBreak = true;
                            }
                            _bIsChange = true;
                        }

                    }
                    else
                    {
                        _bIsBreak = true;
                    }
                }
            }
            if (_bIsChange)
            {
                ReCalcItemHeight();
            }
        }

        private void ReCalcItemHeight()
        {
            m_TotalItemHeight = 0;
            for (int i = 0; i < m_TotalItemArray.Count; i++)
            {
                if(i%m_ColumnNumber==0)
                {
                    ScrollItem _data = m_TotalItemArray[i];
                    float h = m_ItemHeight;
                    if (_data.GetIsVisible() && _data.CurrentData != null)
                    {
                        h = _data.CurrentData.Height;
                    }
                    m_TotalItemHeight += h;
                }
            }
        }

        private void ResetItemData(ScrollItem _data, int _i, int _j)
        {
            int _dataIndex = _j - 1;
            if (null != m_netData && _dataIndex >= 0 && _dataIndex < m_netData.Count)
            {
                ItemLogicData _logicData = m_netData[_dataIndex];
                _data.UpdateData(_logicData);
                if (_logicData != null)
                {
                    _data.ItemTransform.localPosition = new Vector3(_logicData.XPos, -_logicData.YPos, 0);
                    onUpdateScrollItem.Invoke(_data);
                }
            }
            else
            {
                _data.SetVisible(false);
            }
        }

    }
}
