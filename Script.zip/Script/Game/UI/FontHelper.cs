﻿using UnityEngine;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine.UI;

namespace Bokura
{
    /// <summary>
    /// 标签的值类型
    /// </summary>
    public enum TagValueType
    {
        None = 0,
        /// <summary>
        /// 数值
        /// </summary>
        Numerical = 1 << 0,
        /// <summary>
        /// 字符串
        /// </summary>
        String = 1 << 1,
        /// <summary>
        /// 颜色
        /// </summary>
        Color = 1 << 2,
    }



    /// <summary>
    /// 标签解析阶段
    /// </summary>
    public enum TagParsePhase
    {
        /// <summary>
        /// 解析键
        /// </summary>
        Key = 0,
        /// <summary>
        /// 解析值
        /// </summary>
        Value = 1,
        /// <summary>
        /// 空格
        /// </summary>
        Space = 2,
    }




    /// <summary>
    /// 字符UV以及画笔信息
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct CharInfo
    {
        public int      advance;
        public int      maxX;
        public int      maxY;
        public int      minX;
        public int      minY;
        public Vector2  uvBottomLeft;
        public Vector2  uvBottomRight;
        public Vector2  uvTopLeft;
        public Vector2  uvTopRight;
    }



    /// <summary>
    /// 存放指定字体大小、风格的字符信息
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal class FontInformation
    {
        public int                              fontPixelSize;
        public FontStyle                        style;
        private Dictionary<int, CharInfo>       m_Infos = new Dictionary<int, CharInfo>(32);



        public FontInformation Init(int _Size, FontStyle _Style)
        {
            this.fontPixelSize = _Size;
            this.style = _Style;
            return this;
        }



        public void Clear()
        {
            this.m_Infos.Clear();
        }



        public bool TryGetValue(int _Key, out CharInfo _Info)
        {
            return m_Infos.TryGetValue(_Key, out _Info);
        }



        public bool ContainsKey(int _Key)
        {
            return m_Infos.ContainsKey(_Key);
        }



        public void Add(int _Key, CharInfo _Info)
        {
            m_Infos[_Key] = _Info;
        }
    }



    /// <summary>
    /// 相同风格、大小、颜色的文本段
    /// </summary>
    internal struct TextSegment
    {
        /// <summary>
        /// 字体风格
        /// </summary>
        public FontStyle        style;
        /// <summary>
        /// 字体单位大小
        /// </summary>
        public int              size;
        /// <summary>
        /// 字体颜色
        /// </summary>
        public Color32          color;
        /// <summary>
        /// 段在原始文本中的起始索引（include）
        /// </summary>
        public int              start;
        /// <summary>
        /// 段在原始文本中的截止索引（exclude）
        /// </summary>
        public int              end;
        /// <summary>
        /// Quad单位高度(不为0时表示有Quad)
        /// </summary>
        public int              quadSize;
        /// <summary>
        /// 内嵌Quad的单位宽高比
        /// </summary>
        public float            aspect;



        public void Reset(ref TextGenerationSettings _Settings)
        {
            this.style      = _Settings.fontStyle;
            this.size       = _Settings.fontSize;
            this.color      = _Settings.color;
            this.start      = 0;
            this.end        = 0;
            this.quadSize   = 0;
            this.aspect     = 0;
        }
    }



    /// <summary>
    /// 行信息
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public class TextLineInfo
    {
        /// <summary>
        /// 每行的像素长度
        /// </summary>
        public int      length;
        /// <summary>
        /// Y方向顶部坐标
        /// </summary>
        public int      topY;
        /// <summary>
        /// 起始顶点索引
        /// </summary>
        public int      startVertexIdx;
        /// <summary>
        /// 起始字符索引
        /// </summary>
        public int      startCharIdx;
        /// <summary>
        /// 当前行的Ascent
        /// </summary>
        public int      ascent;
        /// <summary>
        /// 当前行的像素高度
        /// </summary>
        public int      height;
    }



    public class FontHelper
    {
        protected FontHelper() { }



        public static int FontAscent;



        private static Dictionary<int, Dictionary<int, FontInformation>> m_FontInfoMap = new Dictionary<int, Dictionary<int, FontInformation>>();



        private static Dictionary<int, int> m_FontTrackes = new Dictionary<int, int>(2);



        public static event System.Action<Font> textureRebuilt;



        private static void RebuildForFont(Font _Font)
        {
#if UI_DEBUG_ENABLE
            Debug.Log("[xjy][ui]<color=yellow>FontHelper:RebuildForFont</color>:" + _Font.name);
#endif
            ClearCache(_Font);
            textureRebuilt?.Invoke(_Font);
        }



        public static void TrackFont(Font _Font)
        {
            if(_Font)
            {
                // The textureRebuilt event is global for all fonts, so we add our delegate the first time we track *any* font
                if (m_FontTrackes.Count == 0)
                    Font.textureRebuilt += RebuildForFont;
                int tFontId = _Font.GetInstanceID();
                int tCount = 1;
                if (m_FontTrackes.ContainsKey(tFontId))
                    tCount += m_FontTrackes[tFontId];
                m_FontTrackes[tFontId] = tCount;
            }
        }



        public static void UntrackFont(Font _Font)
        {
            if (_Font)
            {
                int tFontId = _Font.GetInstanceID();
                int tCount = 0;
                if (m_FontTrackes.TryGetValue(tFontId, out tCount))
                {
                    tCount--;
                    if (tCount <= 0)
                    {
                        ClearCache(_Font);
                        m_FontTrackes.Remove(tFontId);
                        // There is a global textureRebuilt event for all fonts, so once the last font reference goes away, remove our delegate
                        if (m_FontTrackes.Count == 0)
                            Font.textureRebuilt -= RebuildForFont;
                    }
                    else
                        m_FontTrackes[tFontId] = tCount;
                }
            }
        }



        /// <summary>
        /// 清理指定字体的缓存
        /// </summary>
        private static void ClearCache(Font _Font)
        {
            Dictionary<int, FontInformation> tMap = null;
            if (null != _Font)
            {
                int tFontId = _Font.GetInstanceID();
                if (m_FontInfoMap.TryGetValue(tFontId, out tMap))
                {
                    m_FontInfoMap.Remove(tFontId);
                    foreach (var tKV in tMap)
                        FontInformationPool.Recycle(tKV.Value);
                    tMap.Clear();
                }
            }
        }



        /// <summary>
        /// 获取指定字体、指定风格、指定大小的字符信息
        /// </summary>
        internal static FontInformation GetFontInformation(Font _Font, int _Size, FontStyle _Style)
        {
            FontInformation tInfo = null;
            if(null != _Font && _Size >= 0)
            {
                Dictionary<int, FontInformation> tMap = null;
                int tFontId = _Font.GetInstanceID();
                if (!m_FontInfoMap.TryGetValue(tFontId, out tMap) || null == tMap)
                {
                    tMap = new Dictionary<int, FontInformation>(32);
                    m_FontInfoMap[tFontId] = tMap;
                }
                int tKey = UIHelper.GetKeyByFontStyleAndSize(_Style, _Size);
                if (!tMap.TryGetValue(tKey, out tInfo) || null == tInfo)
                {
                    tInfo = FontInformationPool.Spawn().Init(_Size, _Style);
                    tMap[tKey] = tInfo;
                }
            }
            return tInfo;
        } 
      


        internal static void GenerateVertex(VertexArray _Verts, ref CharInfo _CharInfo, float _PixelOffsetX, float _PixelOffsetY, float _UnitPerPixel, ref Color32 _Color)
        {
            //原点在左上角，向下为负
            UISimpleVertex tVert                = new UISimpleVertex();
            float tUnitWidth                    = (_CharInfo.maxX - _CharInfo.minX) * _UnitPerPixel;

            tVert.position                      = new Vector3((_CharInfo.minX + _PixelOffsetX) * _UnitPerPixel, (_CharInfo.maxY - _PixelOffsetY) * _UnitPerPixel);
            tVert.color                         = _Color;
            tVert.uv0                           = _CharInfo.uvTopLeft;
            _Verts.vertices[_Verts.length++]    = tVert;

            tVert.position.x                    = tVert.position.x + tUnitWidth;
            tVert.uv0                           = _CharInfo.uvTopRight;
            _Verts.vertices[_Verts.length++]    = tVert;

            tVert.position.y                    = (_CharInfo.minY - _PixelOffsetY) * _UnitPerPixel;
            tVert.uv0                           = _CharInfo.uvBottomRight;
            _Verts.vertices[_Verts.length++]    = tVert;

            tVert.position.x                    = tVert.position.x - tUnitWidth;
            tVert.uv0                           = _CharInfo.uvBottomLeft;
            _Verts.vertices[_Verts.length++]    = tVert;
        }



        /// <summary>
        /// 给垂直文本用的
        /// </summary>
        internal static void GenerateVerticalVertex(VertexArray _Verts, ref CharInfo _CharInfo, float _QuadPixelHeight, float _PixelOffsetY, float _UnitPerPixel, ref Color32 _Color)
        {
            //水平方向原点在网格中心，向下为负
            UISimpleVertex tVert = new UISimpleVertex();
            float tUnitHalfWidth = (_CharInfo.maxX - _CharInfo.minX) * _UnitPerPixel / 2;
            float tUnitHeight = (_CharInfo.maxY - _CharInfo.minY) * _UnitPerPixel;

            tVert.position = new Vector3(- tUnitHalfWidth, -(_QuadPixelHeight / 2 + _PixelOffsetY) * _UnitPerPixel + tUnitHeight / 2);
            tVert.color = _Color;
            tVert.uv0 = _CharInfo.uvTopLeft;
            _Verts.vertices[_Verts.length++] = tVert;

            tVert.position.x = tUnitHalfWidth;
            tVert.uv0 = _CharInfo.uvTopRight;
            _Verts.vertices[_Verts.length++] = tVert;

            tVert.position.y = tVert.position.y - tUnitHeight;
            tVert.uv0 = _CharInfo.uvBottomRight;
            _Verts.vertices[_Verts.length++] = tVert;

            tVert.position.x = - tUnitHalfWidth;
            tVert.uv0 = _CharInfo.uvBottomLeft;
            _Verts.vertices[_Verts.length++] = tVert;
        }
    }



    /// <summary>
    /// 垂直文本的排列方式
    /// </summary>
    public enum VerticalTextLayout
    {
        LeftToRight,
        RightToLeft,
    }



    /// <summary>
    /// 生成文本顶点所需的额外信息
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct TextGenerationSettingsEx
    {
        /// <summary>
        /// 是否需要检索顶点索引对应的字符索引
        /// </summary>
        public bool needGetCharIdx;



        /// <summary>
        /// 垂直排列
        /// </summary>
        public bool vertical;



        /// <summary>
        /// 垂直文本的字间距
        /// </summary>
        public float cSpacing;



        /// <summary>
        /// 垂直文本的行布局方式
        /// </summary>
        public VerticalTextLayout layout;



        public static TextGenerationSettingsEx defaultSettings = new TextGenerationSettingsEx()
        {
            needGetCharIdx = false,
            vertical = false,
            cSpacing = 0,
            layout = VerticalTextLayout.RightToLeft
        };



        public bool Equals(TextGenerationSettingsEx _Other)
        {
            return this.needGetCharIdx == _Other.needGetCharIdx && 
                this.vertical == _Other.vertical && 
                this.cSpacing == _Other.cSpacing &&
                this.layout == _Other.layout;
        }
    }
}

