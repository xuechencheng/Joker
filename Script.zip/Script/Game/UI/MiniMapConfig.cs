﻿using UnityEngine;

[CreateAssetMenu(menuName = "UIExtend/MiniMap Config", fileName = "config_MiniMap.asset")]
public class MiniMapConfig : ScriptableObject
{
    public float minRadius;
    public float maxRadius;
    public Material iconSharedMat;
    public Material tileSharedMat;
    public string tileMaskSpritePath;
}
