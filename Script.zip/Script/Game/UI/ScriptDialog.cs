using System;
using UnityEngine;

namespace Bokura
{
    class ScriptDialog : Dialog
    {
        string      m_strLuaTableName;
        LuaFunctor  m_postShownFunctor;
        LuaFunctor  m_preCloseFunctor;
        LuaFunctor  m_onCloseFunctor;

        public string LuaTableName
        {
            get
            {
                return m_strLuaTableName;
            }
        }

        public ScriptDialog(string strLayout, string strLuaTable)
        {
            Layout = strLayout;
            m_strLuaTableName = strLuaTable;

            if (string.IsNullOrEmpty(m_strLuaTableName))
            {
                m_postShownFunctor = new LuaFunctor("postShown");
                m_preCloseFunctor = new LuaFunctor("preClose");
                m_onCloseFunctor = new LuaFunctor("onClose");
            }
            else
            {
                m_postShownFunctor = new LuaFunctor(m_strLuaTableName,"postShown");
                m_preCloseFunctor = new LuaFunctor(m_strLuaTableName, "preClose");
                m_onCloseFunctor = new LuaFunctor(m_strLuaTableName, "onClose");
            }
        }

        public override void PostShow()
        {
            if(m_postShownFunctor != null)
                m_postShownFunctor.Call();
        }

        public override void PreClose()
        {
            if(null != m_preCloseFunctor)
                m_preCloseFunctor.Call();
        }

        public override void Close()
        {
            if(null != m_onCloseFunctor)
                m_onCloseFunctor.Call();

            base.Close();
        }

    }
}
