namespace Bokura
{
    class ScriptDialogManager
    {
        static ScriptDialogManager m_instance;
        static public ScriptDialogManager Instance
        {
            get
            {
                if (m_instance == null)
                    m_instance = new ScriptDialogManager();
                return m_instance;
            }
        }

        public ScriptDialogManager()
        {
        }

        public Dialog CreateDialog(string strLayout, string strLuaTable)
        {
            return UIManager.Instance.CreateScriptDialog(strLayout, strLuaTable);
        }

        public void CloseDialog(string strLayout)
        {
            UIManager.Instance.CloseDialog(strLayout);
        }

        public void CloseDialog(Dialog dlg)
        {
            UIManager.Instance.CloseDialog(dlg);
        }

        public Dialog GetDialog(string strLayout)
        {
            return UIManager.Instance.GetDialog(strLayout);
        }

        public UnityEngine.Transform GetUILayer(UILayer layer)
        {
            return UIManager.Instance.GetUILayer(layer);
        }

        public UnityEngine.Transform GetUIRoot()
        {
            return UIManager.Instance.GetUIRoot();
        }

        public UnityEngine.Canvas GetCanvas()
        {
            return UIManager.Instance.GetCanvas();
        }

        public void SetLayerIsVisible(bool _bIsVisible, UILayer _layer)
        {
            UIManager.Instance.SetLayerIsVisible(_bIsVisible, _layer);
        }

        public void SaveAllGameObjectImageReference()
        {
            UIManager.Instance.SaveAllGameObjectImageReference();
        }
    }
}
