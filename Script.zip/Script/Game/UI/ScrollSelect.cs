﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using XLua;

namespace Bokura
{
    public class ScrollSelect : UIBehaviour, IInitializePotentialDragHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IScrollHandler, ICanvasElement
    {
        public ScrollRect hScroll;
        public ScrollRect vScroll;
        private ScrollRect curScroll;

        public void OnInitializePotentialDrag(PointerEventData eventData)
        {
            hScroll.OnInitializePotentialDrag(eventData);
            vScroll.OnInitializePotentialDrag(eventData);
        }
        public void OnBeginDrag(PointerEventData eventData)
        {
            float delX = Mathf.Abs(eventData.delta.x);
            float delY = Mathf.Abs(eventData.delta.y);
            if (delY < delX)
            {
                curScroll = hScroll;
            }
            else
            {
                curScroll = vScroll;
            }
            curScroll.OnBeginDrag(eventData);
        }
        public void OnEndDrag(PointerEventData eventData)
        {
            curScroll.OnEndDrag(eventData);
            curScroll = null;
        }
        public void OnDrag(PointerEventData eventData)
        {
            curScroll.OnDrag(eventData);
        }
        public void OnScroll(PointerEventData eventData)
        {
            curScroll.OnScroll(eventData);
        }
        public void GraphicUpdateComplete()
        {
            curScroll.GraphicUpdateComplete();
        }
        public bool IsDestroy()
        {
            return curScroll.IsDestroyed();
        }

        public void LayoutComplete()
        {
            curScroll.LayoutComplete();
        }

        public void Rebuild(CanvasUpdate executing)
        {
            curScroll.Rebuild(executing);
        }
        static public ScrollSelect Get(GameObject go)
        {
            ScrollSelect listener = go.GetComponent<ScrollSelect>();
            if (listener == null) listener = go.AddComponent<ScrollSelect>();
            return listener;

        }
    }
}