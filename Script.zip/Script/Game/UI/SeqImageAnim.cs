﻿using UnityEngine;
using System.Collections;

public class SeqImageAnim : MonoBehaviour {

	public Sprite[] m_Images;
	public float m_FrameDelay = 0.1f;
	public bool m_IgnorTimeScale = true;
	private int m_nCurFrame;
	private float m_fCurFrame;
	private UnityEngine.UI.Image m_Image;
	// Use this for initialization
	void Start () {
		m_nCurFrame = 0;
		m_fCurFrame = 0.0f;
		m_Image = GetComponent<UnityEngine.UI.Image>();
	}
	
	// Update is called once per frame
	void Update () {

		if(m_Image!=null && m_Images !=null&& m_FrameDelay>0.0f)
		{

			//float now = Time.time/(m_IgnorTimeScale?Time.timeScale) - m_StartPlayTime;
			m_fCurFrame += Time.deltaTime / (m_IgnorTimeScale ? Time.timeScale : 1.0f) / m_FrameDelay;
			if (m_fCurFrame > m_Images.Length)
				m_fCurFrame = m_fCurFrame - (int)(m_Images.Length);
			int nFrame = (int)(m_fCurFrame);
			if (nFrame!=m_nCurFrame)
			{
				m_nCurFrame = nFrame;
				m_Image.sprite = m_Images[m_nCurFrame%m_Images.Length];
			}
			
		}
	}
}
