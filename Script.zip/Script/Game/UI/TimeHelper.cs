
namespace Bokura
{
/// <summary>
/// 用于计算两次更新间隔
/// </summary>
public struct TimeHelper
{
    private long m_LastTime;

    private long m_Interval;

    private bool m_Repeat;

    private bool m_Pause;

    public TimeHelper(float interval ,bool repeat = false)
    {
        m_LastTime = System.DateTime.Now.Ticks;
        m_Interval = (long)(interval * 1E+07f);
        m_Repeat = repeat;
        m_Pause = false;
    }

    /// <summary>
    /// 自上一次调用后，间隔时间是否大于预设值
    /// </summary>
    public bool IsValid()
    {
        if (m_Pause) return false;

        long tCurrent = System.DateTime.Now.Ticks;
        var tDeltaTime = tCurrent - this.m_LastTime;
        bool tIsAchieve = tDeltaTime >= this.m_Interval;
        if (tIsAchieve && m_Repeat)
            this.m_LastTime = tCurrent;

        return tIsAchieve;
    }

    public void Refresh(float interval)
    {
        m_LastTime = System.DateTime.Now.Ticks;
        m_Interval = (long)(interval * 1E+07f);
        m_Interval /= 1000;
    }

    public void Pause(bool _Pause = true)
    {
        m_Pause = _Pause;
        if(!m_Pause)
            m_LastTime = System.DateTime.Now.Ticks;
    }
}

}