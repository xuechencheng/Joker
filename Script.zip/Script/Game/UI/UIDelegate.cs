using System;
using UnityEngine.Events;

namespace Bokura
{
	public delegate bool BoolDelegate();

    public delegate void VoidDelegate();

    public delegate char OnValidateInput(string text, int charIndex, char addedChar);

    //public delegate VertexHelper VertexHelperGetterDelegate(int _Depth, LayerHelper _LayerHelper);

    [Serializable]
    public class SubmitEvent : UnityEvent<string> { }

    [Serializable]
    public class OnChangeEvent : UnityEvent<string> { }

    [Serializable]
    public class FloatEvent : UnityEvent<float> { }

    [Serializable]
    public class IntEvent : UnityEvent<int> { }
    [Serializable]
    public class VoidEvent : UnityEvent { }
}
