using System;
using System.Collections.Generic;
using Bokura;
using UnityEngine;
using System.Text;

namespace Bokura
{
    public enum UILayer
    {
        Base = 0,           
        Main,                  
        Modal,
        Tips,
        Movie,
        Top,
        Loading,
        UpdateWnd,
    }

    public class UILayerComparer : IEqualityComparer<UILayer>
    {
        public bool Equals(UILayer x, UILayer y)
        {
            return x == y;
        }

        public int GetHashCode(UILayer obj)
        {
            return (int)obj;
        }
    }
    public class UILayerData
    {
        public UILayerData(Transform _transform)
        {
            m_transform = _transform;
        }
        public Transform m_transform = null;
        public bool m_bIsVisible = true;
    }
    public class UIManager : ClientSingleton<UIManager>
    {
        private Canvas      m_uiCanvas;
        private Transform   m_uiRoot;
		List<Dialog> m_dialogList = new List<Dialog>();
        Dictionary<UILayer, UILayerData> m_layerList = new Dictionary<UILayer, UILayerData>(new UILayerComparer());
        public List<Dialog> DialogList
        {
            get
            {
                return m_dialogList;
            }
        }

        private bool m_bIsNeedSafeArea = false;
        public bool IsNeedSafeArea
        {
            get
            {
                return m_bIsNeedSafeArea;
            }
        }

        private GameEvent<string> m_OnDialogAdded;
        public GameEvent<string> onDialogAdded
        {
            get { return m_OnDialogAdded; }
        }

        [XLua.BlackList]
        public void Init()
        {
            m_uiRoot = GameObject.Find("UIRoot").transform;
            m_uiCanvas = m_uiRoot.GetComponent<Canvas>();
			m_layerList[UILayer.Base] = new UILayerData(m_uiRoot.transform.Find("LayerBase").transform);
            m_layerList[UILayer.Main] = new UILayerData(m_uiRoot.transform.Find("LayerMain").transform);
            m_layerList[UILayer.Modal] = new UILayerData(m_uiRoot.transform.Find("LayerModal").transform);
            m_layerList[UILayer.Tips] = new UILayerData(m_uiRoot.transform.Find("LayerTips").transform);
            m_layerList[UILayer.Movie] = new UILayerData(m_uiRoot.transform.Find("LayerMovie").transform);
            m_layerList[UILayer.Top] = new UILayerData(m_uiRoot.transform.Find("LayerTop").transform);
            m_layerList[UILayer.Loading] = new UILayerData(m_uiRoot.transform.Find("LayerLoading").transform);
            m_layerList[UILayer.UpdateWnd] = new UILayerData(m_uiRoot.transform.Find("ui_single_UpdateWnd").transform);
            //             DeviceOrientation.LandscapeLeft;
            //             Screen.orientation;
            //             Input.deviceOrientation;
            //             string strDeviceModel = SystemInfo.deviceModel;
            //             if(strDeviceModel == "iPhone10,3" || strDeviceModel == "iPhone10,6"//iphoneX 特殊处理一下
            //                 || strDeviceModel == "iPhone11,8" //iphone xr
            //                 || strDeviceModel == "iPhone11,2" //iphone xs
            //                 || strDeviceModel == "iPhone11,6" //iphone xs max
            //                 )
            //             {
            //                 m_bIsNeedSafeArea = true;
            //                 foreach (var v in m_layerList)
            //                 {
            //                     if( v.Key == UILayer.Main || v.Key == UILayer.Modal
            //                         || v.Key == UILayer.Tips)
            //                     {
            //                         RectTransform rt = v.Value.m_transform as RectTransform;
            //                         rt.offsetMin = new Vector2(70, 0);
            //                         rt.offsetMax = new Vector2(-70, 0);
            //                     }
            //                 }
            //             }
            CheckIsNeedSafeArea();

            m_OnDialogAdded = new GameEvent<string>();
        }

        public void Update()
        {
//             if(m_bIsNeedSafeArea)
//             {
//                 if(Input.deviceOrientation == DeviceOrientation.LandscapeLeft)
//                 {
//                     if(m_CurrentScreenOrientation != ScreenOrientation.LandscapeLeft || m_CurrentScreenOrientation == ScreenOrientation.Unknown)
//                     {
//                         m_CurrentScreenOrientation = Screen.orientation;
//                        // Screen.orientation = ScreenOrientation.LandscapeLeft;
//                         LogHelper.Log("ScreenOrientation.LandscapeLeft");
//                         SetSafeArea(true, false);
//                     }
//                 }
//                 else if(Input.deviceOrientation == DeviceOrientation.LandscapeRight)
//                 {
//                     if (m_CurrentScreenOrientation != ScreenOrientation.LandscapeRight || m_CurrentScreenOrientation == ScreenOrientation.Unknown)
//                     {
//                         m_CurrentScreenOrientation = Screen.orientation;
//                         //Screen.orientation = ScreenOrientation.LandscapeRight;
//                         LogHelper.Log("ScreenOrientation.LandscapeRight");
//                         SetSafeArea(false, true);
//                     }
//                 }
//             }
        }

       // private ScreenOrientation m_CurrentScreenOrientation = ScreenOrientation.Unknown;
        private void CheckIsNeedSafeArea()
        {

            string strDeviceModel = SystemInfo.deviceModel;
            if (strDeviceModel == "iPhone10,3" || strDeviceModel == "iPhone10,6"//iphoneX 特殊处理一下
                || strDeviceModel == "iPhone11,8" //iphone xr
                || strDeviceModel == "iPhone11,2" //iphone xs
                || strDeviceModel == "iPhone11,6" //iphone xs max
                )
            {
                m_bIsNeedSafeArea = true;
                SetSafeArea(true, true);
            }
        }

        private Vector2 m_LeftSafeValue = new Vector2(60.0f,0);
        private Vector2 m_RightSafeValue = new Vector2(-60.0f, 0);
        public Vector2 LeftSafeValue
        {
            get
            {
                return m_LeftSafeValue;
            }
            set
            {
                m_LeftSafeValue = value;
            }
        }

        public Vector2 RightSafeValue
        {
            get
            {
                return m_RightSafeValue;
            }
            set
            {
                m_RightSafeValue = value;
            }
        }


        public void SetSafeArea(bool _bLeft,bool _bRight)
        {
//             if(m_CurrentScreenOrientation != ScreenOrientation.Unknown)
//             {
                foreach (var v in m_layerList)
                {
                    if (v.Key == UILayer.Main || v.Key == UILayer.Modal
                        || v.Key == UILayer.Tips)
                    {
                        RectTransform rt = v.Value.m_transform as RectTransform;
                        if (_bLeft)
                        {
                            rt.offsetMin = m_LeftSafeValue;
                        }
                        else
                        {
                            rt.offsetMin = Vector2.zero;
                        }
                        if (_bRight)
                        {
                            rt.offsetMax = m_RightSafeValue;
                        }
                        else
                        {
                            rt.offsetMax = Vector2.zero;
                        }
                    }
                }
            //}

        }

        public Transform GetUIRoot()
        {
            return m_uiRoot;
        }

        public Canvas GetCanvas()
        {
            return m_uiCanvas;
        }

        public Transform GetUILayer(UILayer layer)
        {
            UILayerData _data;
            if (m_layerList.TryGetValue(layer, out _data))
            {
                
                return _data.m_transform;
            }

            return null;
        }

        public UILayerData GetUILayerData(UILayer layer)
        {
            UILayerData _data;
            if (m_layerList.TryGetValue(layer, out _data))
            {

                return _data;
            }

            return null;
        }

		public float GetScaleFactor()
		{
			
			if (m_uiCanvas)
			{
				return m_uiCanvas.scaleFactor;
			}
			return 1.0f;
		}

        public void AddDialog(Dialog dlg)
        {
            m_dialogList.Add(dlg);
        }

        public void RemoveDialog(Dialog dlg)
        {
            m_dialogList.Remove(dlg);
        }

        public Dialog GetDialog( string strLayout)
        {
            if(!string.IsNullOrEmpty(strLayout))
            {
                Int32 hashCode = strLayout.GetHashCode();
                return GetDialog(hashCode);
            }
            
            return null;
        }
        public Dialog GetDialog(int hashCode)
        {
            for (int i = 0; i < m_dialogList.Count; ++i)
            {
                var dlg = m_dialogList[i];
                if (dlg.HashCode == hashCode)
                    return dlg;
            }
            return null;
        }
        bool IsGameObjectADialog(GameObject go, out Dialog dialog)
        {
            for (int i = 0; i < m_dialogList.Count; ++i)
            {
                var dlg = m_dialogList[i];
                if (dlg.gameObject == go)
                {
                    dialog = dlg;
                    return true;
                }
            }
            dialog = null;
            return false;
        }
        bool IsGameObjectAUILayer(GameObject go, out UILayer layerType)
        {
            var iter = m_layerList.GetEnumerator();
            while (iter.MoveNext())
            {
                var layer = iter.Current.Value;
                
                if (layer != null && layer.m_transform != null && layer.m_transform.gameObject == go)
                {
                    layerType = iter.Current.Key;
                    return true;
                }
            }
            layerType = UILayer.Base;
            return false;
        }
        List<string> controlGameNameTree;
        StringBuilder sbControlFullName = new StringBuilder(32);

        public struct ControlInfo
        {
            public string fullName;

            public enum OwnerType
            {
                UIRoot = 0,

                UILayer_Base = 1,
                UILayer_Main,
                UILayer_Modal,
                UILayer_Tips,
                UILayer_Movie,
                UILayer_Top,
                UILayer_Loading,
                UILayer_UpdateWnd,

                Dialog = 10,
            }

            public OwnerType ownerType;
            public int dialogHashCode;
        }
        public bool GetControlInfo(GameObject go, out ControlInfo ctrlInfo)
        {
            ctrlInfo = new ControlInfo();

            if (go == null)
            {
                return false;
            }

            if (controlGameNameTree == null)
                controlGameNameTree = new List<string>(8);

            Dialog dialog = null;

            Transform parent = go.transform;
            while (parent != null)
            {
                GameObject goParent = parent.gameObject;

                if (goParent == m_uiRoot.gameObject)
                {
                    ctrlInfo.ownerType = ControlInfo.OwnerType.UIRoot;
                    break;
                }

                if (IsGameObjectADialog(goParent, out dialog))
                {
                    ctrlInfo.ownerType = ControlInfo.OwnerType.Dialog;
                    ctrlInfo.dialogHashCode = dialog.HashCode;
                    break;
                }

                UILayer layerType;
                if (IsGameObjectAUILayer(goParent, out layerType))
                {
                    switch (layerType)
                    {
                        case UILayer.Base:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Base; break;
                        case UILayer.Loading:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Loading; break;
                        case UILayer.Main:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Main; break;
                        case UILayer.Modal:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Modal; break;
                        case UILayer.Movie:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Movie; break;
                        case UILayer.Tips:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Tips; break;
                        case UILayer.Top:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_Top; break;
                        case UILayer.UpdateWnd:
                            ctrlInfo.ownerType = ControlInfo.OwnerType.UILayer_UpdateWnd; break;
                        default:
                            Debug.Assert(false, string.Format("unknown ui layer type {0}", layerType)); break;
                    }
                    break;
                }

                controlGameNameTree.Add(goParent.name);

                parent = parent.parent;
            }
            
            for (int i = controlGameNameTree.Count - 1; i >= 0; --i)
            {
                if (sbControlFullName.Length > 0)
                    sbControlFullName.Append('/');
                sbControlFullName.Append(controlGameNameTree[i]);
            }
            
            ctrlInfo.fullName = sbControlFullName.ToString();

            sbControlFullName.Length = 0;
            controlGameNameTree.Clear();

            return true;
        }
        public GameObject FindControlByFullName(ControlInfo.OwnerType ownerType, int dialogHashCode, string fullName)
        {
            Transform parent = null;
            switch (ownerType)
            {
                case ControlInfo.OwnerType.UIRoot:
                    parent = m_uiRoot;
                    break;
                case ControlInfo.OwnerType.Dialog:
                    Dialog dialog = GetDialog(dialogHashCode);
                    if (dialog != null)
                    {
                        parent = dialog.gameObject.transform;
                    }
                    break;
                case ControlInfo.OwnerType.UILayer_Base:
                    parent = m_layerList[UILayer.Base].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_Main:
                    parent = m_layerList[UILayer.Main].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_Modal:
                    parent = m_layerList[UILayer.Modal].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_Tips:
                    parent = m_layerList[UILayer.Tips].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_Movie:
                    parent = m_layerList[UILayer.Movie].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_Top:
                    parent = m_layerList[UILayer.Top].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_Loading:
                    parent = m_layerList[UILayer.Loading].m_transform;
                    break;
                case ControlInfo.OwnerType.UILayer_UpdateWnd:
                    parent = m_layerList[UILayer.UpdateWnd].m_transform;
                    break;
            }
            if (parent != null)
            {
                Transform target = parent.Find(fullName);
                if (target != null)
                {
                    return target.gameObject;
                }
            }
            return null;
        }
        public Dialog CreateScriptDialog(string strLayout, string strLuaTable)
        {
            Dialog dlg = GetDialog(strLayout);
            if (dlg == null)
            {
                if (!string.IsNullOrEmpty(strLayout))
                {
                    dlg = new ScriptDialog(strLayout, strLuaTable);
                    dlg.OnCreate();
                }
            }

            if (dlg != null)
            {
                dlg.SetParent(m_layerList[UILayer.Main].m_transform);
            }

            m_OnDialogAdded?.Invoke(strLayout);

            return dlg;
        }
            
        public void CloseDialog(string strLayout)
        {
            Dialog dlg = GetDialog(strLayout);
            CloseDialog(dlg);
        }

        public void CloseDialog(Dialog dlg)
        {
            if (dlg != null)
            {
                dlg.SetVisble(false);
                dlg.PreClose();
                dlg.Close();
            }
        }
        public void CloseAll(List<string> excludeLayouts = null)
        {
            for (int i = m_dialogList.Count - 1; i >= 0; --i)
            {
                var dialog = m_dialogList[i];
                if (excludeLayouts != null)
                {
                    if (excludeLayouts.IndexOf(dialog.Layout) >= 0)
                        continue;
                }
                CloseDialog(dialog);
            }
        }

        private Vector3 m_delPos = new Vector3(4000, 4000, 0);
        /// <summary>
        /// 设置界面layer是否显示
        /// </summary>
        /// <param name="_bIsVisible">是否显示</param>
        /// <param name="_layer">小于这个layer的才会处理</param>
        public void SetLayerIsVisible(bool _bIsVisible, UILayer _layer)
        {
            int iLayer = (int)_layer;
            for(int i=0;i< iLayer; i++)
            {
                UILayerData _data = GetUILayerData((UILayer)i);
                if(_data != null)
                {
                    if (_data.m_bIsVisible != _bIsVisible)
                    {
                        if (_bIsVisible)
                        {

                            Vector3 _pos = _data.m_transform.position;
                            _data.m_transform.position = _pos + m_delPos;
                        }
                        else
                        {
                            Vector3 _pos = _data.m_transform.position;
                            _data.m_transform.position = _pos - m_delPos;
                        }
                        _data.m_bIsVisible = _bIsVisible;
                    }


                    //transform.gameObject.SetActive(_bIsVisible);
                }
            }
        }

        public bool ToggleSwitchUI()
        {
            //TODO:隐藏UI：关闭canvas_cam
           GameObject uiCamera = GameObject.Find("UI_Camera");
            if(uiCamera)
            {
                //第一方案
                Camera camera = uiCamera.GetComponent<Camera>();
                camera.enabled = !camera.enabled;
                return camera.enabled;
            }
            else
            {
                //第二方案

                m_uiCanvas.enabled = !m_uiCanvas.enabled;
                return m_uiCanvas.enabled;

            }
        }


        /// <summary>
        /// 检查ui那一时刻的图片引用情况
        /// </summary>
        Dictionary<string, List<string>> m_atlasList = null;
        public void SaveAllGameObjectImageReference()
        {
            if(null == m_atlasList)
            {
                m_atlasList = new Dictionary<string, List<string>>(10);
            }
            string _bt = string.Empty;
            m_atlasList.Clear();
            SearchAtlas(GameObject.Find("UIRoot").transform, "");
            foreach(var v in m_atlasList)
            {
                _bt = Utilities.BuildString(_bt,"\nAtlasName:", v.Key);
                int len = v.Value.Count;
                _bt = Utilities.BuildString(_bt, "\nCount:", len.ToString());
                for (int i =0;i< len;i++)
                {
                    _bt = Utilities.BuildString(_bt, "\n","   ",i.ToString(),":", v.Value[i]);
                }
            }
            if(!string.IsNullOrEmpty(_bt))
            {
                byte[] c = new UTF8Encoding().GetBytes(_bt);
                string _path = Utilities.BuildString("uiAtlasReport/", System.DateTime.Now.ToString("yyyyMMdd_HHmmss"), ".bat");
                GameApplication.WriteBytes(_path, c);
                List<swm.TsParamsT> _list = new List<swm.TsParamsT>();
                swm.TsParamsT _xmTs = new swm.TsParamsT();
                _xmTs.key = "{text}";
                _xmTs.value = _path;
                _list.Add(_xmTs);

                NotifyModel.Instance.GetInfoAndDispathTypeEvent(TsInfoID.TS_NORMAL, _list);
            }
            m_atlasList.Clear();
        }

        public void SearchAtlas(Transform t, string objpath)
        {
            if(null != t)
            {
                var imagecomponet = t.GetComponent<UnityEngine.UI.Image>();
                var curpath = Utilities.BuildString(objpath, "/", t.name);

                if (imagecomponet)
                {
                    if (imagecomponet.sprite && imagecomponet.sprite.texture)
                    {
                        string st = Utilities.BuildString("path:", curpath, "   ","spriteName:", imagecomponet.sprite.name);
                        List<string> _stArr = null;
                        if(!m_atlasList.TryGetValue(imagecomponet.sprite.texture.name, out _stArr))
                        {
                            _stArr = new List<string>(1);
                            _stArr.Add(st);
                            m_atlasList[imagecomponet.sprite.texture.name] = _stArr;
                        }
                        else
                        {
                            _stArr.Add(st);
                        }
                    }
                }
                for (int i = 0; i < t.childCount; i++)
                {
                    SearchAtlas(t.GetChild(i), curpath);
                }
            }
        }
        ///
    }
}