﻿using UnityEngine;

namespace Bokura
{
    public class UIPrefabData : ScriptableObject
    {
        public ElementData[] Datas = null;
    }

    /// <summary>
    /// UI元素数据对应的节点类型
    /// </summary>
    public enum PrefabDataType
    {
        //容器
        BASEGROUP           = 0,
        HORIZONTALGROUP     = 1,
        VERTICALGROUP       = 2,
        GRIDGROUP           = 3,
        TOGGLE              = 4,
        TOGGLEGROUP         = 5,
        BUTTON              = 6,
        SLIDER              = 7,
        SCROLLBAR           = 8,
        DROPDOWN            = 9,
        INPUTFIELD          = 10,
        SCROLLVIEW          = 11,
        RECTMASK2D          = 12,
        TREEVIEW            = 13,
        TREENODE            = 14,
        TREELIST            = 15,
        ENHANCEDBUTTON      = 16,
        ENHANCEDTOGGLE      = 17,

        //空
        NORMAL              = 100,

        //元素
        INLINE              = 201,//图文混排
        SPRITE              = 202,
        TEXT                = 203,
        ParticleEffect      = 204,//粒子效果
    }



    public enum BaseFlags
    {
        None                    = 0,
        ActiveSelf              = 1 << 0,
        Enabled                 = 1 << 1,
//         [System.Obsolete("使用LayoutGroup + LayoutElement")]
//         AffectParentSize        = 1 << 2,
        WidthBestFit            = 1 << 3,
        HeightBestFit           = 1 << 4,
        HasLayoutElement        = 1 << 5,
        LayoutElementEnabled    = 1 << 6,
        IgnoreLayout            = 1 << 7,
    }



    public enum ExtendFlags
    {
        None                            = 0,
        //BaseUIElement
        RaycastTarget                   = 1 << 0,
        PreserverAspect                 = 1 << 1,
        FillCenter                      = 1 << 2,
        FillClockwise                   = 1 << 3,
        UseSpriteMesh                   = 1 << 4,
        AlignByGeometry                 = 1 << 5,
        BestFit                         = 1 << 6,
        RichText                        = 1 << 7,
        Outline                         = 1 << 8,
        Shadow                          = 1 << 9,
        UseGraphicAlpha                 = 1 << 10,
        QuadIcon                        = 1 << 11,
        ShowUnderline                   = 1 << 12,
        UseFastGenerator                = 1 << 13,
        SharedByUIExtend                = 1 << 14,

        //Container
        AnimAutoPlay                    = 1 << 0,
        AnimHasSound                    = 1 << 1,
        LayoutGroupChildWidthExpand     = 1 << 2,
        LayoutGroupChildHeightExpand    = 1 << 3,
        LayoutGroupCtrlChildWidth       = 1 << 4,
        LayoutGroupCtrlChildHeight      = 1 << 5,
        LayoutGroupChildScaleWidth      = 1 << 6,
        LayoutGroupChildScaleHeight     = 1 << 7,
        ToggleGroupAllowSwitchOff       = 1 << 8,
        ParticleWorldSpace              = 1 << 9,
        Interactable                    = 1 << 10,
        ToggleIsOn                      = 1 << 11,
        SliderWholeNumbers              = 1 << 12,
        ScrollRectHorizontal            = 1 << 13,
        ScrollRectVertical              = 1 << 14,
        ScrollRectInertial              = 1 << 15,
        TreeListIsVertical              = 1 << 16,
        TreeNodeIsVertical              = 1 << 17,
        HasHorVLayoutGroup              = 1 << 18,
        IsHorizontalLayout              = 1 << 19,
    }




    [System.Serializable]
    public class ElementData
    {
        public string               Name                = string.Empty;
        public int                  NameHash            = 0;
        public short                Uid                 = -1;
        public short                Parent              = -1;
        public short                Depth               = -1;
        public PrefabDataType       DataType            = PrefabDataType.NORMAL;
        public BaseFlags            Flags               = BaseFlags.None;
        public ExtendFlags          ExFlags             = ExtendFlags.None;
        public string               MenuSound           = null;
        public Vector2              Pivot               = new Vector2();
        public Vector2              AnchorMin           = new Vector2();
        public Vector2              AnchorMax           = new Vector2();
        public Vector2              AnchoredPosition    = new Vector2();
        public Quaternion           LocalRotation       = Quaternion.identity;
        public Vector3              LocalScale          = Vector3.one;
        public Vector2              Size                = new Vector2();
		public Vector2				MaxSize				= new Vector2(Const.kMaxFloatValue, Const.kMaxFloatValue);
		public string[]             Fields              = null;
        public string[]             FieldsEx            = null;
    }
}