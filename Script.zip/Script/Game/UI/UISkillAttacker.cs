using UnityEngine;
using System.Collections.Generic;

namespace Bokura
{

	/// <summary>
	/// 空中攻击者 显示
	/// </summary>
	class UISkillAttacker : ClientSingleton<UISkillAttacker>
	{

		const float HIDE_TIME = 5.0f;
		GameObject m_container;
		GameObject m_headTemplate;

		struct AttackInfo
		{
			public Entity m_ety;
			public GameObject m_headIcon;
			public RectTransform m_rectTrans;
			public GameObject m_selected;
			public float m_showTime;
		}
		List<AttackInfo> m_attackers = new List<AttackInfo>(5);
		int m_showCount;
		public UISkillAttacker()
		{
			GameScene.Instance.onAttacked.AddListener(ProcBeAttacked);
		}
		public void SetUIContainer(GameObject container)
		{

			m_container = container;

			m_headTemplate = LuaFastCall.GetChildObject(m_container.transform, "btn_head_template") as GameObject;
			TargetSelector.Instance.onSelectTargetChange.AddListener(ProcLockedChange);

		}

		public void Update()
		{
			if (m_showCount == 0 || m_container == null)
				return;

			float now = Time.time;
			var cameradir = CameraController.Instance.Direction;
			cameradir.y = 0.0f;
			cameradir.Normalize();
			var anglecamera = Utilities.Vector2Angle(cameradir.x, cameradir.z);

			var maincharpos = GameScene.Instance.MainChar.Position;
			for (int i = 0; i < m_attackers.Count; i ++ )
			{
				if (m_attackers[i].m_ety == null)
					continue;
				if( now - m_attackers[i].m_showTime > HIDE_TIME || m_attackers[i].m_ety.Avatar == null)
				{
					var atinfo = m_attackers[i];
					atinfo.m_ety = null;
					m_attackers[i] = atinfo;
					LuaFastCall.SetActive(atinfo.m_headIcon, false);
					m_showCount--;
					continue;
				}

				var dir = m_attackers[i].m_ety.Position - maincharpos;
				dir.y = 0;
				dir.Normalize();
				var angledir = Utilities.Vector2Angle(dir.x, dir.z);
				var diff = Utilities.AngleDiff(anglecamera, angledir);
				if (diff > 90)
					diff = 90;
				if (diff < -90)
					diff = -90;

				//diff = Mathf.Floor(diff / 20.0f);
				diff *= 3.0f;

				m_attackers[i].m_rectTrans.anchoredPosition = new Vector3(diff, 0.0f);

			}


		}

		void ProcLockedChange(Entity ety)
		{
			for(int i = 0; i < m_attackers.Count; i ++ )
			{
				LuaFastCall.SetActive(m_attackers[i].m_selected, m_attackers[i].m_ety == ety);
				//if(ety == m_attackers[i].m_ety)

			}
		}
		
		void ProcBeAttacked(Entity ety)
		{
			if ( TargetSelector.Instance.Selected == null || TargetSelector.Instance.Selected == ety)
			{
				//TargetSelector.Instance.LockTarget(null);
				TargetSelector.Instance.SelectTarget(ety);
                if(GameScene.Instance.MainChar.IsFlying)
                    CameraController.Instance.RotateCameraToEntity(ety);
				//ICameraController.Instance.AnimRotateTo
			}

			if (m_container == null)
				return;
	
			if(m_attackers.Count<5)
			{
				int idx = m_attackers.Count;
				AttackInfo atinfo = new AttackInfo();
				atinfo.m_headIcon = GameObject.Instantiate(m_headTemplate);
				atinfo.m_rectTrans = atinfo.m_headIcon.GetComponent<RectTransform>();
				atinfo.m_rectTrans.SetParent(m_container.transform, false);
				atinfo.m_selected = LuaFastCall.GetChildObject(atinfo.m_rectTrans, "img_selected") as GameObject;
				var btn = atinfo.m_rectTrans.GetComponent<UnityEngine.UI.Button>();
				btn.onClick.AddListener(() => 
				{
					TargetSelector.Instance.SelectTarget(m_attackers[idx].m_ety);
				});
				m_attackers.Add(atinfo);
				AddAttacker(ety);
				return;
			}
			else if(!AddAttacker(ety))
			{
				float fMaxTime = 0.0f;
				int imaxtidx = 0;
				float now = Time.time;
				for(int i = 0; i < m_attackers.Count; i ++ )
				{
					float t = now - m_attackers[i].m_showTime;
					if(t>= fMaxTime)
					{
						imaxtidx = i;
						fMaxTime = t;
					}
				}

				var atinfo = m_attackers[imaxtidx];
				atinfo.m_ety = null;
				m_attackers[imaxtidx] = atinfo;
				AddAttacker(ety);
			}
		}


		bool AddAttacker(Entity ety)
		{
			for (int i = 0; i < m_attackers.Count; i++)
			{
				if (m_attackers[i].m_ety == null)
				{
					AttackInfo atinfo = m_attackers[i];


					atinfo.m_ety = ety;
					atinfo.m_showTime = Time.time;
					LuaFastCall.SetActive(atinfo.m_headIcon, true);
					LuaFastCall.SetActive(atinfo.m_selected, ety == TargetSelector.Instance.Selected);
					m_attackers[i] = atinfo;
					m_showCount++;
					return true;
				}
			}

			return false;
		}

	}

}