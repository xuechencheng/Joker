﻿using UnityEngine;
using System.Runtime.InteropServices;

namespace Bokura
{
    [StructLayout(LayoutKind.Sequential)]
    public struct UISimpleVertex
    {
        public static UISimpleVertex identityVert = new UISimpleVertex
        {
            color       = new Color32(255, 255, 255, 255),
            position    = new Vector3(0.0f, 0.0f, 0.0f),
            uv0         = new Vector2(0.0f, 0.0f)
        };

        public static UISimpleVertex simpleVert;

        public Color32 color;
        public Vector3 position;
        public Vector2 uv0;

        public UISimpleVertex(UIVertex _From)
        {
            this.color      = _From.color;
            this.position   = _From.position;
            this.uv0        = _From.uv0;
        }



        public void CopyFrom(UIVertex vertex)
        {
            uv0         = vertex.uv0;
            color       = vertex.color;
            position    = vertex.position;           
        }
    }



    [StructLayout(LayoutKind.Sequential)]
    public struct UISimpleVertexUV1
    {
        public static UISimpleVertex simpleVert;
        public Color32 color;
        public Vector3 position;
        public Vector2 uv0;
        public Vector2 uv1;



        public void CopyFrom(UIVertex vertex)
        {
            uv0 = vertex.uv0;
            uv1 = vertex.uv1;
            color = vertex.color;
            position = vertex.position;
        }
    }
}