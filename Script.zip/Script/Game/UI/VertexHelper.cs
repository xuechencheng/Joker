using System;
using UnityEngine;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Bokura
{
    public class VertexHelper : IDisposable
    {
        const int kDefaultCapacity = 128;
        const int kResizeCapacity = 512;

        public static VertexHelper Spawn(bool _AddUV1 = false)
        {
            return VertexHelperPool.Spawn().Init(_AddUV1);
        }
        public static VertexHelper Spawn(Mesh _Mesh)
        {
            return VertexHelperPool.Spawn().Init(_Mesh);
        }
        public static void Recycle(VertexHelper _ToRecycle)
        {
            VertexHelperPool.Recycle(_ToRecycle);
        }
        private int m_VertexCapacity = 0;
        private int m_IndexCapacity = 0;
        private Vector3[] m_Positions = null;
        private Color32[] m_Colors = null;
        private Vector2[] m_Uv0s = null;
        private Vector2[] m_Uv1s = null;
        private int[] m_Indices = null;
        private int m_VertexCount = 0;
        private int m_IndexCount = 0;
        private bool m_AddUV1 = false;
        public int currentVertCount
        {
            get { return m_VertexCount; }
        }
        public int currentIndexCount
        {
            get { return m_IndexCount; }
        }
        [Obsolete("Dont Call This Constructor, Call Static Method \'Spawn\' And \'Recycle\' Instead")]
        public VertexHelper()
        {
            InitArray(kDefaultCapacity, kDefaultCapacity * 3);
        }
        public VertexHelper Init(bool _AddUV1 = false)
        {
            if(_AddUV1 != m_AddUV1)
            {
                m_AddUV1 = _AddUV1;
                if (m_AddUV1)
                {
                    if(null == m_Uv1s || m_Uv1s.Length < m_VertexCapacity)
                        m_Uv1s = new Vector2[m_VertexCapacity];
                }
            }
            return this;
        }
        public VertexHelper Init(Mesh _Mesh)
        {
            if(_Mesh)
            {
                m_IndexCount = (int)_Mesh.GetIndexCount(0);
                m_VertexCount = _Mesh.vertexCount;
                ResizeVertexArray(m_VertexCount);
                ResizeIndexArray(m_IndexCount);
                Array.Copy(_Mesh.vertices,      m_Positions,    m_VertexCount);
                Array.Copy(_Mesh.colors32,      m_Colors,       m_VertexCount);
                Array.Copy(_Mesh.uv,            m_Uv0s,         m_VertexCount);
                if (m_AddUV1)
                {
                    var tUV2 = _Mesh.uv2;
                    Array.Copy(tUV2, m_Uv1s, tUV2.Length);
                }
                Array.Copy(_Mesh.GetIndices(0), m_Indices,      m_IndexCount);
            }
            return this;
        }
        ~VertexHelper()
        {
            Dispose();
        }
        private void InitArray(int _VertexCapacity, int _IndexCapacity)
        {
            m_VertexCapacity    = _VertexCapacity;
            m_Positions         = new Vector3[m_VertexCapacity];
            m_Colors            = new Color32[m_VertexCapacity];
            m_Uv0s              = new Vector2[m_VertexCapacity];
            m_IndexCapacity     = _IndexCapacity;
            m_Indices           = new int[m_IndexCapacity];
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void Resize(int _VertexCapacity, int _IndexCapacity)
        {
            ResizeVertexArray(_VertexCapacity);
            ResizeIndexArray(_IndexCapacity);
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void ResizeVertexArray(int _VertexCapacity)
        {
            if (_VertexCapacity > m_VertexCapacity)
            {
                m_VertexCapacity = _VertexCapacity + kResizeCapacity;
                Array.Resize(ref m_Positions, m_VertexCapacity);
                Array.Resize(ref m_Colors, m_VertexCapacity);
                Array.Resize(ref m_Uv0s, m_VertexCapacity);
                if(m_AddUV1)
                    Array.Resize(ref m_Uv1s, m_VertexCapacity);
            }
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void ResizeIndexArray(int _IndexCapacity)
        {
            if (_IndexCapacity > m_IndexCapacity)
            {
                m_IndexCapacity = _IndexCapacity + kResizeCapacity;
                Array.Resize(ref m_Indices, m_IndexCapacity);
            }
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void CopyVertices(int _SourceBeginIdx, int _DestBeginIdx, int _Count)
        {
            Array.Copy(m_Positions, _SourceBeginIdx, m_Positions, _DestBeginIdx, _Count);
            Array.Copy(m_Colors, _SourceBeginIdx, m_Colors, _DestBeginIdx, _Count);
            Array.Copy(m_Uv0s, _SourceBeginIdx, m_Uv0s, _DestBeginIdx, _Count);
            if(m_AddUV1)
                Array.Copy(m_Uv1s, _SourceBeginIdx, m_Uv1s, _DestBeginIdx, _Count);
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void CopyIndices(int _SourceBeginIdx, int _DestBeginIdx, int _Count, int _IdxOffset)
        {
            for (int tIdx = 0; tIdx < _Count; tIdx++)
                m_Indices[_DestBeginIdx++] = m_Indices[_SourceBeginIdx++] + _IdxOffset;
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void CheckVertexCapacity()
        {
            ResizeVertexArray(m_VertexCount + 1);
        }
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void CheckIndexCapacity()
        {
            ResizeIndexArray(m_IndexCount + 3);
        }
        public void Clear()
        {
            m_VertexCount     = 0;
            m_IndexCount      = 0;
        }
        /// <summary>
        /// 返回指定顶点数据
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void PopulateUIVertex(ref UISimpleVertex _Vertex, int _Idx)
        {
            _Vertex.position = m_Positions[_Idx];
            _Vertex.color    = m_Colors[_Idx];
            _Vertex.uv0      = m_Uv0s[_Idx];
        }
        /// <summary>
        /// 返回指定顶点数据
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void PopulateUIVertex(ref UISimpleVertexUV1 _Vertex, int _Idx)
        {
            if (!m_AddUV1) return;
            _Vertex.position = m_Positions[_Idx];
            _Vertex.color    = m_Colors[_Idx];
            _Vertex.uv0      = m_Uv0s[_Idx];
            _Vertex.uv1      = m_Uv1s[_Idx];
        }
        /// <summary>
        /// 修改指定顶点数据
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void SetUIVertex(ref UISimpleVertex _Vertex, int _Idx)
        {
            m_Positions[_Idx]  = _Vertex.position;
            m_Colors[_Idx]     = _Vertex.color;
            m_Uv0s[_Idx]       = _Vertex.uv0;
        }
        /// <summary>
        /// 修改指定顶点数据
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void SetUIVertex(ref UISimpleVertexUV1 _Vertex, int _Idx)
        {
            if (!m_AddUV1) return;
            m_Positions[_Idx]  = _Vertex.position;
            m_Colors[_Idx]     = _Vertex.color;
            m_Uv0s[_Idx]       = _Vertex.uv0;
            m_Uv1s[_Idx]       = _Vertex.uv1;
        }
        /// <summary>
        /// 顶点数据填充到网格
        /// </summary>
        public void FillMesh(Mesh _Mesh)
        {
            _Mesh.Clear();

            if (m_VertexCount >= 65000)
                throw new ArgumentException("Mesh can not have more than 65000 vertices");

            _Mesh.SetVertices(m_Positions,  m_VertexCount);
            _Mesh.SetColors(m_Colors,       m_VertexCount);
            _Mesh.SetUVs(0, m_Uv0s,         m_VertexCount);
            if(m_AddUV1)
                _Mesh.SetUVs(1, m_Uv1s,     m_VertexCount);
            _Mesh.SetTriangles(m_Indices, 0, m_IndexCount);
            _Mesh.RecalculateBounds();
        }
        /// <summary>
        /// 回收数组
        /// </summary>
        public void Dispose()
        {        
            m_Positions     = null;
            m_Colors        = null;
            m_Uv0s          = null;
            m_Uv1s          = null;
            m_Indices       = null;
            Clear();
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddVert(Vector3 _Position, Color32 _Color, Vector2 _UV0)
        {
            CheckVertexCapacity();
            m_Positions[m_VertexCount]    = _Position;
            m_Colors[m_VertexCount]       = _Color;
            m_Uv0s[m_VertexCount]         = _UV0;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddVertNoCheck(Vector3 _Position, Color32 _Color, Vector2 _UV0)
        {
            m_Positions[m_VertexCount]  = _Position;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount]       = _UV0;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddVert(Vector3 _Position, Color32 _Color, Vector2 _UV0, Vector2 _UV1)
        {
            if (!m_AddUV1) return;
            CheckVertexCapacity();
            m_Positions[m_VertexCount]  = _Position;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount]       = _UV0;
            m_Uv1s[m_VertexCount]       = _UV1;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddVertNoCheck(Vector3 _Position, Color32 _Color, Vector2 _UV0, Vector2 _UV1)
        {
            m_Positions[m_VertexCount]  = _Position;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount]       = _UV0;
            m_Uv1s[m_VertexCount]       = _UV1;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddVert(ref UISimpleVertex _Vertex)
        {
            CheckVertexCapacity();
            m_Positions[m_VertexCount]  = _Vertex.position;
            m_Colors[m_VertexCount]     = _Vertex.color;
            m_Uv0s[m_VertexCount]       = _Vertex.uv0;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddVertNoCheck(ref UISimpleVertex _Vertex)
        {
            m_Positions[m_VertexCount]  = _Vertex.position;
            m_Colors[m_VertexCount]     = _Vertex.color;
            m_Uv0s[m_VertexCount]       = _Vertex.uv0;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddVert(ref UIVertex _Vertex)
        {
            CheckVertexCapacity();
            m_Positions[m_VertexCount]  = _Vertex.position;
            m_Colors[m_VertexCount]     = _Vertex.color;
            m_Uv0s[m_VertexCount]       = _Vertex.uv0;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddVertNoCheck(ref UIVertex _Vertex)
        {
            m_Positions[m_VertexCount]  = _Vertex.position;
            m_Colors[m_VertexCount]     = _Vertex.color;
            m_Uv0s[m_VertexCount]       = _Vertex.uv0;
            if (m_AddUV1)
                m_Uv1s[m_VertexCount]   = _Vertex.uv1;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddVert(ref UISimpleVertexUV1 _Vertex)
        {
            if (!m_AddUV1) return;
            CheckVertexCapacity();
            m_Positions[m_VertexCount]  = _Vertex.position;
            m_Colors[m_VertexCount]     = _Vertex.color;
            m_Uv0s[m_VertexCount]       = _Vertex.uv0;
            m_Uv1s[m_VertexCount]       = _Vertex.uv1;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加顶点
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddVertNoCheck(ref UISimpleVertexUV1 _Vertex)
        {
            m_Positions[m_VertexCount]  = _Vertex.position;
            m_Colors[m_VertexCount]     = _Vertex.color;
            m_Uv0s[m_VertexCount]       = _Vertex.uv0;
            m_Uv1s[m_VertexCount]       = _Vertex.uv1;
            m_VertexCount++;
        }
        /// <summary>
        /// 添加三角形索引
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddTriangle(int _Idx0, int _Idx1, int _Idx2)
        {
            CheckIndexCapacity();
            m_Indices[m_IndexCount++] = _Idx0;
            m_Indices[m_IndexCount++] = _Idx1;
            m_Indices[m_IndexCount++] = _Idx2;          
        }
        /// <summary>
        /// 添加三角形顶点索引
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddTriangle012(int _Idx0)
        {
            CheckIndexCapacity();
            m_Indices[m_IndexCount++] = _Idx0;
            m_Indices[m_IndexCount++] = _Idx0 + 1;
            m_Indices[m_IndexCount++] = _Idx0 + 2;
        }
        /// <summary>
        /// 添加三角形顶点索引
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddTriangle012NoCheck(int _Idx0)
        {
            m_Indices[m_IndexCount++] = _Idx0;
            m_Indices[m_IndexCount++] = _Idx0 + 1;
            m_Indices[m_IndexCount++] = _Idx0 + 2;
        }
        /// <summary>
        /// 添加三角形顶点索引
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public void AddTriangle230(int _Idx0)
        {
            CheckIndexCapacity();
            m_Indices[m_IndexCount++] = _Idx0 + 2;
            m_Indices[m_IndexCount++] = _Idx0 + 3;
            m_Indices[m_IndexCount++] = _Idx0;
        }
        /// <summary>
        /// 添加三角形顶点索引
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private void AddTriangle230NoCheck(int _Idx0)
        {
            m_Indices[m_IndexCount++] = _Idx0 + 2;
            m_Indices[m_IndexCount++] = _Idx0 + 3;
            m_Indices[m_IndexCount++] = _Idx0;
        }
        /// <summary>
        /// 添加矩形的四个顶点
        /// </summary>
        public void AddUIVertexQuad(UISimpleVertex[] _Verts)
        {
            int tStartIndex = m_VertexCount;

            ResizeVertexArray(m_VertexCount + 4);
            for (int tIdx = 0; tIdx < 4; tIdx++)
                AddVertNoCheck(ref _Verts[tIdx]);

            ResizeIndexArray(m_IndexCount + 6);
            AddTriangle012NoCheck(tStartIndex);
            AddTriangle230NoCheck(tStartIndex);
        }
        /// <summary>
        /// 一次性添加矩形的4个顶点
        /// </summary>
        public void AddUIVertexQuad(Vector3[] _Positions, Color32 _Color, Vector3[] _QuadUVs)
        {
            int tStartIndex = m_VertexCount;
            ResizeVertexArray(m_VertexCount + 4);
            m_Positions[m_VertexCount]  = _Positions[0];
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[0];

            m_Positions[m_VertexCount]  = _Positions[1];
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[1];

            m_Positions[m_VertexCount]  = _Positions[2];
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[2];

            m_Positions[m_VertexCount]  = _Positions[3];
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[3];

            ResizeIndexArray(m_IndexCount + 6);
            AddTriangle012NoCheck(tStartIndex);
            AddTriangle230NoCheck(tStartIndex);
        }
        /// <summary>
        /// 一次性添加矩形的4个顶点
        /// </summary>
        public void AddUIVertexQuad(Vector3 _Pos0, Vector3 _Pos1, Vector3 _Pos2, Vector3 _Pos3, Color32 _Color, Vector2 _MinUV, Vector2 _MaxUV)
        {
            int tStartIndex = m_VertexCount;
            ResizeVertexArray(m_VertexCount + 4);
            Vector2 tUV                 = new Vector2(_MinUV.x, _MinUV.y);
            m_Positions[m_VertexCount]  = _Pos0;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = tUV;

            tUV.y                       = _MaxUV.y;
            m_Positions[m_VertexCount]  = _Pos1;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = tUV;

            tUV.x                       = _MaxUV.x;
            m_Positions[m_VertexCount]  = _Pos2;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = tUV;

            tUV.y                       = _MinUV.y;
            m_Positions[m_VertexCount]  = _Pos3;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = tUV;

            ResizeIndexArray(m_IndexCount + 6);
            AddTriangle012NoCheck(tStartIndex);
            AddTriangle230NoCheck(tStartIndex);
        }
        /// <summary>
        /// 一次性添加矩形的4个顶点
        /// </summary>
        public void AddUIVertexQuad(Vector3 _Pos0, Vector3 _Pos1, Vector3 _Pos2, Vector3 _Pos3, Color32 _Color, Vector3[] _QuadUVs)
        {
            int tStartIndex = m_VertexCount;
            ResizeVertexArray(m_VertexCount + 4);

            m_Positions[m_VertexCount]  = _Pos0;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[0];

            m_Positions[m_VertexCount]  = _Pos1;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[1];

            m_Positions[m_VertexCount]  = _Pos2;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[2];

            m_Positions[m_VertexCount]  = _Pos3;
            m_Colors[m_VertexCount]     = _Color;
            m_Uv0s[m_VertexCount++]     = _QuadUVs[3];

            ResizeIndexArray(m_IndexCount + 6);
            AddTriangle012NoCheck(tStartIndex);
            AddTriangle230NoCheck(tStartIndex);
        }
        /// <summary>
        /// 添加矩形的四个顶点
        /// </summary>
        public void AddUIVertexQuad(ref UISimpleVertex _Vertex0, ref UISimpleVertex _Vertex1, ref UISimpleVertex _Vertex2, ref UISimpleVertex _Vertex3)
        {
            int tStartIndex = m_VertexCount;

            ResizeVertexArray(m_VertexCount + 4);
            AddVertNoCheck(ref _Vertex0);
            AddVertNoCheck(ref _Vertex1);
            AddVertNoCheck(ref _Vertex2);
            AddVertNoCheck(ref _Vertex3);

            ResizeIndexArray(m_IndexCount + 6);
            AddTriangle012NoCheck(tStartIndex);
            AddTriangle230NoCheck(tStartIndex);
        }
        /// <summary>
        /// 添加矩形的四个顶点
        /// </summary>
        public void AddUIVertexQuad(UISimpleVertexUV1[] _Verts)
        {
            if (!m_AddUV1) return;
            int tStartIndex = m_VertexCount;

            ResizeVertexArray(m_VertexCount + 4);
            for (int tIdx = 0; tIdx < 4; tIdx++)
                AddVertNoCheck(ref _Verts[tIdx]);

            ResizeIndexArray(m_IndexCount + 6);
            AddTriangle012NoCheck(tStartIndex);
            AddTriangle230NoCheck(tStartIndex);
        }
        /// <summary>
        /// 添加顶点数据：构造三角形的顶点位置由_Indices指定
        /// </summary>
        public void AddUIVertexStream(List<UISimpleVertex> _Verts, List<int> _Indices)
        {
            if (null == _Verts || null == _Indices) return;
            int tStartIndex = m_VertexCount;
            int tVertexCount = _Verts.Count;

            ResizeVertexArray(m_VertexCount + tVertexCount);
            for (int tIdx = 0; tIdx < tVertexCount; tIdx++)
            {
                UISimpleVertex tVertex = _Verts[tIdx];
                AddVertNoCheck(ref tVertex);
            }

            int tIndexCount = _Indices.Count;
            ResizeIndexArray(m_IndexCount + tIndexCount);
            for (int tIdx = 0; tIdx < tIndexCount; tIdx++)
                m_Indices[m_IndexCount++] = _Indices[tIdx] + tStartIndex;
        }
        /// <summary>
        /// 添加顶点数据：构造三角形的顶点位置由_Indices指定
        /// </summary>
        public void AddUIVertexStream(List<UISimpleVertexUV1> _Verts, List<int> _Indices)
        {
            if (!m_AddUV1 || null == _Verts || null == _Indices) return;
            int tStartIndex = m_VertexCount;
            int tVertexCount = _Verts.Count;
            ResizeVertexArray(m_VertexCount + tVertexCount);
            for (int tIdx = 0; tIdx < tVertexCount; tIdx++)
            {
                UISimpleVertexUV1 tVertex = _Verts[tIdx];
                AddVertNoCheck(ref tVertex);
            }

            int tIndexCount = _Indices.Count;
            ResizeIndexArray(m_IndexCount + tIndexCount);
            for (int tIdx = 0; tIdx < tIndexCount; tIdx++)
                m_Indices[m_IndexCount++] = _Indices[tIdx] + tStartIndex;
        }
        /// <summary>
        /// 添加顶点数据并变换顶点位置：构造三角形的顶点位置由_Indices指定
        /// </summary>
        public void AddUIVertexStream(List<Vector3> _Positions, List<Color32> _Colors, List<Vector2> _UVs, List<int> _Indices, ref Matrix4x4 _Matrix)
        {
            if (null == _Positions || null == _Colors || null == _UVs || null == _Indices) return;
            int tStartIndex = m_VertexCount;
            int tVertexCount = _Positions.Count;
            ResizeVertexArray(m_VertexCount + tVertexCount);
            for (int tIdx = 0; tIdx < tVertexCount; tIdx++)
                AddVertNoCheck(_Matrix.MultiplyPoint3x4(_Positions[tIdx]), _Colors[tIdx], _UVs[tIdx]);

            int tIndexCount = _Indices.Count;
            ResizeIndexArray(m_IndexCount + tIndexCount);
            for (int tIdx = 0; tIdx < tIndexCount; tIdx++)
                m_Indices[m_IndexCount++] = _Indices[tIdx] + tStartIndex;
        }
        /// <summary>
        /// 添加顶点数据并变换顶点位置：构造三角形的顶点位置由_Indices指定
        /// </summary>
        public void AddUIVertexStream(Vector2[] _Positions, Color32 _Color, Vector2[] _UVs, ushort[] _Indices, ref Matrix4x4 _Matrix)
        {
            if (null == _Positions || null == _UVs || null == _Indices) return;
            int tStartIndex = m_VertexCount;
            int tVertexCount = _Positions.Length;
            ResizeVertexArray(m_VertexCount + tVertexCount);
            for (int tIdx = 0; tIdx < tVertexCount; tIdx++)
                AddVertNoCheck(_Matrix.MultiplyPoint3x4(_Positions[tIdx]), _Color, _UVs[tIdx]);

            int tIndexCount = _Indices.Length;
            ResizeIndexArray(m_IndexCount + tIndexCount);
            for (int tIdx = 0; tIdx < tIndexCount; tIdx++)
                m_Indices[m_IndexCount++] = _Indices[tIdx] + tStartIndex;
        }
        /// <summary>
        /// 添加顶点数据，每三个顶点表示一个三角形
        /// </summary>
        public void AddUIVertexTriangleStream(List<UISimpleVertex> _Verts)
        {
            if(null != _Verts)
            {
                int tVertexCount = _Verts.Count;
                ResizeVertexArray(m_VertexCount + tVertexCount);
                ResizeIndexArray(m_IndexCount + tVertexCount);
                UISimpleVertex tVertex;
                for (int tIdx = 0; tIdx < tVertexCount; tIdx += 3)
                {
                    int tStartIndex = m_VertexCount;
                    tVertex = _Verts[tIdx];
                    AddVertNoCheck(ref tVertex);
                    tVertex = _Verts[tIdx + 1];
                    AddVertNoCheck(ref tVertex);
                    tVertex = _Verts[tIdx + 2];
                    AddVertNoCheck(ref tVertex);
                    AddTriangle012NoCheck(tStartIndex);
                }
            }
        }
        /// <summary>
        /// 添加顶点数据，每三个顶点表示一个三角形
        /// </summary>
        public void AddUIVertexTriangleStream(List<UISimpleVertexUV1> _Verts)
        {
            if (null != _Verts && m_AddUV1)
            {
                int tVertexCount = _Verts.Count;
                ResizeVertexArray(m_VertexCount + tVertexCount);
                ResizeIndexArray(m_IndexCount + tVertexCount);
                UISimpleVertexUV1 tVertex;
                for (int tIdx = 0; tIdx < tVertexCount; tIdx += 3)
                {
                    int tStartIndex = m_VertexCount;
                    tVertex = _Verts[tIdx];
                    AddVertNoCheck(ref tVertex);
                    tVertex = _Verts[tIdx + 1];
                    AddVertNoCheck(ref tVertex);
                    tVertex = _Verts[tIdx + 2];
                    AddVertNoCheck(ref tVertex);
                    AddTriangle012NoCheck(tStartIndex);
                }
            }
        }
        /// <summary>
        /// 添加顶点数据，每四个顶点表示一个矩形
        /// </summary>
        public void AddUIVertexQuadStream(List<UISimpleVertex> _Verts)
        {
            if(null != _Verts)
            {
                UISimpleVertex tVertex;
                int tVertexCount = _Verts.Count;
                ResizeVertexArray(m_VertexCount + tVertexCount);
                ResizeIndexArray(m_IndexCount + tVertexCount * 3 / 2);
                for (int tIdx = 0; tIdx < tVertexCount; )
                {
                    int tStartIndex = m_VertexCount;
                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    AddTriangle012NoCheck(tStartIndex);
                    AddTriangle230NoCheck(tStartIndex);
                }
            }
        }
        /// <summary>
        /// 添加顶点数据，每四个顶点表示一个矩形
        /// </summary>
        public void AddUIVertexQuadStream(VertexArray _Array)
        {
            if (null != _Array)
            {
                int tVertexCount = _Array.length;
                ResizeVertexArray(m_VertexCount + tVertexCount);
                ResizeIndexArray(m_IndexCount + tVertexCount * 3 / 2);
                for (int tIdx = 0; tIdx < tVertexCount;)
                {
                    int tStartIndex = m_VertexCount;
                    AddVertNoCheck(ref _Array.vertices[tIdx++]);
                    AddVertNoCheck(ref _Array.vertices[tIdx++]);
                    AddVertNoCheck(ref _Array.vertices[tIdx++]);
                    AddVertNoCheck(ref _Array.vertices[tIdx++]);

                    AddTriangle012NoCheck(tStartIndex);
                    AddTriangle230NoCheck(tStartIndex);
                }
            }
        }
        /// <summary>
        /// 添加顶点数据，每四个顶点表示一个矩形
        /// </summary>
        public void AddUIVertexQuadStream(IList<UIVertex> _Verts)
        {
            if (null != _Verts)
            {
                UIVertex tVertex;
                int tVertexCount = _Verts.Count;
                ResizeVertexArray(m_VertexCount + tVertexCount);
                ResizeIndexArray(m_IndexCount + tVertexCount * 3 / 2);
                for (int tIdx = 0; tIdx < tVertexCount;)
                {
                    int tStartIndex = m_VertexCount;
                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    tVertex = _Verts[tIdx++];
                    AddVertNoCheck(ref tVertex);

                    AddTriangle012NoCheck(tStartIndex);
                    AddTriangle230NoCheck(tStartIndex);
                }
            }
        }
        /// <summary>
        /// 获取顶点数据，每三个顶点表示一个三角形
        /// </summary>
        public void GetUIVertexStream(List<UISimpleVertex> _Stream)
        {
            if (null != _Stream)
            {
                _Stream.Clear();
                if (_Stream.Capacity < m_IndexCount)
                    _Stream.Capacity = m_IndexCount;
                var tVertex = new UISimpleVertex();
                for (int tIdx = 0; tIdx < m_IndexCount; ++tIdx)
                {
                    var tVertexIdx      = m_Indices[tIdx];
                    tVertex.position    = m_Positions[tVertexIdx];
                    tVertex.color       = m_Colors[tVertexIdx];
                    tVertex.uv0         = m_Uv0s[tVertexIdx];
                    _Stream.Add(tVertex);
                }
            }
        }
        /// <summary>
        /// 获取顶点数据，每三个顶点表示一个三角形
        /// </summary>
        public void GetUIVertexStream(List<UISimpleVertexUV1> _Stream)
        {
            if (null != _Stream && m_AddUV1)
            {
                _Stream.Clear();
                if (_Stream.Capacity < m_IndexCount)
                    _Stream.Capacity = m_IndexCount;
                var tVertex = new UISimpleVertexUV1();
                for (int tIdx = 0; tIdx < m_IndexCount; ++tIdx)
                {
                    var tVertexIdx      = m_Indices[tIdx];
                    tVertex.position    = m_Positions[tVertexIdx];
                    tVertex.color       = m_Colors[tVertexIdx];
                    tVertex.uv0         = m_Uv0s[tVertexIdx];
                    tVertex.uv1         = m_Uv1s[tVertexIdx];
                    _Stream.Add(tVertex);
                }
            }
        }

        // /// <summary>
        // /// 对当前顶点集合应用Shadow效果
        // /// </summary>
        // public void ApplyShadowEffect(Shadow shadowComp)
        // {
        //     if(shadowComp)
        //     {
        //         int tVertexCount = m_VertexCount;
        //         int tIndexCount = m_IndexCount;
        //         Resize(tVertexCount * 2, tIndexCount * 2);
        //         m_VertexCount *= 2;
        //         m_IndexCount *= 2;
        //         CopyVertices(0, tVertexCount, tVertexCount);
        //         CopyIndices(0, tIndexCount, tIndexCount, tVertexCount);
        //         var tEffectDistance = shadowComp.effectDistance;
        //         ApplyShadowZeroAlloc(shadowComp.effectColor, 0, tVertexCount, tEffectDistance.x, tEffectDistance.y, shadowComp.useGraphicAlpha);
        //     }
        // }

        /// <summary>
        /// 对当前顶点集合应用Outline效果
        /// </summary>
        // public void ApplyOutlineEffect(Outline outlineComp)
        // {
        //     if (outlineComp)
        //     {
        //         int tVertexCount = m_VertexCount;
        //         int tIndexCount = m_IndexCount;
        //         Resize(tVertexCount * 5, tIndexCount * 5);
        //         m_VertexCount *= 5;
        //         m_IndexCount *= 5;
        //         CopyVertices(0, tVertexCount, tVertexCount);
        //         CopyVertices(0, tVertexCount * 2, tVertexCount);
        //         CopyVertices(0, tVertexCount * 3, tVertexCount * 2);

        //         CopyIndices(0, tIndexCount, tIndexCount, tVertexCount);
        //         CopyIndices(0, tIndexCount * 2, tIndexCount, tVertexCount * 2);
        //         CopyIndices(0, tIndexCount * 3, tIndexCount * 2, tVertexCount * 3);

        //         var tEffectDistance = outlineComp.effectDistance;
        //         var tEffectColor = outlineComp.effectColor;
        //         var tUseGraphicAlpha = outlineComp.useGraphicAlpha;
        //         int tStart = 0;
        //         int tEnd = tVertexCount;
        //         ApplyShadowZeroAlloc(tEffectColor, tStart, tEnd, tEffectDistance.x, tEffectDistance.y, tUseGraphicAlpha);
        //         tStart = tEnd;
        //         tEnd += tVertexCount;
        //         ApplyShadowZeroAlloc(tEffectColor, tStart, tEnd, tEffectDistance.x, -tEffectDistance.y, tUseGraphicAlpha);
        //         tStart = tEnd;
        //         tEnd += tVertexCount;
        //         ApplyShadowZeroAlloc(tEffectColor, tStart, tEnd, -tEffectDistance.x, tEffectDistance.y, tUseGraphicAlpha);
        //         tStart = tEnd;
        //         tEnd += tVertexCount;
        //         ApplyShadowZeroAlloc(tEffectColor, tStart, tEnd, -tEffectDistance.x, -tEffectDistance.y, tUseGraphicAlpha);
        //     }
        // }
        
        protected void ApplyShadowZeroAlloc(Color32 _Color, int _Start, int _End, float _OffsetX, float _OffsetY, bool _UseGraphicAlpha)
        {
            if(_UseGraphicAlpha)
            {
                for (int tIdx = _Start; tIdx < _End; ++tIdx)
                {
                    m_Positions[tIdx].x += _OffsetX;
                    m_Positions[tIdx].y += _OffsetY;
                    m_Colors[tIdx] = new Color32(_Color.r, _Color.g, _Color.b, (byte)((_Color.a * m_Colors[tIdx].a) / 255));
                }
            }
            else
            {
                for (int tIdx = _Start; tIdx < _End; ++tIdx)
                {
                    m_Positions[tIdx].x += _OffsetX;
                    m_Positions[tIdx].y += _OffsetY;
                    m_Colors[tIdx] = _Color;
                }
            }
        }
    }
}
