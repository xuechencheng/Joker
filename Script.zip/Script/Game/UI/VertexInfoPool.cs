using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Bokura
{
    /// <summary>
    /// 顶点小内存池，只缓存比较高频的，大内存直接分配，大小分界需要测试
    /// </summary>
    public class VertexInfoPool
    {
        /// <summary>
        /// 具有指定顶点数量的缓存池
        /// </summary>
        private class SubPool
        {
            /// <summary>
            /// 顶点容量
            /// </summary>
            private int m_VertexCap;



            /// <summary>
            /// 缓存池
            /// </summary>
            private Stack<VertexArray> m_Pool;



            public SubPool(int _StackCap, int _VertexCap)
            {
                m_VertexCap = _VertexCap;
                _StackCap = Mathf.Max(2, _StackCap);
                m_Pool = new Stack<VertexArray>(_StackCap);
                for (int tIdx = 0; tIdx < _StackCap; tIdx++)
                    m_Pool.Push(new VertexArray(_VertexCap));
            }



            [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
            public VertexArray Spawn()
            {
                if (m_Pool.Count > 0)
                    return m_Pool.Pop();
                else
                    return new VertexArray(m_VertexCap);
            }



            [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
            public void Recycle(VertexArray _VInfo)
            {
                m_Pool.Push(_VInfo);
            }



#if !RELEASE
            public string GetSizeInfo()
            {
                return string.Format("    容量为{0}的VertexArray池：剩余{1};", m_VertexCap, m_Pool.Count);
            }
#endif
        }



        /// <summary>
        /// Key：数组容量。
        /// Value：缓存池。
        /// </summary>
        private static Dictionary<int, SubPool> s_PoolMap = null;



        /// <summary>
        /// 数组容量最多是2的多少次方
        /// </summary>
        private const int kMaxPower = 8;



        /// <summary>
        /// 数组容量最少是2的多少次方
        /// </summary>
        private const int kMinPower = 2;



        static VertexInfoPool()
        {
            s_PoolMap = new Dictionary<int, SubPool>(kMaxPower - kMinPower);
            for (int tIdx = kMinPower; tIdx <= kMaxPower; ++tIdx)
            {
                int tVertexCap = (1 << tIdx);
                s_PoolMap[tVertexCap] = new SubPool(8, tVertexCap);
            }
        }



        protected VertexInfoPool() { }



        public static VertexArray Spawn(int _NeedVertexCount)
        {
            SubPool tPool = null;
            if (s_PoolMap.TryGetValue(GetNextPowerOfTwo(_NeedVertexCount), out tPool))
                return tPool.Spawn();
            else
                return new VertexArray(_NeedVertexCount);
        }



        public static void Recycle(VertexArray _VInfo)
        {
            if (null != _VInfo)
            {
                SubPool tPool = null;
                if (s_PoolMap.TryGetValue(GetNextPowerOfTwo(_VInfo.Capacity), out tPool))
                    tPool.Recycle(_VInfo);
            }
        }



        /// <summary>
        /// 获取等于或大于给定值的2的指数幂的值
        /// </summary>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        private static int GetNextPowerOfTwo(int _Value)
        {
            return Mathf.NextPowerOfTwo(_Value);
        }



#if !RELEASE
        public static string GetSizeInfo()
        {
            string tInfo = "<color=blue>【VertexInfoPool】单位：个</color>;";
            foreach (var item in s_PoolMap)
                tInfo += item.Value.GetSizeInfo();
            return tInfo;
        }
#endif
    }



    /// <summary>
    /// 顶点数组
    /// </summary>
    public class VertexArray
    {
        /// <summary>
        /// 当前存放的顶点数量
        /// </summary>
        public int length;



        /// <summary>
        /// 顶点数组
        /// </summary>
        public UISimpleVertex[] vertices;



        /// <summary>
        /// 数组容量
        /// </summary>
        public int Capacity
        {
            get { return null != vertices ? vertices.Length : 0; }
        }



        internal VertexArray(int _Cap)
        {
            this.length = 0;
            vertices = new UISimpleVertex[_Cap];
        }



        public void Resize(int _NeedCap)
        {
            if (vertices.Length < _NeedCap)
                System.Array.Resize(ref vertices, _NeedCap + 256);
        }



        public static VertexArray Spawn(int _NeedCap)
        {
            return VertexInfoPool.Spawn(_NeedCap);
        }



        public static void Recycle(VertexArray _ToRecycle)
        {
            VertexInfoPool.Recycle(_ToRecycle);
        }
    }
}
