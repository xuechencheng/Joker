﻿namespace Bokura
{
    /// <summary>
    /// 解析富文本时保存标签字段和对应数据信息
    /// </summary>
    public struct XmlTagAttribute
    {
        /// <summary>
        /// 标签名称的字符串哈希值
        /// </summary>
        public int nameHashCode;



        /// <summary>
        /// 值的类型
        /// </summary>
        public TagValueType valueType;



        /// <summary>
        /// 值在字符数组中的起始位置
        /// </summary>
        public int valueStartIndex;



        /// <summary>
        /// 值在字符数组中的长度
        /// </summary>
        public int valueLength;



        /// <summary>
        /// 值的字符串哈希值
        /// </summary>
        public int valueHashCode;



        public static XmlTagAttribute Default = new XmlTagAttribute()
        {
            nameHashCode = 0,
            valueType = TagValueType.None,
            valueStartIndex = 0,
            valueLength = 0,
            valueHashCode = 0
        };



        /// <summary>
        /// 重置参数
        /// </summary>
        public void SetDefault()
        {
            this.nameHashCode = 0;
            this.valueType = TagValueType.None;
            this.valueStartIndex = 0;
            this.valueLength = 0;
            this.valueHashCode = 0;
        }
    }
}
