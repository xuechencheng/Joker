﻿namespace Bokura
{
    /// <summary>
    /// 用于追踪富文本标签的泛型数据结构
    /// </summary>
    public class XmlTagStack<T>
    {
        private T[] m_ItemStack;



        private int m_Count;



        private int m_Capacity;



        public int Count
        {
            get { return m_Count; }
        }



        public XmlTagStack(int _Capacity = 4)
        {
            m_Capacity = Mathf.Max(_Capacity, 4);
            m_ItemStack = new T[m_Capacity];
            m_Count = 0;
        }



        public void Clear()
        {
            m_Count = 0;
        }



        /// <summary>
        /// 元素压栈
        /// </summary>
        public void Push(T item)
        {
            if (m_Count == m_Capacity)
            {
                m_Capacity *= 2;
                System.Array.Resize(ref m_ItemStack, m_Capacity);
            }
            m_ItemStack[m_Count++] = item;
        }



        /// <summary>
        /// 元素出栈
        /// </summary>
        /// <returns></returns>
        public T Pop()
        {
            T tItem = default(T);
            if (m_Count > 0)
               tItem = m_ItemStack[--m_Count];
            return tItem;
        }



        public T Current
        {
            get
            {
                if (m_Count > 0)
                    return m_ItemStack[m_Count - 1];
                return default(T);
            }
        }



        public T Previous
        {
            get
            {
                if (m_Count > 1)
                    return m_ItemStack[m_Count - 2];
                return default(T);
            }
        }
    }
}
