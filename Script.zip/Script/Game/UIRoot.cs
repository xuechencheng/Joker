﻿using UnityEngine;
using System.Collections;

public class UIRoot : MonoBehaviour {

	// Use this for initialization
	void Start () {
		DontDestroyOnLoad(gameObject);
	}
	
}
