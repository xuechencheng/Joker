using UnityEngine;
using System;
using Bokura;

namespace Bokura
{
	public class UserDataMgr 
	{

		swm.SyncMainUserData? m_mainUserData;


		public swm.SyncMainUserData? MainUserData
		{
			get
			{
				return m_mainUserData;
			}
		}

		GameEvent m_onUserDataSync = new GameEvent();
		public GameEvent onUserDataSync
		{
			get
			{
				return m_onUserDataSync;
			}
			set
			{
				m_onUserDataSync = value;
			}
		}




		static UserDataMgr m_instance;
		static public UserDataMgr Instance
		{
			get
			{
                if(m_instance == null)
                    m_instance = new UserDataMgr();
				return m_instance;
			}
		}


		public UserDataMgr()
		{
			MsgDispatcher.instance.RegisterFBMsgProc<swm.SyncMainUserData>(ProcSyncMainUserData);

		}
		public void ProcSyncMainUserData(swm.SyncMainUserData msg)
		{
            //LogHelper.Log("recv main user data: mvspeed" + msg.data.Value.move_speed);
			m_mainUserData = Utility.CopyFBMsgNotRoot(msg,msg.__p.bb_pos);
			if (m_onUserDataSync!=null)
				m_onUserDataSync.Invoke();

            //SkillManager.Instance.ReqGetHeartMethod();
		}

  


	}
}