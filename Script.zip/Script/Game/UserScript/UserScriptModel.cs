﻿using Bokura;

namespace Bokura
{
    class UserScriptModel : ClientSingleton<UserScriptModel>
    {
        [XLua.BlackList]
        public void Init()
        {
            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ScriptCmd>(ProcScriptCmd);
        }



        public void Clear()
        {

        }


        #region 网络消息
        void ProcScriptCmd(swm.ScriptCmd cmd)
        {
            LogHelper.Log(LogCategory.GameLogic, Utilities.BuildString("Proc User Script: ", cmd.scriptcmd));
            var script = cmd.scriptcmd;
            if (string.IsNullOrEmpty(script))
            {
                return;
            }
            LuaFastCall.DoString(script);
        }
        #endregion 
    }
}
