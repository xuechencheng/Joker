using UnityEngine;
using System.Collections.Generic;
using System;

namespace Bokura
{
    public class MidRef<T>
    {
        public T obj;
    }


    public static class UtilityExtensionClass
    {
        //static public Vector3 ToVector3(this x2m.Vector3 p)
        //{
        //    if (float.IsNaN(p.x))
        //        p.x = 0.0f;
        //    if (float.IsNaN(p.y))
        //        p.y = 0.0f;
        //    if (float.IsNaN(p.z))
        //        p.z = 0.0f;
        //    return new Vector3(p.x, p.y, p.z);
        //}

        static public Vector3 FBVec3Vec3(this swm.Vector3 p)
        {
            var x = p.x;
            var y = p.y;
            var z = p.z;
            if (float.IsNaN(x))
                x = 0.0f;
            if (float.IsNaN(y))
                y = 0.0f;
            if (float.IsNaN(z))
                z = 0.0f;
            return new Vector3(x, y, z);
        }
        static public Vector3 FBVec3Vec3(this swm.Vector3? p)
        {
            if (p != null)
                return p.Value.FBVec3Vec3();
            return Vector3.zero;
        }
        static public Vector3 Vec3(this swm.Vector3T p)
        {
            var x = p.x;
            var y = p.y;
            var z = p.z;
            if (float.IsNaN(x))
                x = 0.0f;
            if (float.IsNaN(y))
                y = 0.0f;
            if (float.IsNaN(z))
                z = 0.0f;
            return new Vector3(x, y, z);
        }
      
        static public swm.Vector3T Vec3(this Vector3 v)
        {
            var p= new swm.Vector3T();
            p.x = v.x;
            p.y = v.y;
            p.z = v.z;
            return p;
        }

        static public Vector3 WorldToUnityVec(this Vector3 v)
        {
            return v - LayeredSceneLoader.WorldOffset;
        }
        static public Vector3 UnityToWorldVec(this Vector3 v)
        {
            return v + LayeredSceneLoader.WorldOffset;
        }
    }
    public static class FlatBufferHelperExtend
    {
        static FlatBuffers.FlatBufferBuilder fbb = new FlatBuffers.FlatBufferBuilder(1024);
        static public T Clone<T>(this T a) where T: FlatBuffers.IFlatBufferHelperObject, new()
        {
            fbb.Clear();
            fbb.Finish(a.ToMsg(fbb));
            var b = new T();
            b.FromMsg(fbb);
            return b;
        }

  
    }
    struct DampingValue
    {
        float m_p;
        float m_cur;
        public DampingValue(float v, float p)
        {
            m_p = p;
            m_cur = v;
        }
        public float Set(float dest)
        {
            var d = (dest - m_cur);
            if ( Mathf.Abs(d) >m_p*0.1f)
                m_cur += d * m_p;
            else
                m_cur = dest;
            return m_cur;
        }
        public float RawSet(float dest)
        {
            m_cur = dest;
            return m_cur;
        }
    }
	class Utility
	{
        public const float MoveMinDistance = 0.01f;



  //      static public Vector3 NetPos2Vector3(x2m.Vector3 p)
		//{
		//	if (float.IsNaN(p.x))
		//		p.x = 0.0f;
		//	if (float.IsNaN(p.y))
		//		p.y = 0.0f;
		//	if (float.IsNaN(p.z))
		//		p.z = 0.0f;
		//	return new Vector3(p.x, p.y, p.z);
		//}
		static public Vector3 FBVec3Vec3(swm.Vector3 p)
		{
			var x = p.x;
			var y = p.y;
			var z = p.z;
			if (float.IsNaN(x))
				x = 0.0f;
			if (float.IsNaN(y))
				y = 0.0f;
			if (float.IsNaN(z))
				z = 0.0f;
			return new Vector3(x, y, z);
		}
		static public Vector3 FBVec3Vec3(swm.Vector3? p)
		{
			if (p != null)
                return p.Value.FBVec3Vec3();
            return Vector3.zero;
		}

		static public FlatBuffers.Offset<swm.Vector3> Vec3FBVec3(FlatBuffers.FlatBufferBuilder fbb, Vector3 v)
		{
			return swm.Vector3.CreateVector3(fbb, v.x, v.y, v.z);
		}

        static public int ReadInt32(byte[] data, int offset)
        {
            return data[offset] | data[offset + 1] << 8 | data[offset + 2] << 16 | data[offset + 3] << 24;
        }

        static public uint ReadUInt32(byte[] data, int offset)
        {
            return (uint)(data[offset] | data[offset + 1] << 8 | data[offset + 2] << 16 | data[offset + 3] << 24);
        }
        static public ulong ReadUInt64( byte[] data, int offset)
        {
            return ReadUInt32(data, offset) | ((ulong)ReadUInt32(data, offset + 4)) << 32;
            
        }
        static public ulong ReadInt64(byte[] data, int offset)
        {
            return (ulong)ReadUInt64(data, offset);
        }

        //static public x2m.Vector3 Vector32NetPos(Vector3 p)
        //{
        //	x2m.Vector3 pos = new x2m.Vector3();
        //	pos.x = p.x;
        //	pos.y = p.y;
        //	pos.z = p.z;
        //	return pos;
        //}
        //static public x2m.Vector3 Vector32NetPos(Vector3 p, x2m.Vector3 pos)
        //{
        //	pos.x = p.x;
        //	pos.y = p.y;
        //	pos.z = p.z;
        //	return pos;
        //}
        //static public x2m.Entity NetEntity(x2m.EntityType entity_type, ulong entity_id)
        //      {          
        //          x2m.Entity entity = new x2m.Entity();
        //          entity.entity_type = entity_type;
        //          entity.entity_id = entity_id;    
        //          return entity;
        //      }
        //static public x2m.Entity NetEntity(Entity ety)
        //{
        //	x2m.Entity entity = new x2m.Entity();
        //	entity.entity_type = (x2m.EntityType)ety.EntityType;
        //	entity.entity_id = ety.ThisID;
        //	return entity;
        //}


        //static public void NetEntityList2ClientEntityList(List<x2m.Entity> s, List<Entity> c )
        //{
        //	for(int i = 0; i < s.Count; i ++ )
        //	{
        //		var ety = GameScene.Instance.GetEntityByID(s[i].entity_type, s[i].entity_id);
        //		if(ety!=null)
        //		{
        //			c.Add(ety);
        //		}
        //	}
        //}

        //static public x2m.CombineElement NetCombineElement(ulong item_id, uint item_num)
        //{
        //    x2m.CombineElement combineelement = new x2m.CombineElement();
        //    combineelement.item_id = item_id;
        //    combineelement.item_num = item_num;
        //    return combineelement;
        //}

        static float PowCurvePostive(float step, float power )
        {
            if (step > 1.0f)
                step = 1.0f;

            if (step < 0.5f)
            {
                return Mathf.Pow(step * 2.0f, power) / 2.0f;
            }
            else
            {
                return 1 - Mathf.Pow((1 - step) * 2.0f, power) / 2.0f;
            }
        }

        static public float PowCurve(float step,float power=2.0f)
        {
            if(step<0.0f)
            {

                return -PowCurvePostive(-step, power);
            }
            else
            {
                return PowCurvePostive(step, power);

            }

        }

        
        static public bool LerpMove(Vector3 src, Vector3 dest, float step, out float outstep, out Vector3 dir, bool igrnorz = true)
		{
			bool arrive = false;
			dir = dest - src;
			if(igrnorz)
				dir.y = 0;
			float fdistance = dir.magnitude;
			if (fdistance < MoveMinDistance)
			{
				outstep = 0.0f;
				dir = Vector3.zero;
				return true;
			}

			if (step > fdistance)
			{
				outstep = fdistance;
				arrive = true;
			}
			else
				outstep = step;

			dir.Normalize();
			return arrive;
		}

        static public int GetMailMaxNum()
        {
            swm.MailMax mailmaxnum = swm.MailMax.NUM_MAX;
            
            return Convert.ToInt32(mailmaxnum);
        }

		static public T CopyFBMsg<T>(T src) where T:FlatBuffers.IFlatbufferObject
		{
			FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(src.ByteBuffer.Length);
			src.ByteBuffer.RawBuffer.CopyTo(bb.RawBuffer, 0);
			bb.Position = src.ByteBuffer.Position;
			T fbmsg = default(T);
			fbmsg.__init(bb.GetInt(bb.Position) + bb.Position, bb);
			return fbmsg;
		}
        static public T CopyFBMsgNotRoot<T>(T src, int offset) where T : FlatBuffers.IFlatbufferObject
        {
            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(src.ByteBuffer.Length);
            src.ByteBuffer.RawBuffer.CopyTo(bb.RawBuffer, 0);
            bb.Position = src.ByteBuffer.Position;
            T fbmsg = default(T);
            fbmsg.__init(offset, bb);
            return fbmsg;
        }
        static public T CopyFBMsgFromBuilder<T>(FlatBuffers.FlatBufferBuilder fbb) where T : FlatBuffers.IFlatbufferObject
        {
            var buflen = fbb.DataBuffer.Length - fbb.DataBuffer.Position;

            FlatBuffers.ByteBuffer bb = new FlatBuffers.ByteBuffer(buflen);
            Array.Copy(fbb.DataBuffer.RawBuffer, fbb.DataBuffer.Position, bb.RawBuffer, 0, buflen);

            bb.Position = 0;
            T fbmsg = default(T);
            fbmsg.__init(bb.GetInt(bb.Position) + bb.Position, bb);
            return fbmsg;

        }

        

    }

}