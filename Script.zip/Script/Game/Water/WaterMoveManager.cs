using UnityEngine;
using Bokura;
using Bokura.TriggerZoneManagement;

namespace Bokura
{
    /// <summary>
    /// 用于管理水上的移动相关的;
    /// </summary>
    public class WaterMoveManager : ClientSingleton<WaterMoveManager>
    {
        private bool isAddCharacterMoveListener = false;

        private bool isMovingOrJumping = true;
        private bool isCanUpdateCheckWater = false;

        private float m_currTime = 0;
        private float m_checkTime = 3;

        private System.Action<int> m_OnCreateMainCharacterListener;


        /// <summary>
        /// 注册通信消息;
        /// </summary>
        [XLua.BlackList]
        public void Init()
        {
            m_OnCreateMainCharacterListener = OnCreateMainCharacter;
            IEventDispatchManager.Instance.AddListener(GlobalEventID.CREATE_MAIN_CHARACTER, m_OnCreateMainCharacterListener);
        }



        public void Clear()
        {
            RemoveCharacterMoveListener();
        }

        [XLua.BlackList]
        public void Update()
        {
            //return;

            if (isCanUpdateCheckWater)
            {
                if (!isMovingOrJumping)
                {
                    if (GameScene.Instance.currState == GameState.InGame)
                    {
                        if (GameScene.Instance != null)
                        {
                            if (GameScene.Instance.MainChar != null)
                            {
                                if (isInWater(GameScene.Instance.MainChar.GlobalPosition))
                                {
                                    m_currTime = m_currTime + Time.deltaTime;
                                    if (m_currTime >= m_checkTime)
                                    {
                                        m_currTime = 0;
                                        var playerPos = GameScene.Instance.MainChar.GlobalPosition - LayeredSceneLoader.WorldOffset;
                                        WaterRippleManager.AddWaterRipple(playerPos, 0.8f, 0.5f);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        void OnCreateMainCharacter(int value)
        {
            AddCharacterMoveListener();
        }

        public void AddCharacterMoveListener()
        {
            if (!isAddCharacterMoveListener)
            {
                isAddCharacterMoveListener = true;

                GameScene.Instance.MainChar.onMoveEvent.AddListener(OnMove);
                GameScene.Instance.MainChar.OnJumpStatusChange.AddListener(OnJump);
                GameScene.Instance.MainChar.onRefreshMountChange.AddListener(OnRefreshMount);
                GameScene.Instance.MainChar.OnMoveStopEvent.AddListener(OnMoveStop);
                GameScene.Instance.onBeginLoading.AddListener(OnBeginLoading);
                GameScene.Instance.onEndLoading.AddListener(OnEndLoading);
            }
        }

        public void RemoveCharacterMoveListener()
        {
            if (isAddCharacterMoveListener )
            { 
                if (GameScene.Instance.MainChar)
                {
                    GameScene.Instance.MainChar.onMoveEvent.RemoveListener(OnMove);
                    GameScene.Instance.MainChar.OnJumpStatusChange.RemoveListener(OnJump);
                    GameScene.Instance.MainChar.onRefreshMountChange.RemoveListener(OnRefreshMount);
                    GameScene.Instance.MainChar.OnMoveStopEvent.RemoveListener(OnMoveStop);
                }

                GameScene.Instance.onBeginLoading.RemoveListener(OnBeginLoading);
                GameScene.Instance.onEndLoading.RemoveListener(OnEndLoading);

                isAddCharacterMoveListener = false;
            }
        }

        public void CheckPlayerIsInWater(Vector3 worldPos, Vector3 playerPos)
        {
            if (!GameScene.Instance.MainChar.IsFlying)
            {
                if (isRaining())
                {
                    WaterRippleManager.AddWaterRipple(playerPos, 1, 1);
                }
                else if(isInWater(worldPos))
                {
                    WaterRippleManager.AddWaterRipple(playerPos, 1, 1);
                }
            }
        }

        /// <summary>
        /// 在深水区需要下马;
        /// </summary>
        /// <param name="worldPos"></param>
        public void CheckWaterByRideMount(Vector3 worldPos)
        {
            if (!GameScene.Instance.MainChar.IsFlying)
            {
                if (GameScene.Instance.MainChar.RideMountBaseID != 0)//骑着马;
                {
                    //在深水区需要下马;
                    if (isHighInWater(worldPos))
                    {
                        if (MountMgr.Instance.CurEnableMount != null)
                        {
                            MountMgr.Instance.RequestDismount();
                        }
                    }

                    CheckAddWaterRipple();
                }
            }
        }

        public bool isInWater(Vector3 worldPos)
        {
            return (IWorldMatLUT.Instance.isInWater(worldPos) || IWorldMatLUT.Instance.isLightInWater(worldPos));
        }

        public bool isHighInWater(Vector3 worldPos)
        {
            return IWorldMatLUT.Instance.isInWater(worldPos);
        }

        public bool isLightInWater(Vector3 worldPos)
        {
            return IWorldMatLUT.Instance.isLightInWater(worldPos);
        }

        [XLua.BlackList]
        public void OnBeginLoading()
        {
            isCanUpdateCheckWater = false;
        }

        [XLua.BlackList]
        public void OnEndLoading()
        {
            if (GameScene.Instance.currState == GameState.InGame)
            {
                isMovingOrJumping = false;
                isCanUpdateCheckWater = true;
            }
        }

        [XLua.BlackList]
        public void OnMove()
        {
            isMovingOrJumping = true;
            if(GameScene.Instance.MainChar.Mount)
                CheckWaterByRideMount(GameScene.Instance.MainChar.Mount.GetGlobalPosition());            
            else
                CheckWaterByRideMount(GameScene.Instance.MainChar.GlobalPosition);
        }

        [XLua.BlackList]
        public void OnJump(Character.JumpState state)
        {
            //if (state == Character.JumpState.None)
            {
                isMovingOrJumping = true;
                CheckAddWaterRipple();
            }
        }

        /// <summary>
        /// 检测是否需要波纹;
        /// </summary>
        public void CheckAddWaterRipple()
        {
            var playerPos = GameScene.Instance.MainChar.Position - LayeredSceneLoader.WorldOffset;

            WaterMoveManager.Instance.CheckPlayerIsInWater(GameScene.Instance.MainChar.Position, playerPos);
        }

        /// <summary>
        /// 马在水面上起跳和落下也需要波纹;
        /// </summary>
        [XLua.BlackList]
        public void OnRefreshMount()
        {
            if (GameScene.Instance.MainChar.Mount != null)
            {
                GameScene.Instance.MainChar.Mount.OnJumpStartEvent.RemoveListener(OnMountJumpStart);
                GameScene.Instance.MainChar.Mount.OnJumpStopEvent.RemoveListener(OnMountJumpStop);

                GameScene.Instance.MainChar.Mount.OnJumpStartEvent.AddListener(OnMountJumpStart);
                GameScene.Instance.MainChar.Mount.OnJumpStopEvent.AddListener(OnMountJumpStop);
            }
        }

        [XLua.BlackList]
        public void OnMountJumpStart()
        {
            isMovingOrJumping = true;
            CheckAddWaterRipple();
        }

        [XLua.BlackList]
        public void OnMountJumpStop()
        {
            isMovingOrJumping = false;
            CheckAddWaterRipple();
        }

        [XLua.BlackList]
        public void OnMoveStop()
        {
            isMovingOrJumping = false;
        }

        [XLua.BlackList]
        public bool isRaining()
        {
            return WeatherManager.Instance.isRaining();
        }
    }
}
