using UnityEngine;
using Bokura;
using System.Collections.Generic;

namespace Bokura
{
	public class EarthSwords
	{
		public Character m_host;
		const float m_radius = 1.0f;

		const int EARTH_SWORD_BUFF_BASE_ID = 102101101;

		const int MAX_SWORD_COUNT = 5;

		SwordInfo m_prepareAttackSword;
		enum SwordType
		{
			EARTH,
			SKY,
		}
		class SwordInfo : AvatarEvent
		{
			public IAvatar m_sword;
			public Entity m_target;
			public System.Action m_hit_callback;
			public Bokura.AnimationPath m_animPath;

			Vector3 m_position;
			float m_fly_time;
			float m_total_fly_time = 0.5f;
			SwordType m_sword_type;
			bool m_fired = false;
			bool m_modeloading = false;

			UnityEngine.TrailRenderer[] m_trailrenders;

			public bool IsLoading
			{
				get
				{
					return m_modeloading;
				}
			}

			public SwordType SwordType
			{
				get
				{
					return m_sword_type;
				}
			}
			public Vector3 Position
			{
				set
				{
					m_position = value;
					if (m_sword != null)
						m_sword.SetPosition(value);
				}
				get
				{
					return m_position;
				}
			}



			public void Init(SwordType swtype, string swordpath = null)
			{
				m_sword = IFactory.Instance.CreateAvatar(this);
				m_modeloading = true;
				m_sword.onCreate.RemoveAllListeners();
				m_sword.onCreate.AddListener(OnAvatarCreate);
				if (swtype == SwordType.EARTH)
					m_sword.LoadModel("prefabs/weapons/", string.IsNullOrEmpty(swordpath) ? "weapon_earthsword" : swordpath, true);
				else
					m_sword.LoadModel("prefabs/weapons/", string.IsNullOrEmpty(swordpath) ? "weapon_skysword" : swordpath, true);
		
				m_sword.Visible = false;
				m_sword_type = swtype;
			}
			


			void OnAvatarCreate()
			{
				m_modeloading = false;
				if (m_sword != null)
				{
					m_trailrenders = m_sword.unityObject.GetComponentsInChildren<UnityEngine.TrailRenderer>();
					ClearTrial();
				}
			}

			public void Prepare()
			{
				m_fired = false;
			}

			public void Destroy()
			{
				if (m_sword != null)
				{
					m_sword.Release();
                    IFactory.Instance.ReleaseAvatar(m_sword);
                    m_sword = null;
                }
				m_target = null;
				m_trailrenders = null;
			}
			public bool DoUpdate()
			{
				if (!m_fired)
					return true;
				if (m_target == null || m_target.Avatar == null || m_target.Avatar.unityObject == null)
					return false;


				m_fly_time += Time.deltaTime;
				var targettransform = m_target.Avatar.GetAttachmentTransform(AvatarAttachment.Spine);
				m_animPath.points[1].position = targettransform ? targettransform.position : m_target.Position;

				if (m_fly_time > m_total_fly_time)
				{
					m_fly_time = m_total_fly_time;
					m_target = null;
					if (m_hit_callback != null)
					{
						m_hit_callback();
					}

				}
				Position = m_animPath.GetPointForTime(m_fly_time);
				var dir = m_animPath.GetTangentForTime(m_fly_time);
				if (dir.sqrMagnitude > 0.1f && m_sword.unityObject)
					m_sword.unityObject.transform.rotation = Quaternion.LookRotation(dir, Vector3.forward);

				return m_target != null;
			}
			public void ClearTrial()
			{
				if (m_trailrenders != null)
				{
					for (int i = 0; i < m_trailrenders.Length; i++)
					{
						if(m_trailrenders[i])
							m_trailrenders[i].Clear();
					}
				}
			}
			public void Fire(Entity target, Vector3 uppos, System.Action onHit)
			{
				if (target == null)
					return;
				if (m_animPath == null)
				{
					m_animPath = ScriptableObject.CreateInstance<AnimationPath>();
					m_animPath.points = new AnimationPathPoint[2] { new AnimationPathPoint(), new AnimationPathPoint() };

				}
				//Position = m_position;
				ClearTrial();
				m_fired = true;
				m_fly_time = 0.0f;
				m_target = target;
				m_hit_callback = onHit;
				m_total_fly_time = (m_position - target.Position).magnitude / 30.0f;

				m_animPath.points[0].position = m_position;
				m_animPath.points[0].OutTangentPos = uppos;// new Vector3(m_position.x,m_position.y+ 5.0f, m_position.z);
				m_animPath.points[0].time = m_total_fly_time;// / 3.0f;


				m_animPath.points[1].position = m_target.Position;
				m_animPath.points[1].InTangentPos = m_animPath.points[0].OutTangentPos;
				m_animPath.points[1].time = m_total_fly_time;
			}
			public override bool IsExceptMouseOver()
			{
				return true;
			}

		}


		List<SwordInfo> m_swords = new List<SwordInfo>(MAX_SWORD_COUNT);
		List<SwordInfo> m_attacking_swords = new List<SwordInfo>(MAX_SWORD_COUNT);
		List<SwordInfo> m_reserver_swords = new List<SwordInfo>(4);
		List<SwordInfo> m_reserver_skyswords = new List<SwordInfo>(4);

		//List<Vector3> m_swordsposition;
		float m_angle;
		float m_updown;
		public void Init(Character chr)
		{
			m_host = chr;
			m_host.BuffProxy.onAddBuff.AddListener(OnBuffRefreshOrAdd);
			m_host.BuffProxy.onRefreshBuff.AddListener(OnBuffRefreshOrAdd);
			m_host.BuffProxy.onRemoveBuff.AddListener(OnBuffRemove);
            m_host.onVisibleChangeEvent.AddListener(OnVisibleChange);
			//for (int i = 0; i < 3; i++)
			//{
			//	var sinfo = new SwordInfo();
			//	sinfo.Init(SwordType.EARTH);
			//	m_reserver_swords.Add(sinfo);
			//}
			RefreshSwords();


		}

        void OnVisibleChange()
        {
            if (m_iHidden) return;
            for(int i = 0; i < m_swords.Count; i ++ )
            {
				if (m_swords[i].m_sword!=null)
					m_swords[i].m_sword.Visible = m_host.Visible;
            }
        }

        bool m_iHidden;
        public void Hide()
        {
            m_iHidden = true;
            for (int i = 0; i < m_swords.Count; i++)
            {
                if (m_swords[i].m_sword != null)
                    m_swords[i].m_sword.Visible = false;
            }
        }
        public void CancelHide()
        {
            m_iHidden = false;
            for (int i = 0; i < m_swords.Count; i++)
            {
                if (m_swords[i].m_sword != null)
                    m_swords[i].m_sword.Visible = true;
            }
        }

        public void Destroy()
		{
			if (m_host != null)
			{
				if (m_host.BuffProxy != null)
				{
					m_host.BuffProxy.onAddBuff.RemoveListener(OnBuffRefreshOrAdd);
					m_host.BuffProxy.onRefreshBuff.RemoveListener(OnBuffRefreshOrAdd);
					m_host.BuffProxy.onRemoveBuff.RemoveListener(OnBuffRemove);
				}
				m_host.onVisibleChangeEvent.RemoveListener(OnVisibleChange);
			}
			for (int i = 0; i < m_swords.Count; i++)
			{
				m_swords[i].Destroy();
			}
			m_swords.Clear();

			for (int i = 0; i < m_attacking_swords.Count; i++)
			{
				m_attacking_swords[i].Destroy();
			}
			m_attacking_swords.Clear();

			for (int i = 0; i < m_reserver_swords.Count; i++)
			{
				m_reserver_swords[i].Destroy();
			}
			m_reserver_swords.Clear();

			for (int i = 0; i < m_reserver_skyswords.Count; i++)
			{
				m_reserver_skyswords[i].Destroy();
			}
			m_reserver_skyswords.Clear();
		}

		void RefreshSwords()
		{
			int buffcount = m_host.BuffProxy.GetBuffOverlapCountByBaseID(EARTH_SWORD_BUFF_BASE_ID);
			if (buffcount > MAX_SWORD_COUNT)
				buffcount = MAX_SWORD_COUNT;
			if (buffcount < m_swords.Count)
			{
				for (int i = buffcount; i < m_swords.Count; i++)
				{
					m_swords[i].m_sword.Visible = false;
					m_reserver_swords.Add(m_swords[i]);
				}
				m_swords.RemoveRange(buffcount, m_swords.Count - buffcount);
			}
			else
			{
				while (buffcount > m_swords.Count)
				{
					if (m_reserver_swords.Count == 0)
					{
						var sinfo = new SwordInfo();
						sinfo.Init(SwordType.EARTH);
						m_reserver_swords.Add(sinfo);
					}
					m_swords.Add(m_reserver_swords[m_reserver_swords.Count - 1]);
					m_reserver_swords[m_reserver_swords.Count - 1].m_sword.Visible = m_iHidden? false :true;
					m_reserver_swords[m_reserver_swords.Count - 1].ClearTrial();
					m_reserver_swords[m_reserver_swords.Count - 1].Position = m_host.GlobalPosition;
					m_reserver_swords.RemoveAt(m_reserver_swords.Count - 1);
				}
			}
		}

		static float m_rotateSpeed = 1.0f;
		public void Update()
		{
            if (m_iHidden) return;
			for (int i = m_attacking_swords.Count - 1; i >= 0; i--)
			{
				if (!m_attacking_swords[i].DoUpdate())
				{
					if (m_attacking_swords[i].SwordType == SwordType.EARTH)
						m_reserver_swords.Add(m_attacking_swords[i]);
					else
						m_reserver_skyswords.Add(m_attacking_swords[i]);
					m_attacking_swords[i].m_sword.Visible = false;
					m_attacking_swords.RemoveAt(i);
				}
			}
			float angleDelta = Mathf.PI * 2.0f / m_swords.Count;
			m_angle += m_rotateSpeed * Time.deltaTime * Mathf.PI / 2.0f;
			m_updown += m_rotateSpeed * Time.deltaTime * Mathf.PI /2.0f;
			for (int i = 0; i < m_swords.Count; i++)
			{
				float x = Mathf.Cos(i * angleDelta + m_angle) * m_radius + m_host.GlobalPosition.x;
				//float nextd = (float)m_random.NextDouble();
				//m_updown += nextd;
				float y = Mathf.Sin(m_updown + i * angleDelta*2.0f) * 0.8f + m_host.GlobalPosition.y + 1.2f;
				float z = Mathf.Sin(i * angleDelta + m_angle) * m_radius + m_host.GlobalPosition.z;
				//var newpos = new Vector3(x, y, z);
				var oldpos = m_swords[i].Position;
				
				var newpos = new Vector3(x, y, z);
				var dir = newpos - oldpos;
				var len = dir.magnitude;
                if (len < 0.0001f)
                    continue;
				if (len > 0.2f)
				{
					dir.Normalize();
					newpos = oldpos + dir * (len / 5.0f);
				}
				else if (len > 0.02f)
				{
					dir.Normalize();
					newpos = oldpos + dir*(len / 10.0f);
				}

				m_swords[i].Position = newpos;

				if (m_swords[i].m_sword.unityObject)
				{
					
					//dir.Normalize();
					var newrotate = Quaternion.LookRotation(dir, Vector3.forward);
					float diffangle = Quaternion.Angle(m_swords[i].m_sword.unityObject.transform.rotation, newrotate);
					if (diffangle > 5.0f)
					{
						newrotate = Quaternion.Lerp(m_swords[i].m_sword.unityObject.transform.rotation, newrotate, 5.0f / diffangle);
					}
					m_swords[i].m_sword.unityObject.transform.rotation = newrotate; //Quaternion.identity;
				}
				else if(!m_swords[i].IsLoading)
				{
					m_swords[i].Init(m_swords[i].SwordType);
					m_swords[i].m_sword.Visible = m_iHidden ? false : true;
                }

			}


		}

		public bool AttackTarget(Entity target, System.Action onHit)
		{
			if (m_prepareAttackSword == null)
				PrepareAttack();
			if (m_prepareAttackSword != null)
			{



				m_prepareAttackSword.Fire(target, GetFireStartPos(), onHit);
				m_prepareAttackSword = null;
				return true;
			}
			return false;
		}

		public void PrepareAttack()
		{
			if (m_prepareAttackSword != null)
				return;
			if (m_swords.Count > 0)
			{
				m_prepareAttackSword = m_swords[m_swords.Count - 1];
				m_attacking_swords.Add(m_prepareAttackSword);
				m_swords.RemoveAt(m_swords.Count - 1);
				m_prepareAttackSword.Prepare();

			}
		}


		Vector3 GetFireStartPos()
		{
			var uppos = m_host.GlobalPosition;
			uppos.y += 5.0f;
			return uppos;
		}
		Vector3 GetSkySwordFireStartPos()
		{
			var uppos = m_host.GlobalPosition;
			uppos.y += 2.0f;
			return uppos;
		}
		public void AttackTargetSkySword(Entity target, System.Action onHit, string swordeffectpath = null)
		{
			if (m_reserver_skyswords.Count == 0)
			{
				var sinfo = new SwordInfo();
				sinfo.Init(SwordType.SKY, swordeffectpath);
				m_reserver_skyswords.Add(sinfo);
			}

			var sword = m_reserver_skyswords[m_reserver_skyswords.Count - 1];
			var pos = m_host.GlobalPosition;
			pos.y += 2.5f;
			sword.Position = pos;
			m_attacking_swords.Add(sword);

			m_reserver_skyswords.RemoveAt(m_reserver_skyswords.Count - 1);
			sword.m_sword.Visible = m_iHidden ? false : true;
            sword.Fire(target, GetSkySwordFireStartPos(), onHit);
		}


		void OnBuffRefreshOrAdd(BuffBase buf)
		{
			RefreshSwords();
		}


		void OnBuffRemove(BuffBase buff)
		{
			RefreshSwords();
		}
	}
}