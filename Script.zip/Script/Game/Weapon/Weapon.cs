using System;
using UnityEngine;
using Bokura;

namespace Bokura
{
    public enum WeaponCategory
    {
        Normal = 0,
        Knife  = 1, //刀
        Sword  = 2, //剑
        Crossbow,   //弩
        Lyre,       //琴

        Max,        
    }

    public class Weapon : AvatarEvent
    {
        public Weapon()
        {
            m_Avatar = IFactory.Instance.CreateAvatar(this);
        }
        private ulong m_BaseID = 0;
        public ulong baseID
        {
            get { return m_BaseID; }
        }
        protected IAvatar m_Avatar;
        private GameEvent m_OnAvatarLoaded = new GameEvent();
        public GameEvent OnAvatarLoaded
        {
            get { return m_OnAvatarLoaded; }
        }

        protected WeaponTableBase? m_base;
        public WeaponTableBase? Base
        {
            get { return m_base; }
        }
        AvatarAttachment m_attachment;

        Entity m_owner;
        public IAvatar Avatar
        {
            get
            {
                return m_Avatar;
            }
        }

        bool m_bShow = true;
        bool m_bShowBySkill = true;
        bool m_bShowByAction = true;
        public bool IsShow
        {
            get
            {
                return m_bShow && m_bShowBySkill && m_bShowByAction;
            }
        }
        public bool IsShowByAction { get { return m_bShowByAction; } }

        public bool IsShowBySkill { get { return m_bShowBySkill; } }

        protected WeaponCategory m_weaponCategory = WeaponCategory.Normal;
        public WeaponCategory WeaponCategory { get { return m_weaponCategory; } }

        public AvatarAttachment SrcAttachment = AvatarAttachment.Back;
        public AvatarAttachment Attachment
        {
            get
            {
                return m_attachment;
            }
            set
            {
                if (m_attachment != value)
                {
                    m_attachment = value;
                    //Debug.LogError(m_attachment);
                    OnAttachmentChanged();
                }

            }
        }

        void PlayAnim()
        {
            if (m_attachment == AvatarAttachment.Back)
                CrossFadeAll(AnimatorStateID.ToBack, 0.0f, 0.0f);
            else
                CrossFadeAll(AnimatorStateID.ToHand, 0.0f, 0.0f);
        }

        [XLua.BlackList]
        public void CrossFadeAll(int animid, float fadetime = 0.0f, float normalize = 0.0f, bool forcePlay = true)
        {
            if(m_Avatar.animator.HasAnim(animid))
                m_Avatar.animator.CrossFadeAll(animid, fadetime, normalize, forcePlay);

        }
        public void init(Entity owner,uint weaponID ,bool async = true)
        {
            var data  = WeaponTableManager.GetData((int)weaponID);
            if(data.HasValue)
            {
                SrcAttachment = (AvatarAttachment)data.Value.primary_bind_bone;
                m_weaponCategory = (WeaponCategory)data.Value.type;
                init(owner, "prefabs/weapons/", data.Value.primary_weapon, async);
            }
        }
        public void init(Entity owner, string weapon_name, bool async = true, ulong baseID = 0)
        {
            init(owner, "prefabs/weapons/", weapon_name, async, baseID);
        }

        public void init(Entity owner, string weaponpath, string weapon_name, bool async = true, ulong baseID = 0)
        {
            //Owner可能为null，注意判空
            m_owner = owner;
            m_BaseID = baseID;
            m_Avatar.onCreate.AddListener(OnAvatarCreateDelegate);

            m_Avatar.LoadModel(weaponpath, weapon_name, async); //"weapon_z01"
            m_Avatar.Visible = IsShow;
            if (m_owner != null)
            {
                if (m_owner.StateMachine != null)
                {
                    m_owner.StateMachine.OnPostStateChange.AddListener(OnOwnerStateChange);
                }
            }
        }

        public void SwitchWeapon(uint weapon_id)
        {
            var data = WeaponTableManager.GetData((int)weapon_id);
            if (data.HasValue)
            {
                SrcAttachment = (AvatarAttachment)data.Value.primary_bind_bone;
                m_weaponCategory = (WeaponCategory)data.Value.type;
                m_Avatar.LoadModel("prefabs/weapons/", data.Value.primary_weapon, true);
            }
        }

        // void OnOwnerStateChange(SM.Entity.States oldstate, SM.Entity.States newstate)
        // {
        //     if (oldstate == SM.Entity.States.ATTACK_IDLE && newstate == SM.Entity.States.IDLE)
        //     {
        //         CrossFadeAll(AnimatorStateID.AttIdleToStand, 0.0f, 0.0f);
        //     }
        // }

        void OnAvatarCreateDelegate()
        {
            OnAvatarLoaded.Invoke();

            OnAttachmentChanged();
            m_Avatar.SetLayer(m_owner.Layer);
            m_owner.OnAvatarChanged(m_Avatar.unityObject);
        }

        void OnAttachmentChanged()
        {
            if (m_Avatar != null && m_owner != null)
            {
                m_Avatar.AttachTo(m_owner.Avatar, m_attachment, m_attachment);
                PlayAnim();
            }
        }

        public void Reset()
        {
            if (null != m_Avatar)
            {
                m_Avatar.Release();
                m_Avatar.ResetAvatar();
            }
        }

        public void Release()
        {
            if (null != m_Avatar)
            {
                m_Avatar.Release();
                IFactory.Instance.ReleaseAvatar(m_Avatar);
                m_Avatar = null;
            }
            if (m_owner && m_owner.StateMachine != null)
            {
                m_owner.StateMachine.OnPostStateChange.RemoveListener(OnOwnerStateChange);
            }
        }

        private bool CheckShowState(bool show)
        {
            if (m_owner.IsCharacter())
            {
                if ((m_owner as Character).IsInInteractionPoint)
                    return false;
            }

            return show;
        }

        public void Show(bool show)
        {
            show = CheckShowState(show);

            m_bShow = show;
            if (m_Avatar != null)
                m_Avatar.Visible = IsShow;
        }

        //用于非正常buff影响的显示和隐藏
        public void ShowAvataWithoutState(bool show)
        {
            show = CheckShowState(show);

            if (show)
                ShowAvata();
            else
                HideAvata();
        }

        //强制隐藏武器  但不影响状态
        public void HideAvata() {
            if (m_Avatar != null)
                m_Avatar.Visible = false;
        }
        //显示武器，需要判断状态
        public void ShowAvata() {
            if (m_bShow) {
                m_Avatar.Visible = true;
            }
        }

        public void ShowBySkill(bool show)
        {
            m_bShowBySkill = show;
            if (m_Avatar != null)
                m_Avatar.Visible = IsShow;
        }
        public void ShowByAction(bool show)
        {
            m_bShowByAction = show;
            if (m_Avatar != null)
                m_Avatar.Visible = IsShow;
        }
        public override void Update()
        {
            m_Avatar.MaterialProterties.LateUpdate();
        }

        public void SetUnityObjVisible(bool visible)
        {
            if (Avatar == null)
                return;

            if (Avatar.unityObject == null)
                return;

            Avatar.unityObject.SetActive(visible);
        }
    }
}