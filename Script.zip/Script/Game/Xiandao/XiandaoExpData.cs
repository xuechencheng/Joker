using System;
using System.Collections.Generic;

namespace Bokura
{
    public class XiandaoExpJsonCfg
    {
        /// <summary>
        /// 任务进度信息
        /// </summary>
        public string tasktrack_info;

        /// <summary>
        /// 玩法说明标题
        /// </summary>
        public string play_desc_title;

        /// <summary>
        /// 玩法说明内容
        /// </summary>
        public string play_desc_content;

        /// <summary>
        /// 总结算界面描述
        /// </summary>
        public string settle_info;
    }

    /// <summary>
    /// 仙道历练轮数据
    /// </summary>
    public class XiandaoExpRoundInfo
    {
        /// <summary>
        /// 轮次
        /// </summary>
        public uint round;

        /// <summary>
        /// boss的baseid
        /// </summary>
        public uint boss_id;

        /// <summary>
        /// 此轮得到的经验
        /// </summary>
        public uint round_exp;

        /// <summary>
        /// 刷新
        /// </summary>
        [XLua.BlackList]
        public void Refresh(swm.XiandaoRoundInfo roundinfo)
        {
            round = roundinfo.round;
            boss_id = roundinfo.boss_id;
            round_exp = roundinfo.round_exp;
        }
    }

    /// <summary>
    /// 仙道历练数据
    /// </summary>
    public class XiandaoExpInfo
    {

        /// <summary>
        /// 比较函数
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        private static int CompareRoundInfo(XiandaoExpRoundInfo left, XiandaoExpRoundInfo right)
        {
            if (left.round < right.round)
                return -1;

            return 1;
        }

        /// <summary>
        /// 当前已完成轮次
        /// </summary>
        public uint cur_finish_round = 0;

        /// <summary>
        /// 当前目标副本
        /// </summary>
        public uint cur_copy = Const.kUInt_Max;


        public List<XiandaoExpRoundInfo> m_roundInfoList = new List<XiandaoExpRoundInfo>(Const.kCap8);
        /// <summary>
        /// 历史轮次信息
        /// </summary>
        public List<XiandaoExpRoundInfo> roundInfoList
        {
            get { return m_roundInfoList; }
        }


        /// <summary>
        /// 额外经验奖励
        /// </summary>
        public uint extra_exp = 0;

        /// <summary>
        /// 清理
        /// </summary>
        [XLua.BlackList]
        public void Clear()
        {
            m_roundInfoList.Clear();
        }

        [XLua.BlackList]
        public bool HasCurCopy()
        {
            return (cur_copy != 0) && (cur_copy != Const.kUInt_Max);
        }

        /// <summary>
        /// 刷新通用信息
        /// </summary>
        /// <param name="_cur_finish_round">当前已完成轮次</param>
        /// <param name="_cur_copy">当前目标副本</param>
        /// <param name="_extra_exp">额外经验奖励</param>
        private void RefreshCommonInfo(uint _cur_finish_round, uint _cur_copy, uint _extra_exp)
        {
            cur_finish_round = _cur_finish_round;
            cur_copy = _cur_copy;
            extra_exp = _extra_exp;
        }

        private void RefreshRoundInfo(swm.RspXiandaoInfo msg)
        {
            m_roundInfoList.Clear();

            for (int i = 0; i < msg.round_historyLength; i++)
            {
                swm.XiandaoRoundInfo? msg_roundinfo = msg.round_history(i);
                if (!msg_roundinfo.HasValue)
                    continue;

                XiandaoExpRoundInfo roundInfo = new XiandaoExpRoundInfo();
                roundInfo.Refresh(msg_roundinfo.Value);
                m_roundInfoList.Add(roundInfo);
            }

            m_roundInfoList.Sort(CompareRoundInfo);
        }

        private void RefreshRoundInfo(swm.NotifyXiandaoInfo msg)
        {
            m_roundInfoList.Clear();

            for (int i = 0; i < msg.round_historyLength; i++)
            {
                swm.XiandaoRoundInfo? msg_roundinfo = msg.round_history(i);
                if (!msg_roundinfo.HasValue)
                    continue;

                XiandaoExpRoundInfo roundInfo = new XiandaoExpRoundInfo();
                roundInfo.Refresh(msg_roundinfo.Value);
                m_roundInfoList.Add(roundInfo);
            }

            m_roundInfoList.Sort(CompareRoundInfo);
        }

        [XLua.BlackList]
        public void Refresh(swm.RspXiandaoInfo msg)
        {
            RefreshCommonInfo(msg.cur_finish_round, msg.cur_copy, msg.extra_exp);
            RefreshRoundInfo(msg);
        }

        [XLua.BlackList]
        public void Refresh(swm.NotifyXiandaoInfo msg)
        {
            RefreshCommonInfo(msg.cur_finish_round, msg.cur_copy, msg.extra_exp);
            RefreshRoundInfo(msg);
        }
    }
}
