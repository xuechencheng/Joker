using System;
using System.Collections.Generic;
using swm;
using Bokura;
using FlatBuffers;
using LitJson;

namespace Bokura
{
    public class XiandaoExpModel : ClientSingleton<XiandaoExpModel>
    {
        #region 变量

        private XiandaoExpInfo m_xiandaoExpInfo = new XiandaoExpInfo();
        /// <summary>
        /// 仙道历练数据
        /// </summary>
        public XiandaoExpInfo xiandaoExpInfo
        {
            get { return m_xiandaoExpInfo; }
        }


        private XiandaoExpJsonCfg m_xiandaoExpJsonCfg = new XiandaoExpJsonCfg();
        /// <summary>
        /// json配置
        /// </summary>
        public XiandaoExpJsonCfg xiandaoExpJsonCfg
        {
            get { return m_xiandaoExpJsonCfg; }
        }


        private GameEvent m_onNtfXiandaoInfoEvent = new GameEvent();
        /// <summary>
        /// 通知仙道历练信息事件
        /// </summary>
        public GameEvent onNtfXiandaoInfoEvent
        {
            get { return m_onNtfXiandaoInfoEvent; }
        }



        private GameEvent m_onRspXiandaoInfoEvent = new GameEvent();
        /// <summary>
        /// 回应仙道历练信息事件
        /// </summary>
        public GameEvent onRspXiandaoInfoEvent
        {
            get { return m_onRspXiandaoInfoEvent; }
        }

        #endregion

        #region 继承函数

        [XLua.BlackList]
        public void Init()
        {
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspXiandaoInfo>(ProcRspXiandaoInfo_SC);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.NotifyXiandaoInfo>(ProcNotifyXiandaoInfo_SC);
        }

        [XLua.BlackList]
        public void Clear()
        {
            m_xiandaoExpInfo.Clear();
        }

        [XLua.BlackList]
        public void Load()
        {
            string infocfg = TableManager.LoadFileTable("xiandaoexp_info.json", "/Datas/");
            JsonData jsondata = JsonMapper.ToObject(infocfg);
            if (jsondata.IsObject)
            {
                m_xiandaoExpJsonCfg = JsonMapper.ToObject<XiandaoExpJsonCfg>(jsondata.ToJson());
            }
        }

        #endregion

        #region 消息

        /// <summary>
        /// 客户端请求 仙道历练 信息
        /// </summary>
        public void ReqXiandaoInfo_CS()
        {
            var fb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqXiandaoInfo.StartReqXiandaoInfo(fb);
            var offset = swm.ReqXiandaoInfo.EndReqXiandaoInfo(fb);
            fb.Finish(offset.Value);

            MsgDispatcher.instance.SendFBPackage(swm.ReqXiandaoInfo.HashID, fb);
        }

        private void ProcRspXiandaoInfo_SC(swm.RspXiandaoInfo msg)
        {
            m_xiandaoExpInfo.Refresh(msg);
            onRspXiandaoInfoEvent.Invoke();
        }

        private void ProcNotifyXiandaoInfo_SC(swm.NotifyXiandaoInfo msg)
        {
            m_xiandaoExpInfo.Refresh(msg);
            m_onNtfXiandaoInfoEvent.Invoke();
        }

        #endregion

        #region 函数

        /// <summary>
        /// 是否有活动
        /// </summary>
        /// <returns></returns>
        public bool HasActivity()
        {
            return m_xiandaoExpInfo.HasCurCopy();
        }

        /// <summary>
        /// 测试
        /// </summary>
        [XLua.BlackList]
        public void GM_Test_Open()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            var roundinfo_off1 = swm.XiandaoRoundInfo.CreateXiandaoRoundInfo(tFBB, 2, 800035, 5000);
            var roundinfo_off2 = swm.XiandaoRoundInfo.CreateXiandaoRoundInfo(tFBB, 3, 800038, 3000);
            var roundinfo_off3 = swm.XiandaoRoundInfo.CreateXiandaoRoundInfo(tFBB, 1, 810000, 1000);

            var roundinfo_offlist = new Offset<XiandaoRoundInfo>[] { roundinfo_off1, roundinfo_off2, roundinfo_off3 };
            var roundinfooff = swm.NotifyXiandaoInfo.CreateRoundHistoryVector(tFBB, roundinfo_offlist);

            var tOffset = swm.NotifyXiandaoInfo.CreateNotifyXiandaoInfo(tFBB, 3, 1, roundinfooff, 500);
            tFBB.Finish(tOffset.Value);

            OfflineViewMsgTamper.ProcFBMsg(swm.NotifyXiandaoInfo.HashID, tFBB);
        }

        /// <summary>
        /// 测试
        /// </summary>
        [XLua.BlackList]
        public void GM_Test_Close()
        {
            FlatBufferBuilder tFBB = MsgDispatcher.instance.GetFlatBufferBuilder();

            var roundinfo_off1 = swm.XiandaoRoundInfo.CreateXiandaoRoundInfo(tFBB, 2, 800035, 5000);
            var roundinfo_off2 = swm.XiandaoRoundInfo.CreateXiandaoRoundInfo(tFBB, 3, 800038, 3000);
            var roundinfo_off3 = swm.XiandaoRoundInfo.CreateXiandaoRoundInfo(tFBB, 1, 810000, 1000);

            var roundinfo_offlist = new Offset<XiandaoRoundInfo>[] { roundinfo_off1, roundinfo_off2, roundinfo_off3 };
            var roundinfooff = swm.NotifyXiandaoInfo.CreateRoundHistoryVector(tFBB, roundinfo_offlist);

            var tOffset = swm.NotifyXiandaoInfo.CreateNotifyXiandaoInfo(tFBB, 3, 0, roundinfooff, 500);
            tFBB.Finish(tOffset.Value);

            OfflineViewMsgTamper.ProcFBMsg(swm.NotifyXiandaoInfo.HashID, tFBB);
        }

        #endregion
    }
}
