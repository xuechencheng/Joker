﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;

namespace Bokura
{
    public struct MailBaseItemInfo
    {
        public uint itemid;
        public uint itemnum;
    }

    /// <summary>
    /// 邮件基类
    /// </summary>
    public class MailBase
    {
        public ulong ID;
        public int BaseID;
        public swm.MailState Mail_State;
        public swm.MailAttState Att_State;
        public ulong MailTime;
        public uint Item_Num;

        public swm.MailDataT MailData;

        MailTableBase? m_MailConfig;

		public MailTableBase MailConfig
		{
			get
			{
				return m_MailConfig.Value;
			}
		}

        public ItemManager ItemManager = new ItemManager();

        /// <summary>
        /// 邮件货币等信息
        /// </summary>
        private List<MailBaseItemInfo> baseiteminfolist = new List<MailBaseItemInfo>(Const.kCap8);

        /// <summary>
        /// todo
        /// </summary>
        public List<swm.TsParamsT> paramlist = new List<swm.TsParamsT>(Const.kCap8);

        public MailBase()
        {
            this.ID = 0;//表示这是一个空的
        }

        public MailBase(int baseid)
        {
			m_MailConfig = MailTableManager.GetData(baseid);
        }

        public MailBase(ulong id, int baseid, swm.MailState mailstate, swm.MailAttState attstate, ulong mailtime, uint itemnum)
        {
            this.ID = id;
            this.BaseID = baseid;
            this.Mail_State = mailstate;
            this.Att_State = attstate;
            this.MailTime = mailtime;
            this.Item_Num = itemnum;

			m_MailConfig = MailTableManager.GetData(baseid);
        }

        public void Init(MailTableBase _configData, swm.MailData _item)
        {
			m_MailConfig = _configData;

            this.ID = _item.id;
            this.BaseID = _configData.id;
            this.Mail_State = _item.mail_state;
            this.Att_State = _item.att_state;
            this.MailTime = _item.time;
            this.Item_Num = _item.item_num;
            if (MailData == null)
                MailData = new swm.MailDataT();
            MailData.FromMsg(_item);
        }
        
        public void RefreshMailItem(swm.MailData _item)
        {
            if (MailData == null)
                MailData = new swm.MailDataT();

            MailData.FromMsg(_item);
      
            this.ID = _item.id;
            this.BaseID = (int)_item.baseid;
            this.Mail_State = _item.mail_state;
            this.Att_State = _item.att_state;
            this.MailTime = _item.time;
            this.Item_Num = _item.item_num;

			m_MailConfig = MailTableManager.GetData(BaseID);
        }

        [XLua.BlackList]
        public void RefreshMailItem(swm.RspMailInfo _msg)
        {
            Mail_State = _msg.mail_state;
            Att_State = _msg.att_state;
            
            if (_msg.itemlistLength > 0 && ItemManager.GetItemCount() <= 0)
            {
                for (int i = 0; i < _msg.itemlistLength; i++)
                {
                    var data = _msg.itemlist(i).Value;
                    ItemManager.AddItem(data);
                }
            }

            baseiteminfolist.Clear();
            if (_msg.baseitemlistLength > 0)
            {
                for (int i = 0; i < _msg.baseitemlistLength; i++)
                {
                    var data = _msg.baseitemlist(i).Value;

                    MailBaseItemInfo baseiteminfo = new MailBaseItemInfo();
                    baseiteminfo.itemid = data.itemid;
                    baseiteminfo.itemnum = data.itemnum;
                    baseiteminfolist.Add(baseiteminfo);
                }
            }

            paramlist.Clear();
            for (int i = 0; i < _msg.paramlistLength; i++)
            {
                swm.TsParamsT param = new swm.TsParamsT();
                param.FromMsg(_msg.paramlist(i).Value);
                paramlist.Add(param);
            }
        }

        public ItemBase GetItemByIndex(int index)
        {

            var value = ItemManager.GetItemByIndex(index);            
          
            return value;
        }

        /// <summary>
        /// 消亡
        /// </summary>
        public void Destory()
        {
			m_MailConfig = null;
            MailData = null;
            baseiteminfolist.Clear();

            if (ItemManager != null)
            {
                ItemManager.DeleteAllItem();
                ItemManager = null;
            }
        }

        public int GetBaseItemInfoListNum()
        {
            return baseiteminfolist.Count;
        }

        public MailBaseItemInfo? GetBaseItemInfoByIndex(int index)
        {
            if (index < 0 || index >= baseiteminfolist.Count)
                return null;

            return baseiteminfolist[index];
        }
    }
}