﻿namespace Bokura
{
    public class MailFactory : ClientSingleton<MailFactory>
    {
        public MailBase CreateMailItem(MailTableBase _config, swm.MailData _item)
        {
            MailBase mailBase = null;
            if (null == mailBase)
            {
                mailBase = new MailBase();
            }
            mailBase.Init(_config, _item);
            return mailBase;
        }

    }
}
