﻿using System.Collections.Generic;

namespace Bokura
{
    public class MailManager : ClientSingleton<MailManager>
    {
        private List<MailBase> m_mailList = new List<MailBase>(Const.kCap16);
        private List<MailBase> m_mailTempList = new List<MailBase>(Const.kCap16);

        public void ProcRefreshMailList(swm.RspMailList _msg)
        {
            m_mailTempList.Clear();
            for (int i = 0; i < m_mailList.Count; i++)
            {
                m_mailTempList.Add(m_mailList[i]);
            }

            m_mailList.Clear();
            if (_msg.datasLength > 0)
            {
                for (int i = 0; i < _msg.datasLength; i++)
                {
                    var item = _msg.datas(i).Value;
                    MailBase bBase = GetTempMailItemByThisID(item.id);
                    if (null != bBase)
                    {
                        bBase.RefreshMailItem(item);
                        m_mailList.Add( bBase);
                        m_mailTempList.Remove(bBase);
                    }
                    else
                    {
                        AddMailItem(item);
                    }          
                }
            }

            for (int j = 0; j < m_mailTempList.Count; j++)
            {
                m_mailTempList[j].Destory();
            }
            m_mailTempList.Clear();

            SortMailList();
        }

        private MailBase GetTempMailItemByThisID(ulong thisid)
        {
            MailBase _base = null;
            for (int j = 0; j < m_mailTempList.Count; j++)
            {
                _base = m_mailTempList[j];
                if (_base.ID == thisid)
                {
                    return _base;
                }
            }
            return null;
        }

        public void SortMailList()
        {
            if (m_mailList.Count > 0)
            {
                m_mailList.Sort(ProcessSrotList);
            }
        }

        public int ProcessSrotList(MailBase _a, MailBase _b)
        {
            if(_a.Mail_State < _b.Mail_State)
            {
                return -1;
            }
            else if(_a.Mail_State > _b.Mail_State)
            {
                return 1;
            }

            if (_a.MailTime < _b.MailTime)
            {
                return -1;
            }
            else if (_a.MailTime == _b.MailTime)
            {
                return 0;
            }

            return 1;
        }

        // 添加一个邮件
        public void AddMailItem(swm.MailData _item)
        {
            MailTableBase? _config = MailTableManager.GetData((int)_item.baseid);
            if (_config != null)
            {
                MailBase bBase = GetMailItemByThisID(_item.id);
                if (null != bBase)
                {
                    //已经存在 那就刷新
                    bBase.RefreshMailItem(_item);
                }
                else
                {
                    bBase = MailFactory.Instance.CreateMailItem(_config.Value, _item);
                    m_mailList.Add( bBase );
                }
            }
            else
            {
                //LogHelper.LogWarning("AddBuff config not exist id : ", _buf.baseid.ToString(), "level :", _buf.level.ToString(), "failed!");
            }
        }

        /// <summary>
        /// 获得邮件列表
        /// </summary>
        /// <returns></returns>
        public List<MailBase> GetMailItemList()
        {
            return m_mailList;
        }

        /// <summary>
        /// 获得邮件数量
        /// </summary>
        /// <returns></returns>
        public int GetMailItemNumber()
        {
            return m_mailList.Count;
        }

        /// <summary>
        /// 通过id 删除邮件
        /// </summary>
        /// <param name="thisid"></param>
        public void RemoveMailItem(ulong thisid)
        {
            MailBase _base = GetMailItemByThisID(thisid);
            if (_base != null)
            {
                _base.Destory();
                m_mailList.Remove(_base);
            }
        }

        /**
         *移除所有邮件
         */
        public void DeleteAllMailItem()
        {
            for (int j = 0; j < m_mailList.Count; j++)
            {
                m_mailList[j].Destory();
            }
            m_mailList.Clear();
            m_mailTempList.Clear();
        }

        /// <summary>
        /// 检查是否有未读邮件
        /// </summary>
        /// <returns></returns>
        public bool CheckIsHasUnReadMail()
        {
            bool _b = false;
            for (int j = 0; j < m_mailList.Count; j++)
            {
                if (m_mailList[j].Mail_State == swm.MailState.UNREAD)
                {
                    _b = true;
                    break;
                }
            }

            return _b;
        }

        public int GetUnReadMailNumber()
        {
            int _num = 0;
            if(null != m_mailList)
            {
                for (int j = 0; j < m_mailList.Count; j++)
                {
                    if (m_mailList[j].Mail_State == swm.MailState.UNREAD)
                    {
                        _num++;
                    }
                }
            }
            return _num;
        }

        /**
         * 通过id获得邮件
         */
        public MailBase GetMailItemByThisID(ulong thisid)
        {
            MailBase _base = null;
            for (int j = 0; j < m_mailList.Count; j++)
            {
                _base = m_mailList[j];
                if (_base.ID == thisid)
                {
                    return _base;
                }
            }
            return null;
        }

        /**
         */
        public MailBase GetMailItemByBaseID(int baseid)
        {
            MailBase _base = null;
            for (int j = 0; j < m_mailList.Count; j++)
            {
                _base = m_mailList[j];
                if (_base.BaseID == baseid)
                {
                    return _base;
                }
            }
            return null;
        }

        public MailBase GetMailItemByIndex(int index)
        {          
            if ( index >= 0 && index < m_mailList.Count)
            {
                MailBase value = m_mailList[index];
                return value;
            }
            return null;
        }

        /// <summary>
        /// 获得 邮件最大数量
        /// </summary>
        public int GetMailMaxNum()
        {
           return Utility.GetMailMaxNum();
        }

    }
}