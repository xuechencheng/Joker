using System.Collections.Generic;
using Bokura;
using System.IO;

namespace Bokura
{
    class MailModel : ClientSingleton<MailModel>
    {
        #region 变量

        private uint m_UnReadMailNum = 0;


        public class MailRemoveEvent : GameEvent<int>
        {

        }

        public class RefreshmailEvent : GameEvent<MailBase>
        {

        }

        //public class ParamsMailEvent : GameEvent<List<swm.TsParamsT>>
        //{

        //}


        public class DelMailListEvent : GameEvent<Dictionary<int,int>>
        {

        }

        public GameEvent onRefreshMail = new GameEvent();

        public DelMailListEvent onRemoveMail = new DelMailListEvent();

        public RefreshmailEvent onMailInfo = new RefreshmailEvent();

        //public ParamsMailEvent onParamInfo = new ParamsMailEvent();

        private Dictionary<int, int> m_tempDelList = new Dictionary<int, int>(Const.kCap8);

        public MailRemoveEvent onUnReadMailNumChange = new MailRemoveEvent();

        public uint UnReadMailNum
        {
            get
            {
                return m_UnReadMailNum;
            }
            set
            {
                m_UnReadMailNum = value;
                onUnReadMailNumChange.Invoke((int)m_UnReadMailNum);
            }
        }

        /// <summary>
        /// 邮件详细数据
        /// </summary>
        //private swm.RspMailInfoT m_recvRspMailInfo = new swm.RspMailInfoT();

        /// <summary>
        /// 请求删除邮件
        /// </summary>
        private swm.ReqDelMailT m_sendReqDelMail = new swm.ReqDelMailT();

        #endregion

        #region 内置

        [XLua.BlackList]
        public void Init()
        {
            //注册系统逻辑事件
            RedDotModel.Instance.onRedDotEvent.AddListener(PorcRedPoint);

            //注册网络消息
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspMailList>(ProcRspMailList);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspMailInfo>(ProcRspMailInfo);
            MsgDispatcher.instance.RegisterFBMsgProc<swm.RspDelMail>(ProcRspDelMail);

        }

        public void Clear()
        {
            MailManager.Instance.DeleteAllMailItem();
            m_UnReadMailNum = 0;
        }

        #endregion

        #region 消息处理

        /// <summary>
        /// 关于 邮件的红点数据和处理
        /// </summary>
        /// <param name="_msg"></param>
        private void PorcRedPoint(RedDotData _msg)
        {
            if (_msg.RedDotType == swm.RedDotType.MAIL)
            {
                UnReadMailNum = _msg.Num;
            }
        }

        /// <summary>
        /// 接收 邮件列表
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspMailList(swm.RspMailList _msg)
        {
            MailManager.Instance.ProcRefreshMailList(_msg);
            onRefreshMail.Invoke();
        }

        /// <summary>
        /// 接收邮件详细数据
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspMailInfo(swm.RspMailInfo _msg)
        {
            //m_recvRspMailInfo.FromMsg(_msg);

            MailBase curmail = MailManager.Instance.GetMailItemByThisID(_msg.id);
            if (curmail != null)
            {
                curmail.RefreshMailItem(_msg);

                //if (_msg.paramlistLength > 0)
                //{
                //    onParamInfo.Invoke(curmail.paramlist);
                //}

                onMailInfo.Invoke(curmail);
            }
        }
        
        /// <summary>
        /// 接收 返回删除结果
        /// </summary>
        /// <param name="_msg"></param>
        private void ProcRspDelMail(swm.RspDelMail _msg)
        {
            if (_msg.ret != 0)
            {
                //成功
                if(_msg.idLength > 0)
                {
                    m_tempDelList.Clear();
                    for (int i =0;i< _msg.idLength; i++)
                    {
                        ulong _id = _msg.id(i);
                        MailBase curmail = MailManager.Instance.GetMailItemByThisID(_id);
                        if (curmail != null)
                        {
                            int _baseid = curmail.BaseID;
                            m_tempDelList[(int)_id] = _baseid;
                            MailManager.Instance.RemoveMailItem(_id);
                        }
                    }

                    if(m_tempDelList.Count>0)
                    {
                        onRemoveMail.Invoke(m_tempDelList);
                    }
                }
            }
        }

        /// <summary>
        /// 发送 请求邮件列表
        /// </summary>    
        public void SendReqMailList()
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqMailList.StartReqMailList(fbb);
            swm.ReqMailList.AddCharid(fbb,GameScene.Instance.MainChar.ThisID);
            fbb.Finish(swm.ReqMailList.EndReqMailList(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqMailList.HashID, fbb);

        }

        /// <summary>
        /// 发送 请求邮件信息
        /// </summary>
        public void SendReqMailInfo(ulong _Id)
        {
            MailBase curmail = MailManager.Instance.GetMailItemByThisID(_Id);
            if (curmail != null)
            {
                var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
                swm.ReqMailInfo.StartReqMailInfo(fbb);
                swm.ReqMailInfo.AddCharid(fbb, GameScene.Instance.MainChar.ThisID);
                swm.ReqMailInfo.AddId(fbb, (uint)_Id);
                fbb.Finish(swm.ReqMailInfo.EndReqMailInfo(fbb).Value);
                MsgDispatcher.instance.SendFBPackage(swm.ReqMailInfo.HashID, fbb);
            }
        }

        /// <summary>
        /// 发送 请求删除邮件
        /// </summary>
        public void SendReqDelMail(List<uint> _IdLst)
        {
            if(_IdLst != null && _IdLst.Count > 0)
            {
                m_sendReqDelMail.id = _IdLst;
                m_sendReqDelMail.charid = GameScene.Instance.MainChar.ThisID;
                MsgDispatcher.instance.SendFBPackage(m_sendReqDelMail);
            }
        }

        /// <summary>
        /// 发送 领取附件
        /// </summary>
        public void SendReqGetMailAttachment(ulong _Id)
        {
            var fbb = MsgDispatcher.instance.GetFlatBufferBuilder();
            swm.ReqGetMailAttachment.StartReqGetMailAttachment(fbb);
            swm.ReqGetMailAttachment.AddCharid(fbb, GameScene.Instance.MainChar.ThisID);
            swm.ReqGetMailAttachment.AddId(fbb, (uint)_Id);
            fbb.Finish(swm.ReqGetMailAttachment.EndReqGetMailAttachment(fbb).Value);
            MsgDispatcher.instance.SendFBPackage(swm.ReqGetMailAttachment.HashID, fbb);
        }

        #endregion
    }
}
