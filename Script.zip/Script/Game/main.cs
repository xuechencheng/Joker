using UnityEngine;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System;
using Bokura;

namespace Bokura
{
	/// Main entry of the game application.
    public class main : MonoBehaviour
    {
		///
        public string m_sMainLuaPath;

		/// singleton application main.
		static private main m_instance;
		public static main Instance
		{
			get
			{
				return m_instance;
			}
		}

        enum UpdateStatus
        {
            Ready,
            Updating,
            UpdateComplete,
        }

        UpdateStatus m_updateStatus = UpdateStatus.Ready;
        
        #region MONO_EVENTS
        /// Called on the frame when a script is enabled just before any of the Update methods is called the first frame. 
        void Start()
        {
            

#if (UNITY_STANDALONE_WIN) && (!UNITY_EDITOR)
            PcSelectResolutionUtility.SetCurrWindowPos(128);
#endif

#if REMOTE_DEBUG
            ParamDebugServer.Instance.Start();
#endif

#if (UNITY_IPHONE || UNITY_IOS) && !UNITY_EDITOR
            BuglyAgent.ConfigDebugMode(false);
            BuglyAgent.InitWithAppId("e8cfe9c450");
            BuglyAgent.EnableExceptionHandler();
#elif UNITY_ANDROID && !UNITY_EDITOR
            BuglyAgent.ConfigDebugMode(false);
            BuglyAgent.InitWithAppId("b9353cf22b");
            BuglyAgent.EnableExceptionHandler();
#endif

            m_instance = this;

           
            // low-level app manager
            IEngineMain.Instance.DoStart ();
            
			// 
            DontDestroyOnLoad(gameObject);

            m_updateStatus = UpdateStatus.Updating;

			SplashManager.Instance.ShowSplash(() =>
			{
//#if !UNITY_EDITOR && UNITY_STANDALONE_WIN
          //  StartCoroutine(ResourceUpdate.UpdateResource(delegate ()
         //           {
//#endif
				GameObject tUIRoot = GameObject.Find("UIRoot");
				if (tUIRoot != null)
				{
					Transform tWnd = tUIRoot.transform.Find("ui_single_UpdateWnd");
					if (tWnd != null)
						tWnd.gameObject.SetActive(false);
                }
				m_updateStatus = UpdateStatus.UpdateComplete;
				GameApplication.Instance.Init(this);
//#if !UNITY_EDITOR && UNITY_STANDALONE_WIN
       // }
		//		));
//#endif
			});

            GameApplication.Instance.Start();

            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }



		/// Called when the instance will be destroyed.
		void OnDestroy()
		{
#if REMOTE_DEBUG
            ParamDebugServer.Instance.Stop();
#endif
            // game app shutdown
            GameApplication.Instance.Shutdown();

            // low-level engine shutdown
            IEngineMain.Instance.DoDestroy ();

		}



		// Update is called once per frame.
		void Update()
		{
            if (m_updateStatus != UpdateStatus.UpdateComplete)
                return;


            IRenderUtilities.Instance.Clear();

            // low-level engine update
            IEngineMain.Instance.DoUpdate ();


            // game app update
            Utilities.ProfilerBegin("GameApplication");
            {

                GameApplication.Instance.Update();
            }
            Utilities.ProfilerEnd();

            // audio components update
            Utilities.ProfilerBegin("Audio Update");
            {
                AudioStudio.AudioManager.Instance.DoUpdate();
            }
            Utilities.ProfilerEnd();
        }



		/// Called every fixed framerate frame.
		void FixedUpdate()
		{
            if (m_updateStatus != UpdateStatus.UpdateComplete)
                return;

            GameApplication.Instance.FixedUpdate();
		}

        private void LateUpdate()
        {
            if (m_updateStatus != UpdateStatus.UpdateComplete)
                return;

            Utilities.ProfilerBegin("EngineMain");
            {
                IEngineMain.Instance.DoLateUpdate();
            }
            Utilities.ProfilerEnd();

            GameApplication.Instance.LateUpdate();
        }
        /*
        void OnGUI()
        {
            IEngineMain.Instance.DoGUI();
        }
        */
        /// Called when the player gets or loses focus
        void OnApplicationPause(bool bPause)
		{
			if (GameApplication.Instance.onPause != null)
			{
				GameApplication.Instance.onPause(bPause);
			}
		}

        //windows 版本失去焦点后 拖拽无法自动取消问题。
#if UNITY_STANDALONE_WIN
        private void OnApplicationFocus(bool focus)
        {
        
            LogHelper.Log("OnApplicationFocus", focus);
            var es = UnityEngine.EventSystems.EventSystem.current;
            if (es)
            {
                var inputmodule = es.currentInputModule;
                if (focus)
                {
                    inputmodule?.ActivateModule();
                }
                else
                {
                    inputmodule?.DeactivateModule();
                }

            }
        }
#endif

        #endregion MONO_EVENTS


        public void OnRenderObject()
        {
            if (m_updateStatus != UpdateStatus.UpdateComplete)
                return;
#if UNITY_EDITOR
            IRenderUtilities.Instance.RenderLine();
#endif
        }
    }
}

