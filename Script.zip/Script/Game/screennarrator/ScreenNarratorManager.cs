﻿using AudioStudio;
using swm;
using UnityEngine;
using Bokura;

namespace Bokura
{
    /// <summary>
    /// 屏幕旁白管理器
    /// </summary>
	public class ScreenNarratorManager: ClientSingleton<ScreenNarratorManager>
	{		
		/// <summary>
		/// 注册通信消息
		/// </summary>
		[XLua.BlackList]
		public void Init()
		{
            MsgDispatcher.instance.RegisterFBMsgProc<swm.ShowOS>(ShowOS_SC);
        }



        /// <summary>
        /// 加载配置数据
        /// </summary>
        [XLua.BlackList]
		public void Load()
		{
            m_Config = UIUtility.GetScreenNarratorData();
            m_PlaySoundCallback = OnPlaySoundCallback;
        }
		
		
		
		/// <summary>
		/// （大退/小退）清理缓存
		/// </summary>
		public void Clear()
		{
		
		}



        /// <summary>
        /// 屏幕旁白配置
        /// </summary>
        private IOverlappingSoundConfig m_Config;



        private bool m_DynamicName = false;
        /// <summary>
        /// 是否用当前主角的姓名替换OS内容中的特定称谓
        /// </summary>
        public bool dynamicName
        {
            get { return m_DynamicName; }
        }



        private Transform m_OverrideParent = null;
        /// <summary>
        /// 自定义的OS界面挂载点
        /// </summary>
        public Transform overrideParent
        {
            get { return m_OverrideParent; }
        }



        /// <summary>
        /// 淡入时长
        /// </summary>
        public float fadeInDuration { get { return null != m_Config ? m_Config.fadeInDuration : 0.5f; } }



        /// <summary>
        /// 淡出时长
        /// </summary>
        public float fadeOutDuration { get { return null != m_Config ? m_Config.fadeOutDuration : 0.5f; } }



        /// <summary>
        /// 声音播放回调
        /// </summary>
        private AkCallbackManager.EventCallback m_PlaySoundCallback;



        private GameEvent<string> m_OnShow = new GameEvent<string>();
        /// <summary>
        /// 显示屏幕旁白
        /// </summary>
        public GameEvent<string> onShow { get { return m_OnShow; } }



        private GameEvent<string> m_OnHidden = new GameEvent<string>();
        /// <summary>
        /// 隐藏屏幕旁白
        /// </summary>
        public GameEvent<string> onHidden { get { return m_OnHidden; } }



        private GameEvent<float> m_OnGetSoundDuration = new GameEvent<float>();
        /// <summary>
        /// 获得声音长度
        /// </summary>
        public GameEvent<float> onGetSoundDuration { get { return m_OnGetSoundDuration; } }



        /// <summary>
        /// 服务器通知播放屏幕旁白
        /// </summary>
        private void ShowOS_SC(ShowOS _Msg)
        {
            ShowUI(_Msg.os_id);
        }



        /// <summary>
        /// 显示屏幕旁白
        /// </summary>
        public void ShowUI(string _OsId, bool _DynamicName = false, Transform _OverrideParent = null)
        {
            m_DynamicName = _DynamicName;
            m_OverrideParent = _OverrideParent;
            m_OnShow.Invoke(_OsId);
        }



        /// <summary>
        /// 隐藏屏幕旁白
        /// </summary>
        public void HiddenUI(string _OsId)
        {
            m_OnHidden.Invoke(_OsId);
        }



        /// <summary>
        /// 获取指定屏幕旁白的指定语句内容
        /// </summary>
        public OSDataItem GetOSItem(string osId, int talkId)
        {
            OSDataItem tItem = null;
            if(null != m_Config)
            {
                OSExportData tData = m_Config.GetOSData(osId);
                tItem = tData?.GetOSItem(talkId);
            }
            return tItem;
        }



        /// <summary>
        /// 获取指定屏幕旁白的指定语句内容
        /// </summary>
        public float GetOSLoopDuration(string osId)
        {
            float tDuration = -1f;
            if (null != m_Config)
            {
                OSExportData tData = m_Config.GetOSData(osId);
                if (null != tData)
                    tDuration = tData.loopDuration;
            }
            return tDuration;
        }



        /// <summary>
        /// 获取指定屏幕旁白的语句数量
        /// </summary>
        public int GetOSCount(string osId)
        {
            int tCount = 0;
            if (null != m_Config)
            {
                OSExportData tData = m_Config.GetOSData(osId);
                if (null != tData)
                    tCount = tData.Count;
            }
            return tCount;
        }



        public void OnSkip(float skipDuration)
        {
            IEventDispatchManager.Instance.Invoke(GlobalEventID.TIMELINE_OSSKIP, skipDuration);
        }



        public void OnBreakLoop()
        {
            //可以由Timeline的SkipClip监听
            IEventDispatchManager.Instance.Invoke(GlobalEventID.TIMELINE_OSBREAKLOOP);
        }



        public uint PlaySound(uint soundId)
        {
            return AudioManager.Instance.PlaySound(soundId, (uint)(AkCallbackType.AK_Duration), m_PlaySoundCallback);
        }



        /// <summary>
        /// 停止播放声音
        /// </summary>
        public void StopSound(uint soundId)
        {
            AudioManager.Instance.StopSound(soundId);
        }



        /// <summary>
        /// 声音正常播放完成后的回调
        /// </summary>
        private void OnPlaySoundCallback(object data, AkCallbackType type, AkCallbackInfo info)
        {
            if(AkCallbackType.AK_Duration == type)
                m_OnGetSoundDuration.Invoke((info as AkDurationCallbackInfo).fDuration);
        }
    }
}
