using UnityEngine;

namespace Bokura
{
    enum EntityType
    {
        EntityType_Unknow = (1 << 0),           //< 未知类型
        EntityType_Npc = (1 << 1),           //< npc
        EntityType_Character = (1 << 2),           //< 人物角色
        EntityType_MainCharacter = (1 << 3),           //< 主角
        EntityType_Mount = (1 << 4),           //< 坐骑
    }

    public abstract class AvatarEvent
    {
        public AvatarEvent()
        {
        }

        ~AvatarEvent()
        {
        }

		public virtual Vector3 TopTitleOffset
		{
			get; set;
		}

		public virtual GameEvent TopTitleEvent
		{
			get { return null; }
		}



        public virtual GameEvent onPositionChangeEvent
        {
            get { return null; }
        }



        public virtual Transform HeadTarget
		{
			get { return null; }
		}



		/// 是否是主角 
		public virtual bool IsMainCharacter()
        {
            return false;
        }

        /// 是否是NPC
        public virtual bool IsNpc()
        {
            return false;
        }

        /// 是否是角色
        public virtual bool IsCharacter()
        {
            return false;
        }

        /// 是否是坐骑
        public virtual bool IsMount()
        {
            return false;
        }
        /// <summary>
        /// 是否是采集物
        /// </summary>
        /// <returns></returns>
        public virtual bool IsGatherResource()
        {
            return false;
        }
        /// <summary>
        /// 是否是客户端npc
        /// </summary>
        /// <returns></returns>
        public virtual bool IsClientNpc()
        {
            return false;
        }

        public virtual bool IsHomeBuilding()
        {
            return false;
        }

        /// 是否需要从鼠标拾取列表中排出，True，排除
        public virtual bool IsExceptMouseOver()
        {
            return false;
        }

        /// 获取鼠标拾取优先级
        public virtual int GetSelectPriority()
        {
            return 0;
        }

        public virtual void MessageInvoke<T>(T param)
        {
            
        }

        public virtual bool IsMale()
        {
            return false;
        }

        public virtual bool haveSkill()
        {
            return false;
        }
        public virtual void Update()
        {

        }
    }
}
