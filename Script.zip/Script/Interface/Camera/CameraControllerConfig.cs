﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;

namespace Bokura
{
    [CreateAssetMenu()]
    public class CameraControllerConfig :ScriptableObject
    {

        public float SelectTartgetMaxDistance = 20f;
        public float CameraTargetSelectRange = 0.4f;
        public float TargetLeaveCameraOverTime = 0.4f;



        public float MaxDistance = 12.0f;
        public float MinDistance = 0.4f;
        public float BoundOffset = 0.2f;
        public float InitDistance = 5f;
        
        public float MouseSlideDelta
        {
            get
            {
#if UNITY_IOS || UNITY_ANDROID
                return MobileMouseSlideDelta;
#else
                return StandloneMouseSlideDelta;
#endif
            }
            set
            {
#if UNITY_IOS || UNITY_ANDROID
                MobileMouseSlideDelta = value;
#else
                StandloneMouseSlideDelta = value;
#endif
            }
        }
        public float MouseZoomSpeed
        {
            get
            {
#if UNITY_IOS || UNITY_ANDROID
                return MobileMouseZoomSpeed;
#else
                return StandloneMouseZoomSpeed;
#endif
            }
            set
            {
#if UNITY_IOS || UNITY_ANDROID
                MobileMouseZoomSpeed = value;
#else
                StandloneMouseZoomSpeed = value;
#endif
            }
        }
        [Range(0,2)]
        [HeaderAttribute("PC平台")]
        public float StandloneMouseSlideDelta = 0.1f;
        [Range(0, 10)]
        public float StandloneMouseZoomSpeed = 2;

        [Range(0, 2)]
        [HeaderAttribute("移动平台")]
        public float MobileMouseSlideDelta = 0.25f;

        [Range(0, 10)]
        public float MobileMouseZoomSpeed = 5;
        public CameraCharacterConfig[] CharacterConfig;
        public AnimationCurve FOVCurve = AnimationCurve.Linear(0, 60, 15, 30);

    }

    [Serializable]
    public class CameraCharacterConfig
    {
        public string PrefabName;
        public AnimationCurve LookTargetOffsetCurve = AnimationCurve.Linear(0, 1.5f, 15, 1f);

    }
}