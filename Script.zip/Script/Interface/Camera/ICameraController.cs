using System;
using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    public abstract class ICameraController 
    {
        protected ICameraHelper ICameraHelper;

        public ICameraController(CameraControlMode mode, ICameraHelper hepler)
        {
            ICameraHelper = hepler;
            ICameraHelper.AddController(mode,this);
        }

        public virtual void Enter(ICameraController prev) { }
        public virtual void Leave(ICameraController next) { }

        public abstract void Init();
        public abstract void DeInit();
        public abstract void ResetConfig();
        public abstract void Update();
        public abstract void LateUpdate();
        public virtual bool WorldMove(Vector3 _, Vector3 delta) { return false; }


        //x2engine 访问的接口。
        public virtual void UpdateCameraAnimation(CameraData data, float progress) { }
    }
}

