using System;
using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    public enum CameraControlMode
    {
        ThreeCamera,
        FreeCamera,
        VisitNpcCamera,
        SimpleCamera,
        ManorBuildingCamera,
        TierTrainCamera,
        XYFreeCamera, //平面摄像机 拍照用
        HomeBuildCamera,    // 家园建筑摄像机
        HomeBuildDetailCamera,  // 家园建筑细节查看摄像机
        HomeFieldCamera,    // 家园灵田摄像机
        SeptBuildCamera,    // 仙门建筑查看摄像机
        Count,
    }
    public abstract class ICameraHelper : IBase<ICameraHelper>
    {
        public static ICameraHelper Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.CameraHelper");
                }
                return m_instance;
            }
        }

        public abstract ICameraController CurrentController { get; }

        public abstract bool isFreeMode { get; }
        public abstract Camera MainCamera { get; }
        public abstract GameObject MainCameraGameObject { get; }
        public abstract Transform MainCameraTransform { get; }

        public abstract void AddController(CameraControlMode mode,ICameraController controller);
        public abstract void SwitchController(CameraControlMode mode);
        public abstract CameraControlMode GetNowMode();
        public abstract void Init();
        public abstract void DeInit();
        public abstract void Reset();
        public abstract void Update();
        public abstract void Pause(bool pause = true);

        public abstract void LateUpdate();
        public abstract bool WorldMove(Vector3 _, Vector3 delta);



        public abstract void CloseUserLayer(UserLayer layer);

        public abstract void OpenUserLayer(UserLayer layer);

        public abstract int GetCurrCullingMask();
        public abstract void SetCurrCullingMask(int mask);

        public abstract bool CheckLayerIsOpen(UserLayer layer);

        public abstract void EnableDOF(bool enabled, float focusDistance, float focalLength = 80, float aperture = 10, UnityEngine.Rendering.PostProcessing.KernelSize kernelsize = UnityEngine.Rendering.PostProcessing.KernelSize.Large);
        public abstract float GetDOFFocusDistance();

        public abstract void EnableBlur(bool enabled, int downsample = 1, int blurIterations = 1, float blurSize = 3.0f);


        public abstract GameEvent OnScreenSnapshootEvent { get; }
        public abstract void StartSnapshoot();
        public abstract void GenerateScreenShot(UnityEngine.UI.Image ui);

        
        public abstract void ToggleHeightFog(bool open);

        public abstract void SetFOV( float fov);
        public abstract void SetFOVRange(float min, float max);
        public abstract void RevertFOV();

        public abstract float GetNowFOV();

    }

}

