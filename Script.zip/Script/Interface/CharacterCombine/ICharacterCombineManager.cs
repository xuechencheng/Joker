﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura {

  /// <inheritdoc />
  /// <summary>
  /// use this manager to combine character async.
  /// </summary>
  public abstract class ICharacterCombineManager : ISingletonMonoManager {
    
    /// singleton instance of the log system.
    protected static WeakReference s_instance;
    public static ICharacterCombineManager Instance 
    {
      get
      {
        return (null != s_instance) ? s_instance.Target as ICharacterCombineManager : null;
      }
    }

    /// <summary>
    /// the coroutine interval type.
    /// </summary>
    public enum IntervalType {
      Frames,
      Seconds,
    }

    /// <summary>
    /// the working statistics.
    /// </summary>
    public struct Statistics {
      public int workingTaskCount;
      public int aquiredTaskCount;
      public float maxBlockedTime;
      public string maxBlockedStep;

      public Statistics(int workingTaskCount, int aquiredTaskCount, float maxBlockedTime, string maxBlockedStep) {
        this.workingTaskCount = workingTaskCount;
        this.aquiredTaskCount = aquiredTaskCount;
        this.maxBlockedTime = maxBlockedTime;
        this.maxBlockedStep = maxBlockedStep;
      }
    }

    [InspectorTooltipAttribute("The combine progross interval type.")]
    public IntervalType combineIntervalType = IntervalType.Frames;
    [InspectorTooltipAttribute("The combine progross interval in frames.")]
    public int combineIntervalFrames = 5;
    [InspectorTooltipAttribute("The combine progross interval in seconds.")]
    public float combineIntervalTime = 0.1f;

    /// <summary>
    /// which bones you want to kept after optimization.
    /// </summary>
    public string[] exportBoneNames;

    /// <summary>
    /// the statistics information.
    /// </summary>
    [System.NonSerialized]
    public Statistics statistics = new Statistics(0, 0, 0.0f, string.Empty);

    /// <summary>
    /// require to combine.
    /// </summary>
    /// <param name="targetGameObject">must the general skeleton game object.</param>
    /// <param name="partGameObjects">all part game objects.</param>
    /// <param name="onCompleted">the completion callback.</param>
    /// <param name="isPackTexture">whether to pack the texture.</param>
    /// <param name="textureFormat">the packed texture format.</param>
    /// <param name="useMipMap">whether to mipmap for the texture.</param>
    /// <param name="packingPadding">the pack padding.</param>
    /// <param name="additionalTextureParameterIds">the additional texture parameter in the material.</param>
    /// <returns>the combine task id(can cancel task by this id).</returns>
    public abstract int RequireCombine(
      GameObject targetGameObject,
      GameObject[] partGameObjects,
      Action<int, GameObject> onCompleted,
      bool isPackTexture = true,
      TextureFormat textureFormat = TextureFormat.RGBA32,
      bool useMipMap = true,
      int packingPadding = 16,
      int[] additionalTextureParameterIds = null
    );

    /// <summary>
    /// cancel combine task by id.
    /// </summary>
    /// <param name="taskId">the task id.</param>
    public abstract void CancelCombine(int taskId);

    /// <summary>
    /// update statistics information.
    /// </summary>
    public abstract void UpdateStatistics();
    
    /// <summary>
    /// reset statistics information.
    /// </summary>
    public abstract void ResetStatistics();
  }

}
