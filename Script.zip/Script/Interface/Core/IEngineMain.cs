/********************************************************************
	created:	2017/11/6
	author:		LuoJiEn
	purpose:    Interface of the low-level engine.
*********************************************************************/
using UnityEngine;
using System;



namespace Bokura
{
	/// Interface of the low-level engine.
	public abstract class IEngineMain : MonoBehaviour
    {
		#region INSPECTOR_PARAMETERS
		/// current application mode.
		public enum RuntimeMode
		{
			Development, 	// development build, with all debug info(assert, log) and Unity development build
			Pseudo,         // pseudo build, with all debug info(assert,log) and and Unity release build 
			Release,		// release build, fully optimized and no debug info
		};
		[InspectorLabelFieldAttribute ("Application build mode")]
		public RuntimeMode m_mode;

		/// current application state.
		public enum RuntimeState
		{
			NotStarted, // the application is not started	
			Running, 	// the application is running
			Paused,		// the application is paused
		};
		[InspectorLabelFieldAttribute ("Application execution state")]
		public RuntimeState m_state = RuntimeState.NotStarted;

		/// Unity scene to start with.
		public string    m_startScene;

		/// whether to show all debug onGUI.
		[InspectorTooltipAttribute ("Whether to enable all debug onGUI")]
		public bool      m_showAllGUI = true;     	// enable/disable onGUI	

		/// whether to lock FPS
		[InspectorTooltipAttribute ("Whether to lock FPS")]
		public bool      m_lockFPS = false;

		/// for autotest.
		public string 	 m_autoTestSuite;	// autotest suite to run
		[InspectorTooltipAttribute ("Life span of the autotest suite")]
		public float     m_testCaseLife = 60.0f;    // life span for test case in the suite

		/// singleton instance of the Engine Main.
		protected static IEngineMain s_instance;
		public static IEngineMain Instance 
		{
			get
			{
				return s_instance;
			}
		}

        /// used only for wetest check.
        protected bool m_latestResultForWeTest = false;
        public bool LatestResultForWeTest
        {
            set { m_latestResultForWeTest = true; }
        }
        #endregion INSPECTOR_PARAMETERS

        public abstract void InitRenderPileline();

		public abstract bool GameInited { get; set; }
        /// Called on the frame when a script is enabled just before any of the Update methods is called the first frame.
        public abstract void DoStart ();

		/// Called when the instance will be destroyed.
		public abstract void DoDestroy ();

		/// Called once per frame.
		public abstract void DoUpdate ();

        /// <summary>
        /// Called before loading scene
        /// </summary>
        public abstract void DoPreLoadScene (string scenename, Action<bool> onLoadDone);

        /// Called once per frame.
        public abstract void DoLateUpdate();

        /// Called for rendering and handling GUI events.
        public abstract void DoGUI ();

		/// Add a new manager.
		/// <param name="type"> type of the manager to register.</param>
		public abstract void AddManager (Type type);

		/// Add a new manager.
		/// <param name="manager"> the manager to register.</param>
		public abstract void AddManager (ISingletonMonoManager manager);
		public abstract void AddManager (ISingletonManager manager);

		/// Remove a manager.
		/// <param name="type"> type of the manager to unregister.</param>
		public abstract void RemoveManager (Type type);

		/// Remove a manager.
		/// <param name="manager"> the manager to unregister.</param>
		public abstract void RemoveManager (ISingletonMonoManager manager);
		public abstract void RemoveManager (ISingletonManager manager);

		// Quit the application
		public abstract void QuitApp ();
    }
}
