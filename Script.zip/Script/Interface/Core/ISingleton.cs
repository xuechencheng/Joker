/********************************************************************
	created:	2017/11/6
	author:		LuoJiEn
	purpose:    Interface of all singleton managers.
*********************************************************************/
using UnityEngine;



namespace Bokura
{
	/// Base interface for all singleton managers.
	public abstract class ISingletonManager
	{
		/// Called on the frame when a script is enabled just before any of the Update methods is called the first frame.
		public virtual void DoStart () {}

		/// Called when the instance will be destroyed.
		public virtual void DoDestroy () {}

		/// Called once per frame.
		/// <param name="deltaTime"> time elapsed since last frame, in seconds.</param>
		public virtual void DoUpdate (float deltaTime) {}

        /// Called once per frame.
        /// <param name="deltaTime"> time elapsed since last frame, in seconds.</param>
        public virtual void DoLateUpdate(float deltaTime) {}

        /// Called for rendering and handling GUI events.
        public virtual void DoGUI () {}
	}



	/// Base interface for all singleton managers.
	public abstract class ISingletonMonoManager : MonoBehaviour
	{
		/// Called on the frame when a script is enabled just before any of the Update methods is called the first frame.
		public virtual void DoStart () {}

		/// Called when the instance will be destroyed.
		public virtual void DoDestroy () {}

		/// Called once per frame.
		/// <param name="deltaTime"> time elapsed since last frame, in seconds.</param>
		public virtual void DoUpdate (float deltaTime) {}

        /// Called for rendering and handling GUI events.
        public virtual void DoGUI () {}
	}

    /// <summary>
    /// base singleton manager,  for managed singleton class
    /// all singleton witch inherit from class ISingleton need to be added to this manager  
    /// do not inherit from this class except singleton manager
    /// </summary>
    /// <typeparam name="T"></typeparam>
    class ISingletonManager<T> where T : new()
    {
        static protected T m_instance;

        public static T Instance
        {
            get
            {
                if (m_instance == null)
                    m_instance = new T();
                return m_instance;
            }
        }
    }


    /// Base interface for all singleton.
    public interface ISingletonInterface
    {
    }


    /// simple singleton class
    public class ISingleton<T> : ISingletonInterface
    {
        static protected T m_instance;

        public static T Instance
        {
            get { return m_instance; }
        }
    }
}