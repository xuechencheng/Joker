using System;
using UnityEngine;

namespace Bokura
{
	public abstract class ICrossPlatformInputManager : IBase<ICrossPlatformInputManager>
	{
        public enum ActiveInputMethod
        {
            Hardware,
            Touch
        }

        #region property
        static public ICrossPlatformInputManager Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.CrossPlatformInputManager");
                }
                return m_instance;
            }
        }



		public abstract bool enable
		{ get; set; }

        #endregion

        public abstract IVirtualInput GetMobileInput();

		public abstract IVirtualInput GetActiveInput();

        public abstract void SwitchActiveInputMethod(ActiveInputMethod activeInputMethod);

        public abstract void ControlCameraMode(bool bSet);

        public abstract void ControlCameraHorizontalDeltaX(float horizontalx);

        public abstract void ControlCameraVerticalDeltaY(float verticaly);


        public abstract void Update();

        #region Input
        public abstract bool AxisExists(InputVirtualAxis axis);

        public abstract bool ButtonExists(string name);

        public abstract void RegisterVirtualAxis(VirtualAxis axis);


        public abstract void RegisterVirtualButton(VirtualButton button);


        public abstract void UnRegisterVirtualAxis(InputVirtualAxis axis);


        public abstract void UnRegisterVirtualButton(string name);


        // returns a reference to a named virtual axis if it exists otherwise null
        public abstract VirtualAxis VirtualAxisReference(InputVirtualAxis axis);


        // returns the platform appropriate axis for the given name
        //public abstract float GetAxis(string name);


        public abstract float GetAxisRaw(InputVirtualAxis axis);


        // private function handles both types of axis (raw and not raw)
        public abstract float GetAxis(InputVirtualAxis axis, bool raw = false );


        // -- Button handling --
        public abstract bool GetButton(string name);


        public abstract bool GetButtonDown(string name);


        public abstract bool GetButtonUp(string name);


        public abstract void SetButtonDown(string name);


        public abstract void SetButtonUp(string name);


        public abstract void SetAxisPositive(InputVirtualAxis axis);


        public abstract void SetAxisNegative(InputVirtualAxis axis);


        public abstract void SetAxisZero(InputVirtualAxis axis);


        public abstract void SetAxis(InputVirtualAxis axis, float value);


        public abstract Vector3 mousePosition
		{
			get;
		}



		public abstract Vector3 centerPosition
		{
			get;
		}



        public abstract void SetVirtualMousePositionX(float f);


        public abstract void SetVirtualMousePositionY(float f);

        public abstract void SetVirtualMousePositionZ(float f);

        #endregion



        // virtual axis and button classes - applies to mobile input
        // Can be mapped to touch joysticks, tilt, gyro, etc, depending on desired implementation.
        // Could also be implemented by other input devices - kinect, electronic sensors, etc
        public class VirtualAxis
		{
            public InputVirtualAxis Axis { get; private set; }
            //public string name { get; private set; }
			private float m_Value;
			public bool matchWithInputManager { get; private set; }
            public bool Enable = true;


            public VirtualAxis(InputVirtualAxis axis)
				: this(axis, true)
			{
			}
            public VirtualAxis(InputVirtualAxis axis, bool matchToInputSettings)
            {
                this.Axis = axis;
                //this.name = axis.ToString();
                matchWithInputManager = matchToInputSettings;

            }


			// removes an axes from the cross platform input system
			public void Remove()
			{
                ICrossPlatformInputManager.Instance.UnRegisterVirtualAxis(Axis);
			}


			// a controller gameobject (eg. a virtual thumbstick) should update this class
			public void Update(float value)
			{
				m_Value = value;
			}


			public float GetValue
			{
				get { return m_Value; }
			}


			public float GetValueRaw
			{
				get { return m_Value; }
			}
		}

		// a controller gameobject (eg. a virtual GUI button) should call the
		// 'pressed' function of this class. Other objects can then read the
		// Get/Down/Up state of this button.
		public class VirtualButton
		{
			public string name { get; private set; }
			public bool matchWithInputManager { get; private set; }

			private int m_LastPressedFrame = -5;
			private int m_ReleasedFrame = -5;
			private bool m_Pressed;


			public VirtualButton(string name)
				: this(name, true)
			{
			}


			public VirtualButton(string name, bool matchToInputSettings)
			{
				this.name = name;
				matchWithInputManager = matchToInputSettings;
			}


			// A controller gameobject should call this function when the button is pressed down
			public void Pressed()
			{
				if (m_Pressed)
				{
					return;
				}
				m_Pressed = true;
				m_LastPressedFrame = Time.frameCount;
			}


			// A controller gameobject should call this function when the button is released
			public void Released()
			{
				m_Pressed = false;
				m_ReleasedFrame = Time.frameCount;
			}


			// the controller gameobject should call Remove when the button is destroyed or disabled
			public void Remove()
			{
                ICrossPlatformInputManager.Instance.UnRegisterVirtualButton(name);
			}


			// these are the states of the button which can be read via the cross platform input system
			public bool GetButton
			{
				get { return m_Pressed; }
			}


			public bool GetButtonDown
			{
				get
				{
					return m_LastPressedFrame - Time.frameCount == -1;
				}
			}


			public bool GetButtonUp
			{
				get
				{
					return (m_ReleasedFrame == Time.frameCount - 1);
				}
			}
		}
	}
}
