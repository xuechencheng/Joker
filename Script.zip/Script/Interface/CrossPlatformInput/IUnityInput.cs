using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Bokura
{
    [XLua.LuaCallCSharp]
    public abstract class IUnityInput : IBase<IUnityInput>
    {
        public static IUnityInput Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.UnityInput");
                }
                return m_instance;
            }
        }
        public abstract bool multiTouchEnabled { get; set; }
        public abstract Vector3 mousePosition { get; }
        public abstract int touchCount { get; }
        public abstract float GetAxis(string axisName);
        public abstract float GetAxisRaw(string axisName);
        public abstract bool GetKey(string name);
        public abstract bool GetKey(KeyCode key);
        public abstract bool GetKeyDown(KeyCode key);
        public abstract bool GetKeyDown(string name);
        public abstract bool GetKeyUp(KeyCode key);

        public abstract bool GetKeyUp(string name);
        public abstract bool GetMouseButton(int button);
        public abstract bool GetMouseButtonDown(int button);
        public abstract bool GetMouseButtonUp(int button);
        public abstract Touch GetTouch(int index);
        public abstract void SetInputMonitor(IInputMonitor monitor);
    }

    public interface IInputMonitor
    {
        void OnEnter();
        void OnExit();
        void OnBeginFrame();
        void OnEndFrame();

        Vector3? mousePosition { get; }
        int? touchCount { get; }
        float? GetAxis(string axisName);
        float? GetAxisRaw(string axisName);
        bool? GetKey(string name);
        bool? GetKey(KeyCode key);
        bool? GetKeyDown(KeyCode key);
        bool? GetKeyDown(string name);
        bool? GetKeyUp(KeyCode key);

        bool? GetKeyUp(string name);
        bool? GetMouseButton(int button);
        bool? GetMouseButtonDown(int button);
        bool? GetMouseButtonUp(int button);
        Touch? GetTouch(int index);
    }

    public interface IUIEventMonitor
    {
        void OnEnter();
        void OnExit();
        void OnBeginFrame();
        void OnEndFrame();
        void OnSceneLoading(Scene scene);
        void OnSceneLoaded(Scene scene, LoadSceneMode mode);
    }
}
