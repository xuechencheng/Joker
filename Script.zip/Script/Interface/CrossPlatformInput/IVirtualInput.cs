using System;
using System.Collections.Generic;
using UnityEngine;


namespace Bokura
{
    public enum InputVirtualAxis
    {
        CharHorizontalAxis,
        CharVerticalAxis,
        CameraHorizontalAxis,
        CameraVerticalAxis,
        CameraDistanceAxis,
        CameraHorizontalMoveAxis,
        CameraVerticalMoveAxis,
        Horizontal,

        Count,
    }

    public enum InputVirtualButton
    {
        Count
    }
    public abstract class IVirtualInput
    {


        public IVirtualInput()
        {
        }
  //      public static readonly string CharHorizontalAxisName = "CharHorizontal"; 
  //      public static readonly string CharVerticalAxisName = "CharVertical";
  //      public static readonly string CameraHorizontalAxisName = "CameraHorizontal";
  //      public static readonly string CameraVerticalAxisName = "CameraVertical";
  //      public static readonly string CameraDistanceAxisName = "Mouse ScrollWheel";
		//public static readonly string CameraHorizontalMoveAxisName = "CameraHorizontalMove";
		//public static readonly string CameraVerticalMoveAxisName = "CameraVerticalMove";

        private bool ControlCamera = false;
		private bool m_Enable = true;
		private float CameraHorizontalDeltaX = 0.0f;
        private float CameraVerticalDeltaY = 0.0f;

        #region property

		public bool enable
		{
			get { return m_Enable; }
			set { m_Enable = value; }
		}



        public Vector3 virtualMousePosition { get; private set; }
        public bool controlCamera
        {
            get
            {
                return ControlCamera;
            }
            set
            {
                ControlCamera = value;
            }
        }

        public float cameraHorizontalDeltaX
        {
            get
            {
                return CameraHorizontalDeltaX;
            }
            set
            {
                CameraHorizontalDeltaX = value;
            }
        }

        public float cameraVerticalDeltaY
        {
            get
            {
                return CameraVerticalDeltaY;
            }
            set
            {
                CameraVerticalDeltaY = value;
            }
        }
        #endregion

        protected ICrossPlatformInputManager.VirtualAxis[] m_VirtualAxes = new ICrossPlatformInputManager.VirtualAxis[(int)InputVirtualAxis.Count];

        //protected Dictionary<string, ICrossPlatformInputManager.VirtualAxis> m_VirtualAxes = new Dictionary<string, ICrossPlatformInputManager.VirtualAxis>();
        // Dictionary to store the name relating to the virtual axes
        protected Dictionary<string, ICrossPlatformInputManager.VirtualButton> m_VirtualButtons = new Dictionary<string, ICrossPlatformInputManager.VirtualButton>();
        protected List<InputVirtualAxis> m_AlwaysUseVirtual = new List<InputVirtualAxis>();
        // list of the axis and button names that have been flagged to always use a virtual axis or button


        public abstract void Update();



		protected abstract void Reset();



        #region Axis
        public bool AxisExists(InputVirtualAxis axis)
        {
            return m_VirtualAxes[(int)axis] != null && m_VirtualAxes[(int)axis].Enable;
        }

        public void AddAxes(InputVirtualAxis axis)
        {
            // we have not registered this button yet so add it, happens in the constructor
            RegisterVirtualAxis(new ICrossPlatformInputManager.VirtualAxis(axis));
        }

        // returns a reference to a named virtual axis if it exists otherwise null
        public ICrossPlatformInputManager.VirtualAxis VirtualAxisReference(InputVirtualAxis axis)
        {
            return (m_VirtualAxes[(int)axis] != null && m_VirtualAxes[(int)axis].Enable) ? m_VirtualAxes[(int)axis] : null;
        }

        public void RegisterVirtualAxis(ICrossPlatformInputManager.VirtualAxis axis)
        {
            // check if we already have an axis with that name and log and error if we do
            if (m_VirtualAxes[(int)axis.Axis] != null && m_VirtualAxes[(int)axis.Axis].Enable)
            {
                LogHelper.LogErrorFormat(LogCategory.Input, "There is already a virtual axis named {0}  registered.", axis.Axis);
            }
            else
            {
                // add any new axes
                if (m_VirtualAxes[(int)axis.Axis] == null)
                    m_VirtualAxes[(int)axis.Axis] = axis;

                m_VirtualAxes[(int)axis.Axis].Enable = true;
                // if we dont want to match with the input manager setting then revert to always using virtual
                if (!axis.matchWithInputManager)
                {
                    m_AlwaysUseVirtual.Add(axis.Axis);
                }
            }
        }
        public void UnRegisterVirtualAxis(InputVirtualAxis axis)
        {
            // if we have an axis with that name then remove it from our dictionary of registered axes
            if(m_VirtualAxes[(int)axis] != null)
            {
                m_VirtualAxes[(int)axis].Enable = false;
            }
        }

        public virtual float GetAxis(InputVirtualAxis axis, bool raw)
        {
            if (m_VirtualAxes[(int)axis] == null)
            {
                AddAxes(axis);
            }
            return m_VirtualAxes[(int)axis].GetValue;
        }


        public virtual void SetAxisPositive(InputVirtualAxis axis)
        {
            if (m_VirtualAxes[(int)axis] == null)
            {
                AddAxes(axis);
            }
            m_VirtualAxes[(int)axis].Update(1f);
        }
        public virtual void SetAxisNegative(InputVirtualAxis axis)
        {
            if (m_VirtualAxes[(int)axis] == null)
            {
                AddAxes(axis);
            }
            m_VirtualAxes[(int)axis].Update(-1f);
        }
        public virtual void SetAxisZero(InputVirtualAxis axis)
        {
            if (m_VirtualAxes[(int)axis] == null)
            {
                AddAxes(axis);
            }
            m_VirtualAxes[(int)axis].Update(0f);
        }
        public virtual void SetAxis(InputVirtualAxis axis, float value)
        {
            if (m_VirtualAxes[(int)axis] == null)
            {
                AddAxes(axis);
            }
            m_VirtualAxes[(int)axis].Update(value);
        }
        #endregion

        #region Button

        public bool ButtonExists(string name)
        {
            return m_VirtualButtons.ContainsKey(name);
        }

        public void RegisterVirtualButton(ICrossPlatformInputManager.VirtualButton button)
        {
            // check if already have a buttin with that name and log an error if we do
            if (m_VirtualButtons.ContainsKey(button.name))
            {
                LogHelper.LogError(LogCategory.Input, "There is already a virtual button named ", button.name, " registered.");
            }
            else
            {
                // add any new buttons
                m_VirtualButtons.Add(button.name, button);

                // if we dont want to match to the input manager then always use a virtual axis
                if (!button.matchWithInputManager)
                {
                    //m_AlwaysUseVirtual.Add(button.name);
                }
            }
        }

        public void UnRegisterVirtualButton(string name)
        {
            // if we have a button with this name then remove it from our dictionary of registered buttons
            if (m_VirtualButtons.ContainsKey(name))
            {
                m_VirtualButtons.Remove(name);
            }
        }
        public void AddButton(string name)
        {
            // we have not registered this button yet so add it, happens in the constructor
            Bokura.ICrossPlatformInputManager.Instance.RegisterVirtualButton(new ICrossPlatformInputManager.VirtualButton(name));
        }

        public abstract bool GetButton(string name);
        public abstract bool GetButtonDown(string name);
        public abstract bool GetButtonUp(string name);
        public abstract void SetButtonDown(string name);
        public abstract void SetButtonUp(string name);

        #endregion



        #region Mouse
        public void SetVirtualMousePositionX(float f)
        {
            virtualMousePosition = new Vector3(f, virtualMousePosition.y, virtualMousePosition.z);
        }


        public void SetVirtualMousePositionY(float f)
        {
            virtualMousePosition = new Vector3(virtualMousePosition.x, f, virtualMousePosition.z);
        }


        public void SetVirtualMousePositionZ(float f)
        {
            virtualMousePosition = new Vector3(virtualMousePosition.x, virtualMousePosition.y, f);
        }

        public abstract Vector3 MousePosition();

		public abstract Vector3 centerPosition();
        #endregion

        #region multipoint touch process
        public virtual void OnSceneTouchDown(UnityEngine.EventSystems.PointerEventData e) { }

        public virtual void OnSceneTouchUp(UnityEngine.EventSystems.PointerEventData e) { }

        #endregion
    }
}
