﻿using UnityEngine;
using System;

namespace Bokura
{
    /// Interface of the dynamic bone module.
    public abstract class IDynamicBoneManager : ISingletonManager
    {
        /// singleton instance. 
        protected static WeakReference s_instance;
        public static IDynamicBoneManager Instance
        {
            get
            {
                return (null != s_instance) ? s_instance.Target as IDynamicBoneManager : null;
            }
        }

        public Transform m_ReferenceObject;

        public abstract void AddDynamicBone(DynamicBone dynamicBone);
        public abstract void RemoveDynamicBone(DynamicBone dynamicBone);
        public abstract void EnableDynamicBone(DynamicBone dynamicBone);
        public abstract void DisableDynamicBone(DynamicBone dynamicBone);
    }
}
