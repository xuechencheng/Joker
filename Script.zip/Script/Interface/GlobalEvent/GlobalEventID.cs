namespace Bokura
{
    /// <summary>
    /// 全局事件枚举（该文件自动生成，添加请修改sj-全局事件.xlsx，然后使用工具："Tools/手动生成全局事件枚举"）
    /// </summary>
    public class GlobalEventID
    {
        /// <summary>
        /// [占位]
        /// <summary>
        public const uint NONE = 0;
        /// <summary>
        /// 环境配置切换了
        /// <summary>
        public const uint ENVIRONMENT_PROFILE_CHANGED = 1;
        /// <summary>
        /// 开始加载
        /// <summary>
        public const uint BEGIN_LOADING = 2;
        /// <summary>
        /// 结束加载
        /// <summary>
        public const uint END_LOADING = 3;
        /// <summary>
        /// 创建主角色完成
        /// <summary>
        public const uint CREATE_MAIN_CHARACTER = 4;
        /// <summary>
        /// 获取图片完成
        /// <summary>
        public const uint PHOTO_CALLBACK = 5;
        /// <summary>
        /// Timeline跳转
        /// <summary>
        public const uint TIMELINE_SKIPCLIP = 6;
        /// <summary>
        /// Timeline拍照
        /// <summary>
        public const uint TIMELINE_SNAPSHOOT = 7;
        /// <summary>
        /// Timeline的OS跳过
        /// <summary>
        public const uint TIMELINE_OSSKIP = 8;
        /// <summary>
        /// Timeline的OS跳出循环
        /// <summary>
        public const uint TIMELINE_OSBREAKLOOP = 9;
        /// <summary>
        /// Timeline响应玩家选择的QTE
        /// <summary>
        public const uint TIMELINE_QTE_RESPONSE = 10;
        /// <summary>
        /// 玩家选择QTE
        /// <summary>
        public const uint QTE_SELECTED = 11;
    }
}