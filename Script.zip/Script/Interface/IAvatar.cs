using System;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public delegate void OnAvatarCreateDelegate();

    public delegate void OnAnimStateMachineChangeDelegate(int stateid, int layer);

    [XLua.BlackList]
    public delegate void OnAvatarAnimDelegate(Magic.MagicContext context, AnimEvent eventType, List<EventParam> paramlist);

    public delegate void OnTimelineEventDelegate(AnimEvent eventType);

    public enum AvatarShadowType
    {
        None,
        Unique,
        Decal,
    }
    public enum RefreshAnimatorWay { Refresh, Add, Remove, }
    public interface IAvatar
	{
		GameEvent onCreate { set; get; }

        LoadCallback onLevel0HeadLoaded { set; get; }

        OnAvatarAnimDelegate onAnimEvent { set; get; }

		OnAnimStateMachineChangeDelegate onLeaveStateMachine { set; get; }
		OnAnimStateMachineChangeDelegate onEnterStateMachine { set; get; }

        OnTimelineEventDelegate onTimelineEvent { set; get; }

        UnityEngine.GameObject unityObject { get; set; }


        AvatarAttachment targetAttachment { get; }

        IMaterialPropertyGroup MaterialProterties { get; }

        bool Visible {set;get;}

		bool EnableGrassCollider { set; get; }

        bool EnableLOD { set; get; }

        bool NeedAnimBlend { get; }

        AvatarShadowType shadowType { set; get; }

        
        void Release();
        void SetPosition(float x, float y, float z);

        void SetPosition(Vector3 p);
        Vector3 GetDirection();
        void SetDirection(float x, float y, float z);

        void SetDirectionAngle(float yAngle);


        void SetScale(float x, float y, float z);
        void LoadModel(string strAssetBundlesPath, string strModelName, bool bAsync);

        void LoadPart(AvatarPart part, string strAssetBundlesPath, string strModelName, bool Async, LoadCallback callback = null);
        void LoadSubPart(AvatarPart parentPart, string strAssetBundlesPath, string strModelName, string subBoneName, LoadCallback callback = null);


        void CastMagic(CastMagicData data);
        void CastDefenderMagic(CastDefenderData data);
        void StopMagicAction(uint skillId);

        void Update();

        bool IsInView(Camera camera);

        void SetLayer(Int32 layer);


        Collider getBoundBox();

		void AttachTo(IAvatar targetAvatar, AvatarAttachment target, AvatarAttachment src);

        void AttachToMount(IAvatar targetAvatar, AvatarAttachment target, AvatarAttachment src, string MountName);

        UnityEngine.Transform GetAttachmentTransform(AvatarAttachment transform);

        void DontDestoryOnLoad();

        void OnAvatarChanged(GameObject go);

        void ResetAvatar();
        void SetHorseShadow();
        void ResumeHorseShadow();

        void EnableBulletTime(bool isOn);

        void ReleaseMagicTrackBuilder();


        #region animator
        AnimatorWraper animator { get; }

        Vector3 AnimatorDeltaPosition { get; }
        void RefreshAllAnimator(RefreshAnimatorWay way = RefreshAnimatorWay.Refresh,Animator animator = null);
        void SetAnimParamFloat(int hashName, float f);
        void SetAnimParamFloat(int hashName, float f, float damptime, float deltatime);
        void SetAnimParamBool(int hashName, bool b);

        AnimatorStateInfo GetCurrentAnimatorStateInfo(int layer = 0);
        AnimatorStateInfo GetNextAnimatorStateInfo(int layer = 0);

        #endregion
    }

}
