using UnityEngine;

namespace Bokura
{
    public abstract class IAvatarPicker : IBase<IAvatarPicker>
    {
        static public IAvatarPicker Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.AvatarPickerExport");
                }
                return m_instance;
            }
        }

        public abstract AvatarEvent GetNearestAvatar(Vector3 pos);
        public abstract void Clear();
    }
}
