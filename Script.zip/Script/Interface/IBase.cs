using System;

namespace Bokura
{
    public class IBase<T>
    {
        static protected T m_instance;
        static protected void CreateInstance(string strTypeName)
        {
            /// use reflection construct instance
            Type t = Type.GetType(strTypeName);
			//由于脚本没有被外链，SceneEditor项目中可能遇到t为null的情况
			if (t == null) return;
            m_instance = (T)Activator.CreateInstance(t);
        }
    }
}