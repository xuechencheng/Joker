namespace Bokura
{
    public delegate void SceneLoadingFinishedCallback(float fMinX, float fMinY, float fMinZ, float fMaxX, float fMaxY, float fMaxZ);
    public delegate void LoadCallback(UnityEngine.Object o);
    public delegate void ShaderLoadCallback(UnityEngine.Shader o);
}
