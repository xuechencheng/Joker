﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    public abstract class IDebugBlackboard : MonoBehaviour
    {
        protected static IDebugBlackboard instance;

        public static void Output(string key, String format, params object[] args)
        {
#if UNITY_EDITOR
            if (instance == null)
            {
                GameObject go = new GameObject();
                go.name = "IDebugBlackboard";
                DontDestroyOnLoad(go);

                Type t = Type.GetType("Bokura.DebugBlackboard");
                go.AddComponent(t);
            }

            instance.DoOutput(key, format, args);
#endif
        }
        public static void Erase(string key)
        {
#if UNITY_EDITOR
            instance.DoErase(key);
#endif
        }
        

        protected abstract void DoOutput(string key, String format, params object[] args);

        protected abstract void DoErase(string key);
    }
}
