﻿using UnityEngine;

namespace Bokura
{
    public abstract class IDynamicObstruct : IBase<IDynamicObstruct>
    {

        #region property
        static public IDynamicObstruct Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.DynamicObstruct");

                }
                return m_instance;
            }
        }
        #endregion

        #region public interface
        public enum ObstructType
        {
            box,
            sphere,
            capsule,
            mesh,
        }
        public abstract void AddGameObjectObstruct(GameObject go, ObstructType obType);
        public abstract void RemoveGameObjectObstruct(GameObject go);
        #endregion
    }
}
