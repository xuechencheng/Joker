﻿using System;

namespace Bokura
{
    public abstract class IEventDispatchManager : IBase<IEventDispatchManager>
    {

        #region property
        static public IEventDispatchManager Instance
        {
            get
            {
                if (m_instance == null)
                    CreateInstance("Bokura.EventDispatchManager");
                return m_instance;
            }
        }
        #endregion



        #region public interface
        /// <summary>
        /// listener的实际类型必须是System.Action、System.Action<T0>、System.Action<T0, T1>、System.Action<T0, T1, T2>、System.Action<T0, T1, T2, T3>中的任意一种，不能直接将函数地址作为实参
        /// </summary>
        public abstract void AddListener(uint eventId, Delegate listener);



        /// <summary>
        /// listener的实际类型必须是System.Action、System.Action<T0>、System.Action<T0, T1>、System.Action<T0, T1, T2>、System.Action<T0, T1, T2, T3>中的任意一种，不能直接将函数地址作为实参
        /// </summary
        public abstract void RemoveListener(uint eventId, Delegate listener);



        public abstract void RemoveAllListeners(uint eventId);



        public abstract void Invoke(uint eventId);



        public abstract void Invoke<T>(uint eventId, T arg0);



        public abstract void Invoke<T0, T1>(uint eventId, T0 arg0, T1 arg1);



        public abstract void Invoke<T0, T1, T2>(uint eventId, T0 arg0, T1 arg1, T2 arg2);



        public abstract void Invoke<T0, T1, T2, T3>(uint eventId, T0 arg0, T1 arg1, T2 arg2, T3 arg3);

        #endregion
    }
}
