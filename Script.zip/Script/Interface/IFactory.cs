using System;
using Magic;


namespace Bokura
{
    public abstract class IFactory : IBase<IFactory>
    {
       
        #region property
        static public IFactory Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.Factory");
                }
                return m_instance;
            }
        }
        #endregion

        #region object create interface
        public abstract IAvatar CreateAvatar(AvatarEvent avatarEvent);
        #endregion

        #region object release interface
        public abstract void ReleaseAvatar(IAvatar avatar);
        #endregion

        #region PlayableBehaviourEx create interface
        [XLua.BlackList]
        public abstract ActionBehaviour CreateActionBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseActionBehaviour(ActionBehaviour behaviour);
        [XLua.BlackList]
        public abstract EffectBehaviour CreateEffectBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseEffectBehaviour(EffectBehaviour behaviour);
        [XLua.BlackList]
        public abstract DefendEffectBehaviour CreateDefendEffectBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseDefendEffectBehaviour(DefendEffectBehaviour behaviour);
        [XLua.BlackList]
        public abstract MaterialBehaviour CreateMaterialBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseMaterialBehaviour(MaterialBehaviour behaviour);
        [XLua.BlackList]
        public abstract CameraBehaviour CreateCameraBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseCameraBehaviour(CameraBehaviour behaviour);
        [XLua.BlackList]
        public abstract CameraAnimationBehaviour CreateCameraAnimationBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseCameraAnimationBehaviour(CameraAnimationBehaviour behaviour);
        [XLua.BlackList]
        public abstract DefendCameraBehaviour CreateDefendCameraBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseDefendCameraBehaviour(DefendCameraBehaviour behaviour);
        [XLua.BlackList]
        public abstract RadialBlurBehaviour CreateRadialBlurBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseRadialBlurBehaviour(RadialBlurBehaviour behaviour);
        [XLua.BlackList]
        public abstract BulletBehaviour CreateBulletBehaviour();
        [XLua.BlackList]
        public abstract void ReleaseBulletBehaviour(BulletBehaviour behaviour);
        #endregion
    }
}
