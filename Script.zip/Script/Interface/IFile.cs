using System;
using System.IO;
using UnityEngine;
using System.Runtime.InteropServices;

namespace Bokura
{
    public static class IFile
    {
        public static string AppBundleID = "com.ztgame.xxm";
#if UNITY_ANDROID
        static AndroidJavaClass jc_UnityPlayer;        
        static AndroidJavaObject jo_batteryIntent;   
        static IntPtr jni_read_file_bytes;
        static IntPtr jni_extractAllAssets;
        static AndroidJavaObject jo_currentActivity;
        static AndroidJavaObject jni_currentActivity
        {
            get
            {
                if (jc_UnityPlayer == null)
                    jc_UnityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                if (jo_currentActivity == null)
                    jo_currentActivity = jc_UnityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
                return jo_currentActivity;
            }
        }

        static AndroidJavaObject _jo_fileutility;
        [XLua.BlackList]
        public static AndroidJavaObject jni_fileutility
        {
            get
            {
                if (_jo_fileutility == null)
                {
                    LogHelper.Log("create java object FileUtility start");
                    _jo_fileutility = new AndroidJavaObject(AppBundleID + ".FileUtility");
                    LogHelper.Log("create java object FileUtility end");
                    var classid = AndroidJNI.FindClass((AppBundleID + "/FileUtility").Replace('.', '/'));
                    jni_read_file_bytes = AndroidJNI.GetMethodID(classid, "readFileBytes", "(Ljava/lang/String;)[B");
                    jni_extractAllAssets = AndroidJNI.GetMethodID(classid, "extractAllAssets", "(Ljava/lang/String;)V");
                    LogHelper.Log("jni_read_file_bytes", jni_read_file_bytes, "extractAllAssets", jni_extractAllAssets);
                    //jni_is_file_exist = AndroidJNI.GetMethodID(classid, "isFileExist", "(Ljava/lang/String;)Z");
                }
                return _jo_fileutility;
            }
        }


        static AndroidJavaObject jo_intentFilter;
        static AndroidJavaObject jni_batteryIntent
		{
			get
			{
				if (jo_intentFilter==null)
				{
					jo_intentFilter = new AndroidJavaObject("android.content.IntentFilter", new object[] { "android.intent.action.BATTERY_CHANGED" });
					
				}
				jo_batteryIntent = jni_currentActivity.Call<AndroidJavaObject>("registerReceiver", new object[] { null, jo_intentFilter });
				return jo_batteryIntent;
			}
		}
#endif

        /// Is the file exist
        /// <param name="path"> The file path</param>
        public static bool IsFileExist(string path)
        {
#if UNITY_ANDROID
            if (path.Contains("jar:file"))
            {
                if (path.Length > IResourceLoader.streamingAssetsPath.Length && IResourceLoader.streamingAssetsPath == path.Substring(0, IResourceLoader.streamingAssetsPath.Length))
                {
                    string packpath = path.Substring(IResourceLoader.streamingAssetsPath.Length, path.Length - IResourceLoader.streamingAssetsPath.Length);
                    return jni_fileutility.Call<bool>("isFileExist", packpath);
                }
            }

            if (File.Exists(path))
                return true;
            return false;
#else
            return File.Exists(path);
#endif

        }

        /// <summary>
        /// load resource from persistent path first
        /// if null, load resource form streaming path
        /// </summary>
        /// <param name="fileName">the name of resource</param>
        /// <returns></returns>
        public static byte[] LoadResourceFiles(string fileName)
        {
            if(string.IsNullOrEmpty(fileName))
            {
                LogHelper.LogError("File name is empty or null");
                return null;
            }
                
            byte[] dataToFill = null;
            string strFileName;
            if (
#if UNITY_EDITOR
                AssetBundleManager.UseAssetBundle &&
#endif
                !IResourceLoader.donotUsePersistentFolderResource)
            {
                if (fileName[0] != '/')
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.persistentDataPath, "/", fileName);
                else
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.persistentDataPath, fileName);
                dataToFill = Bokura.IFile.ReadApkResourceFiles(strFileName);
            }
            if(dataToFill == null)
            {
                if(fileName[0] != '/')
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.streamingAssetsPath, "/", fileName);
                else
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.streamingAssetsPath, fileName);
                dataToFill = Bokura.IFile.ReadApkResourceFiles(strFileName);
            }
            return dataToFill;
        }
        public static string GetResourceDirFullName(string dirPath)
        {
            if (string.IsNullOrEmpty(dirPath))
            {
                LogHelper.LogError("dirPath is empty or null");
                return null;
            }

            string strFileName = null;
            if (
#if UNITY_EDITOR
                AssetBundleManager.UseAssetBundle &&
#endif
                !IResourceLoader.donotUsePersistentFolderResource)
            {
                if (dirPath[0] != '/')
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.persistentDataPath, "/", dirPath);
                else
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.persistentDataPath, dirPath);
            }
            if (strFileName == null)
            {
                if (dirPath[0] != '/')
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.streamingAssetsPath, "/", dirPath);
                else
                    strFileName = Bokura.Utilities.BuildString(IResourceLoader.streamingAssetsPath, dirPath);
            }
            return strFileName;
        }
        /// read file from apk files or window file
        /// <param name="path"> The file path</param>
         public static byte[] ReadApkResourceFiles(string path)
        {
#if UNITY_ANDROID
            if (path.Contains("jar:file"))
            {
                if (path.Length > IResourceLoader.streamingAssetsPath.Length && IResourceLoader.streamingAssetsPath == path.Substring(0, IResourceLoader.streamingAssetsPath.Length))
                {
                    string packpath = path.Substring(IResourceLoader.streamingAssetsPath.Length, path.Length - IResourceLoader.streamingAssetsPath.Length);

                    jvalue[] jv = new jvalue[1];
                    var utf8 = AndroidJNI.NewStringUTF(packpath);
                    jv[0].l = utf8;
                    var rt = AndroidJNI.CallObjectMethod(jni_fileutility.GetRawObject(), jni_read_file_bytes, jv);
                    AndroidJNI.DeleteLocalRef(utf8);
                    if (rt == IntPtr.Zero)
                    {
                        return null;
                    }
                    var bytes = AndroidJNI.FromByteArray(rt);
                    AndroidJNI.DeleteLocalRef(rt);
                    return bytes;
                }
            }
#endif
			try
			{
                if (File.Exists(path))
                {
                    return File.ReadAllBytes(path);
                }
                else
                {
                    LogHelper.LogWarning(LogCategory.Framework, "Can't load file: " + path.ToString());
                }
            }
            catch
            {
                LogHelper.LogWarning(LogCategory.Framework, "Exception catched by loading file: " + path.ToString());
            }
            return null;

		


        }

        static public void ExtractAssetsFromApk()
        {
#if UNITY_ANDROID            
            jni_fileutility.Call("extractAllAssets", Application.persistentDataPath);
#endif
        }

        static public void GetExtractAssetState(
            out  int curstep,
            out int totalstep,
            out int curstepWriteBytes,
            out int curstepTotalBytes,
            out int state
            )
        {

#if UNITY_ANDROID
            curstep = jni_fileutility.Call<int>("getCurExtractStep");
            totalstep = jni_fileutility.Call<int>("getTotalExtractStep");
            curstepWriteBytes = jni_fileutility.Call<int>("getCurExtractStepWritedBytes");
            curstepTotalBytes = jni_fileutility.Call<int>("getCurExtractStepTotalBytes");
            state = jni_fileutility.Call<int>("getExtractState");
#else

            curstep = 0;
            totalstep = 1;
            curstepWriteBytes = 0;
            curstepTotalBytes = 1;
            state = 0;
#endif
        }


        /// write windows file
        /// <param name="fname"> The name of file </param>
        /// <param name="buf"> The content of file </param>
        public static bool WriteBytes(string fname, byte[] buf)
        {
            string p;
            //使用Path.Combine能够确保如果上层已经拼接完全路径，这里的拼接会被忽略
#if UNITY_EDITOR
            if (IResourceLoader.donotUsePersistentFolderResource || !AssetBundleManager.UseAssetBundle)
                p = Path.Combine(IResourceLoader.streamingAssetsPath, fname);
            else
#endif
                p = Path.Combine(IResourceLoader.persistentDataPath, fname);
            string dir = Path.GetDirectoryName(p);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            File.WriteAllBytes(p, buf);
            return true;
        }

        /// delete windows file
        /// <param name="path"> The path of file </param>
        public static bool DeleteFile(string path)
        {
            try
            {
                File.Delete(path);
                return true;
            }
            catch
            {
                return false;
            }

        }

        /// delete windows dir
        /// <param name="path"> The path of dir </param>
        public static bool DeleteDirectory(string path)
        {
            try
            {
                if (!Directory.Exists(path))
                    return true;

                Directory.Delete(path, true);
                return true;
            }
            catch (Exception e)
            {
                LogHelper.LogError("delete dir error:", e.ToString());
                return false;
            }

        }

        public static bool Delete(string path)
        {
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                else if (Directory.Exists(path))
                    Directory.Delete(path, true);

                return true;
            }
            catch (Exception e)
            {
                LogHelper.LogError("delete dir error:", e.ToString());
                return false;
            }
        }

        /// get the battery level
        public static float GetBatteryLevel()
        {
#if UNITY_ANDROID
            try
            {
                int level = jni_batteryIntent.Call<int>("getIntExtra", new object[] { "level", -1 });
                int scale = jni_batteryIntent.Call<int>("getIntExtra", new object[] { "scale", -1 });

                // Error checking that probably isn't needed but I added just in case.
                if (level == -1 || scale == -1)
                {
                    return 1.0f;
                }
                return ((float)level / (float)scale);


            }
            catch (Exception e)
            {
                LogHelper.LogError("Get BatteryLevel Error!" + e.ToString());
                return -1.0f;
            }
#elif UNITY_IPHONE || UNITY_IOS
			return 0.0f;/*ios_get_battery_level();*/
#else
            return 0.6f;
#endif

    }
#if UNITY_EDITOR
        /// <summary>
        /// Create a new script object asset or open an exist script object asset: 
        /// Attention: Only use in editor mode
        /// </summary>
        /// <typeparam name="T">the type of scriptobject</typeparam>
        /// <param name="filePath">like,"Assets/xxx/xxx.asset"</param>
        /// <returns></returns>
        public static T OpenScriptObjectAsset<T>(string filePath) where T : ScriptableObject
        {
            int index = filePath.LastIndexOf("/");
            if(index >= 0)
            {
                string directoryPath = filePath.Substring(0, index);
                if(!System.IO.Directory.Exists(directoryPath))
                {
                    System.IO.Directory.CreateDirectory(directoryPath);
                }
            }

            T dataScriptable;
            string tmpFullPath = Application.dataPath.Replace("Assets", "");
            tmpFullPath = tmpFullPath + filePath;
            if(!System.IO.File.Exists(tmpFullPath))
            {
                /// create asset
                dataScriptable = UnityEngine.ScriptableObject.CreateInstance<T>();
                UnityEditor.AssetDatabase.CreateAsset(dataScriptable, filePath);
                P4V.AutoAdd(filePath);
            }
            else
            {
                P4V.AutoCheckOut(filePath);
            }
            /// load asset for edit
            dataScriptable = UnityEditor.AssetDatabase.LoadAssetAtPath<T>(filePath);
            UnityEditor.EditorUtility.SetDirty(dataScriptable);

            return dataScriptable;

        }
#endif
    }
}

