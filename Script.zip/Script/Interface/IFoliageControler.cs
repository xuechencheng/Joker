﻿
using System;
using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    public abstract class IFoliageControler : IBase<IFoliageControler>
    {
        static public IFoliageControler Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("CritiasFoliage.FoliageControler");
                }
                return m_instance;
            }
        }

        public abstract void SetFoliagePhysic(CritiasFoliage.EFoliagePhysicType pt);

    }
}
