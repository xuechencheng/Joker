using UnityEngine;

namespace Bokura
{
    public abstract class IGame : IBase<IGame>
    {
        static public IGame Instance
        {
            get
            {
                if(m_instance == null)
                {
                    CreateInstance("Game.Game");
                }
                return m_instance;
            }
        }

        public abstract MainCharacter GetMainCharacter();
        public abstract IAvatar GetMainChar();
        public abstract bool IsInGame();
        public abstract bool IsOutGame();

        public abstract bool MainCharIsInAir();
        public abstract void RefreshMechanismOperateStr();

        public abstract bool IsMainCharCurrInCloud();
        public abstract Vector3 MainCharLocalPosition();

        public abstract UnityEngine.Canvas GetUICanvas();

        public abstract uint GetCurrentIntomapId();

        public abstract void MiddleNotifyModelDisplayString(string content);

        public abstract int GetBuildVersion();

        public abstract bool IsInLoading();
#if WE_TEST && DEBUG && UNITY_ANDROID && !UNITY_EDITOR && !SCENE_EDITOR && !OUTERNET
        public abstract string GotoPosition(string posStr);

        private string GotoMap(string mapId);
#endif
    }

   
}
