﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System;

namespace Bokura
{
    public abstract class IGameMonoUpdateManager : IBase<IGameMonoUpdateManager>
    {
        static public IGameMonoUpdateManager Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Game.GameMonoUpdateManager");
                }
                return m_instance;
            }
        }

        #region public interface
        public abstract void MonoUpdate();

        public abstract void AddToUpdate(Action callback);

        public abstract void RemoveFromUpdate(Action callback);
        #endregion
    }
}
