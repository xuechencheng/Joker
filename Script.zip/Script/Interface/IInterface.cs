using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    /// layer's enum of unity
    public enum UserLayer
    {
        Layer_Default = 0,
        Layer_TransparentFX = 1,
        Layer_IngoreRaycast = 2,
        Layer_BuiltinLayer3 = 3,
        Layer_Water = 4,
        Layer_UI = 5,
        Layer_BuiltinLayer6 = 6,
        Layer_BuiltinLayer7 = 7,
        Layer_Terrain = 8,
        Layer_Character = 9,
        Layer_MainCharacter = 10,
        Layer_NPC = 11,
        Layer_StaticMeshBig = 12,
        Layer_StaticMeshMiddle = 13,
        Layer_StaticMeshSmall = 14,
        Layer_Tree = 15,
        Layer_Grass = 16,
        Layer_Trigger = 17,
        Layer_FX = 18,
        Layer_ShadowCaster = 19,
        Layer_TerrainObject = 20,
        Layer_Landscape = 21,
        Layer_UI3D = 22,
        Layer_Ocean = 23,
        Layer_Reflection = 24,
        Layer_FogVolume = 25,
        Layer_FogBake =26,
        Layer_AirWall = 27,
        Layer_SOInvisible = 29,
        Layer_AvatarShow = 30,
        Layer_Invisible = 31,
    }
    public enum UserLayerMask
    {
        Default = 1 << 0,
        TransparentFX = 1 << 1,
        IngoreRaycast = 1 << 2,
        BuiltinLayer3 = 1 << 3,
        Water = 1 << 4,
        UI = 1 << 5,
        BuiltinLayer6 = 1 << 6,
        BuiltinLayer7 = 1 << 7,
        Terrain = 1 << 8,
        Character = 1 << 9,
        MainCharacter = 1 << 10,
        NPC = 1 << 11,
        StaticMeshBig = 1 << 12,
        StaticMeshMiddle = 1 << 13,
        StaticMeshSmall = 1 << 14,
        Tree = 1 << 15,
        Grass = 1 << 16,
        Trigger = 1 << 17,
        FX = 1 << 18,
        ShadowCaser = 1 << 19,
        TerrainObject = 1 << 20,
        Landscape = 1 << 21,
        UI3D = 1 << 22,
        Ocean = 1 << 23,
        Reflection = 1 << 24,
        FogVolume = 1 << 25,
        FogBake = 1 << 26,
        AirWall = 1 << 27,
        SOInvisible = 1 << 29,
        AvatarShow = 1 << 30,
        Invisible = 1 << 31,

        AllBlock = Default | Terrain | StaticMeshSmall | StaticMeshMiddle | StaticMeshBig | TerrainObject | Tree | Landscape | Ocean | AirWall | Water,
        Grounds = Terrain | StaticMeshBig | TerrainObject | StaticMeshMiddle | StaticMeshSmall,
        CameraBlock = Terrain | StaticMeshSmall | StaticMeshMiddle | StaticMeshBig | Ocean | TerrainObject,
    }
    //public enum AnimatorControllerType
    //{
    //    ACT_Aattck,
    //    ACT_Defender,
    //}

    /// <summary>
    /// AvatarAttachment 挂载点对应的骨骼名
    /// </summary>
    public static class AvatarAttachmentToBoneNode
    {
        public static string[] CharacterAttachmentBone = new string[]
        {
            "",                 //0
            "Bip001 PropL",     //1 手掌
            "Bip001 PropR",     //2
            "bone_back01",
            "Bip001 L Forearm",
            "Bip001 Spine1",
            "Root",             //6
            "Bip001 Head" ,     //7 脖子
			"Bip001 Head" ,
            "Bip001 L Hand",     //9 手腕
            "Bip001 R Hand",
             "Bip001 R Forearm",
             "",
             "Bip001 FixSpine1",
             "Bip001 L Toe0",           //14 左脚底
             "Bip001 R Toe0",           //15 右脚底
			 "buff_head_node",
			 "gua_handL",
			 "gua_handR",
			 "Carry",
			 "Bip001",
             "target_sel_node",        //21
             "",                    //22 动作表情用了
             "",                    //23
        };
        public static string[] WeaponAttachmentBone = new string[]
        {
            "",					//0
            "gua_handL",		//1
            "gua_handR",		//2
            "gua_back",			//3
            "gua_forearm",		//4
            "gua_Spine",		//5
            "gua_Root",			//6
            "head_root",		//7
            "Bone_hair_root",	//8
            "",					//9
            "",					//10
            "gua_forearm",		//11
            "",					//12
            "",					//13
            "",					//14
            "",					//15
			"",					//16
			"",					//17			
			""	,				//18
			"",					//19
			"Bip001",			//20
            "target_sel_node",  //21
            "",                 //22
            "",                 //23
        };

    }


    //挂载点定义
    public enum AvatarAttachment
    {
        None,
        LeftHandProp,   //左手手掌
        RightHandProp,  //右手手掌
        Back,           //后背（胸口）
        LeftForearm,    //左臂
        Spine,          //脊椎（腰）
        Root,           //脚底
        Head,           //脖子
        Hair,           //脖子（同头）
        LeftHand,       //左右手腕
        RightHand,      //右手手腕
        RightForearm,    //右臂
        MainCamera,       //主相机 这个一般在非技能特效的时候才用。
        FixSpine,           //和腰的位置起始一样，没有旋转。
        LeftSole,           //左脚底
        RightSole,          //右脚底
		UIBuff,         //头顶buff
		LeftWeapon,     //左手武器
		RightWeapon,    //右手武器
		Carry,			//坐骑载点
		Bip001,			
        TargetSelect,     //目标选择点
        EomteStand,         //动作表情挂载点  动态new 出来的

		End,            //23
    }

    public enum AvatarPart
    {
        Body,
        Head,
        Hair,
        Count,
    }


    //清晨、清晨下雨、清晨下雪、中午、中午下雨、中午下雪、黄昏、黄昏下雨、黄昏下雪、夜晚、夜晚下雨、夜晚下雪;
    [System.Flags]
    public enum WeatherType
    {
        Default = 0,

        MorningSunny = 1,
        MorningRain = 2,
        MorningSnow = 3,

        MiddaySunny = 4,
        MiddayRain = 5,
        MiddaySnow = 6,

        DuskSunny = 7,
        DuskRain = 8,
        DuskSnow = 9,

        EveningSunny = 10,
        EveningRain = 11,
        EveningSnow = 12,

        MorningRedSun = 13,
        MiddayRedSun = 14,
        DuskRedSun = 15,
        EveningRedSun = 16,

        NULL = 255
    }


    public static class AnimatorParam
    {
        public static int InCloudGround = Utilities.AnimatorStringToHash("InCloudGround");
        public static int InWater = Utilities.AnimatorStringToHash("InWater");
        public static int Ground = Utilities.AnimatorStringToHash("Ground");
        public static int IsFlying = Utilities.AnimatorStringToHash("IsFlying");
        public static int SpeedH = Utilities.AnimatorStringToHash("SpeedH");
        public static int SpeedV = Utilities.AnimatorStringToHash("SpeedV");

        public static int EmoteMove = Utilities.AnimatorStringToHash("EmoteMove");

        public static int IsCold = Utilities.AnimatorStringToHash("IsCold");
        public static int IsHot = Utilities.AnimatorStringToHash("IsHot");
        public static int IsNormal = Utilities.AnimatorStringToHash("IsNormal");
    }

    public enum AnimEvent
    {
        AttackHit,
        AttackBullet,
        AttackEnd,
        AttackWait,
        ShowPWeapon,
        ShowSWeapon,
        HidePWeapon,
        HideSWeapon,
        ShowAvatar,
        HideAvatar,
        FoliageWeapon,
        FoliageFire,
        RefreshTopTitle,
        SwitchWeaponToLeftHand,
        SwitchWeaponToRightHand,
        SwitchWeaponToBack,
        SwitchShieldToLeftHand,
        SwitchShieldToBack,
        QingKungEnd,
        DodgeEnd,
        Take,
        ShowPWeaponAndRevert,
        ShowSWeaponAndRevert,
        HidePWeaponAndRevert,
        HideSWeaponAndRevert,
        SwitchWeaponToLeftHandAndRevert,
        SwitchWeaponToRightHandAndRevert,
        SwitchWeaponToBackAndRevert,
        HideAvatarAndRevert,
        DestoryGameObject,
        CastSkillCamRotate,
        SwitchItem,
        SwitchCameraTargetNode,

        // 下面是客户端关心的事件, 不需要美术加到timeline
        SkillEnd,
        ActionEnd,

        //
        InteractionPoint_ServeEvent,  //交互点服务事件
        Talk,                           //播一次说话动作
    }

    public enum SpawnInstanceCategory
    {
        Effect,
        Weapon,
        Gizmos,
    }

    public static class UserTags
    {
        public const string SmallTag = "SmallTag";
        public const string MiddleTag = "MiddleTag";
        public const string BigTag = "BigTag";
        public const string PrimaryWeaponTag = "PrimaryWeaponTag";
        public const string SecondaryWeaponTag = "SecondaryWeaponTag";
    }
    public class GameEvent : UnityEvent
    {
        public GameEvent()
        {

        }
    }

    public class GameEvent<T> : UnityEvent<T>
    {
        public GameEvent()
        {

        }

    }

    public class GameEvent<T0, T1> : UnityEvent<T0, T1>
    {
        public GameEvent()
        {

        }
    }

    public class GameEvent<T0, T1, T2> : UnityEvent<T0, T1, T2>
    {
        public GameEvent()
        {

        }
    }

    public class GameEvent<T0, T1, T2, T3> : UnityEvent<T0, T1, T2, T3>
    {
        public GameEvent()
        {

        }
    }
}