using UnityEngine.Rendering.PostProcessing;

namespace Bokura
{
    public abstract class ILevelSystemManager : IBase<ILevelSystemManager>
    {
        static public ILevelSystemManager Instance
        {
            get
            {
                if(m_instance == null)
                {
                    CreateInstance("Bokura.LevelSystemManager");
                }
                return m_instance;
            }
        }

        public abstract void DoInit();

        public abstract void SetDefaultLevelSystem();

        public abstract void SetLevelSystemInt(int level);
        public abstract int GetLevelSystemInt();

        public abstract void Apply();

        public abstract void SetUniqueShadowForHead(bool isHead);

        public abstract int GetTargetFrameRate();
        public abstract int SetTargetFrameRate(bool isHigh);
        public abstract void SetResolution(float scale);

        public abstract bool GetEnableBloom();
        public abstract void SetEnableBloom(bool isEnable);
        public abstract bool GetEnableColorGrading();
        public abstract void SetEnableColorGrading(bool isEnable);

        public abstract bool GetEnableDepthOfField();
        public abstract void SetEnableDepthOfField(bool isEnable);

        public abstract bool GetEnableSunshaft();
        public abstract void SetEnableSunshaft(bool isEnable);

        public abstract PostProcessLayer.Antialiasing GetAntiAliasing();
        public abstract void SetAntiAliasing(int mode);

        public abstract int SetSameScreenRolesNumber(int number);
        public abstract int GetSameScreenRolesNumber();

        public abstract int SetSameScreenEffectsNumber(int number);
        public abstract int GetSameScreenEffectsNumber();

        public abstract bool IsShowDecalShadow();
        public abstract void SetIsShowDecalShadow(bool isShow);

        public abstract void SetRenderScaleTypeNum(int typeNum);//Bokura.SystemLevelInfo
    }
}
