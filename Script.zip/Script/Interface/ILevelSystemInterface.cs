

namespace Bokura
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

    /// <summary>
    /// For Scene Shadow settings
    /// </summary>
    [Serializable]
    public struct ShadowSettings
    {
        public UniqueShadowSettings uniqueShadowSetting;
    }

    /// <summary>
    /// For Main character shadow settings
    /// </summary>
    [Serializable]
    public struct UniqueShadowSettings
    {
        public bool use;
        public float cullDistance;
        public float lightNearSize;
        public float lightFarSize;
        public float horseShadowRadius;
        public FocusSetup headFocusSetups;
        public FocusSetup bip001FocusSetups;
    }

    [System.Serializable]
    public class FocusSetup
    {
        public float fallbackFilterWidth = 3;
        public float radius = 1.2f;
        public float maleDepthBias = 0.001f;
        public float femaleDepthBias = 0.0096f;
        public AvatarAttachment targetAttachment = AvatarAttachment.Bip001;
    }
}
