﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    public abstract class ILocalizationManager : IBase<ILocalizationManager>
    {
        #region events

        #endregion

        #region property
        static public ILocalizationManager Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Game.LocalizationManager");
                }
                return m_instance;
            }
        }
        #endregion

        #region public interface

        //private abstract string GetLanguageAB(SystemLanguage language);
        //public abstract void ReadData();
        //public abstract void SetLanguage(SystemLanguage language);
        public abstract void Init();
        public abstract void ManualSetLanguage(SystemLanguage setLanguage);
        public abstract string GetText_ID(int id);

        public abstract string GetText_HashCode(int hashcode);

        public abstract string GetText(string content);

        public abstract string GetLanguageAB(SystemLanguage language);
        public abstract SystemLanguage GetcurrentLanguage();
        //public abstract void RefreshPrefab();

        ////刷新UIRoot下Text的文本
        //public abstract void RefreshPrefabString(Transform root);

        #endregion
    }
}
