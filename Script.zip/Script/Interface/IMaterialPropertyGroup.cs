﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    /// <summary>
    /// 对于Renderer的MaterialPropertyBlock操作的封装
    /// </summary>
	public interface IMaterialPropertyGroup  
    {
        void EnableKeyword(string nameID);
        void DisableKeyword(string nameID);
        void SetTexture2D(string nameID, Texture2D value);

        void SetVector(int nameID, Vector4 value);

        void SetVector(string name, Vector4 value);

        void SetColor(int nameID, Color value);

        void SetColor(string name, Color value);

        void SetFloat(int nameID, float value);

        void SetFloat(string name, float value);

        void LateUpdate();

        void ApplyChange();
    }

}

