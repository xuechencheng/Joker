using System;

namespace Bokura
{
    public abstract class IMonoUpdateManager : IBase<IMonoUpdateManager>
    {
        static public IMonoUpdateManager Instance
        {
            get
            {
                if (m_instance == null)
                    CreateInstance("Bokura.MonoUpdateManager");
                return m_instance;
            }
        }

        #region public interface
        [XLua.BlackList]
        public abstract void MonoUpdate();
        public abstract void MonoLateUpdate();

        public abstract void AddToUpdate(Action callback);

        public abstract void RemoveFromUpdate(Action callback);

        public abstract void AddToLateUpdate(Action callback);

        public abstract void RemoveFromLateUpdate(Action callback);

        #endregion
    }
}