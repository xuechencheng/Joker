using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public abstract class IParticleSystem: IBase<IParticleSystem>
    {
        #region property
        static public IParticleSystem Instance
        {
            get
            {
                if(m_instance == null)
                    CreateInstance("Bokura.VFXManagement.VFXImplementation");
                return m_instance;
            }
        }
        #endregion

        #region public interface
        public abstract void LoadFX(string strAssetBundlePath, string strName, LoadCallback callback);
        public abstract GameObject CreateEffectObject(GameObject go, FilterType entityFilterType = 0);
        public abstract GameObject CreateEffectObject(GameObject go, Vector3 pos, Quaternion rot, FilterType entityFilterType = 0);
        public abstract void FreeEffectObject(GameObject go);
        #endregion
    }
}
