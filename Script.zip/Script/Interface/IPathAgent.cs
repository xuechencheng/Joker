using UnityEngine;
using System.Collections.Generic;

namespace Bokura
{

    public abstract class IPathAgent : IBase<IPathAgent>
    {
        #region property
        static public IPathAgent Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.AI.NewPathFinderAgent");

                }
                return m_instance;
            }
        }
        #endregion

        #region public interface
        public abstract bool PathUpdate(Vector3 curPos, Vector3 destPos);
        public abstract Vector3[] onStop(Vector3 position);
        public abstract Vector3 DestPos();

        public abstract void NotifySceneLoaded(string scenename);
        public abstract bool FindMainPath(Vector3 start, Vector3 dest, List<Vector3> path);
#if UNITY_EDITOR
        /// <summary>
        /// render the finding path in scene mode, for debugging
        /// </summary>
        /// <param name="bShow">true: render the finding path</param>
        [XLua.BlackList]
        public abstract void RenderPath(bool bShow);
#endif
#endregion
    }
}
