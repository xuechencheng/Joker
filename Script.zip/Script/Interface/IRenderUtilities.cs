using UnityEngine;

namespace Bokura
{
    public abstract class IRenderUtilities : IBase<IRenderUtilities>
    {
        static public IRenderUtilities Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.RenderUtilities");
                }
                return m_instance;
            }
        }

        public abstract void DrawSingleLine(Vector3 start, Vector3 end, Color clr);
        public abstract void DrawSingleLine(float startX, float startY, float startZ, float endX, float endY, float endZ, Color clr);
        public abstract void Clear();
        public abstract void DrawBounds(Bounds bound, Color clr);
        public abstract void RenderLine();
    }
}
