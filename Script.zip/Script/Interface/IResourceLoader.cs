using System;
using UnityEngine;
using System.IO;

namespace Bokura
{
    public abstract class IResourceLoader : IBase<IResourceLoader>
    {
		public static string streamingAssetsPath = Application.streamingAssetsPath;

#if UNITY_STANDALONE_WIN
        public static string persistentDataPath = PathUtility.SimplifiedPath(Path.Combine(Application.dataPath, "../PersistentData/"));
#else
        public static string persistentDataPath = Application.persistentDataPath;
#endif

        public static string strPrefabsPath = "prefabs/";
        public const string strVideoPath = "Videos/";
        public const string strEnvProfilePath = "art_resource/profiler/";
        public const string strPostProfilePath = "prefabs/environment/sky/";
        public static string strEffectPath = "art_resource/effect/effect/";
        public const string strNpcPath = "prefabs/npc/";
        public const string strNpcWeaponPath = "prefabs/weapons/npc_weapons/";
        public const string strCharacterPath = "prefabs/character/";
        public static string strDecorationPath = "prefabs/character/chr_decoration/";
        public static string strBuildingPath = "prefabs/environment/";
        public static string strResourcePath = "prefabs/resource/";
        public const string strWeaponPath = "prefabs/weapons/";
        public static string strTrapPath = "prefabs/traps/";
        public static string strSkillEffectTexturePath = "art_resource/effect/sharedTexture/";
        public static string strSkillEffectPath = "art_resource/effect/effect/skillEffect/";
        public static string strSkillEffectImportPath = "art_resource/effect/effect/skillEffect_import/";
        public static string strBuffEffectPath = "art_resource/effect/effect/sceneEffect_buff/";
        public static string strBuffEffectImportPath = "art_resource/effect/effect/sceneEffect_buff_import/";
        public static string strSharedMaterialPath = "art_resource/effect/sharedMaterials/timeline_materials/";
        public static string _strSharedMaterialPath = "art_resource/effect/sharedMaterials/";

        public const string strTimeline= "prefabs/timeline/";
        public static string strEventDataPath = "prefabs/eventdata/";
        public const string strSkillMagicPath = "prefabs/skillmagic/";
        public const string strEffectConfigPath = "prefabs/effect/";
        public const string strMagicTimelinePath = "prefabs/magictimeline/";
        public const string strMagicAnimeventPath = "prefabs/magicanimevent/";

        public const string strAnimationPathPath = "prefabs/animationpath/";
		public const string strMountPath = "prefabs/mounts/";
        public const string MagicPath = "asset/playable/magic/";
        public const string faceExpressionPath = "playable/expression/";
        public static string strCharacterBodyPath = "prefabs/character/chr_body/";
        public const string strCharacterHeadPath = "prefabs/character/chr_head/";
        public const string strCharacterHairPath = "prefabs/character/chr_hair/";
        public static string strCharacterLipsPath = "prefabs/character/chr_lips/";
        public static string strCharacterDecorationPath = "prefabs/character/chr_decoration/";
        public static string strCharacterTimelinePath = "prefabs/character/chr_timeline/";
        public static string strUIPrefabFolder = "prefabs/";
        public static string strDatasInteractionFolder = "datas/interaction/";
        public static string strDatasFlyPointFolder = "datas/flypoint/";

        public static string strAssertDatas = "datas/";


        public static string strSceneEffectPath = "art_resource/effect/effect/sceneEffect/";
        public static string strSceneEffectImportPath = "art_resource/effect/effect/sceneEffect_import/";

        public static string strAssetFolder = "assets/asset/";
        public const string strAssetSuffix = ".asset";
        public static string strBytesSuffix = ".bytes";
        public const string strPrefabSuffix = ".prefab";
        public static string strShaderSuffix = ".shader";
        public static string strSpriteSuffix = ".png";
        public static string strVideoSuffix = ".mp4";
        public static string strCsvSuffix = ".csv";
        public static string strMatSuffix = ".mat";
        public static string strTgaSuffix = ".tga";
        public static string strFbxSuffix = ".fbx";

        public static string strWorldAssetFolder = "scenes/";
        public static string strUIAssetFolder = "assets/asset/ui/";
        public static string strAsset = "asset/";

        /// <summary>
        /// 设置为true,将不使用persistent目录下资源，使用StreamAssets目录下资源
        /// AssetBundle资源时使用,
        /// </summary>
        public static bool   donotUsePersistentFolderResource = false;

        /// <summary>
        /// 是否使用录像模式。录像模式会使用更多高精度资源
        /// </summary>
        public static bool recordVideoMode = false;

        #region property
        static public IResourceLoader Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.ResourceLoader");
                }
                return m_instance;
            }
        }
#endregion

#region public interface

		public abstract bool UseAssetBundle { get; }

		public abstract UnityEngine.Object Load(string strResPath, Type t = null);
        public abstract UnityEngine.Object[] LoadAll(string strResPath, string strSuffix, Type t = null);
        public abstract void UnloadUnusedAssets();

		public abstract bool IsResourceInSceneFolder(string strAssetBundlePath, string strName);


        /// <summary>
        /// Load asset sync from assets dir
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAsset interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: 
        /// Like "Assets/asset/scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// Or "scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// </param>
        /// <param name="strAssetName">File name: Like "Detail_Type"</param>
        /// <param name="strSuffix">File name suffix: Like ".asset"</param>
        /// <param name="callback"> call back func when loading completed </param>
        /// <param name="bShader"> wether loading the shader resource </param>
        public abstract UnityEngine.Object LoadAssetSync(string strAssetPath, string strAssetName, string strSuffix, bool bShader = false, System.Type t = null);

        /// <summary>
        /// Load asset async from assets dir
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAssetAsyc interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: Like "Assets/asset/scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// Or "scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// </param>
        /// <param name="strAssetName">File name: Like "Detail_Type"</param>
        /// <param name="strSuffix">File name suffix: Like ".asset"</param>
        /// <param name="callback"> call back func when loading completed </param>
        /// <param name="bShader"> wether loading the shader resource </param>
        public abstract void LoadAssetAsync(string strAssetPath, string strAssetName, string strSuffix, LoadCallback callback = null, bool bShader = false, System.Type t = null);

#endregion
    }
}
