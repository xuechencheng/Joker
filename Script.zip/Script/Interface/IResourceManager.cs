using System;

namespace Bokura
{
    public abstract class IResourceManager : IBase<IResourceManager>
    {
        #region property
        static public IResourceManager Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.AssetBundleManager");
                }
                return m_instance;
            }
        }
        #endregion

        #region public interface
        #endregion
    }
}
