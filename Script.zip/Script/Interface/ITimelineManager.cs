﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using Bokura;

namespace Bokura.Timeline
{
    /// <summary>
    /// 描述Timeline播放所需的参数
    /// </summary>
    public class TimelineDesc
    {
        private static TimelineDesc s_Default;
        /// <summary>
        /// 默认参数集合
        /// </summary>
        public static TimelineDesc Default
        {
            get
            {
                if (s_Default == null)
                    s_Default = new TimelineDesc();

                s_Default.id            = -1;
                s_Default.path          = string.Empty;
                s_Default.sex           = 0;
                s_Default.career        = 0;
                s_Default.beforePrepare = null;
                s_Default.onStart       = null;
                s_Default.onStop        = null;
                s_Default.onPause       = null;
                s_Default.onResume      = null;
                s_Default.notEditMode   = true;
                s_Default.overrideCam   = null;
                s_Default.notifyServer  = true;
                s_Default.stopAll       = false;
                s_Default.ovrrideLayer  = 0;
                s_Default.worldPos      = Vector3.zero;
                s_Default.m_Actors.Clear();
                return s_Default;
            }
        }
        private TimelineDesc() { }

        private Dictionary<int, Entity> m_Actors = new Dictionary<int, Entity>(4);
        [XLua.BlackList]
        public IDictionary<int, Entity> actors { get { return m_Actors; } }

        public void AddActor(int actorId, Entity actor)
        {
            m_Actors[actorId] = actor;
        }

        [XLua.BlackList]
        public void GetActors(Dictionary<int, RetrievedEntity> _Map)
        {
            if(null != _Map)
            {
                foreach (var tKV in m_Actors)
                    _Map[tKV.Key] = new RetrievedEntity(tKV.Value);
            }
        }
        public int id;
        public string path;
        public int sex;
        public int career;
        public UnityAction beforePrepare;
        public UnityAction onStart;
        public UnityAction onStop;
        public UnityAction onPause;
        public UnityAction onResume;
        [XLua.BlackList]
        public bool notEditMode;
        /// <summary>
        /// 自定义摄像机
        /// </summary>
        [XLua.BlackList]
        public Camera overrideCam;
        /// <summary>
        /// 是否通知服务器
        /// </summary>
        [XLua.BlackList]
        public bool notifyServer;
        /// <summary>
        /// 停止正在播放的Timeline
        /// </summary>
        public bool stopAll;
        /// <summary>
        /// 自定义Layer
        /// </summary>
        [XLua.BlackList]
        public int ovrrideLayer;
        /// <summary>
        /// 自定义世界位置
        /// </summary>
        public Vector3 worldPos;
    }
    public abstract class ITimelineManager : IBase<ITimelineManager>
    {
        public delegate Camera RetrieveCameraDelegate();
        public delegate GameObject RetrieveCharDelegate(int actorId, ExtraBindingFlag flag);
        public delegate GameObject RetrieveNpcDelegate(int npcId, ExtraBindingFlag flag);
        public delegate GameObject RetrieveSceneObjectDelegate(string objectName, ExtraBindingFlag flag);
        public delegate void AddHeadBubbleDelegate(AvatarEvent avatar, string content);
        public delegate void RemoveHeadBubbleDelegate(AvatarEvent avatar);
        public delegate void AdjustCameraDelegate(Vector3 position, Quaternion rotation);
        public delegate void AdjustCameraWithCallbackDelegate(Vector3 position, Quaternion rotation, UnityAction onEnd);
        public delegate void ForceAdjustStopDelegate();
        public delegate void HideDecorationDelegate(HideDecorationRule rule);
        public delegate void HidePlayerDelegate(HidePlayerRule rule);
        public delegate void HideUIDelegate(HideUIRule rule);
        public delegate void HideEffectDelegate(HideEffectRule rule);
        public delegate void BlockActionDelegate(BlockActionRule rule);
        public delegate string DynamicNameDelegate(string _Content);
        #region property

        static public ITimelineManager Instance
        {
            get
            {
                if (m_instance == null)
                    CreateInstance("Bokura.Timeline.TimelineManager");
                return m_instance;
            }
        }

        public static RetrieveCharDelegate retrieveCharCallback;
        public static RetrieveNpcDelegate retrieveNpcCallback;
        public static RetrieveSceneObjectDelegate retrieveSceneObjectCallback;

        public static AddHeadBubbleDelegate addHeadBubbleCallback;
        public static RemoveHeadBubbleDelegate removeHeadBubbleCallback;

        public static HideDecorationDelegate hideDecorationCallback;
        public static HidePlayerDelegate hidePlayerCallback;
        public static HideUIDelegate hideUICallback;
        public static HideEffectDelegate hideEffectCallback;
        public static BlockActionDelegate blockActionCallback;

        /// <summary>
        /// 检索摄像机的回调
        /// </summary>
        public static RetrieveCameraDelegate retrieveCameraCallback;
        /// <summary>
        /// 播放前摄像机调整的回调
        /// </summary>
        public static AdjustCameraWithCallbackDelegate preAdjustCameraCallback;
        /// <summary>
        /// 播放完成后摄像机调整的回调
        /// </summary>
        public static AdjustCameraDelegate postAdjustCameraCallback;
        /// <summary>
        /// 强制摄像机调整结束的回调
        /// </summary>
        public static ForceAdjustStopDelegate forceAdjustStopCallback;

        /// <summary>
        /// 显示屏幕旁白
        /// </summary>
        public static UnityAction<string, bool> showScreenNarratorCallback;
        /// <summary>
        /// 关闭屏幕旁白 
        /// </summary>
        public static  UnityAction<string> hiddenScreenNarratorCallback;

        /// <summary>
        /// 显示跳过按钮
        /// </summary>
        public static UnityAction<bool, bool> showSkipCallback;

        /// <summary>
        /// 显示拍照按钮
        /// </summary>
        public static UnityAction<bool> showSnapShootCallback;

        public static UnityAction commonOnPrepared;
        public static UnityAction<TimelineController> commonOnStart;
        public static UnityAction commonOnStop;
        public static UnityAction commonOnPause;
        public static UnityAction commonOnResume;
        public static UnityAction commonOnSkip;
        public static UnityAction<float> commonOnUpdate;

        /// <summary>
        /// 获取自由文本的根节点
        /// </summary>
        public static System.Func<Transform> getFreeTextRootCallback = null;
        /// <summary>
        /// 获取底部文本
        /// </summary>
        public static System.Func<UnityEngine.UI.Text> getBaseTextCallback = null;
        /// <summary>
        /// 获取QTE挂载点
        /// </summary>
        public static System.Func<Transform> getQTERootCallback = null;
        /// <summary>
        /// 将文本中的特定内容替换为主角名称
        /// </summary>
        public static DynamicNameDelegate dynamicNameCallback = null;
        /// <summary>
        /// QTE的选择结果
        /// </summary>
        public static ulong[] qteResult = null;
        #endregion



        #region public interface

        /// <summary>
        /// Call this to load and play a timeline asset.
        /// </summary>
        /// <param name="path">The path of the asset.</param>
        /// <param name="hideUI">if true, then the root of ui would be hidden when play</param>
        public abstract void Play(TimelineDesc desc);
        public abstract void SkipAll();
        public abstract void Update();
        public abstract void LateUpdate();

        #endregion
    }
}
