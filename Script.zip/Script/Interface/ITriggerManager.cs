﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace Bokura
{
    public abstract class ITriggerManager : IBase<ITriggerManager>
    {
        #region events
        public class EntityTriggerColliderEvent : GameEvent<TriggerEditor, Collider>
        {

        }
        public class EntityTriggerDestoryEvent : GameEvent<TriggerEditor>
        {

        }
        public GameEvent<TriggerEditor, Collider> onTriggerCollider = new EntityTriggerColliderEvent();
        public GameEvent<TriggerEditor> onTriggerColliderDestory = new EntityTriggerDestoryEvent();
        #endregion

        #region property
        static public ITriggerManager Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.TriggeDelegate");
                }
                return m_instance;
            }
        }
        #endregion

        #region public interface
        public abstract void OnTriggerEnter(TriggerEditor _triggerEditor, Collider other);
        public abstract void OnTriggerDestory(TriggerEditor _triggerEditor);
        #endregion
    }
}
