using System;
using UnityEngine;

namespace Bokura
{
    public abstract class IUILoader : IBase<IUILoader>
    {
        #region property
        static public IUILoader Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.UILoader");
                }
                return m_instance;
            }
        }
        #endregion

        #region public interface
        public abstract void Load(string strAssetBundleName, string strObjectName, string strSuffix, LoadCallback callback);

        public abstract UnityEngine.Object[] LoadAll( string strFilePath, string strSuffix, Type t = null);

        public abstract UnityEngine.Object[] LoadSprites(string strFilePath);

        public abstract UnityEngine.Object LoadSprite(string strFilePath);

        public abstract UnityEngine.Object Load(string strFilePath, string strSuffix, Type t = null);
        #endregion
    }
}
