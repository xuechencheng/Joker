﻿namespace Bokura
{
    /// <summary>
    /// 由于EnhancedTimeline的命名空间在X2Engine层，不能调用X2Game层的天气系统接口。
    /// 因此新增X2Engine层的天气系统，由X2Game层的天气系统初始化。
    /// </summary>
    public class IWeatherManager
    {
        public delegate void ChangeAndLockWeatherDelegate(WeatherType _Type);
        public delegate void RecoverAndUnlockWeatherDelegate();
        public delegate void OpenChangeWeatherDelegate(bool open);



        protected IWeatherManager() { }



        private static IWeatherManager s_Instance;
        public static IWeatherManager instance
        {
            get
            {
                if (null == s_Instance) s_Instance = new IWeatherManager();
                return s_Instance; 
            }
        }
        


        /// <summary>
        /// 改变并锁定天气
        /// </summary>
        public ChangeAndLockWeatherDelegate changeAndLockWeatherFunc;
        /// <summary>
        /// 解锁并恢复天气
        /// </summary>
        public RecoverAndUnlockWeatherDelegate recoverAndUnlockWeatherFunc;
        /// <summary>
        /// 是否开启天气变化
        /// </summary>
        public OpenChangeWeatherDelegate openChangeWeather;
    }
}

