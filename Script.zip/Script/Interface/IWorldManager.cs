using UnityEngine;
using System;



namespace Bokura
{
    /// Singleton world manager.
    public abstract class IWorldManager : IBase<IWorldManager>
    {
        //static IWorldManager m_world;
        SceneLoadingFinishedCallback subWorldLoadingFinished;


        #region property

        /// singleton instance.
        static public IWorldManager Instance
        {
            get
            {
                if (m_instance == null)
                {
                    /// use reflection construct instance
                    CreateInstance ("Bokura.WorldManager");
                }
                return m_instance;
            }
        }

        bool bUpdateRegion = true;
        public bool CanUpdateRegion
        {
            get
            {
                return bUpdateRegion;
            }
            set
            {
                bUpdateRegion = value;
            }
        }

        /// callback when a big world chunk has just finished loading.
        public SceneLoadingFinishedCallback SubSceneLoadingFinishedCallback
        {
            get
            {
                return subWorldLoadingFinished;
            }
            set
            {
                subWorldLoadingFinished = value;
            }
        }
        #endregion



        #region public interface
        /// Load a big world scene without callback. 
        /// <param name="strSceneName">name of the scene to load.</param>
        public abstract void LoadWorld (string strSceneName, LoadCallback callback);


        /// Unload a big world scene.
		/// <param name="strSceneName">Name of the big world scene to unload.</param>
        public abstract void UnLoadWorld (string strSceneName);


        /// Load a chunk in a world map.
		/// <param name="strWorldName">   Name of the big world scene.</param>
		/// <param name="strSubWorldName">Name of the chunk to load.</param>
		/// <param name="bound">          Size of the chunk to load.</param>
        public abstract void LoadSubWorld (string strWorldName, string strSubWorldName, Bounds bound);


        /// Unload a chunk. 
		/// <param name="strWorldName">   Name of the big world scene, from which to unload a chunk.</param>
		/// <param name="strSubWorldName">Name of the chunk to unload.</param> 
        public abstract void UnLoadSubWorld (string strWorldName, string strSubWorldName);


        /// Load a scene in synchronous mode.
        /// <param name="strFileName">name of the scene to load.</param>
        public abstract void LoadScene (string strFileName);


        /// Load a given scene with callback. 
        /// <param name="strSceneName">name of the scene to load.</param>
        /// <param name="callback">    callback to issue after loading the scene. </param>
        public abstract void LoadSceneAsync (string strSceneName, LoadCallback callback);


        /// Unload a scene in asychronous mode.
        /// <param name="strFileName">name of the scene to unload.</param>
        public abstract void UnloadScene (string strSceneName);

        public abstract void DoUpdate();

        #endregion
    }
}
