﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public abstract class IWorldMatLUT : IBase<IWorldMatLUT>
    {

        #region property
        static public IWorldMatLUT Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.WorldMatLUT");
                    m_instance.Load();
                }
                return m_instance;
            }
        }
        #endregion

        #region public interface
        public abstract string getFootFx(Vector3 worldPos);
        public abstract string getMaterialName(Vector3 worldPos);

        public abstract bool isInWater(Vector3 wpos);
        public abstract bool isLightInWater(Vector3 wpos);

        public abstract void Load();
        #endregion
    }
}
