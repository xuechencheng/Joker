
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public interface IMechanism
    {
        ulong ID { get; }

        bool IsShowTips { set; get; }

        uint CurState { set; get; }

        GameObject gameObject { get; }
    }



    public abstract class IMechanismMgr : IBase<IMechanismMgr>
    {

        public delegate void OnMechanism(IMechanism mech);
        public OnMechanism OnMechanismRegiste;
        public OnMechanism OnMechanismUnregiste;
        static public IMechanismMgr Instance
        {
            get
            {
                if (m_instance == null)
                {
                    CreateInstance("Bokura.MechanismMgr");
                }
                return m_instance;
            }
        }
        public abstract void RefreshState(ulong id, uint state, bool isShowTips);

        public abstract MechanismAssets.Item GetItem(ulong id);

        public abstract MechanismAssets.Item GetItemBySceneId(ulong id);
        public abstract MobilePlatformAssets.Item GetMobilePlatformItemBySceneId(ulong id);

        public abstract void RegisterMechanism(IMechanism mech);
        public abstract void UnregisterMechanism(IMechanism mech);

    }

    [System.Serializable]
    public class BezierSerializable
    {
       

        //���߹ؼ���
        [SerializeField]
        public Vector3[] points;

        //ģʽ
        [SerializeField]
        public BezierControlPointMode[] modes;

        //��������
        [SerializeField]
        public AnimationCurve animCurve = AnimationCurve.Linear(0, 0, 1, 1);

        //������ĵ�
        [SerializeField]
        public List<Vector3> realPoints = new List<Vector3>();

        //���������ת�Ƕ�
        [SerializeField]
        public List<float> rotates = new List<float>();

        /// <summary>
        /// ����ʱ��
        /// </summary>
        public float duration = 10f;

        /// <summary>
        /// ����
        /// </summary>
        public string m_animName;


    }

        public enum BezierControlPointMode
    {
        Free,
        Aligned,
        Mirrored
    }

}