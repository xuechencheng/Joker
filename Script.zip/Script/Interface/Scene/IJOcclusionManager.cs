﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    public abstract class IJOcclusionManager : ISingletonMonoManager
    {
        [InspectorTooltipAttribute("Whether to enable/disable SOC(Do not click this on play)")]
        public bool enableSOCEditor = true;

        [InspectorTooltipAttribute("Enable log system(Do not click this on play)")]
        public bool enableDebug = false;

        [InspectorTooltipAttribute("Max occluder distance")]
        public int maxOccluderDistance = 100;

        [InspectorTooltipAttribute("Collected occluders count")]
        public int occludersCount = 0;

        [InspectorTooltipAttribute("Collected occluders count")]
        public int occludeesCount = 0;

        [InspectorTooltipAttribute("Culled occludees count")]
        public int culledCount = 0;

        [InspectorTooltipAttribute("Collected occluders count")]
        public int collectedOccluders = 0;

        [InspectorTooltipAttribute("Collected occludees count")]
        public int collectedOccludees = 0;

        [InspectorTooltipAttribute("JOccludsionCulling Mesh count")]
        public int collectedOccluderMeshesCount = 0;

        [InspectorTooltipAttribute("maxOccludeeNum (Do not Change during run time)")]
        public int maxOccludeeNum = 500;

        [InspectorTooltipAttribute("maxOccluderTri (Do not Change during run time)")]
        public int maxOccluderTri = 2000;

        [NonSerialized]
        public bool enableSOC = true;

#if UNITY_EDITOR
        public bool ocBackBufferDebug = false;
        public Texture2D ocBackBuffer;
#endif

        /// singleton instance of the SOC manager.
        protected static WeakReference s_instance;
        public static IJOcclusionManager Instance
        {
            get
            {
                return (null != s_instance) ? s_instance.Target as IJOcclusionManager : null;
            }
        }

        public abstract void AddOccludeePVS(GameObject go);

        public abstract void RemoveOccludeePVS(GameObject go);

        public abstract void AddOccluder(Renderer renderer, Mesh mesh);

        public abstract void RemoveOccluder(Renderer renderer, Mesh mesh);

        public abstract void EnableSOC();
        public abstract void DisableSOC();
        public abstract void JobProcess(Camera mainCamera);
        public abstract bool CheckVisibility(Renderer renderer);

#if UNITY_EDITOR
        public abstract Texture2D GetOCBackBuffer();
#endif
    }
}
