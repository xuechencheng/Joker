﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{

    public abstract class IPVSManager : ISingletonMonoManager
    {

        public class TargetZoneInfo
        {
            public int x;
            public int y;
            public GameObject go;
            public Transform tr;
            public Bounds bounds;
        }

        [InspectorTooltipAttribute("Debug output the culling result.")]
        public bool isDebug = true;

        [InspectorTooltipAttribute("Whether to enable/disable PVS")]
        public bool enablePVS = true;

        [InspectorTooltipAttribute("Whether to enable/disable distance culling")]
        public bool enableDistanceCulling = true;

        [InspectorTooltipAttribute("The culling update interval time")]
        public float updateInterval = 0.1f;

        [InspectorTooltipAttribute("The distance culling update delta distance")]
        public float distanceCullingUpdateSqrDistance = 8.0f;

        [InspectorTooltipAttribute("The distance culling distance for small layer. 0 means do not cull")]
        public float distanceCullingForSmallLayer = 30.0f;

        [InspectorTooltipAttribute("The distance culling distance for middle layer. 0 means do not cull")]
        public float distanceCullingForMiddleLayer = 100.0f;

        [InspectorTooltipAttribute("The distance culling distance for big layer. 0 means do not cull")]
        public float distanceCullingForBigLayer = 0.0f;

        [InspectorTooltipAttribute("The invisible layer in the camera culling mask. -1 means use SetActive")]
        public int invisibleLayer = -1;

        /// singleton instance of the PVS manager.
        protected static WeakReference s_instance;
        public static IPVSManager Instance
        {
            get
            {
                return (null != s_instance) ? s_instance.Target as IPVSManager : null;
            }
        }

        public abstract void AddLayeredSECTR(UserLayer layer, int x, int y, GameObject go, ref Bounds bounds);
        public abstract void RemoveLayeredSECTR(UserLayer layer, int x, int y);
        public abstract void Cull(Vector3 cameraPosition, PVSData pvsData, bool forceCull = false);
        public abstract void CancelPVSCulling();

        public abstract void WorldMove(Vector3 newOffset, Vector3 delta);

    }

}
