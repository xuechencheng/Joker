
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    [System.Serializable]
    public class IEffectConfig : ScriptableObject
    {

        public List<ISkillConfig.Effect> effects;

    }
}