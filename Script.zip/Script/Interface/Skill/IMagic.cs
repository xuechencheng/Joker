using AudioStudio;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;
using static Bokura.ISkillConfig;

namespace Bokura
{
    public enum FilterType : int
    {
        NONE,                   //无 过滤，都显示
        SPACE_MASK = 0xf,
        SPACE_IN_LAND = 1 << 0, //在陆地上显示
        SPACE_IN_SKY = 1 << 1,  //在空中显示
        SPACE_IN_SEA = 1 << 2,  //在海里显示

        BUFF_MASK = 0xf0,

        EXIST_BUFF = 1 << 4,        //存在这些buffid 的时候显示
        NOT_EXIST_BUFF = 2 << 4,    //不存在这些buffid 的时候显示

    }

    public class HurtActionStart
    {
        public string actionId;
        public float progress;
    }

    public class HurtAction
    {
        public string actionId;
        public float progress;
    }

    public class AttackEffect
    {
        public Playable playable;
    }

    public class HurtEffect
    {
        public Playable playable;
    }

    public class HurtEffectStart
    {
        public Playable playable;
    }

    public class FireBulletEffect
    {
        public GameObject fxGameObject;
        public string fxpath;
        public string fxname;
        public string bulletPath;               //弹道路径
        public string bulletName;               //弹道名字
        public AvatarAttachment start_attach;     //开始挂载点 
        public AvatarAttachment end_attach;     //结束挂载点 
        public int filterType;
        public float fadeouttime;
        public AnimationPath animpath;
        public Transform trans;
        public Vector3 scale = new Vector3(1, 1, 1);
        public Vector3 rotate;
        public Vector3 startOffect;
        public float delay;
        public float beginSpeed;
        public Magic.BulletBehaviour behaviour;
        public List<IAvatar> bulletDefenders;
        public Vector3 targetPos;
    }
    public class BulletEffect
    {
        public Playable playable;
    }
    public class DestroyBulletEffect
    {
        public Magic.BulletBehaviour behaviour;
    }

    public class MaterialChangeEffectEx
    {
        public static ObjectPool<MaterialChangeEffectEx> s_pool = new ObjectPool<MaterialChangeEffectEx>();

        public static MaterialChangeEffectEx Get() { return s_pool.Get(); }
        public void Release()
        {
            //Bokura.LogHelper.Log("[ActionEffect]MaterialChangeEffectEx Release!", changeMatName, loading);
            colour = Color.white;
            isChangeMat = false;
            isBody = false;
            reset = false;
            isPrimaryWeapon = false;
            isSecondaryWeapon = false;
            during = 0;
            lefttime = 0;
            changeMatName = string.Empty;
            tintColor = Color.red;
            dissolveColor = Color.red;
            dissolveThreshold = 0.5f;
            edgeSize = 0.2f;
            colourCurve = null;
            edgeSizeCurve = null;
            dissolveThresholdCurve = null;
            
            s_pool.Release(this);
        }

        public bool loading = false;
        public UnityEngine.Color colour;
        public float power;
        public const string RimColor = "_RimColor";
        public const string RimPower = "_RimPower";
        public bool reset = false;
        public bool isBody = false;
        public bool isPrimaryWeapon = false;
        public bool isSecondaryWeapon = false;
        public float during = 0;
        public float lefttime = 0;

        public Color basecolor;
        public AnimationCurve colourCurve = null;//衰减曲线
        public float basedissolveThreshold;
        public AnimationCurve dissolveThresholdCurve = null;//溶解阈值曲线
        public float baseedgeSize;
        public AnimationCurve edgeSizeCurve = null;//边界尺寸曲线

        //替换材质所修改的参数
        public const string TintColorContent = "_TintColor";
        public const string DissolveThresholdContent = "_DissolveThreshold";
        public const string DissolveColorContent = "_DissolveColor1";
        public const string EdgeSizeContent = "_DissolveEdgeSize";

        public bool isChangeMat = false;//替换材质
        public string changeMatName;//替换材质名
        public Color tintColor = Color.red;//颜色
        public float dissolveThreshold = 0.5f; // 溶解阈值
        public Color dissolveColor = Color.red;//溶解颜色
        public float edgeSize = 0.2f; // 边界尺寸
    }

    public class DefendMaterialChangeEffectEx
    {
        public UnityEngine.Color colour;
        public float power;
        public string RimColor = "_RimColor";
        public string RimPower = "_RimPower";
    }

    public class WwiseAudioStart
    {
        public AudioStudio.AudioEventPC playEvent;
        public bool isUpdatePosition = true;
    }

    public class WwiseAudioStop
    {
        public AudioStudio.AudioEventPC playEvent;
        public AudioStudio.AudioEventPC stopEvent;
        public bool isUpdatePosition = true;
        public bool stop = true;
    }

    public class EventStart
    {
        public string eventName;
        public int eventType;
        //事件参数
        public System.Collections.Generic.List<EventParam> paramList = new System.Collections.Generic.List<EventParam>();
    }

    public class GrassEventStart
    {
        public CritiasFoliage.CutoffGrassAnimateData startData;
    }

    public class DefendGrassEventStart
    {
        public CritiasFoliage.CutoffGrassAnimateData startData;
    }


    public class SkillPreviewEvent
    {
        public Playable playable;
    }


    [System.Serializable]
    public class MagicDataBase
    {
        [HideInInspector]
        // 开始时间
        public double start;
        [HideInInspector]
        // 持续时间
        public double duration;
        [HideInInspector]
        // 结束时间
        public double end;
        [HideInInspector]
        //淡入
        public double easein;
        [HideInInspector]
        //淡出
        public double easeout;
        [HideInInspector]
        //攻击者
        public bool isAttack;
        //阶段id
        public int stateId;
        //组id(区分attackhit调用的特效动作)
        public int groupId;
        //受天气影响
        public MagicHumidityType humidity = MagicHumidityType.Normal;

        [System.NonSerialized]
        public Magic.MagicContext context;
    }

    [System.Serializable]
    public class ActionData : MagicDataBase
    {
        // 状态机名id
        public string actionId;
        // fbx文件路径
        public string fbx;
        //动作名
        public string motion;
        // 动作类型
        public int actionType;
        // 是否循环
        public bool loop;
        // 是否融合
        public bool mix;

        //事件 
        public System.Collections.Generic.List<EventData> eventList = new System.Collections.Generic.List<EventData>();
    }

    [System.Serializable]
    public class EffectData : MagicDataBase
    {
        public string fxpath; //特效路径
        public string fxname; //特效文件名
        public int showType;//特效显示类型(暴击普通等)
        public AvatarAttachment attach; //挂载点 
        public int filterType; //显示过滤类型 public enum FilterType
        public float fadeouttime; //淡出时间
        public Vector3 scale = new Vector3(1, 1, 1);
        public Vector3 rotate;
        public Vector3 offset;
        public int[] exist_buffs; //存在这些buff时显示特效
        public int[] unexist_buffs; //不存在这些buff时显示特效
        public bool bindBone = true;//绑定骨骼
        public bool bindPosition = false; //位移跟随骨骼
        public bool bindRotation = false; //旋转跟随骨骼
        public bool breakClear = false;//动作打断清除特效
        public bool isLineEffect = false;//连线技能
        public AvatarAttachment endAttach;     //结束挂载点 (连线技能用)
        public bool targetPos = false;          //特效生成的目标点位置
        public bool bindTarget = false;            //特效绑定在目标身上
    }

    [System.Serializable]
    public class MaterialData : MagicDataBase
    {
        public AnimationCurve colourCurve = AnimationCurve.Linear(0, 1, 1, 1);//衰减曲线
        public float power = 1.0f;          // 强度
        public Color colour = new Color(0, 0, 0, 1);         // 颜色
        public bool isBody = false; //身体
        public bool isPrimaryWeapon = false;//主武器
        public bool isSecondaryWeapon = false;//副武器

        //替换材质所修改的参数
        public bool isChangeMat = false;//替换材质
        public string changeMatName;//替换材质名
        [ColorUsage(true, true)]
        public Color tintColor = Color.red;//颜色
        public float dissolveThreshold = 0.5f; // 溶解阈值
        [ColorUsage(true, true)]
        public Color dissolveColor = Color.red;//溶解颜色
        public float edgeSize = 0.2f; // 边界尺寸
        public AnimationCurve dissolveThresholdCurve = AnimationCurve.Linear(0, 1, 1, 1);//溶解阈值曲线
        public AnimationCurve edgeSizeCurve = AnimationCurve.Linear(0, 1, 1, 1);//边界尺寸曲线
        //
    }

    [System.Serializable]
    public class CameraData : MagicDataBase
    {
        public float fps = 50.0f;            // 频率
        public Vector3 shakeDetla = Vector3.zero;     // 振幅
        public AnimationCurve fpsCurve = AnimationCurve.Linear(0, 1, 1, 1);//频率衰减曲线
        public AnimationCurve attenuationCurve = AnimationCurve.Linear(0, 1, 1, 1);//振幅衰减曲线
        public bool onlyCaster = false;//是否仅施法者生效
        public float maxDistance = 5f;            // 影响范围
        public AnimationCurve distanceCurve = new AnimationCurve(new Keyframe(0, 1, 0, 0), new Keyframe(1, 0, -1.5f, -1.5f));//距离->强度衰减曲线（距离远近选取衰减值）
        public int filterType; //显示过滤类型 public enum FilterType
        public bool isAnimation = false;//摄像机动画类型

        public float delay = 0f;            // 延时
        public bool isCameraDistanceCurve = true;
        public AnimationCurve cameraDistanceCurve = AnimationCurve.Linear(0, 5, 1, 5);//相机距离曲线
        public bool isCameraRotateXCurve = true;
        public AnimationCurve cameraRotateXCurve = AnimationCurve.Linear(0, 1, 1, 1);//水平方向的旋转角度曲线
        public bool isCameraRotateYCurve = true;
        public AnimationCurve cameraRotateYCurve = AnimationCurve.Linear(0, 1, 1, 1);//竖直方向的旋转角度曲线
        public bool isCameraFollowSmoothTimeCurve = true;
        public AnimationCurve cameraFollowSmoothTimeCurve = AnimationCurve.Linear(0, 0.03f, 1, 0.03f);//相机跟随的平滑时间曲线
        public bool isCameraLookAtOffsetCurve = true;
        public AnimationCurve cameraLookAtOffsetXCurve = AnimationCurve.Linear(0, 0, 1, 0);//LookAtOffsetX
        public AnimationCurve cameraLookAtOffsetYCurve = AnimationCurve.Linear(0, 0, 1, 0);//LookAtOffsetX
        public AnimationCurve cameraLookAtOffsetZCurve = AnimationCurve.Linear(0, 0, 1, 0);//LookAtOffsetX
    }


    [System.Serializable]
    public class CameraPointData : MagicDataBase
    {
        public float cameraCurDistance = 5f;
        public float cameraRotateX = 0.0F;
        public float cameraRotateY = 45.0F;
        public float cameraFollowSmoothTime = 0.03f;
        public float cameraLookAtOffsetX = 0.0F;
        public float cameraLookAtOffsetY = 0.0F;
        public float cameraLookAtOffsetZ = 0.0F;
    }


    [System.Serializable]
    public class BulletData : MagicDataBase
    {
        public string fxpath;               //特效路径
        public string fxname;               //特效文件名
        public int bulletType;               //弹道类型(直线还是按照路径)
        public string bulletPath;               //弹道路径
        public string bulletName;               //弹道名字
        public AvatarAttachment start_attach;     //开始挂载点 
        public AvatarAttachment end_attach;     //结束挂载点 
        public int filterType;     //显示过滤类型 public enum FilterType
        public float fadeouttime; //淡出
        public Vector3 scale = new Vector3(1, 1, 1);
        public Vector3 rotate;
        public Vector3 startOffect;//初始偏移
        public float delay;
        public float beginSpeed;//初始速度

        public CritiasFoliage.CutoffGrassAnimateData grassData;
    }

    [System.Serializable]
    public class RadialBlurData : MagicDataBase
    {
        //采样次数
        public float sampleCount = 30;
        //强度
        public float strength = 1;
        //模糊放射中心
        public Vector2 radialBlurCenter = new Vector2(0.5f, 0.5f);
        //模糊放射强度
        public float radialBlurRadialStrength = 2.0f;
        //模糊放射半径
        public float radialBlurRadialRadius = 0.1f;

        //采样衰减曲线
        public AnimationCurve sampleCountCurve = AnimationCurve.Linear(0, 1, 1, 1);
        //强度衰减曲线
        public AnimationCurve strengthCurve = AnimationCurve.Linear(0, 1, 1, 1);
        //模糊放射强度曲线
        public AnimationCurve radialBlurRadialStrengthCurve = AnimationCurve.Linear(0, 1, 1, 1);
        //模糊放射半径曲线
        public AnimationCurve radialBlurRadialRadiusCurve = AnimationCurve.Linear(0, 1, 1, 1);


        public bool onlyCaster = false;//是否仅施法者生效
        public float maxDistance = 5f;            // 影响范围
        public AnimationCurve distanceCurve = new AnimationCurve(new Keyframe(0, 1, 0, 0), new Keyframe(1, 0, -1.5f, -1.5f));//距离->强度衰减曲线（距离远近选取衰减值）
        public int filterType; //显示过滤类型 public enum FilterType
    }


    [System.Serializable]
    public class EventData : MagicDataBase
    {
        //事件类型
        public int eventType;
        //事件参数
        public System.Collections.Generic.List<EventParam> paramList = new System.Collections.Generic.List<EventParam>();
    }

    [System.Serializable]
    public class EventParam
    {
        //参数类型
        public int paramType;
        //参数名
        public string paramName;
        //参数名
        public string paramValue;
    }

    [System.Serializable]
    public class GrassData : MagicDataBase
    {
        public CritiasFoliage.CutoffGrassAnimateData grassData;
    }

    [System.Serializable]
    public class WWiseData : MagicDataBase
    {
        public AudioEventPC playEvent;
        public bool stop;
        public bool isUpdatePosition = true;
    }

    [System.Serializable]
    public class EffectSkillData
    {
        public float fadeTime;//淡出时间
        public Effect.FadeType fade;//消失方式
        public FilterByWho buffFilterByWho = FilterByWho.BY_CASTER;//依赖谁的buff
        public Effect.AttachObjectType attachObject = Effect.AttachObjectType.CASTER;//该特效是附加在谁身上；0：自己；1：敌人 2:targetpos 3 连线自己和目标
    }

    [System.Serializable]
    public class EffectMecanimData
    {
        public bool isFoot;//脚印
        public bool loopfire;//循环动作只触发一次
        public bool customDuration = true;//自定义消失时间
        public bool isDestroyAfterDuration = true;//自动销毁
        public bool isAutoPlay = true;//自动播放
        public SpawnInstanceCategory category = SpawnInstanceCategory.Effect;
        public int weaponAttachmentBone;//武器挂载点 （mecanim类型为武器时用）
        public int uid;
    }

    [System.Serializable]
    public class WWiseMecanimData
    {
        public bool isFoot;//脚印
        public FootType footType = FootType.LEFT;//脚印类型
        public string playAudioPath;//开始音效路径
        public string stopAudioPath;//停止音效路径
    }

    [System.Serializable]
    public class CameraEnvironmentData : MagicDataBase
    {
        public EnvironmentProfile profile;
        public UnityEngine.Rendering.PostProcessing.PostProcessProfile volume;
        //sun
        [Range(0,360)]
        public float sunDirection = 262;
        [Range(0, 180)]
        public float sunEquator = 145f;
        [Range(0, 360)]
        public float moonDirection = 22;
        [Range(0, 180)]
        public float moonEquator = 100.8f;
        [Range(0, 24)]
        public float timeline = 20;
        public Color sunColor = Color.red;
        public float sunIntensity = 1.5f;

        //skybox
        
        public bool skyboxEnable = true;
        [Range(0, 8)]
        public float skyboxExposure = 1.93f;
        [Range(0, 360)]
        public float skyboxRotation = 0;
        public Texture skyboxTexture;

        //太阳
        public float sunIrradiance = 25;//光照强度
        [Range(0, 200)]
        public float sunDiameter = 80;//直径(sr)  
        [Range(0, 10)]
        public float sunBrightness = 2.5f;//太阳亮度

        //月亮
        [Range(0, 20)]
        public float moonAlbedo = 4f;//反射率
        [Range(0.1f, 10)]
        public float moonContrast = 1f;//明暗对比度
        [Range(60, 360)]
        public float moonDiameter = 100f;//直径
        public Color moonLightColor = Color.white;//颜色
        [Range(1E-06f, 1)]
        public float moonIrradiance = 0.0002f;//月光亮度
        public Vector2 moonLightSource = new Vector2(0, 1);//入射光方向

        //大气散射
        [Range(5, 2000)]
        public float maxDistanceKm = 300f;//最远可视距离*

        //weather system
        public bool isRaining = true;
        [Range(0, 1)]
        public float rainningAmount=0;
        [Range(0, 1)]
        public float diffuseDarkening = 0;
        public float puddleAmount = 0;
        public float puddleRipplesAmount = 0;
        public float puddleRipplesScale = 0;
        public float nearRainDropIntensity = 0;
        public float farRainDropIntensity = 0;
        public bool isSnowing = false;
        [Range(0, 1.5f)]
        public float rpOutDoorStrength = 1;
        [Range(0, 1.0f)]
        public float bakedLighterStength = 1;
        [Range(0.0f, 1.5f)]
        public float bakedEnvGIStrength = 1;
    }

    public enum SkillPreviewTemplateType
    {
        Effect,//行为
        Condition,//条件
        Customize,//自定义(目前不需要模板)
    }

    /// <summary>
    /// 技能逻辑数据
    /// </summary>
    [System.Serializable]
    public class SkillPreviewData : MagicDataBase
    {
        public string clipType;
        //输出参数
        public List<SkillPreviewTemplate> outputParamList = new List<SkillPreviewTemplate>();
        public List<SkillPreviewDataItem> itemList = new List<SkillPreviewDataItem>();
    }


    [System.Serializable]
    public class SkillPreviewDataItem
    {
        //行为模板
        public List<SkillPreviewTemplate> templateList = new List<SkillPreviewTemplate>();
        //条件
        public List<SkillPreviewTemplate> conditionList = new List<SkillPreviewTemplate>();
        //主体
        public TargetTemplate mainbody = new TargetTemplate();
    }

    /// <summary>
    /// 技能逻辑单个数据
    /// </summary>

    [System.Serializable]
    public class SkillPreviewTemplate
    {
        public string name = "";
        public SkillPreviewTemplateType type = SkillPreviewTemplateType.Effect;
        public List<SkillLogicTemplateParamData> paramList = new List<SkillLogicTemplateParamData>();
        public bool isTrue = true;//正条件（condition取反加not  effect取反 放到else的结构里）
        public bool isFold;
        public int andOr;//条件的连接 and or
        public TargetTemplate targetFilter=new TargetTemplate();//目标筛选
    }

    [System.Serializable]
    public class TargetTemplate
    {
        public string name = "";
        public List<SkillLogicTemplateParamData> paramList = new List<SkillLogicTemplateParamData>();
        public bool isFold;
    }

    [System.Serializable]
    public class SkillLogicTemplateParam
    {
        public string paramName = "";

        public string paramType = "";

        public string paramDefaultValue = "";

    }

    [System.Serializable]
    public class SkillLogicTemplateParamData : SkillLogicTemplateParam
    {
        public string paramValue = "";
    }

    public class CastDefenderData
    {
        //技能id
        public uint skillId;
        public int hitIDX;
        public int flag;
        //播放受击动作
        public bool showAction;
        //受击对象是不是main
        public bool isMainCharacter;
        //攻击者是不是main
        public bool casterIsMainCharacter;
        public float distance;
        //受击开始时间 用来和受击特效等做偏移
        public double startTime;
    }

    public class CastMagicData
    {
        public GameObject attacker;
        public uint skillId;
        public uint motionId;
        public List<IAvatar> defender;
        public float distance;
        public bool isMainCharacter;
        public Vector3 targetPos;
        public MagicHumidityType humidity;
        public bool isFlashing;
        public string actionName;
    }

    public enum EventParmaType
    {
        INT = 0,
        STRING = 1,
        FLOAT = 2,
        VECTOR3 = 3,
        RECT = 4
    }

    public enum FootType
    {
        LEFT = 0,
        RIGHT = 1
    }

    /// <summary>
    /// 预览类型
    /// </summary>
    public enum PreviewType
    {
        None = 0,
        ClickFly = 1,
        BeatBack = 2,
        Area = 3,
    }

    /// <summary>
    /// 湿度
    /// </summary>
    public enum MagicHumidityType 
    {
        Dry = 0,
        Normal = 1,
        Wet = 2,
        Flashing=99,
    };

    //弹道类型
    public enum MagicBulletType
    {
        Straight = 0,//直线
        AnimationPath = 1,//路径
        RealBullet = 2,//真实子弹(只需导出偏移数据)
    }

    /// <summary>
    /// 击飞
    /// </summary>
    public struct ClickFlyCalc
    {

        Vector3 m_pos;
        Vector3 m_vel;
        float m_airF;
        float m_g;
        float m_curTime;
        const float m_frameTime = 0.05f;
        public void Init(Vector3 pos, Vector3 vel, float airF, float g)
        {
            m_pos = pos;
            m_vel = vel;
            m_airF = airF;
            m_g = g;
            m_curTime = 0;
        }

        public Vector3 Simulate(float t)
        {
            while (m_curTime < t)
            {
                m_vel.y += m_g * m_frameTime;

                var speed = m_vel.magnitude;
                var dir = m_vel.normalized;
                if (m_vel.y < 0.0f)
                    m_vel.y += 2.0f * m_g * m_frameTime;
                else
                    m_vel -= dir * (speed * speed * m_airF) * m_frameTime;

                var updatePos= m_vel * m_frameTime;
                if(updatePos.y+ m_pos.y >= 0)
                {
                    m_pos += updatePos;
                }
                m_curTime += m_frameTime;
            }

            return m_pos;
        }
    }

    /// <summary>
    /// 击退
    /// </summary>
    public struct BeatBackCalc
    {
        Vector3 m_pos;
        Vector3 m_dest;
        Vector3 m_dir;
        float m_speed;
        float m_len;

        public void Init(Vector3 pos, Vector3 tPos, float speed)
        {
            m_dest = tPos;
            m_pos = pos;
            m_speed = speed;
            m_dir = m_dest - m_pos;
            m_len = m_dir.magnitude;
            m_dir.Normalize();
        }
        public Vector3 Simulate(float t)
        {
            var len = m_speed * t;
            if (len > m_len)
                len = m_len;
            return m_pos + m_dir * len;
        }

        public float GetDistance()
        {
            return Vector3.Distance(m_pos, m_dest);
        }
    }

}