
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    [System.Serializable]
    public class ISkillConfig : ScriptableObject
    {
        //特效过滤
        //public enum FilterType : int
        //{
        //    NONE,                   //无 过滤，都显示
        //    SPACE_MASK = 0xf,
        //    SPACE_IN_LAND = 1 << 0, //在陆地上显示
        //    SPACE_IN_SKY = 1 << 1,  //在空中显示
        //    SPACE_IN_SEA = 1 << 2,  //在海里显示

        //    BUFF_MASK = 0xf0,

        //    EXIST_BUFF = 1 << 4,        //存在这些buffid 的时候显示
        //    NOT_EXIST_BUFF = 2 << 4,    //不存在这些buffid 的时候显示

        //}

        public enum FilterByWho : int
        {
            BY_CASTER,
            BY_TARGET,
        }

        //可见性
        public enum EffectVisible : int
        {
            Caster = 1,
            Target = 2,
            CasterAndTarget = 3,
            AllPlayer = 4,
        }
        public enum BindMode : int
        {
            PositionAndRotation = 0,
            OnlyPosition,
            //Rotation,
        }
        #region 内部类型
        [System.Serializable]
        public class Effect
        {
            public enum AttachObjectType
            {
                CASTER = 0,
                TARGET = 1,
                TARGET_POS = 2,
                CASTER_TARGET_LINK = 3,
            }
            public enum FadeType
            {
                FadeAction,
                FadeSkill,
                FadeLifeTime,
                FadeByBuff,
            }

#if UNITY_EDITOR
            //only used in the editor
            [System.NonSerialized]
            public GameObject e;
            [System.NonSerialized]
            public bool isSelected = false;
            [System.NonSerialized]
            public Vector3 unBindfirstPos;
            [System.NonSerialized]
            public Quaternion unBindfirstRotation;
            [System.NonSerialized]

            [XLua.BlackList]
            public string curPath;
            [XLua.BlackList]
            public UnityEngine.ParticleSystem[] particles;

#endif
            public string path;
            public float delay;
            public AvatarAttachment attach;
            public bool BindAttach;
            public BindMode Bindmode = BindMode.PositionAndRotation;
            public FadeType fade;
            public float lefttime = 10.0f; //FadeLifeTime 类型时有效
                                           //public bool isFataOut;
            public float fadeoutTime = 0.0f; //淡出速度

            [System.NonSerialized]
            public Dictionary<string, Vector3> orinScale = new Dictionary<string, Vector3>(); //源缩放值
            public Vector3 scale = new Vector3(1, 1, 1);

            public Vector3 rotate;
            public Vector3 offset;

            public int attachobject; //该特效是附加在谁身上；0：自己；1：敌人 2:targetpos 3 连线自己和目标

            //public bool stopByAnimDone = true; //动画完成后是否停止 

            public int filterType;      //显示过滤类型 public enum FilterType
            public int[] buffidlist;

            //public int hitidx = 0;  //受击序号，只有受击特效才会使用这个值-1 表示 只要受击就播放 否则只有到了对应的受击序号才会播放
            public FilterByWho buffFilterByWho = FilterByWho.BY_CASTER;
            public EffectVisible visible = EffectVisible.AllPlayer;

            //public static explicit operator Effect(UnityEngine.Object v)
            //{
            //    throw new NotImplementedException();
            //}

            ////cutoff grass animation
            public CritiasFoliage.CutoffGrassAnimateData grassData;
            public ISkillConfig.BuffMaterialConfig materialChange;
            public ISkillConfig.RadialBlurConfig radialBlur;

        }

        [System.Serializable]
        public class CameraShakeConfig
        {
            public enum TargetType { None, OnlySelf, OnlyEnemy, SelfAndEnemy, Circle }
            public float ShakeRadio = 5.0f;
            public TargetType ShakeType = TargetType.None; //为none的话就用 IsSelf来判定
            public bool IsSelf;     //打算弃用
            public bool IsAutoStop; //动作结束自动停止
            public float ShakeTime;
            public float Fps;
            public float ShakeDetla;
            public float DelayTime;
            public int filterType = (int)FilterType.NONE;
        }

        [System.Serializable]
        public class HurtMaterialConfig
        {
            public Color color;
            public float power;
            public float time;
            public float DelayTime;
        }

        [System.Serializable]
        public class BuffMaterialConfig
        {
            public bool hasMaterialChange;
            public Color color;
            public float power;
            public float time;
            public float delayTime;
            public AnimationCurve colourCurve = AnimationCurve.Linear(0, 1, 1, 1);//衰减曲线
        }

        [System.Serializable]
        public class FlowMaterialConfig
        {
            public string tex;
            public Color color;
            public float strength;
            public Vector2 speed = new Vector2(0, 1);
            public Vector2 uv = new Vector2(0.5f, 0.5f);
            public float DelayTime;
            public float durationTime = 1;
        }
        [System.Serializable]
        public class RadialBlurConfig
        {
            public bool hasRadialBlur;
            public int sampleCount;
            public float strength;
            public float radialBlurRadialStrength;
            public float radialBlurRadialRadius;
            public Vector2 radialBlurCenter;
            public float time;
            public float DelayTime;
        }

        [System.Serializable]
        public class BulletConfig
        {
            public string path;         //特效路径
            public AvatarAttachment startPoint;	//子弹起始挂载点 
            public Vector3 rot;         //特效初始化朝向
            public Vector3 scale = new Vector3(1, 1, 1);       //特效缩放
            public string animpath;     //动画路径
            public int filterType;      //显示过滤类型 public enum FilterType
            public int[] buffidlist;
            public int hitidx = 0;  //受击序号，只有受击特效才会使用这个值-1 表示 只要受击就播放 否则只有到了对应的受击序号才会播放
            public float fadespeed = 0.06f; //淡出速度
        }

        #endregion

    }



}