using System.Collections.Generic;
using UnityEngine;

namespace Bokura
{
    [System.Serializable]
    public class IOverlappingSoundConfig : ScriptableObject
    {
        public float fadeInDuration;



        public float fadeOutDuration;



        public List<OSExportData> dataList = new List<OSExportData>();



        private Dictionary<string, OSExportData> m_DataMap = null;



        /// <summary>
        /// 初始化映射
        /// </summary>
        public void InitMap()
        {
            if(null == m_DataMap)
            {
                int tCount = dataList.Count;
                m_DataMap = new Dictionary<string, OSExportData>(tCount);
                for (int tIdx = 0; tIdx < tCount; tIdx++)
                {
                    OSExportData tOS = dataList[tIdx];
                    m_DataMap.Add(tOS.osId, tOS);
                }
            }
        }



        public OSExportData GetOSData(string osId)
        {
            OSExportData tData = null;
            if(null != m_DataMap && !string.IsNullOrEmpty(osId))
                m_DataMap.TryGetValue(osId, out tData);
            return tData;
        }
    }



    [System.Serializable]
    public class OSExportData
    {
        public string osId = "";



        public List<OSDataItem> itemList = new List<OSDataItem>();



        /// <summary>
        /// 最后一句话是否保持住并按指定时间循环
        /// </summary>
        public float loopDuration = -1f;



        public int Count { get { return itemList.Count; } }



        public OSDataItem GetOSItem(int index)
        {
            OSDataItem tItem = null;
            if (null != itemList && index < Count && index >= 0)
                tItem = itemList[index];
            return tItem;
        }
    }



    [System.Serializable]
    public class OSDataItem
    {
        public int npcId = 0;
        public string npcName;
        public string content = "content";//内容
        public float lastTime = 3;//显示时长
        public float spaceTime = 0;//间隔时间
        public OSSkipType skipType = OSSkipType.IMMEDIATELY;//跳过类型 0不允许 1打断式 2立即完成时 
        public uint audioId;//音效
        [XLua.BlackList]
        public string audioName;//音效名



        [XLua.BlackList]
        public OSDataItem() { }



        [XLua.BlackList]
        public OSDataItem(OSDataItem item)
        {
            npcId = item.npcId;
            npcName = item.npcName;
            content = item.content;
            lastTime = item.lastTime;
            spaceTime = item.spaceTime;
            skipType = item.skipType;
            audioId = item.audioId;
        }
    }



    public enum OSSkipType
    {
        NONE = 0,//不跳过
        SKIP = 1,//打断式跳过
        IMMEDIATELY = 2,//立即
    }
}