﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class CoroutineConst
{
    class FloatComparer : IEqualityComparer<float>
    {
        bool IEqualityComparer<float>.Equals(float x, float y)
        {
            return (Mathf.Abs(x - y) < float.Epsilon);
        }
        int IEqualityComparer<float>.GetHashCode(float obj)
        {
            return obj.GetHashCode();
        }
    }

    private static WaitForEndOfFrame s_endOfFrame = new WaitForEndOfFrame();
    public static WaitForEndOfFrame EndOfFrame
    {
        get { return s_endOfFrame; }
    }

    private static WaitForFixedUpdate s_fixedUpdate = new WaitForFixedUpdate();
    public static WaitForFixedUpdate FixedUpdate
    {
        get { return s_fixedUpdate; }
    }

    public const int MAX = 100;
    private static Dictionary<float, WaitForSeconds> m_timeInterval = new Dictionary<float, WaitForSeconds>(MAX, new FloatComparer());
    public static WaitForSeconds GetWaitForSeconds(float seconds)
    {
        WaitForSeconds wfs;
        if (!m_timeInterval.TryGetValue(seconds, out wfs))
        {
            wfs = new WaitForSeconds(seconds);
            if (m_timeInterval.Count < MAX)
            {
                m_timeInterval.Add(seconds, wfs);
            }
        }

        return wfs;
    }
}
