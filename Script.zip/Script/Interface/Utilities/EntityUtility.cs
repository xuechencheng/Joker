using UnityEngine;

namespace Bokura
{
    public sealed class EntityUtility
    {

		public static Transform SearchChildrenTransform(Transform t, string name)
		{
			var c = t.Find(name);
			if (c)
			{
				return c;
			}
			for (int i = 0; i < t.childCount; i++)
			{
				var ct = t.GetChild(i);
				var fd = SearchChildrenTransform(ct, name);
				if (fd)
					return fd;
			}
			return null;
		}
        public static void SearchNearChildrenTransform(Transform t, string name,Vector3 pos,ref Transform node)
        {
            for (int i = 0; i < t.childCount; i++)
            {
                var ct = t.GetChild(i);
                if(ct.name.Equals(name))
                {
                    if (node == null)
                        node = ct;
                    else if (Vector3.Distance(pos, node.position) > Vector3.Distance(pos, ct.position))
                        node = ct;
                }
                SearchNearChildrenTransform(ct, name, pos,ref node);
            }
        }

        public static Transform GetAttachmentTransform(GameObject go, AvatarAttachment attachment)
        {
            if (go)
            {
                return SearchChildrenTransform(go.transform, 
                    Bokura.AvatarAttachmentToBoneNode.CharacterAttachmentBone[(int)attachment]);
            }
            else
            {
                return null;
            }
        }

        public static Transform GetAttachmentSrcTransform(GameObject go, AvatarAttachment attachment)
        {
            if (go)
            {
                return SearchChildrenTransform(go.transform, 
                    AvatarAttachmentToBoneNode.WeaponAttachmentBone[(int)attachment]);
            }
            else
            {
                return null;
            }

        }
    }

}