using System.Diagnostics;
using System.Runtime.CompilerServices;
namespace Bokura
{
     public static class LogHelper
    {
        static System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();
        /// <summary>
        /// 日志信息
        /// </summary>
        /// <param name="args"></param>
        /// 
        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void Log(string args, LogCategory category = LogCategory.GameLogic)
        {
#if SCNEN_EDITOR && UNITY_EDITOR
            UnityEngine.Debug.Log(args);
#else

            if (ILogSystem.Instance != null)
            {
                ILogSystem.Instance.Log(category, args);
            }
#endif
        }
        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogByCategory(LogCategory category, string args)
        {
            Log(args, category);
        }
        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void Log( LogCategory category , string args)
        {
            Log( args, category);
        }

        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void Log(params string[] args)
        {
            Log(Utilities.BuildString(args));
        }

        [Conditional("DEBUG")]
        public static void Log(params object[] args)
        {
            stringBuilder.Length = 0;
            for(int i = 0; i < args.Length; i ++ )
            {            
                stringBuilder.Append(args[i]);
                if (i + 1 < args.Length)
                    stringBuilder.Append(" ");
            }
            Log(stringBuilder.ToString());
        }

        [Conditional("DEBUG")]
        public static void Log(LogCategory category, params object[] args)
        {
            stringBuilder.Length = 0;
            for (int i = 0; i < args.Length; i++)
            {
                stringBuilder.Append(args[i]);
                if (i + 1 < args.Length)
                    stringBuilder.Append(" ");
            }
            Log(category, stringBuilder.ToString());
        }

        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void Log(LogCategory category,params string[] args)
        {
            Log(Utilities.BuildString(args), category);
        }
        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogFormat(string format, params object[] args)
        {
            Log(Utilities.BuildFormatString(format,args));
        }
        [Conditional("DEBUG")]
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogFormat(LogCategory category, string format, params object[] args)
        {
            Log(Utilities.BuildFormatString(format, args), category);
        }

        /// <summary>
        /// 日志警告
        /// </summary>
        /// <param name="args"></param>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogWarning(string args, LogCategory category = LogCategory.GameLogic)
        {
#if SCNEN_EDITOR && UNITY_EDITOR
            UnityEngine.Debug.LogWarning(args);
#else           
            if(ILogSystem.Instance != null)
            {
                ILogSystem.Instance.LogWarning(category, args);
            }
#endif
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogWarning(LogCategory category,string args )
        {
            LogWarning(args, category);
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogWarning(params string[] args)
        {
            LogWarning(Utilities.BuildString(args));
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogWarning(LogCategory category,params string[] args)
        {
            LogWarning(Utilities.BuildString(args), category);
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogWarningFormat(string format, params object[] args)
        {
            LogWarning(Utilities.BuildFormatString(format, args));
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogWarningFormat(LogCategory category, string format, params object[] args)
        {
            LogWarning(Utilities.BuildFormatString(format, args), category);
        }

        public static void LogWarning(params object[] args)
        {
            stringBuilder.Length = 0;
            for (int i = 0; i < args.Length; i++)
            {
                stringBuilder.Append(args[i]);
                if (i + 1 < args.Length)
                    stringBuilder.Append(" ");
            }
            LogWarning(stringBuilder.ToString());
        }
        /// <summary>
        /// 日志错误
        /// </summary>
        /// <param name="args"></param>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogError(string args,LogCategory category = LogCategory.GameLogic)
        {
#if SCNEN_EDITOR && UNITY_EDITOR
            UnityEngine.Debug.LogError(args);
#else
            if(ILogSystem.Instance != null)
            {
                ILogSystem.Instance.LogError(category, args);
            }
#endif
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogError(LogCategory category,string args)
        {
            LogError(args, category);
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogError(params string[] args)
        {
            LogError(Utilities.BuildString(args));
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogError(LogCategory category,params string[] args)
        {
            LogError(Utilities.BuildString(args), category);
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogErrorFormat(string format, params object[] args)
        {
            LogError(Utilities.BuildFormatString(format, args));
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LogErrorFormat(LogCategory category, string format, params object[] args)
        {
            LogError(Utilities.BuildFormatString(format, args), category);
        }

#if UNITY_EDITOR
        [XLua.BlackList]
        public static void ClearLog()
        {
            var flags = System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public;
            var logEntries = System.Type.GetType("UnityEditor.LogEntries,UnityEditor.dll");
            logEntries.GetMethod("Clear", flags).Invoke(null, null);

            var count = (int)logEntries.GetMethod("GetCount").Invoke(null, null);
            if (count > 0)
                throw new System.Exception("Compile Error cannot be cleared");
        }
#endif
    }
}
