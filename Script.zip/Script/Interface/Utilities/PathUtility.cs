﻿using System.Collections.Generic;

public class PathUtility
{
    public static string StandardPath(string p)
    {
        return p.Replace('\\', '/');
              
    }



    /// <summary>
    /// 简化路径，剔除“..”
    /// </summary>
    public static string SimplifiedPath(string p)
    {
        p = p.Replace("\\", "/");
        var paths = p.Split('/');
        string newpath = string.Empty;
        Stack<string> pathstacks = new Stack<string>();
        for (int i = 0; i < paths.Length; i++)
        {
            if (paths[i] == "..")
            {
                if (pathstacks.Count > 0)
                    pathstacks.Pop();
            }
            else if (paths[i] != "." && paths[i].Length > 0)
            {
                pathstacks.Push(paths[i]);
            }
        }
        if (pathstacks.Count > 0)
            newpath = pathstacks.Pop();
        while (pathstacks.Count > 0)
        {
            newpath = Bokura.Utilities.BuildString(pathstacks.Pop(), "/", newpath);
        }

        return newpath;
    }

    public static string GetFilePathWithoutExt(string path)
    {
        var offset = path.LastIndexOf('.');
        return path.Substring(0, offset);
        //return null;
    }

}
