using UnityEngine;
using System.Runtime.CompilerServices;

namespace Bokura
{
    /// <summary>
    /// this class is for using resource loading
    /// all function is inline
    /// </summary>
    public static class ResourceHelper
    {
        /// <summary>
        /// Load asset sync from assets dir
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAsset interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: 
        /// Like "Assets/asset/scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// Or "scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// </param>
        /// <param name="strAssetName">File name: Like "Detail_Type"</param>
        /// <param name="strSuffix">File name suffix: Like ".asset"</param>
        /// <returns> return the asset object</returns>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static UnityEngine.Object LoadResourceSync(string strAssetPath, string strAssetName, string strSuffix, System.Type t = null)
        {
            return IResourceLoader.Instance.LoadAssetSync(strAssetPath, strAssetName, strSuffix, false, t);
        }

        /// <summary>
        /// Load asset async from assets dir
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAssetAsyc interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: Like "Assets/asset/scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// Or "scene/World_JZ_01/DetailChunk/DetailChunk/"
        /// </param>
        /// <param name="strAssetName">File name: Like "Detail_Type"</param>
        /// <param name="strSuffix">File name suffix: Like ".asset"</param>
        /// <param name="callback"> call back func when loading completed </param>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LoadResourceAsync(string strAssetPath, string strAssetName, string strSuffix, LoadCallback callback = null, System.Type t = null)
        {
            IResourceLoader.Instance.LoadAssetAsync(strAssetPath, strAssetName, strSuffix, callback, false, t);
        }

        /// <summary>
        /// Load shader resource sync 
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAssetAsyc interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: Like "Assets/asset/shaders/Nature/"
        /// Or "shaders/Nature/"
        /// </param>
        /// <param name="strAssetName">File name: Like "Grass"</param>
        /// <param name="callback"> call back func when loading completed </param>
        /// <returns> return the shader object</returns>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static UnityEngine.Object LoadShaderSync(string strAssetPath, string strAssetName)
        {
            return IResourceLoader.Instance.LoadAssetSync(strAssetPath, strAssetName, IResourceLoader.strShaderSuffix, true);
        }

        /// <summary>
        /// Load shader resource async 
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAssetAsyc interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: Like "Assets/asset/shaders/Nature/"
        /// Or "shaders/Nature/"
        /// </param>
        /// <param name="strAssetName">File name: Like "Grass"</param>
        /// <param name="callback"> call back func when loading completed </param>
        
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LoadShaderAsync(string strAssetPath, string strAssetName, LoadCallback callback = null)
        {
            IResourceLoader.Instance.LoadAssetAsync(strAssetPath, strAssetName, IResourceLoader.strShaderSuffix, callback, true);
        }

        /// <summary>
        /// Load prefab resource sync 
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAssetAsyc interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: Like "Assets/asset/prefabs/npc/"
        /// Or "prefabs/npc/"
        /// </param>
        /// <param name="strAssetName">File name: Like "chr_fm_j"</param>
        /// <param name="callback"> call back func when loading completed </param>
        /// <returns> return the prefab object</returns>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static UnityEngine.Object LoadPrefabSync(string strAssetPath, string strAssetName)
        {
            return IResourceLoader.Instance.LoadAssetSync(strAssetPath, strAssetName, IResourceLoader.strPrefabSuffix);
        }

        /// <summary>
        /// Load prefab resource async 
        /// In editor mode, it is using "LoadMainAssetAtPath" interface to load resource
        /// In editor runtime mode, it is using Resource.LoadAssetAsyc interface to load resource
        /// In standalone or mobile platform or asset bundle mode, it is loading resource from asset bundle
        /// </summary>
        /// <param name="strAssetPath">
        /// File full path: Like "Assets/asset/prefabs/npc/"
        /// Or "prefabs/npc/"
        /// </param>
        /// <param name="strAssetName">File name: Like "chr_fm_j"</param>
        /// <param name="callback"> call back func when loading completed </param>
        /// <returns> return the prefab object</returns>
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        public static void LoadPrefabAsync(string strAssetPath, string strAssetName, LoadCallback callback)
        {
            IResourceLoader.Instance.LoadAssetAsync(strAssetPath, strAssetName, IResourceLoader.strPrefabSuffix, callback);
        }
    }

}
