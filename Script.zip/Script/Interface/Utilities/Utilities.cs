/********************************************************************
	created:	2017/11/6
	author:		LuoJiEn
	purpose:    Provides common utilities.
*********************************************************************/
using UnityEngine;
using System.Text;
using System;
using System.Text.RegularExpressions;
using System.Runtime.CompilerServices;
using System.Collections.Generic;

namespace Bokura
{
	// This class provides all utility functions
	public sealed class Utilities
	{
        
		/// Provides all utility functions on string concatenation.
		/// global string builder, how to use it
		/// a. m_stringBuilder.Length = 0;     					   	// to clear previous string operation result
		/// b. m_stringBuilder.Append/m_stringBuilder.AppendFormat   // try to use Append as much as possible, since more efficient
		/// c. m_stringBuilder.ToString ();
		#region GLOBAL_STRING_BUILDER
		/// global string builder, to improve both memory efficiency and CPU efficiency.
		// (initially to allow 1024 characters, later on, if we need more, the string builder will automatically expand the internal buffer.)
		static private StringBuilder s_stringBuilder = new StringBuilder (1024 * 4);

        static public StringBuilder GetStringBuilder()
        {
            return s_stringBuilder;
        }

        /// Concatenate multiple strings together, and return the result.
        /// <param name="args">       all substrings to concatenate.</param>
        /// <param name="appendLine"> whether to append a return line between all given substrings.</param>
        /// <returns>                 the resulting concatenated string.</returns>
        static public string BuildString (string[] args, bool appendLine)
		{
			s_stringBuilder.Length = 0; 
			for (int i = 0; i < args.Length; i++)
			{
				s_stringBuilder.Append (args[i]);
				if (true == appendLine)	s_stringBuilder.AppendLine ();
			}
			return s_stringBuilder.ToString ();
		}

        /// Concatenate multiple strings together, and return the result.
		/// <param name="args">       all substrings to concatenate.</param>
		/// <returns>                 the resulting concatenated string.</returns>
        static public string BuildString(params string[] args)
        {
            return BuildString(false, args);
        }
        static public string BuildString(string arg1)
        {
            return BuildString(false, arg1);
        }
        static public string BuildString(string arg1, string arg2)
        {
            return BuildString(false, arg1, arg2);
        }
        static public string BuildString(string arg1, string arg2, string arg3)
        {
            return BuildString(false, arg1, arg2, arg3);
        }
        static public string BuildString(string arg1, string arg2, string arg3, string arg4)
        {
            return BuildString(false, arg1, arg2, arg3, arg4);
        }


        /// Concatenate multiple strings together, and return the result.
        /// <param name="appendLine"> whether to append a return line between all given substrings.</param>
        /// <param name="args">       all substrings to concatenate.</param>
        /// <returns>                 the resulting concatenated string.</returns>
        static public string BuildString (bool appendLine, params string[] args)
		{
			s_stringBuilder.Length = 0; 
			for (int i = 0; i < args.Length; i++)
			{
				s_stringBuilder.Append (args[i]);
				if (true == appendLine)	s_stringBuilder.AppendLine ();
			}
			return s_stringBuilder.ToString ();
        }
        static public string BuildString(bool appendLine, string arg1)
        {
            return appendLine ? BuildString(false, arg1, "\n") : arg1;
        }
        static public string BuildString(bool appendLine, string arg1, string arg2)
        {
            s_stringBuilder.Length = 0;
            s_stringBuilder.Append(arg1);
            if (true == appendLine) s_stringBuilder.AppendLine();
            s_stringBuilder.Append(arg2);
            if (true == appendLine) s_stringBuilder.AppendLine();
            return s_stringBuilder.ToString();
        }
        static public string BuildString(bool appendLine, string arg1, string arg2, string arg3)
        {
            s_stringBuilder.Length = 0;
            s_stringBuilder.Append(arg1);
            if (true == appendLine) s_stringBuilder.AppendLine();
            s_stringBuilder.Append(arg2);
            if (true == appendLine) s_stringBuilder.AppendLine();
            s_stringBuilder.Append(arg3);
            if (true == appendLine) s_stringBuilder.AppendLine();
            return s_stringBuilder.ToString();
        }
        static public string BuildString(bool appendLine, string arg1, string arg2, string arg3, string arg4)
        {
            s_stringBuilder.Length = 0;
            s_stringBuilder.Append(arg1);
            if (true == appendLine) s_stringBuilder.AppendLine();
            s_stringBuilder.Append(arg2);
            if (true == appendLine) s_stringBuilder.AppendLine();
            s_stringBuilder.Append(arg3);
            if (true == appendLine) s_stringBuilder.AppendLine();
            s_stringBuilder.Append(arg4);
            if (true == appendLine) s_stringBuilder.AppendLine();
            return s_stringBuilder.ToString();
        }

        /// Ten times faster than the String.Equals function with two string compare
        /// <returns>             the resulting two strings equals.</returns>
        static public bool StringEquals(string str1, string str2)
        {
            return string.Equals(str1, str2, StringComparison.Ordinal);
        }

        /// Ten times faster than the String.Equals function with two string compare
        /// IgnoreCase
        /// <returns>             the resulting two strings equals.</returns>
        static public bool StringEqualsIgnoreCase(string str1, string str2)
        {
            return string.Equals(str1, str2, StringComparison.OrdinalIgnoreCase);
        }

        /// 20 times faster than the String.StartsWith function with two string compare
        /// <returns>             the resulting two strings equals.</returns>
        static public bool StringStartsWith(string a, string b)
        {
            int aLen = a.Length;
            int bLen = b.Length;
            int ap = 0;
            int bp = 0;

            while (ap < aLen && bp < bLen && a[ap] == b[bp])
            {
                ap++;
                bp++;
            }

            return (bp == bLen && aLen >= bLen) || (ap == aLen && bLen >= aLen);
        }

        /// 100 times faster than the String.EndsWith function with two string compare
        /// <returns>             the resulting two strings equals.</returns>
        static public bool StringEndsWith(string a, string b)
        {
            int ap = a.Length - 1;
            int bp = b.Length - 1;

            while (ap >= 0 && bp >= 0 && a[ap] == b[bp])
            {
                ap--;
                bp--;
            }
            return (bp < 0 && a.Length >= b.Length) || (ap < 0 && b.Length >= a.Length);
        }

        /// low gc generated to use this function, compare with Regex.Match
        static public Match RegexMatch(string strRegExp, string strMatch)
        {
            var myRegExp = new Regex(strRegExp);
            return myRegExp.Match(strMatch);
        }

        /// Build a formated string.
        /// <param name="format"> string format.</param>
        /// <param name="args">   all substrings to concatenate.</param>
        /// <returns>             the resulting concatenated string.</returns>
        static public string BuildFormatString (string format, params object[] args)
		{
			s_stringBuilder.Length = 0; 
			s_stringBuilder.AppendFormat (format, args);
			return s_stringBuilder.ToString ();
		}

        #endregion GLOBAL_STRING_BUILDER

        #region Profiler
        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        static public void ProfilerBegin(string desc)
        {
#if !RELEASE || UNITY_EDITOR
            UnityEngine.Profiling.Profiler.BeginSample(desc);
#endif
        }


        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        static public void ProfilerEnd()
        {
#if !RELEASE || UNITY_EDITOR
            UnityEngine.Profiling.Profiler.EndSample();
#endif
        }
        #endregion

        #region Math Method
        static public float Vector2Angle(float x, float y)
		{
			if (float.IsNaN(x)||float.IsNaN(y))
				return 0.0f;
			float angle = 0;
			if (x == 0)
			{
				angle = y > 0 ? 90 : 270;
			}
			else if (x > 0)
			{
				angle = (float)(y > 0 ? Math.Atan(y / x) : (Mathf.PI * 2 + Math.Atan(y / x))) * Mathf.Rad2Deg;
			}
			else
				angle = (float)(180 + Math.Atan(y / x) * Mathf.Rad2Deg);
			return angle;
		}
		static public void Angle2Vector2(float angle, out float x, out float y)
		{
			if (float.IsNaN(angle))
			{
				x = 1.0f;
				y = 0.0f;
				return;
			}

			x = Mathf.Cos(angle/Mathf.Rad2Deg);
			y = Mathf.Sin(angle/Mathf.Rad2Deg);
		}

		static public float NormalizeAngle(float angle, float rg = 360.0f)
		{
			while (angle > rg) angle -= 360.0f;
			while (angle < rg - 360.0f) angle += 360.0f;
			return angle;

		}

		static public float AngleDiff(float a, float b )
		{
			if (a - b > 180)
				a -= 360.0f;
			if (b - a > 180)
				a += 360.0f;
			return a - b;
		}

        /// <summary>
        /// calc point to line distance
        /// </summary>
        /// <param name="a">line begin point</param>
        /// <param name="b">line end point</param>
        /// <param name="p">point</param>
        /// <param name="closePoint">output closet point on line </param>
        /// <returns>Return point to line distance</returns>
        static public float PointLineDistance(Vector3 a, Vector3 b, Vector3 p, out Vector3 closetPoint)
        {
            var v = b - a;
            var vp = p - a;
            var dot = Vector3.Dot(v, vp);
            if (dot <= 0)
            {
                closetPoint = a;
                return (a-p).magnitude;
            }

            var dis = v.sqrMagnitude;
            if (dot >= dis)
            {
                closetPoint = b;
                return (b-p).magnitude;
            }

            var r = dot / dis;
            closetPoint = v * r + a;
            return (closetPoint-p).magnitude;
        }

        /// <summary>
        /// Gets the number of digital
        /// </summary>
        /// <param name="value">The number for counting</param>
        /// <returns>Return the number of digital</returns>
        public static int GetIntLength(int value)
        {
            int count = 1;
            value = value / 10;
            while(value >= 10)
            {
                count++;
                value = value / 10;
            }

            if(value > 0)
                count++;
            return count;
        }

        static char[] m_charIndex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' }; /// For fill number to string

        /// <summary>
        /// Fill number into a string
        /// </summary>
        public static string FillNumberToString(string result, int number)
        {
            if(!string.IsNullOrEmpty(result))
            {
                if (number < 0)
                    number = -number;

                int length = GetIntLength(number);
                if (result.Length <= length)
                {
                    result = new string('\0', length * 2 + 1);
                    //LogHelper.Log("FillNumberToString:" + result);
                }

                unsafe
                {
                    fixed (char* aTemp = result)
                    {
                        for (int i = length - 1; i >= 0; --i)
                        {
                            *(aTemp + i) = m_charIndex[number % 10];
                            number = number / 10;
                        }

                        for (int i = length; i < result.Length; ++i)
                            *(aTemp + length) = (char)0x0;
                    }
                }
            }
            return result;
        }

        static public float AngleLerp(float a, float b, float s)
		{
			a = NormalizeAngle(a);
			b = NormalizeAngle(b);
			if (a - b > 180)
				a -= 360.0f;
			if (b - a > 180)
				a += 360.0f;
			return a * (1-s) + b*s;
		}

        //No GC 但性能稍微差点,要是能改Unity代码,可以直接使用本地代码提升性能 add guyunhua

        public static void CalculateFrustumPlanes(Camera camera, Plane[] planes)
        {
            CalculateFrustumPlanes(camera.projectionMatrix * camera.worldToCameraMatrix, planes);
        }

        public static void CalculateFrustumPlanes(Matrix4x4 mat, Plane[] planes)
        {
            if (planes == null || planes.Length != 6)
            {
                //throw "plane"
                return;
            }
            planes[0].normal = new Vector3(mat.m30 + mat.m00, mat.m31 + mat.m01, mat.m32 + mat.m02);
            planes[0].distance = mat.m33 + mat.m03;

            planes[1].normal = new Vector3(mat.m30 - mat.m00, mat.m31 - mat.m01, mat.m32 - mat.m02);
            planes[1].distance = mat.m33 - mat.m03;

            planes[2].normal = new Vector3(mat.m30 + mat.m10, mat.m31 + mat.m11, mat.m32 + mat.m12);
            planes[2].distance = mat.m33 + mat.m13;

            planes[3].normal = new Vector3(mat.m30 - mat.m10, mat.m31 - mat.m11, mat.m32 - mat.m12);
            planes[3].distance = mat.m33 - mat.m13;

            planes[4].normal = new Vector3(mat.m30 + mat.m20, mat.m31 + mat.m21, mat.m32 + mat.m22);
            planes[4].distance = mat.m33 + mat.m23;

            planes[5].normal = new Vector3(mat.m30 - mat.m20, mat.m31 - mat.m21, mat.m32 - mat.m22);
            planes[5].distance = mat.m33 - mat.m23;

            for (int i = 0; i < 6; i++)
            {
                float length = planes[i].normal.magnitude;
                planes[i].normal /= length;
                planes[i].distance /= length;
            }
        }
        #endregion

        #region render
        static ShadowQuality m_lastShadowQuality = ShadowQuality.All;

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        static public void DisableShadow()
        {
            m_lastShadowQuality = QualitySettings.shadows;
            QualitySettings.shadows = ShadowQuality.Disable;
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        static public void RestoreShadow()
        {
            QualitySettings.shadows = m_lastShadowQuality;
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        static public DepthTextureMode GetCameraFlags()
        {
#if SCENE_EDITOR && UNITY_EDITOR
            return DepthTextureMode.Depth; // needed this?
#else
            return DepthTextureMode.None; // needed this?
#endif
        }

        [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        static public void SetCameraMode(Camera cam)
        {
            if(cam)
            {
#if SCENE_EDITOR && UNITY_EDITOR
                cam.depthTextureMode |= DepthTextureMode.Depth; // needed this?
#else
                cam.depthTextureMode = DepthTextureMode.None; // needed this?
#endif
            }

        }

        static RenderTextureFormat _rgbFloatRenderTargetFormat = RenderTextureFormat.ARGB32; // mark for not determined
        static public RenderTextureFormat RgbFloatRenderTargetFormat()
        {
            if (_rgbFloatRenderTargetFormat == RenderTextureFormat.ARGB32) // to detect
            {
                if (SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.RGB111110Float))
                    _rgbFloatRenderTargetFormat = RenderTextureFormat.RGB111110Float;
                else if (SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBHalf))
                    _rgbFloatRenderTargetFormat = RenderTextureFormat.ARGBHalf;
                else _rgbFloatRenderTargetFormat = RenderTextureFormat.ARGBFloat;
            }
            return _rgbFloatRenderTargetFormat;
        }
        #endregion


        #region Physics Cast

        static public bool SphereCast(Vector3 origin, float radius, Vector3 direction, out RaycastHit hitInfo, float maxDistance = 9999999, int layerMask = (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.Ignore)
        {
            var count = Physics.SphereCastNonAlloc(origin, radius, direction, casthits, maxDistance, layerMask, queryTriggerInteraction);
            return ReturnCast(count, out hitInfo);
        }
        static public bool SphereCast(Ray ray, float radius, out RaycastHit hitInfo, float maxDistance = 9999999, int layerMask = (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.Ignore)
        {
            var count = Physics.SphereCastNonAlloc(ray, radius, casthits, maxDistance, layerMask, queryTriggerInteraction);
            return ReturnCast(count, out hitInfo);
        }
        static public bool RayCast(Vector3 origin, Vector3 direction, out RaycastHit hitInfo, float maxDistance = 9999999, int layerMask = (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.Ignore)
        {
            var count = Physics.RaycastNonAlloc(origin, direction, casthits, maxDistance, layerMask, queryTriggerInteraction);
            return ReturnCast(count, out hitInfo);
        }
        static public bool RayCast(Vector3 origin, Vector3 direction, float maxDistance = 9999999, int layerMask = (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.Ignore)
        {
            var count = Physics.RaycastNonAlloc(origin, direction, casthits, maxDistance, layerMask, queryTriggerInteraction);
            return count > 0;
        }
        static public bool RayCast(Ray ray, out RaycastHit hitInfo, float maxDistance = 9999999, int layerMask = (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.Ignore)
        {
            var count = Physics.RaycastNonAlloc(ray, casthits, maxDistance, layerMask, queryTriggerInteraction);
            return ReturnCast(count, out hitInfo);
        }
        static public bool RayCast(Ray ray, float maxDistance = 9999999, int layerMask = (int)Bokura.UserLayerMask.AllBlock, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.Ignore)
        {
            var count = Physics.RaycastNonAlloc(ray, casthits, maxDistance, layerMask, queryTriggerInteraction);
            return count > 0;
        }
        static RaycastHit[] casthits = new RaycastHit[16];
        static bool ReturnCast(int count, out RaycastHit hitInfo)
        {
            if (count > 0 && count < casthits.Length)
            {
                //LogHelper.LogWarning("cast start");
                //for (int i = 0; i < count; i++) LogHelper.LogWarningFormat("distance:{0}", casthits[i].distance);
                //LogHelper.LogWarning("cast end");
                hitInfo = casthits[0]; 
                for (int i = 1; i < count; i++)
                    if (casthits[i].distance < hitInfo.distance)
                        hitInfo = casthits[i];
                return true;
            }
            else
            {
                hitInfo = default(RaycastHit);
                return false;
            }
        }
        #endregion

        #region Other

        public static byte[] UTF8Process(byte[] bt)
        {
            if (bt.Length > 3 && bt[0] == 0xEF && bt[1] == 0xBB && bt[2] == 0xBF)
            {
                byte[] nbt = new byte[bt.Length - 3];
                System.Array.Copy(bt, 3, nbt, 0, nbt.Length);
                return nbt;
            }
            return bt;
        }
        #endregion

        #region Transform extand
        public static void CopyTransform(Transform from, Transform to, string name)
        {
            var node = SearchChildTransform(from, name);
            if (node)
            {
                var tonode = SearchChildTransform(to, name);
                if (tonode)
                {
                    tonode.localScale = node.localScale;
                    tonode.localPosition = node.localPosition;
                    tonode.localRotation = node.localRotation;
                }
            }
        }
        public static Transform SearchChildTransform(Transform t, AvatarAttachment attchment, bool isWeapon = false)
        {
            string name = isWeapon ? AvatarAttachmentToBoneNode.WeaponAttachmentBone[(int)attchment] : AvatarAttachmentToBoneNode.CharacterAttachmentBone[(int)attchment];
            return string.IsNullOrEmpty(name) ? null: Utilities.SearchChildTransform(t, name);
        }
        public static Transform SearchChildTransform(Transform t, string name)
        {
            if (t != null)
            {
                var c = t.Find(name);
                if (c)
                {
                    return c;
                }
                for (int i = 0; i < t.childCount; i++)
                {
                    var ct = t.GetChild(i);
                    var fd = SearchChildTransform(ct, name);
                    if (fd)
                        return fd;
                }
            }
            return null;
        }
        public static GameObject SearchChildTransform(GameObject go, string name)
        {
            if (go != null)
            {
                var retgo = SearchChildTransform(go.transform, name);
                return retgo != null ? retgo.gameObject : null;
            }
            return null;
        }
        #endregion

        #region animator
        static Dictionary<int, string> m_hashToName = new Dictionary<int, string>(128);

        public static int AnimatorStringToHash(string s)
        {
            int hash = Animator.StringToHash(s);
#if UNITY_EDITOR
            string name;
            if (m_hashToName.TryGetValue(hash, out name))
            {
                if (name != s)
                    Bokura.LogHelper.LogError("State Name Hash Conflict!", s, " ", name, " ", hash.ToString());
                return hash;
            }
            m_hashToName.Add(hash, s);
#endif
            return hash;
        }

        public static string AnimatorHashToString(int hash)
        {
            string name;
            if (m_hashToName.TryGetValue(hash, out name))
            {
                return name;
            }
            return string.Empty;
        }


        #endregion
    }
}