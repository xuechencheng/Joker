﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatorPlayer : MonoBehaviour {

    public Animator animator = null;
	// Use this for initialization
	void Start () {
		
	}
    private void OnEnable()
    {
        animator = GetComponent<Animator>();
    }
    // Update is called once per frame
    void Update () {

    }

    private void OnAnimatorMove()
    {
        if (animator != null)
        {
            var curinfo = animator.GetCurrentAnimatorStateInfo(0);
            var nextinfo = animator.GetNextAnimatorStateInfo(0);
            Debug.Log(string.Format("{0}({1}) {2}({3}) {4} ", curinfo.shortNameHash, curinfo.normalizedTime, nextinfo.shortNameHash, nextinfo.normalizedTime, animator.deltaPosition));
        }
    }
}
