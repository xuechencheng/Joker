﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;

[CustomEditor(typeof(AnimatorPlayer))]
public class AnimatorPlayerInspector : Editor
{
    [MenuItem("Tools/检查基础状态机基础动作")]
    public static  void CheckAnimator()
    {

    }

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public Animator animator = null;
    private void OnEnable()
    {
        animator = (target as AnimatorPlayer).GetComponent<Animator>();
    }

    public override void OnInspectorGUI()
    {
        if(animator != null)
        {
            AnimatorController animController;
            if (animator.runtimeAnimatorController.GetType() == typeof(AnimatorOverrideController))
                animController = ((AnimatorOverrideController)animator.runtimeAnimatorController).runtimeAnimatorController as AnimatorController;
            else
                animController = animator.runtimeAnimatorController as AnimatorController;
           

            GUILayout.BeginVertical("Box");
            EditorGUI.indentLevel++;
            OnStatesRecursiveGUI(animController.layers[0].stateMachine);
            EditorGUI.indentLevel--;
            GUILayout.EndVertical();
        }
    }

    private List<AnimatorState> GetStates(AnimatorStateMachine sm)
    {
        List<AnimatorState> stateArray = new List<AnimatorState>();
        foreach (ChildAnimatorState childState in sm.states)
        {
            stateArray.Add(childState.state);
        }

        return stateArray;
    }
    protected Dictionary<string, bool> open = new Dictionary<string, bool>();

    private void OnStatesRecursiveGUI(AnimatorStateMachine sm)
    {
        if (!open.ContainsKey(sm.name)) open.Add(sm.name, false);
        
        open[sm.name] = EditorGUILayout.Foldout(open[sm.name], sm.name);
        EditorGUI.indentLevel++;
        if (open[sm.name] == true)
        {
            var states = GetStates(sm);
            foreach (var s in states)
            {
                if (GUILayout.Button(s.name))
                {
                    animator.Play(s.name);
                }
            }
        }
        
        foreach (ChildAnimatorStateMachine childStateMachine in sm.stateMachines)
        {
            OnStatesRecursiveGUI(childStateMachine.stateMachine);
        }
        EditorGUI.indentLevel--;
    }

}
