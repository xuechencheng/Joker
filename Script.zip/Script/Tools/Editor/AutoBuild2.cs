using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using System;
using System.Text;
using System.Linq;
using UnityEngine.Networking;
using Ionic.Zip;
using Bokura.CustomTools;

public static class AutoBuild2
{
    private static string MAP_TASK_CONFIG_PATH = "Assets/Resources/asset/scene/MapTaskConfigure.asset";
    /// project build options.
    static BuildOptions s_defaultBuildOpt
    {
        get
        {
            // perform the build without any special settings or extra tasks
            BuildOptions opt = BuildOptions.None;

            // start the player with a connection to the profiler in the editor
            if (true == EditorUserBuildSettings.connectProfiler) opt |= BuildOptions.ConnectWithProfiler;

            // build a development version of the player
            // (A development build includes debug symbols and enables the Profiler)    
            //if (true == EditorUserBuildSettings.development) opt |= BuildOptions.Development;

            // Symlink runtime libraries when generating iOS XCode project. (Faster iteration time
            if (true == EditorUserBuildSettings.symlinkLibraries) opt |= BuildOptions.SymlinkLibraries;

            // allow script debuggers to attach to the player remotely
            if (true == EditorUserBuildSettings.allowDebugging) opt |= BuildOptions.AllowDebugging;

            // multiple combined options
            return opt;
        }
    }

    public static class AndroidSDKFolder
    {
        public static string Path
        {
            get { return EditorPrefs.GetString("AndroidSdkRoot"); }

            set { EditorPrefs.SetString("AndroidSdkRoot", value); }
        }
    }


    private static bool _GetSetBuildModeParams(out string buildMode)
    {
        buildMode = string.Empty;
        // Begin Parse Args
        Debug.Log("Start Parse Command Args \r\n");
        var args = Environment.GetCommandLineArgs();

        // Parse args
        try
        {
            foreach (var arg in args)
            {
                string[] splits = arg.Split('=');
                Debug.Log(string.Format("Splits = {0} \r\n", splits[0]));
                if (splits.Length < 2)
                    continue;

                switch (splits[0])
                {
                    case "-buildMode":
                        buildMode = splits[1].Trim().ToUpper();
                        Debug.Log(string.Format("BuildMode = {0} \r\n", buildMode));
                        break;
                }
            }
            if (buildMode != "DEBUG" && buildMode != "RELEASE" && buildMode != "PSEUDO")
                throw new Exception(string.Format("Parameters \"{0}\" is invalid.", Environment.CommandLine));
        }
        catch (Exception ex)
        {
            Debug.LogError("[BUILD ERROR] " + ex.ToString() + "/r/n");
            return false;
        }

        return true;
    }

    private static bool _GetSetCustomDefinesParams(out List<string> defines)
    {
        defines = new List<string>();
        // Begin Parse Args
        Debug.Log("Start Parse Command Args \r\n");
        var args = Environment.GetCommandLineArgs();

        // Parse args
        try
        {
            foreach (var arg in args)
            {
                string[] splits = arg.Split('=');
                Debug.Log(string.Format("Splits = {0} \r\n", splits[0]));
                if (splits.Length < 2)
                    continue;

                switch (splits[0])
                {
                    case "-customDefine":
                        var defineString = splits[1].Trim().ToUpper();
                        if (defineString != string.Empty)
                            defines = defineString.Split(';').ToList();
                        Debug.Log(string.Format("{0} defined\r\n", defineString));
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("[BUILD ERROR] " + ex.ToString() + "/r/n");
            return false;
        }

        return true;
    }

    private static bool _GetBuildParams(out string platform, out string outputPath, out string changeList)
    {
        outputPath = @"./Builds/";
        platform = string.Empty;
        changeList = "0";
        // Begin Parse Args
        Debug.Log("Start Parse Command Args \r\n");
        var args = Environment.GetCommandLineArgs();

        // Parse args
        try
        {
            foreach (var arg in args)
            {
                string[] splits = arg.Split('=');
                Debug.Log(string.Format("Splits = {0} \r\n", splits[0]));
                if (splits.Length < 2)
                    continue;

                switch (splits[0])
                {
                    case "-platform":
                        platform = splits[1].Trim().ToUpper();
                        Debug.Log(string.Format("Platform = {0} \r\n", platform));
                        break;
                    case "-output":
                        outputPath = splits[1].Trim();
                        Debug.Log(string.Format("OutputPath = {0} \r\n", outputPath));
                        break;
                    case "-changelist":
                        changeList = splits[1].Trim();
                        Debug.Log(string.Format("ChangeList = {0} \r\n", changeList));
                        break;
                }
            }
            if (platform != "WIN" && platform != "ANDROID" && platform != "IOS")
                throw new Exception(string.Format("Parameters \"{0}\" is invalid.", Environment.CommandLine));
            if (!outputPath.EndsWith("/"))
                outputPath += "/";
            Directory.CreateDirectory(outputPath + platform + "/");
        }
        catch (Exception ex)
        {
            Debug.LogError("[BUILD ERROR] " + ex.ToString() + "/r/n");
            return false;
        }

        return true;
    }

    public static void RunCompileCS()
    {
        // Do nothing but compile CSharp files
    }

    public static void RunSetBuildMode()
    {
        string buildMode;
        if (_GetSetBuildModeParams(out buildMode))
        {
            // All parses end
            Debug.Log(string.Format("Succeed to parse params, buildMode = {0}\r\n", buildMode));
            Debug.Log("Start to Set Build Mode\r\n");

            switch (buildMode)
            {
                case "DEBUG":
                    GiantEditor.BuildConfiguration.SetDevelopMode();
                    break;
                case "RELEASE":
                    GiantEditor.BuildConfiguration.SetReleaseMode();
                    break;
                case "PSEUDO":
                    GiantEditor.BuildConfiguration.SetPseudoMode();
                    break;
            }
        }
    }

    /// <summary>
    /// Set define symbols, always used with RevertScriptingDefineSymbols
    /// </summary>
    public static void RunSetCustomDefines()
    {
        List<string> defines;
        if (_GetSetCustomDefinesParams(out defines))
        {
            // All parses end
            Debug.Log("Start to Set Custom Defines\r\n");

            // Early out
            if (defines.Count == 0)
            {
                Debug.Log("Custom Define is Empty, Return\r\n");
                return;
            }

            // Get origin scripting define symbols
            var sds = UnityEditor.PlayerSettings.GetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup);
            var sdsList = new List<string>(sds.Split(';'));

            // Add symbols.
            foreach (var define in defines)
            {
                if (!sdsList.Contains(define))
                    sdsList.Insert(0, define);
            }
            sds = string.Join(";", sdsList);
            Debug.LogFormat("Important: Set Scripting Define Symbols: {0}\r\n", sds);
            UnityEditor.PlayerSettings.SetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup, sds);
        }
    }

    public static void RunBuildAllDoc()
    {
        AutoGenPBOnBuild.GenAllDocForVersionBuild();
    }

    public static void RunBuild()
    {
        string platform;
        string outputPath;
        string changeList;
        if (_GetBuildParams(out platform, out outputPath, out changeList))
        {
            // All parses end
            Debug.Log(string.Format("Succeed to parse params, platform = {0}, changeList = {1}\r\n", platform, changeList));
            Debug.Log("Start to Build\r\n");

            MakeAssetsLink(platform);
            // Call write change list function. Foo(changeList);
            var bytes = UTF8Encoding.UTF8.GetBytes("return " + changeList);
            File.WriteAllBytes(Path.Combine(Application.streamingAssetsPath, "LuaScript/buildversion.lua"), bytes);
            PlayerSettings.stripEngineCode = true;

            switch (platform)
            {
                case "WIN":
                    BuildWindows64(outputPath + platform + "/");
                    break;
                case "IOS":
                    BuildIOS(outputPath + platform + "/");
                    break;
                case "ANDROID":
                    BuildAndroid(outputPath + platform + "/");
                    break;
            }
        }
    }

    private static void BuildWindows64(string outputPath)
    {
        // list of scenes in the build
        List<string> scenesInBuild = new List<string>();
        GetScenesInBuild(scenesInBuild);
        if (0 == scenesInBuild.Count)
        {
            Debug.LogWarning("No scenes in the Build Settings to build!");
            return;
        }

        // full filename of the export executable
        string buildExe = GetBuildFilename("PC", outputPath, ".exe");

        BuildPlayerOptions bpo = new BuildPlayerOptions();
        bpo.options = s_defaultBuildOpt;
        bpo.scenes = scenesInBuild.ToArray();
        bpo.locationPathName = buildExe;
        bpo.target = BuildTarget.StandaloneWindows64;
        // make a PC build
        EditorUserBuildSettings.selectedStandaloneTarget = BuildTarget.StandaloneWindows64;
        UnityEditor.Build.Reporting.BuildReport error = BuildPipeline.BuildPlayer(bpo);

        if (error.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded) Debug.Log("Build succeed!");
        else Debug.LogError("[BUILD ERROR] " + error.summary.result);
    }

    private static void BuildIOS(string outputPath)
    {
        // list of scenes in the build
        List<string> scenesInBuild = new List<string>();
        GetScenesInBuild(scenesInBuild);
        if (0 == scenesInBuild.Count)
        {
            Debug.LogWarning("No scenes in the Build Settings to build!");
            return;
        }

        // name of the export iOS package
        string buildFolder = outputPath;

        // make an Android build
        BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
        buildPlayerOptions.scenes = scenesInBuild.ToArray();
        buildPlayerOptions.locationPathName = buildFolder;
        buildPlayerOptions.target = BuildTarget.iOS;
        var tOption = s_defaultBuildOpt;
        if (true == EditorUserBuildSettings.development) tOption |= BuildOptions.Development;
        buildPlayerOptions.options = tOption;
        UnityEditor.Build.Reporting.BuildReport error = BuildPipeline.BuildPlayer(buildPlayerOptions);
        if (error.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded) Debug.Log("Build succeed!");
        else Debug.LogError("[BUILD ERROR] " + error.summary.result);
    }

    private static void BuildAndroid(string outputPath)
    {
        // list of scenes in the build
        List<string> scenesInBuild = new List<string>();
        GetScenesInBuild(scenesInBuild);
        if (0 == scenesInBuild.Count)
        {
            Debug.LogWarning("No scenes in the Build Settings to build!");
            return;
        }

        // Android SDK folder for Android build
        string sdkPath = Environment.GetEnvironmentVariable("ANDROID_SDK_PATH");
        if (null != sdkPath)
        {
            Debug.Log("Android SDK Path = " + sdkPath);
            AndroidSDKFolder.Path = sdkPath;
        }

        // name of the export Android package
        string buildApk = GetBuildFilename("Android", outputPath, ".apk");

        // make an Android build
        EditorUserBuildSettings.selectedStandaloneTarget = BuildTarget.Android;
        var tOption = s_defaultBuildOpt;
        if (true == EditorUserBuildSettings.development) tOption |= BuildOptions.Development;
        UnityEditor.Build.Reporting.BuildReport error = BuildPipeline.BuildPlayer(scenesInBuild.ToArray(), buildApk, BuildTarget.Android, tOption);
        if (error.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded) Debug.Log("Build succeed!");
        else Debug.LogError("[BUILD ERROR] " + error.summary.result);
    }

    private static void MakeAssetsLink(string platform)
    {
        // remove all separate assets from the client project
        string batFile;
        string args = string.Empty;
        switch (Environment.OSVersion.Platform)
        {
            case PlatformID.MacOSX:
            case PlatformID.Unix:
                batFile = "/bin/sh";
                args = Application.dataPath + "/../../../tools/remove_link_resource_win.sh";
                break;
            default:
                batFile = Application.dataPath + "/../../../tools/remove_link_resource_win.bat";
                break;
        }
        RunExternalFile(batFile, args, string.Empty, true);

        //if (Directory.Exists(Application.dataPath + "/StreamingAssets/AssetBundles/" + platform.ToLower()) ||
        //    File.Exists(Application.dataPath + "/StreamingAssets/AssetBundles/" + platform.ToLower()))
        //{
        //    // Nothing to do.
        //    Debug.Log("Assetbundles is linked.");
        //}
        //else
        //{
        //    // link all assetbundles to the client project
        //    switch (Environment.OSVersion.Platform)
        //    {
        //        case PlatformID.MacOSX:
        //        case PlatformID.Unix:
        //            batFile = "/bin/sh";
        //            args = Application.dataPath + @"/../../../tools/link_assetbundles_client_" + platform.ToLower() + ".sh";
        //            break;
        //        default:
        //            batFile = Application.dataPath + @"/../../../tools/link_assetbundles_client_" + platform.ToLower() + ".bat";
        //            break;
        //    }
        //    RunExternalFile(batFile, args, string.Empty, true);
        //}
    }

    public static void GetScenesInBuild(List<string> scenesInBuild)
    {
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
        {
            if (null != scene && true == scene.enabled)
            {
                scenesInBuild.Add(scene.path);
            }
        }
    }

    /// Calculate full filename of the target build.
    /// <param name="platform">  build platform.</param>
    /// <param name="buildPath"> path to export the build file.</param>
    /// <param name="extension"> extension of the build file.</param>
    static private string GetBuildFilename(string platform, string buildPath, string extension)
    {
        string appId = PlayerSettings.GetApplicationIdentifier(BuildTargetGroup.Unknown);
        switch (platform)
        {
            case "PC":
                appId = PlayerSettings.GetApplicationIdentifier(BuildTargetGroup.Standalone);
                break;
            case "Android":
                appId = PlayerSettings.GetApplicationIdentifier(BuildTargetGroup.Android);
                break;
        }

        string[] splittedAppId = appId.Split('.');
        // name of the export executable
        string buildExe;
        if (0 == splittedAppId.Length)
            buildExe = buildPath + "DemoApp";
        else
            buildExe = buildPath + splittedAppId[splittedAppId.Length - 1];

        return string.Format("{0}_{1}{2}", buildExe, platform, extension);
    }


    /// Run an external application.
    /// <param name="fileName">    application file to execute. </param>
    /// <param name="args">        application arguments to execute. </param>
    /// <param name="workingDirectory"> applicaiton working directory. </param>
    /// <param name="input">       inputs to the application. </param>
    ///                            (a process can read input text from its standard input stream, typically the keyboard. By redirecting
    ///                             the StandardInput stream, you can programmatically specify the input. For example, instead of using 
    ///                             keyboard input, you can provide text from the contents of a designated file or output from another application)
    /// <param name="output">      application outputs. </param>
    /// <param name="error">       application error message. </param>
    /// <returns>                  whether command execution correctly.</returns>
    public static bool RunExternalFile(string fileName, string args, string workingDirectory, string input, out string output, out string error)
    {
        // fill in the application process info
        System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo();
        info.FileName = fileName;
        if (false == string.IsNullOrEmpty(workingDirectory))
        {
            info.WorkingDirectory = workingDirectory;
        }
        info.Arguments = args;
        info.RedirectStandardOutput = true;
        info.RedirectStandardInput = true;
        info.RedirectStandardError = true;
        info.UseShellExecute = false;
        info.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;

        // start the application process
        System.Diagnostics.Process proc = System.Diagnostics.Process.Start(info);
        if (false == string.IsNullOrEmpty(input))
        {
            StreamWriter myStreamWriter = proc.StandardInput;
            myStreamWriter.WriteLine(input);
            myStreamWriter.Close();
        }

        // wait until the application ends
        StringBuilder outputBuilder = new StringBuilder();
        StringBuilder errorBuilder = new StringBuilder();
        while (false == proc.HasExited)
        {
            // get standard output from the p4
            outputBuilder.Append(proc.StandardOutput.ReadToEnd());
            errorBuilder.Append(proc.StandardError.ReadToEnd());
            System.Threading.Thread.Sleep(1);
        }

        // application outputs
        output = outputBuilder.ToString();
        error = errorBuilder.ToString();

        // on success
        return true;
    }


    /// Run an external application.
    /// <param name="fileName">         application file to execute. </param>
    /// <param name="args">             application argumentss to execute. </param>
    /// <param name="workingDirectory"> application working directory. </param>
    /// <param name="waitForExit">      wait until the application ends. </param>
    public static void RunExternalFile(string fileName, string args, string workingDirectory, bool waitForExit)
    {
        Debug.LogFormat("RunExternalFile: {0} args: {1}", fileName, args);
        // fill in the application process info
        System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo();
        info.FileName = fileName;
        if (false == string.IsNullOrEmpty(workingDirectory))
        {
            info.WorkingDirectory = workingDirectory;
        }
        info.Arguments = args;

        // start the application process
        System.Diagnostics.Process proc = System.Diagnostics.Process.Start(info);
        if (true == waitForExit)
        {
            proc.WaitForExit();
        }
    }

    [CMenuItem("Tools/AutoBake 2.0(自动烘焙 2.0)/下载Bake数据", MenuType.Version, "下载服务器上的Bake原始数据", false, 1300)]
    public static void DownloadBakeFiles()
    {
        DownloadBakedFilesWindow.Init();
    }

    [CMenuItem("Tools/AutoBake 2.0(自动烘焙 2.0)/下载Windows AB包", MenuType.Version, "下载服务器上的Windows版本Assetbundle资源", false, 1300)]
    public static void DownloadWindowsABs()
    {
        EditorUtility.DisplayDialogComplex("出错啦！", "Windows AB包资源过大，无法在UnityEditor内下载。请自行前往175.17或183.105下载。具体事宜咨询 “翁小松” 或 “黄聪”。", "明白了", "知道了", "我懂了");
    }

    [CMenuItem("Tools/AutoBake 2.0(自动烘焙 2.0)/下载iOS AB包", MenuType.Version, "下载服务器上的IOS版本Assetbundle资源", false, 1300)]
    public static void DownloadIOSABs()
    {
        EditorUtility.DisplayDialogComplex("出错啦！", "iOS AB包资源过大，无法在UnityEditor内下载。请自行前往175.17或183.105下载。具体事宜咨询 “翁小松” 或 “黄聪”。", "明白了", "知道了", "我懂了");
    }

    [CMenuItem("Tools/AutoBake 2.0(自动烘焙 2.0)/下载Android AB数据", MenuType.Version, "下载服务器上的Android版本Assetbundle资源", false, 1300)]
    public static void DownloadAndroidABs()
    {
        EditorUtility.DisplayDialogComplex("出错啦！", "Android AB包资源过大，无法在UnityEditor内下载。请自行前往175.17或183.105下载。具体事宜咨询 “翁小松” 或 “黄聪”。", "明白了", "知道了", "我懂了");
    }

    /// Move all files under the source directory to the destination one.
    /// <param name="sourceDirName">the source directory to move from.</param>
    /// <param name="destDirName">  the destination directory to move to.</param>
    /// <param name="copySubDirs">  if true, also include files under subdirectories.</param>
    public static void MoveDirectory(string sourceDirName, string destDirName, bool copySubDirs, Action<string> moveCallback = null)
    {
        // check whether the source directory is existed
        DirectoryInfo srcDir = new DirectoryInfo(sourceDirName);
        if (false == srcDir.Exists)
        {
            Debug.LogError("[BUILD ERROR] MoveDirectory: Source directory does not exist: " + sourceDirName + "\r\n");
            return;
        }

        // get all subdirectories under the source directory
        DirectoryInfo[] subDirs = srcDir.GetDirectories();

        // if the destination directory dest not exist, create it
        if (false == Directory.Exists(destDirName))
        {
            Directory.CreateDirectory(destDirName);
        }

        // get the files in the root directory and copy them to the new location.
        FileInfo[] files = srcDir.GetFiles();
        foreach (FileInfo file in files)
        {
            // remove ReadOnly attribute from the "to" file
            string tempPath = Path.Combine(destDirName, file.Name);
            if (true == File.Exists(tempPath))
            {
                File.SetAttributes(tempPath, FileAttributes.Normal);
                File.Delete(tempPath);
            }
            // create destination directory if not exists
            else if (false == Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // copy file now
            if (moveCallback != null)
                moveCallback(file.Name);
            file.MoveTo(tempPath);
        }

        // if copying subdirectories, copy them and their contents to new location. 
        if (true == copySubDirs)
        {
            foreach (DirectoryInfo subDir in subDirs)
            {
                string tempPath = Path.Combine(destDirName, subDir.Name);
                MoveDirectory(subDir.FullName, tempPath, copySubDirs);
            }
        }
    }

    [MenuItem("Test/Foo", false, 2000)]
    public static void Test()
    {
        float beginTime = Time.realtimeSinceStartup;
        try
        {
            var defines = new List<string>();
            // All parses end
            Debug.Log("Start to Set Custom Defines\r\n");

            var sds = UnityEditor.PlayerSettings.GetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup);
            var sdsList = new List<string>(sds.Split(';'));
            // remove all custom defines.
            sdsList.RemoveAll(item => item.StartsWith("CUSTOM_"));
            foreach (var define in defines)

                sdsList.Add("CUSTOM_" + define);
            sds = string.Join(";", sdsList);
            UnityEditor.PlayerSettings.SetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup, sds);
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }
        Debug.LogFormat("Use Time: {0}s", Time.realtimeSinceStartup - beginTime);
    }

    public static bool DownloadFile(DirectoryInfo dirInfo, string username, string password, string host, int port, string targetPathName)
    {
        var fileName = targetPathName.Split('/')[targetPathName.Split('/').Length - 1];
        if(File.Exists(dirInfo.FullName +"/"+ fileName))
        {
            File.Delete(dirInfo.FullName + "/" + fileName);
        }
        var conInfo = new Renci.SshNet.ConnectionInfo(
            host,
            port,
            username,
            new Renci.SshNet.AuthenticationMethod[] {
                new Renci.SshNet.PasswordAuthenticationMethod(username, password),
            });
        try
        {
            using (var scpClient = new Renci.SshNet.ScpClient(conInfo))
            {
                scpClient.Connect();
                scpClient.Download(targetPathName, dirInfo);
                scpClient.Disconnect();
            }
        }
        catch (Exception ex)
        {
            Debug.LogErrorFormat("[OP ERROR] Download File FAILED!!! Exception: {0}", ex);
            Debug.LogException(ex);
            return false;
        }
        return true;
    }
    public static void SyncDir(string sourcePath, string destPath, Action<string, string, float> callback)
    {
        DirectoryInfo srcDirInfo = new DirectoryInfo(sourcePath);
        if (false == srcDirInfo.Exists)
        {
            Debug.LogError("[BUILD ERROR] SyncDir: Source directory does not exist: " + sourcePath + "\r\n");
            return;
        }
        DirectoryInfo destDirInfo = new DirectoryInfo(destPath);
        if (false == destDirInfo.Exists)
        {
            Debug.LogError("[BUILD ERROR] SyncDir: Destination directory does not exist: " + destPath + "\r\n");
            return;
        }

        // calculate MD5 for downloaded files.
        callback("MD5 downloaded files...", srcDirInfo.FullName, 0.0f);

        var md5 = System.Security.Cryptography.MD5.Create();
        var srcFileInfoList = srcDirInfo.GetFiles("*", SearchOption.AllDirectories);
        var srcFilesMD5 = new Dictionary<string, byte[]>();
        foreach (var srcFileInfo in srcFileInfoList)
        {
            using (var fileStream = new FileStream(srcFileInfo.FullName, FileMode.Open))
            {
                var key = srcFileInfo.FullName.Substring(srcDirInfo.FullName.Length);
                srcFilesMD5.Add(key, md5.ComputeHash(fileStream));
            }
        }

        // delete & md5 old local files.
        var destFilesMD5 = new Dictionary<string, byte[]>();
        List<DirectoryInfo> localDirInfoList = new List<DirectoryInfo>();
        localDirInfoList.AddRange(new DirectoryInfo[] {
            new DirectoryInfo(destDirInfo.FullName + "/Asset/art_resource/effect/effect/sceneEffect_buff_import"),
            new DirectoryInfo(destDirInfo.FullName + "/Asset/art_resource/effect/effect/sceneEffect_import"),
            new DirectoryInfo(destDirInfo.FullName + "/Asset/art_resource/effect/effect/skillEffect_import"),});
        var MapTaskConfig = AssetDatabase.LoadAssetAtPath<MapTaskMgr>(MAP_TASK_CONFIG_PATH);
        if (MapTaskConfig == null)
        {
            Debug.LogErrorFormat("[BUILD ERROR] SyncDir: Configure File[{0}] is Missing", MAP_TASK_CONFIG_PATH);
            return;
        }
        foreach (var mapTaskList in MapTaskConfig.mapNameList)
        {
            foreach (var task in mapTaskList.taskList)
            {
                localDirInfoList.Add(new DirectoryInfo(string.Format("{0}/Asset/scene/{1}/{2}", destDirInfo.FullName, mapTaskList.mapName, task)));
            }
        }
        foreach (var localDirInfo in localDirInfoList)
        {
            if (localDirInfo.Exists)
            {
                callback("Deleting & MD5 old files....", localDirInfo.FullName.Substring(destDirInfo.FullName.Length), 0.0f);

                var targetFileInfoList = localDirInfo.GetFiles("*", SearchOption.AllDirectories);
                foreach (var targetFileInfo in targetFileInfoList)
                {
                    var key = targetFileInfo.FullName.Substring(destDirInfo.FullName.Length);
                    if (!srcFilesMD5.ContainsKey(key))
                    {
                        // delete old file.
                        try
                        {
                            File.SetAttributes(targetFileInfo.FullName, FileAttributes.Normal);
                            File.Delete(targetFileInfo.FullName);
                            Debug.LogFormat("[DEBUG] Delete Old Baked File Succssed: {0}", targetFileInfo.FullName);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogFormat("[DEBUG] Delete Old Baked File Failed: {0}", targetFileInfo.FullName);
                            Debug.LogException(ex);
                        }
                    }
                    else
                    {
                        // MD5 old file.
                        using (var fileStream = new FileStream(targetFileInfo.FullName, FileMode.Open))
                        {
                            destFilesMD5.Add(key, md5.ComputeHash(fileStream));
                        }
                    }
                }
            }
        }

        // move new files.
        callback("Move new files...", "", 0.0f);
        foreach (var srcFilePair in srcFilesMD5)
        {
            bool needToMove = false;
            if (destFilesMD5.ContainsKey(srcFilePair.Key))
            {
                if (!srcFilePair.Value.SequenceEqual(destFilesMD5[srcFilePair.Key]))
                {
                    needToMove = true;
                }
            }
            else
            {
                needToMove = true;
            }

            if (needToMove)
            {
                var srcFileInfo = new FileInfo(srcDirInfo.FullName + srcFilePair.Key);
                var destFileInfo = new FileInfo(destDirInfo.FullName + srcFilePair.Key);
                string destDirName = destFileInfo.DirectoryName;
                // remove ReadOnly attribute from the "to" file
                if (true == File.Exists(destFileInfo.FullName))
                {
                    File.SetAttributes(destFileInfo.FullName, FileAttributes.Normal);
                    File.Delete(destFileInfo.FullName);
                }
                // create destination directory if not exists
                else if (false == Directory.Exists(destDirName))
                {
                    Directory.CreateDirectory(destDirName);
                }

                // copy file now
                callback("Move new files...", srcFilePair.Key, 0.0f);
                srcFileInfo.MoveTo(destFileInfo.FullName);
            }
        }
    }
}

public class DownloadBakedFilesWindow : EditorWindow
{
    public string mBranchName;
    public static void Init()
    {
        if (0 == Resources.FindObjectsOfTypeAll<DownloadBakedFilesWindow>().Length)
        {
            var win = ScriptableObject.CreateInstance<DownloadBakedFilesWindow>();
            win.titleContent = new GUIContent("下载路径");
            win.Show();
        }
    }

    public void OnEnable()
    {
        GetBranchName();
        LoadVersion();
    }
    private static string IP = "192.168.175.17";
    private static int PORT = 22;
    private static string USERNAME = "art";
    private static string PASSWORD = "1";

    private string mServerVersoin;
    private string mClientVersion;

    static string GetFinalPath(string path)
    {

#if SCENE_EDITOR
        return Application.dataPath + "/../" + path;
#else
        return Application.dataPath + "/../../../art/Editor/SceneEditor/" + path;

#endif
    }
    void LoadVersion()
    {
        string targetName = mBranchName;
        if ("mainline" == mBranchName)
            targetName = "";
        else
            targetName = mBranchName + "/";
        string loadDir = GetFinalPath("Intermediate/new");
        string filePath = loadDir + "/intermediate_change_numbers.txt";
        string clientPath = GetFinalPath("intermediate_change_numbers_c.txt");
        if (!Directory.Exists(loadDir))
        {
            Directory.CreateDirectory(loadDir);
        }
        AutoBuild2.DownloadFile(new DirectoryInfo(loadDir), USERNAME, PASSWORD, IP, PORT, string.Format("/home/art/x2m_builds/{0}intermediate_change_numbers.txt", targetName));

        mServerVersoin = GetVersion(filePath);
        mClientVersion = GetVersion(clientPath);

    }

    string GetVersion(string path)
    {
        if (File.Exists(path))
        {
            string[] lines = File.ReadAllLines(path);
            foreach (var line in lines)
            {
                if (line.StartsWith("save_lmInfo:"))
                {
                    return line.Remove(0, "save_lmInfo:".Length);
                }
            }
        }
        return "0";
    }
    GUIStyle labelStyle;
    public void OnGUI()
    {
        GUILayout.Space(10);
        if (mServerVersoin != mClientVersion)
        {
            EditorGUILayout.HelpBox("发现新版本，需要下载Bake数据！", MessageType.Error);
        }
        EditorGUILayout.LabelField("服务器版本号", mServerVersoin);
        EditorGUILayout.LabelField("本地版本号", mClientVersion);
        if (labelStyle == null)
        {
            labelStyle = new GUIStyle(GUI.skin.label);
        }
        labelStyle.fontSize = 12;
        labelStyle.normal.textColor = Color.white;
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("请输入bake数据下载的分支选择", labelStyle);
        GUILayout.FlexibleSpace();
        EditorGUILayout.EndHorizontal();
        GUILayout.Space(20);

        GUILayout.BeginHorizontal();
        EditorGUI.BeginChangeCheck();
        mBranchName = TextField(mBranchName);
        if (EditorGUI.EndChangeCheck())
        {
            LoadVersion();
        }
        GUILayout.EndHorizontal();
        GUILayout.Space(20);

        labelStyle.fontSize = 20;
        labelStyle.normal.textColor = Color.red;
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("分支名输入错误将导致无法进入游戏！！！", labelStyle);
        GUILayout.FlexibleSpace();
        EditorGUILayout.EndHorizontal();
        GUILayout.Space(20);

        labelStyle.fontSize = 12;
        labelStyle.normal.textColor = Color.gray;

        GUILayout.BeginHorizontal();
        if (GUILayout.Button(new GUIContent("OK")))
        {
            Close();
            DownloadBakeData(mBranchName);
        }
        if (GUILayout.Button(new GUIContent("Cancel")))
        {
            Close();
        }
        GUILayout.EndHorizontal();
    }

    private void GetBranchName()
    {
        string[] paths = Application.dataPath.Split('/');

        if (Application.dataPath.Contains("mainline"))
        {
            mBranchName = "mainline";
        }
        else if (Application.dataPath.Contains("branches"))
        {
            for (int i = 0; i < paths.Length; i++)
            {
                if ("branches" == paths[i])
                {
                    mBranchName = paths[i + 1];
                    break;
                }
            }
        }
    }

    private static string HandleCopyPaste(int controlID)
    {
        if (GUIUtility.keyboardControl == controlID)
        {
            if (Event.current.type == EventType.KeyUp && (Event.current.modifiers == EventModifiers.Control || Event.current.modifiers == EventModifiers.Command))
            {
                if (Event.current.keyCode == KeyCode.C)
                {
                    Event.current.Use();
                    TextEditor editor = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
                    editor.Copy();
                }
                else if (Event.current.keyCode == KeyCode.V)
                {
                    Event.current.Use();
                    TextEditor editor = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
                    editor.Paste();
                    return editor.text;
                }
                else if (Event.current.keyCode == KeyCode.A)
                {
                    Event.current.Use();
                    TextEditor editor = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
                    editor.SelectAll();
                }
            }
        }
        return null;
    }

    private static string TextField(string value)
    {
        int textFieldID = GUIUtility.GetControlID("TextField".GetHashCode(), FocusType.Keyboard) + 1;
        if (textFieldID == 0)
            return value;

        value = HandleCopyPaste(textFieldID) ?? value;
        return GUILayout.TextField(value);
    }

    public void DownloadBakeData(string branchName)
    {
        if ("mainline" == branchName)
            branchName = "";
        else
            branchName += "/";
        try
        {


            LoadVersion();
            if (mServerVersoin == mClientVersion)
            {
                if (!EditorUtility.DisplayDialog("提示", "没有发现需要的更新，是否强制更行？", "是", "否"))
                {
                    return;
                }
            }
            string intermePath = GetFinalPath("Intermediate");
            string verionPath = GetFinalPath("");
            string completedVersionPath = GetFinalPath("intermediate_change_numbers_c.txt");
            string ExtractPath = GetFinalPath("");
            string downloadPath = GetFinalPath("Intermediate/x2m_intermediate.zip");
            if (Directory.Exists(intermePath))
                Directory.Delete(intermePath, true);
            if (!Directory.Exists(intermePath))
            {
                Directory.CreateDirectory(intermePath);
            }
            float beginTime = Time.realtimeSinceStartup;
            EditorUtility.DisplayCancelableProgressBar("Downloading...", "Download with SCP, So I Don't Know the Progress. Pls be patient", 0.3f);
            AutoBuild2.DownloadFile(new DirectoryInfo(intermePath), USERNAME, PASSWORD, IP, PORT, string.Format("/home/art/x2m_builds/{0}x2m_intermediate.zip", branchName));
            AutoBuild2.DownloadFile(new DirectoryInfo(verionPath), USERNAME, PASSWORD, IP, PORT, string.Format("/home/art/x2m_builds/{0}intermediate_change_numbers.txt", branchName));
            Debug.LogFormat("Download used {0}s.", Time.realtimeSinceStartup - beginTime);
            beginTime = Time.realtimeSinceStartup;
            FileStream fs = new FileStream(downloadPath, FileMode.Open);
            try
            {

                //using (var ms = new MemoryStream())
                //{
                //    fs.CopyTo(ms);
                var zipFile = ZipFile.Read(fs);
                int totalCount = zipFile.Count;
                int count = 0;
                foreach (var e in zipFile)
                {
                    count++;
                    var filename = Path.GetFileName(e.FileName);
                    if (EditorUtility.DisplayCancelableProgressBar("Extracting...", string.Format("Extracting {0} from x2m_intermediate.zip.", filename), (float)count / (float)totalCount))
                    {
                        Debug.LogError("Cancelled by user.");
                        return;
                    }
                    e.Extract(ExtractPath, ExtractExistingFileAction.OverwriteSilently);
                }
                // }
            }
            finally
            {
                fs.Close();
                EditorUtility.ClearProgressBar();
            }

            Debug.LogFormat("Extraction used {0}s.", Time.realtimeSinceStartup - beginTime);
            beginTime = Time.realtimeSinceStartup;

            try
            {
                /*MoveDirectory(Application.dataPath + "/../../../art/Editor/SceneEditor/Intermediate/Assets", Application.dataPath + "/../../../art/Editor/SceneEditor/Assets", true, (filename) =>
                {
                    EditorUtility.DisplayProgressBar("Replacing...", string.Format("Replacing the local file {0}.", filename), 0.0f);
                });*/
                AutoBuild2.SyncDir(
                    GetFinalPath("Intermediate/Assets"),
                    GetFinalPath("Assets"),
                    (title, message, progress) =>
                    {
                        EditorUtility.DisplayProgressBar(title, message, progress);
                    });
                File.Copy(GetFinalPath("intermediate_change_numbers.txt"), completedVersionPath, true);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
            Debug.LogFormat("Sync used {0}s.", Time.realtimeSinceStartup - beginTime);
            beginTime = Time.realtimeSinceStartup;
            Directory.Delete(GetFinalPath("Intermediate"), true);
            AssetDatabase.Refresh();

            LoadVersion();
        }
        catch (Exception ex)
        {
            Debug.LogErrorFormat("DownloadBakeFiles FAILED!!! Exception: {0}", ex);
            EditorUtility.ClearProgressBar();
        }
    }
}
