﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEditor;
using Bokura.CustomTools;
using GiantUtility;
using System.Text;

public class AutoTest2
{
    [CMenuItem("Test/编译/版本编译测试",MenuType.Other,"", false, 100)]
    public static void CaseCompileTest()
    {
        try
        {
            Debug.LogFormat("Begin to CompileTest.");
            var testOutputPath = Application.dataPath.Replace("Assets", "") + "Test/";
            if (!Directory.Exists(testOutputPath))
                Directory.CreateDirectory(testOutputPath);
            var testAssetPath = "Assets/AutoTest/env_test_d.png";
            var testAsset = AssetDatabase.LoadAssetAtPath<Texture2D>(testAssetPath);
#pragma warning disable 0618
            BuildPipeline.BuildAssetBundle(testAsset, new Object[] { }, testOutputPath + "env_test_d.u", BuildAssetBundleOptions.ChunkBasedCompression, EditorUserBuildSettings.activeBuildTarget);
#pragma warning restore 0618
            Debug.Log("CompileTest finished.");
        }
        catch (System.Exception ex)
        {
            Debug.LogErrorFormat("[TEST ERROR] Compile failed. Ex: {0}", ex);
        }
    }
}
