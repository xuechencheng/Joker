using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using Bokura.CustomTools;
using System.Reflection;
using System;
using System.Linq;
using UnityEditorInternal;
using Game;
public class GameEntityMonitor : EditorWindow
{

    // Use this for initialization
    [CMenuItem("Window/GameEntityMonitor",MenuType.Tools)]
    public static void Start () {
        var wnd = GetWindow<GameEntityMonitor>();
        wnd.Show();

    }
    float SpaceDistance = 4;
    float WindowWidth { get { return position.width - SpaceDistance * 2; } }
    float WindowHeight { get { return position.height - SpaceDistance * 2; } }

    ScrutinyConfig Config = null;
    ReorderableList EntityList = null;
    ReorderableList SingletonList = null;
    private void OnEnable()
    {
        Config = AssetDatabase.LoadAssetAtPath<ScrutinyConfig>("Assets/ScrutinyConfig.asset");
        if(Config == null)
        {
            Config = ScriptableObject.CreateInstance<ScrutinyConfig>();
            AssetDatabase.CreateAsset(Config, "Assets/ScrutinyConfig.asset");
        }

        EntityList = new ReorderableList(Config.EntityMonitor, Config.EntityMonitor.GetType());
        EntityList.drawElementCallback = (rect, index, isActive, isFocused) =>
        {
            OnEntityFieldGUI(rect,Config.EntityMonitor[index]);
        };
        EntityList.drawHeaderCallback = (rect) =>
         {
             EditorGUI.LabelField(rect, "实体详情");
         };
        //EntityList.onAddCallback = (list) => { SaveConfig(); };
        EntityList.onRemoveCallback += (list) => { Config.EntityMonitor.RemoveAt(list.index); SaveConfig(); };
        EntityList.onChangedCallback += (list) => { SaveConfig(); };
        EntityList.onSelectCallback = (list) => { AddMonitorContent = Config.EntityMonitor[list.index]; };
        EntityList.displayAdd = false;

        SingletonList = new ReorderableList(Config.SingletonMonitor, Config.SingletonMonitor.GetType());
        SingletonList.drawElementCallback = (rect, index, isActive, isFocused) =>
        {
            if(ShowSingle)
                OnSingletonFieldGUI(rect, Config.SingletonMonitor[index]);
        };
        SingletonList.drawHeaderCallback = (rect) =>
        {
            ShowSingle = EditorGUI.Foldout(rect,ShowSingle, "单例");
            if (!ShowSingle)
            {
                SingletonList.elementHeight = 0;
                SingletonList.displayRemove = false;
            }
            else {
                SingletonList.elementHeight = 20;
                SingletonList.displayRemove = true;
            }

        };
        //SingletonList.onAddCallback = (list) => { SaveConfig(); };
        SingletonList.onRemoveCallback += (list) => { Config.SingletonMonitor.RemoveAt(list.index); SaveConfig(); };
        SingletonList.onChangedCallback += (list) => {  SaveConfig(); };
        SingletonList.onSelectCallback =  (list) => { AddMonitorContent = Config.SingletonMonitor[list.index];  };
        SingletonList.displayAdd = false;
    }
    private void SaveConfig()
    {
        EditorUtility.SetDirty(Config);
        //AssetDatabase.SaveAssets();
    }
    private void OnDisable()
    {
        SaveConfig();
        AssetDatabase.SaveAssets();
    }
    // Update is called once per frame
    void Update () {
		
	}
    private string AddMonitorContent = string.Empty;
    private bool Setting = false;
    private void OnGUI()
    {
        if (!Application.isPlaying)
        {
            GUILayout.Label("请运行客户端");
            return;
        }

        EditorGUILayout.BeginHorizontal(GUI.skin.box, GUILayout.Width(WindowWidth));

        AddMonitorContent = EditorGUILayout.TextField("新增监视数据", AddMonitorContent);
        if (GUILayout.Button("Add",GUILayout.Width(40)))
        {
            if(SelectedEntity !=  null)
            {
                if(GetFieldValue(SelectedEntity, AddMonitorContent) != null)
                {
                    Config.AddMonitor(AddMonitorContent);
                    EditorUtility.SetDirty(Config);
                }
            }
        }
        if (GUILayout.Button("Add Single", GUILayout.Width(80)))
        {
            if (GetSingleValue(AddMonitorContent) != null)
            {
                Config.AddMonitor(AddMonitorContent, true);
                EditorUtility.SetDirty(Config);
            }
        }
        var oldclr =  GUI.color;
        GUI.color = Setting ? Color.red : GUI.color;
        if (GUILayout.Button("Set", GUILayout.Width(40)))
        {
            Setting = !Setting;
        }
        GUI.color = oldclr;
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal(GUI.skin.box, GUILayout.Width(WindowWidth));
        OnSingletonGUI();
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();

        OnAllEntityGUI();
        OnAnimatorGUI();
        OnEntityGUI();

        EditorGUILayout.EndHorizontal();
        Repaint();
    }
    bool ShowSingle = true;
    private void OnSingletonGUI()
    {
        EditorGUILayout.BeginVertical();

        SingletonList.DoLayoutList();

        EditorGUILayout.EndVertical();
    }
    private void OnSingletonFieldGUI(Rect rect,string pattern)
    {
        
        var value = GetSingleValue(pattern);
        EditorGUI.LabelField(rect, string.Format("{0}:{1}", pattern, value));
        
        if (value != null)
        {
            OnEditGUI(rect, pattern, value, (o) => { return SetSingleValue(pattern, o); });
        }

    }

    private Vector2 allentity_scroll = new Vector2();
    private Vector2 animator_scroll = new Vector2();
    private Vector2 entity_scroll = new Vector2();
    private Game.Entity SelectedEntity = null;
    private void OnAllEntityGUI()
    {
        
        allentity_scroll = EditorGUILayout.BeginScrollView(allentity_scroll, GUI.skin.box,GUILayout.Width(160),GUILayout.Height(500));
        //GUILayout.Label(string.Format("实体列表({0})", Game.GameScene.Instance != null ? Game.GameScene.Instance.AllEntitys.Count : 0));
        var entitycount = Game.GameScene.Instance != null ? Game.GameScene.Instance.AllEntitys.Count : 0;
        ShowAnimator = EditorGUILayout.ToggleLeft($"动画   实体列表({entitycount})", ShowAnimator, GUILayout.Width(160));
        if (Game.GameScene.Instance != null)
        {
            var entities = Game.GameScene.Instance.AllEntitys.Values.ToList();
            entities.Sort((Game.Entity l, Game.Entity r) => { return (int)(Vector3.Distance(l.Position, Game.GameScene.Instance.MainChar.Position) - Vector3.Distance(r.Position, Game.GameScene.Instance.MainChar.Position)); });

            foreach (var kv in entities)
            {
                var oldclr = GUI.color;
                GUI.color = SelectedEntity == kv ? Color.red : GUI.color;
                if (GUILayout.Button(kv.Name))
                {
                    SelectedEntity = kv;
                    Selection.activeObject = kv.Avatar.unityObject.GetComponentInChildren<Animator>();
                }
                GUI.color = oldclr;
            }
        }

        EditorGUILayout.EndScrollView();
    }
    #region animator
    bool ShowAnimator = false;
    void OnAnimatorGUI()
    {
        if (SelectedEntity == null || SelectedEntity.Avatar == null) return;

        var animator = SelectedEntity.Avatar.animator.MainAnimator;
        if(animator != null && ShowAnimator)
        {
            UnityEditor.Animations.AnimatorController animController;
            if (animator.runtimeAnimatorController.GetType() == typeof(AnimatorOverrideController))
                animController = ((AnimatorOverrideController)animator.runtimeAnimatorController).runtimeAnimatorController as UnityEditor.Animations.AnimatorController;
            else
                animController = animator.runtimeAnimatorController as UnityEditor.Animations.AnimatorController;

            //GUILayout.Label(string.Format("状态"));
            //ShowAnimator = EditorGUILayout.Foldout( ShowAnimator, "单例");
            animator_scroll = EditorGUILayout.BeginScrollView(animator_scroll, GUI.skin.box, GUILayout.Width(140), GUILayout.Height(500));

            //GUILayout.BeginVertical("Box");
            //EditorGUI.indentLevel++;
            for (int i = 0; i < animController.layers.Length; i++)
                OnStatesRecursiveGUI(animator,animController.layers[i].stateMachine, animController.layers[i].stateMachine);
            //EditorGUI.indentLevel--;
            //GUILayout.EndVertical();
            EditorGUILayout.EndScrollView();
        }
    }
    private List<AnimatorState> GetStates(AnimatorStateMachine sm)
    {
        List<AnimatorState> stateArray = new List<AnimatorState>();
        foreach (ChildAnimatorState childState in sm.states)
        {
            stateArray.Add(childState.state);
        }

        return stateArray;
    }
    protected Dictionary<string, bool> open = new Dictionary<string, bool>();

    private void OnStatesRecursiveGUI(Animator animator, AnimatorStateMachine sm, AnimatorStateMachine parentSM)
    {
        if (!open.ContainsKey(sm.name)) open.Add(sm.name, false);

        open[sm.name] = EditorGUILayout.Foldout(open[sm.name], sm.name);
        EditorGUI.indentLevel++;
        if (open[sm.name] == true)
        {
            var states = GetStates(sm);
            foreach (var s in states)
            {
                if (GUILayout.Button(string.Format("{0} {1}", s.name, s.GetFullPathHash(parentSM))))
                {
                    for (int i = 0; i < animator.layerCount; i++)
                    {
                        if (animator.HasState(i, Animator.StringToHash(s.name)))
                            animator.Play(s.name, i);
                    }
                }
            }
        }

        foreach (ChildAnimatorStateMachine childStateMachine in sm.stateMachines)
        {
            OnStatesRecursiveGUI(animator,childStateMachine.stateMachine, parentSM);
        }
        EditorGUI.indentLevel--;
    }

    #endregion
    private void OnEntityGUI()
    {
        //EditorGUILayout.BeginVertical(GUI.skin.box, GUILayout.Width(WindowWidth - 100 - SpaceDistance ), GUILayout.Height(500));
        entity_scroll = EditorGUILayout.BeginScrollView(entity_scroll, GUI.skin.box, GUILayout.Width(WindowWidth - 160 - (ShowAnimator ? 140:0) - SpaceDistance *  2 ), GUILayout.Height(500));

        EntityList.DoLayoutList();

        EditorGUILayout.EndScrollView();
    }
    string Editing = string.Empty;
    string EditContent = string.Empty;
    private void OnEntityFieldGUI(Rect rect, string pattern )
    {
        var value = GetFieldValue(SelectedEntity, pattern);
        EditorGUI.LabelField(rect, string.Format("{0}:{1}", pattern, value), GUI.skin.label);

        if (value != null)
        {
            OnEditGUI(rect, pattern, value, (o) => { return SetFieldValue(SelectedEntity, pattern, o); });

        }
    }

    delegate bool SetValueDelegate(object content);
    private void OnEditGUI(Rect rect, string pattern,object value, SetValueDelegate action)
    {
        if (Editing.Equals(pattern))
        {

            var edit_rect = new Rect(rect.x + rect.width - 350, rect.y , 300, rect.height - 2);
            value = OnObjectField(edit_rect, value);
            //EditContent = EditorGUI.TextField(rect, EditContent);
            try
            {
                if (action != null && value != null)
                {
                    action(value);
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning(e);
            }

            var editbtn_rect = new Rect(rect.x + rect.width - 50, rect.y, 50, rect.height - 3);
            if (EditorGUI.DropdownButton(editbtn_rect, new GUIContent("Cancel"), FocusType.Keyboard, GUI.skin.button))
            {
                Editing = string.Empty;
            }

        }
        else
        {
            var editbtn_rect = new Rect(rect.x + rect.width - 50, rect.y,50,rect.height - 3);
            if (EditorGUI.DropdownButton(editbtn_rect, new GUIContent("Edit"), FocusType.Keyboard, GUI.skin.button))
                Editing = pattern;

        }

    }

    private object OnObjectField(Rect rect,object o)
    {
        if (o == null) return null;
        if(IsInteger(o.GetType()))
        {
            o = EditorGUI.IntField(rect, (int)o);
            return o;
        }else if(o.GetType() == typeof(double))
        {
            o = EditorGUI.DoubleField(rect, (double)o);
            return o;
        }
        else if (o.GetType() == typeof(float))
        {
            o = EditorGUI.FloatField(rect, (float)o);
            return o;
        }else if(o.GetType() == typeof(bool))
        {
            o = EditorGUI.Toggle(rect, (bool)o);
            return o;
        }else if(o.GetType() == typeof(Vector3))
        {
            o = EditorGUI.Vector3Field(rect,"", (Vector3)o);
            return o;
        }
        else if (o.GetType() == typeof(Vector2))
        {
            o = EditorGUI.Vector3Field(rect, "", (Vector2)o);
            return o;
        }
        return null;
    }

    bool IsInteger(Type t)
    {
        if (typeof(byte) == t || typeof(UInt16) == t || typeof(Int16) == t || typeof(uint) == t || typeof(Int32) == t || typeof(UInt64) == t || typeof(Int64) == t)
            return true;
        return false;
    }
    bool IsNumber(Type t)
    {
        if (typeof(double) == t || typeof(float) == t )
            return true;
        return false;
    }
    private void OnEditGUI(Rect rect, string pattern, SetValueDelegate action)
    {
        //GUILayout.ExpandWidth(true);
        if (Editing.Equals(pattern))
        {
            rect.x += rect.width - 300 ;
            rect.width = 100;
            EditContent = EditorGUI.TextField(rect,EditContent);

            rect.x += 100;
            rect.width = 100;
            if (EditorGUI.DropdownButton(rect, new GUIContent("OK"), FocusType.Keyboard, GUI.skin.button))
            {
                try
                {
                    if (action != null)
                    {
                        if (action(EditContent)) Editing = string.Empty;
                    }
                }
                catch (Exception e)
                {
                    Debug.LogWarning(e);
                }

            }

            rect.x += 100;
            //rect.width = 100;

            if (EditorGUI.DropdownButton(rect, new GUIContent("Cancel"), FocusType.Keyboard, GUI.skin.button))
            {
                Editing = string.Empty;
            }

        }
        else 
        {
            rect.x += rect.width - 50;
            rect.width = 50;
            if (EditorGUI.DropdownButton(rect, new GUIContent("Edit"), FocusType.Keyboard,GUI.skin.button))
                Editing = pattern;

        }
        //if (Setting && GUILayout.Button("Del", GUILayout.Width(40)))
        //{
        //    Config.SingletonMonitor.Remove(pattern);
        //    Config.EntityMonitor.Remove(pattern);
        //}
    }






    #region Reflection
    private Assembly CSharpAssemply = null;
    private Type GetTypeInfo(string fieldname)
    {
        if(CSharpAssemply == null)
        {
            var path = Application.dataPath + "/../Library/ScriptAssemblies/Assembly-CSharp.dll";
            CSharpAssemply = Assembly.LoadFrom(path);
        }

        Type t = null;
        var typename = fieldname;
        var lastindex = fieldname.Length;
        do
        {
            typename = typename.Substring(0, lastindex);
            t = CSharpAssemply.GetType(typename);
            lastindex = typename.LastIndexOf('.');
        } while (lastindex > 0 && t == null && !string.IsNullOrEmpty(typename));

        return t;
    }
    private bool SetSingleValue(string fieldname,object v)
    {
        Type t = GetTypeInfo(fieldname);
        if (t == null) return false;
        fieldname = fieldname.Substring(t.FullName.Length);
        var fiels = fieldname.Split('.').Where(s => !string.IsNullOrEmpty(s)).ToArray();

        if(fiels.Length == 1)
        {
            return SetStaticValue(t, fiels[0], v);
        }
        else
        {
            var obj = GetStaticValue(t, fiels[0]);
            var lstfields = new List<string>(fiels);
            lstfields.RemoveAt(0);
            return SetFieldValue(obj, lstfields.ToArray(), v);
        }
    }
    private object GetSingleValue(string fieldname)
    {
        Type t = GetTypeInfo(fieldname);
        if (t == null) return null;
        fieldname = fieldname.Substring(t.FullName.Length);
        var fiels = fieldname.Split('.').Where(s => !string.IsNullOrEmpty(s)).ToArray();
        var obj = GetStaticValue(t, fiels[0]);

        for (int i = 1; i < fiels.Length; i++)
        {
            obj = GetValue(obj, fiels[i]);
            if (obj == null) return null;
        }

        return obj;
    }
    private object GetStaticValue(Type t, string fieldname)
    {
        if (t == null) return null;
        var field = t.GetField(fieldname, flag);
        if (field == null)
        {
            var property = t.GetProperty(fieldname, flag);
            if (property == null) return null;
            return property.GetValue(null);
        }
        return field.GetValue(null);
    }
    private bool SetStaticValue(Type t, string fieldname,object v)
    {
        if (t == null) return false;
        var field = t.GetField(fieldname, flag);
        if (field == null) return false;
        field.SetValue(null,v);
        return true;
    }
    BindingFlags flag = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public;
    private object GetValue(object o,string fieldname)
    {
        if (o == null) return null; 
        var t = o.GetType();
        var field = t.GetField(fieldname, flag);
        if (field == null)
        {
            var property = t.GetProperty(fieldname, flag);
            if (property == null) return null;
            return property.GetValue(o);
        }
        return field.GetValue(o);
    }
    private bool SetValue(object o, string fieldname, object v)
    {
        if (o == null) return false;
        var field = o.GetType().GetField(fieldname, flag);
        if (field == null)
        {
            var property = o.GetType().GetProperty(fieldname, flag);
            if (property == null) return false;
            property.SetValue(o, v);
            return true;
        }
        field.SetValue(o,v);
        return true;
    }
    private string GetFieldString(object o, string fieldname)
    {
        var obj = GetFieldValue(o, fieldname);
        if (obj == null) return "{null}";
        return obj.ToString();
    }
    private bool SetFieldValue(object o, string[] fiels, object v)
    {
        var obj = o;
        for (int i = 0; i < fiels.Length - 1; i++)
        {
            obj = GetValue(obj, fiels[i]);
            if (obj == null) return false;
        }

        return SetValue(obj, fiels[fiels.Length - 1], v);
    }
    private bool SetFieldValue(object o, string fieldname, object v)
    {
        var fiels = fieldname.Split('.');
        return SetFieldValue(o, fiels, v);
    }
    private object GetFieldValue(object o, string fieldname)
    {
        var obj = o;
        var fiels = fieldname.Split('.');
        for (int i = 0; i < fiels.Length; i++)
        {
            obj = GetValue(obj, fiels[i]);
            if (obj == null) return null;
        }
        return obj;
    }
    #endregion
}
