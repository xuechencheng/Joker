﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.Networking;
using Ionic.Zip;
using Bokura.CustomTools;

public class IncBakedFilesDownloader : EditorWindow {

    private string changeNumber = "";

    [CMenuItem("Tools/AutoBake 2.0(自动烘焙 2.0)/下载增量Bake数据(仅限Debug使用)",MenuType.Version, "下载服务器上的Bake原始数据(Debug版本使用)", false, 1400)]
    public static void OpenDialog()
    {
        IncBakedFilesDownloader window = (IncBakedFilesDownloader)EditorWindow.GetWindow(typeof(IncBakedFilesDownloader));
        window.minSize = window.maxSize = new Vector2(200, 80);
        window.Show();
    }

    private void OnGUI()
    {
        bool requireDownload = false;
        EditorGUILayout.BeginVertical();
        try
        {
            EditorGUILayout.BeginHorizontal();
            try
            {
                GUILayout.Label("构建ID: ");
                changeNumber = EditorGUILayout.TextField(changeNumber);
            }
            finally
            {
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.BeginHorizontal();
            try
            {
                if (GUILayout.Button("下载"))
                {
                    if (string.IsNullOrEmpty(changeNumber))
                        Debug.LogError("构建ID不能为空");
                    else
                        requireDownload = true;
                }
            }
            finally
            {
                EditorGUILayout.EndHorizontal();
            }
        }
        finally
        {
            EditorGUILayout.EndVertical();
        }

        if (requireDownload)
        {
            DownloadIncBakeFiles(changeNumber);
            requireDownload = false;
        }
    }

    public static void DownloadIncBakeFiles(string changeNumber)
    {
        try
        {
            UnityWebRequest www = UnityWebRequest.Get(string.Format("http://192.168.175.17/x2m_builds/{0}/x2m_inc_intermediate.zip", changeNumber));
            try
            {
                var async = www.SendWebRequest();
                while (!async.isDone)
                {
                    System.Threading.Thread.Sleep(100);
                    if (EditorUtility.DisplayCancelableProgressBar("Downloading...", string.Format("Download x2m_inc_intermediate.zip {0:0.0}%...", www.downloadProgress * 100.0f), www.downloadProgress))
                    {
                        www.Abort();
                        Debug.LogError("Cancelled by user.");
                        return;
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            if (www.isNetworkError || www.isHttpError)
            {
                Debug.LogError(www.error);
                return;
            }

            try
            {
                using (var ms = new MemoryStream(www.downloadHandler.data))
                {
                    var zipFile = ZipFile.Read(ms);
                    int totalCount = zipFile.Count;
                    int count = 0;
                    foreach (var e in zipFile)
                    {
                        count++;
                        var filename = Path.GetFileName(e.FileName);
                        if (EditorUtility.DisplayCancelableProgressBar("Extracting...", string.Format("Extracting {0} from x2m_inc_intermediate.zip.", filename), (float)count / (float)totalCount))
                        {
                            Debug.LogError("Cancelled by user.");
                            return;
                        }
                        e.Extract(Application.dataPath + "/../../../art/Editor/SceneEditor/", ExtractExistingFileAction.OverwriteSilently);
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            try
            {
                EditorUtility.DisplayProgressBar("Replacing...", "Begin to replace local files.", 0.0f);
                AutoBuild2.MoveDirectory(Application.dataPath + "/../../../art/Editor/SceneEditor/Intermediate/Assets", Application.dataPath + "/../../../art/Editor/SceneEditor/Assets", true, (filename) =>
                {
                    EditorUtility.DisplayProgressBar("Replacing...", string.Format("Replacing the local file {0}.", filename), 0.0f);
                });
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            GiantUtility.GiantIO.DeleteDirectory(Application.dataPath + "/../../../art/Editor/SceneEditor/Intermediate");
            AssetDatabase.Refresh();
        }
        catch (Exception ex)
        {
            Debug.LogErrorFormat("DownloadBakeFiles FAILED!!! Exception: {0}", ex);
        }
    }

}
