﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrutinyConfig : ScriptableObject {
    public List<string> SingletonMonitor = new List<string>();
    public List<string> EntityMonitor = new List<string>();

    public void AddMonitor(string pattern, bool isSingle = false)
    {
        if (isSingle)
            SingletonMonitor.Add(pattern);
        else
            EntityMonitor.Add(pattern);
    }
}
